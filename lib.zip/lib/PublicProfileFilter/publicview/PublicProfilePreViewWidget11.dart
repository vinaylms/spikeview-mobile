import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:multi_charts/multi_charts.dart';
//import 'package:multi_charts/multi_charts.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:spike_view_project/PublicProfileFilter/ShareProfileView.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/SpiderAndSkillDataModel.dart';
import 'package:spike_view_project/TestScore/DocumentListingWidget.dart';
import 'package:spike_view_project/TestScore/DocumentListingWidget.dart';
import 'package:spike_view_project/accomplishment/VideoViewBlack.dart';
import 'package:spike_view_project/accomplishment/portfolio/EditPortFolio.dart';
import 'package:spike_view_project/accomplishment/portfolio/PortfolioViewWidget.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/FullImageView.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';

import 'package:spike_view_project/modal/SkillBarModel.dart';
import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile/UserProfileDashBoard.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:path/path.dart' as path;
import 'package:url_launcher/url_launcher.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:url_launcher/url_launcher.dart';

// Create a Form Widget
class PublicProfilePreViewWidget extends StatefulWidget {
  bool isDisplaySocialEmail;
  String userId;
  bool isGPA, isParentCalling, isFirstTimeCalling;

  PublicProfileDataModel _mPublicProfileDataModel;
  AcoomplismentDataModel _mAcoomplismentDataModel;

  String link, profileType;

  PublicProfilePreViewWidget(this.isDisplaySocialEmail,
      this.isGPA,
      this._mPublicProfileDataModel,
      this._mAcoomplismentDataModel,
      this.link,
      this.profileType, this.userId, this.isParentCalling,
      this.isFirstTimeCalling);

  @override
  PublicProfilePreViewWidgetState createState() {
    return   PublicProfilePreViewWidgetState(
      isGPA,
      _mPublicProfileDataModel,
      _mAcoomplismentDataModel,
    );
  }
}

class PublicProfilePreViewWidgetState
    extends State<PublicProfilePreViewWidget> {
  UploadMedia uploadMedia;

  PublicProfilePreViewWidgetState(this.isGPA,
      this._mPublicProfileDataModel,
      this._mAcoomplismentDataModel,);

  SharedPreferences prefs;
  String userIdPref, roleId;
  ScrollController _scrollController =   ScrollController();

  PublicProfileDataModel _mPublicProfileDataModel;
  AcoomplismentDataModel _mAcoomplismentDataModel;
  final PageController pageController = PageController();
  final dataKey0 =   GlobalKey();
  SpiderAndSkillDataModel _mSpiderAndSkillDataModel;
  static StreamController syncDoneController = StreamController.broadcast();

  bool isSpiderChartApiCalled = true;
  bool isShowSummary = false;
  bool isGPA = false;
  List<double> spiderChartList =   List<double>();
  List<String> spiderChartName =   List<String>();
  StreamSubscription<dynamic> _streamSubscription;

  Future skillApi(isShowLaoder, userId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        print("Preview+++"+Constant.ENDPOINT_SPIDER_AND_SKILL_DETAIL_PUBLIC +
            widget.profileType +
            "&profileId=null" +
            "&userId=" +
            userId.toString() +
            "&roleId=" +
            roleId.toString());

        Response response = await   ApiCalling2().apiCallWithouAuth(
            context,
            Constant.ENDPOINT_SPIDER_AND_SKILL_DETAIL_PUBLIC +
                widget.profileType +
                "&profileId=null" +
                "&userId=" +
                userId.toString() +
                "&roleId=" +
                roleId.toString(),
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mSpiderAndSkillDataModel =
                SpiderAndSkillDataModel.fromJson(response.data);

              setState(() {
                _mSpiderAndSkillDataModel;
              });

              spiderChartName.addAll(_mSpiderAndSkillDataModel.result.toName());
              spiderChartList
                  .addAll(_mSpiderAndSkillDataModel.result.toValue());

              if (spiderChartList.length > 0) {
                if (spiderChartList.length < 3) {
                  if (spiderChartList.length == 1) {
                    spiderChartList.add(0);
                    spiderChartName.add("");

                    spiderChartName.add("");
                    spiderChartList.add(0);
                  } else if (spiderChartList.length == 2) {
                    spiderChartList.add(0);
                    spiderChartName.add("");
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      //  if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("Skillapi++++" + e.toString());
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    // roleId = prefs.getString(UserPreference.ROLE_ID);
    roleId = "1";
    if (widget.userId != null && widget.userId != "null" &&
        widget.userId != "") {
      userIdPref = widget.userId;
    }
   // if (widget._mPublicProfileDataModel.result.isAccomplishment)
      skillApi(true, userIdPref);
  }

  bool isVideoPlay = false;

  @override
  void initState() {
    uploadMedia = UploadMedia(context);
    if (_mAcoomplismentDataModel
        .toJson()
        .length == 0 ||
        (!_mPublicProfileDataModel.result.isAccomplishment)) {
      _mPublicProfileDataModel.result.isAccomplishment = false;
    }
    /*else {
      for (AccomplimentData data in _mAcoomplismentDataModel.accomplimentData) {
        print("data length+++++++++++++" +
            data.name +
            "   " +
            data.toJsonData().length.toString());

        if (data.toJsonData().length == 0) {
          int index = spiderChartName.indexOf(data.name);
          if (index > 0) {
            spiderChartName.removeAt(index);
            spiderChartList.removeAt(index);
          }
        }
      }}*/
    getSharedPreferences();
    getShowExternalLinks(_mAcoomplismentDataModel.accomplimentData);
    _streamSubscription =
        VideoPlayPauseState.syncDoneController.stream.listen((value) {
          setState(() {
            isVideoPlay = false;
          });
        });
    super.initState();
  }

  Widget _loader(BuildContext context, String placeHolderImage) =>
      Center(
          child: Container(
            child:   Image.asset(
              placeHolderImage,
              fit: BoxFit.cover,
            ),
          ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    barList() {
      return Container(
        //   color: Colors.white,
          child:   Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children:   List.generate(
                _mSpiderAndSkillDataModel.result.skillChart.length, (
                int index) {
              return Center(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 15),
                      child: Text(
                        _mSpiderAndSkillDataModel.result.skillChart[index].name,
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0, 0.0, 0, 10),
                        child: InkWell(
                          child: Padding(
                            padding: EdgeInsets.only(
                                top: 5,
                                right: 0,
                                left: 5,
                                bottom: _mSpiderAndSkillDataModel
                                    .result.skillChart.length -
                                    1 ==
                                    index
                                    ? 10
                                    : 0),
                            child:   LinearPercentIndicator(
                              width: MediaQuery
                                  .of(context)
                                  .size
                                  .width / 1.1,
                              animation: true,
                              backgroundColor: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                              lineHeight: 15.0,
                              animationDuration: 100,
                              percent: _mSpiderAndSkillDataModel
                                  .result.skillChart[index].value,
                              linearStrokeCap: LinearStrokeCap.butt,
                              progressColor: _mSpiderAndSkillDataModel
                                  .result.skillChart[index].color,
                            ),
                          ),
                        )),
                  ],
                ),
              );
            }),
          ));
    }

    void skillDetail() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>
            WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:   SafeArea(
                  child:   Scaffold(
                      backgroundColor: Colors.black38,
                      body:   Stack(
                        children: <Widget>[
                            Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:   Container(
                                  height: 220.0,
                                  color: Colors.transparent,
                                  child:   Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                              Container(
                                              height: 170.0,
                                              padding:   EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:   Center(
                                                child:   Column(
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        5.0,
                                                        0.0,
                                                        5.0,
                                                        Image.asset(
                                                          'assets/newDesignIcon/info.png',
                                                          height: 25.0,
                                                          width: 25.0,
                                                        )),
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        10.0,
                                                        TextViewWrap.textView(
                                                            "Skills Summary",
                                                            TextAlign.center,
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                            16.0,
                                                            FontWeight.bold)),
                                                      Container(
                                                        child: RichText(
                                                          maxLines: 5,
                                                          textAlign:
                                                          TextAlign.center,
                                                          text: TextSpan(
                                                            text:
                                                            "All our experiences build core skills - these summarize key personal capabilities and strengths.",
                                                            style:   TextStyle(
                                                                color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                          ),
                                                        ))
                                                  ],
                                                ),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                            Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:   Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                    Container(
                                      color: Colors.white,
                                      padding:   EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:   Row(
                                        children: <Widget>[
                                            Expanded(
                                            child:   InkWell(
                                              child:   Container(
                                                  child:   Text(
                                                    "Close",
                                                    textAlign: TextAlign.center,
                                                    style:   TextStyle(
                                                        color:   ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 20.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }


    Padding getUiButtonsIfStudentLoggedIn() {
      return PaddingWrap.paddingfromLTRB(
          13.0,
          10.0,
          13.0,
          10.0,
            Container(
              decoration:   BoxDecoration(
                  color: Colors.white,
                  border:   Border.all(
                      color:   ColorValues.BORDER_COLOR, width: 0.5)),
              child:   Row(
                children: <Widget>[
                    Expanded(
                    child:   Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                          InkWell(
                          child:   Column(
                            children: <Widget>[
                                Image.asset(
                                "assets/newDesignIcon/userprofile/right.png",
                                width: 18.0,
                                height: 18.0,
                              ),
                              PaddingWrap.paddingAll(
                                5.0,
                                TextViewWrap.textView(
                                    "Connected",
                                    TextAlign.center,
                                      ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    14.0,
                                    FontWeight.normal),
                              )
                            ],
                          ),
                          onTap: () {},
                        )

                      ],
                    ),
                    flex: 1,
                  ),
                    Expanded(
                    child:   InkWell(
                      child:   Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                            Image.asset(
                            "assets/newDesignIcon/userprofile/subscribe_blue.png",
                            width: 18.0,
                            height: 18.0,
                          ),
                          PaddingWrap.paddingAll(
                            5.0,
                            TextViewWrap.textView(
                                "Following",
                                TextAlign.center,

                                    ColorValues.BLUE_COLOR_BOTTOMBAR,
                                14.0,
                                FontWeight.normal),
                          )
                        ],
                      ),
                      onTap: () {},
                    ),
                    flex: 1,
                  )
                  ,
                    Expanded(
                    child:   InkWell(
                      child:   Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                            Image.asset(
                            "assets/newDesignIcon/userprofile/msg.png",
                            width: 22.0,
                            height: 22.0,
                          ),
                          PaddingWrap.paddingAll(
                            3.0,
                            TextViewWrap.textView(
                                "Chat",
                                TextAlign.center,
                                  ColorValues.GREY_TEXT_COLOR,
                                14.0,
                                FontWeight.normal),
                          )
                        ],
                      ),
                      onTap: () {

                      },
                    ),
                    flex: 1,
                  )
                  ,
                ],
              )));
    }

    Widget headerUiDesign() {
      return   Container(
        key: dataKey0,
        height: widget.profileType == "Connected"
            ? 550.0
            : _mSpiderAndSkillDataModel == null ||
            _mSpiderAndSkillDataModel.result == null
            ? 840.0
            : _mSpiderAndSkillDataModel.result.spiderChart.length > 0 ||
            _mSpiderAndSkillDataModel.result.skillChart.length > 0
            ? 940.0
            : 840,
        color:   ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
        child:   Stack(
          children: <Widget>[
              Positioned(
                top: 0.0,
                bottom: widget.profileType == "Connected"
                    ? 70.0
                    : _mSpiderAndSkillDataModel == null ||
                    _mSpiderAndSkillDataModel.result == null
                    ? 140.0
                    : _mSpiderAndSkillDataModel.result.spiderChart.length > 0 ||
                    _mSpiderAndSkillDataModel.result.skillChart.length >
                        0
                    ? 180.0
                    : 140.0,
                left: 0.0,
                right: 0.0,
                child: _mPublicProfileDataModel.result != null &&
                    _mPublicProfileDataModel.result.coverImage != "null"
                    ?   Stack(
                  children: <Widget>[
                      Positioned(
                      child:   CachedNetworkImage(
                        imageUrl: Constant.IMAGE_PATH_SMALL +
                            ParseJson.getMediumImage(
                                _mPublicProfileDataModel
                                    .result.coverImage),
                        fit: BoxFit.cover,
                        placeholder: (context, url) =>
                            _loader(context, ""),
                        errorWidget: (context, url, error) => _error(""),
                      ),
                      top: 0.0,
                      bottom: 0.0,
                      left: 0.0,
                      right: 0.0,
                    ),
                      Positioned(
                      child:   Container(
                        width: double.infinity,
                        child:   Image.asset(
                          "assets/newDesignIcon/navigation/layer_cover.png",
                          fit: BoxFit.fill,
                        ),
                      ),
                      top: 0.0,
                      bottom: 0.0,
                      left: 0.0,
                      right: 0.0,
                    ),
                  ],
                )
                    :   Stack(
                  children: <Widget>[
                      Positioned(
                      child:   Container(color:   Color(0xff5E5E5E)),
                      top: 0.0,
                      bottom: 0.0,
                      left: 0.0,
                      right: 0.0,
                    ),
                  ],
                )),
              Positioned(
                top: 150.0,
                bottom: 0.0,
                left: 0.0,
                right: 0.0,
                child:   Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        10.0,
                        20.0,
                        0.0,
                        0.0,
                          Container(
                            child:   Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                  Expanded(
                                  child: PaddingWrap.paddingAll(
                                      10.0,
                                        Container(
                                        width: 111.0,
                                        height: 111.0,
                                        child:   Stack(
                                          children: <Widget>[
                                              Center(
                                                child:   Container(
                                                  child:   ClipOval(
                                                    child: _mPublicProfileDataModel
                                                        .result !=
                                                        null
                                                        ?   CachedNetworkImage(
                                                      imageUrl:
                                                      /*profileInfoModal != null
                        ?*/
                                                      Constant
                                                          .IMAGE_PATH_SMALL +
                                                          ParseJson
                                                              .getMediumImage(
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .profilePicture)
                                                      /*: ""*/,
                                                      fit: BoxFit.cover,
                                                      placeholder: (context,
                                                          url) =>
                                                          _loader(context,
                                                              "assets/profile/user_on_user.png"),
                                                      errorWidget: (context,
                                                          url,
                                                          error) =>
                                                          _error(
                                                              "assets/profile/user_on_user.png"),
                                                    )
                                                        :   Image.asset(
                                                      "assets/profile/user_on_user.png",
                                                    ),
                                                  ),
                                                  width: 111.0,
                                                  height: 111.0,
                                                  padding:   EdgeInsets
                                                      .fromLTRB(
                                                      0.0, 0.0, 0.0, 0.0),
                                                )),
                                          ],
                                        ),
                                      )),
                                  flex: 0,
                                ),
                                  Expanded(
                                  child: PaddingWrap.paddingfromLTRB(
                                      5.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                        Container(
                                          child:   Column(
                                            mainAxisAlignment: MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            children: <Widget>[
                                              _mPublicProfileDataModel == null
                                                  ?   Container(
                                                height: 0.0,
                                              )
                                                  : Container(
                                                child: Padding(
                                                    padding: const EdgeInsets
                                                        .only(
                                                        top: 2.0, right: 0.0),
                                                    child: RichText(
                                                        maxLines: 3,
                                                        textAlign:
                                                        TextAlign.start,
                                                        text: TextSpan(
                                                            text: _mPublicProfileDataModel
                                                                .result ==
                                                                null
                                                                ? ""
                                                                : _mPublicProfileDataModel
                                                                .result
                                                                .lastName ==
                                                                null ||
                                                                _mPublicProfileDataModel
                                                                    .result
                                                                    .lastName ==
                                                                    "" ||
                                                                _mPublicProfileDataModel
                                                                    .result
                                                                    .lastName ==
                                                                    "null"
                                                                ? _mPublicProfileDataModel
                                                                .result
                                                                .firstName ==
                                                                null
                                                                ? ""
                                                                : _mPublicProfileDataModel
                                                                .result
                                                                .firstName
                                                                : _mPublicProfileDataModel
                                                                .result
                                                                .firstName +
                                                                " " +
                                                                _mPublicProfileDataModel
                                                                    .result
                                                                    .lastName,
                                                            style:   TextStyle(
                                                              color: Colors
                                                                  .white,
                                                              fontSize: _mPublicProfileDataModel
                                                                  .result !=
                                                                  null
                                                                  ? getLenthOfName() >
                                                                  24
                                                                  ? 22.0
                                                                  : 24.0
                                                                  : 24.0,
                                                              fontWeight:
                                                              FontWeight
                                                                  .normal,
                                                            ),
                                                            children: [
                                                              WidgetSpan(
                                                                child: _mPublicProfileDataModel
                                                                    .result
                                                                    .badge !=
                                                                    '' &&
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .badge !=
                                                                        'null'
                                                                    ? Padding(
                                                                  padding: const EdgeInsets
                                                                      .only(
                                                                      left:
                                                                      5.0,
                                                                      bottom:
                                                                      5.0,
                                                                      right:
                                                                      10),
                                                                  child: Util
                                                                      .getStudentBadgeProfileForDashBoard(
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .badge,
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .badgeImage),
                                                                )
                                                                    :   Container(
                                                                    height:
                                                                    0.0,
                                                                    width:
                                                                    0.0),
                                                              )
                                                            ]))),
                                              ),
                                              _mPublicProfileDataModel.result ==
                                                  null ||
                                                  _mPublicProfileDataModel
                                                      .result.tagline ==
                                                      "" ||
                                                  _mPublicProfileDataModel
                                                      .result.tagline ==
                                                      "null"
                                                  ?   Container(
                                                height: 0.0,
                                              )
                                                  : PaddingWrap.paddingfromLTRB(
                                                  5.0,
                                                  0.0,
                                                  10.0,
                                                  15.0,
                                                    Text(
                                                    _mPublicProfileDataModel
                                                        .result ==
                                                        null ||
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .tagline ==
                                                            "" ||
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .tagline ==
                                                            "null"
                                                        ? ""
                                                        : _mPublicProfileDataModel
                                                        .result.tagline,
                                                    textAlign: TextAlign.start,
                                                    maxLines: 3,
                                                    overflow: TextOverflow
                                                        .ellipsis,
                                                    style:   TextStyle(
                                                      /*  shadows: <Shadow>[
                                                      Shadow(
                                                        offset: Offset(0.0, 2.0),
                                                        blurRadius: 2.0,
                                                        color: Colors.black.withOpacity(.2),
                                                      ),
                                                    ],*/
                                                        color:
                                                          ColorValues.SEARCH_CATEGORY_BOX_BG,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                        fontSize: 18.0),
                                                  ))
                                            ],
                                          ))),
                                  flex: 1,
                                )
                              ],
                            ))),
                      Container(
                      padding:   EdgeInsets.fromLTRB(40.0, 20.0, 40.0, 20.0),
                      child:   Row(
                        children: <Widget>[
                            Expanded(
                            child:   Container(
                                decoration:  BoxDecoration(
                                  border:  Border(
                                    right:  BorderSide(
                                        width: 0.8,
                                        color: ColorValues.HEADING_COLOR),
                                  ),
                                ),
                                child: PaddingWrap.paddingfromLTRB(
                                  5.0,
                                  0.0,
                                  5.0,
                                  0.0,
                                  AnimatedOpacity(
                                    // If the widget is visible, animate to 0.0 (invisible).
                                    // If the widget is hidden, animate to 1.0 (fully visible).
                                      opacity: 1.0,
                                      duration: Duration(milliseconds: 500),
                                      child:   Column(
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              TextViewWrap.textView(
                                                  _mAcoomplismentDataModel ==
                                                      null ||
                                                      _mPublicProfileDataModel ==
                                                          null ||
                                                      _mPublicProfileDataModel
                                                          .result ==
                                                          null ||
                                                      !_mPublicProfileDataModel
                                                          .result
                                                          .isAccomplishment
                                                      ? _mAcoomplismentDataModel
                                                      .toJsonLength()
                                                      .length
                                                      .toString()
                                                      : _mAcoomplismentDataModel
                                                      .toJson()
                                                      .length
                                                      .toString(),
                                                  TextAlign.center,
                                                    ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  28.0,
                                                  FontWeight.normal)),
                                            InkWell(
                                            child: TextViewWrap.textView(
                                                "Experiences",
                                                TextAlign.center,
                                                  ColorValues.HEADING_COLOR,
                                                14.0,
                                                FontWeight.bold),
                                            onTap: () {},
                                          ),
                                        ],
                                      )),
                                )),
                            flex: 1,
                          ),
                            Expanded(
                            child:   Container(
                                child: PaddingWrap.paddingfromLTRB(
                                    5.0,
                                    0.0,
                                    5.0,
                                    0.0,
                                      Column(
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            0.0,
                                            0.0,
                                            TextViewWrap.textView(
                                                _mAcoomplismentDataModel ==
                                                    null ||
                                                    _mPublicProfileDataModel ==
                                                        null ||
                                                    _mPublicProfileDataModel
                                                        .result ==
                                                        null ||
                                                    !_mPublicProfileDataModel
                                                        .result
                                                        .isRecommendation
                                                    ? _mPublicProfileDataModel
                                                    .result
                                                    .toJsonRecLength()
                                                    .length
                                                    .toString()
                                                    : _mPublicProfileDataModel
                                                    .result
                                                    .toJsonRec()
                                                    .length
                                                    .toString(),
                                                TextAlign.center,
                                                  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                28.0,
                                                FontWeight.normal)),
                                          InkWell(
                                          child: TextViewWrap.textView(
                                              "Recommendations",
                                              TextAlign.center,
                                                ColorValues.HEADING_COLOR,
                                              14.0,
                                              FontWeight.bold),
                                          onTap: () {},
                                        ),
                                      ],
                                    ))),
                            flex: 1,
                          )
                        ],
                      ),
                    ),
                  ],
                )),


              Positioned(
              top: 410,
              bottom: 0.0,
              left: 0.0,
              right: 0.0,
              child: widget.profileType == "Connected"
                  ? getUiButtonsIfStudentLoggedIn()
                  : (_mSpiderAndSkillDataModel != null &&
                  _mSpiderAndSkillDataModel.result != null) &&
                  (_mSpiderAndSkillDataModel.result.spiderChart.length >
                      0 ||
                      _mSpiderAndSkillDataModel.result.skillChart.length >
                          0)
                  ?   SizedBox(
                  child: PageIndicatorContainer(
                    pageView:   PageView.builder(
                      itemCount: 2,
                      controller: pageController,
                      itemBuilder: (context, index2) {
                        return index2 == 0
                            ? PaddingWrap.paddingfromLTRB(
                          13.0,
                          0.0,
                          13.0,
                          30.0,
                            Container(
                              child:   Container(
                                  decoration:   BoxDecoration(
                                      color: Colors.white,
                                      border:   Border.all(
                                          color:   ColorValues.BORDER_COLOR,
                                          width: 0.5)),
                                  child:   Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: <Widget>[
                                        Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              17.0,
                                              10.0,
                                              17.0,
                                              0.0,
                                              TextViewWrap
                                                  .textViewSingleLine(
                                                  "Story",
                                                  TextAlign.start,
                                                  ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                  20.0,
                                                  FontWeight
                                                      .normal)),
                                          PaddingWrap.paddingfromLTRB(
                                              19.0,
                                              5.0,
                                              17.0,
                                              0.0,
                                                Image.asset(
                                                "assets/newDesignIcon/userprofile/line.png",
                                                height: 3.0,
                                                width: 40.0,
                                              )),
                                        ],
                                      ),

                                          _mSpiderAndSkillDataModel
                                              .result
                                              .spiderChart
                                              .length >
                                              0
                                          ?   Container(
                                          padding:
                                            EdgeInsets.all(
                                              0.0),
                                          width: 450,
                                          height: 450,
                                          child: Container(
                                            width: 450,
                                            height: 450,
                                            //Radar Chart
                                            child: RadarChart(
                                              values:
                                              spiderChartList,
                                              labels:
                                              spiderChartName,
                                              maxWidth: 450,
                                              maxLinesForLabels: 5,
                                              labelWidth: 70,
                                              strokeColor:   ColorValues.GREY_TEXT_COLOR,
                                              maxValue: 9,
                                              animate: false,
                                              textScaleFactor: 0.03,
                                              size: Size.infinite,
                                              fillColor:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                              chartRadiusFactor:
                                              0.6,
                                              labelColor:
                                              Colors.black,
                                            ),
                                          ))
                                          :   Container(
                                          padding:
                                            EdgeInsets.all(
                                              0.0),
                                          height: 450.0,
                                          width: double.infinity,
                                          child: Container(
                                              child: Stack(
                                                children: <Widget>[
                                                    Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children: <Widget>[
                                                        Image.asset(
                                                          "assets/radar_proceed.png",
                                                          width: double
                                                              .infinity,
                                                          height: 221),
                                                    ],
                                                  ),
                                                ],
                                              ))),
                                    ],
                                  ))),
                        )
                            : PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            30.0,
                              Container(
                                child:   Container(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 0.0, 0.0, 10.0),
                                    decoration:   BoxDecoration(
                                        color: Colors.white,
                                        border:   Border.all(
                                            color:   ColorValues.BORDER_COLOR,
                                            width: 0.5)),
                                    child:   Column(
                                      // padding: const EdgeInsets.all(0.0),
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: <Widget>[
                                          Row(
                                          children: <Widget>[
                                              Expanded(
                                              child:   Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .start,
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .start,
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      17.0,
                                                      10.0,
                                                      17.0,
                                                      0.0,
                                                      TextViewWrap
                                                          .textViewSingleLine(
                                                          "My Story",
                                                          TextAlign
                                                              .start,
                                                          ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                          20.0,
                                                          FontWeight
                                                              .normal)),
                                                  PaddingWrap
                                                      .paddingfromLTRB(
                                                      19.0,
                                                      5.0,
                                                      17.0,
                                                      12.0,
                                                        Image.asset(
                                                        "assets/newDesignIcon/userprofile/line.png",
                                                        height: 3.0,
                                                        width: 40.0,
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                              Expanded(
                                              child:   InkWell(
                                                child: PaddingWrap
                                                    .paddingfromLTRB(
                                                    17.0,
                                                    0.0,
                                                    17.0,
                                                    0.0,
                                                    Image.asset(
                                                      'assets/newDesignIcon/info.png',
                                                      height: 25.0,
                                                      width: 25.0,
                                                    )),
                                                onTap: () {
                                                  skillDetail();
                                                },
                                              ),
                                              flex: 0,
                                            )
                                          ],
                                        ),
                                        _mSpiderAndSkillDataModel !=
                                            null &&
                                            _mSpiderAndSkillDataModel
                                                .result !=
                                                null
                                            ? barList()
                                            :   Container(
                                          height: 0.0,
                                        )
                                      ],
                                    ))));
                      },
                      onPageChanged: (index) {},
                    ),
                    align: IndicatorAlign.bottom,
                    length: 2,
                    indicatorSpace: 10.0,
                    indicatorColor:   ColorValues.GREY__COLOR_DIVIDER,
                    indicatorSelectorColor:
                      ColorValues.BLUE_COLOR_BOTTOMBAR,
                    shape: IndicatorShape.circle(size: 10.0),
                  ))
                  : PaddingWrap.paddingfromLTRB(
                  13.0,
                  0.0,
                  13.0,
                  0.0,
                    Container(
                      decoration:   BoxDecoration(
                          color: Colors.white,
                          border:   Border.all(
                              color:   ColorValues.BORDER_COLOR,
                              width: 0.5)),
                      child:   Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                            Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  10.0,
                                  17.0,
                                  0.0,
                                  TextViewWrap.textViewSingleLine(
                                      "Story",
                                      TextAlign.start,
                                        ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                      20.0,
                                      FontWeight.normal)),
                              PaddingWrap.paddingfromLTRB(
                                  19.0,
                                  0.0,
                                  17.0,
                                  12.0,
                                    Image.asset(
                                    "assets/newDesignIcon/userprofile/line.png",
                                    height: 3.0,
                                    width: 40.0,
                                  )),
                            ],
                          ),
                            Container(
                              padding:   EdgeInsets.all(0.0),
                              height: 360.0,
                              width: double.infinity,
                              child: Container(
                                  child: Stack(
                                    children: <Widget>[
                                        Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: <Widget>[
                                            Image.asset(
                                              "assets/radar.png",
                                              width: double.infinity,
                                              height: 221),
                                        ],
                                      ),
                                    ],
                                  )))

                        ],
                      ))),
            )
          ],
        ),
      );
    }


    introductionViewUI() {
      return _mPublicProfileDataModel.result == null ||
          _mPublicProfileDataModel.result.introVideo ==
              null ||
          _mPublicProfileDataModel.result
              .introVideo.videoUrl ==
              null ||
          _mPublicProfileDataModel.result
              .introVideo.videoUrl ==
              "null" ||
          _mPublicProfileDataModel.result
              .introVideo.videoUrl ==
              ""
          ?   Container(height: 0.0) : PaddingWrap.paddingfromLTRB(
          0.0,
          0.0,
          0.0,
          0.0,
          PaddingWrap.paddingfromLTRB(
              0.0,
              0.0,
              0.0,
              0.0,
              isVideoPlay
                  ? PaddingWrap.paddingfromLTRB(
                  13.0,
                  13.0,
                  13.0,
                  0.0,   Container(
                  height: 215.50,
                  color: Colors.black,
                  child:   VideoPlayPause(
                    _mPublicProfileDataModel.result
                        .introVideo.videoUrl,
                    "",
                    true,
                    pageName: "profile",
                  )

              ))
                  : PaddingWrap.paddingfromLTRB(
                  13.0,
                  13.0,
                  13.0,
                  0.0,
                    Container(
                      height: 200.0,
                      color: Colors.black,
                      child:   Stack(
                        children: [
                          _mPublicProfileDataModel.result
                              .introVideo
                              .thumbnailUrl
                              .toLowerCase()
                              .contains(
                              "http") ||
                              _mPublicProfileDataModel.result
                                  .introVideo
                                  .thumbnailUrl
                                  .toLowerCase()
                                  .contains(
                                  "www.")
                              ?   CachedNetworkImage(
                            height: 200.0,
                            width:
                            double.infinity,
                            imageUrl: _mPublicProfileDataModel.result
                                .introVideo
                                .thumbnailUrl
                            ,
                            fit: BoxFit.contain,
                            placeholder:
                                (context,
                                url) =>
                                _loader(
                                    context,
                                    ""),
                            errorWidget:
                                (context, url,
                                error) =>
                                _error(""),
                          ) :
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                            child:   CachedNetworkImage(
                              height: 200.0,
                              width:
                              double.infinity,
                              imageUrl:_mPublicProfileDataModel.result
                                  .introVideo
                                  .thumbnailUrl==null|| _mPublicProfileDataModel.result
                                  .introVideo
                                  .thumbnailUrl=="null"|| _mPublicProfileDataModel.result
                                  .introVideo
                                  .thumbnailUrl==""?Constant
                                  .IMAGE_PATH + _mPublicProfileDataModel.result.profilePicture
                                  :Constant
                                  .IMAGE_PATH + _mPublicProfileDataModel.result
                                  .introVideo
                                  .thumbnailUrl,
                              fit: BoxFit.contain,
                              placeholder:
                                  (context,
                                  url) =>
                                  _loader(
                                      context,
                                      ""),
                              errorWidget:
                                  (context, url,
                                  error) =>
                                  _error(""),
                            ),
                          ),
                            Positioned(
                              bottom: 0.0,
                              right: 0.0,
                              top: 0.0,
                              left: 0.0,
                              child:   Image.asset(
                                "assets/newIcon/dimmer.png",

                              )),
                            Positioned(
                              bottom: 48.0,
                              left: 13.0,
                              child: InkWell(
                                onTap: () {
                                  if (_mPublicProfileDataModel.result
                                      .introVideo
                                      .videoUrl
                                      .toLowerCase()
                                      .contains(
                                      "http") ||
                                      _mPublicProfileDataModel.result
                                          .introVideo
                                          .videoUrl
                                          .toLowerCase()
                                          .contains(
                                          "www.")) {
                                    if (_mPublicProfileDataModel.result
                                        .introVideo
                                        .videoUrl
                                        .toLowerCase()
                                        .contains(
                                        "http")) {
                                      launch(_mPublicProfileDataModel.result
                                          .introVideo
                                          .videoUrl);
                                    } else {
                                      String
                                      url =
                                          "http://" +
                                              _mPublicProfileDataModel.result
                                                  .introVideo.videoUrl;
                                      launch(
                                          url);
                                    }
                                  } else {
                                    setState(
                                            () {
                                          isVideoPlay =
                                          true;
                                        });
                                  }
                                },
                                child:   Image
                                    .asset(
                                  "assets/newIcon/pauseIcon.png",
                                  height: 70.0,
                                  width: 70.0,
                                ),
                              )),
                            Positioned(
                              bottom: 13.0,
                              left: 13.0,
                              child:   Text(
                                "Introduction",
                                style:   TextStyle(
                                    color: Colors
                                        .white,
                                    fontSize:
                                    24.0,
                                    fontFamily:
                                    Constant.TYPE_CUSTOMBOLD),
                              )),

                        ],
                      )))));
    }

    Padding summaryView() {
      return PaddingWrap.paddingfromLTRB(
          13.0,
          13.0,
          13.0,
          0.0,
            Container(
              child:   Container(
                  decoration:   BoxDecoration(
                      color: Colors.white,
                      border:   Border.all(
                          color:   ColorValues.BORDER_COLOR,
                          width: 0.5)),
                  child:   Container(
                      color: Colors.white,
                      child:   Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                            Row(
                            children: <Widget>[
                                Expanded(
                                child:   Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        17.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                        TextViewWrap.textViewSingleLine(
                                            "Summary",
                                            TextAlign.start,
                                              ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                            20.0,
                                            FontWeight.normal)),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        5.0,
                                        0.0,
                                        12.0,
                                          Image.asset(
                                          "assets/newDesignIcon/userprofile/line.png",
                                          height: 3.0,
                                          width: 40.0,
                                        )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          PaddingWrap.paddingfromLTRB(
                              17.0,
                              0.0,
                              17.0,
                              0.0,
                                Text(
                                  _mPublicProfileDataModel.result == null ||
                                      _mPublicProfileDataModel
                                          .result.summary ==
                                          null ||
                                      _mPublicProfileDataModel
                                          .result.summary ==
                                          "null"
                                      ? "No Information Available"
                                      : _mPublicProfileDataModel.result.summary,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: isShowSummary ? 100 : 3,
                                  style:   TextStyle(
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 14.0))),
                          _mPublicProfileDataModel.result.summary.length >
                              130 ||
                              _mPublicProfileDataModel.result.summary
                                  .split('\n')
                                  .length >
                                  2
                              ? Align(
                              alignment: Alignment.bottomLeft,
                              child:   InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    17.0,
                                    2.0,
                                    10.0,
                                    10.0,
                                      Text(
                                      isShowSummary ? "Less" : "More",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.end,
                                      style:   TextStyle(
                                          color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          fontSize: 14.0,
                                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                    )),
                                onTap: () {
                                  if (isShowSummary) {
                                    setState(() {
                                      isShowSummary = false;
                                    });
                                  } else {
                                    setState(() {
                                      isShowSummary = true;
                                    });
                                  }
                                },
                              ))
                              :   Container(
                            height: 12.0,
                          )
                        ],
                      )))));
    }

    onTapShare() async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
            ShareProfileView(widget.link,
              _mPublicProfileDataModel.result.firstName, "public",
              widget.isParentCalling)));
      if (result == "push") {
        Navigator.pop(context, "push");
      }
    }

    final bottomBar2 = BottomAppBar(
      elevation: 15.0,
      child:   Container(
        decoration:   BoxDecoration(
            color: Colors.white,
            border:   Border(
              top: BorderSide(
                  color:   ColorValues.BORDER_COLOR, width: 0.5),
            )),
        height: 60.0,
        child:   Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
              InkWell(
                child:   Container(
                  width: 150,
                  height: 35,
                  color: Colors.white,
                  child: Center(
                    child:   Text(
                      "GO TO PROFILE",
                      textAlign: TextAlign.center,
                      style:   TextStyle(
                          color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                          fontSize: 14,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                  ),
                ),
                onTap: () {
                  Navigator.pop(context, "push");
                })
          ],
        ),
      ),
    );
    Future updatePublicProfileStatus(bool isUrl) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "userId": int.parse(userIdPref),
            "roleId": int.parse(roleId),
            "profileType": "Public",
            "isActive": isUrl
          };

          print("BADGE++++" + map.toString());
          Response response = await   ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_UPDATE_PUBLIC_PROFILE_STATUS, map);

          print("BADGE++++:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                syncDoneController.add("sucess");
                onTapShare();
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        print("Error+++" + e.toString());
        e.toString();
      }
    }

    final bottomBar = BottomAppBar(
      elevation: 15.0,
      child:   Container(
        decoration:   BoxDecoration(
            color: Colors.white,
            border:   Border(
              top: BorderSide(
                  color:   ColorValues.BORDER_COLOR, width: 0.5),
            )),
        height: 60.0,
        child:   Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
              InkWell(
                child:   Container(
                  width: 150,
                  height: 35,
                  color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                  child: Center(
                    child:   Text(
                      "PUBLISH",
                      textAlign: TextAlign.center,
                      style:   TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                  ),
                ),
                onTap: () {
                  updatePublicProfileStatus(true);
                })
          ],
        ),
      ),
    );

    return   WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:   GestureDetector(
            onTap: () {
              // FocusScope.of(context).requestFocus(new FocusNode());
            },
            child:   Scaffold(
                appBar:   AppBar(
                  brightness: Brightness.light,
                  automaticallyImplyLeading: false,
                  titleSpacing: 0.0,
                  elevation: 0.0,
                  title:   Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                        Expanded(
                        child:   InkWell(
                          child: CustomViews.getBackButton(),
                          onTap: () {
                            Navigator.pop(context);
                          },
                        ),
                        flex: 0,
                      ),
                        Expanded(
                        child:   Text(
                          "Preview",
                          textAlign: TextAlign.center,
                          style:   TextStyle(
                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 18.0,
                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                        ),
                        flex: 1,
                      )
                    ],
                  ),
                  actions: <Widget>[
                    widget.profileType == "Connected" ?

                      Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                          InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              17.0,
                              0.0,
                                Text(
                                "Edit",
                                textAlign: TextAlign.center,
                                style:   TextStyle(
                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontSize: 16.0,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              )),
                          onTap: () {
                            Navigator.pop(context);
                            //  shareSelectionDialog();
                          },
                        ),

                       /*   InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              17.0,
                              0.0,
                                Image.asset(
                                "assets/profile/post/user_more1.png",
                                height: 25.0,
                                width: 25.0,color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                              )),
                          onTap: () {

                            //  shareSelectionDialog();
                          },
                        )*/
                      ],
                    )

                        : widget.isParentCalling ||

                        widget.isFirstTimeCalling
                        ?     Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                          InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              17.0,
                              0.0,
                                Text(
                                "Edit",
                                textAlign: TextAlign.center,
                                style:   TextStyle(
                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontSize: 16.0,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              )),
                          onTap: () {
                            Navigator.pop(context);
                            //  shareSelectionDialog();
                          },
                        ),


                      ],
                    )
                        :      Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                          InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              17.0,
                              0.0,
                                Text(
                                "Edit",
                                textAlign: TextAlign.center,
                                style:   TextStyle(
                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontSize: 16.0,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                              )),
                          onTap: () {
                            Navigator.pop(context);
                            //  shareSelectionDialog();
                          },
                        ),

                          InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              17.0,
                              0.0,
                                Image.asset(
                                "assets/newDesignIcon/userprofile/share_new.png",
                                height: 20.0,
                                width: 20.0,color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                              )),
                          onTap: () {
                            onTapShare();
                            //  shareSelectionDialog();
                          },
                        )
                      ],
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                bottomNavigationBar: widget.profileType == "Connected"
                    ? bottomBar2
                    : widget.isFirstTimeCalling ?
                bottomBar :   Container(height: 0.0,),
                body:   Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    CustomViews.getSepratorLine(),
                      Expanded(
                      child:   Container(
                        color:   Color(0xffF4F2F2),
                        child:
                        _mPublicProfileDataModel == null ||
                            _mPublicProfileDataModel.result == null
                            ?   Container(
                          height: 0.0,
                        )
                            :   ListView(
                          controller: _scrollController,
                          children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0, 0, 20),
                              child:   Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: [
                                  /*  PaddingWrap.paddingfromLTRB(
                                                13.0,
                                                13.0,
                                                0.0,
                                                5.0,
                                                TextViewWrap.textViewMultiLine(
                                                    "Custom URL",
                                                    TextAlign.start,
                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                    14.0,
                                                    FontWeight.normal,
                                                    1)),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      13.0, 0, 13, 13),
                                              child:   Container(
                                                decoration:   BoxDecoration(
                                                    color: Colors.white,
                                                    border:   Border.all(
                                                        color:   ColorValues.BORDER_COLOR,
                                                        width: 0.5)),
                                                child:   Row(
                                                  children: [
                                                      Expanded(
                                                      child: PaddingWrap.paddingfromLTRB(
                                                          10.0,
                                                          10.0,
                                                          0.0,
                                                          10.0,
                                                          TextViewWrap
                                                              .textViewMultiLine(
                                                                  widget.link,
                                                                  TextAlign
                                                                      .start,
                                                                    Color(
                                                                      0XFF404040),
                                                                  14.0,
                                                                  FontWeight
                                                                      .bold,
                                                                  3)),
                                                      flex: 1,
                                                    ),
                                                      Expanded(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              0.0,
                                                              17.0,
                                                              0.0,
                                                                InkWell(
                                                                onTap: () {
                                                                  Util.copyToClipboardText(
                                                                      widget
                                                                          .link,
                                                                      context);
                                                                },
                                                                child:   Image
                                                                    .asset(
                                                                  "assets/portfolio/copy.png",
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ),
                                                              )),
                                                      flex: 0,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),*/

                                  widget.profileType == "Connected"
                                      ?   Container(
                                    color: Colors.black,
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(0,10,0,10) ,
                                      child: Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .start,
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .center,
                                        children: [
                                            Expanded(
                                            child: PaddingWrap
                                                .paddingfromLTRB(
                                                13.0,
                                                0.0,
                                                10.0,
                                                0.0,
                                                  Image
                                                    .asset(
                                                  "assets/newIcon/infowhite.png",
                                                  height:
                                                  20.0,
                                                  width: 20.0,
                                                )),
                                            flex: 0,
                                          ),
                                            Expanded(
                                            child: Padding(
                                                padding:
                                                const EdgeInsets
                                                    .fromLTRB(
                                                    0.0,
                                                    0,
                                                    13,
                                                    0),
                                                child: Text(
                                                    _mAcoomplismentDataModel ==
                                                        null ||
                                                        _mPublicProfileDataModel ==
                                                            null ||
                                                        _mPublicProfileDataModel
                                                            .result ==
                                                            null ||
                                                        !_mPublicProfileDataModel
                                                            .result
                                                            .isAccomplishment
                                                        ? MessageConstant.MSG_FOR_CONNECTED_LESS_THEN_3_ACC
                                                        : _mAcoomplismentDataModel
                                                        .toJson()
                                                        .length<3?MessageConstant.MSG_FOR_CONNECTED_LESS_THEN_3_ACC
                                                        :MessageConstant.MSG_FOR_CONNECTED
                                                            ,
                                                    style: TextStyle(
                                                        fontSize:
                                                        14,
                                                        color: Colors
                                                            .white,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR))),
                                            flex: 1,
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                      :   Container(
                                    height: 0.0,
                                  ),
                                  headerUiDesign(),

                                  widget.profileType == "Connected"
                                      ? (_mSpiderAndSkillDataModel != null &&
                                      _mSpiderAndSkillDataModel.result !=
                                          null) &&
                                      (_mSpiderAndSkillDataModel.result
                                          .spiderChart.length >
                                          0 ||
                                          _mSpiderAndSkillDataModel.result
                                              .skillChart.length >
                                              0)
                                      ?   Container(
                                      padding:
                                        EdgeInsets
                                          .all(0.0),
                                      width: 540,
                                      height: 530,
                                      child:   SizedBox(
                                          child: PageIndicatorContainer(
                                            pageView:   PageView.builder(
                                              itemCount: 2,
                                              controller: pageController,
                                              itemBuilder: (context, index2) {
                                                return index2 == 0
                                                    ? PaddingWrap
                                                    .paddingfromLTRB(
                                                  13.0,
                                                  0.0,
                                                  13.0,
                                                  30.0,
                                                    Container(
                                                      child:   Container(
                                                          decoration:   BoxDecoration(
                                                              color: Colors
                                                                  .white,
                                                              border:   Border
                                                                  .all(
                                                                  color:   ColorValues.BORDER_COLOR,
                                                                  width: 0.5)),
                                                          child:   Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                            children: <Widget>[
                                                                Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                                children: <
                                                                    Widget>[
                                                                  PaddingWrap
                                                                      .paddingfromLTRB(
                                                                      17.0,
                                                                      10.0,
                                                                      17.0,
                                                                      0.0,
                                                                      TextViewWrap
                                                                          .textViewSingleLine(
                                                                          "Story",
                                                                          TextAlign
                                                                              .start,
                                                                          ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                          20.0,
                                                                          FontWeight
                                                                              .normal)),
                                                                  PaddingWrap
                                                                      .paddingfromLTRB(
                                                                      19.0,
                                                                      5.0,
                                                                      17.0,
                                                                      0.0,
                                                                        Image
                                                                          .asset(
                                                                        "assets/newDesignIcon/userprofile/line.png",
                                                                        height: 3.0,
                                                                        width: 40.0,
                                                                      )),
                                                                ],

                                                              ),

                                                                  _mSpiderAndSkillDataModel
                                                                      .result
                                                                      .spiderChart
                                                                      .length >
                                                                      0
                                                                  ?   Container(
                                                                  padding:
                                                                    EdgeInsets
                                                                      .all(
                                                                      0.0),
                                                                  width: 450,
                                                                  height: 450,
                                                                  child: Container(
                                                                    width: 450,
                                                                    height: 450,
                                                                    //Radar Chart
                                                                    child: RadarChart(
                                                                      values:
                                                                      spiderChartList,
                                                                      labels:
                                                                      spiderChartName,
                                                                      maxWidth: 450,
                                                                      maxLinesForLabels: 5,
                                                                      labelWidth: 70,
                                                                      strokeColor:    ColorValues.GREY_TEXT_COLOR,
                                                                      maxValue: 9,
                                                                      animate: false,
                                                                      textScaleFactor: 0.03,
                                                                      size: Size
                                                                          .infinite,
                                                                      fillColor:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                      chartRadiusFactor:
                                                                      0.6,
                                                                      labelColor:
                                                                      Colors
                                                                          .black,
                                                                    ),
                                                                  ))
                                                                  :   Container(
                                                                  padding:
                                                                    EdgeInsets
                                                                      .all(
                                                                      0.0),
                                                                  height: 450.0,
                                                                  width: double
                                                                      .infinity,
                                                                  child: Container(
                                                                      child: Stack(
                                                                        children: <
                                                                            Widget>[
                                                                            Column(
                                                                            crossAxisAlignment:
                                                                            CrossAxisAlignment
                                                                                .center,
                                                                            mainAxisAlignment:
                                                                            MainAxisAlignment
                                                                                .center,
                                                                            children: <
                                                                                Widget>[
                                                                                Image
                                                                                  .asset(
                                                                                  "assets/radar_proceed.png",
                                                                                  width: double
                                                                                      .infinity,
                                                                                  height: 221),
                                                                            ],
                                                                          ),
                                                                        ],
                                                                      ))),
                                                            ],
                                                          ))),
                                                )
                                                    : PaddingWrap
                                                    .paddingfromLTRB(
                                                    13.0,
                                                    0.0,
                                                    13.0,
                                                    30.0,
                                                      Container(
                                                        child:   Container(
                                                            padding: const EdgeInsets
                                                                .fromLTRB(
                                                                0.0, 0.0, 0.0,
                                                                10.0),
                                                            decoration:   BoxDecoration(
                                                                color: Colors
                                                                    .white,
                                                                border:   Border
                                                                    .all(
                                                                    color:   ColorValues.BORDER_COLOR,
                                                                    width: 0.5)),
                                                            child:   Column(
                                                              // padding: const EdgeInsets.all(0.0),
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              children: <
                                                                  Widget>[
                                                                  Row(
                                                                  children: <
                                                                      Widget>[
                                                                      Expanded(
                                                                      child:   Column(
                                                                        crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                        mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                        children: <
                                                                            Widget>[
                                                                          PaddingWrap
                                                                              .paddingfromLTRB(
                                                                              17.0,
                                                                              10.0,
                                                                              17.0,
                                                                              0.0,
                                                                              TextViewWrap
                                                                                  .textViewSingleLine(
                                                                                  "My Story",
                                                                                  TextAlign
                                                                                      .start,
                                                                                  ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                                  20.0,
                                                                                  FontWeight
                                                                                      .normal)),
                                                                          PaddingWrap
                                                                              .paddingfromLTRB(
                                                                              19.0,
                                                                              5.0,
                                                                              17.0,
                                                                              12.0,
                                                                                Image
                                                                                  .asset(
                                                                                "assets/newDesignIcon/userprofile/line.png",
                                                                                height: 3.0,
                                                                                width: 40.0,
                                                                              )),
                                                                        ],
                                                                      ),
                                                                      flex: 1,
                                                                    ),
                                                                      Expanded(
                                                                      child:   InkWell(
                                                                        child: PaddingWrap
                                                                            .paddingfromLTRB(
                                                                            17.0,
                                                                            0.0,
                                                                            17.0,
                                                                            0.0,
                                                                            Image
                                                                                .asset(
                                                                              'assets/newDesignIcon/info.png',
                                                                              height: 25.0,
                                                                              width: 25.0,
                                                                            )),
                                                                        onTap: () {
                                                                          skillDetail();
                                                                        },
                                                                      ),
                                                                      flex: 0,
                                                                    )
                                                                  ],
                                                                ),
                                                                _mSpiderAndSkillDataModel !=
                                                                    null &&
                                                                    _mSpiderAndSkillDataModel
                                                                        .result !=
                                                                        null
                                                                    ? barList()
                                                                    :   Container(
                                                                  height: 0.0,
                                                                )
                                                              ],
                                                            ))));
                                              },
                                              onPageChanged: (index) {},
                                            ),
                                            align: IndicatorAlign.bottom,
                                            length: 2,
                                            indicatorSpace: 10.0,
                                            indicatorColor:   Color(
                                                0xffDEDEDE),
                                            indicatorSelectorColor:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                            shape: IndicatorShape.circle(
                                                size: 10.0),
                                          )))
                                      : PaddingWrap
                                      .paddingfromLTRB(
                                      13.0,
                                      0.0,
                                      13.0,
                                      10.0,
                                        Container(
                                          decoration:   BoxDecoration(
                                              color: Colors
                                                  .white,
                                              border:   Border
                                                  .all(
                                                  color:   ColorValues.BORDER_COLOR,
                                                  width:
                                                  0.5)),
                                          child:
                                            Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .start,
                                            children: <
                                                Widget>[
                                                Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <
                                                    Widget>[
                                                  PaddingWrap
                                                      .paddingfromLTRB(
                                                      17.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      TextViewWrap
                                                          .textViewSingleLine(
                                                          "Story",
                                                          TextAlign.start,
                                                          ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                          20.0, FontWeight
                                                          .normal)),
                                                  PaddingWrap
                                                      .paddingfromLTRB(
                                                      19.0,
                                                      0.0,
                                                      0.0,
                                                      12.0,
                                                        Image.asset(
                                                        "assets/newDesignIcon/userprofile/line.png",
                                                        height: 3.0,
                                                        width: 40.0,
                                                      )),
                                                ],
                                              ),
                                                Container(
                                                  padding:   EdgeInsets
                                                      .all(0.0),
                                                  height: 360.0,
                                                  width: double.infinity,
                                                  child: Container(
                                                      child: Stack(
                                                        children: <
                                                            Widget>[
                                                            Column(
                                                            crossAxisAlignment: CrossAxisAlignment
                                                                .center,
                                                            mainAxisAlignment: MainAxisAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[
                                                                Image
                                                                  .asset(
                                                                  "assets/radar_proceed.png",
                                                                  width: double
                                                                      .infinity,
                                                                  height: 221),
                                                            ],
                                                          ),
                                                        ],
                                                      )))

                                            ],
                                          )))
                                      :   Container(height: 0.0,),

                                    Column(
                                    children: <Widget>[

                                      !_mPublicProfileDataModel
                                          .result.isIntroVideo
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          :
                                      introductionViewUI(),


                                      _mPublicProfileDataModel
                                          .result ==
                                          null ||
                                          _mPublicProfileDataModel
                                              .result
                                              .summary ==
                                              null ||
                                          _mPublicProfileDataModel
                                              .result.summary
                                              .trim() ==
                                              "" ||
                                          _mPublicProfileDataModel
                                              .result
                                              .summary ==
                                              "null"
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : !_mPublicProfileDataModel
                                          .result.isSummary
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : summaryView(),


                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges
                                          .length +
                                          _mPublicProfileDataModel
                                              .result
                                              .educations
                                              .schools
                                              .length ==
                                          0
                                          ?   Container()
                                          : !_mPublicProfileDataModel
                                          .result.isEducations
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .toJson()
                                          .length ==
                                          0
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          13.0,
                                          13.0,
                                          0.0,
                                            Container(
                                              child:   Container(
                                                  decoration:   BoxDecoration(
                                                      color: Colors.white,
                                                      border:   Border.all(
                                                          color:   ColorValues.BORDER_COLOR,
                                                          width: 0.5)),
                                                  child:   Container(
                                                      color: Colors.white,
                                                      child:   Column(
                                                        crossAxisAlignment: CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment: MainAxisAlignment
                                                            .start,
                                                        children: <Widget>[
                                                            Row(
                                                            children: <Widget>[
                                                                Expanded(
                                                                child:   Column(
                                                                  crossAxisAlignment: CrossAxisAlignment
                                                                      .start,
                                                                  mainAxisAlignment: MainAxisAlignment
                                                                      .start,
                                                                  children: <
                                                                      Widget>[
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        17.0,
                                                                        10.0,
                                                                        0.0,
                                                                        0.0,
                                                                        TextViewWrap
                                                                            .textViewSingleLine(
                                                                            "Education",
                                                                            TextAlign
                                                                                .start,
                                                                            ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                            20.0,
                                                                            FontWeight
                                                                                .normal)),
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        19.0,
                                                                        5.0,
                                                                        0.0,
                                                                        12.0,
                                                                          Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/userprofile/line.png",
                                                                          height: 3.0,
                                                                          width: 40.0,
                                                                        )),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),

                                                          _mPublicProfileDataModel
                                                              .result.educations
                                                              .colleges !=
                                                              null &&
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .educations
                                                                  .colleges
                                                                  .length > 0 &&
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .educations
                                                                  .toCollege()
                                                                  .length > 0
                                                              ? Column(
                                                            mainAxisAlignment: MainAxisAlignment
                                                                .start,
                                                            crossAxisAlignment: CrossAxisAlignment
                                                                .start,
                                                            children: <Widget>[
                                                                Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                      17.0, 0.0,
                                                                      13.0,
                                                                      10.0),
                                                                  child:   Text(
                                                                    "COLLEGE",
                                                                    textAlign: TextAlign
                                                                        .left,
                                                                    style: TextStyle(
                                                                        color: Color(
                                                                            0xff9a9c9c),
                                                                        fontFamily: Constant
                                                                            .customRegular,
                                                                        fontSize: 14.0),
                                                                  )),
                                                                Column(
                                                                  children:   List
                                                                      .generate(
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .educations
                                                                          .colleges
                                                                          .length, (
                                                                      int index) {
                                                                    return getCollegeEducationListItem(
                                                                        index);
                                                                  })),
                                                            ],
                                                          )
                                                              : Container(
                                                            height: 0.0,
                                                          ),

                                                          //School Data
                                                          _mPublicProfileDataModel
                                                              .result.educations
                                                              .schools !=
                                                              null &&
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .educations
                                                                  .schools
                                                                  .length > 0 &&
                                                              _mPublicProfileDataModel
                                                                  .result
                                                                  .educations
                                                                  .toSchool()
                                                                  .length > 0
                                                              ? Column(
                                                            mainAxisAlignment: MainAxisAlignment
                                                                .start,
                                                            crossAxisAlignment: CrossAxisAlignment
                                                                .start,
                                                            children: <Widget>[
                                                                Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                      17.0,
                                                                      10.0,
                                                                      13.0,
                                                                      10.0),
                                                                  child:   Text(
                                                                    "SCHOOL",
                                                                    textAlign: TextAlign
                                                                        .left,
                                                                    style: TextStyle(
                                                                        color: Color(
                                                                            0xff9a9c9c),
                                                                        fontFamily: Constant
                                                                            .customRegular,
                                                                        fontSize: 14.0),
                                                                  )),
                                                                Column(
                                                                  children:   List
                                                                      .generate(
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .educations
                                                                          .schools
                                                                          .length, (
                                                                      int index) {
                                                                    return getSchoolEducationListItem(
                                                                        index);
                                                                  })),
                                                            ],
                                                          )
                                                              : Container(
                                                            height: 0.0,
                                                          ),
                                                        ],
                                                      ))))),
                                      !_mPublicProfileDataModel
                                          .result.isTestScore
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : _mPublicProfileDataModel
                                          .result
                                          .toJsonTestScore()
                                          .length ==
                                          0
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          13.0,
                                          13.0,
                                          0.0,
                                            Container(
                                              child:   Container(
                                                  decoration:   BoxDecoration(
                                                      color: Colors.white,
                                                      border:   Border.all(
                                                          color:   ColorValues.BORDER_COLOR,
                                                          width: 0.5)),
                                                  child:   Container(
                                                      color: Colors.white,
                                                      child:   Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                        children: <
                                                            Widget>[
                                                            Column(
                                                            children: <Widget>[
                                                                Row(
                                                                children: <
                                                                    Widget>[
                                                                    Expanded(
                                                                    child:   Column(
                                                                      crossAxisAlignment: CrossAxisAlignment
                                                                          .start,
                                                                      mainAxisAlignment: MainAxisAlignment
                                                                          .start,
                                                                      children: <
                                                                          Widget>[
                                                                        PaddingWrap
                                                                            .paddingfromLTRB(
                                                                            17.0,
                                                                            10.0,
                                                                            0.0,
                                                                            0.0,
                                                                            TextViewWrap
                                                                                .textViewSingleLine(
                                                                                "Test Score",
                                                                                TextAlign
                                                                                    .start,
                                                                                ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                                20.0,
                                                                                FontWeight
                                                                                    .normal)),
                                                                        PaddingWrap
                                                                            .paddingfromLTRB(
                                                                            19.0,
                                                                            5.0,
                                                                            0.0,
                                                                            0.0,
                                                                              Image
                                                                                .asset(
                                                                              "assets/newDesignIcon/userprofile/line.png",
                                                                              height: 3.0,
                                                                              width: 40.0,
                                                                            )),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              Padding(
                                                                padding: const EdgeInsets
                                                                    .fromLTRB(
                                                                    0.0, 0, 0,
                                                                    8),
                                                                child:   Column(
                                                                    children:   List
                                                                        .generate(
                                                                        _mPublicProfileDataModel
                                                                            .result
                                                                            .testScores
                                                                            .length, (
                                                                        int index) {
                                                                      return getTestScoreListItem(
                                                                          index);
                                                                    })),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ))))),
                                      _mAcoomplismentDataModel == null
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : !_mPublicProfileDataModel
                                          .result
                                          .isAccomplishment
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          :   Column(
                                        children: <Widget>[
                                            Container(
                                              padding:
                                                EdgeInsets
                                                  .fromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0),
                                              child:
                                                Column(
                                                  crossAxisAlignment: CrossAxisAlignment
                                                      .start,
                                                  children:   List.generate(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData
                                                          .length,
                                                          (int index) {
                                                        return _mAcoomplismentDataModel
                                                            .accomplimentData[index]
                                                            .toJsonData()
                                                            .length == 0
                                                            ?   Container(
                                                          height: 0.0,
                                                        )
                                                            : PaddingWrap
                                                            .paddingfromLTRB(
                                                            13.0,
                                                            13.0,
                                                            13.0,
                                                            0.0,
                                                              Container(
                                                                decoration:   BoxDecoration(
                                                                    color: Colors
                                                                        .white,
                                                                    border:   Border
                                                                        .all(
                                                                        color:   ColorValues.BORDER_COLOR,
                                                                        width: 0.5)),
                                                                child: Padding(
                                                                  padding: const EdgeInsets
                                                                      .fromLTRB(
                                                                      0, 0, 0,
                                                                      8.0),
                                                                  child:   Column(
                                                                    crossAxisAlignment: CrossAxisAlignment
                                                                        .start,
                                                                    mainAxisAlignment: MainAxisAlignment
                                                                        .start,
                                                                    children: <
                                                                        Widget>[
                                                                      _mAcoomplismentDataModel
                                                                          .accomplimentData[index]
                                                                          .achievement
                                                                          .length ==
                                                                          0
                                                                          ?   Container(
                                                                        height: 0.0,
                                                                      )
                                                                          :   Column(
                                                                          children: <
                                                                              Widget>[
                                                                              Row(
                                                                              children: <
                                                                                  Widget>[
                                                                                  Expanded(
                                                                                  child:   Column(
                                                                                    crossAxisAlignment: CrossAxisAlignment
                                                                                        .start,
                                                                                    mainAxisAlignment: MainAxisAlignment
                                                                                        .start,
                                                                                    children: <
                                                                                        Widget>[
                                                                                      PaddingWrap
                                                                                          .paddingfromLTRB(
                                                                                          17.0,
                                                                                          10.0,
                                                                                          0.0,
                                                                                          0.0,
                                                                                          TextViewWrap
                                                                                              .textViewSingleLine(
                                                                                              _mAcoomplismentDataModel
                                                                                                  .accomplimentData[index]
                                                                                                  .name,
                                                                                              TextAlign
                                                                                                  .start,
                                                                                              ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                                              20.0,
                                                                                              FontWeight
                                                                                                  .bold)),
                                                                                      PaddingWrap
                                                                                          .paddingfromLTRB(
                                                                                          19.0,
                                                                                          5.0,
                                                                                          0.0,
                                                                                          12.0,
                                                                                            Image
                                                                                              .asset(
                                                                                            "assets/newDesignIcon/userprofile/line.png",
                                                                                            height: 3.0,
                                                                                            width: 40.0,
                                                                                          )),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ]),
                                                                        Column(
                                                                        children: <
                                                                            Widget>[
                                                                          _mAcoomplismentDataModel
                                                                              .accomplimentData[index]
                                                                              .achievement
                                                                              .length >
                                                                              0
                                                                              ?   InkWell(
                                                                            child: getgridAchivement(
                                                                                index),
                                                                          )
                                                                              :   Container(
                                                                            height: 0.0,
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                )));
                                                      }))),
                                        ],
                                      ),
                                      _mPublicProfileDataModel
                                          .result
                                          .loveInterests
                                          .length >
                                          0 ||
                                          _mPublicProfileDataModel
                                              .result
                                              .goalInterests
                                              .length >
                                              0
                                          ? !_mPublicProfileDataModel
                                          .result.isInterests
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          :   Column(
                                        //key: dataKeyInterest,
                                        children: <Widget>[
                                          getUserInterestAndGoals(),
                                        ],
                                      )
                                          :   Container(
                                        height: 0.0,
                                      ),
                                      !_mPublicProfileDataModel.result
                                          .isSkillAndCertification ||
                                          (_mPublicProfileDataModel
                                              .result
                                              .toJsonCertificate()
                                              .length ==
                                              0 &&
                                              _mPublicProfileDataModel
                                                  .result
                                                  .skills
                                                  .length ==
                                                  0)
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : skillView(),
                                      _mPublicProfileDataModel.result
                                          .badges ==
                                          null ||
                                          _mPublicProfileDataModel
                                              .result
                                              .badges
                                              .collections
                                              .length ==
                                              0 ||
                                          (_mPublicProfileDataModel
                                              .result
                                              .badges
                                              .collections
                                              .length ==
                                              0)
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : !_mPublicProfileDataModel
                                          .result.isBadges
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : _mPublicProfileDataModel
                                          .result
                                          .badges
                                          .toJsonBadge()
                                          .length ==
                                          0
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : Padding(
                                        padding:
                                        const EdgeInsets
                                            .fromLTRB(
                                            13.0,
                                            13,
                                            13,
                                            0),
                                        child:
                                        Container(
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Color(
                                                      0xffDEDEDE)),
                                              color: Colors
                                                  .white),
                                          child: Column(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .start,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: <
                                                Widget>[
                                                Row(
                                                children: <
                                                    Widget>[
                                                    Expanded(
                                                    child:
                                                      Column(
                                                      crossAxisAlignment: CrossAxisAlignment
                                                          .start,
                                                      mainAxisAlignment: MainAxisAlignment
                                                          .start,
                                                      children: <Widget>[
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            17.0, 10.0, 0.0,
                                                            0.0, TextViewWrap
                                                            .textViewSingleLine(
                                                            "Badges",
                                                            TextAlign.start,
                                                            ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                            20.0,
                                                            FontWeight.normal)),
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            19.0,
                                                            5.0,
                                                            0.0,
                                                            0.0,
                                                              Image.asset(
                                                              "assets/newDesignIcon/userprofile/line.png",
                                                              height: 3.0,
                                                              width: 40.0,
                                                            )),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              badgeList2(),
                                            ],
                                          ),
                                        ),
                                      ),
                                      _mPublicProfileDataModel
                                          .result ==
                                          null ||
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations ==
                                              null ||
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations
                                              .length ==
                                              0
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : !_mPublicProfileDataModel
                                          .result
                                          .isRecommendation
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : _mPublicProfileDataModel
                                          .result
                                          .toJsonRec()
                                          .length ==
                                          0
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          :   Column(
                                        children: <
                                            Widget>[
                                          ecommendation(),
                                        ],
                                      ),
                                      !_mPublicProfileDataModel.result
                                          .isDisplaySocialEmail
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          13.0,
                                          13.0,
                                          0.0,
                                            Container(
                                              child:   Container(
                                                  decoration:   BoxDecoration(
                                                      color: Colors.white,
                                                      border:   Border.all(
                                                          color:   ColorValues.BORDER_COLOR,
                                                          width: 0.5)),
                                                  child:   Container(
                                                      color: Colors.white,
                                                      child:   Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .start,
                                                        children: <
                                                            Widget>[
                                                            Row(
                                                            children: <
                                                                Widget>[
                                                                Expanded(
                                                                child:   Column(
                                                                  crossAxisAlignment: CrossAxisAlignment
                                                                      .start,
                                                                  mainAxisAlignment: MainAxisAlignment
                                                                      .start,
                                                                  children: <
                                                                      Widget>[
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        17.0,
                                                                        10.0,
                                                                        0.0,
                                                                        0.0,
                                                                        TextViewWrap
                                                                            .textViewSingleLine(
                                                                            "Contact information",
                                                                            TextAlign
                                                                                .start,
                                                                            ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                            20.0,
                                                                            FontWeight
                                                                                .normal)),
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        19.0,
                                                                        5.0,
                                                                        0.0,
                                                                        5.0,
                                                                          Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/userprofile/line.png",
                                                                          height: 3.0,
                                                                          width: 40.0,
                                                                        )),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Padding(
                                                            padding: const EdgeInsets
                                                                .fromLTRB(
                                                                17.0,
                                                                0,
                                                                13,
                                                                8),
                                                            child:
                                                              Container(
                                                              child:
                                                                Row(
                                                                children: [
                                                                    Expanded(
                                                                    child: PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                          Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/userprofile/Mail.png",
                                                                          height: 20.0,
                                                                          width: 20.0,
                                                                        )),
                                                                    flex: 0,
                                                                  ),
                                                                    Expanded(
                                                                    child: PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        10.0,
                                                                        10.0,
                                                                        0.0,
                                                                        10.0,
                                                                        TextViewWrap
                                                                            .textViewMultiLine(
                                                                            _mPublicProfileDataModel
                                                                                .result
                                                                                .email,
                                                                            TextAlign
                                                                                .start,
                                                                              Color(
                                                                                0XFF151515),
                                                                            16.0,
                                                                            FontWeight
                                                                                .normal,
                                                                            3)),
                                                                    flex: 1,
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ))))),
                                      _mPublicProfileDataModel
                                          .result ==
                                          null ||
                                          _mPublicProfileDataModel
                                              .result
                                              .socialLinks ==
                                              null
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : !_mPublicProfileDataModel
                                          .result
                                          .isSocialLinks
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : _mPublicProfileDataModel
                                          .result
                                          .toJsonLink()
                                          .length ==
                                          0
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          13.0,
                                          13.0,
                                          0.0,
                                            Container(
                                              child:   Container(
                                                  decoration:   BoxDecoration(
                                                      color: Colors.white,
                                                      border:   Border.all(
                                                          color:   ColorValues.BORDER_COLOR,
                                                          width: 0.5)),
                                                  child:   Container(
                                                      color: Colors.white,
                                                      child:   Column(
                                                        crossAxisAlignment: CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment: MainAxisAlignment
                                                            .start,
                                                        children: <Widget>[
                                                            Row(
                                                            children: <Widget>[
                                                                Expanded(
                                                                child:   Column(
                                                                  crossAxisAlignment: CrossAxisAlignment
                                                                      .start,
                                                                  mainAxisAlignment: MainAxisAlignment
                                                                      .start,
                                                                  children: <
                                                                      Widget>[
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        17.0,
                                                                        10.0,
                                                                        0.0,
                                                                        0.0,
                                                                        TextViewWrap
                                                                            .textViewSingleLine(
                                                                            "Social Links",
                                                                            TextAlign
                                                                                .start,
                                                                            ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                                                            20.0,
                                                                            FontWeight
                                                                                .normal)),
                                                                    PaddingWrap
                                                                        .paddingfromLTRB(
                                                                        19.0,
                                                                        5.0,
                                                                        0.0,
                                                                        12.0,
                                                                          Image
                                                                            .asset(
                                                                          "assets/newDesignIcon/userprofile/line.png",
                                                                          height: 3.0,
                                                                          width: 40.0,
                                                                        )),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          Padding(
                                                            padding: const EdgeInsets
                                                                .fromLTRB(
                                                                17, 0, 0, 10),
                                                            child: Container(
                                                              height: 50.0,
                                                              child: ListView(
                                                                  scrollDirection: Axis
                                                                      .horizontal,
                                                                  children:   List
                                                                      .generate(
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .socialLinks
                                                                          .length, (
                                                                      int index) {
                                                                    return !_mPublicProfileDataModel
                                                                        .result
                                                                        .socialLinks[index]
                                                                        .isProfileDisplay
                                                                        ?   Container(
                                                                      height: 0.0,
                                                                    )
                                                                        : Padding(
                                                                        padding: const EdgeInsets
                                                                            .fromLTRB(
                                                                            2.0,
                                                                            0,
                                                                            0,
                                                                            0),
                                                                        child: Padding(
                                                                            padding: const EdgeInsets
                                                                                .all(
                                                                                4.0),
                                                                            child: InkWell(
                                                                                onTap: () {
                                                                                  if (_mPublicProfileDataModel
                                                                                      .result
                                                                                      .socialLinks[index]
                                                                                      .socialUrl
                                                                                      .toLowerCase()
                                                                                      .contains(
                                                                                      "http")) {
                                                                                    launch(
                                                                                        _mPublicProfileDataModel
                                                                                            .result
                                                                                            .socialLinks[index]
                                                                                            .socialUrl);
                                                                                  } else {
                                                                                    String url = "http://" +
                                                                                        _mPublicProfileDataModel
                                                                                            .result
                                                                                            .socialLinks[index]
                                                                                            .socialUrl;
                                                                                    launch(
                                                                                        url);
                                                                                  }
                                                                                },
                                                                                child: ClipOval(
                                                                                    child: Container(
                                                                                      child: FadeInImage
                                                                                          .assetNetwork(
                                                                                        fit: BoxFit
                                                                                            .fill,
                                                                                        placeholder: 'assets/profile/img_default.png',
                                                                                        image: _mPublicProfileDataModel
                                                                                            .result
                                                                                            .socialLinks[index]
                                                                                            .image ==
                                                                                            "" ||
                                                                                            _mPublicProfileDataModel
                                                                                                .result
                                                                                                .socialLinks[index]
                                                                                                .image ==
                                                                                                "null"
                                                                                            ? ""
                                                                                            : Constant
                                                                                            .IMAGE_PATH +
                                                                                            _mPublicProfileDataModel
                                                                                                .result
                                                                                                .socialLinks[index]
                                                                                                .image,
                                                                                      ),
                                                                                    )))));
                                                                  })),
                                                            ),
                                                          )
                                                        ],
                                                      ))))),

                                      !_mPublicProfileDataModel
                                          .result
                                          .isResume
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          :  _mPublicProfileDataModel
                                          .result
                                          .resume !=
                                          null&&_mPublicProfileDataModel
                                          .result
                                          .resume.displayName!="null"&&_mPublicProfileDataModel
                                          .result
                                          .resume.displayName!=""
                                          ? PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          13.0,
                                          13.0,
                                          20.0,
                                            Container(
                                              child:   Container(
                                                  decoration:   BoxDecoration(
                                                      color: Colors.white,
                                                      border:   Border
                                                          .all(
                                                          color:   ColorValues.BORDER_COLOR,
                                                          width: 0.5)),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                        Row(
                                                        children: <Widget>[
                                                            Expanded(
                                                            child:   Column(
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              children: <Widget>[
                                                                PaddingWrap.paddingfromLTRB(17.0, 10.0, 0.0, 0.0, TextViewWrap.textViewSingleLine("Resume", TextAlign.start,   ColorValues.HEADING_TEXT_CUSTOMPROFILE, 20.0, FontWeight.normal)),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    19.0,
                                                                    5.0,
                                                                    0.0,
                                                                    12.0,
                                                                      Image.asset(
                                                                      "assets/newDesignIcon/userprofile/line.png",
                                                                      height: 3.0,
                                                                      width: 40.0,
                                                                    )),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),

                                                        Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                            const EdgeInsets.fromLTRB(15.0, 0, 13, 13),
                                                            child:   Container(
                                                              child:   Row(
                                                                children: [
                                                                    Expanded(
                                                                    child: PaddingWrap.paddingfromLTRB(
                                                                        0.0,
                                                                        5.0,
                                                                        0.0,
                                                                        0.0,
                                                                          Image.asset(
                                                                          "assets/resume_icon.png",
                                                                          height: 40.0,
                                                                          width: 40.0,
                                                                        )),
                                                                    flex: 0,
                                                                  ),
                                                                    Expanded(
                                                                    child:   Column(
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment.start,
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        PaddingWrap.paddingfromLTRB(
                                                                            5.0,
                                                                            0.0,
                                                                            5.0,
                                                                            0.0,
                                                                      InkWell(onTap:(){
                                                                        Util.launchUrl(_mPublicProfileDataModel
                                                                            .result
                                                                            .resume
                                                                            .uploadType, _mPublicProfileDataModel
                                                                            .result
                                                                            .resume
                                                                            .resumeUrl);
                                                                      },
                                                                          child:    Text(
                                                                              _mPublicProfileDataModel
                                                                                  .result
                                                                                  .resume
                                                                                  .displayName,
                                                                              maxLines: 1,
                                                                              style:   TextStyle(
                                                                                  fontWeight:
                                                                                  FontWeight.normal,
                                                                                  color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                                  fontSize: 16.0),
                                                                            ))),

                                                                      ],
                                                                    ),
                                                                    flex: 1,
                                                                  ),

                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  )))):new Container(
                                        height: 0.0,
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                      flex: 1,
                    )
                  ],
                ))));
  }

  Container getSchoolEducationListItem(index) {
    return !_mPublicProfileDataModel
        .result.educations.schools[index].isProfileDisplay
        ?   Container(
      height: 0.0,
    )
        :   Container(
        child:   InkWell(
          child: PaddingWrap.paddingfromLTRB(
              17.0,
              0.0,
              13.0,
              10.0,
                Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                    Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        10.0,
                        0.0,
                        _mPublicProfileDataModel.result.educations
                            .schools[index].logo ==
                            "" ||
                            _mPublicProfileDataModel.result.educations
                                .schools[index].logo ==
                                "null"
                            ? Image.asset(
                          "assets/profile/img_default.png",
                          height: 37.0,
                          width: 37.0,
                        )
                            :   InkWell(
                            onTap: () {
                              Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                        FullImageView(
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .schools[index]
                                            .logo,
                                        pageName: MessageConstant
                                            .EDUCATION_HEDING,
                                      )));
                            },
                            child:   CachedNetworkImage(
                              height: 37.0,
                              width: 37.0,
                              imageUrl: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel.result
                                      .educations.schools[index].logo,
                              fit: BoxFit.cover,
                              placeholder: (context, url) =>
                                  _loader(
                                      context,
                                      "assets/profile/img_default.png'"),
                              errorWidget: (context, url, error) =>
                                  _error(
                                      "assets/profile/img_default.png'"),
                            )) /*new Container(
                                  height: 37.0,
                                  width: 37.0,
                                  child: FadeInImage.assetNetwork(
                                    fit: BoxFit.cover,
                                    placeholder:
                                        'assets/profile/img_default.png',
                                    image: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel.result
                                            .educations.schools[index].logo,
                                  ))*/
                    ),
                    flex: 0,
                  ),
                    Expanded(
                    child:   Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                              Text(
                              _mPublicProfileDataModel
                                  .result.educations.schools[index].institute,
                              maxLines: 5,
                              style:   TextStyle(
                                  fontWeight: FontWeight.normal,
                                  color:   ColorValues.HEADING_COLOR_EDUCATION,
                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 16.0),
                            )),
                        RichText(
                          maxLines: 15,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            text: _mPublicProfileDataModel.result.educations
                                .schools[index].toYear ==
                                null ||
                                _mPublicProfileDataModel.result.educations
                                    .schools[index].toYear ==
                                    "null" ||
                                _mPublicProfileDataModel.result.educations
                                    .schools[index].toYear ==
                                    ""
                                ? _mPublicProfileDataModel.result.educations
                                .schools[index].fromYear +
                                " - " +
                                "Ongoing" +
                                " | "
                                : _mPublicProfileDataModel.result.educations
                                .schools[index].fromYear +
                                " - " +
                                _mPublicProfileDataModel.result.educations
                                    .schools[index].toYear +
                                " | ",
                            style:   TextStyle(
                                color:   ColorValues.GREY__COLOR,
                                fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 14.0),
                            children: [
                                TextSpan(
                                  text: _mPublicProfileDataModel
                                      .result
                                      .educations
                                      .schools[index]
                                      .fromGrade +
                                      " - " +
                                      _mPublicProfileDataModel.result
                                          .educations.schools[index].toGrade,
                                  style:   TextStyle(
                                      color:
                                        ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0)),
                                TextSpan(
                                  text:
                                  _mPublicProfileDataModel.result.isGpa &&
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .schools[index]
                                          .gpa !=
                                          null &&
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .schools[index]
                                          .gpa !=
                                          ''
                                      ? " | GPA: " +
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .schools[index]
                                          .gpa
                                          .toString()
                                      : '',
                                  style:   TextStyle(
                                      color:
                                        ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    flex: 1,
                  ),
                ],
              )),
          onTap: () {},
          /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
        ));
  }

  Container getCollegeEducationListItem(index) {
    return !_mPublicProfileDataModel
        .result.educations.colleges[index].isProfileDisplay
        ?   Container(
      height: 0.0,
    )
        :   Container(
        child:   InkWell(
          child: PaddingWrap.paddingfromLTRB(
              17.0,
              0.0,
              13.0,
              10.0,
                Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                    Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        10.0,
                        0.0,
                        _mPublicProfileDataModel.result.educations
                            .colleges[index].logo ==
                            "" ||
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].logo ==
                                "null"
                            ? Image.asset(
                          "assets/profile/img_default.png",
                          height: 37.0,
                          width: 37.0,
                        )
                            :   InkWell(
                            onTap: () {
                              Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                        FullImageView(
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .logo,
                                        pageName: MessageConstant
                                            .EDUCATION_HEDING,
                                      )));
                            },
                            child:   CachedNetworkImage(
                              height: 37.0,
                              width: 37.0,
                              imageUrl: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel.result
                                      .educations.colleges[index].logo,
                              fit: BoxFit.cover,
                              placeholder: (context, url) =>
                                  _loader(
                                      context,
                                      "assets/profile/img_default.png'"),
                              errorWidget: (context, url, error) =>
                                  _error(
                                      "assets/profile/img_default.png'"),
                            )) /*new Container(
                                  height: 37.0,
                                  width: 37.0,
                                  child: FadeInImage.assetNetwork(
                                    fit: BoxFit.cover,
                                    placeholder:
                                        'assets/profile/img_default.png',
                                    image: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel.result
                                            .educations.colleges[index].logo,
                                  ))*/
                    ),
                    flex: 0,
                  ),
                    Expanded(
                    child:   Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                              Text(
                              _mPublicProfileDataModel.result.educations
                                  .colleges[index].institute,
                              maxLines: 5,
                              style:   TextStyle(
                                  fontWeight: FontWeight.normal,
                                  color:   ColorValues.HEADING_COLOR_EDUCATION,
                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 16.0),
                            )),
                   /*     _mPublicProfileDataModel.result.educations
                            .colleges[index].degree !=
                            null &&
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].degree !=
                                "null" &&
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].degree !=
                                ""
                            ? RichText(
                          maxLines: 15,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            text: _mPublicProfileDataModel.result
                                .educations.colleges[index].degree +
                                ", ",
                            style:   TextStyle(
                                color:
                                  ColorValues.GREY__COLOR,
                                fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 14.0),
                            children: [
                                TextSpan(
                                  text: _mPublicProfileDataModel
                                      .result
                                      .educations
                                      .colleges[index]
                                      .degree !=
                                      'Professional Certificate'
                                      ? "Major: " +
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .major
                                  *//*" | " +
                                    collegesInfoList[index].minor*//*
                                      : "Certification Name: " +
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .certifications,
                                  style:   TextStyle(
                                      color:  ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0)),
                                TextSpan(
                                  text: _mPublicProfileDataModel
                                      .result
                                      .educations
                                      .colleges[index]
                                      .minor !=
                                      '' &&
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .minor !=
                                          null &&
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .minor !=
                                          'null' &&
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .degree !=
                                          'Professional Certificate'
                                      ? ", Minor: " +
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .minor
                                  *//*" | " +
                                    collegesInfoList[index].minor*//*
                                      : '',
                                  style:   TextStyle(
                                      color:  ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0)),
                            ],
                          ),
                        )
                            : Container(
                          width: 0,
                          height: 0,
                        ),*/

                        _mPublicProfileDataModel.result.educations
                            .colleges[index].degree != null &&
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].degree != "null" &&
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].degree != ""
                            ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            RichText(
                              maxLines: 15,
                              textAlign: TextAlign.start,
                              text: TextSpan(
                                text:
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].degree, //+ ", ",
                                style:   TextStyle(
                                    color:   ColorValues.GREY__COLOR,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 14.0),
                              ),
                            ),
                              Text(
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].degree !=
                                    'Professional Certificate'
                                    ? "Major: " +
                                    _mPublicProfileDataModel.result.educations
                                        .colleges[index].major.trim()
                                /*" | " +
                                    collegesInfoList[index].minor*/
                                    : "Certification Name: " +
                                    _mPublicProfileDataModel.result.educations
                                        .colleges[index]
                                        .certifications
                                        .trim(),
                                style:   TextStyle(
                                    color:   ColorValues.GREY__COLOR,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 14.0)),
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].minor != '' &&
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].minor != null &&
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].minor != 'null' &&
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].degree !=
                                    'Professional Certificate'
                                ?   Text(
                                "Minor: " +
                                    _mPublicProfileDataModel.result.educations
                                        .colleges[index].minor.trim(),
                                /*" | " +
                                    collegesInfoList[index].minor*/

                                style:   TextStyle(
                                    color:   ColorValues.GREY__COLOR,
                                    fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 14.0))
                                : Container(
                              width: 0,
                              height: 0,
                            ),
                          ],
                        )
                            : Container(
                          width: 0,
                          height: 0,
                        ),

                          Row(
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                  Text(
                                  _mPublicProfileDataModel.result.educations
                                      .colleges[index].toYear ==
                                      null ||
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .toYear ==
                                          "null" ||
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .toYear ==
                                          ""
                                      ? _mPublicProfileDataModel
                                      .result
                                      .educations
                                      .colleges[index]
                                      .fromYear +
                                      " - " +
                                      "Ongoing"
                                      : _mPublicProfileDataModel
                                      .result
                                      .educations
                                      .colleges[index]
                                      .fromYear +
                                      " - " +
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .toYear ,
                                  style:   TextStyle(
                                      color:
                                        ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                )),
                           /* PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                  Text(
                                  _mPublicProfileDataModel.result.educations
                                      .colleges[index].graduationYear,
                                  style:   TextStyle(
                                      color:
                                        ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                )),*/
                            _mPublicProfileDataModel.result.isGpa &&
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].gpa !=
                                    null &&
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].gpa !=
                                    ''
                                ? PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                  Text(
                                  _mPublicProfileDataModel
                                      .result
                                      .educations
                                      .colleges[index]
                                      .gpa !=
                                      null
                                      ? " | GPA: " +
                                      _mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .gpa
                                          .toString()
                                      : '',
                                  style:   TextStyle(
                                      color:  ColorValues.GREY__COLOR,
                                      fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 14.0),
                                ))
                                :   Container(
                              height: 0.0,
                            ),
                          ],
                        ),
                      ],
                    ),
                    flex: 1,
                  ),
                ],
              )),
          onTap: () {},
          /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
        ));
  }

  Container getTestScoreListItem(index) {
    return   Container(
        color: Colors.white,
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            0.0,
            0.0,
              Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                  Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        17.0,
                        0.0,
                        13.0,
                        0.0,
                          Column(
                            children:   List.generate(
                                _mPublicProfileDataModel.result
                                    .testScores[index].scores.length, (index3) {
                              return !_mPublicProfileDataModel
                                  .result
                                  .testScores[index]
                                  .scores[index3]
                                  .isProfileDisplay
                                  ?   Container(
                                height: 0.0,
                              )
                                  : PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                    Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                        Container(
                                          child:   Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                    Text(
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .testScores[index].name,
                                                    maxLines: 2,
                                                    textAlign: TextAlign.start,
                                                    style:   TextStyle(
                                                        fontWeight:
                                                        FontWeight.normal,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0),
                                                  )),

                                                Row(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <Widget>[
                                                    Expanded(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                          0.0,
                                                          5.0,
                                                          0.0,
                                                          0.0,
                                                            Text(
                                                              getConvertedDateStamp2(_mPublicProfileDataModel
                                                                .result
                                                                .testScores[index]
                                                                .scores[index3]
                                                                .dateTaken),
                                                            style:    TextStyle(
                                                              color:
                                                                ColorValues.GREY__COLOR,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize: 14.0),
                                                          )),
                                                      flex: 1),
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .testScores[index]
                                                      .scores[index3]
                                                      .docUrl
                                                      .length >
                                                      0 ||
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .testScores[index]
                                                          .scores[index3]
                                                          .imageUrl
                                                          .length >
                                                          0
                                                      ?   Expanded(
                                                      child:   InkWell(
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            0.0,
                                                            0.0,
                                                              Text(
                                                              "View Photos & Documents",
                                                              maxLines: 2,
                                                              style:   TextStyle(
                                                                  color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  fontSize:
                                                                  14.0,
                                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () {
                                                          var score = _mPublicProfileDataModel
                                                              .result
                                                              .testScores[index]
                                                              .scores[index3];


                                                          Navigator.of(context)
                                                              .push(
                                                                MaterialPageRoute(
                                                                  builder: (
                                                                      BuildContext
                                                                      context) =>
                                                                    DocumentListingWidget(
                                                                      TestDataModel(
                                                                          score
                                                                              .name,
                                                                          int
                                                                              .parse(
                                                                              score
                                                                                  .testId
                                                                                  .toString()),
                                                                          score
                                                                              .userTestId,
                                                                          score
                                                                              .dateTaken,
                                                                          0,
                                                                          score
                                                                              .docUrl,
                                                                          null,
                                                                          score
                                                                              .imageUrl,
                                                                          "0"))));
                                                        },
                                                      ),
                                                      flex: 0)
                                                      :   Container(
                                                    height: 0.0,
                                                  ),
                                                ],
                                              ),


                                                Column(
                                                  children:   List.generate(
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .testScores[index]
                                                          .scores[index3]
                                                          .subjects
                                                          .length, (index2) {
                                                    return Container(
                                                        color: Colors.white,
                                                        child:
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            10.0,
                                                            0.0,
                                                              Row(
                                                              children: <
                                                                  Widget>[
                                                                  Expanded(
                                                                  child:   Text(
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .testScores[
                                                                    index]
                                                                        .scores[
                                                                    index3]
                                                                        .subjects[
                                                                    index2]
                                                                        .subject,
                                                                    style:   TextStyle(
                                                                        color:   Color(
                                                                            0xFF151515),
                                                                       fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                        fontSize:
                                                                        14.0),
                                                                  ),
                                                                  flex: 1,
                                                                ),
                                                                  Expanded(
                                                                  child:   Text(
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .testScores[
                                                                    index]
                                                                        .scores[
                                                                    index3]
                                                                        .subjects[
                                                                    index2]
                                                                        .score
                                                                        .toString(),
                                                                    style:   TextStyle(
                                                                        color:   Color(
                                                                            0XFF151515),
                                                                       fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                        fontSize:
                                                                        14.0),
                                                                  ),
                                                                  flex: 0,
                                                                )
                                                              ],
                                                            )));
                                                  })),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                    Container(
                                                    height: 1.0,
                                                    color:   ColorValues.GREY_TEXT_COLOR
                                                        .withOpacity(.1),
                                                  ))
                                            ],
                                          ))
                                    ],
                                  ));
                            }))),
                  ],
                ),

                // CustomViews.getSepratorLine()
              ],
            )));
  }

  badgeList2() {
    return   Column(
      children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children:   List.generate(
                _mPublicProfileDataModel.result.badges.collections.length,
                    (int index) {
                  return !_mPublicProfileDataModel
                      .result.badges.collections[index].isProfileDisplay
                      ?   Container(
                    height: 0.0,
                  )
                      :   Column(
                    children: <Widget>[
                        Row(
                        children: <Widget>[
                          Expanded(
                            flex: 0,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  left: 13.0,
                                  top: 7.0,
                                  right: 10.0,
                                  bottom: 7.0),
                              child: Container(
                                height: 94.0,
                                width: 86.0,
                                decoration: BoxDecoration(
                                    border:
                                    Border.all(color: ColorValues.GREY__COLOR_DIVIDER)),
                                child: Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child:   ClipOval(
                                      child: FadeInImage.assetNetwork(
                                        fit: BoxFit.contain,
                                        placeholder:
                                        'assets/profile/user_on_user.png',
                                        image: Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getMediumImage(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .badges
                                                    .collections[index]
                                                    .image),
                                        height: 94.0,
                                        width: 86.0,
                                      )),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[



                                Expanded(
                                  flex: 0,
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 3, bottom: 4),
                                    child: Text(
                                      _mPublicProfileDataModel.result.badges
                                          .collections[index].name.toString(),
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        color: ColorValues.HEADING_COLOR_EDUCATION,
                                      ),
                                    ),
                                  ),
                                ),

                                Expanded(
                                  flex: 0,
                                  child:  _mPublicProfileDataModel.result.badges
                                      .collections[index].companyName
                                      .toString() ==
                                      ""
                                      ? new Container(height: 0.0)
                                      : Text(
                                    _mPublicProfileDataModel.result.badges
                                        .collections[index].companyName
                                        .toString(),
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400,

                                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      color:
                                      ColorValues.HEADING_COLOR_EDUCATION,
                                    ),
                                  ),
                                ),


                                Expanded(
                                  flex: 0,
                                  child:  _mPublicProfileDataModel.result.badges
                                      .collections[index].date
                                      .toString() ==
                                      ""
                                      ? new Container(height: 0.0)
                                      : InkWell(
                                    child: Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child:Text(

                                        _mPublicProfileDataModel.result.badges
                                            .collections[index].type=="request" && _mPublicProfileDataModel.result.badges
                                            .collections[index].status=="accepted"? 'Issued on: '  +Util.getConvertedDateStampNew( _mPublicProfileDataModel.result.badges
                                            .collections[index].date.toString()):'Issued on: '+ Util.getConvertedDateStampNew(_mPublicProfileDataModel.result.badges
                                            .collections[index].date.toString()),
                                      style: TextStyle(
                                        color: ColorValues.riminderColor,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        fontFamily:
                                        Constant.TYPE_CUSTOMREGULAR,
                                      ),
                                      )
                                    ),
                                    onTap: () {},
                                  ),
                                ),


                              ],
                            ),
                          )
                        ],
                      )
                    ],
                  );
                })),
      ],
    );
  }

  Widget ecommendation() {
    return PaddingWrap.paddingfromLTRB(
        13.0,
        13.0,
        13.0,
        0.0,
          Container(
            decoration:   BoxDecoration(
                color: Colors.white,
                border:   Border.all(
                    color:   ColorValues.BORDER_COLOR, width: 0.5)),
            child:   Column(
              children: <Widget>[
                  Row(
                  children: <Widget>[
                      Expanded(
                      child:   Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              17.0,
                              5.0,
                              5.0,
                              5.0,
                              TextViewWrap.textViewSingleLine(
                                  "Recommendations",
                                  TextAlign.start,
                                    ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                  20.0,
                                  FontWeight.normal)),
                          PaddingWrap.paddingfromLTRB(
                              19.0,
                              0.0,
                              0.0,
                              0.0,
                                Image.asset(
                                  "assets/newDesignIcon/userprofile/line.png",
                                  height: 3.0,
                                  width: 40.0)),
                        ],
                      ),
                    ),
                  ],
                ),
                  Container(
                    padding:   EdgeInsets.fromLTRB(17.0, 0.0, 17.0, 0.0),
                    child:   Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children:   List.generate(
                            _mPublicProfileDataModel
                                .result.recommendations.length, (int index) {
                          return !_mPublicProfileDataModel.result
                              .recommendations[index].isProfileDisplay
                              ?   Container(
                            height: 0.0,
                          )
                              : Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                                Expanded(
                                child:   Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[


                                    _mPublicProfileDataModel
                                        .result
                                        .recommendations[index].stage == "Added"||   _mPublicProfileDataModel
                                        .result
                                        .recommendations[index].stage=="Replied"
                                        ? Expanded(
                                      flex: 0,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 5, left: 0.0, right: 0),
                                        child: Text(
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index]
                                              .recommendation,
                                          maxLines:
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index].isMore
                                              ? 50
                                              : 3,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 16,
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR,
                                          ),
                                        ),
                                      ),
                                    )
                                        : Expanded(
                                      flex: 0,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 5, left: 0.0, right: 0),
                                        child: Text(
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index].request,
                                          maxLines:
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index].isMore
                                              ? 50
                                              : 3,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 15,
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR,
                                          ),
                                        ),
                                      ),
                                    ),
                                    _mPublicProfileDataModel
                                        .result
                                        .recommendations[index].stage == "Added"
                                        ? _mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .recommendation
                                        .length >
                                        100
                                        ? InkWell(
                                      child: Padding(
                                          padding: const EdgeInsets.only(
                                              top: 0.0,
                                              left: 0.0,
                                              right: 0),
                                          child: Text(
                                            _mPublicProfileDataModel
                                                .result
                                                .recommendations[index]
                                                .isMore
                                                ? "Less"
                                                : "More",
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          )),
                                      onTap: () {
                                        if (_mPublicProfileDataModel
                                            .result
                                            .recommendations[index]
                                            .isMore)
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index]
                                              .isMore = false;
                                        else
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index]
                                              .isMore = true;

                                        setState(() {
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index].isMore;
                                        });
                                      },
                                    )
                                        : Container(
                                      height: 0.0,
                                    )
                                        :_mPublicProfileDataModel
                                        .result
                                        .recommendations[index].request.length >
                                        100
                                        ? InkWell(
                                      child: Padding(
                                          padding: const EdgeInsets.only(
                                              top: 0.0,
                                              left: 0.0,
                                              right: 0),
                                          child: Text(
                                            _mPublicProfileDataModel
                                                .result
                                                .recommendations[index]
                                                .isMore
                                                ? "Less"
                                                : "More",
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 16,
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR,
                                            ),
                                          )),
                                      onTap: () {
                                        if (_mPublicProfileDataModel
                                            .result
                                            .recommendations[index]
                                            .isMore)
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index]
                                              .isMore = false;
                                        else
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index]
                                              .isMore = true;

                                        setState(() {
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[index].isMore;
                                        });
                                      },
                                    )
                                        : Container(
                                      height: 0.0,
                                    ),

                                    /*(_mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .stage==
                                        "Added"&& _mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .recommendation
                                        .trim() .length==0)||
                                        (_mPublicProfileDataModel
                                            .result
                                            .recommendations[index]
                                            .stage==
                                            "Replied"&& _mPublicProfileDataModel
                                            .result
                                            .recommendations[index]
                                            .recommendation
                                            .trim() .length==0)

                                        ?new Container(height:0.0):
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        8.0,
                                        0.0,
                                          Text(
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[
                                          index]
                                              .stage ==
                                              "Requested"
                                              ? "" +
                                              _mPublicProfileDataModel
                                                  .result
                                                  .recommendations[
                                              index]
                                                  .request
                                                  .trim() +
                                              ""
                                              : "" +
                                              _mPublicProfileDataModel
                                                  .result
                                                  .recommendations[
                                              index]
                                                  .recommendation
                                                  .trim() +
                                              "",
                                          maxLines: 50,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style:   TextStyle(
                                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 16.0,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                        )),*/


                                    _mPublicProfileDataModel
                                        .result
                                        .recommendations[
                                    index]
                                        .recommenderFile!="null"&&_mPublicProfileDataModel
                                        .result
                                        .recommendations[
                                    index]
                                        .recommenderFile!=""  ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        15.0,
                                        8.0,
                                        15.0,    InkWell(onTap:(){
                                      launch(Constant.IMAGE_PATH+ _mPublicProfileDataModel
                                          .result
                                          .recommendations[
                                      index]
                                          .recommenderFile);

                                    },child:Row(
                                      crossAxisAlignment:

                                      CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: <Widget>[
                                          Expanded(
                                            child: Image.asset(
                                                "assets/added_pdf.png",
                                                height: 56,
                                                width: 56),
                                            flex: 0),
                                          Expanded(
                                            child: Padding(
                                              padding:
                                              const EdgeInsets
                                                  .only(
                                                  left: 10.0,
                                                  bottom:
                                                  8.0),
                                              child: TextViewWrap
                                                  .textViewMultiLine(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .recommendations[
                                                  index]
                                                      .recommenderFileName,
                                                  TextAlign
                                                      .start,
                                                    ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  14.0,
                                                  FontWeight
                                                      .normal,
                                                  1),
                                            ),
                                            flex: 1)
                                      ],
                                    ))):new Container(height: 0.0,),

                                    _mPublicProfileDataModel
                                        .result
                                        .recommendations[
                                    index]
                                        .recommender ==
                                        null ||
                                        _mPublicProfileDataModel
                                            .result
                                            .recommendations[
                                        index]
                                            .recommender
                                            .length ==
                                            0
                                        ?   Container(
                                      height: 0.0,
                                    )
                                        : PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        8.0,
                                        2.0,
                                          Text(
                                          _mPublicProfileDataModel
                                              .result
                                              .recommendations[
                                          index]
                                              .recommender[0]
                                              .firstName ==
                                              "null"
                                              ? ""
                                              : _mPublicProfileDataModel
                                              .result
                                              .recommendations[
                                          index]
                                              .recommender[
                                          0]
                                              .lastName ==
                                              "null"
                                              ? _mPublicProfileDataModel
                                              .result
                                              .recommendations[
                                          index]
                                              .recommender[0]
                                              .firstName
                                              : _mPublicProfileDataModel
                                              .result
                                              .recommendations[
                                          index]
                                              .recommender[
                                          0]
                                              .firstName +
                                              " " +
                                              _mPublicProfileDataModel
                                                  .result
                                                  .recommendations[
                                              index]
                                                  .recommender[
                                              0]
                                                  .lastName,
                                          overflow:
                                          TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style:   TextStyle(
                                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMBOLD),
                                        )),
                                    _mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .level3Competency ==
                                        "null" || _mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .level3Competency ==
                                        "" ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        8.0,
                                        10.0,
                                        Row(
                                          children: <Widget>[

                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                8.0,
                                                5.0,
                                                Text(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .recommendations[index]
                                                      .title,
                                                  overflow: TextOverflow
                                                      .ellipsis,
                                                  textAlign: TextAlign.start,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      fontSize: 12.0,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                )),


                                            _mPublicProfileDataModel
                                                .result
                                                .recommendations[index].stage ==
                                                "Replied" ||
                                                _mPublicProfileDataModel
                                                    .result
                                                    .recommendations[index]
                                                    .stage == "Requested" ?
                                            Expanded(
                                              child: Text("Sent On: " +
                                                  Util.getConvertedDateStampNew(
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .recommendations[index]
                                                          .requestedDate),
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.end,
                                                maxLines: 2,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                    Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                              flex: 1,
                                            ) : Expanded(
                                              child: Text(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .recommendations[index]
                                                    .type == "self"
                                                    ? "" +
                                                    Util
                                                        .getConvertedDateStampNew(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .recommendations[index]
                                                            .requestedDate)
                                                    : "Sent On: " +
                                                    Util
                                                        .getConvertedDateStampNew(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .recommendations[index]
                                                            .requestedDate),
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.end,
                                                maxLines: 2,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                    Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                              flex: 1,
                                            )


                                          ],
                                        )) :
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        8.0,
                                        5.0,
                                        Text(
                                          _mPublicProfileDataModel.result
                                              .recommendations[index].title,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontSize: 12.0,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )),


                                    _mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .level3Competency ==
                                        "null" || _mPublicProfileDataModel
                                        .result
                                        .recommendations[index]
                                        .level3Competency ==
                                        "" ? Container(height: 0,) :

                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        8.0,
                                        10.0,
                                        Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                "For: ",
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontSize: 12.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                              flex: 0,
                                            ),

                                            Expanded(
                                              child: Text(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .recommendations[index]
                                                    .level3Competency,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                    Constant.customBold),
                                              ),
                                              flex: 0,
                                            ),

                                            _mPublicProfileDataModel
                                                .result
                                                .recommendations[index].stage ==
                                                "Replied" ||
                                                _mPublicProfileDataModel
                                                    .result
                                                    .recommendations[index]
                                                    .stage == "Requested" ?
                                            Expanded(
                                              child: Text("Sent On: " +
                                                  Util.getConvertedDateStampNew(
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .recommendations[index]
                                                          .requestedDate),
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.end,
                                                maxLines: 2,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                    Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                              flex: 1,
                                            ) : Expanded(
                                              child: Text(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .recommendations[index]
                                                    .type == "self"
                                                    ? "" +
                                                    Util
                                                        .getConvertedDateStampNew(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .recommendations[index]
                                                            .requestedDate)
                                                    : "Sent On: " +
                                                    Util
                                                        .getConvertedDateStampNew(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .recommendations[index]
                                                            .requestedDate),
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.end,
                                                maxLines: 2,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 12.0,
                                                    fontFamily:
                                                    Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                              flex: 1,
                                            )


                                          ],
                                        )),

                                  ],
                                ),
                                flex: 1,
                              ),
                            ],
                          );
                        })))
              ],
            )));
  }

  Padding skillView() {
    return PaddingWrap.paddingfromLTRB(
        13.0,
        13.0,
        13.0,
        0.0,
          Container(
            child:   Container(
                decoration:   BoxDecoration(
                    color: Colors.white,
                    border:   Border.all(
                        color:   ColorValues.BORDER_COLOR,
                        width: 0.5)),
                child:   Container(
                    color: Colors.white,
                    child:   Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                          Row(
                          children: <Widget>[
                              Expanded(
                              child:   Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                      17.0,
                                      10.0,
                                      0.0,
                                      0.0,
                                      TextViewWrap.textViewSingleLine(
                                          "Skills & Certifications",
                                          TextAlign.start,
                                            ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                          20.0,
                                          FontWeight.normal)),
                                  PaddingWrap.paddingfromLTRB(
                                      19.0,
                                      5.0,
                                      0.0,
                                      12.0,
                                        Image.asset(
                                        "assets/newDesignIcon/userprofile/line.png",
                                        height: 3.0,
                                        width: 40.0,
                                      )),
                                ],
                              ),
                            ),
                          ],
                        ),
                          Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            _mPublicProfileDataModel.result != null &&
                                _mPublicProfileDataModel.result.skills !=
                                    null &&
                                _mPublicProfileDataModel
                                    .result.skills.length >
                                    0
                                ? Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                PaddingWrap.paddingfromLTRB(
                                    17.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    TextViewWrap.textViewSingleLine(
                                        "Skills",
                                        TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                        14.0,
                                        FontWeight.bold)),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      13.0, 0, 13, 0),
                                  child: getSelectedWidgets(),
                                ),
                              ],
                            )
                                :   Container(
                              height: 0.0,
                            ),
                            /* _mPublicProfileDataModel.result.skills.length > 0 &&
                                    _mPublicProfileDataModel
                                            .result.certificates.length >
                                        0
                                ?   Divider(color: Colors.grey[300])
                                :   Container(
                                    height: 0.0,
                                  ),*/
                            _mPublicProfileDataModel.result
                                .toJsonCertificate()
                                .length ==
                                0
                                ?   Container(
                              height: 0.0,
                            )
                                : Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                PaddingWrap.paddingfromLTRB(
                                    17.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    TextViewWrap.textViewSingleLine(
                                        "Certifications",
                                        TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                        14.0,
                                        FontWeight.bold)),
                                  Column(
                                    children:   List.generate(
                                        _mPublicProfileDataModel
                                            .result
                                            .certificates
                                            .length, (int index) {
                                      return !_mPublicProfileDataModel
                                          .result
                                          .certificates[index]
                                          .isProfileDisplay
                                          ?   Container(
                                        height: 0.0,
                                      )
                                          : getCertificateItem(index);
                                    })),
                              ],
                            )
                          ],
                        )
                      ],
                    )))));
  }

  Container getCertificateItem(index) {
    return   Container(
        child:   InkWell(
          child: PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              0.0,
              0.0,
                Column(
                children: <Widget>[
                    Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                        Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            17.0,
                            3.0,
                            10.0,
                            5.0,
                            _mPublicProfileDataModel
                                .result.certificates[index].image ==
                                "" ||
                                _mPublicProfileDataModel
                                    .result.certificates[index].image ==
                                    "null"
                                ? Image.asset(
                              "assets/portfolio/certificate.png",
                              height: 50.0,
                              width: 50.0,
                            )
                                :   InkWell(
                              child:   Container(
                                  height: 50.0,
                                  width: 50.0,
                                  child: FadeInImage.assetNetwork(
                                    fit: BoxFit.cover,
                                    placeholder:
                                    'assets/portfolio/certificate.png',
                                    image: Constant.IMAGE_PATH +
                                        _mPublicProfileDataModel
                                            .result.certificates[index].image,
                                  )),
                              onTap: () {
                                Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                          FullImageView(
                                            _mPublicProfileDataModel
                                                .result
                                                .certificates[index]
                                                .image)));
                              },
                            )),
                        flex: 0,
                      ),
                        Expanded(
                        child:   Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                5.0,
                                0.0,
                                  Text(
                                  _mPublicProfileDataModel
                                      .result.certificates[index].title,
                                  maxLines: 5,
                                  style:   TextStyle(
                                      fontWeight: FontWeight.normal,
                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 16.0),
                                )),
                            PaddingWrap.paddingfromLTRB(
                                5.0,
                                5.0,
                                0.0,
                                20.0,
                                  Text(
                                  'Received on: '  +
                                      Util.getConvertedDateStamp(
                                          _mPublicProfileDataModel
                                              .result.certificates[index].date
                                              .toString()),
                                  style:   TextStyle(
                                      color:   ColorValues.GREY_TEXT_COLOR,
                                      fontSize: 12.0),
                                )),
                          ],
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                  /*    _mPublicProfileDataModel.result.certificates.length - 1 != index
                  ?   Container(
                      color: Colors.grey[300],
                      height: 1.0,
                    )
                  :   Container(
                      height: 0.0,
                    )*/
                ],
              )),
          onTap: () {},
          /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
        ));
  }

  Container getSelectedWidgets() {
    return Container(
      //color: Colors.redAccent,
      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          primary: true,
          shrinkWrap: true,
          children: <Widget>[
            Wrap(
              spacing: 5.0,
              runSpacing: 0.0,
              children: List<Widget>.generate(
                  _mPublicProfileDataModel.result.skills.length,
                  // place the length of the array here
                      (int index) {
                    //int h = _items[index].name.toString().length % 36;
                    //print('Height h:::: $h');
                    return InputChip(
                      label: Text(
                        '${_mPublicProfileDataModel.result.skills[index].name}',
                        overflow: TextOverflow.clip,
                        style: TextStyle(
                          fontSize: 14.0,
                        ),
                      ),
                      // softWrap: true,maxLines: 100,
                      //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      backgroundColor:   ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                      shape: StadiumBorder(
                        side: BorderSide(
                          color:   ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                        ),
                      ),
                      onSelected: (bool value) {},

                      labelStyle: TextStyle(
                        color:   ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5.0, vertical: 3.0),
                    );
                  }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget getUserInterestAndGoals() {
    return PaddingWrap.paddingfromLTRB(
        13.0,
        13.0,
        13.0,
        0.0,
          Container(
            decoration:   BoxDecoration(
                color: Colors.white,
                border:   Border.all(
                    color:   ColorValues.BORDER_COLOR, width: 0.5)),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 5),
              child:   Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                    child:   Row(
                      children: <Widget>[
                          Expanded(
                          child:   Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  5.0,
                                  5.0,
                                  5.0,
                                  TextViewWrap.textViewSingleLine(
                                      "Interests & Future Goals",
                                      TextAlign.start,
                                        ColorValues.HEADING_TEXT_CUSTOMPROFILE,
                                      20.0,
                                      FontWeight.normal)),
                              PaddingWrap.paddingfromLTRB(
                                  19.0,
                                  0.0,
                                  0.0,
                                  10.0,
                                    Image.asset(
                                      "assets/newDesignIcon/userprofile/line.png",
                                      height: 3.0,
                                      width: 40.0)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                            17.0,
                            0.0,
                            17.0,
                            0.0,
                            getUserInterestChips(
                                _mPublicProfileDataModel.result
                                    .loveOtherInterests),
                          ),
                          _mPublicProfileDataModel.result.goalInterests.length >
                              0
                              ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              /*       Container(
                                  color:   ColorValues.BORDER_COLOR,
                                  height: 0.5,
                                ),*/
                              PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  10.0,
                                  17.0,
                                  5.0,
                                  TextViewWrap.textViewSingleLine(
                                      "What’s next after high school?",
                                      TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.bold)),
                              //getUserInterestChips(goalInterestsList,false),
                              PaddingWrap.paddingfromLTRB(
                                17.0,
                                0.0,
                                17.0,
                                0.0,
                                getUserInterestChips(_mPublicProfileDataModel
                                    .result.goalInterests),
                              ),

                              _mPublicProfileDataModel
                                  .result.goalInterestInstitute !=
                                  null &&
                                  _mPublicProfileDataModel
                                      .result.goalInterestInstitute !=
                                      'null' &&
                                  _mPublicProfileDataModel
                                      .result.goalInterestInstitute !=
                                      ''
                                  ? PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  10.0,
                                  17.0,
                                  5.0,
                                  TextViewWrap.textViewSingleLine(
                                      "Institute(s)",
                                      TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.bold))
                                  : Container(),
                              _mPublicProfileDataModel
                                  .result.goalInterestInstitute !=
                                  null &&
                                  _mPublicProfileDataModel
                                      .result.goalInterestInstitute !=
                                      'null' &&
                                  _mPublicProfileDataModel
                                      .result.goalInterestInstitute !=
                                      ''
                                  ? PaddingWrap.paddingfromLTRB(
                                  17.0,
                                  0.0,
                                  17.0,
                                  13.0,
                                  TextViewWrap.textViewSingleLine(
                                      "${_mPublicProfileDataModel.result
                                          .goalInterestInstitute}",
                                      TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.normal))
                                  : Container(),
                            ],
                          )
                              : Container(
                            height: 0,
                            width: 0,
                          )
                        ],
                      )),
                ],
              ),
            )));
  }

  getUserInterestChips(_items) {
    return _items != null
        ? Container(
      //color: Colors.redAccent,
      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          primary: true,
          shrinkWrap: true,
          children: <Widget>[
            Wrap(
              spacing: 5.0,
              runSpacing: 0.0,
              children: List<Widget>.generate(
                  _items.length, // place the length of the array here
                      (int index) {
                    //int h = _items[index].name.toString().length % 36;
                    //print('Height h:::: $h');
                    return InputChip(
                      label: Text(
                        '${_items[index].name}',
                        overflow: TextOverflow.clip,
                        style: TextStyle(
                          fontSize: 14.0,
                        ),
                      ),
                      // softWrap: true,maxLines: 100,
                      //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      backgroundColor:   ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                      shape: StadiumBorder(
                        side: BorderSide(
                          color:   ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                        ),
                      ),
                      onSelected: (bool value) {},

                      labelStyle: TextStyle(
                        color:   ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 0.0, vertical: 3.0),
                    );
                  }).toList(),
            ),
          ],
        ),
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }

  Container getgridBadges(narativeListIndex, index) {
    return _mAcoomplismentDataModel.accomplimentData[narativeListIndex]
        .achievement[index].all_badge_trophy_certificate !=
        null &&
        _mAcoomplismentDataModel.accomplimentData[narativeListIndex]
            .achievement[index].all_badge_trophy_certificate.length >
            0
        ?   Container(
        padding:   EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: Column(
          children: <Widget>[
              Row(
              children: <Widget>[
                  Expanded(
                  child:   Image.asset(
                    "assets/newDesignIcon/userprofile/certificate.png",
                    width: 12.0,
                    height: 10.0,
                  ),
                  flex: 0,
                ),
                  Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      20.0,
                      0.0,
                      TextViewWrap.textView(
                          "  CERTIFICATES, TROPHIES & BADGES",
                          TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                          12.0,
                          FontWeight.w400)),
                  flex: 0,
                ),
                  Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      10.0,
                      0.0,
                        Container(
                        child: CustomViews.getSepratorLine(),
                      )),
                  flex: 1,
                )
              ],
            ),
            PaddingWrap.paddingfromLTRB(
                0.0,
                10.0,
                0.0,
                10.0,
                  Container(
                    height: 48.0,
                    child:   GridView.count(
                      primary: true,
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.all(5.0),
                      crossAxisCount: 1,
                      childAspectRatio: .98,
                      mainAxisSpacing: 5.0,
                      crossAxisSpacing: 4.0,
                      children:   List.generate(
                          _mAcoomplismentDataModel
                              .accomplimentData[narativeListIndex]
                              .achievement[index]
                              .all_badge_trophy_certificate
                              .length, (int index2) {
                        return   Container(
                            decoration:   BoxDecoration(
                                border:   Border.all(
                                    color:   ColorValues.LIGHT_GREY_TEXT_COLOR)),
                            child:   InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  /* FadeInImage.assetNetwork(
                                            fit: BoxFit.cover,
                                            height: 45.0,
                                            width: 48.0,
                                            placeholder:
                                                'assets/profile/default_achievement.png',
                                            image: Constant.IMAGE_PATH + uri)*/
                                    CachedNetworkImage(
                                    height: 45.0,
                                    width: 48.0,
                                    imageUrl: Constant.IMAGE_PATH +
                                        _mAcoomplismentDataModel
                                            .accomplimentData[
                                        narativeListIndex]
                                            .achievement[index]
                                            .all_badge_trophy_certificate[
                                        index2]
                                            .file,
                                    fit: BoxFit.cover,
                                    placeholder: (context, url) =>
                                        _loader(
                                            context,
                                            "assets/profile/default_achievement.png"),
                                    errorWidget: (context, url, error) =>
                                        _error(
                                            "assets/profile/default_achievement.png"),
                                  )),
                              onTap: () {
                                Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                          CommonFullViewWidget(
                                            _mAcoomplismentDataModel
                                                .accomplimentData[
                                            narativeListIndex]
                                                .achievement[index]
                                                .all_badge_trophy_certificate,
                                            MessageConstant
                                                .CUSTOM_PROFILE_HEDING,
                                            index2,
                                            MessageConstant
                                                .CERTIFICATES_TROPHIES_HEDING)));
                              },
                            ));
                      }),
                    ))),
          ],
        ))
        :   Container(
      height: 1.0,
    );
  }

  Widget isImageOrVideo(FileDataModel _mPortFolioAssest, heigt, type) {
    return _mPortFolioAssest.type == "image"
        ?   Container(
        height: heigt,
        child:   CachedNetworkImage(
          width: double.infinity,
          height: heigt,
          imageUrl: Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
          fit: BoxFit.cover,
          placeholder: (context, url) =>
              _loader(
                  context,
                  type == "Sports"
                      ? "assets/portfolio/sport_default.png"
                      : "assets/portfolio/arts_default.png"),
          errorWidget: (context, url, error) =>
              _error(type == "Sports"
                  ? "assets/portfolio/sport_default.png"
                  : "assets/portfolio/arts_default.png"),
        ))
        :   Container(
        height: heigt,
        width: double.infinity,
        child: /*new VideoPlayPause(Constant.IMAGE_PATH + _mPortFolioAssest.file, "")*/

          VideoView(Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
            "", false, type));
  }

  getVideoThumb(path, int index) async {
    final thumbnailFile =
    await uploadMedia.getVideoThumbnailFromUrl(Constant.IMAGE_PATH + path);
    print(
        'getData() index::: $index, thumbnailFile:::: ${thumbnailFile}, video url:::: ${path}');
    return Image.file(
      thumbnailFile,
      fit: BoxFit.contain,
    );
  }

  Widget getgridAchivement(index1) {
    return _mAcoomplismentDataModel.accomplimentData[index1].achievement !=
        null &&
        _mAcoomplismentDataModel
            .accomplimentData[index1].achievement.length >
            0
        ?   Column(
      children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children:   List.generate(
                _mAcoomplismentDataModel.accomplimentData[index1]
                    .achievement.length, (int index) {
              int size = _mAcoomplismentDataModel.accomplimentData[index1]
                  .achievement[index].fileList.length;

              return !_mAcoomplismentDataModel.accomplimentData[index1]
                  .achievement[index].isProfileDisplay
                  ?   Container(
                height: 0.0,
              )
                  : _mAcoomplismentDataModel.accomplimentData[index1]
                  .achievement[index].type ==
                  "portfolio"
                  ?   Column(
                children: <Widget>[
                    InkWell(
                    child:   Column(
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            10.0,
                            0.0,
                            10.0,
                            PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Column(
                                  children: [
                                    Stack(
                                      children: [
                                        _mAcoomplismentDataModel
                                            .accomplimentData[
                                        index1]
                                            .achievement[
                                        index]
                                            .fileList
                                            .length <
                                            4
                                            ? _mAcoomplismentDataModel
                                            .accomplimentData[
                                        index1]
                                            .achievement[
                                        index]
                                            .fileList
                                            .length ==
                                            0
                                            ?   Container(
                                          height:
                                          165.0,
                                          width: double
                                              .infinity,
                                          child:   Image
                                              .asset(
                                            _mAcoomplismentDataModel
                                                .accomplimentData[index1]
                                                .level1 ==
                                                "Sports"
                                                ? "assets/portfolio/sport_default.png"
                                                : "assets/portfolio/arts_default.png",
                                            fit: BoxFit
                                                .fill,
                                          ),
                                        )
                                            : Padding(
                                            padding:
                                            const EdgeInsets.fromLTRB(
                                                3.0,
                                                0,
                                                3,
                                                0),
                                            child: isImageOrVideo(
                                                _mAcoomplismentDataModel
                                                    .accomplimentData[index1]
                                                    .achievement[index]
                                                    .fileList[
                                                size -
                                                    1],
                                                160.0,
                                                _mAcoomplismentDataModel
                                                    .accomplimentData[index1]
                                                    .level1))
                                            :   Column(
                                          children: [
                                              Row(
                                              children: [
                                                  Expanded(
                                                  child: isImageOrVideo(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .achievement[index]
                                                          .fileList[size -
                                                          1],
                                                      80.0,
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .level1),
                                                  flex: 1,
                                                ),
                                                  Expanded(
                                                  child: isImageOrVideo(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .achievement[index]
                                                          .fileList[size -
                                                          2],
                                                      80.0,
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .level1),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                              Row(
                                              children: [
                                                  Expanded(
                                                  child: isImageOrVideo(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .achievement[index]
                                                          .fileList[size -
                                                          3],
                                                      80.0,
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .level1),
                                                  flex: 1,
                                                ),
                                                  Expanded(
                                                  child: isImageOrVideo(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .achievement[index]
                                                          .fileList[size -
                                                          4],
                                                      80.0,
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .level1),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                          Container(
                                          height: 165.0,
                                          width:
                                          double.infinity,
                                          child:
                                            Image.asset(
                                            "assets/portfolio/bg.png",
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                          Positioned(
                                          right: 13.0,
                                          top: 52.0,
                                          left: 0.0,
                                          child:   Row(
                                            children: [
                                                Expanded(
                                                child: Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      13.0,
                                                      0,
                                                      0,
                                                      0),
                                                  child:
                                                    Container(
                                                    width: 60.0,
                                                    height:
                                                    60.0,
                                                    child:
                                                      Stack(
                                                      children: <
                                                          Widget>[
                                                          Center(
                                                            child:
                                                              Container(
                                                              child:   ClipOval(
                                                                  child:   CachedNetworkImage(
                                                                    imageUrl:
                                                                    Constant
                                                                        .IMAGE_PATH +
                                                                        _mAcoomplismentDataModel
                                                                            .accomplimentData[index1]
                                                                            .achievement[index]
                                                                            .userImage,
                                                                    fit:
                                                                    BoxFit
                                                                        .cover,
                                                                    placeholder: (
                                                                        context,
                                                                        url) =>
                                                                        _loader(
                                                                            context,
                                                                            "assets/profile/user_on_user.png"),
                                                                    errorWidget: (
                                                                        context,
                                                                        url,
                                                                        error) =>
                                                                        _error(
                                                                            "assets/profile/user_on_user.png"),
                                                                  )),
                                                              width:
                                                              60.0,
                                                              height:
                                                              60.0,
                                                              padding:   EdgeInsets
                                                                  .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                            )),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                                Expanded(
                                                child: Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      13.0,
                                                      0,
                                                      13,
                                                      0),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: [
                                                        Text(
                                                          _mAcoomplismentDataModel
                                                              .accomplimentData[
                                                          index1]
                                                              .achievement[
                                                          index]
                                                              .title,
                                                          style:   TextStyle(
                                                              fontSize: 18.0,
                                                              color: Colors
                                                                  .white,
                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                        Text(
                                                          _mAcoomplismentDataModel
                                                              .accomplimentData[index1]
                                                              .achievement[index]
                                                              .city +
                                                              ", " +
                                                              _mAcoomplismentDataModel
                                                                  .accomplimentData[index1]
                                                                  .achievement[index]
                                                                  .state,
                                                          style:   TextStyle(
                                                              fontSize: 14.0,
                                                              color: Colors
                                                                  .white,
                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                    ],
                                                  ),
                                                ),
                                                flex: 1,
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                      InkWell(
                                        child:   Container(
                                            height: 40.0,
                                            color: _mAcoomplismentDataModel
                                                .accomplimentData[
                                            index1]
                                                .level1 ==
                                                "Sports"
                                                ?   Color(
                                                0xffFDC675)
                                                :   Color(
                                                0xff41BEC2),
                                            child: Center(
                                                child:   Text(
                                                  _mAcoomplismentDataModel
                                                      .accomplimentData[
                                                  index1]
                                                      .level1 ==
                                                      "Sports"
                                                      ? "View Sports Portfolio"
                                                      : "View Arts Portfolio",
                                                  style:   TextStyle(
                                                      fontSize:
                                                      14.0,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMBOLD,
                                                      color: Colors
                                                          .white),
                                                  textAlign:
                                                  TextAlign
                                                      .center,
                                                ))),
                                        onTap: () {
                                          Achievement _mData =
                                          _mAcoomplismentDataModel
                                              .accomplimentData[
                                          index1]
                                              .achievement[index];

                                          List<Stats>
                                          statsList =
                                            List();
                                          _mData.stats
                                              .forEach((v) {
                                            statsList.add(new Stats
                                                .fromJson(
                                                v.toJson()));
                                          });

                                          List<Team> teamList =
                                            List();
                                          _mData.team
                                              .forEach((v) {
                                            teamList.add(new Team
                                                .fromJson(
                                                v.toJson()));
                                          });

                                          List<ExternalLinks>
                                          externalLinks =
                                            List();
                                          _mData.externalLinks
                                              .forEach((v) {
                                            externalLinks.add(
                                                  ExternalLinks
                                                    .fromJson(
                                                    v.toJson()));
                                          });

                                          Achivment _mAchivment = Achivment(
                                              _mData.sId,
                                              _mData.achievementId
                                                  .toString(),
                                              _mData.competencyTypeId
                                                  .toString(),
                                              _mData
                                                  .level2Competency,
                                              _mData
                                                  .level3Competency,
                                              _mData.userId
                                                  .toString(),
                                              _mData.title,
                                              _mData
                                                  .description,
                                              _mData.fromDate
                                                  .toString(),
                                              _mData.toDate
                                                  .toString(),
                                              _mData.isActive
                                                  .toString(),
                                              _mData.importance
                                                  .toString(),
                                              _mData.skills
                                                  .toString(),
                                              _mData.guide
                                                  .promptRecommendation
                                                  .toString(),
                                              null,
                                              null,
                                              null,
                                              null,
                                              null,
                                              null,
                                              null,
                                              null,
                                              _mData.guide
                                                  .firstName,
                                              _mData.guide
                                                  .lastName,
                                              _mData
                                                  .guide.email,
                                              _mData
                                                  .guide.title,
                                              _mData.guide
                                                  .recommenderTitle,
                                              _mData.isShowMore,
                                              null,
                                              "",
                                              _mData
                                                  .hoursWorkedPerWeek,
                                              _mData.height,
                                              _mData.weight,
                                              _mData
                                                  .createdTimestamp
                                                  .toString(),
                                              _mData.parentId
                                                  .toString(),
                                              _mData
                                                  .personalStatement,
                                              _mData.city,
                                              _mData.state,
                                              _mData.age,
                                              _mData.type,
                                              _mData.userImage,
                                              statsList,
                                              teamList,
                                              externalLinks,
                                              _mData
                                                  .portFolioAssestList,
                                              null,
                                              _mData.level2Icon,
                                                RecommendationsDataNar
                                                  .fromJson(
                                                  _mData
                                                      .recommendations
                                                      .toJson()),
                                              null,
                                              _mData.focusArea,_mData.personalReflection,_mData.isShowMorePersonalRef,_mData.isShowPersonalReflection);

                                          Navigator.of(context).push(
                                                MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                    PortfolioViewWidget(
                                                      _mAchivment,
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[
                                                      index1]
                                                          .level1)));
                                        }),
                                  ],
                                ))),
                        _mAcoomplismentDataModel
                            .accomplimentData[index1]
                            .achievement
                            .length >
                            1
                            ? index == 1 &&
                            _mAcoomplismentDataModel
                                .accomplimentData[
                            index1]
                                .achievement
                                .length ==
                                2
                            ?   Container(
                          height: 0.0,
                        )
                            : PaddingWrap.paddingfromLTRB(
                            0.0,
                            10.0,
                            0.0,
                            0.0,
                              Container(
                              height: 1.0,
                              color:
                                ColorValues.GREY__COLOR_DIVIDER,
                            ))
                            :   Container(
                          height: 0.0,
                        )
                      ],
                    ),
                    onTap: () {},
                  )
                ],
              )
                  :   Column(
                children: <Widget>[
                    InkWell(
                    child:   Column(
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            10.0,
                            0.0,
                            0.0,
                            //
                            _mAcoomplismentDataModel
                                .accomplimentData[
                            index1]
                                .achievement[index]
                                .mediaList
                                .length >
                                0
                                ?   SizedBox(
                              // Pager view
                                height: 215.50,
                                child:
                                PageIndicatorContainer(
                                  pageView:
                                    PageView.builder(
                                    itemCount:
                                    _mAcoomplismentDataModel
                                        .accomplimentData[
                                    index1]
                                        .achievement[
                                    index]
                                        .mediaList
                                        .length,
                                    controller:
                                      PageController(),
                                    itemBuilder:
                                        (context, index2) {
                                      return   InkWell(
                                        child:   Stack(
                                            children: <
                                                Widget>[
                                              /*      Container(
                                                                      height:
                                                                          215.50,
                                                                      child:
                                                                            CachedNetworkImage(
                                                                        width: double
                                                                            .infinity,
                                                                        height:
                                                                            215.50,
                                                                        imageUrl:
                                                                            Constant.IMAGE_PATH +
                                                                                _mAcoomplismentDataModel.accomplimentData[index1].achievement[index].mediaList[index2].file,
                                                                        fit: BoxFit
                                                                            .fill,
                                                                        placeholder: (context, url) => _loader(
                                                                            context,
                                                                            "assets/aerial/default_img.png"),
                                                                        errorWidget: (context,
                                                                                url,
                                                                                error) =>
                                                                            _error("assets/aerial/default_img.png"),
                                                                      )),*/

                                              _mAcoomplismentDataModel
                                                  .accomplimentData[
                                              index1]
                                                  .achievement[
                                              index]
                                                  .mediaList[
                                              index2]
                                                  .type ==
                                                  "image"
                                                  ? Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color:
                                                    Colors.black,
                                                  ),
                                                  child:
                                                    CachedNetworkImage(
                                                    width:
                                                    double.infinity,
                                                    height:
                                                    215.50,
                                                    imageUrl:
                                                    Constant.IMAGE_PATH +
                                                        _mAcoomplismentDataModel
                                                            .accomplimentData[index1]
                                                            .achievement[index]
                                                            .mediaList[index2]
                                                            .file,
                                                    //fit: BoxFit.contain,
                                                    fit:
                                                    BoxFit.fitHeight,
                                                    placeholder: (context,
                                                        url) =>
                                                        _loader(context,
                                                            "assets/aerial/default_img.png"),
                                                    errorWidget: (context, url,
                                                        error) =>
                                                        _error(
                                                            "assets/aerial/default_img.png"),
                                                  ))
                                                  :   Container(
                                                  decoration:
                                                  BoxDecoration(
                                                    color:
                                                    Colors.black,
                                                    borderRadius:
                                                    BorderRadius.circular(0),
                                                  ),
                                                  height:
                                                  215.50,
                                                  child:
                                                    Center(
                                                    child:   VideoPlayPauseNew(
                                                        _mAcoomplismentDataModel
                                                            .accomplimentData[index1]
                                                            .achievement[index]
                                                            .mediaList[index2]
                                                            .file,
                                                        "",
                                                        true,
                                                        _scrollController),
                                                    /*new Container(
                                                                                  child:   Stack(
                                                                                    children: <Widget>[

                                                                                      Container(
                                                                                        height: 215.50,
                                                                                        color: Colors.black,
                                                                                        margin: EdgeInsets.only(left: 0, right: 0),
                                                                                        child: */ /*new VideoViewBlack(
                                                                                            Constant.IMAGE_PATH + _mAcoomplismentDataModel.accomplimentData[index1].achievement[index].mediaList[index2].file, "", false, ""),*/ /*

                                                                                          Container(
                                                                                          width: 140.0,
                                                                                          height: 80.0,
                                                                                          color: Colors.black,
                                                                                          child: FutureBuilder(
                                                                                              future: getVideoThumb(
                                                                                                  _mAcoomplismentDataModel.accomplimentData[index1].achievement[index].mediaList[index2].file,index),
                                                                                              builder: (BuildContext context,
                                                                                                  AsyncSnapshot<Image> image) {
                                                                                                if (image.hasData) {
                                                                                                  return   Container(
                                                                                                      height: 215.50,
                                                                                                      child: image
                                                                                                          .data); // image is ready
                                                                                                } else {
                                                                                                  return   CachedNetworkImage(
                                                                                                    height: 215.50,
                                                                                                    imageUrl: "",
                                                                                                    fit: BoxFit.fitHeight,
                                                                                                    placeholder: (context,
                                                                                                        url) =>
                                                                                                        _loader(context,
                                                                                                            "assets/aerial/default_img.png"),
                                                                                                    errorWidget: (context, url,
                                                                                                        error) =>
                                                                                                        _error(
                                                                                                            "assets/aerial/default_img.png"),
                                                                                                  ); // placeholder
                                                                                                }
                                                                                              }),
                                                                                        )
                                                                                      ),

                                                                                        Center(
                                                                                          child:   Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                                                            children: <Widget>[
                                                                                                InkWell(
                                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                                    0.0,
                                                                                                    0.0,
                                                                                                    0.0,
                                                                                                    0.0,
                                                                                                      Image.asset(
                                                                                                      //'assets/pre_login/video_play_button.png',
                                                                                                      'assets/newDesignIcon/circle_play.png',
                                                                                                      width: 50.0,
                                                                                                      height: 50.0,
                                                                                                    )),
                                                                                              )
                                                                                            ],
                                                                                          )),
                                                                                    ],
                                                                                  )),*/
                                                  )),
                                              _mAcoomplismentDataModel
                                                  .accomplimentData[index1]
                                                  .achievement[index].mediaList
                                                  .length ==
                                                  1 ||
                                                  _mAcoomplismentDataModel
                                                      .accomplimentData[index1]
                                                      .achievement[index]
                                                      .mediaList[index2].type ==
                                                      "video"
                                                  ?   Container(
                                                height:
                                                0.0,
                                              )
                                                  :   InkWell(
                                                  onTap:
                                                      () {
                                                    Navigator.of(context).push(
                                                          MaterialPageRoute(
                                                            builder: (
                                                                BuildContext context) =>
                                                              CommonFullViewWidget(
                                                                _mAcoomplismentDataModel
                                                                    .accomplimentData[index1]
                                                                    .achievement[index]
                                                                    .mediaList,
                                                                MessageConstant
                                                                    .ACCOMPLISHMENT_HEDING,
                                                                index2,
                                                                _mAcoomplismentDataModel
                                                                    .accomplimentData[index1]
                                                                    .achievement[index]
                                                                    .title)));
                                                  },
                                                  child:
                                                    Container(
                                                    height:
                                                    215.50,
                                                    width:
                                                    double.infinity,
                                                    child:
                                                      Image.asset(
                                                      "assets/newDesignIcon/navigation/layer_image.png",
                                                      fit: BoxFit.fill,
                                                    ),
                                                  ))
                                            ]),
                                        onTap: () {
                                          Navigator.of(context).push(
                                                MaterialPageRoute(
                                                  builder: (
                                                      BuildContext context) =>
                                                    CommonFullViewWidget(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[
                                                      index1]
                                                          .achievement[
                                                      index]
                                                          .mediaList,
                                                      MessageConstant
                                                          .ACCOMPLISHMENT_HEDING,
                                                      index2,
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[
                                                      index1]
                                                          .achievement[
                                                      index]
                                                          .title)));
                                        },
                                      );
                                    },
                                    onPageChanged:
                                        (index) {},
                                  ),
                                  align:
                                  IndicatorAlign.bottom,
                                  length:
                                  _mAcoomplismentDataModel
                                      .accomplimentData[
                                  index1]
                                      .achievement[
                                  index]
                                      .mediaList
                                      .length,
                                  indicatorSpace: 10.0,
                                  indicatorColor:
                                  _mAcoomplismentDataModel
                                      .accomplimentData[
                                  index1]
                                      .achievement[
                                  index]
                                      .asset
                                      .length ==
                                      1
                                      ? Colors
                                      .transparent
                                      :   Color(
                                      0xffc4c4c4),
                                  indicatorSelectorColor:
                                  _mAcoomplismentDataModel
                                      .accomplimentData[
                                  index1]
                                      .achievement[
                                  index]
                                      .mediaList
                                      .length ==
                                      1
                                      ? Colors
                                      .transparent
                                      :   Color(
                                      0XFFFFFFFF),
                                  shape:
                                  IndicatorShape.circle(
                                      size: 5.0),
                                ))
                                :   Stack(children: <Widget>[
                                Image.asset(
                                "assets/profile/default_achievement.png",
                                fit: BoxFit.cover,
                                height: 215.50,
                                width: double.infinity,
                              ),
                              /*   Container(
                                      height: 215.50,
                                      color: Colors.black54
                                          .withOpacity(.4),
                                    )*/
                            ])),
                        Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.start,
                          children: [
                            PaddingWrap.paddingfromLTRB(
                                17.0,
                                10.0,
                                17.0,
                                0.0,
                                  Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                      Row(
                                      children: <Widget>[
                                          Expanded(
                                          child: RichText(
                                            maxLines: 15,
                                            textAlign:
                                            TextAlign.start,
                                            text: TextSpan(
                                              text: _mAcoomplismentDataModel
                                                  .accomplimentData[
                                              index1]
                                                  .achievement[
                                              index]
                                                  .focusArea == null ||
                                                  _mAcoomplismentDataModel
                                                      .accomplimentData[
                                                  index1]
                                                      .achievement[
                                                  index]
                                                      .focusArea == "null" ||
                                                  _mAcoomplismentDataModel
                                                      .accomplimentData[
                                                  index1]
                                                      .achievement[
                                                  index]
                                                      .focusArea == ""
                                                  ?

                                              _mAcoomplismentDataModel
                                                  .accomplimentData[
                                              index1]
                                                  .achievement[
                                              index]
                                                  .level3Competency +
                                                  " | "
                                                  : _mAcoomplismentDataModel
                                                  .accomplimentData[
                                              index1]
                                                  .achievement[
                                              index]
                                                  .focusArea +
                                                  " | ",
                                              style:
                                                TextStyle(
                                                  color:
                                                    ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize:
                                                  16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              children: [
                                                  TextSpan(
                                                    text: _mAcoomplismentDataModel
                                                        .accomplimentData[
                                                    index1]
                                                        .achievement[
                                                    index]
                                                        .title,
                                                    style:   TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR)),
                                              ],
                                            ),
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ),
                                      Row(
                                      children: <Widget>[
                                        PaddingWrap
                                            .paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            0.0,
                                            5.0,
                                              Text(
                                              getConvertedDateStamp2(
                                                  _mAcoomplismentDataModel
                                                      .accomplimentData[
                                                  index1]
                                                      .achievement[
                                                  index]
                                                      .fromDate
                                                      .toString()) +
                                                  " - " +
                                                  getConvertedDateStamp2(
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[
                                                      index1]
                                                          .achievement[
                                                      index]
                                                          .toDate
                                                          .toString()),
                                              textAlign:
                                              TextAlign
                                                  .left,
                                              maxLines:
                                              null,
                                              style:   TextStyle(
                                                  color:   Color(
                                                      0xFF404040),
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize:
                                                  14.0),
                                            )),
                                      ],
                                    ),
                                    _mAcoomplismentDataModel
                                        .accomplimentData[
                                    index1]
                                        .achievement[
                                    index]
                                        .hoursWorkedPerWeek !=
                                        null &&
                                        _mAcoomplismentDataModel
                                            .accomplimentData[
                                        index1]
                                            .achievement[
                                        index]
                                            .hoursWorkedPerWeek !=
                                            "null" &&
                                        _mAcoomplismentDataModel
                                            .accomplimentData[
                                        index1]
                                            .achievement[
                                        index]
                                            .hoursWorkedPerWeek
                                            .trim() !=
                                            ""
                                        ? PaddingWrap
                                        .paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        5.0,
                                          Text(
                                          "Hours Worked Per Week: " +
                                              _mAcoomplismentDataModel
                                                  .accomplimentData[
                                              index1]
                                                  .achievement[
                                              index]
                                                  .hoursWorkedPerWeek,
                                          textAlign:
                                          TextAlign
                                              .left,
                                          maxLines:
                                          null,
                                          style:   TextStyle(
                                              color:   Color(
                                                  0xFF404040),
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                              fontSize:
                                              14.0),
                                        ))
                                        :   Container(
                                      height: 0.0,
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        0.0,
                                        5.0,
                                          Text(
                                          _mAcoomplismentDataModel
                                              .accomplimentData[
                                          index1]
                                              .achievement[
                                          index]
                                              .description ==
                                              null
                                              ? ""
                                              : _mAcoomplismentDataModel
                                              .accomplimentData[
                                          index1]
                                              .achievement[
                                          index]
                                              .description,
                                          maxLines: _mAcoomplismentDataModel
                                              .accomplimentData[
                                          index1]
                                              .achievement[
                                          index]
                                              .isShowMore
                                              ? 25
                                              : 3,
                                          overflow: TextOverflow
                                              .ellipsis,
                                          textAlign:
                                          TextAlign.start,
                                          style:   TextStyle(
                                              color:   ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                      Row(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .start,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .start,
                                      children: <Widget>[
                                          Expanded(
                                          child: _mAcoomplismentDataModel
                                              .accomplimentData[
                                          index1]
                                              .achievement[
                                          index]
                                              .description ==
                                              null
                                              ?   Container(
                                            height: 0.0,
                                          )
                                              : _mAcoomplismentDataModel
                                              .accomplimentData[
                                          index1]
                                              .achievement[
                                          index]
                                              .description
                                              .length >
                                              130
                                              ?   InkWell(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                15.0,
                                                10.0,
                                                  Text(
                                                  _mAcoomplismentDataModel
                                                      .accomplimentData[index1]
                                                      .achievement[index]
                                                      .isShowMore
                                                      ? "Less"
                                                      : "More",
                                                  maxLines:
                                                  1,
                                                  overflow:
                                                  TextOverflow.ellipsis,
                                                  textAlign:
                                                  TextAlign.start,
                                                  style:   TextStyle(
                                                      color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 14.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap:
                                                () {
                                              if (_mAcoomplismentDataModel
                                                  .accomplimentData[index1]
                                                  .achievement[index]
                                                  .isShowMore)
                                                _mAcoomplismentDataModel
                                                    .accomplimentData[index1]
                                                    .achievement[index]
                                                    .isShowMore = false;
                                              else
                                                _mAcoomplismentDataModel
                                                    .accomplimentData[index1]
                                                    .achievement[index]
                                                    .isShowMore = true;
                                              setState(
                                                      () {
                                                    _mAcoomplismentDataModel
                                                        .accomplimentData[index1]
                                                        .achievement[index]
                                                        .isShowMore;
                                                  });
                                            },
                                          )
                                              :   Container(
                                            height:
                                            0.0,
                                          ),
                                          flex: 0,
                                        ),
                                      ],
                                    ),
                                    getgridBadges(
                                        index1, index),
                                  ],
                                )),
                            _mAcoomplismentDataModel
                                .accomplimentData[
                            index1]
                                .achievement[index]
                                .externalLinks ==
                                null
                                ?   Container(height: 0.0)
                                : _mAcoomplismentDataModel
                                .accomplimentData[
                            index1]
                                .achievement[
                            index]
                                .externalLinks
                                .length >
                                1 ||
                                (_mAcoomplismentDataModel
                                    .accomplimentData[
                                index1]
                                    .achievement[
                                index]
                                    .externalLinks
                                    .length ==
                                    1 &&
                                    _mAcoomplismentDataModel
                                        .accomplimentData[
                                    index1]
                                        .achievement[
                                    index]
                                        .externalLinks[
                                    0]
                                        .url
                                        .toString() !=
                                        "null" &&
                                    _mAcoomplismentDataModel
                                        .accomplimentData[
                                    index1]
                                        .achievement[
                                    index]
                                        .externalLinks[
                                    0]
                                        .url
                                        .toString() !=
                                        "")
                                ? Padding(
                              padding:
                              const EdgeInsets
                                  .fromLTRB(
                                  0.0, 0, 0, 13),
                              child:   Column(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .start,
                                children: [
                                 /* _mAcoomplismentDataModel
                                      .accomplimentData[
                                  index1]
                                      .achievement[
                                  index]
                                      .showExternalLinkText
                                      ?   Divider(
                                    color:   Color(
                                        ColorValues
                                            .BORDER_COLOR),
                                  )
                                      :   Container(
                                    width: 0.0,
                                    height: 0.0,
                                  ),*/
                                  PaddingWrap
                                      .paddingfromLTRB(
                                      17.0,
                                      0.0,
                                      17.0,
                                      0.0,
                                        Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .start,
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .start,
                                        children: [
                                          _mAcoomplismentDataModel
                                              .accomplimentData[index1]
                                              .achievement[index]
                                              .showExternalLinkText
                                              ?    Row(
                                            children: <Widget>[
                                                Expanded(
                                                child:   Image.asset(
                                                  "assets/ic_link.png",
                                                  width: 15.0,
                                                  height: 15.0,
                                                ),
                                                flex: 0,
                                              ),
                                                Expanded(child: PaddingWrap.paddingfromLTRB(7.0, 0.0, 5.0, 0.0, TextViewWrap.textView("EXTERNAL  LINKS", TextAlign.start,   ColorValues.HEADING_COLOR_EDUCATION, 12.0, FontWeight.w400)), flex: 0),
                                                Expanded(
                                                child: PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                      Container(
                                                      child: CustomViews.getSepratorLine(),
                                                    )),
                                                flex: 1,
                                              )
                                            ],
                                          )
                                              :   Container(
                                            width: 0.0,
                                            height: 0.0,
                                          ),
                                            Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: List.generate(
                                                _mAcoomplismentDataModel
                                                    .accomplimentData[index1]
                                                    .achievement[index]
                                                    .externalLinks.length,
                                                    (index2) {
                                                  return _mAcoomplismentDataModel
                                                      .accomplimentData[index1]
                                                      .achievement[index]
                                                      .externalLinks[index2]
                                                      .label.toString() !=
                                                      "null" &&
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .achievement[index]
                                                          .externalLinks[index2]
                                                          .label.toString() !=
                                                          ""
                                                      ?   Column(
                                                    crossAxisAlignment: CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment: MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      Padding(
                                                        padding: const EdgeInsets
                                                            .fromLTRB(
                                                            0.0, 10, 0, 0),
                                                        child:   InkWell(
                                                          onTap: () {
                                                            /*if (_mAcoomplismentDataModel.accomplimentData[index1].achievement[index].externalLinks[index2].url.toLowerCase().contains("http")) {
                                                                                              launch(_mAcoomplismentDataModel.accomplimentData[index1].achievement[index].externalLinks[index2].url);
                                                                                            } else {
                                                                                              String url = "http://" + _mAcoomplismentDataModel.accomplimentData[index1].achievement[index].externalLinks[index2].url;
                                                                                              launch(url);
                                                                                            }*/

                                                            //apurva added
                                                            if (_mAcoomplismentDataModel
                                                                .accomplimentData[index1]
                                                                .achievement[index]
                                                                .externalLinks[index2]
                                                                .url
                                                                .toLowerCase()
                                                                .contains(
                                                                "http")) {

                                                              launch(
                                                                  _mAcoomplismentDataModel
                                                                      .accomplimentData[index1]
                                                                      .achievement[index]
                                                                      .externalLinks[index2]
                                                                      .url
                                                                      .trim());
                                                            } else {
                                                              print(
                                                                  'apurva contain http');
                                                              launch(
                                                                 "http://" +  _mAcoomplismentDataModel
                                                                      .accomplimentData[index1]
                                                                      .achievement[index]
                                                                      .externalLinks[index2]
                                                                      .url
                                                                      .trim());
                                                            }
                                                          },
                                                          child:   Text(
                                                              _mAcoomplismentDataModel
                                                                  .accomplimentData[index1]
                                                                  .achievement[index]
                                                                  .externalLinks[index2]
                                                                  .label,
                                                              style:   TextStyle(
                                                                  fontSize: 14.0,
                                                                  color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                        ),
                                                      ),
                                                      _mAcoomplismentDataModel
                                                          .accomplimentData[index1]
                                                          .achievement[index]
                                                          .externalLinks[index2]
                                                          .description
                                                          .toString() ==
                                                          "null" ||
                                                          _mAcoomplismentDataModel
                                                              .accomplimentData[index1]
                                                              .achievement[index]
                                                              .externalLinks[index2]
                                                              .description
                                                              .toString() == ""
                                                          ?   Container(
                                                        height: 0.0,
                                                      )
                                                          : Padding(
                                                        padding: const EdgeInsets
                                                            .fromLTRB(
                                                            0.0, 5, 0, 0),
                                                        child:   Text(
                                                            _mAcoomplismentDataModel
                                                                .accomplimentData[index1]
                                                                .achievement[index]
                                                                .externalLinks[index2]
                                                                .description,
                                                            style:   TextStyle(
                                                                fontSize: 16.0,
                                                                color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                      ),
                                                    ],
                                                  )
                                                      :   Container(
                                                    height: 0.0,
                                                    width: 0.0,
                                                  );
                                                }),
                                          )
                                        ],
                                      ))
                                ],
                              ),
                            )
                                :   Container(
                              height: 0.0,
                            )
                          ],
                        ),
                        _mAcoomplismentDataModel
                            .accomplimentData[index1]
                            .achievement
                            .length >
                            1
                            ? index == 1 &&
                            _mAcoomplismentDataModel
                                .accomplimentData[
                            index1]
                                .achievement
                                .length ==
                                2
                            ?   Container(
                          height: 0.0,
                        )
                            : PaddingWrap.paddingfromLTRB(
                            0.0,
                            7.0,
                            0.0,
                            0.0,
                              Container(
                              height: 1.0,
                              color:
                                ColorValues.GREY__COLOR_DIVIDER,
                            ))
                            :   Container(
                          height: 0.0,
                        )
                      ],
                    ),
                    onTap: () {},
                  )
                ],
              );
            })),
      ],
    )
        : PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        0.0,
          Container(
          height: 0.0,
        ));
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now =   DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter =   DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      //  var formatter =   DateFormat('MMM dd, yyyy');
      //return formatter.format(new DateTime.now());
      return "Ongoing";
    }
  }

  int getLenthOfName() {
    int lenght = 0;
    if (_mPublicProfileDataModel.result == null) {
      return 0;
    } else {
      if (_mPublicProfileDataModel.result.lastName == null ||
          _mPublicProfileDataModel.result.lastName == "" ||
          _mPublicProfileDataModel.result.lastName == "null") {
        lenght = 0;
      } else {
        lenght = _mPublicProfileDataModel.result.firstName.length +
            _mPublicProfileDataModel.result.lastName.length;
      }
    }

    return lenght;
  }

  void shareSelectionDialog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>
          WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:   SafeArea(
                child:   Scaffold(
                    backgroundColor: Colors.black38,
                    body:   Stack(
                      children: <Widget>[
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:   Container(
                              //height: 160.0,
                                height: 280.0,
                                color: Colors.transparent,
                                child:   Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                            Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:   Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(
                                                        13.0, 13, 13, 3),
                                                    child:   Text(
                                                      "Share Your Custom Profile",
                                                      textAlign:
                                                      TextAlign.start,
                                                      maxLines: 5,
                                                      style:   TextStyle(
                                                          color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ),
                                                  Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          13.0, 0, 13, 3),
                                                      child:   Text(
                                                        "Share your profile with others in your network.",
                                                        textAlign:
                                                        TextAlign.start,
                                                        maxLines: 5,
                                                        style:   TextStyle(
                                                            color:   ColorValues.GREY_TEXT_COLOR,
                                                            fontSize: 12.0,
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                      )),
                                                    InkWell(
                                                    child:   Container(
                                                        padding:   EdgeInsets
                                                            .fromLTRB(13.0,
                                                            13.0, 0.0, 13.0),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                          children: [
                                                              Expanded(
                                                              child: Padding(
                                                                padding:
                                                                const EdgeInsets
                                                                    .fromLTRB(
                                                                    0.0,
                                                                    0,
                                                                    15,
                                                                    0),
                                                                child:   Image
                                                                    .asset(
                                                                  "assets/newDesignIcon/userprofile/share_new.png",
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ),
                                                              ),
                                                              flex: 0,
                                                            ),
                                                              Expanded(
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                                  mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                                  children: [
                                                                      Text(
                                                                      "Share Via",
                                                                      textAlign:
                                                                      TextAlign
                                                                          .start,
                                                                      maxLines:
                                                                      5,
                                                                      style:   TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                          16.0,
                                                                          fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                      Text(
                                                                      "Pick an app to share your profile.",
                                                                      textAlign:
                                                                      TextAlign
                                                                          .start,
                                                                      maxLines:
                                                                      5,
                                                                      style:   TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .GREY_TEXT_COLOR,
                                                                          fontSize:
                                                                          14.0,
                                                                          fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                  ],
                                                                ),
                                                                flex: 1),
                                                          ],
                                                        )),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      String preLinkText = 'Hi,' +
                                                          "\n\n" +
                                                          'I am sharing my spikeview with you. Please take a look and let\'s connect.';
                                                      String postLinkText =
                                                          _mPublicProfileDataModel
                                                              .result.firstName;
                                                      String sharedText =
                                                          '$preLinkText \n\n' +
                                                              widget.link +
                                                              ' \n\n$postLinkText';
                                                      Util.shareViaOtherApp(
                                                          context,
                                                          sharedText,
                                                          'My spikeview Shared With You');
                                                    },
                                                  ),
                                                    Container(
                                                    color:   ColorValues.BORDER_COLOR,
                                                    height: 1.0,
                                                  ),
                                                    InkWell(
                                                    child: Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .fromLTRB(
                                                            13.0,
                                                            13,
                                                            0,
                                                            13),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                          children: [
                                                              Expanded(
                                                              child: Padding(
                                                                  padding:
                                                                  const EdgeInsets
                                                                      .fromLTRB(
                                                                      0.0,
                                                                      0,
                                                                      15,
                                                                      0),
                                                                  child:
                                                                    Image
                                                                      .asset(
                                                                    "assets/portfolio/copy.png",
                                                                    height:
                                                                    20.0,
                                                                    width: 20.0,
                                                                  )),
                                                              flex: 0,
                                                            ),
                                                              Expanded(
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                                  mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                                  children: [
                                                                      Text(
                                                                      "Copy to Clipboard",
                                                                      textAlign:
                                                                      TextAlign
                                                                          .start,
                                                                      maxLines:
                                                                      5,
                                                                      style:   TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .HEADING_COLOR_EDUCATION,
                                                                          fontSize:
                                                                          16.0,
                                                                          fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                      Text(
                                                                      "Copy your profile link to share.",
                                                                      textAlign:
                                                                      TextAlign
                                                                          .start,
                                                                      maxLines:
                                                                      5,
                                                                      style:   TextStyle(
                                                                          color:
                                                                              ColorValues
                                                                                  .GREY_TEXT_COLOR,
                                                                          fontSize:
                                                                          14.0,
                                                                          fontFamily:
                                                                          Constant.TYPE_CUSTOMREGULAR),
                                                                    ),
                                                                  ],
                                                                ),
                                                                flex: 1),
                                                          ],
                                                        )),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      //apiCallForShare("Message");

                                                      String sharedText =
                                                          widget.link;
                                                      Util.copyToClipboardText(
                                                          sharedText, context);
                                                      //Util.copyToClipboardText('Lalla',context);
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                          Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:   Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                  Container(
                                    color: Colors.white,
                                    padding:   EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:   Row(
                                      children: <Widget>[
                                          Expanded(
                                          child:   InkWell(
                                            child:   Container(
                                                child:   Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:   TextStyle(
                                                      color:    ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 20.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void getShowExternalLinks(List<AccomplimentData> narrativeList) {
    if (narrativeList != null && narrativeList.length > 0) {
      for (var item in narrativeList) {
        //[index1].achivmentList[index].externalLinksList
        for (var ach in item.achievement) {
          for (var link in ach.externalLinks) {
            if (link.url.toString().trim() != '' &&
                link.url.toString().trim() != 'null') {
              setState(() {
                ach.showExternalLinkText = true;
              });
              break;
            }
          }
        }
      }
      setState(() {});
    }
  }
}
