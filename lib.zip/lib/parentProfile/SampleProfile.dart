import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class SampleProfile extends StatefulWidget {
  @override
  SampleProfileState createState() {
    return  SampleProfileState();
  }
}

class SampleProfileState extends State<SampleProfile> {
  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child:  Scaffold(
                body:  Stack(
              children: <Widget>[
                 Positioned(
                    top: 0.0,
                    bottom: 0.0,
                    left: 0.0,
                    right: 0.0,
                    child:  SingleChildScrollView(
                        child:  Column(
                      children: <Widget>[
                         Image.asset(
                            "assets/profile/parent/sample_profile.png"),
                      ],
                    ))),
                 Positioned(
                    right: 0.0,
                    top: 35.0,
                    child:  InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          10.0,
                          0.0,
                           Image.asset(
                            "assets/newDesignIcon/navigation/cancle_circle_white.png",
                            height: 30.0,
                            width: 30.0,
                          )),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ))
              ],
            ))));
  }
}
