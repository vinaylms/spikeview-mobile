// Updated COde

import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/MaskedTextInputFormatter.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/new_onboarding/All_education_list_model.dart';
import 'package:spike_view_project/new_onboarding/calendar_list.dart';
import 'package:spike_view_project/new_onboarding/onboarding_education_added_list.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/profile/UpdateUserProfile.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:http/http.dart' as http;
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/gateway/ReferalCodeResponse.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

import 'MobileNumberVerification.dart';

class ParentAddData extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  String pageName;

  ParentAddData(this.profileInfoModal, this.pageName);

  @override
  ParentDataState createState() => ParentDataState();
}

class ParentDataState extends State<ParentAddData> {
  int groupValue = 0;
  SharedPreferences prefs;
  String userIdPref, token;

  final _formKey = GlobalKey<FormState>();

  static StreamController syncDoneController = StreamController.broadcast();
  TextEditingController firstNameController = TextEditingController(),
      lastNameController = TextEditingController(),
      mobileController = TextEditingController(),
      dobController = TextEditingController(),
      add1Controller = TextEditingController(),
      add2Controller = TextEditingController(),
      cityController = TextEditingController(),
      stateController = TextEditingController(),
      zipController = TextEditingController(),
      countryController = TextEditingController(),
      firstNameParentController = TextEditingController(),
      lastNameParentController = TextEditingController(),
      emailParentController = TextEditingController();
  String selectedCountryCode = '';

  bool isActiveDobSelecter = false;
  int strDateOfBirth;
  String zipCodePrevious = "";
  String strFirstName = "",
      strTitle = "",
      strMobile,
      strLastName = "",
      strEmmail,
      strAdd1,
      strAdd2,
      strCity,
      strState,
      strZipcode,
      strCountry,
      strTagline,
      strAddEmail;
  FocusNode myFocusNode;
  ScrollController _controller = ScrollController();
  bool isParent = false;
  FocusNode mobileFocusNode = FocusNode();
  int diffrenceInDob = 14;

  DateTime pickedDate;
  bool isValid = true;
  bool isGenderSelected = true;

  bool isApiCalling = false;

  bool isZipCodeChange = false;

  bool isAddSecondaryEmail = false;
  String email = '';
  String profileImagePath = "";
  AllEducationListModel allEducationList;

  onTapSignOut() async {
    // setState(() {
    Constant.isAlreadyLoggedIn = false;
    //});

    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });

    GlobalSocketConnection.socket.emit("disconnect2", []);

    prefs.setString(UserPreference.NAME, "");
    prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    bloc.resetData(prefs);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }

  Future apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
        };

        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "PartnerDashboard", context);
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    email = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);

    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";
    ApiGetAllEducationList();
  }

  List<String> genderList = [
    "NA",
    "Non-Binary",
    "Female",
    "Male",
  ].toList();
  String gender;

  String strCountryName = "", strPrefixPathOrganization = '';
  bool isStudentCountrySelected = true;
  CountryList _mCountryItem;
  List<Item> countries = List();
  Item selectedCityItem;
  bool isShowStudentCitySelectionError = true;
  bool showList = false;
  bool educationIsAdded = false;
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');

  Future apiCallingForParent() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "roleId": 2,
          "firstName": firstNameParentController.text,
          "lastName": lastNameParentController.text,
          "email": emailParentController.text,
          "studentId": userIdPref,
          "signupType": "spikeview",
          "platformType": "mobile",
          "requestedFrom": "onboarding"
        };

        print("map:-" + map.toString());
        response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_PARENT_ADD, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              if (educationIsAdded) {
                String result = await Navigator.of(context)
                    .pushReplacement(new MaterialPageRoute(
                        builder: (BuildContext context) => EducationAddedWeight(
                              mProfileInfoModal: widget.profileInfoModal,
                              screenName: "onBoarding",
                            )));
                if (result == "push") {}
              } else {
                DateTime date = DateTime.fromMillisecondsSinceEpoch(
                    int.tryParse(widget.profileInfoModal.dob));
                int endYar = DateTime.now().year + 10;
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) => AddEducationWeight(
                          profileInfoModal: widget.profileInfoModal,
                          startYear: date.year,
                          endYear: endYar,
                        )));
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddParent", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future ApiGetAllEducationList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall4(
            context,
            Constant.ENDPOINT_GET_ALLEDUCATION_LIST + '?userId=' + userIdPref,
            "get" /*context, Constant.ENDPOINT_ORGANIZATION_LIST, map*/);
        MessageConstant.printWrapped("data++++++searchText===" +
            Constant.ENDPOINT_GET_ALLEDUCATION_LIST +
            '?userId=' +
            userIdPref);

        final String jsonString = jsonEncode(response.data);
        MessageConstant.printWrapped("data++++++searchText===" + jsonString);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              allEducationList = AllEducationListModel.fromJson(response.data);
              int primaryLengh =
                  allEducationList.result.primaryEducation.length;
              int middleLengh = allEducationList.result.middleEducation.length;
              int highLengh = allEducationList.result.highEducation.length;
              int collageLengh =
                  allEducationList.result.collegeEducation.length;

              if (primaryLengh == 0 &&
                  middleLengh == 0 &&
                  highLengh == 0 &&
                  collageLengh == 0) {
                setState(() {
                  educationIsAdded = false;
                });
              } else {
                setState(() {
                  educationIsAdded = true;
                });
              }
            } else {}
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  @override
  void initState() {
    myFocusNode = FocusNode();

    getSharedPreferences();
    super.initState();
  }

  bool allFieldCompletedParent = false;

  checkAllFieldSubmittedParent() {
    if (ValidationWidget.isName(firstNameParentController.text) &&
        ValidationWidget.isName(lastNameParentController.text) &&
        ValidationWidget.isEmail(emailParentController.text)) {
      allFieldCompletedParent = true;
      setState(() {});
    } else {
      allFieldCompletedParent = false;
      setState(() {});
    }
  }

  final homeScaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final firnameUiParent = CustomFormField(
        // maxLength: 35,
        onSaved: (val) => strFirstName = val,
        maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
        controller: firstNameParentController,
        label: "First name",
        onType: (v) {
          checkAllFieldSubmittedParent();
        },
        validation: (val) => val.trim().length == 0
            ? MessageConstant.ENTER_FIRST_NAME_VAL
            : !ValidationWidget.isName(val)
                ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                : null);

    final lastNameuiParent = CustomFormField(
        // maxLength: 35,
        onSaved: (val) => strLastName = val,
        controller: lastNameParentController,
        maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
        label: "Last name",
        onType: (v) {
          checkAllFieldSubmittedParent();
        },
        validation: (val) => val.trim().length == 0
            ? MessageConstant.ENTER_LAST_NAME_VAL
            : !ValidationWidget.isName(val)
                ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                : null);

    final emailUiParent = CustomFormField(
      // maxLength: 35,
      onSaved: (val) => strLastName = val,
      controller: emailParentController,
      label: "Email",
      onType: (v) {
        checkAllFieldSubmittedParent();
      },
      validation: (val) => val.trim().length == 0
          ? MessageConstant.ENTER_EMAIL_VAL
          : !ValidationWidget.isEmail(val)
              ? MessageConstant.VALID_EMAIL_VAL
              : null,
    );

    return WillPopScope(
        onWillPop: () {},
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                backgroundColor: Colors.white,
                key: homeScaffoldKey,
                body: FormKeyboardActions(
                    nextFocus: false,
                    keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                    //optional
                    keyboardBarColor: Colors.grey[200],
                    //optional
                    actions: [
                      KeyboardAction(
                        focusNode: mobileFocusNode,
                      ),
                    ],
                    child: SafeArea(
                      child: Container(
                          color: Colors.white,
                          child: Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              children: <Widget>[
                                Expanded(
                                  child: Form(
                                      /*  autovalidate: true,*/
                                      key: _formKey,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 10.0,
                                                            bottom: 0),
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: RichText(
                                                            maxLines: 1,
                                                            textAlign:
                                                                TextAlign.start,
                                                            text: TextSpan(
                                                              text:
                                                                  'Add parent details',
                                                              style: AppConstants
                                                                  .txtStyle
                                                                  .heading400LatoRegularDarkBlue
                                                                  .copyWith(
                                                                      fontSize:
                                                                          28,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w700),
                                                            ),
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        Expanded(
                                                          child: InkWell(
                                                            onTap: () {
                                                              apiCallForLogout();
                                                            },
                                                            child: Image.asset(
                                                              "assets/png/logout.png",
                                                              height: 32.0,
                                                              width: 32.0,
                                                            ),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 10.0),
                                                            child: const HelpButtonWidget(),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                      ],
                                                    )),
                                                Padding(
                                                  padding:
                                                      EdgeInsets.only(top: 11),
                                                  child: InkWell(
                                                    child: BaseText(
                                                      textAlign:
                                                          TextAlign.start,
                                                      text:
                                                          'You are under 13 so we will need your legal guardian information to complete the account set up.',
                                                      textColor: AppConstants
                                                          .colorStyle
                                                          .lightPurple,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoSemibold,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 18,
                                                    ),
                                                    onTap: () {},
                                                  ),
                                                ),
                                              ],
                                            ),
                                            flex: 0,
                                          ),
                                          Expanded(
                                            child: Container(
                                                child: Column(
                                              children: <Widget>[
                                                Expanded(
                                                  child: SingleChildScrollView(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            10.0,
                                                            Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        top:
                                                                            18.0),
                                                                    child:
                                                                        firnameUiParent,
                                                                  ),
                                                                  Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              18.0),
                                                                      child:
                                                                          lastNameuiParent),
                                                                  Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              18.0),
                                                                      child:
                                                                          emailUiParent),
                                                                ])),
                                                  ),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                  child: Container(
                                                      child: Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  top: 20.0),
                                                          child: Row(
                                                            children: <Widget>[
                                                              Expanded(
                                                                child:
                                                                    Container(
                                                                        height:
                                                                            44.0,
                                                                        width:
                                                                            112,
                                                                        child:
                                                                            FlatButton(
                                                                          onPressed:
                                                                              () async {
                                                                            if (widget.pageName ==
                                                                                "updateProfile") {
                                                                              Navigator.pop(context);
                                                                            } else {
                                                                              Navigator.of(context).popUntil((route) => route.isFirst);
                                                                              Navigator.of(context).pushReplacement(new MaterialPageRoute(builder: (BuildContext context) => UpdateUserProfile(widget.profileInfoModal, '')));
                                                                            }
                                                                          },
                                                                          shape: RoundedRectangleBorder(
                                                                              side: BorderSide(color: AppConstants.colorStyle.btnBg, width: 1, style: BorderStyle.solid),
                                                                              borderRadius: BorderRadius.circular(10)),
                                                                          child:
                                                                              Row(
                                                                            // Replace with a Row for horizontal icon + text
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            children: <Widget>[
                                                                              BaseText(
                                                                                textAlign: TextAlign.center,
                                                                                text: 'Back',
                                                                                textColor: AppConstants.colorStyle.lightPurple,
                                                                                fontFamily: AppConstants.stringConstant.latoRegular,
                                                                                fontWeight: FontWeight.w600,
                                                                                fontSize: 16,
                                                                              )
                                                                            ],
                                                                          ),
                                                                        )),
                                                                flex: 0,
                                                              ),
                                                              Expanded(
                                                                child: Padding(
                                                                  padding: const EdgeInsets
                                                                          .only(
                                                                      left:
                                                                          12.0),
                                                                  child: Stack(
                                                                    children: <
                                                                        Widget>[
                                                                      Container(
                                                                          height:
                                                                              44.0,
                                                                          width: double
                                                                              .infinity,
                                                                          child:
                                                                              FlatButton(
                                                                            onPressed:
                                                                                () async {
                                                                              apiCallingForParent();
                                                                            },
                                                                            shape:
                                                                                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                                                            color:
                                                                                AppConstants.colorStyle.lightBlue,
                                                                            child:
                                                                                Row(
                                                                              // Replace with a Row for horizontal icon + text
                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                              children: <Widget>[
                                                                                Text('Continue', style: AppConstants.txtStyle.heading18600LatoRegularWhite),
                                                                              ],
                                                                            ),
                                                                          )),
                                                                      allFieldCompletedParent
                                                                          ? SizedBox(
                                                                              height: 0,
                                                                            )
                                                                          : Container(
                                                                              height: 44.0,
                                                                              width: double.infinity,
                                                                              color: Colors.white.withOpacity(0.75),
                                                                            )
                                                                    ],
                                                                  ),
                                                                ),
                                                                flex: 1,
                                                              ),
                                                            ],
                                                          ))),
                                                  flex: 0,
                                                ),
                                              ],
                                            )),
                                            flex: 1,
                                          ),
                                        ],
                                      )),
                                  flex: 1,
                                )
                              ],
                            ),
                          )),
                    )))));
  }
}
