import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';

import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

// Create a Form Widget
class UpdateTestScorePerformance extends StatefulWidget {
  List<Scores> mainTestList;
  String sasToken, containerName, userId;
  final ProfileData studentprofile;

  UpdateTestScorePerformance(
    this.mainTestList,
    this.sasToken,
    this.containerName,
    this.userId, {
    this.studentprofile,
  });

  @override
  UpdateTestScoreState createState() {
    return UpdateTestScoreState(mainTestList, sasToken, containerName);
  }
}

class UpdateTestScoreState extends State<UpdateTestScorePerformance> {
  UpdateTestScoreState(this.localListMain, this.sasToken, this.containerName);

  static const platform = const MethodChannel('samples.flutter.io/battery');

  final formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, sasToken, containerName;
  List<Scores> mainTestList = List();
  List<Scores> localListMain = List();
  String strPrefixPathOrganization;
  File mediaImage, imagePath;
  DateTime startDate;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    String dob = widget.studentprofile != null
        ? widget.studentprofile.dob
        : prefs.getString(UserPreference.DOB);

    if (dob != null && dob != 'null' && dob != '') {
      int d = int.tryParse(dob);
      startDate = DateTime.fromMillisecondsSinceEpoch(d);
      setState(() {});
    } else {
      startDate = DateTime.now();
    }

    userIdPref = widget.userId;
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";

    callApiForSaas();
  }

  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_APP_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //=========================================================Api Calling =======================================

  @override
  void initState() {
    // TODO: implement initState
    try {
      mainTestList = localListMain;

      getSharedPreferences();
    } catch (e) {
      print(e.toString());
    }
    super.initState();
  }

  void showConfirmationAlert(userTestId) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to delete?',
            negativeText: 'Cancel',
            positiveText: 'Delete',
            isSucessPopup: false,
            positiveTextColor:ColorValues
                .circle4,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              deleteTest(userTestId);
            },
          );
        });


  }

  Future deleteTest(userTestId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "userTestId": userTestId,
        };
        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_DELETE_TEST_SCORE_DATA, map);

        print("response:-fetcProfile" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              print("response:- fetcProfile");
              bloc.fetcprofileData(userIdPref, context, prefs, true);
              Navigator.pop(context, true);
              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "userId": userIdPref,
          "testScores": mainTestList.map((item) => item.toJson2()).toList(),
        };

        print("map+++" + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_TEST_SCORE_DATA, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              print("suceess");
              bloc.fetcprofileData(userIdPref, context, prefs, true);
              Navigator.pop(context, true);
            } else {
              for (Scores model in mainTestList) {
                model.imageUrl.insert(0, null);
                model.docUrl.insert(0, null);
              }
              setState(() {});
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      for (Scores model in mainTestList) {
        model.imageUrl.insert(0, null);
        model.docUrl.insert(0, null);
      }
      setState(() {});
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    validateMethod(Subjects model, value) {
      if (value == '') {
        return "Please enter value between " +
            model.minScore.toString() +
            "-" +
            model.maxScore.toString();
      } else if (value >= int.parse(model.minScore) &&
          value <= int.parse(model.maxScore)) {
        return null;
      }

      return "Please enter value between " +
          model.minScore.toString() +
          "-" +
          model.maxScore.toString();
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
      @required Scores dataModel,
    }) async {
      setState(() {});

      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathOrganization);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        String path = strPrefixPathOrganization + strAzureImageUploadPath;
        if (type == "image") {
          // dataModel.imageUrl.removeLast();
          dataModel.imageUrl.add(path);
          // dataModel.imageUrl.add(null);
          setState(() {
            dataModel;
          });
        } else {
          //  dataModel.docUrl.removeLast();
          dataModel.docUrl.add(path);
          // dataModel.docUrl.add(null);
          setState(() {
            dataModel;
          });
        }
        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    onTapImageAddButton(Scores dataModel) async {
      mediaImage = await UploadMedia(context).pickImageFromGallery();

      //   mediaImage = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (mediaImage != null) {
        imagePath = mediaImage;
        //   await _cropImage(mediaImage);
        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer = Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                dataModel: dataModel,
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    getDocuments(Scores dataModel) async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );
          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if (path != null && path != "") {
            if ((Util.getFileExtension(path) == ".pdf" ||
                    Util.getFileExtension(path) == ".doc" ||
                    Util.getFileExtension(path) == ".docx") &&
                path != null) {
              print("path+++++" + path.toString());

              CustomProgressLoader.showLoader(context);
              Timer _timer = Timer(const Duration(milliseconds: 400), () {
                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    dataModel: dataModel,
                    type: "doc");
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.INVALID_FILE_FORMAT_VAL, context);
            }
          }
        } catch (e) {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    }

    void _checkValidation() async {
      print("checking");
      final form = formKey.currentState;
      form.save();
      if (form.validate()) {
        apiCalling();
      } else {
        print("not validate..");
      }
    }

    Padding gridSelectedDocument(List<String> docUrl) {
      return docUrl != null && docUrl.length > 0
          ? PaddingWrap.paddingfromLTRB(
              15.0,
              0.0,
              15.0,
              0.0,
              Container(
                  height: 80.0,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: List.generate(docUrl.length, (int index) {
                      return Padding(
                        padding: EdgeInsets.only(left: index == 0 ? 0 : 13.0),
                        child: Stack(
                          children: [
                            Container(
                                child: Container(
                              decoration: BoxDecoration(
                                  color: AppConstants.colorStyle.lightPurple,
                                  border: Border.all(
                                      color:
                                          ColorValues.LIGHT_GREY_TEXT_COLOR)),
                              width: 123,
                              height: 67,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/patner/pdf.png",
                                  height: 67,
                                ),
                              ),
                            )),
                            Positioned(
                              top: 20,
                              right: 50,
                              child: InkWell(
                                onTap: () {
                                  docUrl.removeAt(index);
                                  setState(() {});
                                },
                                child: Image.asset(
                                  "assets/generateScript/cross_close.png",
                                  height: 25.0,
                                  width: 25.0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              0.0,
              5.0,
              0.0,
              Container(
                height: 0.0,
              ));
    }

    Padding gridSelectedImagesVideos(List<String> imageUrl) {
      return imageUrl != null && imageUrl.length > 0
          ? PaddingWrap.paddingfromLTRB(
              15.0,
              0.0,
              15.0,
              0.0,
              Container(
                  height: 80.0,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: List.generate(imageUrl.length, (int index) {
                      return Padding(
                        padding: EdgeInsets.only(left: index == 0 ? 0 : 13.0),
                        child: Stack(
                          children: [
                            Container(
                              width: 123,
                              height: 67,
                              child: FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                placeholder: 'assets/aerial/default_img.png',
                                image: Constant.IMAGE_PATH + imageUrl[index],
                              ),
                            ),
                            Positioned(
                              top: 20,
                              right: 50,
                              child: InkWell(
                                onTap: () {
                                  imageUrl.removeAt(index);
                                  setState(() {});
                                },
                                child: Image.asset(
                                  "assets/generateScript/cross_close.png",
                                  height: 25.0,
                                  width: 25.0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              0.0,
              5.0,
              0.0,
              Container(
                height: 0.0,
              ));
    }

    mediaSection(List<String> imageUrl, Scores model) {
      return Column(
        children: [
          InkWell(
            onTap: () async {
              var status = await Permission.photos.status;
              if (status.isGranted) {
                onTapImageAddButton(model);
              } else {
                checkPermissionPhoto(context);
              }
            },
            child: Stack(
              alignment: Alignment.center,
              overflow: Overflow.visible,
              children: [
                Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 96,
                      child: Column(
                        children: [
                          const SizedBox(height: 18),
                          imageUrl.length == 0
                              ? Image.asset(
                                  "assets/generateScript/camera.png",
                                  height: 26.0,
                                  width: 25.0,
                                )
                              : SizedBox(),
                          const SizedBox(height: 5),
                          Text(
                            imageUrl.length == 0
                                ? 'Your uploaded photos will appear here'
                                : "",
                            maxLines: 1,
                            textAlign: TextAlign.center,
                            style: AppConstants
                                .txtStyle.heading14400LatoItalicLightPurple,
                          ),
                        ],
                      ),
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                            color:
                                AppConstants.colorStyle.borderGenerateScript),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10)),
                      ),
                    ),
                    SizedBox(
                      height: 12,
                    )
                  ],
                ),
                gridSelectedImagesVideos(imageUrl),
                Positioned(
                  bottom: 0,
                  child: InkWell(
                    radius: 50,
                    onTap: () async {
                      var status = await Permission.photos.status;
                      if (status.isGranted) {
                        onTapImageAddButton(model);
                      } else {
                        checkPermissionPhoto(context);
                      }
                    },
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 26.0,
                      width: 25.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    docSection(List<String> docUrl, Scores model) {
      return Column(
        children: [
          InkWell(
            onTap: () async {
              if (docUrl.length <= 5) {
                getDocuments(model);
              } else {
                ToastWrap.showToast(
                    MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
              }
            },
            child: Stack(
              alignment: Alignment.center,
              overflow: Overflow.visible,
              children: [
                Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: docUrl.length == 0 ? 100 : 96,
                      child: Column(
                        children: [
                          const SizedBox(height: 18),
                          docUrl.length == 0
                              ? Image.asset(
                                  "assets/generateScript/pdf.png",
                                  height: 26.0,
                                  width: 25.0,
                                )
                              : SizedBox(),
                          const SizedBox(height: 5),
                          Text(
                            docUrl.length == 0
                                ? 'Your uploaded documents (PDF only) will appear here  '
                                : "",
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            style: AppConstants
                                .txtStyle.heading14400LatoItalicLightPurple,
                          ),
                        ],
                      ),
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.tabBg,
                        border: Border.all(
                            color:
                                AppConstants.colorStyle.borderGenerateScript),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10)),
                      ),
                    ),
                    SizedBox(
                      height: 12,
                    )
                  ],
                ),
                gridSelectedDocument(docUrl),
                Positioned(
                  bottom: 0,
                  child: InkWell(
                    radius: 50,
                    onTap: () async {
                      if (docUrl.length <= 5) {
                        getDocuments(model);
                      } else {
                        ToastWrap.showToast(
                            MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                      }
                    },
                    child: Image.asset(
                      "assets/generateScript/plus_icon.png",
                      height: 26.0,
                      width: 25.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return GestureDetector(
      child: WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: GestureDetector(
          child: customAppbar(
            context,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Container(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 24, bottom: 5),
                      child: BaseText(
                        text: mainTestList[0].name,
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                        width: double.infinity,
                        child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Form(
                              key: formKey,
                              child: Container(
                                  child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Column(
                                      children: List.generate(
                                          mainTestList.length, (index3) {
                                    return Container(
                                        child: PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            0.0,
                                            30.0,
                                            Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[



                                                mainTestList[index3]
                                                            .subjects
                                                            .length ==
                                                        1
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 4.0,left: 20,right: 20,
                                                                bottom: 32),
                                                        child: BaseText(
                                                          text: mainTestList[
                                                                  index3]
                                                              .subjects[0]
                                                              .subject,
                                                          textColor:  AppConstants.colorStyle.lightPurple,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: 16,
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 1,
                                                        ),
                                                      )
                                                    : SizedBox(
                                                        height: 32,
                                                      ),
                                                PaddingWrap.paddingfromLTRB(
                                                    20.0,
                                                    0.0,
                                                    20.0,
                                                    0.0,
                                                    Container(
                                                      padding: EdgeInsets.only(
                                                          left: 0.0,
                                                          top: 5.0,
                                                          right: 0.0,
                                                          bottom: 0.0),
                                                      child: CustomFormField(
                                                          // maxLength: 35,

                                                          readOnly: true,
                                                          controller:
                                                              TextEditingController(
                                                                  text: mainTestList[
                                                                          index3]
                                                                      .dateTaken),
                                                          label: "Date taken",
                                                          onClick: () async {
                                                            DateTime
                                                                pickedDate1 =
                                                                await showDatePicker(
                                                              context: context,
                                                              initialDate:
                                                                  DateTime
                                                                      .now(),
                                                              //get today's date
                                                              firstDate:
                                                                  DateTime(
                                                                      1900),
                                                              //DateTime.now() - not to allow to choose before today.
                                                              lastDate: DateTime
                                                                  .now(),
                                                              confirmText:
                                                                  'Apply',
                                                              cancelText:
                                                                  'Cancel',
                                                            );
                                                            if (pickedDate1 !=
                                                                null) {
                                                              mainTestList[
                                                                          index3]
                                                                      .dateOrigionl =
                                                                  pickedDate1
                                                                      .millisecondsSinceEpoch
                                                                      .toString();
                                                              String date =
                                                                  Util.getDate(
                                                                      pickedDate1);
                                                              mainTestList[
                                                                          index3]
                                                                      .dateTaken =
                                                                  date;
                                                              setState(() {
                                                                mainTestList;
                                                              });
                                                            } else {
                                                              FocusScope.of(
                                                                      context)
                                                                  .requestFocus(
                                                                      new FocusNode());
                                                            }
                                                            // selectDob(context);
                                                          },
                                                          validation: (value) {
                                                            return value.length ==
                                                                    0
                                                                ? MessageConstant
                                                                    .SELECT_DATE_TAKEN_VAL
                                                                : null;
                                                          }),
                                                    )),
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Column(
                                                        children: List.generate(
                                                            mainTestList[index3]
                                                                .subjects
                                                                .length,
                                                            (index2) {
                                                      return Container(
                                                          child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 30.0,
                                                                    left: 20,right: 20,),
                                                              child:
                                                                  CustomFormField(
                                                                autovalidateMode:
                                                                    AutovalidateMode
                                                                        .disabled,
                                                                textInputType:
                                                                    TextInputType
                                                                        .number,
                                                                controller: mainTestList[
                                                                        index3]
                                                                    .subjects[
                                                                        index2]
                                                                    .textEditingController,
                                                                onType:
                                                                    (val) {},
                                                                inputFormatter: <
                                                                    TextInputFormatter>[
                                                                  WhitelistingTextInputFormatter
                                                                      .digitsOnly
                                                                ],
                                                                label: mainTestList[
                                                                            index3]
                                                                        .subjects[
                                                                            index2]
                                                                        .subject +
                                                                    " (" +
                                                                    mainTestList[
                                                                            index3]
                                                                        .subjects[
                                                                            index2]
                                                                        .minScore
                                                                        .toString() +
                                                                    "-" +
                                                                    mainTestList[
                                                                            index3]
                                                                        .subjects[
                                                                            index2]
                                                                        .maxScore
                                                                        .toString() +
                                                                    ")",
                                                                validation: (val) => mainTestList[index3]
                                                                            .subjects[
                                                                                index2]
                                                                            .isOptional &&
                                                                        (val == null ||
                                                                            val ==
                                                                                "")
                                                                    ? null
                                                                    : validateMethod(
                                                                        mainTestList[index3].subjects[
                                                                            index2],
                                                                        mainTestList[index3].subjects[index2].textEditingController != null &&
                                                                                mainTestList[index3].subjects[index2].textEditingController.text != ""
                                                                            ? int.parse(mainTestList[index3].subjects[index2].textEditingController.text)
                                                                            : ''),
                                                              ),
                                                            ),
                                                          ]));
                                                    })),
                                                  ],
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(left: 20,right: 20,
                                                          top: 24.0),
                                                  child: docSection(
                                                      mainTestList[index3]
                                                          .docUrl,
                                                      mainTestList[index3]),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          top: 24.0,left: 20,right: 20,
                                                          bottom: 30),
                                                  child: mediaSection(
                                                      mainTestList[index3]
                                                          .imageUrl,
                                                      mainTestList[index3]),
                                                ),
                                                InkWell(
                                                  child: Center(
                                                    child: BaseText(
                                                      text: 'Delete',
                                                      textColor:
                                                          ColorValues.circle4,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 16,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 1,
                                                    ),
                                                  ),
                                                  onTap: () {
                                                    showConfirmationAlert(
                                                        mainTestList[index3]
                                                            .userTestId);
                                                  },
                                                ),
                                                (mainTestList.length - 1) ==
                                                        index3
                                                    ? SizedBox()
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 20.0),
                                                        child: Container(
                                                          height: 1,
                                                          color: AppConstants
                                                              .colorStyle.btnBg,
                                                        ),
                                                      ),
                                              ],
                                            )));
                                  })),

                                  // CustomViews.getSepratorLine()
                                ],
                              ))),
                        )),
                  ),
                  flex: 1,
                ),
                Expanded(
                  child: Stack(
                    children: [
                      InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                          20.0,
                          20.0,
                          20.0,
                          20.0,
                          Container(
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppConstants.colorStyle.lightBlue,
                              border: Border.all(
                                  color: AppConstants.colorStyle.lightBlue),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Update",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.WHITE,
                                  fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                  fontSize: 16.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                        onTap: () async {
                          _checkValidation();
                        },
                      ),
                    ],
                  ),
                  flex: 0,
                )
              ],
            ),
            () {
              Navigator.pop(context);
            },
            isShowIcon: false,
          ),
        ),
      ),
    );
  }
}
