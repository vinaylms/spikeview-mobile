import 'package:flutter/material.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

enum FontType { Bold, Regular, Light,Italic }

class AppTextStyle {
  static const String _fontBold = Constant.TYPE_CUSTOMBOLD;
  static const String _fontRegular = Constant.TYPE_CUSTOMREGULAR;
  static const String _fontLight = "customLight";
  static const String _fontItalic = "customItalic";

  static String getFont(FontType fontType) {
    if (fontType == FontType.Bold) {
      return _fontBold;
    } else if (fontType == FontType.Regular) {
      return _fontRegular;
    } else if (fontType == FontType.Light) {
      return _fontLight;
    }else if (fontType == FontType.Italic) {
      return _fontItalic;
    }

    return _fontRegular;
  }



  static TextStyle getDynamicFontStyleNewDesign(
      Color color, double fontSize, FontType fontType) {
    return TextStyle(
      fontStyle: FontStyle.normal,
      color: color,
      fontSize: fontSize,
      fontWeight: fontType == FontType.Bold ? FontWeight.w700 : FontWeight.w400,
      fontFamily: getFont(fontType),
    );
  }

  static Widget getLableTextForDetail(String lableText, String value) {
    return  RichText(
      text:  TextSpan(
          text: '$lableText',
          style: AppTextStyle.getDynamicFont(
              ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType.Regular),
          children: [
            TextSpan(
              text: '$value',
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            )
          ]),
    );
  }
  static Widget getLableTextForDetailRow(String lableText, String value) {
    return  Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BaseText(
              text: '$lableText',
              textColor: ColorValues.labelColor,
              fontSize: 12.0,
              fontFamily: Constant.latoMedium,
              fontWeight: FontWeight.w400
          ),
          UIHelper.verticalSpaceSmall,

          BaseText(
              text: '$value',
              textColor: ColorValues.HEADING_COLOR_EDUCATION_1 ,
              fontSize: 14.0,
              fontFamily: Constant.latoMedium,
              fontWeight: FontWeight.w400
          )
        ]);
  }

  static Widget getBoldLableTextForDetail(String lableText, String value) {
    return  RichText(
      text:  TextSpan(
          text: '$lableText',
//style: underlineStyle.copyWith(decoration: TextDecoration.none),
          style: AppTextStyle.getDynamicFont(
              ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType.Bold),
          children: [
            TextSpan(
              text: '$value',
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            )
          ]),
    );
  }

  static Widget getLableTextForDetailNew(String lableText) {
    return  RichText(
      text:  TextSpan(
        text: '$lableText',
//style: underlineStyle.copyWith(decoration: TextDecoration.none),
        style: AppTextStyle.getDynamicFont(
            ColorValues.GREY__COLOR,
            14,
            FontType.Regular),
      ),
    );
  }

  static Widget getTextForDetail( String value) {
    return  RichText(
      text:  TextSpan(
        text: '$value',
//style: underlineStyle.copyWith(decoration: TextDecoration.none),
        style: AppTextStyle.getDynamicFont(
            ColorValues.HEADING_COLOR_EDUCATION,
            16,
            FontType.Regular),
      ),
    );
  }
  static TextStyle getDynamicFontStyle(
      Color color, double fontSize, FontType fontType) {
    return TextStyle(
      fontStyle: FontStyle.normal,
      color: color,
      fontSize: fontSize,
      fontWeight: fontType == FontType.Bold ? FontWeight.w700 : FontWeight.w400,
      fontFamily: getFont(fontType),
    );
  }

  static TextStyle getDynamicFonLatoFont(
      Color color, double fontSize, FontType fontType) {
    return TextStyle(
      fontStyle: FontStyle.normal,
      color: color,
      fontSize: fontSize,
      fontWeight: fontType == FontType.Bold ? FontWeight.w700 : FontWeight.w400,
      fontFamily: AppConstants.stringConstant.latoMedium,
    );
  }


  static TextStyle getDynamicFont(
      Color color, double fontSize, FontType fontType) {
    return TextStyle(
      fontStyle: FontStyle.normal,
      color: color,
      fontSize: fontSize,
      fontWeight: fontType == FontType.Bold ? FontWeight.w700 : FontWeight.w400,
      fontFamily: getFont(fontType),
    );
  }

  static TextStyle getDynamicFontStyleWithWeight( Color color,
      double fontSize, FontType fontType, FontWeight fontWeight) {
    return TextStyle(
      fontWeight: fontWeight,
      fontStyle: FontStyle.normal,
      color: color,
      fontSize: fontSize,
      fontFamily: getFont(fontType),
    );
  }

  static TextStyle getDynamicStyleAddPortfolia(
      Color color, double fontSize, FontType fontType) {
    return TextStyle(
      color: color,
      fontSize: fontSize,
      fontFamily: getFont(fontType),
    );
  }
  static TextStyle getDynamicStyleGroup(
      Color color, double fontSize, FontType fontType) {
    return TextStyle(
      fontStyle: FontStyle.normal,
      color: color,
      fontSize: fontSize,
      fontWeight:  FontWeight.normal,

      fontFamily: getFont(fontType),
    );
  }

  static TextStyle getDynamicStyleGroupHEIGHT(
      Color color, double fontSize, FontType fontType, double heightValue) {
    return TextStyle(
      fontStyle: FontStyle.normal,
      color: color,
      height: heightValue,
      fontSize: fontSize,
      fontWeight:  FontWeight.normal,
      fontFamily: getFont(fontType),
    );
  }


}
