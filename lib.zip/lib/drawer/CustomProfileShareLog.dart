import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomViewForUser.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ProfileLogDataModel.dart';
import 'package:spike_view_project/modal/ProfileShareLogModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class CustomProfileShareLog extends StatefulWidget {
  String userId, pageName;
  bool isParentCalling;

  CustomProfileShareLog(this.userId, this.isParentCalling, {this.pageName});

  @override
  CustomProfileShareLogState createState() => CustomProfileShareLogState();
}

class CustomProfileShareLogState extends State<CustomProfileShareLog> {
  bool selectActiveButton1 = false;
  bool selectActiveButton2 = true;
  String isPerformChanges = "pop", userIdPref, roleId, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;
  ProfileInfoModal profileInfoModal;
  bool isLoading = false;
  bool isCoomunitySetting = true;
  bool isPreLoginSetting = true;

  List<ProfileShareModel> profileShareLogLIst = List();

  ProfileLogDataModel _mProfileLogDataModel;

  onBack() async {
    if (widget.pageName != null && widget.pageName == "main") {
      if (widget.isParentCalling) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context, isPerformChanges);
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = "1";

    isHide = prefs.getString(UserPreference.ISHide);
    if (widget.userId != null &&
        widget.userId != "null" &&
        widget.userId != "") {
      userIdPref = widget.userId;
    }
    setState(() {
      isLoading = true;
    });
    getData(true);

    if (profileInfoModal != null) dob = profileInfoModal.dob;

    setState(() {
      isLoading = false;
    });
    setState(() {});
  }

  Future apiCallingForUpdateStudentHideStatus(isHideBool) async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "isHide": isHideBool,
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setString(UserPreference.ISHide, isHideBool);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForGetShareLog() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        print(
            'Log Api URL:: ${Constant.ENDPOINT_SHARE_LOG + widget.userId + "&roleId=" + roleId}');
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_SHARE_LOG + widget.userId + "&roleId=" + roleId,
            "get");

        isLoading = false;
        setState(() {
          isLoading;
        });

        print(Constant.ENDPOINT_SHARE_LOG + widget.userId);
        print("LOg Api response profile+++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileShareLogLIst.clear();
              profileShareLogLIst =
                  ParseJson.parseMapShareLog(response.data['result']);
              if (profileShareLogLIst.length > 0) {
                setState(() {
                  profileShareLogLIst;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  //--------------------------Api Calling for update user Status ------------------
  Future apiCallingForUpdateStudentStatus(index) async {
    try {
      print(
          'inside apiCallingForUpdateStudentStatus isActive:: ${_mProfileLogDataModel.result[index].isActive}');
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "sharedId": int.parse(profileShareLogLIst[index].sharedId),
          "isActive": profileShareLogLIst[index].isActive
        };

        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_SHARE_UPDATE, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg+profileShareLogLIst[index].isActive.toString());
              setState(() {
                profileShareLogLIst[index].isActive = "false";
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForUpdateURl(index) async {
    print(
        'inside apiCallingForUpdateURl isActive:: ${_mProfileLogDataModel.result[index].isActive}');
    print(
        'inside apiCallingForUpdateURl customProfileLink:: ${_mProfileLogDataModel.result[index].customProfileLink}');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String profileId = "";
        if (_mProfileLogDataModel.result[index].customProfileLink
            .contains("Linear"))
          profileId = _mProfileLogDataModel.result[index].customProfileLink
              .split("/Linear/")[1];
        else
          profileId = _mProfileLogDataModel.result[index].customProfileLink
              .split("/Preso/")[1];

        print('inside apiCallingForUpdateURl profileId:: ${profileId}');
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId =
            stringToBase64.decode(profileId.replaceAll("&SPK", "="));
        print(
            'inside apiCallingForUpdateURl decodedSharedId:: ${decodedSharedId}');
        Map map = {
          "userId": userIdPref,
          "roleId": roleId,
          "profileId": decodedSharedId,
          "isActive": _mProfileLogDataModel.result[index].isActive
        };
        print("Revoke accessMap++++++++" + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_PROFILE_SHARE_UPDATE, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg+profileShareLogLIst[index].isActive.toString());
              setState(() {
                _mProfileLogDataModel.result[index].isActive = false;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future getData(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(
            context, Constant.ENDPOINT_PROFILE_SHARE_LOG + userIdPref, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PROFILE_DETAIL++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS] == "Success") {
              _mProfileLogDataModel =
                  ProfileLogDataModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("getProfileDetail_INFO++++" + e.toString());
    }
  }

  @override
  void initState() {
    apiCallForGetShareLog();
    getSharedPreferences();
    super.initState();
  }

  void _confirmActionDialogNew(index, type) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to revoke this URL?',
            negativeText: 'Cancel',
            positiveText: 'Stop',
            isSucessPopup: false,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              _mProfileLogDataModel.result[index].isActive = false;
              apiCallingForUpdateURl(index);
            },
          );
        });



  }

  onTapText(text, context) async {
    if (text.contains("cus") && text.contains("Linear")) {
      String shareId = text.split("/Linear/")[1];
      try {
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId = stringToBase64
            .decode(shareId.replaceAll("&SPK", "=")); // username:password
        print('SharedID public preview 111:: ${shareId}');
        print('decodedSharedId public preview 111:: ${decodedSharedId}');
        if (decodedSharedId != null && decodedSharedId != "") {
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                  CustomViewForUser(decodedSharedId, "chat")));
        }
      } catch (e) {
        print('Exception 111 e: $e');
      }
    } else if (text.contains("cus") && text.contains("Preso")) {
      //http://app.spikeview.com/cus/Preso/MjIxNA==
      String shareId = text.split("/Preso/")[1];
      try {
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId = stringToBase64
            .decode(shareId.replaceAll("&SPK", "=")); // username:password
        print('SharedID public preview 111:: ${shareId}');
        print('decodedSharedId public preview 111:: ${decodedSharedId}');
        if (decodedSharedId != null && decodedSharedId != "") {
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) => CustomPresoViewForUser(
                  decodedSharedId, "chat", 'Custom', false.toString(), "")));
          // CustomProgressLoader.cancelLoader(context);
        }
      } catch (e) {
        print('Exception 111 e: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          onBack();
          return Future.value(false);
        },
        child: customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 20, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          BaseText(
                            text: 'Custom profile share',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w700,
                            fontSize: 28,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                          const SizedBox(height: 2),
                          BaseText(
                            text: 'Log of your custom profile shares.',
                            textColor: Color(0xff455276),
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 20,top: 20),

                      child: ListView(
                        padding: EdgeInsets.zero,

                        children: <Widget>[
                          (profileShareLogLIst != null &&
                                      profileShareLogLIst.length > 0) ||
                                  (_mProfileLogDataModel?.result != null &&
                                      (_mProfileLogDataModel
                                              ?.result?.isNotEmpty ??
                                          false))
                              ? Container(
                                  decoration: BoxDecoration(
                                      color: ColorValues.SELECTION_BG,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                          color: ColorValues.SELECTION_BG,
                                          width: 1.0)),
                                  child: Padding(
                                    padding: const EdgeInsets.all(9.0),
                                    child: Column(
                                      children: <Widget>[
                                        _mProfileLogDataModel != null &&
                                                _mProfileLogDataModel.result !=
                                                    null
                                            ? Container(
                                                child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: List.generate(
                                                        _mProfileLogDataModel
                                                            .result.length,
                                                        (int index) {
                                                      return PaddingWrap
                                                          .paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        10.0,
                                                        Container(
                                                          decoration: BoxDecoration(
                                                              color: Colors
                                                                  .transparent,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          10),
                                                              border: Border.all(
                                                                  color: ColorValues
                                                                      .LIST_BOTTOM_BG,
                                                                  width: 1.0)),
                                                          child: Column(
                                                            children: <Widget>[
                                                              Container(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0),
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      Container(
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Colors.white,
                                                                          borderRadius:
                                                                              BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(10),
                                                                            topRight:
                                                                                Radius.circular(10),
                                                                            bottomLeft: Radius.circular(_mProfileLogDataModel.result[index].isActive
                                                                                ? 0
                                                                                : 10),
                                                                            bottomRight: Radius.circular(_mProfileLogDataModel.result[index].isActive
                                                                                ? 0
                                                                                : 10),
                                                                          ),
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: const EdgeInsets.only(
                                                                              left: 0.0,
                                                                              right: 0,
                                                                              top: 13),
                                                                          child: Column(
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                Padding(
                                                                                    padding: const EdgeInsets.only(
                                                                                      left: 13.0,
                                                                                      right: 13,
                                                                                    ),
                                                                                    child: BaseText(
                                                                                      text: 'Link',
                                                                                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                                      fontFamily: AppConstants.stringConstant.latoRegular,
                                                                                      fontWeight: FontWeight.w600,
                                                                                      fontSize: 14,
                                                                                      textAlign: TextAlign.start,
                                                                                      maxLines: 3,
                                                                                    )),
                                                                                SizedBox(
                                                                                  height: 5,
                                                                                ),
                                                                                Padding(
                                                                                    padding: const EdgeInsets.only(
                                                                                      left: 13.0,
                                                                                      right: 13,
                                                                                    ),
                                                                                    child: InkWell(
                                                                                        onTap: () {
                                                                                          onTapText(_mProfileLogDataModel.result[index].customProfileLink, context);
                                                                                        },
                                                                                        child: BaseText(
                                                                                          text: _mProfileLogDataModel.result[index].customProfileLink,
                                                                                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                                          fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                          fontWeight: FontWeight.w400,
                                                                                          fontSize: 12,
                                                                                          textAlign: TextAlign.start,
                                                                                          maxLines: 3,
                                                                                        ))),
                                                                                SizedBox(
                                                                                  height: 5,
                                                                                ),
                                                                                Padding(
                                                                                    padding: const EdgeInsets.only(
                                                                                      left: 13.0,
                                                                                      right: 13,
                                                                                    ),
                                                                                    child: BaseText(
                                                                                      text: _mProfileLogDataModel.result[index].isProfileLinkExpire ? "Expires On: " + Util.getConvertedDateTimeStamp(_mProfileLogDataModel.result[index].expirationDate.toString()) : "Link set to not expire",
                                                                                      textColor: ColorValues.light_grey,
                                                                                      fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                      fontWeight: FontWeight.w400,
                                                                                      fontSize: 10,
                                                                                      textAlign: TextAlign.start,
                                                                                      maxLines: 3,
                                                                                    )),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.only(top: 9.0, bottom: 9),
                                                                                  child: Container(
                                                                                    color: ColorValues.LIST_BOTTOM_BG,
                                                                                    height: 1,
                                                                                  ),
                                                                                ),
                                                                                Padding(
                                                                                  padding: const EdgeInsets.only(
                                                                                    left: 13.0,
                                                                                    right: 13,
                                                                                    bottom: 9,
                                                                                  ),
                                                                                  child: Row(
                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: [
                                                                                      Expanded(
                                                                                        child: Column(
                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                          children: [
                                                                                            BaseText(
                                                                                              text: 'Created date:',
                                                                                              textColor: ColorValues.light_grey,
                                                                                              fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                              fontWeight: FontWeight.w500,
                                                                                              fontSize: 10,
                                                                                              textAlign: TextAlign.start,
                                                                                              maxLines: 3,
                                                                                            ),
                                                                                            SizedBox(
                                                                                              height: 5,
                                                                                            ),
                                                                                            BaseText(
                                                                                              text: Util.getConvertedDatetamp(_mProfileLogDataModel.result[index].createdAt.toString()),
                                                                                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                                              fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                              fontWeight: FontWeight.w500,
                                                                                              fontSize: 14,
                                                                                              textAlign: TextAlign.start,
                                                                                              maxLines: 3,
                                                                                            )
                                                                                          ],
                                                                                        ),
                                                                                        flex: 1,
                                                                                      ),
                                                                                      Expanded(
                                                                                        child: Column(
                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                          children: [
                                                                                            BaseText(
                                                                                              text: 'Created time:',
                                                                                              textColor: ColorValues.light_grey,
                                                                                              fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                              fontWeight: FontWeight.w500,
                                                                                              fontSize: 10,
                                                                                              textAlign: TextAlign.start,
                                                                                              maxLines: 3,
                                                                                            ),
                                                                                            SizedBox(
                                                                                              height: 5,
                                                                                            ),
                                                                                            BaseText(
                                                                                              text: Util.getConvertedTimeStamp(_mProfileLogDataModel.result[index].createdAt.toString()).trimLeft(),
                                                                                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                                              fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                              fontWeight: FontWeight.w500,
                                                                                              fontSize: 14,
                                                                                              textAlign: TextAlign.start,
                                                                                              maxLines: 3,
                                                                                            )
                                                                                          ],
                                                                                        ),
                                                                                        flex: 1,
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                )
                                                                              ]),
                                                                        ),
                                                                      ),
                                                                      _mProfileLogDataModel
                                                                              .result[index]
                                                                              .isActive
                                                                          ? Center(
                                                                              child: Padding(
                                                                                  padding: EdgeInsets.fromLTRB(13.0, 13.0, 13.0, 13.0),
                                                                                  child: GestureDetector(
                                                                                      onTap: () => _confirmActionDialogNew(index, "new"),
                                                                                      child: BaseText(
                                                                                        text: 'Revoke',
                                                                                        textColor: ColorValues.HEADING_COLOR_EDUCATION_2,
                                                                                        fontFamily: AppConstants.stringConstant.latoMedium,
                                                                                        fontWeight: FontWeight.w500,
                                                                                        fontSize: 14,
                                                                                        textAlign: TextAlign.start,
                                                                                        maxLines: 3,
                                                                                      ))),
                                                                            )
                                                                          : Container(height: 0.0),
                                                                    ],
                                                                  )),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    })),
                                              )
                                            : Container(
                                                height: 0.0,
                                              ),
                                      ],
                                    ),
                                  ),
                                )
                              : isLoading
                                  ? const SizedBox.shrink()
                                  :  const SizedBox.shrink(),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                ],
              )),
          () {
            Navigator.pop(context);
          },
          isShowIcon: false,
          isShowExplanation: false,
        ));
  }
}
