import 'dart:io';

class FileModel {
  File file;
  String path;

  FileModel(this.file, this.path);
}
