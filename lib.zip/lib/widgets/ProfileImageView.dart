import 'package:flutter/material.dart';

class ProfileImageView extends StatelessWidget {
  final String placeHolderImage;
  final String imagePath;
  final VoidCallback onTap;
  final double height,width,borderRadius;
  final bool withoutShadow;

  const ProfileImageView({
    @required this.imagePath,
    @required this.placeHolderImage,
    @required this.onTap,
    @required this.height,
  @required this.width,
   this.withoutShadow,
  this.borderRadius,

  });

  @override
  Widget build(BuildContext context) {
    return  InkWell(
      onTap: (){
        if (onTap != null) {
          onTap();
        }
      },
        child:Container(
            height:height?? 48.0,
            width: width??48.0,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(borderRadius??15),

                border: Border.all(
                    color: Colors.white,
                    width: 1),
                boxShadow: withoutShadow ?? false
                ?null
                :[
                  BoxShadow(
                    spreadRadius: 3,
                    blurRadius: 3,
                    offset: Offset(0, 2),
                    color: Color.fromRGBO(98, 175, 226,0.09),
                  )
                ]
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(borderRadius??15.0),
              child:FadeInImage(
                fit: BoxFit.cover,
                placeholder: AssetImage(
                  placeHolderImage?? 'assets/profile/user_on_user.png',
                ),
                image: NetworkImage(imagePath??''),
              ),
            )));
  }
}
