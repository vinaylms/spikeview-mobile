import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardFromParent.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class CompletedWizard extends StatefulWidget {
  String userId;

  CompletedWizard(this.userId);

  @override
  CompletedWizardState createState() {
    return  CompletedWizardState();
  }
}

class CompletedWizardState extends State<CompletedWizard> {
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
  }
  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return  WillPopScope(
        onWillPop: () {
          Navigator.of(context).popUntil((route) => route.isFirst);
          syncDoneController.add("profile");
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.singin_bg_color,
            body:  Stack(
              children: <Widget>[
                 Positioned(
                    left: 0.0,
                    right: 0.0,
                    top: 0.0,
                    bottom: 0.0,
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0.0, 40, 0, 0),//135 from top
                          child:  Image.asset(
                            "assets/newDesignIcon/sucess.png",
                            height: 84.0,
                            width: 84.0,
                          ),
                        ),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            25.0,
                            0.0,
                            5.0,
                            TextViewWrap.textView(
                                "Profile Created Successfully",
                                TextAlign.center,
                                 ColorValues.HEADING_COLOR_EDUCATION,
                                28.0,
                                FontWeight.normal)),
                        PaddingWrap.paddingfromLTRB(
                            16.0,
                            0.0,
                            16.0,
                            5.0,
                            TextViewWrap.textViewMultiLine(
                                "Thank you for creating your child’s profile, it looks amazing. Continue to add more detail about you.",
                                TextAlign.center,
                                 ColorValues.HEADING_COLOR_EDUCATION,
                                14.0,
                                FontWeight.normal,
                                5)),
                        PaddingWrap.paddingfromLTRB(
                          13.0,
                          20.0,
                          13.0,
                          13.0,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                    height: 156,
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        border:  Border.all(
                                            color:  ColorValues.BORDER_COLOR,
                                            width: 1.0)),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: <Widget>[
                                         Image.asset(
                                          "assets/story_new/go_to_profile.png",
                                          height: 50.0,
                                          width: 50.0,
                                        ),
                                        Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0,
                                                20.0,
                                                0.0,
                                                0.0),
                                            child:
                                             Text(
                                              "GO TO PROFILE",
                                              textAlign:
                                              TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontFamily: Constant.customRegular,
                                                  fontSize: 14.0),
                                            )),
                                      ],
                                    ),
                                  ),
                                  onTap: (){
                                    ////"CONTINUE BUILDING MY PROFILE",
                                    print("Completed userID+++++++++++++++"+widget.userId.toString());
                                    syncDoneController.add("profile");
                                  //  prefs.setString(UserPreference.USER_ID, widget.userId);
                                    Navigator.of(context)
                                        .popUntil((route) => route.isFirst);

                                    Navigator.of(context).push(
                                         MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                             UserProfileDashBoardFromParent(
                                                widget.userId)));
                                  },
                                ),
                              ),
                              Container(
                                width: 13.0,
                              ),
                              Expanded(
                                child: InkWell(
                                  child: Container(
                                    height: 156,
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        border:  Border.all(
                                            color:  ColorValues.BORDER_COLOR,
                                            width: 1.0)),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: <Widget>[
                                         Image.asset(
                                          "assets/story_new/parent_dashboard.png",
                                          height: 50.0,
                                          width: 50.0,
                                        ),
                                        Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0,
                                                20.0,
                                                0.0,
                                                0.0),
                                            child:
                                             Text(
                                              "GO TO PARENT DASHBOARD",
                                              textAlign:
                                              TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontFamily: Constant.customRegular,
                                                  fontSize: 14.0),
                                            )),
                                      ],
                                    ),
                                  ),
                                  onTap: (){
                                    syncDoneController.add("profile");
                                    Navigator.of(context)
                                        .popUntil((route) => route.isFirst);
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),


                        /*PaddingWrap.paddingfromLTRB(
                            16.0,
                            30.0,
                            16.0,
                            5.0,
                             InkWell(
                              child: TextViewWrap.textView(
                                  "GO TO PROFILE",
                                  TextAlign.center,
                                   ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                  16.0,
                                  FontWeight.normal),
                              onTap: () {
                                syncDoneController.add("profile");
                                Navigator.of(context)
                                    .popUntil((route) => route.isFirst);
                                Navigator.of(context).push(
                                     MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                         UserProfileDashBoardFromParent(
                                            widget.userId)));
                              },
                            )),
                          PaddingWrap.paddingfromLTRB(
                            16.0,
                            0.0,
                            16.0,
                            5.0,
                            TextViewWrap.textViewMultiLine(
                                "Add photos, videos, and documents to make it stand out",
                                TextAlign.center,
                                 ColorValues.GREY_TEXT_COLOR,
                                14.0,
                                FontWeight.normal,
                                5)),
                        PaddingWrap.paddingfromLTRB(
                            16.0,
                            30.0,
                            16.0,
                            5.0,
                             InkWell(
                              child: TextViewWrap.textView(
                                  "GO TO PARENT DASHBOARD",
                                  TextAlign.center,
                                   ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                  16.0,
                                  FontWeight.normal),
                              onTap: () {
                                syncDoneController.add("profile");
                                Navigator.of(context)
                                    .popUntil((route) => route.isFirst);
                              },
                            )),
                        PaddingWrap.paddingfromLTRB(
                            16.0,
                            0.0,
                            16.0,
                            5.0,
                            TextViewWrap.textViewMultiLine(
                                "View, Monitor, and Control Privacy Settings for your children’s profiles",
                                TextAlign.center,
                                 ColorValues.GREY_TEXT_COLOR,
                                14.0,
                                FontWeight.normal,
                                5)),*/
                      ],
                    )),


              ],
            )));
  }

// Updated View for POST TYPE

}
