class CategorySubjectResponse {
  String status;
  List<CategorySubjectResult> result;

  CategorySubjectResponse({this.status, this.result});

  CategorySubjectResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<CategorySubjectResult>();
      json['result'].forEach((v) {
        result.add(new CategorySubjectResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CategorySubjectResult {
  int categoryId;
  String name;
  String description;
  List<Subjects> subjects;

  CategorySubjectResult({this.categoryId, this.name, this.description, this.subjects});

  CategorySubjectResult.fromJson(Map<String, dynamic> json) {
    categoryId = json['categoryId'];
    name = json['name'];
    description = json['description'];
    if (json['subjects'] != null) {
      subjects =  List<Subjects>();
      json['subjects'].forEach((v) {
        subjects.add(new Subjects.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['categoryId'] = this.categoryId;
    data['name'] = this.name;
    data['description'] = this.description;
    if (this.subjects != null) {
      data['subjects'] = this.subjects.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Subjects {
  int subjectId;
  String name;
  String description;
  int categoryId;

  Subjects({this.subjectId, this.name, this.description, this.categoryId});

  Subjects.fromJson(Map<String, dynamic> json) {
    subjectId = json['subjectId'];
    name = json['name'];
    description = json['description'];
    categoryId = json['categoryId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['subjectId'] = this.subjectId;
    data['name'] = this.name;
    data['description'] = this.description;
    data['categoryId'] = this.categoryId;
    return data;
  }
}
