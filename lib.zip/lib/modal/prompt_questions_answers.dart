class PromptQuestionsAnswers {

  String questionId;
  String promptQuestion;
  String promptAnswer;

  PromptQuestionsAnswers(
      {
        this.questionId,
        this.promptQuestion,
        this.promptAnswer});

  PromptQuestionsAnswers.fromJson(Map<String, dynamic> json) {
    questionId = json['question_id'];
    promptQuestion = json['prompt_question'];
    promptAnswer = json['prompt_answer'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['question_id'] = this.questionId;
    data['prompt_question'] = this.promptQuestion;
    data['prompt_answer'] = this.promptAnswer;
    return data;
  }
}