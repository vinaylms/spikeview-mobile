import 'package:flutter/material.dart';
class LinkUrlModel {
  //TimeBetween toFromTime;
  //String label = "";
  //String url = "";
  TextEditingController labelController, urlController,descController;

  LinkUrlModel({this.labelController, this.urlController,this.descController});


  Map<String, dynamic> toJson() => {
    "label": this.labelController.text==null?"":this.labelController.text,
    "url": this.urlController.text==null?"":this.urlController.text,
    "description": this.descController.text==null?"":this.descController.text,

  };
}