import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/wizard/AddAccomplishment_Widget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/parentProfile/wizard/CompletedWizard.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/accomplishment/EditAchievment.dart';

import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class ACCompetenciesWidget extends StatefulWidget {
//  String name;
  String userEmail, userName;
  String sasToken;
  StudentDataModel studModel;
String pageName;
  ACCompetenciesWidget(
      this.sasToken, this.userEmail, this.userName, this.studModel,this.pageName);

  @override
  CompetenciesWidgetState createState() {
    return  CompetenciesWidgetState();
  }
}

class CompetenciesWidgetState extends State<ACCompetenciesWidget> {
  final _formKey = GlobalKey<FormState>();
  String userIdPref, token;

  ScrollController _controller = ScrollController();

  // List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  String isPerformChanges = "pop";
  List<CompetencyModel> listCompetency =  List();
  SharedPreferences prefs;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    competencyApiCall();
    // narrativeApi();
  }

  Future apiCallWizardCompleted() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("current student id accoplis"+widget.studModel.userId);

        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_COMPLETED_WIZARD +  prefs.getString(UserPreference.PARENT_WIZARD_USERID),
          "get",
        );
        print("wizardapi" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {

            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>  CompletedWizard(widget.studModel.userId)));
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

//------------------------------------Api Calling for get Commpetency -------------------------
  Future competencyApiCall() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_COMPENTENCY, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              listCompetency.clear();
              listCompetency =
                  ParseJson.parseMapCompetency(response.data['result']);
              if (listCompetency.length > 0) {
                setState(() {
                  listCompetency;
                  print("competency:-" + listCompetency.toString());
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Api Calling for delete achevement ------------------
  Future apiCallingForDeleteAchievment(achievementId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {
          "achievementId": achievementId,
        };

        Response response = await  ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              ToastWrap.showToast(msg, context);
              Navigator.pop(context, "push");
              isPerformChanges = "push";

              //  narrativeApi();
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
//============================================ grid view achevements nd core logic =====================================

//=========================================On Tap Add Achievement =================================
    onTapAddAchievement(level1Name,level3Competencylist, id, name) async {
      final result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>  AddAcomplishmentForm(level1Name,
              level3Competencylist,
              id,
              name,
              widget.sasToken,
              widget.studModel,widget.pageName)));
      print("shgubhresult :" + result.toString());
      if (result == "push") {
        setState(() {
          isPerformChanges = "push";
        });
        Navigator.pop(context, "push");
        //narrativeApi();
      }
    }

/*
    onTapAddRecommendation(level3Competencylist, id, name) async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>  AddRecommendationForm(
              level3Competencylist,
              id,
              name,
              widget.sasToken,
              widget.userEmail,
              widget.userName)));
      if (result == "push") {
        setState(() {
          isPerformChanges = "push";
        });

        Navigator.pop(context, "push");
      }
    }
*/

    Column getCompetencyItem(position) {
      return  Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
       /*   position == 0
              ? PaddingWrap.paddingfromLTRB(
                  16.0,
                  20.0,
                  16.0,
                  5.0,
                   Text(
                    "Select any from the list below to add your competency",
                    textAlign: TextAlign.start,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ))
              :  Container(
                  height: 0.0,
                ),*/
          PaddingWrap.paddingfromLTRB(
              13.0,
              10.0,
              13.0,
              0.0,
               Container(
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      border:  Border.all(
                          color:   ColorValues.DEVIDER_COLOR,
                          width: 1.0)),
                  child:  InkWell(
                      child: ListTile(
                        trailing:  Container(
                            padding:  EdgeInsets.all(8.0),
                            height: 40.0,
                            width: 30.0,
                            child:  Image.asset(
                              listCompetency[position].isSelected
                                  ? "assets/newDesignIcon/competency/up_arrow.png"
                                  : "assets/newDesignIcon/competency/down_arrow.png",
                              height: 15.0,
                              width: 15.0,
                            )),
                        title:  Text(
                          listCompetency[position].level1,
                          style:  TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 16.0,
                              color:
                                   ColorValues.BLUE_COLOR_BOTTOMBAR),
                        ),
                      ),
                      onTap: () {
                        if (listCompetency[position].isSelected) {
                          listCompetency[position].isSelected = false;
                        } else {
                          listCompetency[position].isSelected = true;
                        }
                        setState(() {
                          if (position == (listCompetency.length - 1)) {
                            _controller.jumpTo(
                                _controller.position.maxScrollExtent + 80.0);
                          }

                          listCompetency[position].isSelected;
                        });
                      }))),
          listCompetency[position].isSelected
              ? PaddingWrap.paddingfromLTRB(
              13.0,
                  10.0,
              13.0,
                  5.0,
                   Container(
                      decoration:  BoxDecoration(
                          color: Colors.white,
                          border:  Border.all(
                              color:   ColorValues.DEVIDER_COLOR,
                              width: 1.0)),
                      child:  Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:  List.generate(
                              listCompetency[position]
                                  .level2Competencylist
                                  .length, (int index) {
                            return PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                 Column(
                                  children: <Widget>[
                                     Container(
                                        /*   decoration:  BoxDecoration(
                                    border:  Border.all(
                                        color:  ColorValues.DEVIDER_COLOR,
                                        width: 1.0)),*/
                                        child: ListTile(
                                      title:  Text(
                                        listCompetency[position]
                                            .level2Competencylist[index]
                                            .name,
                                        style:  TextStyle(
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 16.0,
                                            color:  ColorValues.HEADING_COLOR_EDUCATION),
                                      ),
                                      onTap: () {
                                        onTapAddAchievement(listCompetency[position].level1,
                                            listCompetency[position]
                                                .level2Competencylist[index]
                                                .level3Competencylist,
                                            listCompetency[position]
                                                .level2Competencylist[index]
                                                .competencyTypeId,
                                            listCompetency[position]
                                                .level2Competencylist[index]
                                                .name);
                                      },
                                    )),
                                    (listCompetency[position]
                                                    .level2Competencylist
                                                    .length -
                                                1) ==
                                            index
                                        ?  Container(
                                            height: 0.0,
                                          )
                                        :  Divider(
                                            color:   ColorValues.DEVIDER_COLOR,
                                            height: 1.0,
                                          )
                                  ],
                                ));
                          }))))
              :  Container(
                  height: 0.0,
                ),
        ],
      );
    }

    Row getUpperDots() {
      return  Row(
        children: <Widget>[
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
      );
    }

    Container getBottomBar() {
      return  Container(

          child:  Row(
            children: <Widget>[
               InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                    child: Image.asset(
                      'assets/newDesignIcon/parentProfile/backword.png',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  onBackwordClick();
                },
              ),
               Expanded(
                child:  InkWell(
                  child:new Padding(
      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
      child:   Text(
                    "SKIP",
                    style: TextStyle(
                        fontSize: 16.0,
                        fontFamily: Constant.customRegular,
                        color: ColorValues.GREY_TEXT_COLOR),
                    textAlign: TextAlign.center,
                  )),
                  onTap: () {
                    skipOnClick();
                  },
                ),
                flex: 1,
              ),
              !true
                  ?  InkWell(
                      child:  Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                          child: Image.asset(
                            'assets/newDesignIcon/parentProfile/next.png',
                            height: 45.0,
                            width: 45.0,
                          )),
                      onTap: () {
                        onNextClick();
                      },
                    )
                  :  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                      child: Image.asset(
                        'assets/newDesignIcon/parentProfile/next_gray.png',
                        height: 45.0,
                        width: 45.0,
                      ))
            ],
          ));
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            body:  Column(
              children: <Widget>[
                 Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
                    child: getUpperDots()),
                 Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                    child:  Text(
                      "Add Accomplishment",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontFamily: Constant.customRegular,
                          fontSize: 28.0,
                          fontWeight: FontWeight.normal,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    )),
                 Expanded(
                  child: listCompetency.length > 0
                      ?  ListView.builder(
                          controller: _controller,
                          itemCount: listCompetency.length,
                          itemBuilder: (BuildContext context, int position) {
                            return getCompetencyItem(position);
                          })
                      :  Container(),
                  flex: 1,
                ),
                 Container(
                  child: getBottomBar(),
                )
              ],
            )));
  }

  void skipOnClick() {
    if(widget.pageName=="all"){
      Navigator.pop(context);
    }else {
      apiCallWizardCompleted();
    }
  }

  void onNextClick() {
    // make Api Call
  }

  void onBackwordClick() {
    Navigator.pop(context);
  }
}
