import 'dart:async';

import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';

import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/group/New/ManageGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';

import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/report/ReportWidget.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

import '../AboutGroupWidget.dart';
import '../AddGroupWidget.dart';
import '../AddGroupWidgetForParent.dart';
import '../EditGroupWidget.dart';
import 'GroupInvitationWidget.dart';

class GroupConnectedWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return GroupConnectedWidgetState();
  }
}

class GroupConnectedWidgetState extends State<GroupConnectedWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, zipCode;
  bool isLoading = true;
  String isPerformChanges = "false";
  List<GroupModel> groupList = List();
  List<GroupModel> groupRequestList = List();
  bool isUserRepoted = true;
  bool isParent = false;
  String sasToken, containerName;

  int offset = 0;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    if (roleId == "2") {
      isParent = true;
    }
    roleId = prefs.getString(UserPreference.ROLE_ID);
    zipCode = prefs.getString(UserPreference.ZIPCODE);
    isUserRepoted = UserPreference.getIsUserReported();
    callApiForSaas(false);
    isLoading = true;
    setState(() {
      isLoading;
    });

    AddGroupWidgetState.syncDoneController.stream.listen((value) {
      apiCallForGet();
    });

    /*GroupDetailWidgetState.syncDoneController.stream.listen((value) {
          apiCallForGet();
        });*/

    AddGroupWidgetForParentState.syncDoneController.stream.listen((value) {
      apiCallForGet();
    });

    ManageGroupWidgetState.syncDoneController.stream.listen((value) {
      apiCallForGet();
    });
    await apiCallForGetRequest();
    await apiCallForGet();
    isLoading = false;
    setState(() {});
  }

  ScrollController _scrollController = ScrollController();
  int skip = 0;
  bool isLoadMore = true;
  bool isLoadingData = false;

  @override
  void initState() {
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
    getSharedPreferences();
    super.initState();
  }

  _scrollListener() {
    if (_scrollController.offset >=
            _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      offset++;
      if (isLoadMore) {
        apiCallForLoadMore();
      }
    }
  }

//==========================================================

  Future apiCallForGet() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        offset = 0;
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_BY_TYPE +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=0&status=Accepted&name=",
            "get");
        print('response+++' +
            Constant.GET_GROUP_BY_TYPE +
            userIdPref +
            "&roleId=" +
            roleId +
            "&skip=0&status=Accepted&name=");
        print('response+++' + response.toString());
        isLoading = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupList = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
    }
  }

  Future apiCallForGetRequest() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
        });
        offset = 0;
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_BY_TYPE +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=0&status=Invited&name=",
            "get");
        print('response+++' +
            Constant.GET_GROUP_BY_TYPE +
            userIdPref +
            "&roleId=" +
            roleId +
            "&skip=0&status=Accepted&name=");
        print('response+++' + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupRequestList = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupRequestList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  Future apiCallForLoadMore() async {
    try {
      print("load mo0re call");
      isLoadingData = true;
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        print("load mo0re call++" +
            Constant.GET_GROUP_BY_TYPE +
            userIdPref +
            "&roleId=" +
            roleId +
            "&skip=$offset&status=Accepted&name=");
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_BY_TYPE +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=$offset&status=Invited&name=",
            "get");

        isLoadingData = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var groupList1 = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupList.addAll(groupList1);
              });

              if (groupList1.length > 0) {
                setState(() {
                  groupList.addAll(groupList1);
                });
              } else {
                isLoadMore = false;
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadingData = false;

      e.toString();
    }
  }

  Future apiCallingForLeave(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "userId": int.parse(userIdPref),
          "groupId": int.parse(groupId),
          "roleId": int.parse(roleId)
        };
        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_LEAVE_GROUP, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallForGet();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  Future apiCallingDeleteGroup(GroupModel groupListModel) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {"groupId": int.parse(groupListModel.groupId)};
        print("test++++" + map.toString());
        response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_ADD_GROUP, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallForGet();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  void leaveConfromAtionDialog(GroupModel groupListModel) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Center(
                                              child: Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: MessageConstant
                                                      .ABOUT_GROUP_LEAVE,
                                                  style: AppTextStyle
                                                      .getDynamicStyleGroup(
                                                          ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          16.0,
                                                          FontType.Regular),
                                                  /*TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),*/
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                        text: "\" " +
                                                            groupListModel
                                                                .groupName +
                                                            " \"",
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            fontSize: 18.0,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR)),
                                                    TextSpan(
                                                      text: MessageConstant
                                                          .ABOUT_GROUP_GROUP_,
                                                      style: AppTextStyle
                                                          .getDynamicStyleGroup(
                                                              ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontType
                                                                  .Regular), /*TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ],
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: AppTextStyle
                                                  .getDynamicStyleGroup(
                                                      ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      16.0,
                                                      FontType
                                                          .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.ABOUT_GROUP_LEAVE,
                                              textAlign: TextAlign.center,
                                              style: AppTextStyle
                                                  .getDynamicStyleGroup(
                                                      ColorValues
                                                          .BLUE_COLOR_BOTTOMBAR,
                                                      16.0,
                                                      FontType
                                                          .Regular), /*TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallingForLeave(
                                                  groupListModel.groupId);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void deleteConfromAtionDialog(GroupModel groupListModel) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Center(
                                              child: Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: MessageConstant
                                                      .ABOUT_GROUP_DELETE1,
                                                  style: AppTextStyle
                                                      .getDynamicStyleGroup(
                                                          ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          16.0,
                                                          FontType.Regular),
                                                  /*TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),*/
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                        text: "\"" +
                                                            groupListModel
                                                                .groupName +
                                                            "\"",
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR)),
                                                    TextSpan(
                                                      text: MessageConstant
                                                          .ABOUT_GROUP_GROUP_,
                                                      style: AppTextStyle
                                                          .getDynamicStyleGroup(
                                                              ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontType
                                                                  .Regular), /*TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ],
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: AppTextStyle
                                                  .getDynamicStyleGroup(
                                                      ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      16.0,
                                                      FontType
                                                          .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant
                                                  .ABOUT_GROUP_DELETE1,
                                              textAlign: TextAlign.center,
                                              style: AppTextStyle
                                                  .getDynamicStyleGroup(
                                                      ColorValues
                                                          .BLUE_COLOR_BOTTOMBAR,
                                                      16.0,
                                                      FontType
                                                          .Regular), /*TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallingDeleteGroup(
                                                  groupListModel);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  onTapReport(GroupModel groupListModel) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            Report("group", groupListModel.groupId, "", "")));
    if (result == "push") {
      apiCallForGet();
    }
  }

  void moreOptionIfUserNotAAdmin(GroupModel groupListModel) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Container(
                                height: 210.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                            child: Center(
                                                                child: Text(
                                                              MessageConstant
                                                                  .ABOUT_GROUP_ABOUT_GROUP,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 5,
                                                              style: AppTextStyle
                                                                  .getDynamicStyleGroupHEIGHT(
                                                                      ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR,
                                                                      16.0,
                                                                      FontType
                                                                          .Regular,
                                                                      1.2), /*TextStyle(
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    height: 1.2,
                                                                    fontSize:
                                                                        16.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),*/
                                                            ))),
                                                        onTap: () {
                                                          Navigator.pop(
                                                              context);
                                                          GroupDetailModel
                                                              model =
                                                              GroupDetailModel(
                                                                  "0",
                                                                  groupListModel
                                                                      .groupId,
                                                                  groupListModel
                                                                      .groupName,
                                                                  groupListModel
                                                                      .type,
                                                                  groupListModel
                                                                      .creationDate,
                                                                  groupListModel
                                                                      .createdBy,
                                                                  groupListModel
                                                                      .isActive,
                                                                  groupListModel
                                                                      .aboutGroup,
                                                                  groupListModel
                                                                      .otherInfo,
                                                                  groupListModel
                                                                      .groupImage,
                                                                  null,
                                                                  groupListModel
                                                                      .isAdmin,
                                                                  groupListModel
                                                                      .status,
                                                                  null,
                                                                  null,
                                                                  null,
                                                                  false,
                                                                  null,
                                                                  "");
                                                          Navigator.of(context).push(
                                                              new MaterialPageRoute(
                                                                  builder: (BuildContext
                                                                          context) =>
                                                                      AboutGroupWidget(
                                                                          model)));
                                                        },
                                                      )),
                                                  Container(
                                                    height: 1.0,
                                                    color: ColorValues
                                                        .BORDER_COLOR,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child: Center(
                                                            child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_LEAVE_GROUP,
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroupHEIGHT(
                                                                  ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontType
                                                                      .Regular,
                                                                  1.2), /* TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),*/
                                                        ))),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      leaveConfromAtionDialog(
                                                          groupListModel);
                                                      //  apiCallingForLeave();
                                                    },
                                                  ),
                                                  Container(
                                                    height: 1.0,
                                                    color: ColorValues
                                                        .BORDER_COLOR,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child: Center(
                                                            child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_SUPPORT_REPORT_GROUP,
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroupHEIGHT(
                                                                  ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontType
                                                                      .Regular,
                                                                  1.2), /* TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),*/
                                                        ))),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      onTapReport(
                                                          groupListModel);
                                                      //  apiCallingForLeave();
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: AppTextStyle
                                                  .getDynamicStyleGroup(
                                                      ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      16.0,
                                                      FontType
                                                          .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  onTapEditGroup(GroupModel groupListModel) async {
    GroupDetailModel model = GroupDetailModel(
        "0",
        groupListModel.groupId,
        groupListModel.groupName,
        groupListModel.type,
        groupListModel.creationDate,
        groupListModel.createdBy,
        groupListModel.isActive,
        groupListModel.aboutGroup,
        groupListModel.otherInfo,
        groupListModel.groupImage,
        null,
        groupListModel.isAdmin,
        groupListModel.status,
        null,
        null,
        null,
        false,
        null,
        "");

    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            EditGroupWidget(model, sasToken, containerName)));
    if (result == "push") {
      apiCallForGet();
    }
  }

  void moreOptionIfUserAdmin(GroupModel groupListModel) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Container(
                                height: 160.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Container(
                                                    height: 1.0,
                                                    color: ColorValues
                                                        .BORDER_COLOR,
                                                  ),
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                            child: Center(
                                                                child: Text(
                                                              MessageConstant
                                                                  .ABOUT_GROUP_EDIT_GROUP,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 5,
                                                              style: AppTextStyle
                                                                  .getDynamicStyleGroupHEIGHT(
                                                                      ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR,
                                                                      16.0,
                                                                      FontType
                                                                          .Regular,
                                                                      1.2), /*TextStyle(
                                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    height: 1.2,
                                                                    fontSize:
                                                                        16.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),*/
                                                            ))),
                                                        onTap: () {
                                                          Navigator.pop(
                                                              context);
                                                          onTapEditGroup(
                                                              groupListModel);
                                                        },
                                                      )),
                                                  Container(
                                                    height: 1.0,
                                                    color: ColorValues
                                                        .BORDER_COLOR,
                                                  ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child: Center(
                                                            child: Text(
                                                          MessageConstant
                                                              .ABOUT_GROUP_DELETE_GROUP,
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroupHEIGHT(
                                                                  ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontType
                                                                      .Regular,
                                                                  1.2), /* TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),*/
                                                        ))),
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                      deleteConfromAtionDialog(
                                                          groupListModel);
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: AppTextStyle
                                                  .getDynamicStyleGroup(
                                                      ColorValues
                                                          .GREY_TEXT_COLOR,
                                                      16.0,
                                                      FontType
                                                          .Regular), /*TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  Future apiCallingForAccept(groupId, index, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "isAdmin": false,
          "status": type
        };

        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallForGetRequest();
              await apiCallForGet();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  onTapViewAllRequest() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => GroupInvitationWidget()));
    if (result == "push") {
      apiCallForGetRequest();
      apiCallForGet();
    }
  }

  Widget requestItem(groupModel, index) {
    return PaddingWrap.paddingfromLTRB(
      5.0,
      10.0,
      5.0,
      0.0,
      Container(
        width: 165,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: ColorValues.SELECTION_BG,
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 20.0, right: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 12,
              ),
              ProfileImageView(
                imagePath: Constant.IMAGE_PATH_SMALL +
                    ParseJson.getSmallImage(groupModel.groupImage),
                placeHolderImage:
                'assets/newDesignIcon/group/default_circle_bg.png',
                height: 60.0,
                width: 60.0,
                onTap: () async {
                  String result = await Navigator.of(context).push(
                      MaterialPageRoute(
                          builder: (BuildContext context) =>
                              GroupDetailWidget(
                                  groupModel.groupId, "", "", "", "")));
                  if (result == 'push') {
                    apiCallForGet();
                  }
                },
              ),
              PaddingWrap.paddingfromLTRB(
                  7.0,
                  10.0,
                  2.0,
                  0.0,
                  RichText(
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    text: TextSpan(
                      text: groupModel.groupName + " ",
                      style: TextStyle(
                        fontStyle: FontStyle.normal,
                        color: AppConstants.colorStyle.darkBlue,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                      ),
                    ),
                  )),
              Row(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                    7.0,
                    3.0,
                    0.0,
                    0.0,
                    Image.asset(
                      groupModel.type == "private"
                          ? "assets/png/private_group.png"
                          : "assets/png/public_group.png",
                      height: 15.0,
                      width: 15.0,
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: groupModel.type ==
                            MessageConstant.ABOUT_GROUP_PRIVATE
                            ? MessageConstant.ABOUT_GROUP_PRIVATE_GROUP
                            : MessageConstant.ABOUT_GROUP_PUBLIC_GROUP,
                        textColor: ColorValues.labelColor,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ))
                ],
              ),
              Padding(
                padding:
                const EdgeInsets.only(top: 15.0, bottom: 12, left: 5),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    InkWell(
                      onTap: () {
                        apiCallingForAccept(
                            groupModel.groupId, 0, "Accepted");
                      },
                      child: Container(
                          height: 26.0,
                          width: 70,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: ColorValues.WHITE,
                            border: Border.all(
                                color: ColorValues.HEADING_COLOR_EDUCATION_2,
                                width: 1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Padding(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 2.0),
                                child: BaseText(
                                  text: 'Accept',
                                  textColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_2,
                                  fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  textAlign: TextAlign.start,
                                  maxLines: 3,
                                ),
                              ),
                            ],
                          )),
                    ),
                    InkWell(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(8.0, 0.0, 0.0, 0.0),
                          child: Container(
                              height: 23.0,
                              width: 23.0,
                              child: Image.asset(
                                'assets/png/cancel_circle.png',
                              ))),
                      onTap: () {
                        apiCallingForAccept(
                            groupModel.groupId, 0, "Rejected");
                      },
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget getListview(groupModel, index) {
    print("url" + groupModel.groupImage);

    return PaddingWrap.paddingfromLTRB(
      20.0,
      10.0,
      20.0,
      0.0,
      InkWell(
        child: Column(
          children: [
            Container(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Expanded(
                            child: ProfileImageView(
                              imagePath: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getSmallImage(groupModel.groupImage),
                              placeHolderImage:
                              'assets/newDesignIcon/group/default_circle_bg.png',
                              height: 48.0,
                              width: 48.0,
                              onTap: () async {
                                String result = await Navigator.of(context).push(
                                    MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            GroupDetailWidget(groupModel.groupId,
                                                "", "", "", "")));
                                // print('refresh++++++connected++'+result.trim().toString());
                                if (result == 'push') {
                                  apiCallForGet();
                                }
                              },
                            ),
                            flex: 0,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                5.0,
                                10.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        7.0,
                                        0.0,
                                        2.0,
                                        0.0,
                                        RichText(
                                          maxLines: 1,
                                          textAlign: TextAlign.start,
                                          overflow: TextOverflow.ellipsis,
                                          text: TextSpan(
                                            text: groupModel.groupName + " ",
                                            style: TextStyle(
                                              fontStyle: FontStyle.normal,
                                              color: AppConstants
                                                  .colorStyle.darkBlue,
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoMedium,
                                            ),
                                          ),
                                        )),
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: groupModel.isAdmin
                                              ? Padding(
                                            padding: const EdgeInsets.only(
                                                left: 5.0, top: 6),
                                            child: Container(
                                                height: 18.0,
                                                width: 45,
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                  color: ColorValues
                                                      .TAB_BACKGROUND_COLOR,
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      15),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .center,
                                                  children: <Widget>[
                                                    Padding(
                                                      padding: EdgeInsets
                                                          .fromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          2.0),
                                                      child: BaseText(
                                                        text: 'Owner',
                                                        textColor: ColorValues
                                                            .HEADING_COLOR_EDUCATION_2,
                                                        fontFamily: AppConstants
                                                            .stringConstant
                                                            .latoRegular,
                                                        fontWeight:
                                                        FontWeight.w400,
                                                        fontSize: 12,
                                                        textAlign:
                                                        TextAlign.start,
                                                        maxLines: 3,
                                                      ),
                                                    ),
                                                  ],
                                                )),
                                          )
                                              : SizedBox(),
                                          flex: 0,
                                        ),
                                        Expanded(
                                          child: Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                6.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  groupModel.type == "private"
                                                      ? "assets/png/private_group.png"
                                                      : "assets/png/public_group.png",
                                                  height: 15.0,
                                                  width: 15.0,
                                                ),
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  0.0,
                                                  BaseText(
                                                    text: groupModel.type ==
                                                        MessageConstant
                                                            .ABOUT_GROUP_PRIVATE
                                                        ? MessageConstant
                                                        .ABOUT_GROUP_PRIVATE_GROUP
                                                        : MessageConstant
                                                        .ABOUT_GROUP_PUBLIC_GROUP,
                                                    textColor:
                                                    ColorValues.labelColor,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoRegular,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 14,
                                                    textAlign: TextAlign.start,
                                                    maxLines: 3,
                                                  ))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                    isUserRepoted
                        ? Expanded(
                      child: Row(
                        children: [
                          groupModel.isAdmin
                              ? Align(
                              alignment: Alignment.center,
                              child: ButtonView(
                                btnName: 'Edit',
                                borderColor:
                                AppConstants.colorStyle.lightBlue,
                                bgColor: AppConstants
                                    .colorStyle.box_bg_color,
                                txtColor:
                                AppConstants.colorStyle.lightBlue,
                                onButtonTap: () {
                                  onTapEditGroup(groupModel);
                                },
                              ))
                              : SizedBox()
                        ],
                      ),
                      flex: 0,
                    )
                        : SizedBox()
                  ],
                )),
            Padding(
              padding: const EdgeInsets.only(top: 16.0, bottom: 8),
              child: Container(
                height: 1,
                color: AppConstants.colorStyle.btnBg,
              ),
            )
          ],
        ),
        onTap: () {
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) =>
                  GroupDetailWidget(groupModel.groupId, "", "", "", ""))).then((value) {
                    if(value != null && value == 'push'){
                      apiCallForGet();
                    }
          });
        },
      ),
    );
  }

  onTapAddGroup() async {
    print("isParent++++" + isParent.toString());
    if (isParent) {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              AddGroupWidgetForParent(sasToken, containerName)));

      if (result == "push") {
        groupList.clear();
        apiCallForGet();
      }
    } else {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              AddGroupWidget(sasToken, containerName, "")));

      if (result == "push") {
        groupList.clear();
        apiCallForGet();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;



    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child: isLoading
            ? SizedBox()
            : groupList.length > 0 || groupRequestList.length > 0
                ? ListView(
                    controller: _scrollController,
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          groupRequestList.length > 0
                              ? Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                20, 0, 20, 10),
                                            child: BaseText(
                                              text: 'Received requests',
                                              textColor: AppConstants
                                                  .colorStyle.darkBlue,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18,
                                              textAlign: TextAlign.center,
                                              maxLines: 5,
                                            )),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              right: 15.0),
                                          child: InkWell(
                                              onTap: () {
                                                onTapViewAllRequest();
                                              },
                                              child: Container(
                                                width: 40,
                                                height: 40,
                                                child: Center(
                                                  child: Icon(
                                                    Icons.arrow_forward,
                                                    color: AppConstants
                                                        .colorStyle.lightBlue,
                                                    size: 22,
                                                  ),
                                                ),
                                              )),
                                        )
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 15.0, right: 15),
                                      child: Container(
                                        height: 192,
                                        child: ListView(
                                            scrollDirection: Axis.horizontal,
                                            children: List.generate(
                                                groupRequestList.length,
                                                (int index) {
                                              return requestItem(
                                                  groupRequestList[index],
                                                  index);
                                            })),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                  ],
                                )
                              : SizedBox(),
                          Column(
                            children: [
                              groupRequestList.length > 0
                                  ? Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                20, 0, 20, 10),
                                            child: BaseText(
                                              text: 'My groups',
                                              textColor: AppConstants
                                                  .colorStyle.darkBlue,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18,
                                              textAlign: TextAlign.center,
                                              maxLines: 5,
                                            )),
                                      ],
                                    )
                                  : SizedBox(
                                      height: 10,
                                    ),
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: List.generate(groupList.length,
                                      (int index) {
                                    return getListview(groupList[index], index);
                                  })),
                            ],
                          )
                        ],
                      )
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Padding(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 35),
                          child: BaseText(
                            text:
                                MessageConstant.ABOUT_GROUP_IT_LOOKS_LIKEHAVENT,
                            textColor: AppConstants.colorStyle.lightPurple,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            textAlign: TextAlign.center,
                            maxLines: 5,
                          )),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 50.0),
                        child: InkWell(
                          onTap: () {
                            onTapAddGroup();
                          },
                          child: Container(
                              height: 44,
                              width: 177,
                              decoration: BoxDecoration(
                                color: AppConstants.colorStyle.lightBlue,
                                border: Border.all(
                                    color: AppConstants.colorStyle.lightBlue),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Align(
                                  alignment: Alignment.center,
                                  // Align however you like (i.e .centerRight, centerLeft)
                                  child: Text(
                                    "Create group",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: ColorValues.WHITE,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontSize: 18.0,
                                    ),
                                  ))),
                        ),
                      ),
                    ],
                  ));
  }
}
