import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/TestScore/AddTestScoreWidget.dart';
import 'package:spike_view_project/TestScore/AddTestScoreWidgetPerformance.dart';
import 'package:spike_view_project/TestScore/EditTestScoreWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

import 'AddTestScore.dart';
import 'DocumentPerformance.dart';
import 'UpdateTestScorePerformance.dart';

// Create a Form Widget
class TestScoreListWidgetPerformance extends StatefulWidget {
  ProfileData profileInfoModal;
  List<TestScores> userTestList;

  TestScoreListWidgetPerformance(this.profileInfoModal, this.userTestList);

  @override
  TestScoreListWidgetState createState() {
    return TestScoreListWidgetState(userTestList);
  }
}

class TestScoreListWidgetState extends State<TestScoreListWidgetPerformance> {
  String userIdPref, token;
  List<TestScores> userTestList;
  String isPerformChnges = "pop";
  SharedPreferences prefs;

  TestScoreListWidgetState(this.userTestList);

  onTapAddTestScore() async {
    var result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            AddTestScore(widget.profileInfoModal)));

    print(result);
    if (result != null && result) {
      testScoreApi(true);
    }
  }

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    token = prefs.getString(UserPreference.USER_TOKEN);
    // narrativeApi();
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  Future testScoreApi(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PROFILE_DATA +
                userIdPref +
                "&roleId=" +
                widget.profileInfoModal.roleId,
            "get");

        print("response education" + response.toString());

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              ProfileBloc.itemModel = ProfileDataModel.fromJson(response.data);
              userTestList.clear();
              List<TestScores> userTestListNew =
                  ProfileBloc.itemModel.profileDataModel.testScores;
              if (userTestListNew.length > 0) {

                userTestList.addAll(userTestListNew);
                if (mounted) {
                  setState(() {
                    userTestList;
                  });
                }
              }
              setState(() {


              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Delete Education Data ------------------
  Future deleteTest(testId, userTestId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": userIdPref,
          "userTestId": userTestId,
        };
        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_DELETE_TEST_SCORE_DATA, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              userTestList.removeAt(index);
              setState(() {
                userTestList;
                isPerformChnges = "push";
              });

              if (userTestList.length == 0) Navigator.pop(context, "push");

              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    onTapEditTestScore(
        List<Scores> mainTestList1, ProfileData profileInfoModal) async {
      var result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => UpdateTestScorePerformance(
              mainTestList1, '', '', profileInfoModal.userId)));

      if (result != null && result) {
        bloc.fetcprofileData(userIdPref, context, prefs, true);

        await testScoreApi(true);
        if (userTestList.length == 0) {
          Navigator.pop(context);
        }
      }
    }

    Container getTestScoreListItem(index) {
      return Container(
          color: Colors.white,
          child: PaddingWrap.paddingfromLTRB(
              20.0,
              10.0,
              20.0,
              13.0,
              Container(
                decoration: BoxDecoration(
                  color: AppConstants.colorStyle.cardLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                child: Container(
                                    width: double.infinity,
                                    child: PaddingWrap.paddingfromLTRB(
                                        16.0,
                                        13.0,
                                        16.0,
                                        13.0,
                                        BaseText(
                                          text: userTestList[index].name,
                                          textColor: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 16,
                                          maxLines: 2,
                                        ))),
                                flex: 1,
                              ),
                              Expanded(
                                child: InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      5.0,
                                      13.0,
                                      16.0,
                                      13.0,
                                      Image.asset(
                                        "assets/png/edit_blue.png",
                                        height: 20.0,
                                        width: 20.0,
                                      )),
                                  onTap: () {
                                    List<Scores> scores1 = List();
                                    scores1.addAll(userTestList[index].scores);
                                    onTapEditTestScore(
                                        scores1, widget.profileInfoModal);
                                  },
                                ),
                                flex: 0,
                              )
                            ],
                          ),
                          flex: 5,
                        ),
                      ],
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: AppConstants.colorStyle.fillShade,
                          borderRadius: new BorderRadius.only(
                              bottomRight: const Radius.circular(10.0),
                              bottomLeft: const Radius.circular(10.0))),
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Container(
                            decoration: BoxDecoration(
                                color: AppConstants.colorStyle.fillShade,
                                borderRadius: new BorderRadius.only(
                                    bottomRight: const Radius.circular(10.0),
                                    bottomLeft: const Radius.circular(10.0))),
                            child: Column(
                                children: List.generate(
                                    userTestList[index].scores.length,
                                    (index3) {
                              return Container(
                                  decoration: BoxDecoration(
                                    border: Border(
                                      bottom: BorderSide(
                                        //                    <--- top side
                                        color:
                                            (userTestList[index].scores.length -
                                                        1) ==
                                                    index3
                                                ? Colors.transparent
                                                : AppConstants.colorStyle.btnBg,
                                        width: 1.0,
                                      ),
                                    ),
                                  ),
                                  child: PaddingWrap.paddingfromLTRB(
                                      16.0,
                                      10.0,
                                      16.0,
                                      16.0,
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Container(
                                              child: new Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Column(
                                                  children: List.generate(
                                                      /*  userTestList[index]
                                                              .scores[index3]
                                                              .isShowMore
                                                          ? userTestList[index]
                                                              .scores[index3]
                                                              .subjects
                                                              .length
                                                          : userTestList[index]
                                                                      .scores[
                                                                          index3]
                                                                      .subjects
                                                                      .length >
                                                                  2
                                                              ? 3
                                                              :*/
                                                      userTestList[index]
                                                          .scores[index3]
                                                          .subjects
                                                          .length, (index2) {
                                                return Container(
                                                    child:
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                0.0,
                                                                Row(
                                                                  children: <
                                                                      Widget>[
                                                                    Expanded(
                                                                      child:
                                                                          BaseText(
                                                                        text: userTestList[index]
                                                                            .scores[index3]
                                                                            .subjects[index2]
                                                                            .subject,
                                                                        textColor:
                                                                            ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                        fontFamily: AppConstants
                                                                            .stringConstant
                                                                            .latoRegular,
                                                                        fontWeight:
                                                                            FontWeight.w400,
                                                                        fontSize:
                                                                            14,
                                                                        maxLines:
                                                                            3,
                                                                      ),
                                                                      flex: 1,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          BaseText(
                                                                        text: userTestList[index]
                                                                            .scores[index3]
                                                                            .subjects[index2]
                                                                            .score
                                                                            .toString(),
                                                                        textColor:
                                                                            ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                        fontFamily: AppConstants
                                                                            .stringConstant
                                                                            .latoRegular,
                                                                        fontWeight:
                                                                            FontWeight.w700,
                                                                        fontSize:
                                                                            16,
                                                                        maxLines:
                                                                            3,
                                                                      ),
                                                                      flex: 0,
                                                                    )
                                                                  ],
                                                                )));
                                              })),
                                              Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            9.0,
                                                            0.0,
                                                            0.0,
                                                            BaseText(
                                                              text: userTestList[
                                                                      index]
                                                                  .scores[
                                                                      index3]
                                                                  .dateTaken,
                                                              textColor: ColorValues
                                                                  .labelColor,
                                                              fontFamily: AppConstants
                                                                  .stringConstant
                                                                  .latoItalic,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize: 12,
                                                              maxLines: 3,
                                                            )),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: userTestList[index]
                                                        .scores[index3]
                                                        .docUrl
                                                        .length >
                                                        0 ||
                                                        userTestList[index]
                                                            .scores[index3]
                                                            .imageUrl
                                                            .length >
                                                            0
                                                        ? InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              9.0,
                                                              0.0,
                                                              0.0,
                                                              BaseText(
                                                                text:
                                                                    'View attachment',
                                                                textColor:
                                                                    ColorValues
                                                                        .HEADING_COLOR_EDUCATION_2,
                                                                fontFamily: AppConstants
                                                                    .stringConstant
                                                                    .latoRegular,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600,
                                                                fontSize: 12,
                                                                maxLines: 3,
                                                              )),
                                                      onTap: () {
                                                        Navigator.of(context).push(new MaterialPageRoute(
                                                            builder: (BuildContext
                                                            context) =>
                                                                DocumentPerformance(
                                                                    userTestList[index]
                                                                        .scores[
                                                                    index3])));
                                                      },
                                                    ):SizedBox(),
                                                    flex: 0,
                                                  ),
                                                ],
                                              ),
                                              /*    userTestList[index]
                                                          .scores[index3]
                                                          .subjects
                                                          .length >
                                                      2
                                                  ? PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      InkWell(
                                                        child: Text(
                                                          userTestList[index]
                                                                  .scores[
                                                                      index3]
                                                                  .isShowMore
                                                              ? "Less"
                                                              : "More",
                                                          style: AppTextStyle
                                                              .getDynamicStyleGroup(
                                                                  ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontType
                                                                      .Regular), */ /* TextStyle(
                                                              color:     ColorValues.BLUE_COLOR_BOTTOMBAR,fontFamily: Constant.customRegular,
                                                              fontSize: 16.0),*/ /*
                                                        ),
                                                        onTap: () {
                                                          if (userTestList[
                                                                  index]
                                                              .scores[index3]
                                                              .isShowMore)
                                                            userTestList[index]
                                                                .scores[index3]
                                                                .isShowMore = false;
                                                          else
                                                            userTestList[index]
                                                                .scores[index3]
                                                                .isShowMore = true;
                                                          setState(() {});
                                                        },
                                                      ))
                                                  : Container(
                                                      height: 0.0,
                                                    ),*/
                                            ],
                                          )),
                                        ],
                                      )));
                            })),
                          )),
                    ),

                    // CustomViews.getSepratorLine()
                  ],
                ),
              )));
    }

//============================================ grid view achevements nd core logic =====================================
    onTapAddEducationBtn() async {
      final result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              AddTestScoreWidgetPerformance(widget.profileInfoModal)));
      ;

      print(result);
      if (result == "push") {
        setState(() {
          isPerformChnges = "push";
        });
        testScoreApi(true);
      }
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChnges);
        },
        child: Scaffold(
            backgroundColor: Colors.white,
            bottomNavigationBar: Container(
                decoration: BoxDecoration(
                  color: AppConstants.colorStyle.white,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0x75CCDCF7),
                      blurRadius: 13,
                      spreadRadius: 13,
                    )
                  ],
                ),

                child: PaddingWrap.paddingfromLTRB(
                  20.0,
                  20.0,
                  20.0,
                  20.0,
              InkWell(
                  child: Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppConstants.colorStyle.lightBlue,
                        border: Border.all(
                            color: AppConstants.colorStyle.lightBlue),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Align(
                          alignment: Alignment.center,
                          // Align however you like (i.e .centerRight, centerLeft)
                          child: Text(
                            "Done",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: ColorValues.WHITE,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontSize: 18.0,
                            ),
                          ))),
              onTap: () async {
                Navigator.pop(context);
              }),
            )),
            floatingActionButton: Padding(
              padding: const EdgeInsets.only(bottom: 30),
              child: FloatingActionButton(
                  elevation: 0.0,
                  backgroundColor: Colors.transparent,
                  child: Image.asset(
                    "assets/png/add1.png",
                    width: 56.0,
                    height: 56.0,
                  ),
                  onPressed: () async {
                    onTapAddTestScore();
                  }),
            ),
            body: SafeArea(
              child: Column(
                children: <Widget>[
                  Expanded(
                      child: Column(
                    children: <Widget>[
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 20.0, right: 20, top: 20, bottom: 24),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  BaseText(
                                    text: 'Test score',
                                    textColor:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 28,
                                    maxLines: 1,
                                  ),
                                  const HelpButtonWidget(),
                                ],
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Align(
                                  alignment: Alignment.topLeft,
                                  child: BaseText(
                                    text: 'Add your test score',
                                    textColor:
                                        AppConstants.colorStyle.lightPurple,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    maxLines: 2,
                                  )),
                            ],
                          ),
                        ),
                        flex: 0,
                      ),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                              children: List.generate(userTestList.length,
                                  (int index) {
                            return getTestScoreListItem(index);
                          })),
                        ),
                        flex: 1,
                      )
                    ],
                  ))
                ],
              ),
            )));
  }
}
