import 'package:flutter/cupertino.dart';

class DrawerMenu {
  String title;
  String assetIcon;
  VoidCallback onTap;

  DrawerMenu({
    @required this.title,
    @required this.assetIcon,
    @required this.onTap,
  });
}
