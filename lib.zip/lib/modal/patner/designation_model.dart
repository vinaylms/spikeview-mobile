class DesignationModel {
  String status;
  List<DesignationModelResult> result;

  DesignationModel({this.status, this.result});

  DesignationModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<DesignationModelResult>();
      json['result'].forEach((v) {
        result.add(new DesignationModelResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DesignationModelResult {
  int categoryId;
  String name;
  String description;

  DesignationModelResult({this.categoryId, this.name, this.description});

  DesignationModelResult.fromJson(Map<String, dynamic> json) {
    categoryId = json['categoryId'];
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['categoryId'] = this.categoryId;
    data['name'] = this.name;
    data['description'] = this.description;
    return data;
  }
}
