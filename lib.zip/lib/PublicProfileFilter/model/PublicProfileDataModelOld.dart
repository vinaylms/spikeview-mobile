import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';

class PublicProfileDataModel {
  String status;
  Result result;

  PublicProfileDataModel({this.status, this.result});

  PublicProfileDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'].toString();
    result =
    json['result'] != null ?   Result.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class Result {
  String sId;
  String userId;
  String email;
  String profilePicture;
  String roleId;
  bool isActive;
  String organizationId;
  String gender;
  String dob;
  bool isArchived;
  String creationTime;
  bool isWizard;
  String zipCode;
  String country;
  String state;
  String city;
  bool isHide;

  // String referralPopupShowDate;
  String stage;

  // List<String> userInterest;
  //List<Role> role;
  String lastName;
  String firstName;
  String coverImage;
  String tagline;
  String summary;

//  bool isEmailSubscribed;
  String lastSeen;
  String referCode;

  // bool isLeaderboardDisplay;
  String badge;

  // String gamificationPoints;
  String badgeImage;
  Address address;
  bool ccToParents;
  String genderAtBirth;

//  bool requireParentApproval;
  String title;
  bool usCitizenOrPR;
  List<SocialLinks> socialLinks;
  String userType;
  Educations educations;
  bool isEducations;
  bool isSummary;
  bool isDisplaySocialEmail;
  bool isGpa;
  bool isSocialLinks;
  bool isBadges;
  bool isTestScore;
  bool isRecommendation;
  bool isSkillAndCertification;
  bool isInterests;
  bool isAccomplishment;
  List<Certificates> certificates;
  List<SkillID> skills;
  String  goalInterestInstitute;
  List<GoalInterests> goalInterests;
  List<LoveInterests> otherInterests;
  List<LoveInterests> loveInterests;
  List<LoveInterests> loveOtherInterests;
  Badges badges;
  List<TestScores> testScores;
  List<Recommendations> recommendations;
  static String type = "";

  Result(
      {this.sId,
        this.userId,
        this.email,
        this.profilePicture,
        this.roleId,
        this.isActive,
        this.organizationId,
        this.gender,
        this.dob,
        this.isArchived,
        this.creationTime,
        this.isWizard,
        this.zipCode,
        this.country,
        this.state,
        this.city,
        this.isHide,
        //  this.referralPopupShowDate,
        this.stage,
        //  this.userInterest,
        //   this.role,
        this.lastName,
        this.firstName,
        this.coverImage,
        this.tagline,
        this.summary,
        //  this.isEmailSubscribed,
        this.lastSeen,
        this.referCode,
        //   this.isLeaderboardDisplay,
        this.badge,
        //  this.gamificationPoints,
        this.badgeImage,
        this.address,
        this.ccToParents,
        this.genderAtBirth,
        //  this.requireParentApproval,
        this.title,
        this.usCitizenOrPR,
        this.socialLinks,
        this.userType,
        this.educations,
        this.isEducations,
        this.isSummary,
        this.isGpa,
        this.isDisplaySocialEmail,
        this.isSocialLinks,
        this.isBadges,
        this.isTestScore,
        this.isRecommendation,
        this.isSkillAndCertification,
        this.isInterests,
        this.isAccomplishment,
        this.certificates,
        this.skills,
        this.goalInterests,
        this.otherInterests,
        this.loveInterests,
        this.badges,
        this.testScores,
        this.recommendations});

  Result.fromJson(Map<String, dynamic> json) {
    try {
      socialLinks =   List<SocialLinks>();
      skills =   List<SkillID>();
      goalInterests =   List<GoalInterests>();
      otherInterests =   List<LoveInterests>();
      loveInterests =   List<LoveInterests>();
      certificates =   List<Certificates>();
      testScores =   List<TestScores>();
      recommendations =   List<Recommendations>();

      sId = json['_id'].toString();
      userId = json['userId'].toString();
      email = json['email'].toString();
      profilePicture = json['profilePicture'].toString();
      roleId = json['roleId'].toString();
      isActive = json['isActive'];
      organizationId = json['organizationId'].toString();
      gender = json['gender'].toString();
      if(gender=="Non-binary"||gender=="NonBinary"){
        gender="Non-Binary";
      }
      dob = json['dob'].toString();
      isArchived = json['isArchived'];
      creationTime = json['creationTime'].toString();
      isWizard = json['isWizard'];
      zipCode = json['zipCode'].toString();
      country = json['country'].toString();
      state = json['state'].toString();
      city = json['city'].toString();
      isHide = json['isHide'];
      // referralPopupShowDate = json['referralPopupShowDate'].toString();
      stage = json['stage'].toString();
      // userInterest = json['userInterest'].cast<String>();
      /* if (json['role'] != null) {
        role =   List<Role>();
        json['role'].forEach((v) {
          role.add(new Role.fromJson(v));
        });
      }*/

      lastName = json['lastName'].toString();
      firstName = json['firstName'].toString();
      coverImage = json['coverImage'].toString();
      tagline = json['tagline'].toString();
      summary = json['summary'].toString();
      // isEmailSubscribed = json['isEmailSubscribed'];
      lastSeen = json['lastSeen'].toString();
      referCode = json['referCode'].toString();
      // isLeaderboardDisplay = json['isLeaderboardDisplay'];
      badge = json['badge'].toString();
      // gamificationPoints = json['gamificationPoints'].toString();
      badgeImage = json['badgeImage'].toString();
      address = json['address'] != null
          ?   Address.fromJson(json['address'])
          : null;
      ccToParents = json['ccToParents'];
      genderAtBirth = json['genderAtBirth'].toString();
      // requireParentApproval = json['requireParentApproval'];
      title = json['title'].toString();
      usCitizenOrPR = json['usCitizenOrPR'];

      if (json['socialLinks'] != null) {
        json['socialLinks'].forEach((v) {
          socialLinks.add(new SocialLinks.fromJson(v));
        });
      }
      userType = json['userType'].toString();
      educations = json['educations'] != null && json["educations"].length > 0
          ?   Educations.fromJson(json['educations'])
          : null;
      print("Type++=======" + Result.type);
      isEducations = Result.type == "custom" ? true : json['isEducations'];
      isSummary = Result.type == "custom" ? true : json['isSummary'];
      isGpa = Result.type == "custom" ? true : json['isGpa'];
      isDisplaySocialEmail =
      Result.type == "custom" ? true : json['isDisplaySocialEmail'];
      isSocialLinks = Result.type == "custom" ? true : json['isSocialLinks'];
      isBadges = Result.type == "custom" ? true : json['isBadges'];
      isTestScore = Result.type == "custom" ? true : json['isTestScore'];
      isRecommendation =
      Result.type == "custom" ? true : json['isRecommendation'];
      isSkillAndCertification =
      Result.type == "custom" ? true : json['isSkillAndCertification'];
      isInterests = Result.type == "custom" ? true : json['isInterests'];
      isAccomplishment =
      Result.type == "custom" ? true : json['isAccomplishment'];

      if (json['certificates'] != null) {
        json['certificates'].forEach((v) {
          certificates.add(new Certificates.fromJson(v));
        });
      }
      if (json['skills'] != null) {
        json['skills'].forEach((v) {
          skills.add(new SkillID.fromJson(v));
        });
      }
      goalInterestInstitute= json['goalInterestInstitute'].toString();
      if (json['goal_interests'] != null) {
        json['goal_interests'].forEach((v) {
          goalInterests.add(new GoalInterests.fromJson(v));
        });
      }
      if (json['other_interests'] != null) {
        json['other_interests'].forEach((v) {
          otherInterests.add(new LoveInterests.fromJson(v));
        });
      }
      if (json['love_interests'] != null) {
        json['love_interests'].forEach((v) {
          loveInterests.add(new LoveInterests.fromJson(v));
        });
      }
      badges = json['badges'] != null && json["badges"].length > 0
          ?   Badges.fromJson(json['badges'])
          : null;

      if (json['testScores'] != null) {
        json['testScores'].forEach((v) {
          testScores.add(new TestScores.fromJson(v));
        });
      }
      if (json['recommendations'] != null) {
        json['recommendations'].forEach((v) {
          if (v['stage'] == "Added" && v['isActive'])
            recommendations.add(new Recommendations.fromJson(v));
        });
      }
    } catch (e) {
      print("ERRor data++++++++++++" + e.toString());
      e.toString();
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId.toString();
    data['userId'] = this.userId.toString();
    data['email'] = this.email.toString();
    data['profilePicture'] = this.profilePicture.toString();
    data['roleId'] = this.roleId.toString();
    data['isActive'] = this.isActive;
    data['organizationId'] = this.organizationId.toString();
    data['gender'] = this.gender.toString();
    data['dob'] = this.dob.toString();
    data['isArchived'] = this.isArchived;
    data['creationTime'] = this.creationTime.toString();
    data['isWizard'] = this.isWizard;
    data['zipCode'] = this.zipCode.toString();
    data['country'] = this.country.toString();
    data['state'] = this.state.toString();
    data['city'] = this.city.toString();
    data['isHide'] = this.isHide;
    //   data['referralPopupShowDate'] = this.referralPopupShowDate.toString();
    data['stage'] = this.stage.toString();
    /*  data['userInterest'] = this.userInterest.toString();
    if (this.role != null) {
      data['role'] = this.role.map((v) => v.toJson()).toList();
    }
*/
    data['lastName'] = this.lastName.toString();
    data['firstName'] = this.firstName.toString();
    data['coverImage'] = this.coverImage.toString();
    data['tagline'] = this.tagline.toString();
    data['summary'] = this.summary.toString();
    // data['isEmailSubscribed'] = this.isEmailSubscribed.toString();
    data['lastSeen'] = this.lastSeen.toString();
    data['referCode'] = this.referCode.toString();
    //data['isLeaderboardDisplay'] = this.isLeaderboardDisplay.toString();
    data['badge'] = this.badge.toString();
    //  data['gamificationPoints'] = this.gamificationPoints.toString();
    data['badgeImage'] = this.badgeImage.toString();
    if (this.address != null) {
      data['address'] = this.address.toJson();
    }
    data['ccToParents'] = this.ccToParents.toString();
    data['genderAtBirth'] = this.genderAtBirth.toString();
    //  data['requireParentApproval'] = this.requireParentApproval.toString();
    data['title'] = this.title.toString();
    data['usCitizenOrPR'] = this.usCitizenOrPR.toString();
    if (this.socialLinks != null) {
      data['socialLinks'] = this.socialLinks.map((v) => v.toJson()).toList();
    }
    data['userType'] = this.userType.toString();
    if (this.educations != null) {
      data['educations'] = this.educations.toJson();
    }
    data['isEducations'] = this.isEducations;
    data['isSummary'] = this.isSummary;
    data['isGpa'] = this.isGpa;
    data['isSocialLinks'] = this.isSocialLinks;
    data['isSocialLinks'] = this.isSocialLinks;
    data['isBadges'] = this.isBadges;
    data['isTestScore'] = this.isTestScore;
    data['isRecommendation'] = this.isRecommendation;
    data['isSkillAndCertification'] = this.isSkillAndCertification;
    data['isInterests'] = this.isInterests;
    data['isAccomplishment'] = this.isAccomplishment;
    if (this.certificates != null) {
      data['certificates'] = this.certificates.map((v) => v.toJson()).toList();
    }
    if (this.skills != null) {
      data['skills'] = this.skills.map((v) => v.toJson()).toList();
    }
    if (this.goalInterests != null) {
      data['goal_interests'] =
          this.goalInterests.map((v) => v.toJson()).toList();
    }
    if (this.otherInterests != null) {
      data['other_interests'] =
          this.otherInterests.map((v) => v.toJson()).toList();
    }
    if (this.loveInterests != null) {
      data['love_interests'] =
          this.loveInterests.map((v) => v.toJson()).toList();
    }
    if (this.badges != null) {
      data['badges'] = this.badges.toJson();
    }
    if (this.testScores != null) {
      data['testScores'] = this.testScores.map((v) => v.toJson()).toList();
    }
    if (this.recommendations != null) {
      data['recommendations'] =
          this.recommendations.map((v) => v.toJson()).toList();
    }
    return data;
  }

  List<int> toJsonRec() {
    List<int> dataList =   List();
    if (this.recommendations != null) {
      this.recommendations.map((v) {
        if (v.isProfileDisplay != null) if (v.isProfileDisplay) {
          dataList.add(v.recommendationId);
        }
      }).toList();
    }
    return dataList;
  }

  List<int> toJsonTestScore() {
    List<int> dataList =   List();
    if (this.testScores != null) {
      this.testScores.map((v) {
        dataList.addAll(v.toScore());
      }).toList();
    }
    return dataList;
  }

  List<int> toJsonCertificate() {
    List<int> dataList =   List();
    if (this.certificates != null) {
      this.certificates.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.index);
        }
      }).toList();
    }
    return dataList;
  }

  List<int> toJsonLink() {
    List<int> dataList =   List();
    if (this.socialLinks != null) {
      this.socialLinks.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.socialId);
        }
      }).toList();
    }
    return dataList;
  }
}

class Badges {
  List<Requests> requests;
  List<Collections> collections;

  Badges({this.requests, this.collections});

  Badges.fromJson(Map<String, dynamic> json) {
    requests =   List<Requests>();
    collections =   List<Collections>();
    if (json['requests'] != null) {
      json['requests'].forEach((v) {
        requests.add(new Requests.fromJson(v));
      });
    }
    if (json['collections'] != null) {
      json['collections'].forEach((v) {
        collections.add(new Collections.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    if (this.requests != null) {
      data['requests'] = this.requests.map((v) => v.toJson()).toList();
    }
    if (this.collections != null) {
      data['collections'] = this.collections.map((v) => v.toJson()).toList();
    }
    return data;
  }

  List<int> toJsonBadge() {
    List<int> dataList =   List();
    if (this.collections != null) {
      this.collections.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.badgeReqId);
        }
      }).toList();
    }
    return dataList;
  }
}

class Requests {
  String badgeReqId;
  String badgeId;
  String message;
  String status;
  String date;
  String name;
  String image;
  String companyName;
  bool isProfileDisplay;

  Requests(
      {this.badgeReqId,
        this.badgeId,
        this.message,
        this.status,
        this.date,
        this.name,
        this.image,
        this.companyName,
        this.isProfileDisplay});

  Requests.fromJson(Map<String, dynamic> json) {
    try {
      isProfileDisplay = Result.type == "custom"
          ? true
          : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
      badgeReqId = json['badgeReqId'].toString();
      badgeId = json['badgeId'].toString();
      message = json['message'].toString();
      status = json['status'].toString();
      date = json['date'].toString();
      name = json['name'].toString();
      image = json['image'].toString();
      companyName = json['companyName'].toString();
    } catch (e) {}
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['badgeReqId'] = this.badgeReqId;
    data['badgeId'] = this.badgeId;
    data['message'] = this.message;
    data['status'] = this.status;
    data['date'] = this.date;
    data['name'] = this.name;
    data['image'] = this.image;
    data['companyName'] = this.companyName;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Collections {
  int badgeReqId;
  String badgeId;
  String message;
  String status;
  String date;
  String name;
  String image;
  String companyName;
  bool isProfileDisplay;

  Collections(
      {this.badgeReqId,
        this.badgeId,
        this.message,
        this.status,
        this.date,
        this.name,
        this.image,
        this.companyName,
        this.isProfileDisplay});

  Collections.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    badgeReqId = json['badgeReqId'];
    badgeId = json['badgeId'].toString();
    message = json['message'].toString();
    status = json['status'].toString();
    date = json['date'].toString();
    name = json['name'].toString();
    image = json['image'].toString();
    companyName = json['companyName'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['badgeReqId'] = this.badgeReqId;
    data['badgeId'] = this.badgeId;
    data['message'] = this.message;
    data['status'] = this.status;
    data['date'] = this.date;
    data['name'] = this.name;
    data['image'] = this.image;
    data['companyName'] = this.companyName;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Role {
  String id;

  Role({this.id});

  Role.fromJson(Map<String, dynamic> json) {
    id = json['id'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['id'] = this.id;
    return data;
  }
}

class Parents {
  String userId;
  String zipCode;
  String gender;
  String dob;
  String lastName;
  String firstName;
  String email;

  Parents(
      {this.userId,
        this.zipCode,
        this.gender,
        this.dob,
        this.lastName,
        this.firstName,
        this.email});

  Parents.fromJson(Map<String, dynamic> json) {
    userId = json['userId'].toString();
    zipCode = json['zipCode'].toString();
    gender = json['gender'].toString();
    dob = json['dob'].toString();
    lastName = json['lastName'].toString();
    firstName = json['firstName'].toString();
    email = json['email'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['userId'] = this.userId;
    data['zipCode'] = this.zipCode;
    data['gender'] = this.gender;
    data['dob'] = this.dob;
    data['lastName'] = this.lastName;
    data['firstName'] = this.firstName;
    data['email'] = this.email;
    return data;
  }
}

class Address {
  String zip;
  String country;
  String state;
  String city;
  String street2;
  String street1;

  Address(
      {this.zip,
        this.country,
        this.state,
        this.city,
        this.street2,
        this.street1});

  Address.fromJson(Map<String, dynamic> json) {
    zip = json['zip'].toString();
    country = json['country'].toString();
    state = json['state'].toString();
    city = json['city'].toString();
    street2 = json['street2'].toString();
    street1 = json['street1'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['zip'] = this.zip;
    data['country'] = this.country;
    data['state'] = this.state;
    data['city'] = this.city;
    data['street2'] = this.street2;
    data['street1'] = this.street1;
    return data;
  }
}

class SocialLinks {
  int socialId;
  String socialUrl;
  String socialName;
  String image;
  bool isProfileDisplay;

  SocialLinks(
      {this.socialId,
        this.socialUrl,
        this.socialName,
        this.image,
        this.isProfileDisplay});

  SocialLinks.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    socialId = json['socialId'];
    socialUrl = json['socialUrl'].toString();
    socialName = json['socialName'].toString();

    image = json['image'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['socialId'] = this.socialId;
    data['socialUrl'] = this.socialUrl;
    data['socialName'] = this.socialName;
    data['image'] = this.image;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Educations {
  List<Schools> schools;
  List<Colleges> colleges;

  Educations({this.schools, this.colleges});

  Educations.fromJson(Map<String, dynamic> json) {
    schools =   List<Schools>();
    colleges =   List<Colleges>();
    if (json['schools'] != null) {
      json['schools'].forEach((v) {
        schools.add(new Schools.fromJson(v));
      });
    }
    if (json['colleges'] != null) {
      json['colleges'].forEach((v) {
        colleges.add(new Colleges.fromJson(v));
      });
    }
  }

  List<int> toJson() {
    List<int> dataList =   List();
    if (this.schools != null) {
      this.schools.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.educationId);
        }
      }).toList();
    }

    if (this.colleges != null) {
      this.colleges.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.educationId);
        }
      }).toList();
    }

    return dataList;
  }

  List<int> toSchool() {
    List<int> dataList =   List();
    if (this.schools != null) {
      this.schools.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.educationId);
        }
      }).toList();
    }

    return dataList;
  }

  List<int> toCollege() {
    List<int> dataList =   List();

    if (this.colleges != null) {
      this.colleges.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.educationId);
        }
      }).toList();
    }

    return dataList;
  }
}

class Schools {
  String sId;
  int educationId;
  String organizationId;
  String userId;
  String institute;
  String city;
  String logo;
  String fromGrade;
  String toGrade;
  String fromYear;
  String toYear;
  String description;

  // bool isActive;
  String type;
  bool isProfileDisplay;
  String gpa;
  String outOfGpa;

  Schools(
      {this.sId,
        this.educationId,
        this.organizationId,
        this.userId,
        this.institute,
        this.city,
        this.logo,
        this.fromGrade,
        this.toGrade,
        this.fromYear,
        this.toYear,
        this.description,
        //  this.isActive,
        this.type,
        this.isProfileDisplay,
        this.gpa,
        this.outOfGpa});

  Schools.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    sId = json['_id'].toString();
    educationId = json['educationId'];
    organizationId = json['organizationId'].toString();
    userId = json['userId'].toString();
    institute = json['institute'].toString();
    city = json['city'].toString();
    logo = json['logo'].toString();
    fromGrade = json['fromGrade'].toString();
    toGrade = json['toGrade'].toString();
    fromYear = json['fromYear'].toString();
    toYear = json['toYear'].toString();
    description = json['description'].toString();
    //  isActive = json['isActive'];
    type = json['type'].toString();

    gpa = json['gpa'].toString() == "null" ? "" : json['gpa'].toString();
    outOfGpa = json['outOfGpa'].toString() == "null"
        ? ""
        : json['outOfGpa'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['educationId'] = this.educationId;
    data['organizationId'] = this.organizationId;
    data['userId'] = this.userId;
    data['institute'] = this.institute;
    data['city'] = this.city;
    data['logo'] = this.logo;
    data['fromGrade'] = this.fromGrade;
    data['toGrade'] = this.toGrade;
    data['fromYear'] = this.fromYear;
    data['toYear'] = this.toYear;
    data['description'] = this.description;
    //data['isActive'] = this.isActive;
    data['type'] = this.type;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Colleges {
  String sId;
  int educationId;
  String organizationId;
  String userId;
  String institute;
  String city;
  String logo;
  String fromYear;
  String toYear;

  //bool isActive;
  String gpa;
  String degree;
  String major;
  String minor;
  String graduationYear;
  String certifications;
  String year;
  String isWeighted;
  String outOfGpa;
  String otherDegree;
  String type;
  bool isProfileDisplay;

  Colleges(
      {this.sId,
        this.educationId,
        this.organizationId,
        this.userId,
        this.institute,
        this.city,
        this.logo,
        this.fromYear,
        this.toYear,
        // this.isActive,
        this.gpa,
        this.degree,
        this.major,
        this.minor,
        this.graduationYear,
        this.certifications,
        this.year,
        this.isWeighted,
        this.outOfGpa,
        this.otherDegree,
        this.type,
        this.isProfileDisplay});

  Colleges.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    sId = json['_id'].toString();
    educationId = json['educationId'];
    organizationId = json['organizationId'].toString();
    userId = json['userId'].toString();
    institute = json['institute'].toString();
    city = json['city'].toString();
    logo = json['logo'].toString();
    fromYear = json['fromYear'].toString();
    toYear = json['toYear'].toString();
    // isActive = json['isActive'];
    gpa = json['gpa'].toString() == "null" ? "" : json['gpa'].toString();
    degree = json['degree'].toString().trim();
    major = json['major'].toString().trim();
    minor = json['minor'].toString().trim();
    graduationYear = json['graduationYear'].toString();
    certifications = json['certifications'].toString().trim();
    year = json['year'].toString();
    isWeighted = json['isWeighted'].toString();
    outOfGpa = json['outOfGpa'].toString() == "null"
        ? ""
        : json['outOfGpa'].toString();
    otherDegree = json['otherDegree'].toString();
    type = json['type'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['educationId'] = this.educationId;
    data['organizationId'] = this.organizationId;
    data['userId'] = this.userId;
    data['institute'] = this.institute;
    data['city'] = this.city;
    data['logo'] = this.logo;
    data['fromYear'] = this.fromYear;
    data['toYear'] = this.toYear;
    //data['isActive'] = this.isActive;
    data['gpa'] = this.gpa;
    data['degree'] = this.degree;
    data['major'] = this.major;
    data['minor'] = this.minor;
    data['graduationYear'] = this.graduationYear;
    data['certifications'] = this.certifications;
    data['year'] = this.year;
    data['isWeighted'] = this.isWeighted;
    data['outOfGpa'] = this.outOfGpa;
    data['otherDegree'] = this.otherDegree;
    data['type'] = this.type;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Certificates {
  int index;
  String date;
  String image;
  String title;
  bool isProfileDisplay;

  Certificates(
      {this.index, this.date, this.image, this.title, this.isProfileDisplay});

  Certificates.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    index = json['index'];
    date = json['date'].toString();
    image = json['image'].toString();
    title = json['title'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['index'] = this.index;
    data['date'] = this.date;
    data['image'] = this.image;
    data['title'] = this.title;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Skills {
  String name;
  String hobbyId;

  Skills({this.name, this.hobbyId});

  Skills.fromJson(Map<String, dynamic> json) {
    name = json['name'].toString();
    hobbyId = json['hobbyId'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['name'] = this.name;
    data['hobbyId'] = this.hobbyId;
    return data;
  }
}

class TestScores {
  String testId;
  String name;
  bool isProfileDisplay;
  List<Scores> scores;

  TestScores({this.testId, this.name, this.isProfileDisplay, this.scores});

  TestScores.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    testId = json['testId'].toString();
    name = json['name'].toString();

    if (json['scores'] != null) {
      scores =   List<Scores>();
      json['scores'].forEach((v) {
        scores.add(new Scores.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['testId'] = this.testId;
    data['name'] = this.name;
    data['isProfileDisplay'] = this.isProfileDisplay;
    if (this.scores != null) {
      data['scores'] = this.scores.map((v) => v.toJson()).toList();
    }
    return data;
  }

  List<int> toScore() {
    List<int> dataList =   List();
    if (this.scores != null) {
      this.scores.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.userTestId);
        }
      }).toList();
    }
    return dataList;
  }
}

class Scores {
  String sId;
  int userTestId;
  String testId;
  String userId;
  String dateTaken;
  List<String> imageUrl;
  List<String> docUrl;
  List<Subjects> subjects;
  String name;
  bool isProfileDisplay;

  Scores(
      {this.sId,
        this.userTestId,
        this.testId,
        this.userId,
        this.dateTaken,
        this.imageUrl,
        this.docUrl,
        this.subjects,
        this.name,
        this.isProfileDisplay});

  Scores.fromJson(Map<String, dynamic> json) {
    isProfileDisplay = Result.type == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    sId = json['_id'].toString();
    userTestId = json['userTestId'];
    testId = json['testId'].toString();
    userId = json['userId'].toString();
    dateTaken = json['dateTaken'].toString();
    imageUrl = json['imageUrl'].cast<String>();
    if (json['docUrl'] != null) {
      docUrl =   List<Null>();
      json['docUrl'].forEach((v) {
        docUrl.add(v);
      });
    }
    if (json['subjects'] != null) {
      subjects =   List<Subjects>();
      json['subjects'].forEach((v) {
        subjects.add(new Subjects.fromJson(v));
      });
    }
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userTestId'] = this.userTestId;
    data['testId'] = this.testId;
    data['userId'] = this.userId;
    data['dateTaken'] = this.dateTaken;
    data['imageUrl'] = this.imageUrl;
    if (this.docUrl != null) {
      data['docUrl'] = this.docUrl.map((v) => v).toList();
    }
    if (this.subjects != null) {
      data['subjects'] = this.subjects.map((v) => v.toJson()).toList();
    }
    data['name'] = this.name;
    data['isProfileDisplay'] = this.isProfileDisplay;
    return data;
  }
}

class Subjects {
  String sId;
  String scoreId;
  String testSubId;
  String score;
  String userTestId;
  String subject;
  String minScore;
  String maxScore;

  Subjects(
      {this.sId,
        this.scoreId,
        this.testSubId,
        this.score,
        this.userTestId,
        this.subject,
        this.minScore,
        this.maxScore});

  Subjects.fromJson(Map<String, dynamic> json) {
    sId = json['_id'].toString();
    scoreId = json['scoreId'].toString();
    testSubId = json['testSubId'].toString();
    score = json['score'].toString();
    userTestId = json['userTestId'].toString();
    subject = json['subject'].toString();
    minScore = json['minScore'].toString();
    maxScore = json['maxScore'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['scoreId'] = this.scoreId;
    data['testSubId'] = this.testSubId;
    data['score'] = this.score;
    data['userTestId'] = this.userTestId;
    data['subject'] = this.subject;
    data['minScore'] = this.minScore;
    data['maxScore'] = this.maxScore;
    return data;
  }
}

class Recommendations {
  String sId;
  int recommendationId;
  String userId;
  String recommenderId;
  String competencyTypeId;
  String level3Competency;
  String level2Competency;
  String title;
  String request;
  String recommendation;
  String stage;
  String interactionStartDate;
  String interactionEndDate;
  bool isActive;
  String requestedDate;
  String recommenderTitle;
  List<Asset> asset;
  List<Recommender> recommender;

  // User user;
  bool isProfileDisplay;

  Recommendations(
      {this.sId,
        this.recommendationId,
        this.userId,
        this.recommenderId,
        this.competencyTypeId,
        this.level3Competency,
        this.level2Competency,
        this.title,
        this.request,
        this.recommendation,
        this.stage,
        this.interactionStartDate,
        this.interactionEndDate,
        this.isActive,
        this.requestedDate,
        this.recommenderTitle,
        this.asset,
        this.recommender,
        //this.user,
        this.isProfileDisplay});

  Recommendations.fromJson(Map<String, dynamic> json) {
    try {
      isProfileDisplay = Result.type == "custom"
          ? true
          : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
      sId = json['_id'].toString();
      recommendationId = json['recommendationId'];
      userId = json['userId'].toString();
      recommenderId = json['recommenderId'].toString();
      competencyTypeId = json['competencyTypeId'].toString();
      level3Competency = json['level3Competency'].toString();
      level2Competency = json['level2Competency'].toString();
      title = json['title'].toString();
      request = json['request'].toString();
      recommendation = json['recommendation'].toString();
      stage = json['stage'].toString();
      interactionStartDate = json['interactionStartDate'].toString();
      interactionEndDate = json['interactionEndDate'].toString();
      isActive = json['isActive'];
      requestedDate = json['requestedDate'].toString();
      recommenderTitle = json['recommenderTitle'].toString();

      if (json['asset'] != null) {
        asset =   List<Asset>();
        json['asset'].forEach((v) {
          asset.add(new Asset.fromJson(v));
        });
      }

      if (json['recommender'] != null) {
        recommender =   List<Recommender>();
        json['recommender'].forEach((v) {
          recommender.add(new Recommender.fromJson(v));
        });
      }
      /*   user = json['user'] != null ?   User.fromJson(json['user']) : null;*/

    } catch (e) {
      print("Recommendations error+++++" + e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['recommendationId'] = this.recommendationId;
    data['userId'] = this.userId;
    data['recommenderId'] = this.recommenderId;
    data['competencyTypeId'] = this.competencyTypeId;
    data['level3Competency'] = this.level3Competency;
    data['level2Competency'] = this.level2Competency;
    data['title'] = this.title;
    data['request'] = this.request;
    data['recommendation'] = this.recommendation;
    data['stage'] = this.stage;
    data['interactionStartDate'] = this.interactionStartDate;
    data['interactionEndDate'] = this.interactionEndDate;
    data['isActive'] = this.isActive;
    data['requestedDate'] = this.requestedDate;
    data['recommenderTitle'] = this.recommenderTitle;
    data['isProfileDisplay'] = this.isProfileDisplay;

    if (this.asset != null) {
      data['asset'] = this.asset.map((v) => v.toJson()).toList();
    }

    if (this.recommender != null) {
      data['recommender'] = this.recommender.map((v) => v.toJson()).toList();
    }
    /* if (this.user != null) {
      data['user'] = this.user.toJson();
    }*/
    return data;
  }
}

class Asset {
  String file;
  String tag;
  String type;

  Asset({this.file, this.tag, this.type});

  Asset.fromJson(Map<String, dynamic> json) {
    file = json['file'].toString();
    tag = json['tag'].toString();
    type = json['type'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['file'] = this.file;
    data['tag'] = this.tag;
    data['type'] = this.type;
    return data;
  }
}

class SkillID {
  String hobbyId;
  String name;

  SkillID({this.hobbyId, this.name});

  SkillID.fromJson(Map<String, dynamic> json) {
    hobbyId = json['hobbyId'].toString();
    name = json['name'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['hobbyId'] = this.hobbyId;
    data['name'] = this.name;
    return data;
  }
}

class Recommender {
  String sId;
  String userId;
  String email;
  String password;
  String salt;
  String profilePicture;
  String roleId;
  bool isActive;

  // bool isPasswordChanged;
  String organizationId;
  String dob;
  String title;

  // String tempPassword;
  bool isArchived;
  String creationTime;
  String zipCode;

  // bool userLoginFirstTime;
  bool isHide;

//  String referralPopupShowDate;
  String stage;

  // String gamificationPoints;
  String badge;

  // String referCode;
  // List<IntroducingFeatures> introducingFeatures;
//  bool isLeaderboardDisplay;
  // String userType;
  // List<NotificationSettings> notificationSettings;
  // bool isEmailSubscribed;
  //List<Role> role;
  String lastName;
  String firstName;

  Recommender({
    this.sId,
    this.userId,
    this.email,
    this.password,
    this.salt,
    this.profilePicture,
    this.roleId,
    this.isActive,
    //  this.isPasswordChanged,
    this.organizationId,
    this.dob,
    this.title,
    //this.tempPassword,
    this.isArchived,
    this.creationTime,
    this.zipCode,
    //this.userLoginFirstTime,
    this.isHide,
    // this.referralPopupShowDate,
    this.stage,
    //  this.gamificationPoints,
    this.badge,
    //  this.referCode,
    //   this.introducingFeatures,
    //   this.isLeaderboardDisplay,
    // this.userType,
    //   this.notificationSettings,
    //  this.isEmailSubscribed,
    //   this.role,
    this.lastName,
    this.firstName,
  });

  Recommender.fromJson(Map<String, dynamic> json) {
    try {
      sId = json['_id'].toString();
      userId = json['userId'].toString();
      email = json['email'].toString();
      password = json['password'].toString();
      salt = json['salt'].toString();
      profilePicture = json['profilePicture'].toString();
      roleId = json['roleId'].toString();
      isActive = json['isActive'];
      // isPasswordChanged = json['isPasswordChanged'];
      organizationId = json['organizationId'].toString();
      dob = json['dob'].toString();
      title = json['title'].toString();
      // tempPassword = json['tempPassword'].toString();
      isArchived = json['isArchived'];
      creationTime = json['creationTime'].toString();
      zipCode = json['zipCode'].toString();
      //  userLoginFirstTime = json['userLoginFirstTime'];
      isHide = json['isHide'];
      // referralPopupShowDate = json['referralPopupShowDate'].toString();
      stage = json['stage'].toString();
      //  gamificationPoints = json['gamificationPoints'].toString();
      badge = json['badge'].toString();
      // referCode = json['referCode'].toString();

      /*  if (json['introducingFeatures'] != null) {
        introducingFeatures =   List<IntroducingFeatures>();
        json['introducingFeatures'].forEach((v) {
          introducingFeatures.add(new IntroducingFeatures.fromJson(v));
        });
      }
      isLeaderboardDisplay = json['isLeaderboardDisplay'];
      userType = json['userType'];

      if (json['notificationSettings'] != null) {
        notificationSettings =   List<NotificationSettings>();
        json['notificationSettings'].forEach((v) {
          notificationSettings.add(new NotificationSettings.fromJson(v));
        });
      }*/
      //  isEmailSubscribed = json['isEmailSubscribed'];

      /*  if (json['role'] != null) {
        role =   List<Role>();
        json['role'].forEach((v) {
          role.add(new Role.fromJson(v));
        });
      }
*/
      lastName = json['lastName'].toString();
      firstName = json['firstName'].toString();
    } catch (e) {
      print("Recommender error+++++++++++" + e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userId'] = this.userId;
    data['email'] = this.email;
    data['password'] = this.password;
    data['salt'] = this.salt;
    data['profilePicture'] = this.profilePicture;
    data['roleId'] = this.roleId;
    data['isActive'] = this.isActive;
    //  data['isPasswordChanged'] = this.isPasswordChanged;
    data['organizationId'] = this.organizationId;
    data['dob'] = this.dob;
    data['title'] = this.title;
    // data['tempPassword'] = this.tempPassword;
    data['isArchived'] = this.isArchived;
    data['creationTime'] = this.creationTime;
    data['zipCode'] = this.zipCode;
    //  data['userLoginFirstTime'] = this.userLoginFirstTime;
    data['isHide'] = this.isHide;
    //   data['referralPopupShowDate'] = this.referralPopupShowDate;
    data['stage'] = this.stage;
    // data['gamificationPoints'] = this.gamificationPoints;
    data['badge'] = this.badge;
    //  data['referCode'] = this.referCode;

    /* if (this.introducingFeatures != null) {
      data['introducingFeatures'] =
          this.introducingFeatures.map((v) => v.toJson()).toList();
    }
    data['isLeaderboardDisplay'] = this.isLeaderboardDisplay;
    data['userType'] = this.userType;

    if (this.notificationSettings != null) {
      data['notificationSettings'] =
          this.notificationSettings.map((v) => v.toJson()).toList();
    }
    data['isEmailSubscribed'] = this.isEmailSubscribed;

    if (this.role != null) {
      data['role'] = this.role.map((v) => v.toJson()).toList();
    }*/

    data['lastName'] = this.lastName;
    data['firstName'] = this.firstName;
    return data;
  }
}

class IntroducingFeatures {
  bool display;
  bool exploreOpportunity;
  bool gamification;
  bool communityPost;
  String roleId;

  IntroducingFeatures(
      {this.display,
        this.exploreOpportunity,
        this.gamification,
        this.communityPost,
        this.roleId});

  IntroducingFeatures.fromJson(Map<String, dynamic> json) {
    display = json['display'];
    exploreOpportunity = json['exploreOpportunity'];
    gamification = json['gamification'];
    communityPost = json['communityPost'];
    roleId = json['roleId'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['display'] = this.display;
    data['exploreOpportunity'] = this.exploreOpportunity;
    data['gamification'] = this.gamification;
    data['communityPost'] = this.communityPost;
    data['roleId'] = this.roleId;
    return data;
  }
}

class NotificationSettings {
  bool feedNotification;
  bool profileNotification;
  bool allNotification;
  String roleId;

  NotificationSettings(
      {this.feedNotification,
        this.profileNotification,
        this.allNotification,
        this.roleId});

  NotificationSettings.fromJson(Map<String, dynamic> json) {
    feedNotification = json['feedNotification'];
    profileNotification = json['profileNotification'];
    allNotification = json['allNotification'];
    roleId = json['roleId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['feedNotification'] = this.feedNotification;
    data['profileNotification'] = this.profileNotification;
    data['allNotification'] = this.allNotification;
    data['roleId'] = this.roleId.toString();
    return data;
  }
}

class User {
  String sId;
  String userId;
  String email;
  String password;
  String salt;
  String mobileNo;
  String profilePicture;
  String roleId;
  bool isActive;
  bool isPasswordChanged;
  String organizationId;
  String gender;
  String dob;
  bool isArchived;
  String creationTime;
  bool isWizard;
  String zipCode;
  String country;
  String state;
  String city;
  bool userLoginFirstTime;
  bool isHide;
  String referralPopupShowDate;
  String stage;
  List<String> userInterest;
  List<Role> role;
  List<Parents> parents;
  String lastName;
  String firstName;
  String coverImage;
  String tagline;
  String summary;
  bool isEducation;
  bool isEmailSubscribed;
  String lastSeen;
  bool isAchievement;
  List<CommunityPostSubscription> communityPostSubscription;
  String referCode;
  List<NotificationSettings> notificationSettings;
  bool isLeaderboardDisplay;
  List<IntroducingFeatures> introducingFeatures;
  String badge;
  String gamificationPoints;
  String badgeImage;
  Address address;
  bool ccToParents;
  String genderAtBirth;
  bool requireParentApproval;
  String title;
  bool usCitizenOrPR;
  List<SocialLinks> socialLinks;
  String userType;

  User(
      {this.sId,
        this.userId,
        this.email,
        this.password,
        this.salt,
        this.mobileNo,
        this.profilePicture,
        this.roleId,
        this.isActive,
        this.isPasswordChanged,
        this.organizationId,
        this.gender,
        this.dob,
        this.isArchived,
        this.creationTime,
        this.isWizard,
        this.zipCode,
        this.country,
        this.state,
        this.city,
        this.userLoginFirstTime,
        this.isHide,
        this.referralPopupShowDate,
        this.stage,
        this.userInterest,
        this.role,
        this.parents,
        this.lastName,
        this.firstName,
        this.coverImage,
        this.tagline,
        this.summary,
        this.isEducation,
        this.isEmailSubscribed,
        this.lastSeen,
        this.isAchievement,
        this.communityPostSubscription,
        this.referCode,
        this.notificationSettings,
        this.isLeaderboardDisplay,
        this.introducingFeatures,
        this.badge,
        this.gamificationPoints,
        this.badgeImage,
        this.address,
        this.ccToParents,
        this.genderAtBirth,
        this.requireParentApproval,
        this.title,
        this.usCitizenOrPR,
        this.socialLinks,
        this.userType});

  User.fromJson(Map<String, dynamic> json) {
    sId = json['_id'].toString();
    userId = json['userId'].toString();
    email = json['email'].toString();
    password = json['password'].toString();
    salt = json['salt'].toString();
    mobileNo = json['mobileNo'].toString();
    profilePicture = json['profilePicture'].toString();
    roleId = json['roleId'].toString();
    isActive = json['isActive'];
    isPasswordChanged = json['isPasswordChanged'];
    organizationId = json['organizationId'].toString();
    gender = json['gender'].toString();
    dob = json['dob'].toString();
    isArchived = json['isArchived'];
    creationTime = json['creationTime'].toString();
    isWizard = json['isWizard'];
    zipCode = json['zipCode'].toString();
    country = json['country'].toString();
    state = json['state'].toString();
    city = json['city'].toString();
    userLoginFirstTime = json['userLoginFirstTime'];
    isHide = json['isHide'];
    referralPopupShowDate = json['referralPopupShowDate'].toString();
    stage = json['stage'].toString();
    userInterest = json['userInterest'].cast<String>();
    if (json['role'] != null) {
      role =   List<Role>();
      json['role'].forEach((v) {
        role.add(new Role.fromJson(v));
      });
    }
    if (json['parents'] != null) {
      parents =   List<Parents>();
      json['parents'].forEach((v) {
        parents.add(new Parents.fromJson(v));
      });
    }
    lastName = json['lastName'].toString();
    firstName = json['firstName'].toString();

    coverImage = json['coverImage'].toString();
    tagline = json['tagline'].toString();
    summary = json['summary'].toString();
    isEducation = json['isEducation'];
    isEmailSubscribed = json['isEmailSubscribed'];
    lastSeen = json['lastSeen'].toString();
    isAchievement = json['isAchievement'];
    if (json['communityPostSubscription'] != null) {
      communityPostSubscription =   List<CommunityPostSubscription>();
      json['communityPostSubscription'].forEach((v) {
        communityPostSubscription
            .add(new CommunityPostSubscription.fromJson(v));
      });
    }
    referCode = json['referCode'];
    if (json['notificationSettings'] != null) {
      notificationSettings =   List<NotificationSettings>();
      json['notificationSettings'].forEach((v) {
        notificationSettings.add(new NotificationSettings.fromJson(v));
      });
    }
    isLeaderboardDisplay = json['isLeaderboardDisplay'];
    if (json['introducingFeatures'] != null) {
      introducingFeatures =   List<IntroducingFeatures>();
      json['introducingFeatures'].forEach((v) {
        introducingFeatures.add(new IntroducingFeatures.fromJson(v));
      });
    }
    badge = json['badge'].toString();
    gamificationPoints = json['gamificationPoints'].toString();
    badgeImage = json['badgeImage'].toString();
    address =
    json['address'] != null ?   Address.fromJson(json['address']) : null;
    ccToParents = json['ccToParents'];
    genderAtBirth = json['genderAtBirth'].toString();
    requireParentApproval = json['requireParentApproval'];
    title = json['title'].toString();
    usCitizenOrPR = json['usCitizenOrPR'];
    if (json['socialLinks'] != null) {
      socialLinks =   List<SocialLinks>();
      json['socialLinks'].forEach((v) {
        socialLinks.add(new SocialLinks.fromJson(v));
      });
    }
    userType = json['userType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userId'] = this.userId;
    data['email'] = this.email;
    data['password'] = this.password;
    data['salt'] = this.salt;
    data['mobileNo'] = this.mobileNo;
    data['profilePicture'] = this.profilePicture;
    data['roleId'] = this.roleId;
    data['isActive'] = this.isActive;
    data['isPasswordChanged'] = this.isPasswordChanged;
    data['organizationId'] = this.organizationId;
    data['gender'] = this.gender;
    data['dob'] = this.dob;
    data['isArchived'] = this.isArchived;
    data['creationTime'] = this.creationTime;
    data['isWizard'] = this.isWizard;
    data['zipCode'] = this.zipCode;
    data['country'] = this.country;
    data['state'] = this.state;
    data['city'] = this.city;
    data['userLoginFirstTime'] = this.userLoginFirstTime;
    data['isHide'] = this.isHide;
    data['referralPopupShowDate'] = this.referralPopupShowDate;
    data['stage'] = this.stage;
    data['userInterest'] = this.userInterest;
    if (this.role != null) {
      data['role'] = this.role.map((v) => v.toJson()).toList();
    }
    if (this.parents != null) {
      data['parents'] = this.parents.map((v) => v.toJson()).toList();
    }
    data['lastName'] = this.lastName;
    data['firstName'] = this.firstName;

    data['coverImage'] = this.coverImage;
    data['tagline'] = this.tagline;
    data['summary'] = this.summary;
    data['isEducation'] = this.isEducation;
    data['isEmailSubscribed'] = this.isEmailSubscribed;
    data['lastSeen'] = this.lastSeen;
    data['isAchievement'] = this.isAchievement;
    if (this.communityPostSubscription != null) {
      data['communityPostSubscription'] =
          this.communityPostSubscription.map((v) => v.toJson()).toList();
    }
    data['referCode'] = this.referCode;
    if (this.notificationSettings != null) {
      data['notificationSettings'] =
          this.notificationSettings.map((v) => v.toJson()).toList();
    }
    data['isLeaderboardDisplay'] = this.isLeaderboardDisplay;
    if (this.introducingFeatures != null) {
      data['introducingFeatures'] =
          this.introducingFeatures.map((v) => v.toJson()).toList();
    }
    data['badge'] = this.badge;
    data['gamificationPoints'] = this.gamificationPoints;
    data['badgeImage'] = this.badgeImage;
    if (this.address != null) {
      data['address'] = this.address.toJson();
    }
    data['ccToParents'] = this.ccToParents;
    data['genderAtBirth'] = this.genderAtBirth;
    data['requireParentApproval'] = this.requireParentApproval;
    data['title'] = this.title;
    data['usCitizenOrPR'] = this.usCitizenOrPR;
    if (this.socialLinks != null) {
      data['socialLinks'] = this.socialLinks.map((v) => v.toJson()).toList();
    }
    data['userType'] = this.userType;
    return data;
  }
}

class CommunityPostSubscription {
  bool isSubscribed;
  String roleId;

  CommunityPostSubscription({this.isSubscribed, this.roleId});

  CommunityPostSubscription.fromJson(Map<String, dynamic> json) {
    isSubscribed = json['isSubscribed'];
    roleId = json['roleId'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['isSubscribed'] = this.isSubscribed;
    data['roleId'] = this.roleId;
    return data;
  }
}
