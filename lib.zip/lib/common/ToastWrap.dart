import 'package:flutter/material.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class ToastWrap {
  static showToastForAccessDenied(msg, context) {
   /* Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                      color: Color(0xffFF0101),
                                      height: 1.2,
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: Constant.customRegular),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToastPending(msg, context) {
   /* Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 85.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToastGreen(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style: TextStyle(
                                    color: Color(0xff408738),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xff408738),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
    );
  }

  static showToastGreenDismissibleFalse(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
    });

    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style: TextStyle(
                                    color: Color(0xff408738),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xff408738),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
    );
  }

  static showToasSucess(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style: TextStyle(
                                    color: Color(0xff408738),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xff408738),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
    );
  }

  static showToasSucessWithPiush(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style: TextStyle(
                                    color: Color(0xff408738),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xff408738),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
    );
  }

  static showToastLong(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToastLongNew(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 7000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 75.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: *//*'ERROR: '*//* '',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
    );
  }

  static showToast(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                      color: Color(0xffFF0101),
                                      height: 1.2,
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: Constant.customRegular),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToastWithICon(context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(Constant.applicationContext);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: PaddingWrap.paddingfromLTRB(
                                    10.0,
                                    10.0,
                                    11.0,
                                    10.0,
                                    Image.asset(
                                      "assets/newDesignIcon/error.png",
                                      width: 22.0,
                                      height: 20.0,
                                    )),
                                flex: 0,
                              ),
                              Expanded(
                                  child: TextViewWrap.textViewMultiLine(
                                      "You have incomplete accomplishment(s) in your profile, kindly complete",
                                      TextAlign.start,
                                      Color(0XFF090909),
                                      14.0,
                                      FontWeight.normal,
                                      2),
                                  flex: 1)
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: "You have incomplete accomplishment(s) in your profile, kindly complete",
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToastWithPush(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(context);
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToas3(msg, context) {
   /* Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child:  GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style:  TextStyle(
                                    color:  Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style:  TextStyle(
                                          color:  Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToast2Sec(msg, context) {
   /* Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child:  GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style:  TextStyle(
                                    color:  Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style:  TextStyle(
                                          color:  Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static showToast1Sec(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child:  GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: ' ',
                                  style:  TextStyle(
                                    color:  Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style:  TextStyle(
                                          color:  Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showToastDialog(
      context: context,
      msg: msg,
      heading: "Warning!",
      headingColor: Color(0xffEB5757),
    );
  }

  static void showToastDialog({
    @required BuildContext context,
    @required String msg,
    String heading,
    Color headingColor,
  }) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            headingText: heading,
            negativeText: 'OK',
            isSucessPopup: true,
            msg: msg,
            headingTextColor: headingColor,
          );
        });
  }


  static showToastWithPushMultiLine(msg, context) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            headingText: msg,
            negativeText: 'OK',
            isSucessPopup: true,
            msg: msg,
            onNegativeTap: (){
              Navigator.pop(context);
            },
          );
        });



  }


}
