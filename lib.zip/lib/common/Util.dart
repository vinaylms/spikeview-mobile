import 'dart:io';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:confetti/confetti.dart';
import 'package:connectivity/connectivity.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'dart:async';

import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share/share.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/modal/ReferPointResponse.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/new_onboarding/onboarding_education_added_list.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/wizard/AllAccomplishmentListWidget.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:path/path.dart' as path;
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';

class Util {
  static ConfettiController _controllerConfetti = ConfettiController(
    duration: Duration(seconds: 3),
  );

  static TextStyle errorTextStyle =
  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR);
  static StreamController syncDoneController = StreamController.broadcast();

  static final List<String> timeList = [
    '12:00 AM',
    '12:30 AM',
    '01:00 AM',
    '01:30 AM',
    '02:00 AM',
    '02:30 AM',
    '03:00 AM',
    '03:30 AM',
    '04:00 AM',
    '04:30 AM',
    '05:00 AM',
    '05:30 AM',
    '06:00 AM',
    '06:30 AM',
    '07:00 AM',
    '07:30 AM',
    '08:00 AM',
    '08:30 AM',
    '09:00 AM',
    '09:30 AM',
    '10:00 AM',
    '10:30 AM',
    '11:00 AM',
    '11:30 AM',
    '12:00 PM',
    '12:30 PM',
    '01:00 PM',
    '01:30 PM',
    '02:00 PM',
    '02:30 PM',
    '03:00 PM',
    '03:30 PM',
    '04:00 PM',
    '04:30 PM',
    '05:00 PM',
    '05:30 PM',
    '06:00 PM',
    '06:30 PM',
    '07:00 PM',
    '07:30 PM',
    '08:00 PM',
    '08:30 PM',
    '09:00 PM',
    '09:30 PM',
    '10:00 PM',
    '10:30 PM',
    '11:00 PM',
    '11:30 PM',
  ].toList();




  static onTapViewTimeLine(context,String screenName,{String userId}) async {
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => EducationAddedWeight(
          mProfileInfoModal: null,
          screenName:screenName?? "custom",
          userId:userId??'' ,
        )));
  }

  static onTokenExpired(context) async {
    // setState(() {
    print("onTokenExpired++++");
    Constant.isAlreadyLoggedIn = false;
    // });
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    prefs.setString(UserPreference.NAME, "");
    prefs.setString(UserPreference.COMPANY_NAME_PATH, "");

    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });

    GlobalSocketConnection.socket.emit("disconnect2", []);
    bloc.resetData(prefs);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }

  static String showAcceptButton(
      SharedPreferences prefs, schoolId, searchUserAccessConnection) {
    if (schoolId == null) {
      schoolId = "";
    }

    if (prefs.getBool(UserPreference.IS_SCHOOL)) {
      if (prefs.getString(UserPreference.ACCESS_CONTROL_CONNECTION) ==
          "schoolCommunity") {
        if (schoolId == prefs.getString(UserPreference.SCHOOL_CODE)) {
          return "true";
        } else {
          return "false";
        }
      } else {
        return "true";
      }
    } else {
      if (searchUserAccessConnection == "schoolCommunity") {
        return "false";
      } else {
        return "true";
      }
    }
  }

  static String showJoinGroupButton(
      SharedPreferences prefs, schoolId, actionType) {
    if (schoolId == null) {
      schoolId = "";
    }
    print("actionType School code++++" + actionType);
    if (actionType == Constant.JOIN_GROUP) {
      if (prefs.getBool(UserPreference.IS_SCHOOL)) {
        if (prefs.getString(UserPreference.ACCESS_CONTROL_GROUP_TYPE) ==
            "schoolCommunity") {
          print("School code++++" +
              schoolId +
              "  " +
              prefs.getString(UserPreference.SCHOOL_CODE));
          if (schoolId == prefs.getString(UserPreference.SCHOOL_CODE)) {
            return "true";
          } else {
            return "false";
          }
        } else {
          return "true";
        }
      } else {
        return "true";
      }
    } else {
      return "true";
    }
  }

  static Widget getStudentBadge12(String badge, String badgeImage) {
    return Align(
      alignment: Alignment.center,
      child: badgeImage != '' && badgeImage != 'null' && badgeImage != null
          ? Padding(
          padding: const EdgeInsets.only(left: 3.0,top: 3),
          child: CachedNetworkImage(
            height: 12,
            width: 12,
            imageUrl: Constant.IMAGE_PATH + '$badgeImage',
            fit: BoxFit.cover,
            placeholder: (context, url) =>
                _loader(context, "assets/gamification/badge.png", 12, 12),
            errorWidget: (context, url, error) =>
                _error("assets/gamification/badge.png", 12, 12),
          ))
          : Container(
        height: 0.0,
        width: 0.0,
      ),
    );
  }

  static Widget getStudentBadge15(String badge, String badgeImage) {
    return Align(
      alignment: Alignment.center,
      child: badgeImage != '' && badgeImage != 'null' && badgeImage != null
          ? Padding(
          padding: const EdgeInsets.only(left: 3.0,top: 3),
          child: CachedNetworkImage(
            height: 18,
            width: 18,
            imageUrl: Constant.IMAGE_PATH + '$badgeImage',
            fit: BoxFit.cover,
            placeholder: (context, url) =>
                _loader(context, "assets/gamification/badge.png", 12, 12),
            errorWidget: (context, url, error) =>
                _error("assets/gamification/badge.png", 12, 12),
          ))
          : Container(
        height: 0.0,
        width: 0.0,
      ),
    );
  }


  static Widget getStudentBadge12New(String badge, String badgeImage) {
    return Align(
      alignment: Alignment.center,
      child: badgeImage != '' && badgeImage != 'null' && badgeImage != null
          ? Padding(
          padding: const EdgeInsets.only(left: 3.0,top: 3),
          child: CachedNetworkImage(
            height: 18,
            width: 18,
            imageUrl: Constant.IMAGE_PATH + '$badgeImage',
            fit: BoxFit.cover,
            placeholder: (context, url) =>
                _loader(context, "assets/gamification/badge.png", 12, 12),
            errorWidget: (context, url, error) =>
                _error("assets/gamification/badge.png", 12, 12),
          ))
          : Container(
        height: 0.0,
        width: 0.0,
      ),
    );
  }

  static Widget getStudentBadgeRichText(String badge, String badgeImage) {
    return badgeImage != '' && badgeImage != 'null' && badgeImage != null
        ? Padding(
        padding: const EdgeInsets.only(left: 3.0,top: 3),
        child: CachedNetworkImage(
          height: 12,
          width: 12,
          imageUrl: Constant.IMAGE_PATH +
              //'sv_1/profile1.png',
              '$badgeImage',
          fit: BoxFit.cover,
          placeholder: (context, url) =>
              _loader(context, "assets/gamification/badge.png", 12, 12),
          errorWidget: (context, url, error) =>
              _error("assets/gamification/badge.png", 12, 12),
        ))
        : Container(height: 0.0, width: 0.0);
  }

  static String getPhoneNoFormate(String mobileNo) {
    if (mobileNo != '' && mobileNo.toString() != 'null') {
      if (mobileNo.toString().length > 7)
        return '${mobileNo.substring(0, 3)} ${mobileNo.substring(3, 7)} ${mobileNo.substring(7)}';
      else if (mobileNo.toString().length > 3)
        return '${mobileNo.substring(0, 3)} ${mobileNo.substring(3)}';
      else
        return mobileNo;
    }
    return '';
  }

  static Widget getStudentBadgeRichTextWithPadding(
      String badge, String badgeImage) {
    return badgeImage != '' && badgeImage != 'null' && badgeImage != null
        ? Padding(
        padding: const EdgeInsets.only(left: 5.0, bottom: 2),
        child: CachedNetworkImage(
          height: 12,
          width: 12,
          imageUrl: Constant.IMAGE_PATH +
              //'sv_1/profile1.png',
              '$badgeImage',
          fit: BoxFit.cover,
          placeholder: (context, url) =>
              _loader(context, "assets/gamification/badge.png", 12, 12),
          errorWidget: (context, url, error) =>
              _error("assets/gamification/badge.png", 12, 12),
        ))
        : Container(height: 0.0, width: 0.0);
  }

  static onTapSignOut(context, prefs) async {
    Constant.isAlreadyLoggedIn = false;
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });

    GlobalSocketConnection.socket.emit("disconnect2", []);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }

  static Future apiCallForLogout(context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
          "roleId": prefs.getString(UserPreference.ROLE_ID)
        };
        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut(context, prefs);
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut(context, prefs);
            }
          }
        } else {
          onTapSignOut(context, prefs);
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut(context, prefs);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  static bool showUpdateDialog(
      context, bool isRestrict, String upgradeMessage) {
    if (isRestrict == null) {
      isRestrict = false;
    }
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: SafeArea(
                child: Scaffold(
                  backgroundColor: isRestrict
                      ? Colors.black.withOpacity(.7)
                      : Colors.transparent,
                  body: Stack(
                    children: <Widget>[
                      Positioned(
                          right: 0.0,
                          bottom: 60.0,
                          left: 0.0,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                            child: Center(
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: TextViewWrap.textViewMultiLine(
                                          upgradeMessage,
                                          TextAlign.start,
                                          Colors.white,
                                          12.0,
                                          FontWeight.normal,
                                          3),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              30.0, 0.0, 15.0, 0.0),
                                          child: Center(
                                            child: TextViewWrap.textViewMultiLine(
                                                isRestrict ? "Quit" : "Close",
                                                TextAlign.center,
                                                Colors.white,
                                                12.0,
                                                FontWeight.normal,
                                                3),
                                          ),
                                        ),
                                        onTap: () {
                                          if (isRestrict) {
                                            apiCallForLogout(context);
                                          } else {
                                            Navigator.of(context,
                                                rootNavigator: true)
                                                .pop('dialog');
                                          }
                                        },
                                      ),
                                      flex: 0,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0.0, 0.0, 15.0, 0.0),
                                            child: TextViewWrap.textViewMultiLine(
                                                "Upgrade",
                                                TextAlign.start,
                                                Colors.white,
                                                12.0,
                                                FontWeight.normal,
                                                3)),
                                        onTap: () {
                                          if (isRestrict) {
                                            if (Platform.isAndroid) {
                                              launch(
                                                  "https://play.google.com/store/apps/details?id=com.spikeview.spikeviewproject&hl=en_IN&gl=US");
                                            } else {
                                              launch(
                                                  "https://apps.apple.com/us/app/spikeview/id1480816432");
                                            }
                                          } else {
                                            Navigator.pop(context);
                                            if (Platform.isAndroid) {
                                              launch(
                                                  "https://play.google.com/store/apps/details?id=com.spikeview.spikeviewproject&hl=en_IN&gl=US");
                                            } else {
                                              launch(
                                                  "https://apps.apple.com/us/app/spikeview/id1480816432");
                                            }
                                          }
                                        },
                                      ),
                                      flex: 0,
                                    ),
                                  ]),
                            ),
                          )),
                    ],
                  ),
                ))));
  }

  static Future getDetailUsingZipCode(isShowLaoder, context, zipCode) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(
          context,
          "https://maps.googleapis.com/maps/api/geocode/json?address=Postcode$zipCode&&key=" +
              Constant.kGoogleApiKey,
          "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      print("parent=====" + response.toString());

      if (response != null) {
        if (response.statusCode == 200) {
          if (response.data['results'] != null) {
            String formatedAddress =
            response.data['results'][0]["formatted_address"];

            return formatedAddress;
          } else
            return "";
        }
      }
    } catch (e) {
      return "";
      print("issue shubh" + e.toString());

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  static Future<Response> getDataFromLatLong(
      isShowLaoder, context, lat, long) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);

      Response response = await ApiCalling2().apiCallMap(
          context,
          "https://maps.googleapis.com/maps/api/geocode/json?latlng=postal_code:$lat,$long&key=" +
              Constant.kGoogleApiKey,
          "get");

      print("zipAPi:===" +
          "https://maps.googleapis.com/maps/api/geocode/json?latlng=postal_code:$lat,$long&key=" +
          Constant.kGoogleApiKey);

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      print("parent=====" + response.toString());

      if (response != null) {
        if (response.statusCode == 200) {
          //apurva chnages for zip code validation start
          if (response.data['status'].toString() != "ZERO_RESULTS") {
            return response;
          } else
            return null;
        }
      }
    } catch (e) {
      print("issue shubh" + e.toString());
      return null;

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

//99999999
  static Future<Response> getDetailUsingZipCodeNew(
      isShowLaoder, context, zipCode) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCallMap(
          context,
          "https://maps.googleapis.com/maps/api/geocode/json?components=postal_code:$zipCode&address=Postcode$zipCode&key=" +
              Constant.kGoogleApiKey,
          "get");

      print("zipAPi:===" +
          "https://maps.googleapis.com/maps/api/geocode/json?components=postal_code:$zipCode&address=Postcode$zipCode&key=" +
          Constant.kGoogleApiKey);

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      print("parent=====" + response.toString());

      if (response != null) {
        if (response.statusCode == 200) {
          if (response.data['status'].toString() != "ZERO_RESULTS") {
            return response;
          } else
            return null;
        }
      }
    } catch (e) {
      return null;
    }
  }

  static String launchUrl(String type, String path) {
    if (type == "Url") {
      if (path.toLowerCase().contains("http")) {
        launch(path);
      } else {
        String url = "http://" + path;
        launch(url);
      }
    } else {
      print("data+++" + Constant.IMAGE_PATH);
      print("data+++" + path);
      launch(Constant.IMAGE_PATH + path);
    }
  }

  static String getConvertedDateStamp(String time) {
    print("date " + time);
    if (time != null && time != "" && time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  static String getConvertedDateTimeStamp(String time) {
    print("date " + time);
    if (time != "" && time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy | hh:mm a');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy | hh:mm a');
      return formatter.format(new DateTime.now());
    }
  }

  static String getConvertedDatetamp(String time) {
    print("date " + time);
    if (time != "" && time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  static String getConvertedTimeStamp(String time) {
    print("date " + time);
    if (time != "" && time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy | hh:mm a');
      String formatted = formatter.format(now);
      return formatted.split('|').last;
    } else {
      var formatter = DateFormat('MMM dd, yyyy | hh:mm a');
      return formatter.format(new DateTime.now()).split('|').last;
    }
  }

  static String getConvertedTimeForScheduleDate(int time) {
    if (time != null) {
      var now = DateTime.fromMillisecondsSinceEpoch(time);
      var formatter = DateFormat('hh:mm a');
      String formatted = formatter.format(now);
      return formatted.replaceAll("00:", "12:");
    } else {
      return "";
    }
  }

  static String getDate(DateTime date) {
    if (date != "null") {
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(date);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  static String getConvertedDateStampNew(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

/*  static String getConvertedDateStampNew(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }*/

  static String getConvertedDateStampNewSlash(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MM/dd/yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MM/dd/yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  static showErrorMsg(msg, context) {
    Timer _timer;
    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 60.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: RichText(
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: 'ERROR :',
                              style: TextStyle(
                                color: Color(0xffFF0101),
                                height: 1.2,
                                fontSize: 13.0,
                                fontWeight: FontWeight.bold,
                              ),
                              children: <TextSpan>[
                                TextSpan(
                                  text: msg,
                                  style: TextStyle(
                                      color: Color(0xffFF0101),
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.normal,
                                      fontFamily: Constant.customRegular),
                                )
                              ],
                            ),
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  static String formatTimeFromDateTime(DateTime date) {
    var parsedDate = date.toLocal();
    String formatDate = ""; //DateFormat('MMM d, yyyy').format(parsedDate);
    formatDate = '${DateFormat('hh:mm a').format(parsedDate)}';
    return formatDate;
  }

  static bool dobCheck(String time) {
    if (time != null && time != "" && time != "null") {
      int millis = int.tryParse(time);
      DateTime bod = DateTime.fromMillisecondsSinceEpoch(millis);
      int diffrenceInDob = DateTime.now().year - bod.year;
      print("dOB year +++++ ${bod.year}");
      print("current year +++++ ${new DateTime.now().year}");
      print("diffrenceInDob+day+++++" + diffrenceInDob.toString());

      DateTime currentDate = DateTime.now();
      int age = currentDate.year - bod.year;

      if (age > 13) {
        return true;
      }
      if (age == 13) {
        print("apurva equal" + '$age');
        int month1 = currentDate.month;
        int month2 = bod.month;
        if (month2 > month1) {
          print("apurva below" + '$age');
          return false;
        } else if (month1 == month2) {
          int day1 = currentDate.day;
          int day2 = bod.day;
          if (day2 > day1) {
            print("apurva below" + '$age');
            return false;
          } else {
            print("apurva equal or above" + '$age');
            return true;
          }
        } else {
          print("apurva equal or above" + '$age');
          return true;
        }
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  static int currentAge(DateTime bod, int ageRestriction) {
    int diffrenceInDob = DateTime.now().year - bod.year;
    DateTime currentDate = DateTime.now();
    int age = currentDate.year - bod.year;

    if (age > ageRestriction) {
      return diffrenceInDob;
    }
    if (age == ageRestriction) {
      print("apurva equal" + '$age');
      int month1 = currentDate.month;
      int month2 = bod.month;
      if (month2 > month1) {
        print("apurva below" + '$age');
        return ageRestriction;
      } else if (month1 == month2) {
        int day1 = currentDate.day;
        int day2 = bod.day;
        if (day2 > day1) {
          print("apurva below" + '$age');
          return ageRestriction;
        } else {
          print("apurva equal or above" + '$age');
          return diffrenceInDob;
        }
      } else {
        print("apurva equal or above" + '$age');
        return diffrenceInDob;
      }
    }

    return diffrenceInDob;
  }

  static onTapImageTile(
      {@required String tapedUserRole,
        @required String partnerUserId,
        @required BuildContext context,
        String pageName}) {
    if (pageName == null || pageName == "null" || pageName == "") {
      pageName = "";
    }
    //  if (partnerUserId != "1") {
    if (tapedUserRole == "1") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => UserProfileDashBoardForOther(
              partnerUserId, false, pageName, "1")));
    } else if (tapedUserRole == "2") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              ParentProfilePageWithHeader(partnerUserId, pageName)));
    } else if (tapedUserRole == "4") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              PatnerProfileWidgetForOtherUser(partnerUserId, pageName)));
    }
  }

  static String getFileExtension(String file) {
    return path.extension(file);
  }

  static List<Address> getLoCation(selectedCountries) {
    List<Address> locationList = List<Address>();

    for (int i = 0; i < selectedCountries.length; i++) {
      String zipcode = selectedCountries[i].zipcode.toString();
      String city = selectedCountries[i].city.toString();
      String country = selectedCountries[i].country.toString();
      String state = selectedCountries[i].state.toString();
      String name = selectedCountries[i].name.toString();

      locationList
          .add(new Address(name, "", city, state, country, zipcode, ''));
    }

    return locationList;
  }

  static List<String> fetchDataUsingURL(String url) {
    List<String> result = List();
    List<String> splitFromQuestion = url.split("?");

    List<String> splitFromAnd = splitFromQuestion[1].split("&");

    List<String> opportunityId = splitFromAnd[0].split("=");
    List<String> title = splitFromAnd[1].split("=");
    List<String> image = splitFromAnd[2].split("=");
    List<String> description = splitFromAnd[3].split("=");

    result.add(opportunityId[1]);
    result.add(title[1]);
    result.add(image[1]);
    result.add(description[1]);

    return result;
  }

  static void copyToClipboard(String toClipboard, context) {
    if (toClipboard.contains("https://spikeview.com") ||
        toClipboard.contains("HTTP://spikeview.com") ||
        toClipboard.contains("HTTPS://spikeview.com") ||
        toClipboard.contains("https://spikeview.com") ||
        toClipboard.contains("https://app.spikeview.com")) {
    } else {
      ClipboardData data = ClipboardData(text: toClipboard);
      Clipboard.setData(data);
      ToastWrap.showToasSucess('Copied to Clipboard.', context);
    }
  }

  static void copyToClipboardText(String toClipboard, context) {
    ClipboardData data = ClipboardData(text: toClipboard);
    Clipboard.setData(data);
    ToastWrap.showToasSucess('Copied to Clipboard.', context);
  }

  static void copyToClipboardTextWithoutToast(String toClipboard, context) {
    ClipboardData data = ClipboardData(text: toClipboard);
    Clipboard.setData(data);
  }

  static isOpportunitySharedView(String text) {
    if (text.contains("https://spikeview.com") ||
        text.contains("http://spikeview.com") ||
        text.contains("http://15.206.172.61:8000") ||
        text.contains("HTTP://spikeview.com") ||
        text.contains("HTTPS://spikeview.com") ||
        text.contains("https://spikeview.com") ||
        text.contains("http://app.spikeview.com") ||
        text.contains("https://app.spikeview.com"))
      return true;
    else
      return false;
  }

//write to app path
  static Future<void> writeToFile(ByteData data, String path) {
    final buffer = data.buffer;
    return File(path).writeAsBytes(
        buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
  }

  static void shareViaOtherApp(
      BuildContext context, String shareText, String shareSubject) {
    final RenderBox box = context.findRenderObject();
    Share.share(shareText,
        subject: shareSubject,
        sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size)
        .then((value) {
      print('Apurva inside shareViaOtherApp() after shaing the profile');
      return null;
    });
  }

  static Future<void> shareAppLinkViaOtherApp(
      BuildContext context, String referCode, String name) async {
    String appLinkShareContent = '';
    String appLink = '';
    String referralPoints = await apiCallGetReffer(context);
    String shareTag1 =
        'Build your profile, connect with students and find global opportunities';
    String shareTag2 = 'Hi, I want to invite and connect with you on spikeview.' +
        "\n\n" +
        'It\'s an awesome platform for students! We both get $referralPoints referral points so use the code below!';

    String shareRefferal = 'Referral Code: $referCode-1';
    String shareSubject =
        '${name.toString().trim()} is inviting you to spikeview!';
    String shareText = 'spikeview - Own Your Narrative';

    appLink = Constant.REFER_BASE_URL + "refer";

    appLinkShareContent = shareTag2 +
        "\n\n" +
        appLink +
        "\n" +
        shareRefferal +
        "\n\n" +
        shareText +
        "\n" +
        shareTag1;

    final RenderBox box = context.findRenderObject();

    Share.share(appLinkShareContent,
        subject: shareSubject,
        sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size);
  }

  static void shareAppLinkViaOtherAppParent(
      BuildContext context, String referCode, String name) {
    String appLinkShareContent = '';
    String appLink = '';
    String shareTag1 = 'Global Portfolio Platform for Students';
    String shareTag2 = 'Hi, I want to invite and connect with you on spikeview.' +
        "\n\n" +
        'It\'s an awesome platform for students and parents! Students can access amazing global opportunities and parents can connect and support their journey. Join now!!';

    //Referral Code
    String shareRefferal = 'Referral Code: $referCode-2';
    String shareSubject =
        '${name.toString().trim()} is inviting you to spikeview!';
    String shareText = 'spikeview - Own Your Narrative';

    appLink = Constant.REFER_BASE_URL + "refer";

    appLinkShareContent = shareTag2 +
        "\n\n" +
        appLink +
        "\n" +
        shareRefferal +
        "\n\n" +
        shareText +
        "\n" +
        shareTag1;

    final RenderBox box = context.findRenderObject();

    Share.share(appLinkShareContent,
        subject: shareSubject,
        sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size);
  }

  static Widget getConfettiWidget(
      BuildContext context, String msg, ConfettiController controllerConfetti) {
    controllerConfetti.play();

    return Container(
      child: Stack(
        children: <Widget>[
          Align(
            alignment: Alignment.center,
            child: true
                ? Padding(
              padding: const EdgeInsets.symmetric(horizontal: 0.0),
              child: Container(
                height: 38,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                      'assets/gamification/congrats_popup_bg.png',
                    ),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 8.0, horizontal: 8.0),
                  child: Center(
                    child: Text("$msg",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            fontFamily: Constant.TYPE_CUSTOMBOLD)),
                  ),
                ),
              ),
            )
                : Container(),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: ConfettiWidget(
                confettiController: controllerConfetti,
                canvas: Size(MediaQuery.of(context).size.width, 150),
                blastDirection: 0,
                particleDrag: 0.05,
                emissionFrequency: 0.05,
                numberOfParticles: 25,
                gravity: 0.05,
                minimumSize: Size(4, 4),
                maximumSize: Size(16, 6),
                shouldLoop: false,
                //displayTarget: true,
                colors: [
                  ColorValues.confetti1,
                  ColorValues.confetti2,
                  ColorValues.confetti3,
                  ColorValues.confetti4,
                  ColorValues.confetti5,
                  ColorValues.confetti6,
                  ColorValues.confetti7,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  static getConfettiWidgetAlert(msg, context) {
    Timer _timer;

    print("getConfettiWidgetAlert timer on");
    _controllerConfetti.play();
    _timer = Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");

      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              _timer.cancel();
              Navigator.pop(context);
              return Future.value(false);
            },
            child: GestureDetector(
              /*onHorizontalDragUpdate: (GestureDragUpdateCallback) {
              _timer.cancel();
              Navigator.pop(context);
            },*/
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 10.0,
                        top: 100.0,
                        left: 10.0,
                        child: Container(
                          //color: Colors.pinkAccent,
                          child: Stack(
                            children: <Widget>[
                              Align(
                                alignment: Alignment.center,
                                child: true
                                    ? Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 0.0, vertical: 20),
                                  child: Container(
                                    height: 55,
                                    width:
                                    MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                          'assets/gamification/congrats_popup_bg.png',
                                        ),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10.0,
                                          horizontal: 8.0),
                                      child: Center(
                                        child: Text("$msg",
                                            //"drg drgbrtkjer sdgv sdgv dv drsbv dabrd brdbrdeb rdbrdeber rdbfrde rbreb r brdbrae rdb rdb rdb drb  db d b rdb dsbs b da bda b db d bgbtrb trbt sdvsd dsvc sdc sdvs dvs dcsd  sdv sd vsd vsd sd vsd vsd r trbtr trb rtbt rbtr trbtrbtr rtgnbtrbtrbtr trbtrb tr brtbntrnrt trbtrbtr",
                                            maxLines: 4,
                                            softWrap: true,
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                fontWeight:
                                                FontWeight.w700,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMBOLD)),
                                      ),
                                    ),
                                  ),
                                )
                                    : Container(),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 16.0),
                                  child: ConfettiWidget(
                                    //blastDirectionality: BlastDirectionality.directional,
                                    confettiController: _controllerConfetti,
                                    canvas: Size(
                                        MediaQuery.of(context).size.width, 200),
                                    blastDirection: 0,
                                    particleDrag: 0.05,
                                    emissionFrequency: 0.05,
                                    numberOfParticles: 25,
                                    gravity: 0.05,
                                    minimumSize: Size(4, 4),
                                    maximumSize: Size(16, 6),
                                    shouldLoop: false,
                                    //displayTarget: true,
                                    colors: [
                                      ColorValues.confetti1,
                                      ColorValues.confetti2,
                                      ColorValues.confetti3,
                                      ColorValues.confetti4,
                                      ColorValues.confetti5,
                                      ColorValues.confetti6,
                                      ColorValues.confetti7,
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  static getConfettiWidgetAlertPush(msg, context) {
    print("getConfettiWidgetAlert timer on");
    _controllerConfetti.play();
    Timer _timer = Timer(const Duration(milliseconds: 3000), () {
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });
    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () => Future.value(false),
            child: GestureDetector(
              onHorizontalDragUpdate: (details) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 10.0,
                        top: 100.0,
                        left: 10.0,
                        child: Stack(
                          children: <Widget>[
                            Align(
                              alignment: Alignment.center,
                              child: true
                                  ? Container(
                                width:
                                MediaQuery.of(context).size.width,
                                clipBehavior: Clip.antiAlias,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                      'assets/gamification/congrats_popup_bg.png',
                                    ),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 17, horizontal: 29),
                                alignment: Alignment.center,
                                child: Text(
                                  "$msg",
                                  style: TextStyle(
                                    color: const Color(0xff27275A),
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: Constant.latoRegular,
                                  ),
                                ),
                              )
                                  : Container(),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 16.0),
                                child: ConfettiWidget(
                                  //blastDirectionality: BlastDirectionality.directional,
                                  confettiController: _controllerConfetti,
                                  canvas: Size(
                                      MediaQuery.of(context).size.width, 170),
                                  blastDirection: 0,
                                  particleDrag: 0.05,
                                  emissionFrequency: 0.05,
                                  numberOfParticles: 25,
                                  gravity: 0.05,
                                  minimumSize: Size(4, 4),
                                  maximumSize: Size(16, 6),
                                  shouldLoop: false,
                                  //displayTarget: true,
                                  colors: [
                                    ColorValues.confetti1,
                                    ColorValues.confetti2,
                                    ColorValues.confetti3,
                                    ColorValues.confetti4,
                                    ColorValues.confetti5,
                                    ColorValues.confetti6,
                                    ColorValues.confetti7,
                                  ],
                                ),
                              ),
                            ),
                          ],
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }




  static Widget getStudentBadgeProfileForDashBoard(
      String badge, String badgeImage) {
    return badgeImage != '' && badgeImage != 'null' && badgeImage != null
        ? Padding(
        padding: const EdgeInsets.only(left: 3.0,bottom: 3),
        child: CachedNetworkImage(
          height: 18,
          width: 18,
          imageUrl: Constant.IMAGE_PATH + '$badgeImage',
          fit: BoxFit.cover,
          placeholder: (context, url) =>
              _loader(context, "assets/gamification/badge.png", 12, 12),
          errorWidget: (context, url, error) =>
              _error("assets/gamification/badge.png", 12, 12),
        ))
        : Container(
      height: 0.0,
      width: 0.0,
    );
  }

  static Widget getStudentBadgeMember(
      String badge, String badgeImage) {
    return badgeImage != '' && badgeImage != 'null' && badgeImage != null
        ? Padding(
        padding: const EdgeInsets.only(left: 3.0,bottom: 0),
        child: CachedNetworkImage(
          height: 18,
          width: 18,
          imageUrl: Constant.IMAGE_PATH + '$badgeImage',
          fit: BoxFit.cover,
          placeholder: (context, url) =>
              _loader(context, "assets/gamification/badge.png", 12, 12),
          errorWidget: (context, url, error) =>
              _error("assets/gamification/badge.png", 12, 12),
        ))
        : Container(
      height: 0.0,
      width: 0.0,
    );
  }

  static Widget getStudentBadgeDashBoard(String badge, String badgeImage) {
    return badgeImage != '' && badgeImage != 'null' && badgeImage != null
        ? Padding(
        padding: const EdgeInsets.only(left: 3.0,top: 3),
        child: CachedNetworkImage(
          height: 18,
          width: 18,
          imageUrl: Constant.IMAGE_PATH + '$badgeImage',
          fit: BoxFit.cover,
          placeholder: (context, url) =>
              _loader(context, "assets/gamification/badge.png", 12, 12),
          errorWidget: (context, url, error) =>
              _error("assets/gamification/badge.png", 12, 12),
        ))
        : Container(
      height: 0.0,
      width: 0.0,
    );
  }

  static Widget getStudentBadgeProfile(String badge, String badgeImage) {
    return Align(
      alignment: Alignment.centerLeft,
      child: badgeImage != '' && badgeImage != 'null' && badgeImage != null
          ? Padding(
          padding: const EdgeInsets.only(left: 3.0,top: 3),
          child: CachedNetworkImage(
            height: 18,
            width: 18,
            imageUrl: Constant.IMAGE_PATH + '$badgeImage',
            fit: BoxFit.cover,
            placeholder: (context, url) =>
                _loader(context, "assets/gamification/badge.png", 12, 12),
            errorWidget: (context, url, error) =>
                _error("assets/gamification/badge.png", 12, 12),
          ))
          : Container(
        height: 0.0,
        width: 0.0,
      ),
    );
  }

  static Widget _loader(BuildContext context, String placeHolderImage,
      double width, double height) =>
      Center(
          child: SizedBox(
            width: width,
            height: height,
            child: Image.asset(
              placeHolderImage,
              fit: BoxFit.cover,
            ),
          ));

  static Widget _error(String placeHolderImage, double width, double height) {
    return SizedBox(
      width: width,
      height: height,
      child: Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  static updateGamificationPoints(RewardStatus rewardStatus) {
    if (rewardStatus != null) {
      print('inside gamification:: ${rewardStatus.msg}');
      syncDoneController.add(rewardStatus);
    }
  }

  static showRewardPoint(RewardStatus rewardStatus, BuildContext context) {
    if (rewardStatus != null && rewardStatus.display != null) {
      if (rewardStatus.display) {
        String message =
            "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        if (rewardStatus.type == 'earn_points')
          message =
          "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        else if (rewardStatus.type == 'earn_badge')
          message =
          "Congratulations! You have earned ${rewardStatus.badge} badge";
        else if (rewardStatus.type == 'remaining_points')
          message =
          "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        //Util.getConfettiWidgetAlert('Congratulations! ${rewardStatus.msg}',context);
        Util.getConfettiWidgetAlert('${rewardStatus.msg}', context);
        syncDoneController.add(rewardStatus);
      }
    }
  }

  static getConfettiWidgetAlertOnBoarding(
      msg, context, StudentDataModel studModel) {
    Timer _timer;

    print("getConfettiWidgetAlert timer on");
    _controllerConfetti.play();
    _timer = Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");

      Navigator.pop(context);
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
              AllAccomplishmentListWidget(studModel)));
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 10.0,
                        top: 100.0,
                        left: 10.0,
                        child: Container(
                          //color: Colors.pinkAccent,
                          child: Stack(
                            children: <Widget>[
                              Align(
                                alignment: Alignment.center,
                                child: true
                                    ? Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 0.0),
                                  child: Container(
                                    //height: 38,
                                    width:
                                    MediaQuery.of(context).size.width,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                          'assets/gamification/congrats_popup_bg.png',
                                        ),
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 10.0,
                                          horizontal: 8.0),
                                      child: Center(
                                        child: Text("$msg",
                                            //"drg drgbrtkjer sdgv sdgv dv drsbv dabrd brdbrdeb rdbrdeber rdbfrde rbreb r brdbrae rdb rdb rdb drb  db d b rdb dsbs b da bda b db d bgbtrb trbt sdvsd dsvc sdc sdvs dvs dcsd  sdv sd vsd vsd sd vsd vsd r trbtr trb rtbt rbtr trbtrbtr rtgnbtrbtrbtr trbtrb tr brtbntrnrt trbtrbtr",
                                            maxLines: 4,
                                            softWrap: true,
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14.0,
                                                fontWeight:
                                                FontWeight.w700,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMBOLD)),
                                      ),
                                    ),
                                  ),
                                )
                                    : Container(),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 16.0),
                                  child: ConfettiWidget(
                                    //blastDirectionality: BlastDirectionality.directional,
                                    confettiController: _controllerConfetti,
                                    canvas: Size(
                                        MediaQuery.of(context).size.width, 200),
                                    blastDirection: 0,
                                    particleDrag: 0.05,
                                    emissionFrequency: 0.05,
                                    numberOfParticles: 25,
                                    gravity: 0.05,
                                    minimumSize: Size(4, 4),
                                    maximumSize: Size(16, 6),
                                    shouldLoop: false,
                                    //displayTarget: true,
                                    colors: [
                                      ColorValues.confetti1,
                                      ColorValues.confetti2,
                                      ColorValues.confetti3,
                                      ColorValues.confetti4,
                                      ColorValues.confetti5,
                                      ColorValues.confetti6,
                                      ColorValues.confetti7,
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  static showRewardPointOnBoarding(RewardStatus rewardStatus,
      BuildContext context, StudentDataModel studModel) {
    if (rewardStatus != null) {
      if (rewardStatus.display) {
        String message =
            "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        if (rewardStatus.type == 'earn_points')
          message =
          "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        else if (rewardStatus.type == 'earn_badge')
          message =
          "Congratulations! You have earned ${rewardStatus.badge} badge";
        else if (rewardStatus.type == 'remaining_points')
          message =
          "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        Util.getConfettiWidgetAlertOnBoarding(
            '${rewardStatus.msg}', context, studModel);
        syncDoneController.add(rewardStatus);
      }
    }
  }

  static showRewardPointPush(RewardStatus rewardStatus, BuildContext context) {
    if (rewardStatus != null) {
      if (rewardStatus.display) {
        String message =
            "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        if (rewardStatus.type == 'earn_points')
          message =
          "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";
        else if (rewardStatus.type == 'earn_badge')
          message =
          "Congratulations! You have earned ${rewardStatus.badge} badge";
        else if (rewardStatus.type == 'remaining_points')
          message =
          "Congratulations! You have earned ${rewardStatus.gamificationPoints} points";

        Util.getConfettiWidgetAlertPush('${rewardStatus.msg}', context);
        syncDoneController.add(rewardStatus);
      }
    }
  }

  static Future<String> apiCallGetReffer(context) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling().apiCallWithAuthToken(
            context, Constant.ENDPOINT_REFER_POINTS, "get");

        print("Apurva Refer points" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];

            if (status == "Success") {
              ReferPointResponse apiResponse =
              ReferPointResponse.fromJson(response.data);
              for (int i = 0; i < apiResponse.result[0].actions.length; i++) {
                if (apiResponse.result[0].actions[i].actionId == 2) {
                  referPoint =
                      apiResponse.result[0].actions[i].point.toString();
                  print('Refer points:: $referPoint');
                  return referPoint;
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      e.toString();
    }
  }

  static String getFileExtensionFile(File file) {
    return path.extension(file.path);
  }

  static int getLenthOfName(var profileInfoModal) {
    int lenght = 0;
    if (profileInfoModal == null) {
      return 0;
    } else {
      if (profileInfoModal.lastName == "" ||
          profileInfoModal.lastName == "null") {
        lenght = 0;
      } else {
        lenght = profileInfoModal.firstName.length +
            profileInfoModal.lastName.length;
      }
    }

    return lenght;
  }

  static Widget loader(BuildContext context, String placeHolderImage) => Center(
      child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  static Widget error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  static String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      return "Ongoing";
    }
  }

  static Future<String> getDownloadPath() async {
    Directory directory;
    try {
      if (Platform.isIOS) {
        directory = await getApplicationDocumentsDirectory();
      } else {
        directory = Directory('/storage/emulated/0/Download');
        // Put file in global download folder, if for an unknown reason it didn't exist, we fallback
        // ignore: avoid_slow_async_io
        if (!await directory.exists())
          directory = await getExternalStorageDirectory();
      }
    } catch (err, stack) {
      print("Cannot get download folder path");
    }
    return directory?.path;
  }
}
