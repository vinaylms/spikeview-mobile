
class RoleDataModel {
  String roleTypeId, roleName, description, image;
  bool isSelected = false;

  RoleDataModel(this.roleTypeId, this.roleName, this.description, this.image,
      this.isSelected);
}
