class QualificationsModel {
  String status;
  List<QualificationsModelResult> result;

  QualificationsModel({this.status, this.result});

  QualificationsModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<QualificationsModelResult>();
      json['result'].forEach((v) {
        result.add(new QualificationsModelResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class QualificationsModelResult {
  int qualificationId;
  String name;
  String description;

  QualificationsModelResult({this.qualificationId, this.name, this.description});

  QualificationsModelResult.fromJson(Map<String, dynamic> json) {
    qualificationId = json['qualificationId'];
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['qualificationId'] = this.qualificationId;
    data['name'] = this.name;
    data['description'] = this.description;
    return data;
  }
}
