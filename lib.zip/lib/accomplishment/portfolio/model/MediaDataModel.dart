import 'dart:io';

import 'package:flutter/material.dart';

class MediaDataModel {
  String type = "", filePath;
  File thumbnailFile, imagePath;
  bool isSelectMedia=true;
  TextEditingController labelController =  TextEditingController(),
      statisticsController =  TextEditingController(),
      descController =  TextEditingController();

  MediaDataModel(
      this.labelController, this.statisticsController, this.descController,{this.type,this.filePath,this.thumbnailFile,this.isSelectMedia});

  Map<String, dynamic> toJson() => {
        "label": labelController.text,
        "description": descController.text,
        "statistics": statisticsController.text,
        "file": this.filePath,
        "type": this.type,
        "tag": "media",
      };


}


