class EducationDetailInfoModel {
  String status;
  EducationResult result;

  EducationDetailInfoModel({this.status, this.result});

  EducationDetailInfoModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    result =
    json['result'] != null ?  EducationResult.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class EducationResult {
  bool isAllEducation;
  List<Institute> schools;
  List<Institute> colleges;

  EducationResult({this.isAllEducation, this.schools, this.colleges});

  EducationResult.fromJson(Map<String, dynamic> json) {
    isAllEducation = json['isAllEducation'];
    if (json['schools'] != null) {
      schools =  List<Institute>();
      json['schools'].forEach((v) {
        schools.add(new Institute.fromJson(v));
      });
    }
    if (json['colleges'] != null) {
      colleges =  List<Institute>();
      json['colleges'].forEach((v) {
        colleges.add(new Institute.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['isAllEducation'] = this.isAllEducation;
    if (this.schools != null) {
      data['schools'] = this.schools.map((v) => v.toJson()).toList();
    }
    if (this.colleges != null) {
      data['colleges'] = this.colleges.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Institute {
  String sId;
  int educationId;
  int organizationId;
  int userId;
  String institute;
  String city;
  String logo;
  String fromGrade;
  String toGrade;
  String fromYear;
  String toYear;
  String description;
  bool isActive;
  double gpa;
  String certifications;
  bool isWeighted;
  double outOfGpa;
  int iV;
  String type;

  String degree;
  String major;
  String minor;
  String graduationYear;
  String year;
  String otherDegree;

  Institute(
      {this.sId,
        this.educationId,
        this.organizationId,
        this.userId,
        this.institute,
        this.city,
        this.logo,
        this.fromGrade,
        this.toGrade,
        this.fromYear,
        this.toYear,
        this.description,
        this.isActive,
        this.gpa,
        this.certifications,
        this.isWeighted,
        this.outOfGpa,
        this.iV,
        this.type,

        this.degree,
        this.major,
        this.minor,
        this.graduationYear,
        this.year,
        this.otherDegree
      });

  Institute.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    educationId = json['educationId'];
    organizationId = json['organizationId'];
    userId = json['userId'];
    institute = json['institute'];
    city = json['city'];
    logo = json['logo'];
    fromGrade = json['fromGrade'];
    toGrade = json['toGrade'];
    fromYear = json['fromYear'];
    toYear = json['toYear'];
    description = json['description'];
    isActive = json['isActive'].toString() is String ? json['isActive']== 'true' ? true :false :json['isActive'];
    gpa = json['gpa'] is int ? (json['gpa'] as int).toDouble() : json['gpa'];
    //lat: json["lat"] is int ? (json['lat'] as int).toDouble() : json['lat'],
    certifications = json['certifications'].toString().trim();
    isWeighted = json['isWeighted'] is String ? json['isWeighted']== 'true' ? true :false  :json['isWeighted'];
    outOfGpa = json['outOfGpa'] is int ? (json['outOfGpa'] as int).toDouble() : json['outOfGpa'];
    iV = json['__v'];
    type = json['type'];


    degree = json['degree'].toString().trim();
    major = json['major'].toString().trim();
    minor = json['minor'].toString().trim();
    graduationYear = json['graduationYear'];
    year = json['year'];
    otherDegree = json['otherDegree'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['educationId'] = this.educationId;
    data['organizationId'] = this.organizationId;
    data['userId'] = this.userId;
    data['institute'] = this.institute;
    data['city'] = this.city;
    data['logo'] = this.logo;
    data['fromGrade'] = this.fromGrade;
    data['toGrade'] = this.toGrade;
    data['fromYear'] = this.fromYear;
    data['toYear'] = this.toYear;
    data['description'] = this.description;
    data['isActive'] = this.isActive;
    data['gpa'] = this.gpa;
    data['certifications'] = this.certifications;
    data['isWeighted'] = this.isWeighted;
    data['outOfGpa'] = this.outOfGpa;
    data['__v'] = this.iV;
    data['type'] = this.type;

    data['degree'] = this.degree;
    data['major'] = this.major;
    data['minor'] = this.minor;
    data['graduationYear'] = this.graduationYear;
    data['year'] = this.year;
    data['otherDegree'] = this.otherDegree;
    return data;
  }
}

class Colleges {
  String sId;
  int educationId;
  int organizationId;
  int userId;
  String institute;
  String city;
  String logo;
  String fromYear;
  String toYear;
  String description;
  bool isActive;
  double gpa;
  String degree;
  String major;
  String minor;
  String graduationYear;
  String certifications;
  String year;
  String isWeighted;
  double outOfGpa;
  int iV;
  String type;

  Colleges(
      {this.sId,
        this.educationId,
        this.organizationId,
        this.userId,
        this.institute,
        this.city,
        this.logo,
        this.fromYear,
        this.toYear,
        this.description,
        this.isActive,
        this.gpa,
        this.degree,
        this.major,
        this.minor,
        this.graduationYear,
        this.certifications,
        this.year,
        this.isWeighted,
        this.outOfGpa,
        this.iV,
        this.type});

  Colleges.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    educationId = json['educationId'];
    organizationId = json['organizationId'];
    userId = json['userId'];
    institute = json['institute'];
    city = json['city'];
    logo = json['logo'];
    fromYear = json['fromYear'];
    toYear = json['toYear'];
    description = json['description'];
    isActive = json['isActive'];
    gpa = json['gpa'] is int ? (json['gpa'] as int).toDouble() : json['gpa'];
    degree = json['degree'].toString().trim();
    major = json['major'].toString().trim();
    minor = json['minor'].toString().trim();
    graduationYear = json['graduationYear'];
    certifications = json['certifications'].toString().trim();
    year = json['year'];
    isWeighted = json['isWeighted'];
    outOfGpa = json['outOfGpa'] is int ? (json['outOfGpa'] as int).toDouble() : json['outOfGpa'];
    iV = json['__v'];
    type = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['educationId'] = this.educationId;
    data['organizationId'] = this.organizationId;
    data['userId'] = this.userId;
    data['institute'] = this.institute;
    data['city'] = this.city;
    data['logo'] = this.logo;
    data['fromYear'] = this.fromYear;
    data['toYear'] = this.toYear;
    data['description'] = this.description;
    data['isActive'] = this.isActive;
    data['gpa'] = this.gpa;
    data['degree'] = this.degree;
    data['major'] = this.major;
    data['minor'] = this.minor;
    data['graduationYear'] = this.graduationYear;
    data['certifications'] = this.certifications;
    data['year'] = this.year;
    data['isWeighted'] = this.isWeighted;
    data['outOfGpa'] = this.outOfGpa;
    data['__v'] = this.iV;
    data['type'] = this.type;
    return data;
  }
}
