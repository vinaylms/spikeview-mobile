import 'package:spike_view_project/modal/patner/offer_model.dart';

class CompanyModel {
  String companyId,userId,roleId,name,address,phone,about,profilePicture,coverPicture,partnerStatus,declineReason;

  List<OfferModel> offers;

  CompanyModel(this.profilePicture,this.coverPicture,this.companyId, this.userId, this.roleId, this.name,
      this.address, this.phone, this.about, this.offers,this.partnerStatus,this.declineReason);


}
