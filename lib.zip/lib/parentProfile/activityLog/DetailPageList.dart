import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/DashBoardDetailModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

class DetailPageListWidget extends StatefulWidget {
  String title;
  int listType;
String studentId;
  DetailPageListWidget(
    String title,
    String studentId,

  ) {
    this.title = title;
    this.studentId=studentId;

  }

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    // ignore: return_of_invalid_type
    return  MainView(title);
  }
}

class MainView extends State<DetailPageListWidget> {
  String title;
  int listType;
  String statusIndex;
  BuildContext context;
  SharedPreferences prefs;
  String userIdPref, userProfilePath;

List<DashBoardDetailModel> dataList=new List();

  MainView(
    String title,

  ) {
    this.title = title;

  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);



    apiCalling();
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();

  }

  @override
  void dispose() {

    super.dispose();
  }

  bool isNeedToRefresh = false;
  bool isLoading = true;

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;



        Map map ={
            "userId":int.parse(widget.studentId),
          "category":widget.title

    };

        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_DETAIL_DASHBOARD, map);
        print("response====="+response.toString());
        print("response new:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              dataList =
                  ParseJson.parseDasboardDataModel(response.data['result']);
              if (dataList != null) {
                if (mounted) {
                  setState(() {
                    dataList;
                  });
                }
              }
              print("dataList====="+dataList.length.toString());
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {

        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {

      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;

    onTapImageTile(tapedUserId,roleId) {
      if(tapedUserId==userIdPref){

      }else {
        Util.onTapImageTile(
            tapedUserRole: roleId
            , partnerUserId: tapedUserId,
            context: context
        );
      }

    }

    Container getListview(requestedTagModel, index) {
      return  Container(
          padding:  EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 5.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   InkWell(
                    child:  Column(children: <Widget>[
                 Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[



                   Expanded(
                    child:  InkWell(
                      child: ProfileImageView(
                        imagePath: Constant.IMAGE_PATH_SMALL +
                            ParseJson.getSmallImage(
                                requestedTagModel.profileImage),
                        placeHolderImage: 'assets/profile/user_on_user.png',
                        height: 50.0,
                        width: 50.0,
                        onTap: () async{

                        },
                      ),
                      onTap: () {
                        onTapImageTile(requestedTagModel.actedUserId, requestedTagModel.actedRoleId);
                        // Profile Picture CLick
                      },
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        10.0,
                        0.0,
                        10.0,
                        0.0,
                         Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                             Container(
                                child: RichText(
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: requestedTagModel.actedBy,
                                    recognizer:
                                    TapGestureRecognizer()
                                      ..onTap = () {
                                        onTapImageTile(requestedTagModel.actedUserId, requestedTagModel.actedRoleId);
                                      },
                                    style:  TextStyle(
                                      color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    children: [
                                      WidgetSpan(
                                        child: requestedTagModel
                                            .actedRoleId ==
                                            "1"
                                            ? Util
                                            .getStudentBadgeRichTextWithPadding(
                                            requestedTagModel
                                                .badge,
                                            requestedTagModel
                                                .badgeImage)
                                            : Container(
                                        ),
                                      ),


                                      TextSpan(
                                          text:requestedTagModel.message1.toString().trim().length>0?" "+requestedTagModel.message1:"",
                                          style:  TextStyle(
                                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                      TextSpan(
                                          text: requestedTagModel.actedOn.toString().trim().length>0?" "+requestedTagModel.actedOn:"",
                                          style:  TextStyle(
                                            color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                          )),
                                      TextSpan(
                                          text:requestedTagModel.message2.toString().trim().length>0?" "+ requestedTagModel.message2:"",
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                    ],
                                  ),
                                )),

                          ],
                        )),
                    flex: 1,
                  ),
                ],
              ),
                      PaddingWrap.paddingfromLTRB(40.0, 15.0, 20.0, 0.0,    Container(
                          height: 1.0,
                          color: ColorValues.DARK_GREY),)
                    ],) ,
                    onTap: () {},
                  )
                ],
              )));
    }


    return  customAppbar(
      context,
      GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 20.0, right: 20, top: 24, bottom: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      BaseText(
                        text: title,
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ],
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: ListView(

                  children: <Widget>[

                    Column(
                      children:  List.generate(dataList.length,
                              (int index) {
                            return getListview(dataList[index],index);
                          }),
                    )

                  ],
                ),
                flex: 1,
              ),
            ],
          )),
          () {
            Navigator.pop(context, isNeedToRefresh);
      },
      isShowIcon: false,
      isShowExplanation: false
    );


    return MaterialApp(
      home: Scaffold(
        backgroundColor:  ColorValues.SCREEN_BG_COLOR,
        appBar:  AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Expanded(
                child:  InkWell(
                  child: CustomViews.getBackButton(),
                  onTap: () {
                    Navigator.pop(context, isNeedToRefresh);
                  },
                ),
                flex: 0,
              ),
               Expanded(
                child:  Text(
                  title,
                  textAlign: TextAlign.center,
                  style:  TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              )
            ],
          ),
          actions: <Widget>[
             Container(
              width: 30.0,
            )
          ],
          backgroundColor: Colors.white,
        ),
        body:  Container(
            color: ColorValues.LIGHT_GRAY_BG,
            child:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                  child: ListView(

                    children: <Widget>[

                      Column(
                              children:  List.generate(dataList.length,
                                  (int index) {
                           return getListview(dataList[index],index);
                              }),
                            )

                    ],
                  ),
                  flex: 1,
                )
              ],
            )),
      ),
    );
  }

}
