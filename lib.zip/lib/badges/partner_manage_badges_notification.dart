import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/badges/AllBadges.dart';
import 'package:spike_view_project/badges/model/CollectionResult.dart';
import 'package:spike_view_project/badges/model/Collection_badges.dart';
import 'package:spike_view_project/badges/model/RequestResult.dart';
import 'package:spike_view_project/badges/model/Request_badges.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/modal/BadgeListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'dart:async';

import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class PartnerNotificationManageBadges extends StatefulWidget {
  String page, badgeId = "";

  PartnerNotificationManageBadges(this.page, {this.badgeId});

  @override
  ManageBadgesState createState() => ManageBadgesState();
}

class ManageBadgesState extends State<PartnerNotificationManageBadges> {
//  BadgeListModel badgeModel;
  CollectionBadges mCollectionBadges = CollectionBadges();
  RequestBadges mRequestBadges = RequestBadges();
  CollectionBadges mPresentBadges = CollectionBadges();

  List<Result> mCollectionBadgesList = [];
  List<RequestResult> mRequestBadgesList = [];
  List<Result> mPresentBadgesList = [];

  bool isRequestChange = false;
  bool isCollectionChange = false;
  bool isMore = false;
  SharedPreferences prefs;
  String userIdPref, roleId;
  String isPerformChanges = "pop";
  bool isViewMore = false;

  String requestCount = "";
  String collectionCount = "";
  String presentedCount = "";

  int positionOfChild = 0;
  int positionOfCollection = 0;
  int positionOfPresented = 0;

  bool isDataLoadingRequest = false;
  bool isDataLoadingCollection = false;
  bool isDataLoadingPresented = false;

  final ItemScrollController _scrollControllerRequest = ItemScrollController();
  ScrollController _scrollControllerCollection = ScrollController();
  ScrollController _scrollControllerPresented = ScrollController();
  int skip = 0;
  int skipPresented = 0;
  int skipCollection = 0;


  String strTabValue = 'Requested';
  int currentIndex = 0;


  Future apiBadgesCount() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_BADGESCOUNT +
                "userId=" +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");

        print("requestedCount//////" + response.toString());
        print("requestedCount//////" + response.data['result'].toString());
        if (response != null) {
          if (response.statusCode == 200) {
            setState(() {
              requestCount = response.data['result']['requestCount'].toString();
              collectionCount =
                  response.data['result']['collectionCount'].toString();
              presentedCount =
                  response.data['result']['presentedCount'].toString();
            });

            print("strRequestCount//////" +
                requestCount +
                collectionCount +
                presentedCount);
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }


  Future apiCallUpdateStatus(badgeId, status, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {"badgeReqId": badgeId, "status": status};

        print(map.toString());
        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_BADGE_STATUS_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges = "push";
             // ToastWrap.showToas(msg, context);

              setState(() {
                mCollectionBadgesList.clear();
                mRequestBadgesList.clear();
                mPresentBadgesList.clear();
                badgeId = "";
                widget.badgeId = "";

                skip = 0;
                skipCollection = 0;
                skipPresented = 0;
              });

              getSharedPreferences();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ManageBadges", context);
      e.toString();
    }
  }

  bool notificationLoader = true;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    print("object/////////////" + widget.badgeId);

    await apiBadgesCount();

    await apiCallingRequestBadges();

    await apiCallingCollectiontBadges();

    await apiCallingPresentBadges();

    if (widget.badgeId == "") {
    } else {
      if (mRequestBadgesList != null) {
        List<RequestResult> results1 = mRequestBadgesList
            .where((user) => user.badgeReqId.toString() == widget.badgeId)
            .toList();

        print("results1////" + results1.length.toString());

        if (results1.length == 0) {
          Future.delayed(Duration(seconds: 1), () {
            ToastWrap.showToas3("No longer exists ", context);
          });
        }
      }
    }
  }

  Future apiCallingRequestBadges() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        response = await ApiCalling().apiCall(
            context,
            Constant.BADGEBYTYPE +
                "userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&type=request" +
                "&redirectBy=notification",
            "get");

        MessageConstant.printWrapped(
            "BADGEBYTYPE........" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              setState(() {
                mRequestBadges = RequestBadges.fromJson(response.data);
                mRequestBadgesList.addAll(mRequestBadges.requestResult);
              });

              if (widget.page == "notification" || widget.page == "login") {
                for (int i = 0; i < mRequestBadgesList.length; i++) {
                  if (widget.badgeId ==
                      mRequestBadgesList[i].badgeReqId.toString()) {
                    Timer(const Duration(milliseconds: 2000), () async {
                      if (notificationLoader) {
                        _scrollControllerRequest.jumpTo(index: i);
                        setState(() {
                          notificationLoader = false;
                        });
                      }
                    });
                  }
                }
              }

              if (mRequestBadgesList == null || mRequestBadgesList.isEmpty) {
                setState(() {
                  isDataLoadingRequest = true;
                });
              }

              try {} catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingCollectiontBadges() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        response = await ApiCalling().apiCall(
            context,
            Constant.BADGEBYTYPE +
                "userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&type=collection&skip=" +
                skipCollection.toString() +
                "&redirectBy=:redirectBy",
            "get");

        MessageConstant.printWrapped(
            "BADGEBYTYPE........" + response.toString());

        //  mCollectionBadges = response.data;
        //
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              setState(() {
                mCollectionBadges = CollectionBadges.fromJson(response.data);
                mCollectionBadgesList.addAll(mCollectionBadges.result);
              });

              if (mCollectionBadgesList == null ||
                  mCollectionBadgesList.isEmpty) {
                isDataLoadingCollection = true;
              }

              try {} catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingPresentBadges() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        response = await ApiCalling2().apiCall(
            context,
            Constant.BADGEBYTYPE +
                "userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&type=presented&skip=" +
                skipPresented.toString() +
                "&redirectBy=:redirectBy",
            "get");

        MessageConstant.printWrapped(
            "BADGEBYTYPE........" + response.toString());

        //  mCollectionBadges = response.data;
        //
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              setState(() {
                mPresentBadges = CollectionBadges.fromJson(response.data);
                mPresentBadgesList.addAll(mPresentBadges.result);
              });

              if (mPresentBadgesList == null || mPresentBadgesList.isEmpty) {
                isDataLoadingPresented = true;
              }

              try {} catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<Null> onRefresh() async {
    setState(() {
      skip = 0;
      mRequestBadgesList.clear();
    });

    apiCallingRequestBadges();
    apiBadgesCount();
  }

  Future<Null> onRefreshCollection() async {
    setState(() {
      skipCollection = 0;
      mCollectionBadgesList.clear();
    });

    apiCallingCollectiontBadges();
    apiBadgesCount();
  }

  Future<Null> onRefreshPresented() async {
    setState(() {
      skipPresented = 0;
      mPresentBadgesList.clear();
    });

    apiCallingPresentBadges();
    apiBadgesCount();
  }

  @override
  void initState() {
    // TODO: implement initState

    getSharedPreferences();

    _scrollControllerCollection.addListener(() {
      if (mCollectionBadgesList.length - 1 == positionOfCollection) {
        if (_scrollControllerCollection.position.pixels ==
            _scrollControllerCollection.position.maxScrollExtent) {
          setState(() {
            skipCollection = skipCollection + 1;
            apiCallingCollectiontBadges();
          });
        }
      }
    });

    _scrollControllerPresented.addListener(() {
      if (mPresentBadgesList.length - 1 == positionOfPresented) {
        if (_scrollControllerPresented.position.pixels ==
            _scrollControllerPresented.position.maxScrollExtent) {
          setState(() {
            skipPresented = skipPresented + 1;
            apiCallingPresentBadges();
          });
        }
      }
    });

    super.initState();
  }

  BuildContext mContext;


  @override
  Widget build(BuildContext context) {
    mContext = context;
    onBack() async {
      print("Badge++++" + widget.page);
      if (widget.page == "login") {
        String roleId = prefs.getString(UserPreference.ROLE_ID);
        if (roleId == "2") {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => DashBoardWidgetParent(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
        } else if (roleId == "4") {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => DashBoardWidgetPartner(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
        } else {
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) => DashBoardWidget(
                  prefs.getString(UserPreference.IS_PARENT_ROLE),
                  prefs.getString(UserPreference.IS_PARTNER_ROLE),
                  prefs.getString(UserPreference.IS_USER_ROLE))));
        }
      } else {
        Navigator.pop(context, isPerformChanges);
      }
    }



    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: DefaultTabController(
          length: 2,
          initialIndex: currentIndex,

          child: Scaffold(

                body: SafeArea(
                  child: Container(
                    color: Colors.white,
                    child: Column(
                      children: [
                        Container(
                          color: Colors.white,
                          child: SizedBox(
                            height: 90,
                            width: double.infinity,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  InkWell(
                                    onTap: () {
                                      onBack();
                                    },
                                    child: Image.asset(
                                      "assets/generateScript/back.png",
                                      height: 32.0,
                                      width: 32.0,
                                    ),
                                  ),
                                  const HelpButtonWidget(),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: Column(children: [
                            Align(
                                alignment: Alignment.topLeft,
                                child: BaseText(
                                  text: "Manage badges",
                                  textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 28,
                                  maxLines: 1,
                                )),
                            SizedBox(
                              height: 5,
                            ),
                            Align(
                                alignment: Alignment.topLeft,
                                child: BaseText(
                                  text: "Review and manage badges",
                                  textColor: AppConstants.colorStyle.lightPurple,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 2,
                                )),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                25.0,
                                0.0,
                                0.0,
                                Row(
                                  children: [
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                          //width: MediaQuery.of(context).size.width*0.45,
                                          child: Text(
                                            'Requested' + " (" + requestCount + ")",
                                            maxLines: 1,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: strTabValue == 'Requested'
                                                  ? ColorValues.WHITE
                                                  : AppConstants
                                                  .colorStyle.darkBlue,
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                            ),
                                          ),
                                          padding: EdgeInsets.only(
                                              top: 9, bottom: 9, left: 9, right: 9),
                                          decoration: BoxDecoration(
                                            color: strTabValue == 'Requested'
                                                ? ColorValues.DARK_YELLOW
                                                : AppConstants.colorStyle.tabBg,
                                            border: Border.all(
                                                color: strTabValue == 'Requested'
                                                    ? ColorValues.DARK_YELLOW
                                                    : AppConstants.colorStyle
                                                    .borderGenerateScript),
                                            borderRadius: const BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                bottomLeft: Radius.circular(10)),
                                          ),
                                        ),
                                        onTap: () {
                                          //Request tab -
                                          setState(() {
                                            strTabValue = 'Requested';
                                          });

                                          setState(() {});
                                        },
                                      ),
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                          //width: MediaQuery.of(context).size.width*0.45,
                                          child: Text(
                                            'My badges' + " (" + collectionCount + ")",
                                            maxLines: 1,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: strTabValue == 'Collections'
                                                  ? ColorValues.WHITE
                                                  : AppConstants
                                                  .colorStyle.darkBlue,
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                            ),
                                          ),
                                          padding: EdgeInsets.only(
                                              top: 9, bottom: 9, left: 9, right: 9),
                                          decoration: BoxDecoration(
                                            color: strTabValue == 'Collections'
                                                ? ColorValues.DARK_YELLOW
                                                : AppConstants.colorStyle.tabBg,
                                            border: Border.all(
                                                color: AppConstants.colorStyle
                                                    .borderGenerateScript),
                                            borderRadius: const BorderRadius.only(
                                                topRight: Radius.circular(10),
                                                bottomRight: Radius.circular(10)),
                                          ),
                                        ),
                                        onTap: () {
                                          setState(() {
                                            strTabValue = 'Collections';
                                          });
                                          setState(() {
                                          });
                                        },
                                      ),
                                    ),

                                  ],
                                )),
                          ]),
                        ),
                        SizedBox(
                          height: 15,
                        ),

                        strTabValue == 'Requested'
                            ?   Expanded(
                          flex: 1,
                          child: RefreshIndicator(
                              onRefresh: onRefresh,
                              displacement: 0.0,
                              child: isDataLoadingRequest
                                  ? Padding(
                                padding: const EdgeInsets.only(top: 20.0),
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 20.0),
                                  child: Container(
                                    // width: 349,
                                    height: 336,

                                    child: Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                              width: 250.0,
                                              height: 180.0,
                                              child: PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  Image.asset(
                                                    "assets/badges/noBadgesAvailable.png",
                                                  ))),

                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                                  : requestView(mContext, mRequestBadgesList)),
                        )
                            :  Expanded(
                          flex: 1,
                          // pending_recomendation
                          child:    mCollectionBadges == null
                              ? Padding(
                            padding: const EdgeInsets.only(top: 20.0),
                            child: Container(
                              // width: 349,
                              height: 336,

                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment:
                                  CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                        width: 250.0,
                                        height: 180.0,
                                        child: PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            0.0,
                                            0.0,
                                            Image.asset(
                                              "assets/badges/noBadgesAvailable.png",
                                            ))),

                                  ],
                                ),
                              ),
                            ),
                          )
                              :   RefreshIndicator(
                              onRefresh: onRefresh,
                              displacement: 0.0,
                              child: isDataLoadingRequest
                                  ? Padding(
                                padding: const EdgeInsets.only(top: 20.0),
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 20.0),
                                  child: Container(
                                    // width: 349,
                                    height: 336,

                                    child: Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                              width: 250.0,
                                              height: 180.0,
                                              child: PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  Image.asset(
                                                    "assets/badges/noBadgesAvailable.png",
                                                  ))),

                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                                  : collectionView(context,
                                  mCollectionBadgesList)),
                        )

                      ,

                        SizedBox(height: 5)
                      ],
                    ),
                  ),
                )
            ),


        ));
  }

  Widget collectionListTile(
      BuildContext context, List<BadgeModel> collectionBadgeList, int index) {
    return Container(
      margin: const EdgeInsets.only(top: 13, bottom: 5),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                  margin: const EdgeInsets.only(top: 10),
                  padding: const EdgeInsets.all(5.0),
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xffDEDEDE))),
                  child: Image.asset(
                    'assets/badges/national_pic.png',
                    height: 50,
                    width: 44,
                  )),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Diligent Sports',
                    textAlign: TextAlign.start,
                    style: TxtStyle.nunito_16_600Black,
                  ),
                ],
              )
            ],
          ),
          const SizedBox(height: 15),
          Container(
            color: const Color(0xffDEDEDE),
            width: MediaQuery.of(context).size.width,
            height: 1,
          )
        ],
      ),
    );
  }


  Widget presentedView(BuildContext context, List<Result> result) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.transparent,
          border:
              Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR, width: 0.5)),
      child: ListView.builder(
          physics: AlwaysScrollableScrollPhysics(),
          controller: _scrollControllerPresented,
          itemCount: result == null ? 0 : result.length,
          itemBuilder: (BuildContext context, int index) {
            positionOfPresented = index;
            return presentedListTile(context, result, index);
          }),
    );
  }

  Widget requestView(BuildContext context, List<RequestResult> result) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.transparent,
         ),
      child: ScrollablePositionedList.builder(
          physics: AlwaysScrollableScrollPhysics(),
          itemScrollController: _scrollControllerRequest,
          itemCount: result == null ? 0 : result.length,
          itemBuilder: (BuildContext context, int index) {

            return requestListTile(context, result, index);
          }),
    );
  }



  collectionList(BuildContext context, List<Result> result, int index) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20,right: 25,top: 5),
          child: Container(
            decoration: BoxDecoration(
              color: ColorValues.SELECTION_BG,
              border: Border.all(
                  color: ColorValues
                      .BORDER_GENERATE_SCRIPT),
              borderRadius:
              const BorderRadius.all(
                  Radius.circular(10)
              ),
            ),

            child: Padding(
                padding: const EdgeInsets.only(left: 0.0, right: 0,top: 10),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 5,left: 10,right: 10),
                      child: Row(
                        children: [

                          Container(
                            width: 75,
                            height: 78,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10), // half of the height to make it circular
                              border: Border.all(width: 1, color: Color(0xffD4E4FF)),
                            ),
                            child: Center(
                                child: SizedBox(
                                    height: 65,
                                    width: 65,
                                    child:
                                    FadeInImage.assetNetwork(
                                      placeholder: 'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getMediumImage(
                                              mCollectionBadgesList[index].image),
                                      width: 65,
                                      height: 65,
                                      fit: BoxFit.contain,
                                    )
                                )
                            ),
                          ),

                          const SizedBox(width: 15),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                  mCollectionBadgesList[index].name.toString(),
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: Constant.latoRegular,
                                    color:ColorValues.HEADING_COLOR_EDUCATION_1,

                                  )
                              ),

                            ],
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: 15),
                  ],
                )),
          ),
        ),
        const SizedBox(height: 15),
      ],
    );
  }

  Widget collectionView(
      BuildContext context,
      List<Result> result,
      ) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.transparent,
      ),
      padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
      child: ListView.builder(
          physics: AlwaysScrollableScrollPhysics(),
          controller: _scrollControllerCollection,
          itemCount: result == null ? 0 : result.length,
          itemBuilder: (BuildContext context, int index) {
            positionOfCollection = index;
            return collectionList(context, result, index);
          }),
    );
  }

  Widget requestEmptyView(BuildContext context) {
    return Container(
      color: const Color(0xffFFFFFF),
      margin: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height -
                MediaQuery.of(context).size.height / 2,
            padding: const EdgeInsets.all(10),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/badges/request_not_available.png',
                      width: 180),
                  const SizedBox(height: 15),
                  Text(
                    'No request sending by you.',
                    textAlign: TextAlign.start,
                    style: TxtStyle.nunito_16_600Grey,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget collectionEmptyView(BuildContext context) {
    return Container(
      color: const Color(0xffFFFFFF),
      margin: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height -
                MediaQuery.of(context).size.height / 2,
            padding: const EdgeInsets.all(10),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/badges/collection_not_available.png',
                      width: MediaQuery.of(context).size.width),
                  const SizedBox(height: 15),
                  Text(
                    'No badge received by you.',
                    textAlign: TextAlign.start,
                    style: TxtStyle.nunito_16_600Grey,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget presentedEmptyView(BuildContext context) {
    return Container(
      color: const Color(0xffFFFFFF),
      margin: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height -
                MediaQuery.of(context).size.height / 2,
            padding: const EdgeInsets.all(10),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/badges/presented_not_available.png',
                      width: MediaQuery.of(context).size.width),
                  const SizedBox(height: 15),
                  Text(
                    'No badge sent by you.',
                    textAlign: TextAlign.start,
                    style: TxtStyle.nunito_16_600Grey,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget requestListTileold(
      BuildContext context, List<RequestResult> requestedBadgeList, int index) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.fromLTRB(13.0, 13.0, 13.0, 0.0),
          margin: const EdgeInsets.all(5),
          color: widget.page == "notification" &&
                  widget.badgeId.toString() ==
                      requestedBadgeList[index].badgeReqId.toString()
              ? ColorValues.DEVIDER_COLOR
              : widget.page == "login" &&
                      widget.badgeId.toString() ==
                          requestedBadgeList[index].badgeReqId.toString()
                  ? ColorValues.DEVIDER_COLOR
                  : Colors.transparent,
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    child: Padding(
                        padding: const EdgeInsets.only(top: 0.0, bottom: 0.0),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(25.0),
                          child: ClipOval(
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.contain,
                              placeholder: 'assets/profile/user_on_user.png',
                              image: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getMediumImage(
                                      requestedBadgeList[index].userImage),
                              height: 50.0,
                              width: 50.0,
                            ),
                          ),
                        )),
                    onTap: () {
                      if (requestedBadgeList[index].userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: requestedBadgeList[index].userRoleId,
                            partnerUserId: requestedBadgeList[index].userId,
                            context: context);
                      }
                    },
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                requestedBadgeList[index].userTagline ==
                                            "null" ||
                                        requestedBadgeList[index].userTagline ==
                                            "" ||
                                        requestedBadgeList[index].userTagline ==
                                            null
                                    ? Padding(
                                        padding: const EdgeInsets.only(
                                            top: 20, left: 0.0, right: 0),
                                        child: Text(
                                          requestedBadgeList[index]
                                              .userName
                                              .toString(),
                                          textAlign: TextAlign.start,
                                          style: TxtStyle.nunito_14_700Blue,
                                        ))
                                    : Padding(
                                        padding: const EdgeInsets.only(
                                            top: 7, left: 0.0, right: 0),
                                        child: Text(
                                          requestedBadgeList[index]
                                              .userName
                                              .toString(),
                                          textAlign: TextAlign.start,
                                          style: TxtStyle.nunito_14_700Blue,
                                        )),
                                requestedBadgeList[index].userTagline ==
                                            "null" ||
                                        requestedBadgeList[index].userTagline ==
                                            "" ||
                                        requestedBadgeList[index].userTagline ==
                                            null
                                    ? Container(
                                        height: 0,
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.only(
                                            top: 0, left: 0.0, right: 0),
                                        child: Text(
                                          requestedBadgeList[index]
                                              .userTagline
                                              .toString(),
                                          textAlign: TextAlign.start,
                                          style: TxtStyle.nunito_12_400Grey,
                                        )),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Expanded(
                          flex: 0,
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 0, left: 0.0, right: 0),
                            child: Text(
                              requestedBadgeList[index].message,
                              maxLines:
                                  requestedBadgeList[index].isMore ? 35 : 3,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 15,
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              ),
                            ),
                          ),
                        ),
                        requestedBadgeList[index].message.length > 100
                            ? InkWell(
                                child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 0.0, left: 0.0, right: 0),
                                    child: Text(
                                      requestedBadgeList[index].isMore
                                          ? "Less"
                                          : "More",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      ),
                                    )),
                                onTap: () {
                                  if (requestedBadgeList[index].isMore)
                                    requestedBadgeList[index].isMore = false;
                                  else
                                    requestedBadgeList[index].isMore = true;

                                  setState(() {
                                    requestedBadgeList[index].isMore;
                                  });
                                },
                              )
                            : Container(
                                height: 0.0,
                              ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 0, top: 0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  /*Padding(
                                      padding: const EdgeInsets.only(top: 0),
                                      child: Text(
                                        'For: ',
                                        textAlign: TextAlign.start,
                                        maxLines: 2,
                                        style: TxtStyle.nunito_12_400Grey,
                                      )),*/
                                  /*Text(
                                    'For: '+requestedBadgeList[index].name,
                                    maxLines:1,
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_600Black,
                                  ),*/
                                  RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      text: 'For: ',
                                      style: TxtStyle.nunito_14_400Grey,
                                      children: <TextSpan>[
                                        TextSpan(
                                            text:
                                                requestedBadgeList[index].name,
                                            style: TxtStyle
                                                .nunito_20_600nunitoBold)
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child: Text(
                                        'Received on: ' +
                                            Util.getConvertedDateStampNew(
                                                requestedBadgeList[index]
                                                    .date
                                                    .toString()),
                                        textAlign: TextAlign.start,
                                        style: TxtStyle.nunito_12_400Grey,
                                      ))
                                ],
                              ),
                            ),

                            /*    Expanded(
                                flex: 0,
                                child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 0.0, left: 5.0, right: 5),
                                    child: Container(
                                      color: const Color(0xffDEDEDE),
                                      height: 50,
                                      width: 1,
                                    ))),*/
                            /*Expanded(
                                flex:5,
                                child: Row(
                                  children: [


                                  ],
                                ))*/
                          ],
                        ),
                        const SizedBox(height: 15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            InkWell(
                              child: Row(
                                children: [
                                  Image.asset(
                                    'assets/newDesignIcon/navigation/right_circle.png',
                                    height: 35,
                                    width: 35,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'Approve',
                                    maxLines: 1,
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_16_400Blue,
                                  ),
                                ],
                              ),
                              onTap: () {
                                showSucessMsg(index, "accepted");
                              },
                            ),
                            const SizedBox(width: 10),
                            InkWell(
                              child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 0, left: 0.0, right: 5, bottom: 5),
                                  child: Image.asset(
                                    'assets/badges/cross.png',
                                    height: 25,
                                    width: 25,
                                  )),
                              onTap: () {
                                DeleteshowSucessMsg(
                                    requestedBadgeList[index]
                                        .badgeReqId
                                        .toString(),
                                    index);
                              },
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 5),
        Container(
          color: const Color(0xffDEDEDE),
          width: MediaQuery.of(context).size.width,
          height: 1,
        ),
        const SizedBox(height: 5),
      ],
    );
    /* );*/
  }


  Widget requestListTile(
      BuildContext context, List<RequestResult> requestedBadgeList, int index)  {
    return /*Container(
      margin: const EdgeInsets.only(top: 10, bottom: 5, right: 5, left: 5),
      child:*/
      Column(
        children: [


          Padding(
            padding: const EdgeInsets.only(left: 20,right: 25,top: 15),
            child: Container(
              decoration: BoxDecoration(
                color: widget.page == "notification" &&
                    widget.badgeId.toString() ==
                        requestedBadgeList[index].badgeReqId.toString()
                    ? ColorValues.light_COLOR
                    : widget.page == "login" &&
                    widget.badgeId.toString() ==
                        requestedBadgeList[index].badgeReqId.toString()
                    ? ColorValues.light_COLOR
                    : ColorValues.SELECTION_BG,

                border: Border.all(
                    color: ColorValues
                        .BORDER_GENERATE_SCRIPT),
                borderRadius:
                const BorderRadius.all(
                    Radius.circular(10)
                ),
              ),

              child:  Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          0.0,
                          Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(left: 10,right: 10,top: 10),
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Stack(
                                        children: <Widget>[
                                          InkWell(
                                            child:

                                            ProfileImageView(
                                              imagePath: Constant
                                                  .IMAGE_PATH_SMALL +
                                                  ParseJson.getMediumImage(
                                                      requestedBadgeList[index].userImage),
                                              placeHolderImage:
                                              'assets/profile/user_on_user.png',
                                              height: 45.0,
                                              width: 45.0,
                                              onTap: () async {},
                                              borderRadius: 8,

                                            ),


                                            onTap: () {
                                              if (requestedBadgeList[index].userId == userIdPref) {
                                              } else {
                                                Util.onTapImageTile(
                                                    tapedUserRole: requestedBadgeList[index].userRoleId,
                                                    partnerUserId: requestedBadgeList[index].userId,
                                                    context: context);
                                              }
                                            },
                                          ),
                                        ],
                                      ),
                                      flex: 0,
                                    ),

                                    Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: <Widget>[

                                            PaddingWrap.paddingfromLTRB(
                                              12.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              RichText(
                                                textAlign:
                                                TextAlign.center,
                                                text: TextSpan(
                                                  text: "",
                                                  //MessageConstant  .ADD_RECOMMENDATION_FROM,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      height: 1.2,
                                                      fontSize: 14.0,
                                                      fontWeight:
                                                      FontWeight
                                                          .normal,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                      text: requestedBadgeList[index]
                                                          .userName
                                                          .toString(),
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          fontSize:
                                                          14.0,
                                                          fontWeight:
                                                          FontWeight
                                                              .bold,
                                                          fontFamily:
                                                          Constant
                                                              .customBold),
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ),

                                            requestedBadgeList[index]
                                                .userTagline
                                                .toString() == null ?
                                            PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                2.0,
                                                0.0,
                                                0.0,
                                                PaddingWrap.paddingAll(
                                                  2.0,
                                                  TextViewWrap.textView(
                                                      requestedBadgeList[index]
                                                          .userTagline
                                                          .toString() ,
                                                      //recomdation.user.tagline
                                                      TextAlign.start,
                                                      ColorValues
                                                          .labelColor,
                                                      12.0,
                                                      FontWeight
                                                          .normal),
                                                )) : Container(),

                                          ],
                                        ),
                                        flex: 1),
                                  ],
                                ),
                              ),

                              Expanded(
                                flex: 0,
                                child: Padding(
                                  padding:
                                  const EdgeInsets
                                      .only(
                                      top: 13,
                                      left:
                                      10.0,
                                      right:
                                      0,bottom: 10),
                                  child: Text(

                                    requestedBadgeList[index].message,
                                    maxLines:
                                    requestedBadgeList[index]
                                        .isMore
                                        ? 50
                                        : 3,
                                    overflow:
                                    TextOverflow
                                        .ellipsis,
                                    style:
                                    TextStyle(
                                      fontWeight:
                                      FontWeight
                                          .w400,
                                      fontSize:
                                      15,
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1,
                                      fontFamily:
                                      Constant
                                          .latoRegular,
                                    ),
                                  ),
                                ),
                              ),

                              requestedBadgeList[index].message.length > 100
                                  ? InkWell(
                                child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 0.0, left: 0.0, right: 0),
                                    child: Text(
                                      requestedBadgeList[index].isMore
                                          ? "Less"
                                          : "More",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      ),
                                    )),
                                onTap: () {
                                  if (requestedBadgeList[index].isMore)
                                    requestedBadgeList[index].isMore = false;
                                  else
                                    requestedBadgeList[index].isMore = true;

                                  setState(() {
                                    requestedBadgeList[index].isMore;
                                  });
                                },
                              )
                                  : Container(
                                height: 0.0,
                              ),

                              Padding(
                                padding: const EdgeInsets.only(left: 10,right: 10),
                                child: Divider(),
                              ),

                              //for
                              Padding(
                                padding: const EdgeInsets.only(left: 10,right: 10,top: 10),
                                child: Row(
                                  children: <
                                      Widget>[
                                    Expanded(
                                      child:
                                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                        Padding(
                                          padding: const EdgeInsets.only(bottom: 8),
                                          child: Text(
                                            "For: ",
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                              fontWeight: FontWeight.w500,
                                              color: ColorValues.labelColor,
                                              fontSize: 12.0,
                                              fontFamily: Constant.latoRegular,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          requestedBadgeList[index].name,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                            fontWeight: FontWeight.w400,
                                            color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontFamily: Constant.latoMedium,
                                          ),
                                        ),
                                      ]),
                                      flex:
                                      0,
                                    ),
                                    Spacer(),
                                    // Expanded(
                                    //   flex: 0,
                                    // ),

                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(bottom: 8),
                                            child: Text(
                                              "Received date: ",
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                color: ColorValues.labelColor,
                                                fontSize: 12.0,
                                                fontFamily: Constant.latoRegular,
                                              ),
                                            ),
                                          ),
                                          Text(
                                            Util.getConvertedDateStampNew(
                                                requestedBadgeList[index]
                                                    .date
                                                    .toString()),
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION_1, fontSize: 13.0, fontFamily: Constant.latoMedium, fontWeight: FontWeight.w400),
                                          ),
                                        ],
                                      ),
                                      flex: 1,
                                    )

                                  ],
                                ),
                              ),

                              // bottom bottons
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  15.0,
                                  0.0,
                                  0.0,
                                  Container(
                                      height: 42.0,
                                      decoration: BoxDecoration(
                                        color: ColorValues
                                            .LIST_BOTTOM_BG,
                                        borderRadius:
                                        BorderRadius.only(
                                          bottomLeft:
                                          Radius.circular(
                                              10.0),
                                          bottomRight:
                                          Radius.circular(
                                              10.0),
                                        ),
                                      ),
                                      //List cell bottom -
                                      child:
                                      // requestedRecommendationtList[index].stage == "Requested"
                                      Container(
                                        child: Column(
                                          children: [
                                            Container(
                                              height:1,
                                              color: ColorValues.BORDER_GENERATE_SCRIPT,
                                            ),
                                            Row(
                                              children: [
                                                // Send Edit ---
                                                Expanded(
                                                  child: Container(
                                                    alignment:
                                                    Alignment
                                                        .center,
                                                    child: InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                          0.0,
                                                          3.0,
                                                          0.0,
                                                          0.0,
                                                          Text("Accept",
                                                            style: TextStyle(
                                                                fontSize: 14.0,
                                                                fontFamily: Constant.latoRegular,
                                                                fontWeight: FontWeight.w600,
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION_2),
                                                          )),
                                                      onTap: () {
                                                        //  onTapRecommendation(requestedRecommendationtList[index]);
                                                        showSucessMsg(index, "accepted");


                                                      },
                                                    ),
                                                  ),
                                                  flex: 1,
                                                ),
                                                //separator viw
                                                Container(
                                                  alignment: Alignment
                                                      .center,
                                                  width: 1,
                                                  height: 40,
                                                  color: ColorValues
                                                      .BORDER_GENERATE_SCRIPT,
                                                ),
                                                //Cancel Button
                                                Expanded(
                                                  child: Container(
                                                    alignment:
                                                    Alignment
                                                        .center,
                                                    child: InkWell(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                        0.0,
                                                        3.0,
                                                        0.0,
                                                        0.0,
                                                        Text("Reject",
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .HEADING_COLOR_EDUCATION_1,
                                                                fontSize:
                                                                14.0,
                                                                fontFamily: Constant
                                                                    .latoRegular,
                                                                fontWeight:
                                                                FontWeight.w600)),
                                                      ),
                                                      onTap: () {
                                                        DeleteshowSucessMsg(requestedBadgeList[index].badgeReqId
                                                            .toString(), index);
                                                      },
                                                    ),
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      )
                                    //  PendingRequestedSectionBottom(index)
                                    // bottom actions -
                                  )
                              )

                            ],
                          )),
                    ),
                  ]),
            ),
          ),

        ],
      );
    /*);*/
  }



  Widget presentedListTile(
      BuildContext context, List<Result> presentBadgeList, int index) {
    return /*Container(
      margin: const EdgeInsets.only(top: 13, bottom: 5),
      padding: EdgeInsets.fromLTRB(13.0, 15.0, 13.0, 10.0),
      child:*/
        Column(
      children: [
        Container(
          margin: const EdgeInsets.only(top: 13, bottom: 0),
          padding: EdgeInsets.fromLTRB(13.0, 10.0, 13.0, 0.0),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    child:

                    ProfileImageView(
                      imagePath: Constant
                          .IMAGE_PATH_SMALL +
                          ParseJson.getMediumImage(
                              presentBadgeList[index].userImage),
                      placeHolderImage:
                      'assets/profile/user_on_user.png',
                      height: 50.0,
                      width: 50.0,
                      onTap: () async {},
                      borderRadius: 10,

                    ),



                    onTap: () {
                      if (presentBadgeList[index].userId == userIdPref) {
                      } else {
                        Util.onTapImageTile(
                            tapedUserRole: presentBadgeList[index].userRoleId,
                            partnerUserId: presentBadgeList[index].userId,
                            context: context);
                      }
                    },
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: const EdgeInsets.only(
                                        top: 8, left: 0.0, right: 0),
                                    child: Text(
                                      presentBadgeList[index].userName,
                                      textAlign: TextAlign.start,
                                      style: TxtStyle.nunito_14_700Blue,
                                    )),
                                Padding(
                                    padding: const EdgeInsets.only(
                                        top: 0, left: 0.0, right: 0),
                                    child: Text(
                                      presentBadgeList[index].userTagline,
                                      textAlign: TextAlign.start,
                                      style: TxtStyle.nunito_12_400Grey,
                                    )),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Expanded(
                          flex: 0,
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 0, left: 0.0, right: 0),
                            child: Text(
                              presentBadgeList[index].message,
                              maxLines: presentBadgeList[index].isMore ? 35 : 3,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 15,
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              ),
                            ),
                          ),
                        ),
                        presentBadgeList[index].message.length > 100
                            ? InkWell(
                                child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 0.0, left: 0.0, right: 0),
                                    child: Text(
                                      presentBadgeList[index].isMore
                                          ? "Less"
                                          : "More",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontWeight: FontWeight.w400,
                                        fontSize: 16,
                                        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      ),
                                    )),
                                onTap: () {
                                  if (presentBadgeList[index].isMore)
                                    presentBadgeList[index].isMore = false;
                                  else
                                    presentBadgeList[index].isMore = true;

                                  setState(() {
                                    presentBadgeList[index].isMore;
                                  });
                                },
                              )
                            : Container(
                                height: 0.0,
                              ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Text(
                                        'For: ',
                                        textAlign: TextAlign.start,
                                        maxLines: 3,
                                        style: TxtStyle.nunito_12_400Grey,
                                      )),
                                  Text(
                                    presentBadgeList[index].name,
                                    maxLines: 3,
                                    textAlign: TextAlign.start,
                                    style: TxtStyle.nunito_14_600Black,
                                  ),
                                ],
                              ),
                              flex: 2,
                            ),
                            Expanded(
                              child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 0.0, left: 10.0, right: 10),
                                  child: Container(
                                    color: const Color(0xffDEDEDE),
                                    height: 50,
                                    width: 1,
                                  )),
                              flex: 0,
                            ),
                            Expanded(
                                flex: 5,
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: ClipOval(
                                          child: FadeInImage.assetNetwork(
                                        fit: BoxFit.contain,
                                        placeholder:
                                            'assets/profile/user_on_user.png',
                                        image: Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getMediumImage(
                                                presentBadgeList[index].image),
                                        height: 50.0,
                                        width: 50.0,
                                      )),
                                      flex: 0,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                        child: Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 8),
                                            child: Text(
                                              'Received on: ' +
                                                  '\n' +
                                                  Util.getConvertedDateStampNew(
                                                      presentBadgeList[index]
                                                          .date
                                                          .toString()),
                                              textAlign: TextAlign.start,
                                              maxLines: 3,
                                              style: TxtStyle.nunito_12_400Grey,
                                            ))),
                                  ],
                                ))
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
            ],
          ),
        ),
        Container(
          color: const Color(0xffDEDEDE),
          width: MediaQuery.of(context).size.width,
          height: 1,
        )
      ],
    );
  }

  void showSucessMsg(index, status)   {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,

      builder: (_) {
        return ConfirmationDialog(
          positiveText: "OK",
          positiveTextColor: Color(0xff27275A),
          msg: 'Are you sure you want to present your badge to ' + mRequestBadgesList[index].userName + "?",
          onPositiveTap: (){
            apiCallUpdateStatus(
                mRequestBadgesList[index].badgeReqId,
                status,
                index);
          },
        );
      },
    );
  }

  showSucessMsgold(index, status) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(10.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 15.0, bottom: 5.0),
                child: Image.asset(
                  "assets/recommendation/green_tick_circle.png",
                  height: 70.0,
                  width: 69.0,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                "Confirmation",
                textAlign: TextAlign.center,
                maxLines: 3,
                style: TextStyle(
                    fontSize: 20.0,
                    color: ColorValues.BUTTON_GREEN_DARK,
                    fontWeight: FontWeight.w700),
              ),
              SizedBox(height: 10.0),
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Are you sure you want to present your badge to ',
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  children: <TextSpan>[
                    TextSpan(
                        text: mRequestBadgesList[index].userName + "?",
                        style: TextStyle(
                            color: ColorValues.HEADING_COLOR_EDUCATION,
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: Constant.customBold))
                  ],
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                      padding: EdgeInsets.only(
                          left: 10.0, top: 20.0, right: 20.0, bottom: 25.0),
                      child: InkWell(
                        child: Container(
                            height: 40.0,
                            width: 90.0,
                            decoration: BoxDecoration(
                                color: Colors.transparent,
                                border: Border.all(
                                    color: ColorValues.BLUE_COLOR, width: 0.5)),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  MessageConstant.CANCEL,
                                  style: TextStyle(
                                    color: ColorValues.BLUE_COLOR,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 20.0,
                                  ),
                                )
                              ],
                            )),
                        onTap: () {
                          Navigator.pop(context);
                        },
                      )),
                  Padding(
                      padding: EdgeInsets.only(
                          left: 0.0, top: 20.0, right: 20.0, bottom: 25.0),
                      child: InkWell(
                        child: Container(
                            height: 40.0,
                            width: 60.0,
                            color: ColorValues.BLUE_COLOR,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  MessageConstant.OK,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 20.0,
                                  ),
                                )
                              ],
                            )),
                        onTap: () {
                          Navigator.pop(context);

                          apiCallUpdateStatus(
                              mRequestBadgesList[index].badgeReqId,
                              status,
                              index);
                        },
                      ))
                ],
              )
            ],
          ),
        );
      },
    );
  }

  void DeleteshowSucessMsg(String badgesId, index)  {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Are you sure you want decline your badge to ' + mRequestBadgesList[index].userName + "?",
          onPositiveTap: (){
            apiCallingForDeleteBadges(badgesId, index);

          },
        );
      },
    );
  }

  DeleteshowSucessMsgold(String badgesId, index) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(10.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 15.0, bottom: 5.0),
                child: Image.asset(
                  "assets/badges/delete_badge.png",
                  height: 70.0,
                  width: 69.0,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                "Confirmation",
                textAlign: TextAlign.center,
                maxLines: 3,
                style: TextStyle(
                    fontSize: 20.0,
                    color: ColorValues.black,
                    fontWeight: FontWeight.w700),
              ),
              SizedBox(height: 10.0),
              RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Are you sure you want decline your badge to ',
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  children: <TextSpan>[
                    TextSpan(
                        text: mRequestBadgesList[index].userName + "?",
                        style: TextStyle(
                            color: ColorValues.HEADING_COLOR_EDUCATION,
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: Constant.customBold))
                  ],
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Padding(
                      padding: EdgeInsets.only(
                          left: 10.0, top: 20.0, right: 20.0, bottom: 15.0),
                      child: InkWell(
                        child: Container(
                            height: 40.0,
                            width: 90.0,
                            decoration: BoxDecoration(
                                color: Colors.transparent,
                                border: Border.all(
                                    color: ColorValues.BLUE_COLOR, width: 0.5)),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  MessageConstant.CANCEL,
                                  style: TextStyle(
                                    color: ColorValues.BLUE_COLOR,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 20.0,
                                  ),
                                )
                              ],
                            )),
                        onTap: () {
                          Navigator.pop(context);
                        },
                      )),
                  Padding(
                      padding: EdgeInsets.only(
                          left: 0.0, top: 20.0, right: 20.0, bottom: 15.0),
                      child: InkWell(
                        child: Container(
                            height: 40.0,
                            width: 60.0,
                            color: ColorValues.BLUE_COLOR,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(
                                  MessageConstant.OK,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 20.0,
                                  ),
                                )
                              ],
                            )),
                        onTap: () {
                          Navigator.pop(context);

                          apiCallingForDeleteBadges(badgesId, index);
                        },
                      ))
                ],
              )
            ],
          ),
        );
      },
    );
  }

  void DeletebadgeDialog(String badgesId, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(20.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//

                                                  RichText(
                                                    textAlign: TextAlign.center,
                                                    text: TextSpan(
                                                      text:
                                                          "Are you sure you want to withdraw your request?",
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                      children: <TextSpan>[],
                                                    ),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Ok",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);

                                              apiCallingForDeleteBadges(
                                                  badgesId, index);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallingForDeleteBadges(badgeReqId, index) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "badgeReqId": badgeReqId,
      };

      Response response = await ApiCalling()
          .apiCallDeleteWithMapData(context, Constant.ENDPOINT_BADGES, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            setState(() {
              mRequestBadgesList.removeAt(index);
            });

            apiBadgesCount();
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }



}
