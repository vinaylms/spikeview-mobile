import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

import '../GroupDetailWidget.dart';

class GroupStudentRequestWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return GroupStudentRequestWidgetState();
  }
}

class GroupStudentRequestWidgetState extends State<GroupStudentRequestWidget> {
  BuildContext context;
  SharedPreferences prefs;
  bool isLoading = true;
  String isPerformChanges = "pop", roleId, userIdPref, searchName = "";
  List<GroupModel> groupRequestList = List();
  ScrollController _scrollController = ScrollController();
  int skip = 0;
  bool isLoadMore = true;
  bool isLoadingData = false;
  int offset = 0;

  Future apiCallForGetRequest() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {});
        offset = 0;
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_STUDENT +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=0&status=Invited&name=",
            "get");
        print('response+++' +
            Constant.GET_GROUP_BY_TYPE +
            userIdPref +
            "&roleId=" +
            roleId +
            "&skip=0&status=Accepted&name=");
        print('response+++' + response.toString());
        isLoading = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupRequestList = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
    }
  }

  Future apiCallForLoadMore() async {
    try {
      print("load mo0re call");
      isLoadingData = true;
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        print("load mo0re call++" +
            Constant.GET_GROUP_BY_TYPE +
            userIdPref +
            "&roleId=" +
            roleId +
            "&skip=$offset&status=Invited&name=");
        response = await ApiCalling().apiCall(
            context,
            Constant.GET_GROUP_BY_TYPE +
                userIdPref +
                "&roleId=" +
                roleId +
                "&skip=$offset&status=Invited&name=",
            "get");

        isLoadingData = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var groupList1 = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupRequestList.addAll(groupList1);
              });

              if (groupList1.length > 0) {
                setState(() {
                  groupRequestList.addAll(groupList1);
                });
              } else {
                isLoadMore = false;
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadingData = false;

      e.toString();
    }
  }

  getSharedPreferences() async {
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    apiCallForGetRequest();
  }

  _scrollListener() {
    if (_scrollController.offset >=
            _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      offset++;
      if (isLoadMore) {
        apiCallForLoadMore();
      }
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  // -------------------  API ------------------------------
  Future apiCallingForAccept(groupId, index, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "isAdmin": false,
          "status": type
        };

        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges = "push";
              apiCallForGetRequest();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;

    Widget getListview(groupModel, index) {
      return Container(
        child: Column(
          children: [
            Slidable(
              // delegate: new SlidableDrawerDelegate(),
              actionPane: SlidableDrawerActionPane(),
              actionExtentRatio: 0.18,
              child: new Container(
                  padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 5.0),
                  child: InkWell(
                    child: Column(
                      children: [
                        Container(
                            child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: ProfileImageView(
                                      imagePath: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(
                                              groupModel.groupImage),
                                      placeHolderImage:
                                          'assets/newDesignIcon/group/default_circle_bg.png',
                                      height: 48.0,
                                      width: 48.0,
                                      onTap: () async {
                                        String result = await Navigator.of(
                                                context)
                                            .push(MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        GroupDetailWidget(
                                                            groupModel.groupId,
                                                            "",
                                                            "",
                                                            "",
                                                            "")));
                                        if (result == 'push') {
                                          apiCallForGetRequest();
                                        }
                                      },
                                    ),
                                    flex: 0,
                                  ),
                                  Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        5.0,
                                        0.0,
                                        5.0,
                                        10.0,
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                0.0,
                                                2.0,
                                                0.0,
                                                RichText(
                                                  maxLines: 1,
                                                  textAlign: TextAlign.start,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  text: TextSpan(
                                                    text: groupModel.groupName +
                                                        " ",
                                                    style: TextStyle(
                                                      fontStyle:
                                                          FontStyle.normal,
                                                      color: AppConstants
                                                          .colorStyle.darkBlue,
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoMedium,
                                                    ),
                                                  ),
                                                )),
                                            Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 7.0, top: 6),
                                                child: RichText(
                                                  maxLines: 1,
                                                  textAlign: TextAlign.start,
                                                  text: TextSpan(
                                                    text: "For ",
                                                    style: TextStyle(
                                                      color: AppConstants
                                                          .colorStyle
                                                          .lightPurple,
                                                      fontSize: 12.0,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                    ),
                                                    children: <TextSpan>[
                                                      TextSpan(
                                                          text: groupModel
                                                              .studentName,
                                                          style: TextStyle(
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMBOLD,
                                                            fontSize: 12.0,
                                                            color: AppConstants
                                                                .colorStyle
                                                                .lightPurple,
                                                          ))
                                                    ],
                                                  ),
                                                )),
                                          ],
                                        )),
                                    flex: 1,
                                  ),
                                ],
                              ),
                              flex: 1,
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    top: 20.0, bottom: 12),
                                child: Row(
                                  children: <Widget>[
                                    InkWell(
                                      onTap: () {
                                        apiCallingForAccept(
                                            groupModel.groupId, 0, "Accepted");
                                      },
                                      child: Container(
                                          height: 26.0,
                                          width: 70,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color: ColorValues.WHITE,
                                            border: Border.all(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_2,
                                                width: 1),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    0.0, 0.0, 0.0, 2.0),
                                                child: BaseText(
                                                  text: 'Accept',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_2,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoRegular,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 14,
                                                  textAlign: TextAlign.start,
                                                  maxLines: 3,
                                                ),
                                              ),
                                            ],
                                          )),
                                    ),
                                    /*         InkWell(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(7.0, 0.0, 0.0, 0.0),
                                              child: Container(
                                                  height: 23.0,
                                                  width: 23.0,
                                                  child: Image.asset(
                                                    'assets/png/cancel_circle.png',
                                                  ))),
                                          onTap: () {
                                            apiCallingForAccept(
                                                groupModel.groupId, 0, "Rejected");
                                          },
                                        )*/
                                  ],
                                ),
                              ),
                              flex: 0,
                            )
                          ],
                        )),
                      ],
                    ),
                    onTap: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (BuildContext context) => GroupDetailWidget(
                              groupModel.groupId, "", "", "", "")));
                    },
                  )),

              secondaryActions: <Widget>[
                new SlideAction(
                  child: Text("Delete",
                      style: TextStyle(
                          color: ColorValues.WHITE,
                          fontSize: 14.0,
                          fontFamily: Constant.latoRegular)),
                  // color: ColorValues.Delete_lable_color,
                  decoration:
                      BoxDecoration(color: ColorValues.Delete_lable_color),
                  onTap: () {
                    apiCallingForAccept(groupModel.groupId, 0, "Rejected");
                  },
                ),
              ],
            ),
            Padding(
                padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 0.0),
                child: Divider(
                  color: ColorValues.BORDER_COLOR_NEW,
                  height: 2.0,
                )),
          ],
        ),
      );
    }

    return customAppbar(
      context,
      GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 20.0, right: 20, top: 24, bottom: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      BaseText(
                        text: 'Requests',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ],
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: groupRequestList.length == 0
                    ? Container()
                    : Container(
                        child: Column(
                        children: <Widget>[
                          Expanded(
                              child: ListView(
                            padding: EdgeInsets.zero,
                            controller: _scrollController,
                            children: <Widget>[
                              SizedBox(
                                height: 10,
                              ),
                              Column(
                                children: List.generate(groupRequestList.length,
                                    (int index) {
                                  return getListview(
                                      groupRequestList[index], false);
                                }),
                              )
                            ],
                          ))
                        ],
                      )),
                flex: 1,
              ),
            ],
          )),
      () {
        Navigator.pop(context, isPerformChanges);
      },
      isShowIcon: false,
    );
  }
}
