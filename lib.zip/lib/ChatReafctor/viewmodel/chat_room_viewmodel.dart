import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/app/locator.dart';
import 'package:spike_view_project/ChatReafctor/model/ChatModel.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/services/chat_service.dart';
import 'package:spike_view_project/ChatReafctor/services/opportunity_data_service.dart';
import 'package:spike_view_project/ChatReafctor/services/shared_data_service.dart';
import 'package:spike_view_project/PublicProfileFilter/PublicViewModel/PublicViewModel.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomViewForUser.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';

import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/chat/modal/ChatRoomModel.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/home/OpportunityView.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:stacked/stacked.dart';

import 'package:spike_view_project/modal/RewardStatusResponse.dart';

class ChatRoomViewModel extends FutureViewModel<List<ChatData>>
    with WidgetsBindingObserver {
  ChatRoomViewModel(
      this.mFriends, this.link, this.pageName, this.shareId, this.mContext);

  ShareProfileModal shareProfileModal;
  Friends mFriends;
  BuildContext mContext;
  final _sharedService = locator<SharedService>();
  final _opportunityService = locator<OpportunityService>();

  bool isLoading = true;

  String link = "", pageName, shareId;

  double mInputHeight = 50;

  SharedPreferences prefs;
  Timer _timer;

  //Register chat service in locator
  final _postsService = locator<ChatService>();

  List<ChatData> chatList = List();

  ScrollController mController = ScrollController();

  //Edittext controller for handle chat box area
  TextEditingController chatMessageEditTextController;

  String userIdPref, roleId, dob;

  bool isStartTypeingCalled = false;
  bool isTyping = false;
  StreamSubscription<dynamic> _streamSubscription;

  bool isEmojiVisible = false;
  bool isKeyboardVisible = false;
  final focusNode = FocusNode();
  int diffrenceInDob;
  PublicViewModel _PublicViewModel;

  bool isLoadMoreWithList = false;
  bool isLoadMoreApiCall = true;

  Future apiCallForPublicData(isShowLaoder, context, publicURL) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" +
            Constant.ENDPOINT_GET_PREVIEW_DETAIL_IN_PUBLIC +
            publicURL +
            "&profileType=Public&userId=" +
            userIdPref);
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_GET_PREVIEW_DETAIL_IN_PUBLIC +
                publicURL +
                "&profileType=Public&userId=" +
                userIdPref,
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _PublicViewModel = PublicViewModel.fromJson(response.data);

              if (_PublicViewModel != null &&
                  _PublicViewModel.result.profileView == "Linear") {
                try {
                  Navigator.of(context).push(new MaterialPageRoute(
                      builder: (BuildContext context) => PublicViewForUser(
                          publicURL,
                          pageName != null &&
                                  (pageName == "main" ||
                                      pageName == "notification")
                              ? "main"
                              : "chat",
                          "Public",
                          false)));
                } catch (e) {
                  print('Exception 111 e: $e');
                }
              } else {
                //print("pagename+++++++++++++++++++++++"+pageName);

                Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) => CustomPresoViewForUser(
                        publicURL,
                        pageName != null &&
                                (pageName == "main" ||
                                    pageName == "notification")
                            ? "main"
                            : "chat",
                        'Public',
                        false.toString(),
                        "")));
                //  ToastWrap.showToast("Presoview not implemented", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  Future apiCallingForUpdateStudentStatus(Friends model, context) async {
    try {
      Response response;
      print("rseponse+rseponse+++Chat+++++" + response.toString());
      Map map = {
        "sharedId": int.parse(shareId),
        "shareTo": model.partnerId,
        "roleId": int.parse(roleId)
      };
      print("request++++" + map.toString());
      response = await ApiCalling()
          .apiCallPutWithMapData(context, Constant.ENDPOINT_SHARE_UPDATE, map);
      print("Reward status response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            RewardStatus rewardStatus =
                RewardStatus.fromJson(response.data['result']['rewardStatus']);
            if (rewardStatus != null)
              Util.showRewardPoint(rewardStatus, context);
            //Util.updateGamificationPoints(rewardStatus);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    try {
      prefs = await SharedPreferences.getInstance();
      userIdPref = prefs.getString(UserPreference.USER_ID);
      roleId = prefs.getString(UserPreference.ROLE_ID);

      dob = prefs.getString(UserPreference.DOB);

      if (dob != null) {
        int d = int.tryParse(dob);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
        diffrenceInDob = DateTime.now().year - date.year;
        print("dob++++" + diffrenceInDob.toString());
      }

      _leaveOrEnterChatRoom(true);

      _streamSubscription =
          GlobalSocketConnection.updateChatController.stream.listen((data) {
        try {
          print("updatechat++++++++++++++++111" + data.toString());

          if ((mFriends.partnerId == data['sender'] &&
                  mFriends.partnerRoleId == data['senderRoleId']) ||
              (userIdPref == data['sender'].toString() &&
                  roleId == data['senderRoleId'].toString())) {
            String opportunityId = "",
                opportunityTitle = "",
                opportunityImage = "",
                opportunityDesc = "";
            if (data['type'] == Constant.opportunityPredefinedType) {
              // For Opportunity
              List<String> extracted_URL_KeyValues =
                  Util.fetchDataUsingURL(data['text']);
              opportunityId = extracted_URL_KeyValues[0];
              opportunityTitle = extracted_URL_KeyValues[1];
              opportunityImage = extracted_URL_KeyValues[2];
              opportunityDesc = extracted_URL_KeyValues[3];
            }

            var now = DateTime.now();
            var formatter = DateFormat('MMM dd, yyyy');
            String formatted = formatter.format(now);
            String converTedDate = "";

            print("Date++++++++++" + ChatModel.previousDateStamp);
            print("Date++++++++++" + formatted);
            if (ChatModel.previousDateStamp != formatted) {
              converTedDate = formatted;
            }

            chatList.add(new ChatData(
                messageId: 0,
                connectorId: data['connectorId'],
                sender: data['sender'],
                receiver: data['receiver'],
                deletedBy: 0,
                senderRoleId: data['senderRoleId'],
                receiverRoleId: data['receiverRoleId'],
                time: data['time'],
                text: data['text'],
                type: data['type'],
                status: data['status'],
                opportunityId: opportunityId,
                opportunityTitle: opportunityTitle,
                opportunityImage: opportunityImage,
                opportunityDesc: opportunityDesc,
                convertedDateString: converTedDate));
            if (converTedDate != "") {
              ChatModel.previousDateStamp = converTedDate;
            }
            onNotify();
          }
        } catch (e) {
          print("Error+++++++++++++chat===" + e.toString());
        }
      });

      _streamSubscription =
          GlobalSocketConnection.startTypingController.stream.listen((data) {
        print("startTyping on++++++++" +
            data.toString() +
            " " +
            mFriends.partnerId.toString() +
            " " +
            mFriends.partnerRoleId.toString());
        if ((mFriends.partnerId == data['sender'] &&
            mFriends.partnerRoleId == data['senderRoleId'])) {
          print("startTyping if++++");
          isTyping = true;
          notifyListeners();
        }
      });

      _streamSubscription =
          GlobalSocketConnection.stopTypingController.stream.listen((data) {
        print("stopTyping on++++++++" + data.toString());
        if ((mFriends.partnerId == data['sender'] &&
            mFriends.partnerRoleId == data['senderRoleId'])) {
          Timer(Duration(milliseconds: 100), () {
            isTyping = false;
            notifyListeners();
          });
        }
      });

      _streamSubscription =
          GlobalSocketConnection.onlineStatusController.stream.listen((data) {
        print("changeUserOnlineStatus++++++++" + data.toString());
        if (mFriends.partnerId == data['userId']) {
          if (data['presence_status'] == "online") {
            mFriends.online = 1;
            mFriends.lastSeen = data['lastSeen'];
          } else if (data['presence_status'] == "offline") {
            mFriends.online = 0;
            mFriends.lastSeen = data['lastSeen'];
          }
          notifyListeners();
        }
      });

      if (isApiCalling) {
        chatList.addAll(await _postsService.getPosts(
            mFriends, skip.toString(), false, mContext));
        isApiCalling = false;
        Future.delayed(Duration(milliseconds: 1000), () {
          onNotify();
        });
      }
      isLoading = false;
      if (link != null && link != "") {
        chatMessageEditTextController.selection =
            TextSelection.fromPosition(TextPosition(offset: 0));
      }

      notifyListeners();
    } catch (e) {
      print("Error+++" + e.toString());
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // fetchMessages();
    }
  }

  int positionOfChild = 0;
  int skip = 0;
  bool isApiCalling = true;

  @override
  Future initialise() {
    ChatModel.previousDateStamp = "";
    WidgetsBinding.instance.addObserver(this);
    chatMessageEditTextController = TextEditingController(text: link);
    if (link != null && link != "") {
      chatMessageEditTextController.selection =
          TextSelection.fromPosition(TextPosition(offset: 0));
    }
    chatMessageEditTextController.addListener(() {
      Map map = {
        "sender": mFriends.userId,
        "receiver": mFriends.partnerId,
        "connectorId": mFriends.connectId,
        "time": DateTime.now().millisecondsSinceEpoch,
        "senderRoleId": int.parse(roleId),
        "receiverRoleId": mFriends.partnerRoleId,
      };
      GlobalSocketConnection.socket
          .emitWithAck("startTyping", [map]).then((data) {
        isStartTypeingCalled = false;
        // this callback runs when this specific message is acknowledged by the server
        print("startTyping++++" +
            data.toString() +
            " " +
            chatMessageEditTextController.text);
      });

      if (_timer != null) {
        _timer.cancel();
      }
      _timer = Timer(Duration(milliseconds: 300), () {
        Map map = {
          "sender": mFriends.userId,
          "receiver": mFriends.partnerId,
          "connectorId": mFriends.connectId,
          "time": DateTime.now().millisecondsSinceEpoch,
          "senderRoleId": int.parse(roleId),
          "receiverRoleId": mFriends.partnerRoleId,
        };

        GlobalSocketConnection.socket
            .emitWithAck("stopTyping", [map]).then((data) {
          isStartTypeingCalled = true;
          // this callback runs when this specific message is acknowledged by the server
          print("stopTyping++++" +
              data.toString() +
              " " +
              chatMessageEditTextController.text);
        });
      });

      _checkInputHeight();
    });
    getSharedPreferences();

    KeyboardVisibility.onChange.listen((bool isKeyboardVisible) {
      this.isKeyboardVisible = isKeyboardVisible;

      if (isKeyboardVisible && isEmojiVisible) {
        isEmojiVisible = false;
      }

      notifyListeners();
    });

    mController.addListener(() async {
      if (mController.position.pixels == mController.position.minScrollExtent) {
        if (isLoadMoreApiCall) {
          isLoadMoreWithList = true;
          notifyListeners();
          skip = skip + 1;
          prefs.setString(UserPreference.chat_skip_count, skip.toString());
          apiCallingForMessage(mFriends, skip.toString(), true, mContext);
        }
      } else {
        isLoadMoreWithList = false;
      }
    });
    return super.initialise();
  }

  @override
  Future<List<ChatData>> futureToRun() {
    return null;
  }

  void onBack(context) {
    if (isEmojiVisible) {
      toggleEmojiKeyboard(context);
    } else {
      if (pageName == "notification") {
        if (roleId == "1") {
          // For Studenet
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));
        } else if (roleId == "2") {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Parent
        } else if (roleId == "4") {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Partner
        }
      } else {
        _leaveOrEnterChatRoom(false);

        Navigator.pop(
            context,
            chatList.length > 0
                ? ChatRoomModel(
                    chatList[chatList.length - 1].messageId.toString(),
                    chatList[chatList.length - 1].connectorId.toString(),
                    chatList[chatList.length - 1].sender.toString(),
                    chatList[chatList.length - 1].receiver.toString(),
                    chatList[chatList.length - 1].time.toString(),
                    chatList[chatList.length - 1].text,
                    chatList[chatList.length - 1].type.toString(),
                    chatList[chatList.length - 1].status.toString(),
                    chatList[chatList.length - 1].opportunityId,
                    chatList[chatList.length - 1].opportunityTitle,
                    chatList[chatList.length - 1].opportunityImage,
                    chatList[chatList.length - 1].opportunityDesc)
                : null);
      }
    }
  }

  Future toggleEmojiKeyboard(context) async {
    if (isKeyboardVisible) {
      FocusScope.of(context).unfocus();
    }

    isEmojiVisible = !isEmojiVisible;
    notifyListeners();
  }

  void onClickedEmoji(context) async {
    if (isEmojiVisible) {
      focusNode.requestFocus();
    } else if (isKeyboardVisible) {
      await SystemChannels.textInput.invokeMethod('TextInput.hide');
      await Future.delayed(Duration(milliseconds: 100));
    }
    toggleEmojiKeyboard(context); //onBlurred();
  }

  void _leaveOrEnterChatRoom(bool flag) async {
    if (GlobalSocketConnection.socket != null) {
      int screenId;
      screenId = flag ? 1 : 0;

      Map map = {
        "userId": mFriends.userId,
        "partnerId": mFriends.partnerId,
        "screenId": screenId,
        "userRoleId": int.parse(roleId),
        "partnerRoleId": mFriends.partnerRoleId,
      };
      print("makeConnection++++" + map.toString());
      GlobalSocketConnection.socket
          .emitWithAck("makeConnection", [map]).then((data) {
        print("makeConnection res++++" + data.toString());
      });
    }
  }

  void sendChatMessage({message}) async {
    print("message++++++++++++++++++++++++++++");

    try {
      if ((chatMessageEditTextController.text.trim().length > 0) ||
          (message != null && message != "")) {
        String msg = chatMessageEditTextController.text.toString();
        if (message != "" && message != null) {
          msg = message;
        }
        if (GlobalSocketConnection.socket != null) {
          int dateAndTimeMil = DateTime.now().millisecondsSinceEpoch;

          Map map = {
            "connectorId": mFriends.connectId,
            "sender": mFriends.userId,
            "receiver": mFriends.partnerId,
            "time": dateAndTimeMil,
            "text": msg,
            "type": 1,
            "senderRoleId": int.parse(roleId),
            "receiverRoleId": mFriends.partnerRoleId,
          };

          GlobalSocketConnection.socket
              .emitWithAck("sendMessage", [map]).then((data) {
            print("sendMessagechat++++" + data.toString());
          });

          chatMessageEditTextController.text = "";
        }
      }
    } catch (e) {
      print("Error send msg+++++" + e.toString());
    }
  }

  Future<Null> onRefresh() async {
    print("refreshpage+++++++++");
    notifyListeners();
    return null;
  }

  onTapPresoView(context) async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    await Navigator.push(
        context,
        MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) => SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, "chat")));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  Future shareIDData(shareId, context) async {
    try {
      print("rseponse+rseponse+++ChatroomViewModel+++++");
      CustomProgressLoader.showLoader(context);
      Response response = await _sharedService.getPosts(shareId);
      CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data['message'];
          print(response.toString());
          if (status == "Success") {
            shareProfileModal =
                ParseJson.parseShareProfile(response.data['result']);
            if (shareProfileModal.profileOwner != "") {
              print("profile status" + shareProfileModal.isActive);
              print("profile status" + shareProfileModal.isViewed);
              if (shareProfileModal.isActive == "true") {
                if (shareProfileModal.sharedView == "linear") {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) => ShareProfilePage(
                              shareProfileModal.profileOwner,
                              false,
                              "shareProfile",
                              shareProfileModal,
                              pageName != null &&
                                      (pageName == "main" ||
                                          pageName == "notification")
                                  ? "main"
                                  : "chat")));
                } else {
                  onTapPresoView(context);
                }
              } else {
                ToastWrap.showToast(
                    MessageConstant.ACCESS_PROFILE_REVOKED_ERROR, context);
              }
            }

            return;
          } else {
            ToastWrap.showToast(message, context);
          }
        }
      }
    } catch (e) {
      e.toString();
      return;
    }
  }

  Future getOpportunityUsingId(opportunityId, context) async {
    try {
      print("rseponse+rseponse+++ChatroomViewModel+++++");
      CustomProgressLoader.showLoader(context);
      Response response = await _opportunityService.getPosts(opportunityId);
      CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data['message'];
          print(response.toString());
          if (status == "Success") {
            // get Accepted array from data
            if (response.data['result'].length == 0) {
              ToastWrap.showToast(MessageConstant.FEED_IS_DELETED, context);
            } else {
              List<UserPostModal> activeOpportunityList = List();

              activeOpportunityList = await ParseJson.parseHomeData(
                  response.data['result'], userIdPref, roleId);

              Future.delayed(const Duration(seconds: 1), () {
                if (activeOpportunityList[0].opportunityModelForFeed != null) {
                  Navigator.of(context).push(new MaterialPageRoute(
                      builder: (BuildContext context) => OpportunityViewWidget(
                          activeOpportunityList[0].opportunityModelForFeed,
                          activeOpportunityList[0].feedId,
                          userIdPref,
                          roleId,
                          diffrenceInDob,
                          "")));
                }
              });
            }
          } else {
            ToastWrap.showToast(message, context);
          }
        }
      }
    } catch (e) {
      e.toString();
      return;
    }
  }

  onTapText(text, context) async {
    if (Util.isOpportunitySharedView(text)) {
      if (text.contains("/sv/")) {
        String publicURL = text.split("/sv/")[1];

        apiCallForPublicData(true, context, publicURL);
      } else if (text.contains("previewprofile") ||
          text.contains("publicprofile")) {
        String sharedId = "";
        if (text.contains("shareProfile")) {
          text = text.split("/shareProfile/")[0];
          sharedId = text.substring(text.lastIndexOf("/") + 1);
        } else {
          sharedId = text.substring(text.lastIndexOf("/") + 1);
        }

        if (sharedId != "") {
          print("sharedId+++++" + sharedId);
          String decodedSharedId = '';
          try {
            Codec<String, String> stringToBase64 = utf8.fuse(base64);
            decodedSharedId = stringToBase64
                .decode(sharedId.replaceAll("&SPK", "=")); // username:password
            print('SharedID public preview 111:: ${sharedId}');
            print('decodedSharedId public preview 111:: ${decodedSharedId}');
            if (decodedSharedId != null && decodedSharedId != "") {
              //  Navigator.pop(context);
              shareIDData(decodedSharedId, context);
              // CustomProgressLoader.cancelLoader(context);
            }
          } catch (e) {}
        }
      } else if (text.contains("cus") && text.contains("Linear")) {
        String shareId = text.split("/Linear/")[1];
        try {
          Codec<String, String> stringToBase64 = utf8.fuse(base64);
          String decodedSharedId = stringToBase64
              .decode(shareId.replaceAll("&SPK", "=")); // username:password
          print('SharedID public preview 111:: ${shareId}');
          print('decodedSharedId public preview 111:: ${decodedSharedId}');
          if (decodedSharedId != null && decodedSharedId != "") {
            print('CustomViewForUser 111:: ${pageName}');
            print('CustomViewForUser 111:: ' + pageName.toString());
            print('CustomViewForUser Test:: ' + pageName.toString());
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => CustomViewForUser(
                    decodedSharedId,
                    pageName != null &&
                            (pageName == "main" || pageName == "notification")
                        ? "main"
                        : "chat")));

            //  Navigator.pop(context);
            // CustomProgressLoader.cancelLoader(context);
          }
        } catch (e) {
          print('Exception 111 e: $e');
        }
      } else if (text.contains("cus") && text.contains("Preso")) {
        //http://app.spikeview.com/cus/Preso/MjIxNA==
        String shareId = text.split("/Preso/")[1];
        try {
          Codec<String, String> stringToBase64 = utf8.fuse(base64);
          String decodedSharedId = stringToBase64
              .decode(shareId.replaceAll("&SPK", "=")); // username:password
          print('SharedID public preview 111:: ${shareId}');
          print('decodedSharedId public preview 111:: ${decodedSharedId}');
          if (decodedSharedId != null && decodedSharedId != "") {
            Navigator.pop(context);
            //print("pagename+++++++++++++++++++++++"+pageName);
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) => CustomPresoViewForUser(
                    decodedSharedId,
                    pageName != null &&
                            (pageName == "main" || pageName == "notification")
                        ? "main"
                        : "chat",
                    'Custom',
                    false.toString(),
                    "")));

            // CustomProgressLoader.cancelLoader(context);
          }
        } catch (e) {
          print('Exception 222 e: $e');
        }
      }
    } else {
      Navigator.push(
          context,
          MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
              builder: (context) => WebViewWidget(text, "spikeview")));
    }
  }

  onTapOpportunity(opportunityId, context) {
    getOpportunityUsingId(opportunityId, context);
  }

  //Handle chat box area height
  void _checkInputHeight() async {
    int numLines1 = '\n'.allMatches(chatMessageEditTextController.text).length;
    int numLines = (chatMessageEditTextController.text.length / 30).round();

    if (numLines1 > numLines) {
      numLines = numLines1;
    }

    if (numLines == 0) {
      mInputHeight = 50.0;
    } else {
      if (mInputHeight <= 150.0) mInputHeight = 50.0 * numLines;
    }
    notifyListeners();
  }

  void onNotify() {
    if (mController?.position != null) {
      Timer(Duration(milliseconds: 300),
          () => mController?.jumpTo(mController.position.maxScrollExtent));
    }
    notifyListeners();
  }

  Future<void> apiCallingForMessage(
      Friends model, skip, bool loader, BuildContext mContext) async {
    try {
      // CustomProgressLoader.showLoader(mContext);

      notifyListeners();
      ChatModel.previousDateStamp = "";

      print('chat Api+ message api ------------ ++++++++==' +
          ChatModel.previousDateStamp);

      print(Constant.ENDPOINT_CHAT_HISTORY +
          model.connectId.toString() +
          "&userId=" +
          userIdPref.toString() +
          "&roleId=" +
          roleId.toString() +
          "&skip=" +
          skip.toString());

      Response response = await ApiCalling2().apiCall(
          null,
          Constant.ENDPOINT_CHAT_HISTORY +
              model.connectId.toString() +
              "&userId=" +
              userIdPref.toString() +
              "&skip=" +
              skip.toString() +
              "&roleId=" +
              roleId.toString(),
          "get");

      for (var j = 0; j < chatList.length; j++) {
        if (chatList[j].messageId == 010) {
          chatList.removeAt(j);
        }
      }

      notifyListeners();

      // _posts.clear();
      print('response message ------------+++++++++==' + response.toString());
      String convertedDateString = "";

      if (userIdPref == 1) {
        if (model.creationTime != null &&
            model.creationTime != "null" &&
            model.creationTime != "") {
          int millis = int.tryParse(model.creationTime.toString());
          var now = DateTime.fromMillisecondsSinceEpoch(millis);
          var formatter = DateFormat('MMM dd, yyyy');
          String formatted = formatter.format(now);
          ChatModel.previousDateStamp = formatted;
          convertedDateString = formatted;
        }
      } else {
        if (model.partnerId.toString() == "1") {
          String creationTime = prefs.getString(UserPreference.CREATION_TIME);
          if (creationTime != null &&
              creationTime != "null" &&
              creationTime != "") {
            int millis = int.tryParse(creationTime.toString());
            var now = DateTime.fromMillisecondsSinceEpoch(millis);
            var formatter = DateFormat('MMM dd, yyyy');
            String formatted = formatter.format(now);

            ChatModel.previousDateStamp = formatted;
            convertedDateString = formatted;
          }
        }
      }

      ChatModel _mFrienndListModel = await ChatModel.fromJson(response.data);

      // CustomProgressLoader.cancelLoader(mContext);
      //  List<ChatData> chat_list =  List();
      // chat_list.addAll(_mFrienndListModel.mChatDataList);

      if (_mFrienndListModel == null ||
          _mFrienndListModel.mChatDataList == null ||
          _mFrienndListModel.mChatDataList.length == 0) {
        print("isloadmore+++++false");
        isLoadMoreApiCall = false;
      } else {
        print("isloadmore+++++true");
      }

      for (var i = 0; i < _mFrienndListModel.mChatDataList.length; i++) {
        chatList.insert(i, _mFrienndListModel.mChatDataList[i]);
      }
      notifyListeners();
      chatList.insert(
          0,
          ChatData(
              messageId: 010,
              connectorId: 0,
              sender: 1,
              receiver: 0,
              deletedBy: 0,
              time: model.creationTime,
              text:
                  "Welcome to spikeview! Look around, invite your friends and let us know how we can help.",
              type: 1,
              status: 0,
              convertedDateString: convertedDateString));

      isLoadMoreWithList = false;
      notifyListeners();
      //   chatList.addAll(_mFrienndListModel.mChatDataList);

    } catch (e) {
      print("Error+++" + e.toString());
      // CustomProgressLoader.cancelLoader(mContext);
    }
  }
}
