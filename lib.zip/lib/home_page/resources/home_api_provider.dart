import 'dart:async';

import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/common/Connectivity.dart';


class HomeApiProvider {

  Future<List<UserPostModal>> fetchPostData(userIdPref, roleId, context) async {
    DateTime dateFormat = DateTime.now();
    print(dateFormat);
    List<UserPostModal> userPostList =  List<UserPostModal>();
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      String url = "";
      int count = await DbHelper().numberOfItem();
   /*   if (count == 0) {
        url = "ui/feed/feedListPOC?userId=" +
            "$userIdPref&skip=0" +
            "&roleId=" +
            roleId;
      } else {*/
        url = Constant.ENDPOINT_FEED_DATA +
            "$userIdPref&skip=0" +
            "&roleId=" +
            roleId;
     // }
      /*     print("number of item++++" + count.toString());
      print("number of item++++" + url.toString());*/

      final response = await  ApiCalling2().apiCall(context, url, "get");
      print("response item++++fetch post++" + response.toString());
      if (response.statusCode == 200) {
        DateTime dateFormat1 = DateTime.now();
        print(dateFormat1);
        final final_time = dateFormat1.difference(dateFormat).inSeconds;

        if (final_time > Constant.FEED_DATA_RESPONSE_MAX_TIME) {
          API.ApiForUpdateReportStatus(
              context,
              "get",
              Constant.ENDPOINT_FEED_DATA,
              "userId=" + userIdPref + "&roleId=1",
              final_time.toString());
        }
        print("userPostList response data");
        userPostList.addAll(ParseJson.parseHomeModel(
            response.data['result'], userIdPref, roleId));
        print("userPostList++++" + userPostList.length.toString());

        return userPostList;
      } else {
        return userPostList;
        // If that call was not successful, throw an error.
        throw Exception('Failed to load post');
      }
    }
  }



}
