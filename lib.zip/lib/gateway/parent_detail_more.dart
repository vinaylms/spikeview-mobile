// Updated COde

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/MaskedTextInputFormatter.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/CountryListModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:http/http.dart' as http;
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/gateway/ReferalCodeResponse.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

class ParentData extends StatefulWidget {
  bool isEducatorAllowedDomain;

  ParentData(this.isEducatorAllowedDomain);

  @override
  ParentDataState createState() => ParentDataState();
}

class ParentDataState extends State<ParentData> {
  final formKey = GlobalKey<FormState>();
  final formKeyReferal = GlobalKey<FormState>();

  Color borderColor = Colors.amber;
  BuildContext context;
  bool isAgree = false;
  SharedPreferences prefs;

  int strDateOfBirth = 0;
  int diffrenceInDob = 14;

  static const platform = const MethodChannel('samples.flutter.io/battery');

  showSucessMsgLong(msg, context) {
    Timer _timer;
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  secondryEmailApi() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        Address address2;

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {
          'Authorization': prefs.getString(UserPreference.USER_TOKEN)
        };

        Map map = {
          "secondaryEmail": emailTxtController.text,
          "userId": userId,
          "countryCode": '+1',
          "roleId": '1',
          "mobileNo": numberTxtController.text.replaceAll('-', ''),
          //"otp": otpTxtController.text
        };

        print("map+++++11111111" + map.toString());

        Response response =
            await dio.put(Constant.ADD_PERSONAL_EMAIL, data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        print("response+++++11111111" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            Navigator.pop(context);
            StudentOnBoarding()
                .getStudentOnBoardingInit(context, null, "", userId);
          } else {
            ToastWrap.showToast(message, context);
          }
        } else {
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        if (mounted) CustomProgressLoader.cancelLoader(context);

        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  loginServiceCall() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token};
        // Prepare Data

        Map map = {
          "studentUserId": userId,
          "studentEmail": email,
          "firstName": strFirstName,
          "lastName": strLastName,
          "email": strEmail.toLowerCase(),
          "roleId": 2,
          "signupType": "spikeview",
          "platformType": "mobile",
          "isAcceptedTermCon": true,
          "isParentWithStu": true,
        };

        print("map+++++" + map.toString());
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_PARENT_SIGNUP,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);

        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setBool(UserPreference.IS_ADDED_DOB, true);
            if (widget.isEducatorAllowedDomain) {
              AddSecondaryEmailDialog();
            } else {
              StudentOnBoarding()
                  .getStudentOnBoardingInit(context, null, "", userId);
            }
          } else {
            ToastWrap.showToastLong(message, context);
          }
        } else {
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ParentDetailMore", context);
        if (mounted) CustomProgressLoader.cancelLoader(context);

        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  void _checkValidation() async {
    try {
      final form = formKey.currentState;
      form.save();
      AddSecondaryEmailDialog();
      if (form.validate()) {
        loginServiceCall();
      } else {}
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDetailMore", context);
      print("error+++" + e.toString());
    }
  }

  final FocusNode firstNameFocus = FocusNode();
  final FocusNode lastNameFocus = FocusNode();
  final FocusNode emailFocus = FocusNode();

  TextEditingController firstNameController = TextEditingController(text: "");
  TextEditingController lastNameController = TextEditingController(text: "");
  TextEditingController emailController = TextEditingController(text: "");
  bool isUnderAge = true;
  TextEditingController emailTxtController = TextEditingController(text: "");
  final _formKey2 = GlobalKey<FormState>();
  TextEditingController otpTxtController = TextEditingController(text: "");

  TextEditingController numberTxtController = TextEditingController(text: "");
  String strNewPassword = "";

  String token;
  String roleId = "", userId = "", email = "";

  Future<bool> sendOtpEmail() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        Address address2;

        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {
          'Authorization': prefs.getString(UserPreference.USER_TOKEN)
        };

        Map map = {
          "secondaryEmail": emailTxtController.text,
          "userId": userId,
          "roleId": '1',
        };
        print("map+++++11111111" + map.toString());

        Response response =
            await dio.put(Constant.SEND_OTP_ON_EMAIL, data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        print("response+++++11111111" + response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            ToastWrap.showToasSucess(message.toString(), context);
            return true;
          } else {
            ToastWrap.showToast(message, context);
            return false;
          }
        } else {
          return false;
          // If that call was not successful, throw an error.
          throw Exception(MessageConstant.SOMETHING_WENT_WRONG_ERROR);
        }
      } catch (e) {
        if (mounted) CustomProgressLoader.cancelLoader(context);
        return false;
        print(e);
        ToastWrap.showToast(
            MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
      }
    } else {
      return false;
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  //String gender;
  bool isOtpSend = false;

  AddSecondaryEmailDialog11() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return StatefulBuilder(builder: (context, StateSetter setState) {
            return WillPopScope(
                onWillPop: () {
                  Navigator.pop(context);
                },
                child: Container(
                  child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          child: Column(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Container(
                                    padding: EdgeInsets.all(12.0),
                                    width: double.infinity,
                                    color: Colors.white,
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 15.0, bottom: 25),
                                            child: Center(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                ),
                                                height: 4.0,
                                                width: 55,
                                              ),
                                            ),
                                          ),
                                          Form(
                                            key: _formKey2,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  MessageConstant
                                                      .CHANGE_EXISTING_EMAIL,
                                                  style: TextStyle(
                                                      fontSize: 16.0,
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                  MessageConstant
                                                      .CHANGE_EXISTING_EMAIL_TEXT_ONBOARDING,
                                                  style: TextStyle(
                                                      fontSize: 12.0,
                                                      color: ColorValues
                                                          .GREY__COLOR,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w400),
                                                ),
                                                SizedBox(
                                                  height: 20,
                                                ),
                                                /* Container(
                                                  child: Text(
                                                    "Personal Email Address",
                                                    textAlign: TextAlign.start,
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.black,
                                                        fontSize: 12.0,
                                                        fontFamily:
                                                            "customRegular"),
                                                  ),
                                                ),*/

                                                Row(
                                                  children: <Widget>[
                                                    Expanded(
                                                        child: Container(
                                                          child: TextFormField(
                                                            controller:
                                                                emailTxtController,
                                                            keyboardType:
                                                                TextInputType
                                                                    .emailAddress,
                                                            textInputAction:
                                                                TextInputAction
                                                                    .done,
                                                            validator: (val) => val
                                                                        .trim()
                                                                        .length ==
                                                                    0
                                                                ? MessageConstant
                                                                    .ENTER_EMAIL_VAL
                                                                : /* !ValidationWidget.isEmail(val)
                                                            ? MessageConstant.ENTER_CORRECRT_EMAIL_VAL
                                                            : !*/
                                                                ValidationWidget
                                                                    .isSecondaryEmail(
                                                                        val,
                                                                        educatorAllowedDomain)
                                                            /* ? MessageConstant
                                                                    .ENTER_CORRECRT_DOMAIN_VAL
                                                                : null*/
                                                            ,
                                                            cursorColor: Constant
                                                                .CURSOR_COLOR,
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontFamily:
                                                                    "customRegular"),
                                                            decoration:
                                                                InputDecoration(
                                                                    suffixIcon:
                                                                        InkWell(
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets.only(
                                                                            top:
                                                                                8.0,
                                                                            bottom:
                                                                                8),
                                                                        child: Container(
                                                                            decoration: BoxDecoration(
                                                                              border: Border.all(color: ColorValues.BLUE_COLOR_BOTTOMBAR, width: 1),
                                                                              borderRadius: BorderRadius.all(Radius.circular(5)),
                                                                              color: Color(0xffFFFFFF),
                                                                            ),
                                                                            padding: EdgeInsets.all(5.0),
                                                                            width: 65,
                                                                            child: Text(
                                                                              "Verify",
                                                                              textAlign: TextAlign.center,
                                                                              style: TextStyle(color: ColorValues.BLUE_COLOR_BOTTOMBAR, fontSize: 14.0, fontFamily: Constant.customRegular),
                                                                            )),
                                                                      ),
                                                                      onTap:
                                                                          () async {
                                                                        final form1 =
                                                                            _formKey2.currentState;

                                                                        form1
                                                                            .save();
                                                                        if (form1
                                                                            .validate()) {
                                                                          print("isotp+++" +
                                                                              isOtpSend.toString());
                                                                          isOtpSend =
                                                                              await sendOtpEmail();
                                                                          print("isotp+++" +
                                                                              isOtpSend.toString());
                                                                          setState(
                                                                              () {
                                                                            isOtpSend;
                                                                          });
                                                                        }
                                                                      },
                                                                    ),
                                                                    contentPadding:
                                                                        const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                    focusedBorder: UnderlineInputBorder(
                                                                        borderSide: BorderSide(
                                                                            color: ColorValues
                                                                                .GREY__COLOR_DIVIDER)),
                                                                    enabledBorder: UnderlineInputBorder(
                                                                        borderSide: BorderSide(
                                                                            color: ColorValues
                                                                                .GREY__COLOR_DIVIDER)),
                                                                    errorStyle: Util
                                                                        .errorTextStyle,
                                                                    labelText:
                                                                        "Personal Email Address",
                                                                    errorMaxLines:
                                                                        2,
                                                                    labelStyle: TextStyle(
                                                                        color: ColorValues
                                                                            .black,
                                                                        fontFamily:
                                                                            "customRegular"),
                                                                    border: UnderlineInputBorder(
                                                                        borderSide:
                                                                            BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                          ),
                                                        ),
                                                        flex: 1),
                                                    /* Expanded(
                                                    child:  InkWell(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(top:8.0,bottom: 8),
                                                        child: Container(
                                                            decoration:
                                                            BoxDecoration(
                                                              border: Border.all(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  width:
                                                                  1),
                                                              borderRadius: BorderRadius.all(Radius.circular(5)),
                                                              color: Color(
                                                                  0xffFFFFFF),

                                                            ),

                                                            padding:
                                                            EdgeInsets
                                                                .all(
                                                                5.0),
                                                            width: 65,
                                                            child: Text(
                                                              "Verify",
                                                              textAlign:
                                                              TextAlign
                                                                  .center,
                                                              style: TextStyle(
                                                                  color:ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  fontSize:
                                                                  14.0,
                                                                  fontFamily:
                                                                  Constant
                                                                      .customRegular),
                                                            )),
                                                      ),
                                                      onTap: () async{
                                                        final form1 =
                                                            _formKey2
                                                                .currentState;

                                                        form1.save();
                                                        if (form1
                                                            .validate()) {
                                                          print("isotp+++"+isOtpSend.toString());
                                                          isOtpSend=await   sendOtpEmail();
                                                          print("isotp+++"+isOtpSend.toString());
                                                          setState(() {
                                                            isOtpSend;
                                                          });
                                                        }
                                                      },
                                                    ),
                                                    flex: 0)*/
                                                  ],
                                                ),
                                                isOtpSend
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 20.0),
                                                        child: TextFormField(
                                                          controller:
                                                              otpTxtController,
                                                          keyboardType:
                                                              TextInputType
                                                                  .number,
                                                          textInputAction:
                                                              TextInputAction
                                                                  .done,
                                                          maxLength: 20,
                                                          validator:
                                                              (String arg) {
                                                            if (arg.length >
                                                                3) {
                                                              return null;
                                                            } else {
                                                              return MessageConstant
                                                                  .ENTER_CORRECT_INPUT_VAL;
                                                            }
                                                          },
                                                          inputFormatters: [
                                                            WhitelistingTextInputFormatter
                                                                .digitsOnly,
                                                          ],
                                                          cursorColor: Constant
                                                              .CURSOR_COLOR,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.black,
                                                              fontFamily:
                                                                  "customRegular"),
                                                          decoration: InputDecoration(
                                                              counterText: '',
                                                              contentPadding:
                                                                  const EdgeInsets.fromLTRB(
                                                                      0.0,
                                                                      -5.0,
                                                                      0.0,
                                                                      0.0),
                                                              focusedBorder: UnderlineInputBorder(
                                                                  borderSide: BorderSide(
                                                                      color: ColorValues
                                                                          .GREY__COLOR_DIVIDER)),
                                                              enabledBorder: UnderlineInputBorder(
                                                                  borderSide: BorderSide(
                                                                      color: ColorValues
                                                                          .GREY__COLOR_DIVIDER)),
                                                              errorStyle: Util
                                                                  .errorTextStyle,
                                                              labelText:
                                                                  'Enter verification code',
                                                              labelStyle: TextStyle(
                                                                  color:
                                                                      ColorValues
                                                                          .black,
                                                                  fontFamily:
                                                                      "customRegular"),
                                                              border:
                                                                  UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                        ),
                                                      )
                                                    : SizedBox(
                                                        height: 0,
                                                      ),
                                                SizedBox(
                                                  height: 20,
                                                ),

                                                /* Text(
                                                  "Cell Phone Number (Optional)",
                                                  textAlign: TextAlign.start,
                                                  style: TextStyle(
                                                      color: ColorValues.black,
                                                      fontSize: 12.0,
                                                      fontFamily:
                                                          "customRegular"),
                                                ),*/

                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .baseline,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  textBaseline:
                                                      TextBaseline.ideographic,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 12.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      17,
                                                                      13,
                                                                      10),
                                                              child:
                                                                  Image.asset(
                                                                "assets/us.png",
                                                                width: 30.0,
                                                                height: 20.0,
                                                              ),
                                                            ),
                                                            Container(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER,
                                                              height: 1.2,
                                                              width: 45,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 0,
                                                    ),
                                                    Expanded(
                                                      child: TextFormField(
                                                        controller:
                                                            numberTxtController,
                                                        keyboardType:
                                                            TextInputType
                                                                .number,
                                                        textInputAction:
                                                            TextInputAction
                                                                .done,
                                                        maxLength: 20,
                                                        validator:
                                                            (String arg) {
                                                          if (arg.length > 0) {
                                                            if (arg.length >
                                                                7) {
                                                              return null;
                                                            } else {
                                                              return MessageConstant
                                                                  .ENTER_CORRECT_INPUT_VAL;
                                                            }
                                                          } else {
                                                            return null;
                                                          }
                                                        },
                                                        inputFormatters: [
                                                          WhitelistingTextInputFormatter
                                                              .digitsOnly,
                                                          MaskedTextInputFormatter(),
                                                        ],
                                                        cursorColor: Constant
                                                            .CURSOR_COLOR,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontFamily:
                                                                "customRegular"),
                                                        decoration: InputDecoration(
                                                            counterText: '',
                                                            contentPadding:
                                                                const EdgeInsets.fromLTRB(
                                                                    0.0,
                                                                    -5.0,
                                                                    0.0,
                                                                    0.0),
                                                            focusedBorder: UnderlineInputBorder(
                                                                borderSide: BorderSide(
                                                                    color: ColorValues
                                                                        .GREY__COLOR_DIVIDER)),
                                                            enabledBorder: UnderlineInputBorder(
                                                                borderSide: BorderSide(
                                                                    color: ColorValues
                                                                        .GREY__COLOR_DIVIDER)),
                                                            errorStyle: Util
                                                                .errorTextStyle,
                                                            labelText:
                                                                'Cell Phone Number (Optional)',
                                                            labelStyle: TextStyle(
                                                                color: ColorValues
                                                                    .black,
                                                                fontFamily:
                                                                    "customRegular"),
                                                            border: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 15,
                                                ),
                                                //  prefs.getString(UserPreference.EMAIL)
                                              ],
                                            ),
                                          ),
                                          isOtpSend
                                              ? PaddingWrap.paddingfromLTRB(
                                                  13.0,
                                                  20.0,
                                                  13.0,
                                                  15.0,
                                                  Center(
                                                    child: Container(
                                                        color: ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        padding: EdgeInsets.all(
                                                            10.0),
                                                        width: 222,
                                                        height: 45.0,
                                                        child: Row(
                                                          children: <Widget>[
                                                            Expanded(
                                                              child: InkWell(
                                                                child: Container(
                                                                    child: Text(
                                                                  "Save",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: TextStyle(
                                                                      color: Colors
                                                                          .white,
                                                                      fontSize:
                                                                          16.0,
                                                                      fontFamily:
                                                                          Constant
                                                                              .customRegular),
                                                                )),
                                                                onTap: () {
                                                                  final form1 =
                                                                      _formKey2
                                                                          .currentState;

                                                                  form1.save();
                                                                  if (form1
                                                                      .validate()) {
                                                                    secondryEmailApi();
                                                                  }
                                                                },
                                                              ),
                                                              flex: 1,
                                                            ),
                                                          ],
                                                        )),
                                                  ))
                                              : PaddingWrap.paddingfromLTRB(
                                                  13.0,
                                                  20.0,
                                                  13.0,
                                                  15.0,
                                                  Center(
                                                    child: Stack(
                                                      children: <Widget>[
                                                        Container(
                                                            color: ColorValues
                                                                .BLUE_COLOR_BOTTOMBAR,
                                                            padding:
                                                                EdgeInsets.all(
                                                                    10.0),
                                                            width: 222,
                                                            height: 45.0,
                                                            child: Row(
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  child:
                                                                      InkWell(
                                                                    child: Container(
                                                                        child: Text(
                                                                      "Save",
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      style: TextStyle(
                                                                          color: Colors
                                                                              .white,
                                                                          fontSize:
                                                                              16.0,
                                                                          fontFamily:
                                                                              Constant.customRegular),
                                                                    )),
                                                                    onTap:
                                                                        () {},
                                                                  ),
                                                                  flex: 1,
                                                                ),
                                                              ],
                                                            )),
                                                        Container(
                                                          color: Colors.white
                                                              .withOpacity(.5),
                                                          padding:
                                                              EdgeInsets.all(
                                                                  10.0),
                                                          width: 222,
                                                          height: 45.0,
                                                        )
                                                      ],
                                                    ),
                                                  ))
                                        ]),
                                  )),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ));
          });
        });
  }

  AddSecondaryEmailDialog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        Container(
                          child: Column(
                            children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Container(
                                    padding: EdgeInsets.all(12.0),
                                    width: double.infinity,
                                    color: Colors.white,
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 15.0, bottom: 25),
                                            child: Center(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5.0),
                                                ),
                                                height: 4.0,
                                                width: 55,
                                              ),
                                            ),
                                          ),
                                          Form(
                                            key: _formKey2,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  MessageConstant
                                                      .CHANGE_EXISTING_EMAIL,
                                                  style: TextStyle(
                                                      fontSize: 16.0,
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                  MessageConstant
                                                      .CHANGE_EXISTING_EMAIL_TEXT_ONBOARDING,
                                                  style: TextStyle(
                                                      fontSize: 12.0,
                                                      color: ColorValues
                                                          .GREY__COLOR,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontWeight:
                                                          FontWeight.w400),
                                                ),
                                                SizedBox(
                                                  height: 20,
                                                ),

                                                TextFormField(
                                                  controller:
                                                      emailTxtController,
                                                  keyboardType: TextInputType
                                                      .emailAddress,
                                                  textInputAction:
                                                      TextInputAction.done,
                                                  validator: (val) => val
                                                              .trim()
                                                              .length ==
                                                          0
                                                      ? MessageConstant
                                                          .ENTER_EMAIL_VAL
                                                      : /* !ValidationWidget.isEmail(val)
                                                            ? MessageConstant.ENTER_CORRECRT_EMAIL_VAL
                                                            : !*/
                                                      ValidationWidget
                                                          .isSecondaryEmail(val,
                                                              educatorAllowedDomain)
                                                  /* ? MessageConstant
                                                                    .ENTER_CORRECRT_DOMAIN_VAL
                                                                : null*/
                                                  ,
                                                  cursorColor:
                                                      Constant.CURSOR_COLOR,
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          "customRegular"),
                                                  decoration: InputDecoration(
                                                      contentPadding:
                                                          const EdgeInsets.fromLTRB(
                                                              0.0, 0.0, 0.0, 0.0),
                                                      focusedBorder: UnderlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER)),
                                                      enabledBorder: UnderlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER)),
                                                      errorStyle:
                                                          Util.errorTextStyle,
                                                      labelText:
                                                          "Personal Email Address",
                                                      errorMaxLines: 2,
                                                      labelStyle: TextStyle(
                                                          color:
                                                              ColorValues.black,
                                                          fontFamily:
                                                              "customRegular"),
                                                      border: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                ),

                                                SizedBox(
                                                  height: 20,
                                                ),

                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .baseline,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  textBaseline:
                                                      TextBaseline.ideographic,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 12.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      17,
                                                                      13,
                                                                      10),
                                                              child:
                                                                  Image.asset(
                                                                "assets/us.png",
                                                                width: 30.0,
                                                                height: 20.0,
                                                              ),
                                                            ),
                                                            Container(
                                                              color: ColorValues
                                                                  .GREY__COLOR_DIVIDER,
                                                              height: 1.2,
                                                              width: 45,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      flex: 0,
                                                    ),
                                                    Expanded(
                                                      child: TextFormField(
                                                        controller:
                                                            numberTxtController,
                                                        keyboardType:
                                                            TextInputType
                                                                .number,
                                                        textInputAction:
                                                            TextInputAction
                                                                .done,
                                                        maxLength: 20,
                                                        validator:
                                                            (String arg) {
                                                          if (arg.length > 0) {
                                                            if (arg.length >
                                                                7) {
                                                              return null;
                                                            } else {
                                                              return MessageConstant
                                                                  .ENTER_VALID_PHONE_NUMBER_VAL;
                                                            }
                                                          } else {
                                                            return null;
                                                          }
                                                        },
                                                        inputFormatters: [
                                                          WhitelistingTextInputFormatter
                                                              .digitsOnly,
                                                          MaskedTextInputFormatter(),
                                                        ],
                                                        cursorColor: Constant
                                                            .CURSOR_COLOR,
                                                        style: TextStyle(
                                                            color: Colors.black,
                                                            fontFamily:
                                                                "customRegular"),
                                                        decoration: InputDecoration(
                                                            counterText: '',
                                                            contentPadding:
                                                                const EdgeInsets.fromLTRB(
                                                                    0.0,
                                                                    -5.0,
                                                                    0.0,
                                                                    0.0),
                                                            focusedBorder: UnderlineInputBorder(
                                                                borderSide: BorderSide(
                                                                    color: ColorValues
                                                                        .GREY__COLOR_DIVIDER)),
                                                            enabledBorder: UnderlineInputBorder(
                                                                borderSide: BorderSide(
                                                                    color: ColorValues
                                                                        .GREY__COLOR_DIVIDER)),
                                                            errorStyle: Util
                                                                .errorTextStyle,
                                                            labelText:
                                                                'Cell Phone Number (Optional)',
                                                            labelStyle: TextStyle(
                                                                color: ColorValues
                                                                    .black,
                                                                fontFamily:
                                                                    "customRegular"),
                                                            border: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.GREY__COLOR_DIVIDER))),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                                SizedBox(
                                                  height: 15,
                                                ),
                                                //  prefs.getString(UserPreference.EMAIL)
                                              ],
                                            ),
                                          ),
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              20.0,
                                              13.0,
                                              15.0,
                                              Center(
                                                child: Container(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    padding:
                                                        EdgeInsets.all(10.0),
                                                    width: 222,
                                                    height: 45.0,
                                                    child: Row(
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: InkWell(
                                                            child: Container(
                                                                child: Text(
                                                              "Save",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .white,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .customRegular),
                                                            )),
                                                            onTap: () {
                                                              final form1 =
                                                                  _formKey2
                                                                      .currentState;

                                                              form1.save();
                                                              if (form1
                                                                  .validate()) {
                                                                secondryEmailApi();
                                                              }
                                                            },
                                                          ),
                                                          flex: 1,
                                                        ),
                                                      ],
                                                    )),
                                              ))
                                        ]),
                                  )),
                            ],
                          ),
                        ),
                      ],
                    )))));
  }

  List<String> educatorAllowedDomain = List();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    token = prefs.getString(UserPreference.USER_TOKEN);
    userId = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    email = prefs.getString(UserPreference.EMAIL);
    try {
      educatorAllowedDomain =
          prefs.getStringList(UserPreference.EDU_ALLOWED_DOMAIN);
      isUnderAge = prefs.getBool(UserPreference.IS_UNDER_AGE);
    } catch (e) {}
  }

  @override
  void initState() {
    getSharedPreferences();
  }

  String strFirstName = "", strEmail = "", strLastName = "";

  //String gender;

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    _fieldFocusChange(
        BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
      currentFocus.unfocus();
      FocusScope.of(context).requestFocus(nextFocus);
    }

    final userFirstNameUi = Padding(
      padding: EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
      child: Theme(
          data: ThemeData(
              backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
          child: TextFormField(
            keyboardType: TextInputType.text,
            controller: firstNameController,
            textInputAction: TextInputAction.next,
            focusNode: firstNameFocus,
            onFieldSubmitted: (term) {
              _fieldFocusChange(context, firstNameFocus, lastNameFocus);
            },
            textCapitalization: TextCapitalization.sentences,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_FIRST_NAME_VAL
                : !ValidationWidget.isName(val.trim())
                    ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                    : null,
            onSaved: (val) => strFirstName = val.trim(),
            cursorColor: Constant.CURSOR_COLOR,
            style: TextStyle(
                color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              border: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              labelText: "First Name",
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    final lastNameUi = Padding(
      padding: EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
      child: Theme(
          data: ThemeData(
              backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
          child: TextFormField(
            keyboardType: TextInputType.text,
            maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
            controller: lastNameController,
            textInputAction: TextInputAction.next,
            focusNode: lastNameFocus,
            onFieldSubmitted: (term) {
              _fieldFocusChange(context, lastNameFocus, emailFocus);
            },
            cursorColor: Constant.CURSOR_COLOR,
            textCapitalization: TextCapitalization.sentences,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_LAST_NAME_VAL
                : null,
            onSaved: (val) => strLastName = val.trim(),
            style: TextStyle(
                color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              border: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              labelText: "Last Name",
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );
    Text getTextLab(txt, size, color, fontWeight) {
      return Text(
        txt,
        textAlign: TextAlign.start,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final emailUi = Padding(
      padding:
          EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 35.0),
      child: Theme(
          data: ThemeData(
              backgroundColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor: ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor: ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor: ColorValues.LIGHT_GREY_TEXT_COLOR),
          child: TextFormField(
            controller: emailController,
            textInputAction: TextInputAction.done,
            focusNode: emailFocus,
            onFieldSubmitted: (term) {},
            keyboardType: TextInputType.emailAddress,
            cursorColor: Constant.CURSOR_COLOR,
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_EMAIL_VAL
                : !ValidationWidget.isEmail(val)
                    ? MessageConstant.VALID_EMAIL_VAL
                    : null,
            onSaved: (val) => strEmail = val,
            enabled: true,
            style: TextStyle(
                color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              border: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
              labelText: "Email",
              errorStyle: Util.errorTextStyle,
              counterText: "",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final loginButton = Container(
        child: Padding(
            padding: EdgeInsets.only(
                left: 13.0, top: 0.0, right: 13.0, bottom: 10.0),
            child: Container(
                height: 44.0,
                width: double.infinity,
                child: FlatButton(
                  onPressed: () {
                    FocusScope.of(context).unfocus();
                    final form = formKey.currentState;
                    form.save();
                    _checkValidation();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(0)),
                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                  child: Row(
                    // Replace with a Row for horizontal icon + text
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('Continue',
                          style: TextStyle(
                              fontSize: 20.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: Colors.white)),
                    ],
                  ),
                ))));

    textFormFieldDecorationWithNoBorders(String name, {String helperText}) {
      return InputDecoration(
        contentPadding: const EdgeInsets.fromLTRB(
          0.0,
          5.0,
          5.0,
          5.0,
        ),
        labelText: name,
        errorStyle: TextStyle(
            fontFamily: AppTextStyle.getFont(FontType.Regular),
            color: Palette.redColor),
        helperText: helperText,
        helperStyle: AppTextStyle.getDynamicFontStyle(
            Palette.secondaryTextColor, 12, FontType.Regular),
        hintStyle: AppTextStyle.getDynamicFontStyle(
            ColorValues.hintColor, 14, FontType.Regular),
        labelStyle: TextStyle(
            color: ColorValues.GREY_TEXT_COLOR,
            fontFamily: Constant.TYPE_CUSTOMREGULAR),
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
        border: InputBorder.none,
      );
    }

    final bottomBarView = Container(
      // color:  ColorValues.HEADING_COLOR_EDUCATION,
      padding: EdgeInsets.only(left: 4.0, right: 4.0),
      height: 140.0 + MediaQuery.of(context).padding.bottom,
      child: Container(
          child: Column(
        children: <Widget>[
          Container(
              padding: EdgeInsets.fromLTRB(13.0, 0.0, 13.0, 60.0),
              child: Column(
                children: <Widget>[
                  loginButton,
                ],
              )),
        ],
      )),
    );

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, "pop");
        },
        child: GestureDetector(
            onTap: () {
              //  FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                backgroundColor: ColorValues.WHITE,
                body: Container(
                  child: Column(
                    children: <Widget>[
                      Expanded(
                        child: Container(
                            color: ColorValues.WHITE,
                            height: double.infinity,
                            child: Container(
                                color: ColorValues.WHITE,
                                child: Container(
                                  padding: EdgeInsets.all(0.0),
                                  child: Form(
                                      key: formKey,
                                      child: ListView(
                                        children: <Widget>[
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Expanded(
                                                child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    InkWell(
                                                      child: SizedBox(
                                                        height: 40.0,
                                                        width: 30.0,
                                                        child: PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            3.0,
                                                            Center(
                                                                child: Image.asset(
                                                                    "assets/newDesignIcon/navigation/back.png",
                                                                    height:
                                                                        20.0,
                                                                    width: 10.0,
                                                                    fit: BoxFit
                                                                        .fitHeight))),
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(
                                                            context, "pop");
                                                      },
                                                    ),
                                                  ],
                                                ),
                                                flex: 1,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      10.0, 20.0, 10.0, 0.0),
                                                  child: Image.asset(
                                                    "assets/family.png",
                                                    height: 50.0,
                                                    width: 50.0,
                                                  ),
                                                ),
                                                flex: 1,
                                              ),
                                              Expanded(
                                                child: Container(),
                                                flex: 1,
                                              ),
                                            ],
                                          ),
                                          Column(
                                            children: <Widget>[
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text("Add Parent Information",
                                                      style: new TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR,
                                                          fontSize: 22.0,
                                                          fontWeight:
                                                              FontWeight.w700)),
                                                  Padding(
                                                    padding: const EdgeInsets
                                                            .fromLTRB(
                                                        13, 3, 13, 15),
                                                    child: TextViewWrap
                                                        .textViewMultiLine(
                                                            "You are under 13 so we will need your legal guardian information to complete the account set up.",
                                                            TextAlign.center,
                                                            ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            12.0,
                                                            FontWeight.normal,
                                                            5),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              userFirstNameUi,
                                              lastNameUi,
                                              emailUi,
                                            ],
                                          ),
                                          loginButton
                                        ],
                                      )),
                                ))),
                        flex: 1,
                      )
                    ],
                  ),
                  color: ColorValues.LIGHT_GRAY_BG,
                ))));
  }
}
