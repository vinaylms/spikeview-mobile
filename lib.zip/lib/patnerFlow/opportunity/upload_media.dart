import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:video_compress/video_compress.dart';

import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart' as dir;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:flutter/material.dart';
import 'package:thumbnails/thumbnails.dart';

class UploadMedia with BaseCommonWidget {
  File image;
  File cameraImage;
  File video;
  File cameraVideo;
  File document;
  BuildContext context;

  bool isImage = true;
  bool isDoc = false;

  // final flutterVideoCompress = FlutterVideoCompress();

  String sasToken, sasContainer;
  Subscription _subscription;

  UploadMedia(BuildContext context) {
    this.context = context;
/*    _subscription =
        flutterVideoCompress.compressProgress$.subscribe((progress) {
      print('progress: $progress%');
    });*/
  }

  void dispose() {
    //  _subscription.unsubscribe();
  }

  // This funcion will helps you to pick and Image from Gallery
  Future<File> pickImageFromGallery() async {
     File image = await ImagePicker.pickImage(source: ImageSource.gallery);
     return image;


    print('media select+++2');
    FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
      allowedFileExtensions: ['jpg', 'png', 'jpeg'],
      allowedMimeTypes: ['image/*'],
      invalidFileNameSymbols: ['/'],
    );

    String path = await FlutterDocumentPicker.openDocument(params: params);
    isImage = true;
    isDoc = false;
    if (path != null && path != '') {
      this.image = File(path);
      return this.image;
    }


  }

  static Future<File> getThumbnailFromUrl(String url) async {
    File file;
    try {
      if (url.isNotEmpty && url != 'null') {
        String path = (await dir.getTemporaryDirectory()).path;
        final rawPath = await VideoThumbnail.thumbnailFile(
          video: url,
          thumbnailPath: path.replaceAll(" ", "%20"),
          imageFormat: ImageFormat.JPEG,
          quality: 30,
        );
        file = File(rawPath);
      }
      return file;
    } catch (e) {
      print(" ----- Exception thumb uint8list path+++ $e");
      return file;
    }
  }

  // This funcion will helps you to pick and Image from Camera
  Future<File> pickImageFromCamera() async {

    File image = await ImagePicker.pickImage(source: ImageSource.camera);
    isImage = true;
    isDoc = false;
    return cameraImage = image;
    // setState(() {});
    // updateUiAndCompressAndUploadMedia(_cameraImage, false);
  }

  // This funcion will helps you to pick a Video File
  Future<File> pickVideoFromGallery() async {
    print('Apurva inside pickVideoFromGallery()');
    File video = await ImagePicker.pickVideo(source: ImageSource.gallery);
    isImage = false;
    isDoc = false;
    return this.video = video;
    // setState(() {});

    // updateUiAndCompressAndUploadMedia(_video, true);
  }

  // This funcion will helps you to pick a Video File from Camera
  Future<File> pickVideoFromCamera() async {
    File video = await ImagePicker.pickVideo(source: ImageSource.camera);
    isImage = false;
    isDoc = false;
    return cameraVideo = video;
    // setState(() {});
    // updateUiAndCompressAndUploadMedia(_cameraVideo, true);
  }

  /*Future<File> pickDocument() async {
    File document = await FilePicker.getFile(
      type: FileType.any,
    );
    isImage = null;
    isDoc = true;
    return this.document = document;
  }*/

  Future<AssetModel> buildUploadMediaUrl(
      File file, userIdPref, token, type) async {
    AssetModel isUploaded = await API.uploadMedia(sasContainer,
        getFileName(file), sasToken, file, false, userIdPref, type);
    return isUploaded;
  }

  String getFileName(File file) {
    return path.basename(file.path);
  }

  Future<AssetModel> generateSasToken(
      File file, userIdPref, token, type) async {
    AssetModel model;
    if (sasToken != null &&
        sasToken.isNotEmpty &&
        sasContainer != null &&
        sasContainer.isNotEmpty) {
      print('token available');
      print('sas token -> $sasToken');
      print('sas container -> $sasContainer');
      model = await buildUploadMediaUrl(file, userIdPref, token, type);
      //Navigator.of(context).pop();
      // ToastWrap. showToast('Sucessfully uploaded...',context);
    } else {
      print('token null');
      Map<String, dynamic> result = await API.generateSasToken(token);
      print(result);
      sasToken = result['sasToken'];
      sasContainer = result['container'];
      print('sas token -> $sasToken');
      print('sas container -> $sasContainer');
      model = await buildUploadMediaUrl(file, userIdPref, token, type);
      //Navigator.of(context).pop();
    }
    return model;
  }

  Future<File> compresssData(File file, bool isCompress, type) async {
    // _loadingStreamCtrl.sink.add(true);
    File uploadingFile = file;
    //  showCircularProgressDialog(context);
    // showUi();

    if (isCompress) {
      String fileName = getFileName(uploadingFile);
      print('apurva inside compresssData() fileName:: $fileName');

      if (type == "video") {
        final MediaInfo info = await VideoCompress.compressVideo(file.path,
            quality: VideoQuality.MediumQuality,
            deleteOrigin: false,
            includeAudio: true);

        uploadingFile = File(info.path);
      } else if (type == "image") {
        uploadingFile = await compressImage(file);
      }
      print(
          'apurva inside compresssData() uploadingFile.path:: ${uploadingFile.path}');
      //print(uploadingFile.path);
    }
    return uploadingFile;
    // _loadingStreamCtrl.sink.add(false);
  }

  Future<AssetModel> updateUiAndCompressAndUploadMedia(
      File file, bool isCompress, userIdPref, token, type) async {
    // _loadingStreamCtrl.sink.add(true);
    print("userIDShubh++++" + userIdPref);
    File uploadingFile = file;
    //  showCircularProgressDialog(context);
    // showUi();
    if (isCompress) {
      String fileName = getFileName(uploadingFile);
      print(fileName);

      if (isImage != null && !isImage) {
        final MediaInfo info = await VideoCompress.compressVideo(
          file.path,
          quality: VideoQuality.MediumQuality,
          deleteOrigin: false,
        );

        debugPrint(info.toJson().toString());
        uploadingFile = File(info.path);
      } else if (isImage != null && isImage) {
        uploadingFile = await compressImage(file);
      }
      print(uploadingFile.path);
    }
    return await generateSasToken(uploadingFile, userIdPref, token, type);
    // _loadingStreamCtrl.sink.add(false);
  }

  // 2. compress file and get file.
  Future<File> compressImage(File file) async {
    String filename = getFileName(file);

    var tempDir = await dir.getTemporaryDirectory();

    var targetPath = tempDir.absolute.path + "/$filename";

    print("Target Path " + targetPath);

    print("File Path " + file.absolute.path);

    // Alok Changes 26-Feb
//    var result = await FlutterImageCompress.compressAndGetFile(
//      file.absolute.path,
//      targetPath,
//      quality: 88,
//    );

    var result = file;

    print(file.lengthSync());
    print(result.lengthSync());

    return result;
  }

  getVideoThumbnailFromFile(String url) async {
    try {
      String path = (await dir.getTemporaryDirectory()).path;
      print("path path+++" + path);
      print("path url+++" + url);

      final uint8list = await VideoThumbnail.thumbnailFile(
        video: url.replaceAll(" ", "%20"),
        thumbnailPath: path,
        imageFormat: ImageFormat.PNG,
        //maxHeightOrWidth: 64,// specify the height of the thumbnail, let the width auto-scaled to keep the source aspect ratio
        quality: 50,
      );

      /*final uint8list = await VideoThumbnail.thumbnailData(
        video: url,
        imageFormat: ImageFormat.PNG,
        maxHeight: 64, // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
        quality: 50,

      );*/

      /*String s =  String.fromCharCodes(uint8list);
      var outputAsUint8List =  Uint8List.fromList(s.codeUnits);
      print("thumb uint8list path outputAsUint8List+++"+outputAsUint8List.toString());*/

      print("thumb uint8list path+++" + uint8list.toString());

      return File(uint8list.toString());
    } catch (e) {
      print("Exception thumb uint8list path+++ $e");
      return File('');
    }
  }

  getVideoThumbnailFromUrl(String url) async {
    if (url.toString() != '' && url.toString() != 'null') {
      try {
        String path = (await dir.getTemporaryDirectory()).path;
        //String path=  (await dir.getExternalStorageDirectory()).path;
        print("path path+++" + path);
        print("path url+++" + url);
        //path url+++http://spikeviewmediastorage.blob.core.windows.net/spikeview-media-development/sv_82/media/image_eb8b9a98b6a74da7950a3eb6df276895/VID_2021-01-14 08-06-25.mp4
        final uint8list = await VideoThumbnail.thumbnailFile(
          //video: "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
          video: url,
          //"https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
          thumbnailPath: path.replaceAll(" ", "%20"),
          imageFormat: ImageFormat.PNG,
          //maxHeightOrWidth: 64,// specify the height of the thumbnail, let the width auto-scaled to keep the source aspect ratio
          quality: 30,
        );

        print("thumb uint8list path+++" + uint8list.toString());

        return File(uint8list.toString());
      } catch (e) {
        print("Exception thumb uint8list path+++ $e");
        return File('');
      }
    } else {
      return File('');
    }
  }

  Future<String> getVideoThumbnailFromUrlOld(String url) async {
    final uint8list = await VideoThumbnail.thumbnailFile(
      video: url != null
          ? url
          : "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
      thumbnailPath: (await dir.getTemporaryDirectory()).path,
      imageFormat: ImageFormat.JPEG,
      quality: 25,
    );
    return uint8list;
  }

// @override
// Widget build(BuildContext context) {
//   return SafeArea(
//     child: Scaffold(
//       appBar:  AppBar(
//         backgroundColor: Palette.webColor,
//         centerTitle: true,
//         title: Text(
//           'Media',
//           style: AppTextStyle.getDynamicFontStyle(
//               Palette.primaryTextColor, 18, FontType.Regular),
//         ),
//         leading: backIcon(context),
//       ),
//       body: Container(
//         color: Palette.webColor,
//         child: ListView(
//           children: <Widget>[
//             Column(
//               mainAxisSize: MainAxisSize.min,
//               children: <Widget>[
//                 FlatButton.icon(
//                   icon: Icon(Icons.image),
//                   label: Text('Upload image from gallery'),
//                   onPressed: _pickImageFromGallery,
//                 ),
//                 FlatButton.icon(
//                   icon: Icon(Icons.camera_alt),
//                   label: Text('Upload image from camera'),
//                   onPressed: _pickImageFromCamera,
//                 ),
//                 FlatButton.icon(
//                   icon: Icon(Icons.videocam),
//                   label: Text('Upload video from gallery'),
//                   onPressed: _pickVideo,
//                 ),
//                 FlatButton.icon(
//                   icon: Icon(Icons.camera_alt),
//                   label: Text('Upload video from camera'),
//                   onPressed: _pickVideoFromCamera,
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     ),
//   );
// }

// showUi() {
//   showDialog(
//     context: context,
//     builder: (context) {
//       // return StreamBuilder<bool>(
//       //   stream: _loadingStreamCtrl.stream,
//       //   builder: (context, AsyncSnapshot<bool> snapshot) {
//       //     if (snapshot.data == true) {
//       return GestureDetector(
//         onTap: () {
//           _flutterVideoCompress.cancelCompression();
//         },
//         child: Center(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             mainAxisSize: MainAxisSize.max,
//             children: [
//               CircularProgressIndicator(),
//               Padding(
//                 padding: const EdgeInsets.all(8),
//                 child: Text('[$_taskName] $_progressState %'),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(8),
//                 child: const Text('click cancel...'),
//               ),
//             ],
//           ),
//         ),
//       );
//       //     }
//       //     return Container();
//       //   },
//       // );
//     },
//   );
// }
}
