import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class CompanyProfileModel {
  String firstName,
      lastName,
      email,
      dob,
      mobileNo,
      companyId,
      userId,
      roleId,
      name,
      address,
      phone,
      url,
      about,
      profilePicture,zipCode,gender,
      coverPicture,city,state,country,countryCode,partnerStatus,declineReason;

  List<OfferModel> offers;
  List<Assest> assestList;
  List<Assest> assestVideoAndImage;
  List<Assest> videoList;
  List<Assest> docList;
  List<Assest> googleLinkList;
  List<Assest> mediaList;
  List<CategoryModel> categoryModel;

  bool isActive;

  CompanyProfileModel(
      this.firstName,
      this.lastName,
      this.mobileNo,
      this.companyId,
      this.userId,
      this.roleId,
      this.name,
      this.address,
      this.phone,
      this.url,
      this.about,
      this.profilePicture,
      this.coverPicture,
      this.offers,
      this.assestList,
      this.assestVideoAndImage,
      this.videoList,
      this.docList,
      this.mediaList,this.googleLinkList,
      this.email,
      this.dob,this.zipCode,this.gender,this.city,this.state,this.country,this.countryCode,this.categoryModel, this.isActive,this.partnerStatus,this.declineReason);


}
