
import 'package:spike_view_project/common/Util.dart';



import 'package:intl/intl.dart';

import 'package:spike_view_project/constant/Constant.dart';


class ChatModel {
  String status;
  List<ChatData> mChatDataList;
static  String previousDateStamp="";
  ChatModel({this.status, this.mChatDataList});

  ChatModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      mChatDataList =  List<ChatData>();

      json['result'].forEach((v) {

        mChatDataList.add(new ChatData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.mChatDataList != null) {
      data['result'] = this.mChatDataList.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ChatData {
  int messageId;
  int connectorId;
  int sender;
  int receiver;
  int deletedBy;
  int senderRoleId;
  int receiverRoleId;
  int time;
  String text;
  int type;
  int status;
  String opportunityId;
  String opportunityTitle;
  String opportunityImage;
  String opportunityDesc;
  String convertedDateString;

  ChatData(
      {this.messageId,
      this.connectorId,
      this.sender,
      this.receiver,
      this.deletedBy,
      this.senderRoleId,
      this.receiverRoleId,
      this.time,
      this.text,
      this.type,
      this.status,
      this.opportunityId,
      this.opportunityTitle,
      this.opportunityImage,
      this.opportunityDesc,this.convertedDateString});

  ChatData.fromJson(Map<String, dynamic> json) {
    try {
      messageId = json['messageId'];
      connectorId = json['connectorId'];
      sender = json['sender'];
      receiver = json['receiver'];
      deletedBy = json['deletedBy'];
      senderRoleId = json['senderRoleId'];
      receiverRoleId = json['receiverRoleId'];
      time = json['time'];
      text = json['text'];
      type = json['type'];
      status = json['status'];
      opportunityId = "";
      opportunityTitle = "";
      opportunityImage = "";
      opportunityDesc = "";

      if(time!=null&&time!="null"&&time!=""){
        int millis = int.tryParse(time.toString());
        var now =  DateTime.fromMillisecondsSinceEpoch(millis);
        var formatter =  DateFormat('MMM dd, yyyy');
        String formatted = formatter.format(now);



        if (formatted != ChatModel.previousDateStamp) {
          ChatModel. previousDateStamp = formatted;
          convertedDateString=ChatModel.previousDateStamp;
        } else {
          convertedDateString="";
        }
      }

      if (type == Constant.opportunityPredefinedType) {
        // For Opportunity
        List<String> extracted_URL_KeyValues = Util.fetchDataUsingURL(text);
        opportunityId = extracted_URL_KeyValues[0];
        opportunityTitle = extracted_URL_KeyValues[1];
        opportunityImage = extracted_URL_KeyValues[2];
        opportunityDesc = extracted_URL_KeyValues[3];
      }
    }catch(e){

    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['messageId'] = this.messageId;
    data['connectorId'] = this.connectorId;
    data['sender'] = this.sender;
    data['receiver'] = this.receiver;
    data['deletedBy'] = this.deletedBy;
    data['senderRoleId'] = this.senderRoleId;
    data['receiverRoleId'] = this.receiverRoleId;
    data['time'] = this.time;
    data['text'] = this.text;
    data['type'] = this.type;
    data['status'] = this.status;
    data['opportunityId'] = this.opportunityId;
    data['opportunityTitle'] = this.opportunityTitle;
    data['opportunityImage'] = this.opportunityImage;
    data['opportunityDesc'] = this.opportunityDesc;

    return data;
  }
}
