import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/video_player/video_play_view.dart';
import 'package:video_player/video_player.dart';

class CameraPage extends StatefulWidget {
  final String generateScriptResponse;
  final ProfileData studentProfile;

  CameraPage(this.generateScriptResponse,{this.studentProfile});

  @override
  _CameraPageState createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  var isButtonEnable = false;
  XFile filePath;
  bool _isLoading = true;
  bool _isRecording = false;
  bool _isVisibleStartButton = true;
  var cameraIcon = "assets/generateScript/start.png";
  CameraController _cameraController;
  VideoPlayerController _videoPlayerController;
  TextEditingController addSummary;
  Timer countdownTimer;
  Duration myDuration = const Duration(seconds: 0);
  SharedPreferences prefs;
  String userIdPref;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    if(widget.studentProfile != null){
      userIdPref = widget.studentProfile.userId;
    }else{
      userIdPref = prefs.getString(UserPreference.USER_ID);
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    _initCamera();
    addSummary = TextEditingController(
        text:
            "Hi there! My name is [student's name], and I'm excited to share a little bit about myself with you. My favorite sport is soccer, and I love playing it with my friends and family. But sports aren't the only thing I'm good at - I'm also proud to have won the regional spelling bee last year. It was an amazing accomplishment that showed me how hard work and dedication can pay off. When I grow up, I want to be an astronaut and explore the mysteries of space. I don't know yet what I want to study in college, but my favorite subjects right now are math and history. My favorite teacher would describe me as fun, curious, and energetic - always ready to learn something new and have a good time doing it. Thanks for listening!");
    setState(() {});
    super.initState();
  }

  Future _initVideoPlayer() async {
    _videoPlayerController = VideoPlayerController.file(File(filePath.path));
    await _videoPlayerController.initialize();
    await _videoPlayerController.setLooping(false);
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    countdownTimer?.cancel();
    _videoPlayerController?.dispose();
    super.dispose();
  }

  void startTimer() {
    countdownTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => setCountDown());
  }

  void stopTimer() {
    countdownTimer?.cancel();
  }

  void setCountDown() {
    const reduceSecondsBy = 1;
    setState(() {
      final seconds = myDuration.inSeconds + reduceSecondsBy;
      if (seconds < 0) {
        countdownTimer?.cancel();
      } else {
        myDuration = Duration(seconds: seconds);
      }
    });
  }

  _initCamera() async {
    final cameras = await availableCameras();
    final front = cameras.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.front);
    _cameraController = CameraController(front, ResolutionPreset.max);
    await _cameraController.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    });
    setState(() => _isLoading = false);
  }

  _recordVideo() async {
    if (_isRecording) {
      filePath = await _cameraController?.stopVideoRecording();
      print('File Path == ${filePath.path.toString()}');
      stopTimer();
      setState(() {
        _isRecording = false;
        _isVisibleStartButton = false;
        isButtonEnable = true;
      });

    } else {
      await _cameraController?.prepareForVideoRecording();
      await _cameraController?.startVideoRecording();
      setState(() => _isRecording = true);
      setState(() => cameraIcon = "assets/generateScript/stop.png");
      startTimer();
    }
  }

  Future<bool> _onWillPop() {
    Navigator.pop(context, 'pop');
  }

  @override
  Widget build(BuildContext context) {
    String strDigits(int n) => n.toString().padLeft(2, '0');
    final days = strDigits(myDuration.inDays);
    // Step 7
    final hours = strDigits(myDuration.inHours.remainder(24));
    final minutes = strDigits(myDuration.inMinutes.remainder(60));
    final seconds = strDigits(myDuration.inSeconds.remainder(60));
    // get screen size
    final size = MediaQuery.of(context).size;

    // calculate scale for aspect ratio widget
    var scale = _cameraController != null
        ? _cameraController.value.aspectRatio / size.aspectRatio
        : 0;

    // check if adjustments are needed...
    if (_cameraController != null &&
        _cameraController.value.aspectRatio < size.aspectRatio) {
      scale = 1 / scale;
    }

    if (_isLoading) {
      return Container(
        color: Colors.white,
        child: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    } else {
      return WillPopScope(
        onWillPop: _onWillPop,
        child: Scaffold(
         bottomNavigationBar: bottomSection(),
          backgroundColor: Colors.white,
          body: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image:
                    AssetImage("assets/new_onboarding/background_screen.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 54, 20, 18),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        child: SizedBox(
                          height: 32.0,
                          width: 32.0,
                          child: Center(
                              child: Image.asset(
                                  "assets/new_onboarding/back_blue_icon.png",
                                  height: 32.0,
                                  width: 32.0,
                                  fit: BoxFit.fitHeight)),
                        ),
                        onTap: () => Navigator.pop(context),
                      ),
                      const HelpButtonWidget(),
                    ],
                  ),
                ),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(35),
                      ),
                    ),
                    padding: EdgeInsets.fromLTRB(0, 25, 0, 20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: BaseText(
                            text: "Record introduction",
                            textColor: const Color(0xff27275A),
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                            fontFamily: Constant.latoRegular,
                          ),
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          height: 278,
                          child: _isVisibleStartButton
                              ? Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    Container(
                                      width:
                                          MediaQuery.of(context).size.width,
                                      height: 278,
                                      color: Colors.black,
                                      child: Center(
                                        child: AspectRatio(
                                            aspectRatio: _cameraController
                                                .value.aspectRatio,
                                            child: CameraPreview(
                                                _cameraController)),
                                      ),
                                    ),
                                    Positioned(
                                      left: 20.0,
                                      top: 12,
                                      child: _isRecording
                                      ?Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Image.asset(
                                            "assets/generateScript/red_circle.png",
                                            height: 12.0,
                                            width: 12.0,
                                          ),
                                          const SizedBox(width: 7),
                                          BaseText(
                                            text: '$minutes:$seconds',
                                            textColor: Colors.white,
                                            fontSize: 18,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: Constant.latoRegular,
                                          ),
                                        ],
                                      )
                                      :const SizedBox.shrink(),
                                    ),
                                    Positioned(
                                      left: 0,
                                      right: 0,
                                      bottom: 12,
                                      child: Center(
                                        child: InkWell(
                                          onTap: () {
                                            _recordVideo();
                                          },
                                          child: Image.asset(
                                            cameraIcon,
                                            height: 40.0,
                                            width: 40.0,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              : FutureBuilder(
                                  future: _initVideoPlayer(),
                                  builder: (context, state) {
                                    if (state.connectionState ==
                                        ConnectionState.waiting) {
                                      return const Center(
                                          child: CircularProgressIndicator());
                                    } else {
                                      /*return Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          Container(
                                            width: MediaQuery.of(context)
                                                .size
                                                .width,
                                            height: 278,
                                            child: VideoPlayPauseOffline(
                                              filePath.path,
                                              "",
                                              true,
                                              pageName: "profile",
                                            ),
                                          ),
                                        ],
                                      );*/
                                      return VideoPlayerView(videoPath: filePath.path, videoType: VideoType.file);
                                    }
                                  },
                                ),
                        ),
                        Expanded(
                          child: Scrollbar(
                            thickness: 4,
                            radius: Radius.circular(100), //corner radius of scrollbar
                            child: SingleChildScrollView(
                              padding: EdgeInsets.fromLTRB(20, 14, 20, 0),
                              child:  Text(
                                widget.generateScriptResponse,
                                style:  AppConstants.txtStyle.heading14400LatoRegularDarkBlue,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }

  copyButton() {
    return Container(
        height: 44.0,
        width: 111,
        child: FlatButton(
          onPressed: () async {
            ToastWrap.showToasSucess("Text Copied", context);
            await Clipboard.setData(
                ClipboardData(text: widget.generateScriptResponse));
          },
          shape: RoundedRectangleBorder(
              side: BorderSide(color: AppConstants.colorStyle.btnBg),
              borderRadius: BorderRadius.circular(10)),
          color: AppConstants.colorStyle.white,
          child: Row(
            // Replace with a Row for horizontal icon + text
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Copy",
                  style:
                      AppConstants.txtStyle.heading18600LatoRegularLightPurple),
            ],
          ),
        ));
  }

  addButton() {
    return Container(
        height: 44.0,
        child: FlatButton(
          onPressed: () {
            if (filePath != null) {
              apiCallingForVideo(File(filePath.path));
            }
          },
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          color: isButtonEnable
              ? AppConstants.colorStyle.lightBlue
              : AppConstants.colorStyle.lightBlueButtonDisableColor,
          child: Row(
            // Replace with a Row for horizontal icon + text
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text("Add",
                  style: AppConstants.txtStyle.heading18600LatoRegularWhite),
            ],
          ),
        ));
  }

  bottomSection() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Color.fromRGBO(204, 220, 247, 0.46),
            blurRadius: 13,
            spreadRadius: 10,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          copyButton(),
          const SizedBox(width: 12),
          Expanded(child: addButton()),
        ],
      ),
    );
  }

  Future apiCallingForVideo(File file) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        String fileName = file.path.split('/').last;
        String fileName2 = fileName.split('.').first;
        print("FileName+++++++" + fileName2);
        FormData formData;
        if (Platform.isIOS) {
          formData = FormData.from({
            "userId": userIdPref,
            "file": UploadFileInfo(file, fileName2 + ".mov"),
          });
        } else {
          formData = FormData.from({
            "userId": userIdPref,
            "file": UploadFileInfo(file, fileName2 + ".mp4"),
          });
        }

        Response response = await ApiCalling().apiCallForVideo(
            context, Constant.ENDPOINT_ADD_INTRODUCTIO_VIDEO, formData);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              bloc.fetcprofileData(userIdPref, context, prefs, true);
              ToastWrap.showToasSucess(msg, context);

              Timer(Duration(milliseconds: 1200), () async {
                Navigator.pop(context, status);
              });
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      ToastWrap.showToast(MessageConstant.SOMETHING_WENT_WRONG_ERROR, context);
    }
  }
}
