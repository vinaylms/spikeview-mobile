import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class GroupListForUserModel {

  String status;
  List<GroupForUser> groupList;

  GroupListForUserModel({this.status, this.groupList});

  GroupListForUserModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      groupList =  List<GroupForUser>();
      json['result'].forEach((v) {
        groupList.add(new GroupForUser.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.groupList != null) {
      data['result'] = this.groupList.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class GroupForUser {
  String sId;
  int groupId;
  String groupName;
  String type;
  int creationDate;
  int createdBy;
  int roleId;
  bool isActive;
  String groupImage;

  GroupForUser(
      {this.sId,
        this.groupId,
        this.groupName,
        this.type,
        this.creationDate,
        this.createdBy,
        this.roleId,
        this.isActive,
        this.groupImage});

  GroupForUser.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    groupId = json['groupId'];
    groupName = json['groupName'];
    type = json['type'];
    creationDate = json['creationDate'];
    createdBy = json['createdBy'];
    roleId = json['roleId'];
    isActive = json['isActive'];
    groupImage = json['groupImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['groupId'] = this.groupId;
    data['groupName'] = this.groupName;
    data['type'] = this.type;
    data['creationDate'] = this.creationDate;
    data['createdBy'] = this.createdBy;
    data['roleId'] = this.roleId;
    data['isActive'] = this.isActive;
    data['groupImage'] = this.groupImage;
    return data;
  }
}

