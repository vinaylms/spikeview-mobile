import 'package:spike_view_project/linkPreview/preview_link.dart';
import 'package:spike_view_project/linkPreview/whatsapp/view.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';

class WhatsAppLinkPreview extends PreviewLink {
  build(String url, UserPostModal userPostModal) {
    return this.render(url, (dynamic body) {

      userPostModal.webLinkModel.imageUrl =
          body == null ? "" : body['image_url'];
      userPostModal.webLinkModel.title = body == null ? "" : body['title'];
      userPostModal.webLinkModel.url = body == null ? "" : body['url'];
      userPostModal.webLinkModel.description =
          body == null ? "" : body['description'];
      return  WhatsAppView(

        feedId: userPostModal.feedId,
        imageUrl: body == null ? "" : body['image_url'],
        title: body == null ? "" : body['title'],
        url: body == null ? "" : body['url'],
        description: body == null ? "" : body['description'],
      );
    });
  }
}
