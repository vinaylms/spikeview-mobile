import 'dart:io';

import 'package:video_player/video_player.dart';

class VideoModel {
  VideoPlayerController controller;
  File VideoFile;

  VideoModel(this.controller, this.VideoFile);

}
