import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/accomplishment/portfolio/PortfolioViewWidget.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/experiences/portfolio_media.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/widgets/full_image_widget.dart';
import 'package:spike_view_project/widgets/util_widget.dart';
import 'package:url_launcher/url_launcher.dart';

class CustomPortFolioDetailsView extends StatefulWidget {
  final Achievement achieveItem;
  final String levelOneName;

  const CustomPortFolioDetailsView({
    @required this.achieveItem,
    @required this.levelOneName,
  });

  @override
  State<CustomPortFolioDetailsView> createState() => _CustomPortFolioDetailsViewState();
}

class _CustomPortFolioDetailsViewState extends State<CustomPortFolioDetailsView>
    with SingleTickerProviderStateMixin {
  AnimationController rotationController;
  ScrollController _scrollController = ScrollController();
  List<StatsAcc> statsList = [];

  @override
  void initState() {
    if(widget.achieveItem?.stats?.isNotEmpty ?? false){
      widget.achieveItem.stats.forEach((item) {
        if((item.label.toString() != 'null' && item.label.toString() != '')
            || (item.value.toString() != 'null' && item.value.toString() != '')
            || (item.playingPosition.toString() != 'null' && item.playingPosition.toString() != '')){
          statsList.add(item);
        }
      });
    }

    rotationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    if (widget.achieveItem?.isShowPersonalReflection ?? false) {
      rotationController.animateBack(0.0);
    } else {
      rotationController.forward(from: 0.0);
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned(
            left: 0,
            top: 0,
            right: 0,
            child: Container(
              height: 286,
              width: double.maxFinite,
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                colors: [
                  Color(0xff27275A),
                  Color(0x0DF48808),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              )),
            ),
          ),
          Column(
            children: [
              AppBar(
                automaticallyImplyLeading: false,
                titleSpacing: 0.0,
                elevation: 0.0,
                shadowColor: Colors.transparent,
                leading: Center(
                  child: InkWell(
                    onTap: () => _onBackPressed(),
                    child: Image.asset(
                      'assets/portfolio_details/ic_back.png',
                      height: 32,
                      width: 32,
                    ),
                  ),
                ),
                backgroundColor: Colors.transparent,
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: _scrollController,
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 30, 17, 54),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              clipBehavior: Clip.antiAlias,
                              child: CachedNetworkImage(
                                height: 100,
                                width: 100,
                                fit: BoxFit.cover,
                                imageUrl: Constant.IMAGE_PATH +
                                    widget.achieveItem.userImage,
                                placeholder: (_, str) {
                                  return Center(
                                    child: SizedBox(
                                      width: 30,
                                      height: 30,
                                      child: CircularProgressIndicator(
                                        valueColor: AlwaysStoppedAnimation(
                                          Colors.black54,
                                        ),
                                        strokeWidth: 2.0,
                                      ),
                                    ),
                                  );
                                },
                                errorWidget: (_, str, e) {
                                  return Center(
                                    child: Icon(
                                      Icons.person,
                                      color: Colors.white,
                                      size: 40,
                                    ),
                                  );
                                },
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  BaseText(
                                    text: widget.achieveItem?.title ?? 'N/A',
                                    textColor: Colors.white,
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 24,
                                    maxLines: 2,
                                    fontWeight: FontWeight.w700,
                                  ),
                                  const SizedBox(height: 8),
                                  BaseText(
                                    text:
                                        "${widget.achieveItem?.city ?? ''}${widget.achieveItem?.state?.toString() != 'null' ? ",${widget.achieveItem?.state}" : ''}",
                                    textColor: const Color(0xff666B9A),
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 16,
                                    maxLines: 2,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Visibility(
                        visible: (widget.achieveItem?.personalStatement
                                    ?.isNotEmpty ??
                                false) &&
                            widget.achieveItem?.personalStatement?.toString() !=
                                'null',
                        child: _personalStatement(),
                      ),
                      Visibility(
                        visible: (widget.achieveItem?.height?.toString() !=
                                    'null' &&
                                widget.achieveItem?.height?.toString() !=
                                    '') ||
                            (widget.achieveItem?.age?.toString() != 'null' &&
                                widget.achieveItem?.age?.toString() != '') ||
                            (widget.achieveItem?.weight?.toString() !=
                                    'null' &&
                                widget.achieveItem?.weight?.toString() != ''),
                        child: _myDetailsView(),
                      ),
                      Visibility(
                        visible:
                        statsList.isNotEmpty ,
                        child: _playPositionView(),
                      ),
                      Visibility(
                        visible: widget
                                .achieveItem?.portFolioAssestList?.isNotEmpty ??
                            false,
                        child: _portfolioMedianView(),
                      ),
                      Visibility(
                        visible:
                        widget.achieveItem?.team?.any((element) => element.teams?.isNotEmpty ?? false) ?? false,
                        child: _teamView(),
                      ),
                      Visibility(
                        visible:
                            widget.achieveItem?.externalLinks?.isNotEmpty ??
                                false,
                        child: _externalLinkView(),
                      ),
                      Visibility(
                        visible: (widget.achieveItem?.personalReflection
                                    ?.isNotEmpty ??
                                false) &&
                            widget.achieveItem?.personalReflection
                                    ?.toString() !=
                                'null',
                        child: _personalReflectionView(),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _personalStatement() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 34),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          widget.levelOneName == "Arts"
              ? Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _label(label: 'BIO'),
                    const SizedBox(height: 16),
                    BaseText(
                      text: UtilWidget.stringCheck(
                          string: widget?.achieveItem?.description),
                      textColor: Colors.white,
                      fontFamily: Constant.latoRegular,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                    ),
                    const SizedBox(height: 35),
                  ],
                )
              : const SizedBox.shrink(),
          _label(
              label: widget.levelOneName == "Arts"
                  ? "ARTIST STATEMENT"
                  : 'PERSONAL STATEMENT'),
          const SizedBox(height: 16),
          BaseText(
            text: widget?.achieveItem?.personalStatement ?? '',
            textColor: Colors.white,
            fontFamily: Constant.latoRegular,
            fontSize: 16,
            fontWeight: FontWeight.w400,
          ),
        ],
      ),
    );
  }

  Widget _myDetailsView() {
    final validAge = widget.achieveItem?.age?.toString() != 'null' &&
        widget.achieveItem?.age?.toString() != '';
    final validHeight = widget.achieveItem?.height?.toString() != 'null' &&
        widget.achieveItem.height.toString() != "0\'0\"" &&
        widget.achieveItem?.height?.toString() != '';
    final validWeight =widget.achieveItem?.weight?.toString() != 'null' &&
        widget.achieveItem?.weight?.toString() != '';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(label: 'My Detail'),
          const SizedBox(height: 16),
          IntrinsicHeight(
            child: Row(
              children: [
                Visibility(
                  visible: validAge,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BaseText(
                        text: "Age :",
                        textColor: const Color(0xff666B9A),
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      const SizedBox(width: 6),
                      BaseText(
                        text: "${widget.achieveItem?.age ?? ''}",
                        textColor: Colors.white,
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: (validAge && validHeight) || validWeight,
                  child: VerticalDivider(
                    width: 26,
                    color: const Color(0xffF3F5FF),
                    thickness: 0.5,
                  ),),
                Visibility(
                  visible: validHeight,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BaseText(
                        text: "Height :",
                        textColor: const Color(0xff666B9A),
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      const SizedBox(width: 6),
                      BaseText(
                        text: "${widget.achieveItem?.height ?? ''}",
                        textColor: Colors.white,
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: (validAge || validHeight) && validWeight,
                  child: VerticalDivider(
                    width: 26,
                    color: const Color(0xffF3F5FF),
                    thickness: 0.5,
                  ),),
                Visibility(
                  visible: validWeight,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BaseText(
                        text: "Weight :",
                        textColor: const Color(0xff666B9A),
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      const SizedBox(width: 6),
                      BaseText(
                        text: "${widget.achieveItem?.weight ?? ''} pounds",
                        textColor: Colors.white,
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _playPositionView() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 35),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      decoration: BoxDecoration(
        color: const Color(0xff24272C),
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListView.separated(
        itemBuilder: (_, index) {
          final item = statsList[index];
            return Row(
              children: [
                Expanded(
                    flex: 1,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        BaseText(
                          text: "Playing Position",
                          textColor: const Color(0xff666B9A),
                          fontFamily: Constant.latoRegular,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                        BaseText(
                          text: UtilWidget.stringCheck(
                              string: item?.playingPosition),
                          textColor: Colors.white,
                          fontFamily: Constant.latoRegular,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ],
                    )),
                Expanded(
                    flex: 1,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        BaseText(
                          text: "Statistics",
                          textColor: const Color(0xff666B9A),
                          fontFamily: Constant.latoRegular,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                        BaseText(
                          text:
                          "${UtilWidget.stringCheck(string: item?.label)}: ${UtilWidget.stringCheck(string: item?.value)}",
                          textColor: Colors.white,
                          fontFamily: Constant.latoRegular,
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ],
                    )),
              ],
            );
        },
        separatorBuilder: (_, index) => Divider(
          color: const Color(0xff393C41),
          height: 30,
          thickness: 0.5,
        ),
        itemCount: statsList.length,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: EdgeInsets.zero,
      ),
    );
  }

  Widget _portfolioMedianView() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 0, 35),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(label: "Gallery"),
          const SizedBox(height: 16),
          ListView.separated(
            itemBuilder: (_, index) {
              return _portfolioMediaItem(index);
            },
            separatorBuilder: (_, index) => const SizedBox(height: 35),
            itemCount: widget.achieveItem?.portFolioAssestList?.length ?? 0,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Widget _portfolioMediaItem(int index) {
    final item = widget.achieveItem.portFolioAssestList[index];
    final double height = 212;
    final double width = item?.file?.length == 1 ? MediaQuery.of(context).size.width -32: MediaQuery.of(context).size.width * 0.6;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        mediaEncode(item.type) == PortFolioMediaType.image
            ? SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(
                    item.file.length,
                    (i) {
                      return InkWell(
                        onTap: () {
                          Navigator.of(context).push(
                            new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  FullImageWidget(
                                imagePath: item.file[i].filePath
                                        .contains(Constant.IMAGE_PATH)
                                    ? item.file[i].filePath
                                        .replaceAll(Constant.IMAGE_PATH, '')
                                    : item.file[i].filePath,
                                type: FullImageType.network,
                              ),
                            ),
                          );
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white24,
                          ),
                          margin: const EdgeInsets.only(right: 16),
                          clipBehavior: Clip.antiAlias,
                          child: CachedNetworkImage(
                            imageUrl:
                                Constant.IMAGE_PATH + item.file[i].filePath,
                            height: height,
                            width: width,
                            fit: BoxFit.cover,
                            placeholder: (_, str) {
                              return Center(
                                child: SizedBox(
                                  width: 30.0,
                                  height: 30.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(
                                      Colors.black54,
                                    ),
                                    strokeWidth: 2.0,
                                  ),
                                ),
                              );
                            },
                            errorWidget: (_, str, e) {
                              return Image.asset(
                                "assets/portfolio/media.png",
                                height: height,
                                width: width,
                                fit: BoxFit.fill,
                              );
                            },
                          ),
                        ),
                      );
                    },
                  ),
                ),
              )
            : mediaEncode(item.type) == PortFolioMediaType.video
                ? SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: List.generate(
                        item.file.length,
                        (i) {
                          return InkWell(
                            onTap: () => _videoPlayPopUp(item.file[i].filePath),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white24,
                              ),
                              margin: const EdgeInsets.only(right: 16),
                              clipBehavior: Clip.antiAlias,
                              height: height,
                              width: width,
                              child: Stack(
                                children: [
                                  FutureBuilder<File>(
                                    builder: (_, snap) {
                                      if (snap.connectionState ==
                                          ConnectionState.waiting) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30.0,
                                            height: 30.0,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                                  AlwaysStoppedAnimation(
                                                Colors.black54,
                                              ),
                                              strokeWidth: 2.0,
                                            ),
                                          ),
                                        );
                                      } else if (snap.connectionState ==
                                          ConnectionState.done) {
                                        if (snap.hasData) {
                                          return Image.file(
                                            snap.data,
                                            height: height,
                                            width: width,
                                            fit: BoxFit.cover,
                                          );
                                        } else {
                                          return Container(
                                            height: height,
                                            width: width,
                                            color: Colors.white38,
                                          );
                                        }
                                      } else {
                                        return Text(
                                            'State: ${snap.connectionState}');
                                      }
                                    },
                                    future: UploadMedia.getThumbnailFromUrl(
                                        Constant.IMAGE_PATH +
                                            item.file[i].filePath),
                                  ),
                                  Center(
                                    child: Image.asset(
                                      'assets/portfolio_details/ic_play.png',
                                      height: 40,
                                      width: 40,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  )
                : mediaEncode(item.type) == PortFolioMediaType.link
                    ? SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: List.generate(
                            item.file.length,
                            (i) {
                              return InkWell(
                                onTap: () {
                                  if (!(item.file[i].filePath
                                      .toLowerCase()
                                      .contains("http"))) {
                                    launch("http://" + item.file[i].filePath);
                                  } else {
                                    launch(item.file[i].filePath);
                                  }
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.white24,
                                  ),
                                  margin: const EdgeInsets.only(right: 16),
                                  clipBehavior: Clip.antiAlias,
                                  child: Image.asset(
                                    widget.levelOneName == "Sports"
                                        ? "assets/portfolio/sport_default.png"
                                        : "assets/portfolio/arts_default.png",
                                    height: height,
                                    width: width,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
        const SizedBox(height: 15),
        BaseText(
          text: item.label,
          textColor: Colors.white,
          fontFamily: Constant.latoRegular,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
        const SizedBox(height: 8),
        BaseText(
          text: item.description,
          textColor: Colors.white,
          fontFamily: Constant.latoRegular,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
        Visibility(
          visible: item.statistics.toString() != 'null' &&
              (item?.statistics?.toString()?.trim()?.isNotEmpty ?? false),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              BaseText(
                text: "Statistics: ${item.statistics}",
                textColor: const Color(0xff666B9A),
                fontFamily: Constant.latoRegular,
                fontStyle: FontStyle.italic,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _videoPlayPopUp(String filePath) {
    if (filePath?.isNotEmpty ?? false) {
      showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) {
          return Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              height: 220,
              child: Stack(
                overflow: Overflow.visible,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    height: 220,
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black,
                    ),
                    child: VideoPlayPauseNew(
                      filePath,
                      "",
                      false,
                      ScrollController(),
                    ),
                  ),
                  Positioned(
                    right: 0,
                    top: 0,
                    child: InkWell(
                      onTap: () => Navigator.pop(context),
                      child: Padding(
                        padding: const EdgeInsets.only(right: 5),
                        child: Image.asset(
                          "assets/profile/skills/red_close.png",
                          height: 40,
                          width: 40,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }
  }

  Widget _teamView() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(label: "Teams"),
          const SizedBox(height: 15),
          ListView.separated(
            itemBuilder: (_, index) => _teamItem(index),
            separatorBuilder: (_, index) => const SizedBox(height: 24),
            itemCount: widget.achieveItem?.team?.length ?? 0,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Widget _teamItem(int index) {
    final item = widget.achieveItem.team[index];
    return ListView.separated(
      itemBuilder: (_, innerIndex) {
        final team = item.teams[innerIndex];
        return Container(
          padding: const EdgeInsets.fromLTRB(14, 14, 0, 16),
          decoration: BoxDecoration(
            color: const Color(0xff24272C),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Stack(
            children: [
              Positioned(
                right: 61,
                top: 25,
                bottom: 18,
                child: Image.asset(
                    'assets/portfolio_details/team_item_bg.png',
                height: 157,
                  width: 166,
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              BaseText(
                                text: team.orgName,
                                textColor: const Color(0xffF48808),
                                fontFamily: Constant.latoRegular,
                                fontSize: 20,
                                maxLines: 2,
                                fontWeight: FontWeight.w700,
                              ),
                              const SizedBox(height: 8),
                              BaseText(
                                text: "${team.teamName}(${item.teamType})",
                                textColor: const Color(0xff666B9A),
                                fontFamily: Constant.latoRegular,
                                fontSize: 16,
                                maxLines: 2,
                                fontWeight: FontWeight.w600,
                              ),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset(
                                    'assets/portfolio_details/ic_location.png',
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Flexible(
                                    child: BaseText(
                                      text: "${team.city}, ${team.state}",
                                      textColor: Colors.white,
                                      fontFamily: Constant.latoRegular,
                                      fontSize: 14,
                                      maxLines: 1,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            BaseText(
                              text: team.jersey,
                              textColor: const Color(0xff666B9A),
                              fontFamily: Constant.latoRegular,
                              fontSize: 60,
                              fontWeight: FontWeight.w700,
                            ),
                            BaseText(
                              text: "JERSEY#",
                              textColor: const Color(0xff666B9A),
                              fontFamily: Constant.latoRegular,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  Divider(
                    height: 24,
                    thickness: 1,
                    color: const Color(0xff666B9A).withOpacity(0.2),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        RichText(
                          text: TextSpan(
                              text: team.coachName,
                              style: TextStyle(
                                color: const Color(0xff828282),
                                fontFamily: Constant.latoRegular,
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                              ),
                              children: [
                                TextSpan(
                                  text: " (Coach)",
                                  style: TextStyle(
                                    color: const Color(0xff666B9A),
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ]),
                        ),
                        const SizedBox(height: 6),
                        BaseText(
                          text: team.coachEmail,
                          textColor: const Color(0xff828282),
                          fontFamily: Constant.latoRegular,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                        const SizedBox(height: 6),
                        BaseText(
                          text: "+${team.coachCountryCode}-${team.coachPhoneNo}",
                          textColor: const Color(0xff828282),
                          fontFamily: Constant.latoRegular,
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
      separatorBuilder: (_, index) => const SizedBox(height: 24),
      itemCount: item?.teams?.length ?? 0,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
    );
  }

  Widget _externalLinkView() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 17),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(label: "external links & mentions"),
          ListView.separated(
            itemBuilder: (_, index) => _externalItem(index),
            separatorBuilder: (_, index) => const SizedBox(height: 35),
            itemCount: widget.achieveItem?.externalLinks?.length ?? 0,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: EdgeInsets.fromLTRB(0, 15, 0, 0),
          ),
        ],
      ),
    );
  }

  Widget _externalItem(int index) {
    final item = widget.achieveItem.externalLinks[index];
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () {
            if (!item.url.toLowerCase().contains("http")) {
              launch("http://" + item.url);
            } else {
              launch(item.url);
            }
          },
          child: BaseText(
            text: item.label,
            textColor: const Color(0xff4684EB),
            fontFamily: Constant.latoRegular,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 6),
        BaseText(
          text: item.description,
          textColor: Colors.white,
          fontFamily: Constant.latoRegular,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ],
    );
  }

  Widget _personalReflectionView() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          color: const Color(0xff24272C),
          height: 0,
          thickness: 1,
        ),
        const SizedBox(height: 18),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: () {
                  widget.achieveItem?.isShowPersonalReflection =
                      !(widget.achieveItem?.isShowPersonalReflection ?? false);
                  if (widget.achieveItem?.isShowPersonalReflection ?? false) {
                    rotationController.animateBack(0.0);
                  } else {
                    rotationController.forward(from: 0.0);
                  }
                  setState(() {});
                  Future.delayed(Duration(milliseconds: 600),(){
                    _scrollController.animateTo(
                        _scrollController.position.maxScrollExtent,
                        duration: Duration(milliseconds: 300),
                        curve: Curves.ease);
                  });
                },
                child: Row(
                  children: [
                    Expanded(child: _label(label: "Personal reflections")),
                    const SizedBox(width: 12),
                    RotationTransition(
                      turns: Tween(begin: 0.0, end: 0.5)
                          .animate(rotationController),
                      child: Image.asset(
                        'assets/portfolio_details/ic_arrow_up.png',
                        width: 15,
                        height: 15,
                      ),
                    ),
                  ],
                ),
              ),
              Visibility(
                visible: widget.achieveItem?.isShowPersonalReflection ?? false,
                child: Container(
                  margin: const EdgeInsets.only(top: 22),
                  decoration: BoxDecoration(
                    color: const Color(0xff24272C),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      BaseText(
                        text: UtilWidget.stringCheck(
                            string: widget.achieveItem?.personalReflection),
                        textColor: Colors.white,
                        fontFamily: Constant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      const SizedBox(height: 18),
                      Divider(
                        color: const Color(0x56EAE0F3),
                        height: 0,
                        thickness: 1,
                      ),
                      const SizedBox(height: 9),
                      BaseText(
                        text:
                            "Note: Personal Reflection is only for yourself, this is not sharable to anyone",
                        textColor: const Color(0xffF48808),
                        fontFamily: Constant.latoRegular,
                        fontSize: 12,
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w400,
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget _label({@required String label}) {
    return BaseText(
      text: label.toUpperCase(),
      textColor: const Color(0xffF48808),
      fontFamily: Constant.latoRegular,
      fontSize: 16,
      fontWeight: FontWeight.w800,
      letterSpacing: 2.4,
    );
  }

  void _onBackPressed() {
    Navigator.pop(context);
  }

  @override
  void dispose() {
    rotationController?.dispose();
    super.dispose();
  }
}
