/*
class ScheduleModelParam {

  String day;
  List<HourObj> hours;

  ScheduleModelParam({this.day, this.hours});
  
  static Map<String, dynamic> toMap(ScheduleModelParam categoryObject) {
    Map<String, dynamic> scheduleMap = Map();
    scheduleMap['day'] = categoryObject.day;
    scheduleMap['hours'] = categoryObject.hours;
    return scheduleMap;
  }

  static List<Map<String, dynamic>> mapList(List<ScheduleModelParam> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "day": category.day,
              "hours": category.hours,
            })
        .toList();
    return listOfCategory;
  }
}

class HourObj {
  int timeFrom;
  int timeTo;

  HourObj(this.timeFrom, this.timeTo);
  static Map<String, dynamic> toMap(HourObj categoryObject) {
    Map<String, dynamic> scheduleMap = Map();
    scheduleMap['timeFrom'] = categoryObject.timeFrom;
    scheduleMap['timeTo'] = categoryObject.timeTo;
    return scheduleMap;
  }

  static List<Map<String, dynamic>> mapList(List<HourObj> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
      "timeFrom": category.timeFrom,
      "timeTo": category.timeTo,
    })
        .toList();
    return listOfCategory;
  }

}
*/
class ScheduleModelParam {
  String day;
  List<HoursData> hours =  List();

  ScheduleModelParam({this.day, this.hours});

  Map<String, dynamic> toJson() => <String, dynamic>{
        "day": day,
        "hours": hours,
      };

  static List<Map<String, dynamic>> mapList(
      List<ScheduleModelParam> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "day": category.day,
              "hours": HoursData.mapList(category.hours),
            })
        .toList();
    return listOfCategory;
  }
}

class HoursData {
  int timeFrom ;
  int timeTo;

  HoursData({this.timeTo, this.timeFrom});

  Map<String, dynamic> toJson() => <String, dynamic>{
        'timeFrom': timeFrom,
        'timeto': timeTo,
      };

  static List<Map<String, dynamic>> mapList(List<HoursData> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "timeFrom": category.timeFrom,
              "timeTo": category.timeTo,
            })
        .toList();
    return listOfCategory;
  }
}
