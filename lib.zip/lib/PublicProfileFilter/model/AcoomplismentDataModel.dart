import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';

class AcoomplismentDataModel {
  String status;
  List<AccomplimentData> accomplimentData;
  int count = 0;
  bool hasIncompleteAchievement;
  AcoomplismentDataModel({this.status, this.accomplimentData});

  AcoomplismentDataModel.fromJson(Map<String, dynamic> json, pageName) {
    status = json['status'].toString();
    hasIncompleteAchievement = json['hasIncompleteAchievement'];
    if(hasIncompleteAchievement==null){
      hasIncompleteAchievement=false;
    }
    if (json['result'] != null) {
      accomplimentData =   List<AccomplimentData>();
      json['result'].forEach((v) {
        //  count=count+(new AccomplimentData.fromJson(v)).
        var data =   AccomplimentData.fromJson(v, pageName);
        count = count + data.achievement.length;
        accomplimentData.add(data);
      });
    }
  }

  List<int> toJsonLength() {
    List<int> dataList =   List();
    if (this.accomplimentData != null) {
      this.accomplimentData.map((v) {
        for (Achievement item in v.achievement) {

            dataList.add(item.achievementId);

        }
      }).toList();
    }

    return dataList;
  }
  List<int> accomplishmentLength() {
    List<int> dataList =   List();
    if (this.accomplimentData != null) {
      this.accomplimentData.map((v) {
        for (Achievement item in v.achievement) {
            dataList.add(item.achievementId);
        }
      }).toList();
    }

    return dataList;
  }

  List<int> toJson() {
    List<int> dataList =   List();
    if (this.accomplimentData != null) {
      this.accomplimentData.map((v) {
        for (Achievement item in v.achievement) {
          if (item.isProfileDisplay) {
            dataList.add(item.achievementId);
          }
        }
      }).toList();
    }

    return dataList;
  }

  List<int> toJsonA() {
    List<int> dataList =   List();
    try{
    if (this.accomplimentData != null) {
      this.accomplimentData.map((v) {
        for (Achievement item in v.achievement) {
          if (item.isProfileDisplay) {
            dataList.add(item.achievementId);
          }
        }
      }).toList();
    }}catch(e){
      print("error accom++++"+e.toString());
    }

    return dataList;
  }

  List<Map<String,dynamic>> toJsonSortOrder() {
    List<Map<String,dynamic>> dataList =   List();
    try{
    if (this.accomplimentData != null) {

      this.accomplimentData.map((v) {
        int index=1;
        for (Achievement item in v.achievement) {
          if (item.isProfileDisplay) {
            dataList.add(SortOrder(achievementId:item.achievementId,achievementSortOrder: index ).toJson());
          }
          index++;
        }


      }).toList();
    }}catch(e){
      print("error accom++++"+e.toString());
    }

    return dataList;
  }

  List<Map<String,dynamic>> toJsonCategoryOrder() {
    List<Map<String,dynamic>> dataList =   List();
    try{
    if (this.accomplimentData != null) {
      int index=1;
      this.accomplimentData.map((v) {
        int competencyId;
        String comepetencyName="";
        bool dataSelected= false;

        for (Achievement item in v.achievement) {
          if (item.isProfileDisplay) {
            try {
              competencyId = int.parse(item.competencyTypeId);
              comepetencyName=v.name;
            }catch(e){
              competencyId=1;
            }
            dataSelected=true;
          }
        }

        if(dataSelected){
          dataList.add(CategoryOrder(competencyTypeId:competencyId,competencySortOrder: index,name: comepetencyName ).toJson());
          index++;
        }

      }).toList();
    }}catch(e){
      print("error accom++++"+e.toString());
    }

    return dataList;
  }
}

class AccomplimentData {
  String iId;
  String name;
  String level1;
  List<Achievement> achievement;
  String orderBy;
  String sortDate;
  String status;
  bool isLevel2CompOther;

  AccomplimentData(
      {this.iId,
      this.name,
      this.level1,
      this.achievement,
      this.orderBy,
      this.sortDate,
      this.status});

  AccomplimentData.fromJson(Map<String, dynamic> json, pageName) {
    try {
      print("narattivejson+++"+json.toString());
      iId = json['_id'].toString();
      name = json['name'].toString();
      level1 = json['level1'].toString();
       isLevel2CompOther=false;
      try {
        isLevel2CompOther = json['isLevel2CompOther'];
        if (isLevel2CompOther == null) {
          isLevel2CompOther = false;
        }
      }catch(e){

      }

      if (json['achievement'] != null) {
        achievement =   List<Achievement>();
        json['achievement'].forEach((v) {
          if ("preso" == pageName) {
            if (v['type'].toString() != "portfolio")
              achievement.add(new Achievement.fromJson(v));
          } else {
            achievement.add(new Achievement.fromJson(v));
          }
        });
      }
      orderBy = json['orderBy'].toString();
      sortDate = json['sortDate'].toString();
      status = json['status'].toString();
    } catch (e) {
      print("AccomplimentData Error+++++++++" + e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.iId;
    data['name'] = this.name;
    data['level1'] = this.level1;

    if (this.achievement != null) {
      data['achievement'] = this.achievement.map((v) => v.toJson()).toList();
    }
    data['orderBy'] = this.orderBy;
    data['sortDate'] = this.sortDate;
    data['status'] = this.status;
    return data;
  }

  List<int> toJsonData() {
    List<int> dataList =   List();
    if (this.achievement != null) {
      this.achievement.map((v) {
        if (v.isProfileDisplay) {
          dataList.add(v.achievementId);
        }
      }).toList();
    }

    return dataList;
  }
}

class Achievement {
  String sId;
  String createdTimestamp;
  int achievementId;
  String competencyTypeId;
  String level2Competency;
  String level3Competency;
  String userId;
  String title;
  String description;
  String fromDate;
  String toDate;
  bool isActive;
  String importance;
  String hoursWorkedPerWeek;
  String parentId;
  List<String> stories;
  List<Skills> skills;
  List<Asset> asset;
  List<Asset> mediaList;
  List<Asset> mediaAndVideoList;
  List<Asset> all_badge_trophy_certificate;
  bool isProfileDisplay;
  String type;
  String importanceName;

  String personalStatement;
  String city;
  String state;
  String age;
  String userImage;
  String focusArea;
  String personalReflection;
  String level2Icon;
  List<StatsAcc> stats;
  List<TeamAcc> team;
  List<ExternalLinksAcc> externalLinks;

  static String callingType = "";
  bool isShowMore = false;
  bool isShowMorePersonalRef = false;
  bool isShowPersonalReflection = false;

  List<PortFolioAssest> portFolioAssestList;

  Guide guide;

  String weight;
  String height;
  List<FileDataModel> fileList =   List();
  RecommendationsData recommendations;
  bool showExternalLinkText = false;

  Achievement({
    this.sId,
    this.createdTimestamp,
    this.achievementId,
    this.competencyTypeId,
    this.level2Competency,
    this.level3Competency,
    this.userId,
    this.title,
    this.fromDate,
    this.toDate,
    this.isActive,
    this.importance,
    this.guide,
    this.hoursWorkedPerWeek,
    this.parentId,
    this.weight,
    this.height,
    this.isProfileDisplay,
    this.personalStatement,
    this.city,
    this.state,
    this.age,
    this.type,
    this.userImage,
    this.level2Icon,
    this.stats,
    this.team,
    this.externalLinks,
    this.stories,
    this.skills,
    this.asset,
    this.importanceName,
    this.recommendations,
    this.description,
    this.focusArea,
    this.personalReflection,
  });

  Achievement.fromJson(Map<String, dynamic> json) {
    stats =   List<StatsAcc>();
    team =   List<TeamAcc>();
    externalLinks =   List<ExternalLinksAcc>();
    skills =   List<Skills>();
    asset =   List<Asset>();
    all_badge_trophy_certificate =   List<Asset>();
    mediaList =   List<Asset>();
    mediaAndVideoList =   List<Asset>();
    portFolioAssestList =   List<PortFolioAssest>();
    isProfileDisplay = Achievement.callingType == "custom"
        ? true
        : json['isProfileDisplay'] == null ? true : json['isProfileDisplay'];
    sId = json['_id'].toString();
    createdTimestamp = json['createdTimestamp'].toString();
    achievementId = json['achievementId'];
    competencyTypeId = json['competencyTypeId'].toString();
    level2Competency = json['level2Competency'].toString();
    level3Competency = json['level3Competency'].toString();
    focusArea = json['focusArea'].toString();
    userId = json['userId'].toString();
    title = json['title'].toString();
    fromDate = json['fromDate'].toString();
    toDate = json['toDate'].toString();
    isActive = json['isActive'];
    importance = json['importance'].toString();
    guide = json['guide'] != null ?   Guide.fromJson(json['guide']) : null;
    hoursWorkedPerWeek = json['hoursWorkedPerWeek'].toString();
    parentId = json['parentId'].toString();
    weight = json['weight'].toString();
    height = json['height'].toString();

    personalStatement = json['personalStatement'].toString();
    city = json['city'].toString();
    state = json['state'].toString();
    age = json['age'].toString();
    type = json['type'].toString();
    userImage = json['userImage'].toString();
    level2Icon = json['level2Icon'].toString();

    if (json['stats'] != null) {
      json['stats'].forEach((v) {
        stats.add(new StatsAcc.fromJson(v));
      });
    }
    if (json['team'] != null) {
      json['team'].forEach((v) {
        team.add(new TeamAcc.fromJson(v));
      });
    }
    if (json['external_links'] != null) {
      json['external_links'].forEach((v) {
        externalLinks.add(new ExternalLinksAcc.fromJson(v));
      });
    }
    stories = json['stories'].cast<String>();

    if (json['skills'] != null) {
      json['skills'].forEach((v) {
        skills.add(new Skills.fromJson(v));
      });
    }
    if (json['asset'] != null) {
      json['asset'].forEach((v) {
        if (json['type'].toString() == "portfolio") {
          String type = v['type'].toString();
          String tag = v['tag'].toString();
          // String file = v['file'].toString();
          String statistics = v['statistics'].toString();
          String description = v['description'].toString();
          String label = v['label'].toString();
          var fileData = v['file'];
          List<FileDataModel> fileDataList =   List();
          for (int n = 0; n < fileData.length; n++) {
            String type = fileData[n]['type'].toString();
            String filePath = fileData[n]['file'].toString();
            fileDataList.add(new FileDataModel(type: type, filePath: filePath));
            fileList.add(new FileDataModel(type: type, filePath: filePath));
          }
          portFolioAssestList.add(new PortFolioAssest(
              type, tag, fileDataList, statistics, description, label));
        } else {
          Asset value =   Asset.fromJson(v);

          if (value.tag == "certificates" ||
              value.tag == "badges" ||
              value.tag == "trophy") {
            all_badge_trophy_certificate.add(value);
          } else {
            mediaAndVideoList.add(value);
            mediaList.add(value);
          }

          asset.add(value);
        }
      });
    }
    importanceName = json['importanceName'].toString();
    recommendations = json['recommendations'] != null
        ?   RecommendationsData.fromJson(json['recommendations'])
        : null;
    description = json['description'].toString();
    personalReflection = json['personalReflection'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['createdTimestamp'] = this.createdTimestamp;
    data['achievementId'] = this.achievementId;
    data['competencyTypeId'] = this.competencyTypeId;
    data['level2Competency'] = this.level2Competency;
    data['level3Competency'] = this.level3Competency;
    data['userId'] = this.userId;
    data['title'] = this.title;
    data['fromDate'] = this.fromDate;
    data['toDate'] = this.toDate;
    data['isActive'] = this.isActive;
    data['importance'] = this.importance;
    if (this.guide != null) {
      data['guide'] = this.guide.toJson();
    }
    data['hoursWorkedPerWeek'] = this.hoursWorkedPerWeek;
    data['parentId'] = this.parentId;
    data['weight'] = this.weight;
    data['height'] = this.height;
    data['isProfileDisplay'] = this.isProfileDisplay;
    data['personalStatement'] = this.personalStatement;
    data['city'] = this.city;
    data['state'] = this.state;
    data['age'] = this.age;
    data['type'] = this.type;
    data['userImage'] = this.userImage;
    data['level2Icon'] = this.level2Icon;
    if (this.stats != null) {
      data['stats'] = this.stats.map((v) => v.toJson()).toList();
    }
    if (this.team != null) {
      data['team'] = this.team.map((v) => v.toJson()).toList();
    }
    if (this.externalLinks != null) {
      data['external_links'] =
          this.externalLinks.map((v) => v.toJson()).toList();
    }
    data['stories'] = this.stories;

    if (this.skills != null) {
      data['skills'] = this.skills.map((v) => v.toJson()).toList();
    }
    if (this.asset != null) {
      data['asset'] = this.asset.map((v) => v.toJson()).toList();
    }
    data['importanceName'] = this.importanceName;
    if (this.recommendations != null) {
      data['recommendations'] = this.recommendations.toJson();
    }
    data['description'] = this.description;

    return data;
  }
}

class StatsAcc {
  String value;
  String label;
  String playingPosition;

  StatsAcc({this.value, this.label, this.playingPosition});

  StatsAcc.fromJson(Map<String, dynamic> json) {
    value = json['value'].toString();
    label = json['label'].toString();
    playingPosition = json['playingPosition'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['value'] = this.value;
    data['label'] = this.label;
    data['playingPosition'] = this.playingPosition;
    return data;
  }
}

class RecommendationsData {
  String stage;
  String repliedDate;
  String recommendation;
  RecommenderData recommender;

  RecommendationsData(
      {this.stage, this.repliedDate, this.recommendation, this.recommender});

  RecommendationsData.fromJson(Map<String, dynamic> json) {
    stage = json['stage'].toString();
    repliedDate = json['repliedDate'].toString();
    recommendation = json['recommendation'].toString();
    recommender = json['recommender'] != null
        ?   RecommenderData.fromJson(json['recommender'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['stage'] = this.stage;
    data['repliedDate'] = this.repliedDate;
    data['recommendation'] = this.recommendation;
    if (this.recommender != null) {
      data['recommender'] = this.recommender.toJson();
    }
    return data;
  }
}

class RecommenderData {
  String firstName;
  String lastName;
  String email;
  String profilePicture;

  RecommenderData(
      {this.firstName, this.lastName, this.email, this.profilePicture});

  RecommenderData.fromJson(Map<String, dynamic> json) {
    firstName = json['firstName'].toString();
    lastName = json['lastName'].toString();
    email = json['email'].toString();
    profilePicture = json['profilePicture'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['email'] = this.email;
    data['profilePicture'] = this.profilePicture;
    return data;
  }
}

class TeamAcc {
  List<Teams> teams;
  String teamType;

  TeamAcc({this.teams, this.teamType});

  TeamAcc.fromJson(Map<String, dynamic> json) {
    teams =   List<Teams>();
    if (json['teams'] != null) {
      json['teams'].forEach((v) {
        teams.add(new Teams.fromJson(v));
      });
    }
    teamType = json['teamType'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    if (this.teams != null) {
      data['teams'] = this.teams.map((v) => v.toJson()).toList();
    }
    data['teamType'] = this.teamType;
    return data;
  }
}
class SortOrder {
int achievementId,achievementSortOrder;


  SortOrder({this.achievementId, this.achievementSortOrder});


Map<String, dynamic> toJson() {
  final Map<String, dynamic> data =   Map<String, dynamic>();
  data['achievementId'] = this.achievementId;
  data['achievementSortOrder'] = this.achievementSortOrder;

  return data;
}

}

class CategoryOrder {
  int competencyTypeId,competencySortOrder;
String name;

  CategoryOrder({this.competencyTypeId, this.competencySortOrder,this.name});


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['competencyTypeId'] = this.competencyTypeId;
    data['competencySortOrder'] = this.competencySortOrder;
    data['name'] = this.name;

    return data;
  }

}

class Teams {
  String coachCountryCode;
  String coachPhoneNo;
  String coachEmail;
  String coachName;
  String jersey;
  String state;
  String city;
  String teamName;
  String orgName;

  Teams(
      {this.coachCountryCode,
      this.coachPhoneNo,
      this.coachEmail,
      this.coachName,
      this.jersey,
      this.state,
      this.city,
      this.teamName,
      this.orgName});

  Teams.fromJson(Map<String, dynamic> json) {
    coachCountryCode = json['coachCountryCode'].toString();
    coachPhoneNo = json['coachPhoneNo'].toString();
    coachEmail = json['coachEmail'].toString();
    coachName = json['coachName'].toString();
    jersey = json['jersey'].toString();
    state = json['state'].toString();
    city = json['city'].toString();
    teamName = json['teamName'].toString();
    orgName = json['orgName'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['coachCountryCode'] = this.coachCountryCode;
    data['coachPhoneNo'] = this.coachPhoneNo;
    data['coachEmail'] = this.coachEmail;
    data['coachName'] = this.coachName;
    data['jersey'] = this.jersey;
    data['state'] = this.state;
    data['city'] = this.city;
    data['teamName'] = this.teamName;
    data['orgName'] = this.orgName;
    return data;
  }
}

class ExternalLinksAcc {
  String description;
  String url;
  String label;

  ExternalLinksAcc({this.description, this.url, this.label});

  ExternalLinksAcc.fromJson(Map<String, dynamic> json) {
    description = json['description'].toString();
    url = json['url'].toString();
    label = json['label'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['description'] = this.description;
    data['url'] = this.url;
    data['label'] = this.label;
    return data;
  }
}

class Guide {
  String request;
  String recommenderTitle;
  String title;
  String email;
  String lastName;
  String firstName;
  bool promptRecommendation;

  Guide(
      {this.request,
      this.recommenderTitle,
      this.title,
      this.email,
      this.lastName,
      this.firstName,
      this.promptRecommendation});

  Guide.fromJson(Map<String, dynamic> json) {
    request = json['request'].toString();
    recommenderTitle = json['recommenderTitle'].toString();
    title = json['title'].toString();
    email = json['email'].toString();
    lastName = json['lastName'].toString();
    firstName = json['firstName'].toString();
    try {
      promptRecommendation = json['promptRecommendation'];
    } catch (e) {
      promptRecommendation = false;
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['request'] = this.request;
    data['recommenderTitle'] = this.recommenderTitle;
    data['title'] = this.title;
    data['email'] = this.email;
    data['lastName'] = this.lastName;
    data['firstName'] = this.firstName;
    data['promptRecommendation'] = this.promptRecommendation;
    return data;
  }
}

class Skills {
  String skillId;
  String label;

  Skills({this.skillId, this.label});

  Skills.fromJson(Map<String, dynamic> json) {
    skillId = json['skillId'].toString();
    label = json['label'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['skillId'] = this.skillId;
    data['label'] = this.label;
    return data;
  }
}

class Asset {
  String file;
  String tag;
  String type;

  Asset({this.file, this.tag, this.type});

  Asset.fromJson(Map<String, dynamic> json) {
    file = json['file'].toString();
    tag = json['tag'].toString();
    type = json['type'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['file'] = this.file;
    data['tag'] = this.tag;
    data['type'] = this.type;
    return data;
  }
}
