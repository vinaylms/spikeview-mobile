import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/patner/CompanyModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';
import 'package:spike_view_project/modal/patner/opportunity_category_model.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestFromParent.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestRepliedParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class ManageOfferingWidget extends StatefulWidget {
  @override
  ManageOfferingWidgetState createState() {
    return  ManageOfferingWidgetState();
  }
}

class ManageOfferingWidgetState extends State<ManageOfferingWidget> {
  CompanyModel companyModel;
  List<OfferModelForLocal> offersList =  List();
  List<OfferModelForLocal> selectedList =  List();
  SharedPreferences prefs;
  String userIdPref, roleId;
  static StreamController syncDoneController = StreamController.broadcast();

  List<OpportunityCategoriesResult> opportunityCategoryList = [];

  //--------------------------company Info api ------------------

  Future companyInfoApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await  ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny Apurva" + response.toString());
      print("response comapny userIdPref" + userIdPref + " &roleId " + roleId);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            companyModel = ParseJson.parseCompanyInfo(response.data['result']);
            if (companyModel != null) {
              prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                  companyModel.profilePicture);
              prefs.setString(
                  UserPreference.COMPANY_NAME_PATH, companyModel.name);

              print('Apurva companyModel.offers.length:: ${companyModel.offers.length}');
              print('Apurva offersList.length:: ${offersList.length}');

              /*for (int i = 0; i < companyModel.offers.length; i++) {

              for (int j = 0; j < offersList.length; j++) {
                if (companyModel.offers[i].offerId == offersList[j].offerId) {
                  offersList[i].isSelected = true;
                  break;
                }
              }
              }*/
              int count=0;
              for(var company in companyModel.offers){
                for(var offer in offersList){
                  if(company.offerId == offer.offerId){
                    offer.isSelected = true;
                    count++;
                    break;
                  }
                }
              }

              print('Apurva selected count:: $count');
              setState(() {
                offersList;
              });
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    await callApiOpporunityCategory();
    await companyInfoApi(true);
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.pop(context);
      syncDoneController.add("sucess");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future updateOfferingApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "offer": OfferModelForLocal.mapList(selectedList),
          "companyId": companyModel.companyId
        };

        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_COMPANY_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context);
              syncDoneController.add("sucess");
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    /*offersList.add(new OfferModelForLocal(
        offerId: 1,
        name: "Internship / Job / Volunteering Opportunities",
        isSelected: false));
    offersList.add(new OfferModelForLocal(
        offerId: 2, name: "Advertise Service / Programs", isSelected: false));*/
    /*  offersList.add(new OfferModelForLocal(
        offerId: 3, name: "College Admissions Counselling", isSelected: false));*/

    getSharedPreferences();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    checkBoxLabelText(String label) {
      return Expanded(
        child: Padding(
          padding: const EdgeInsets.only(bottom:2.0),
          child: BaseText(
            text:  label,
            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
            fontFamily:
            AppConstants.stringConstant.latoMedium,
            fontWeight: FontWeight.w500,
            fontSize: 16,
            textAlign: TextAlign.start,
            maxLines: 1,
          ),
        )


      );
    }

    customCheckBox(bool isChecked, index) {
      return
        InkWell(
          child: Image.asset(
            isChecked ? 'assets/experience/ic_checked.png' : 'assets/experience/ic_unchecked.png',
            height: 20,
            width: 20,

          ),
          onTap: () {
            if (offersList[index].isSelected)
              offersList[index].isSelected = false;
            else
              offersList[index].isSelected = true;

            setState(() {
              offersList;
            });
          },
        );

    }

    Widget getListItem(index) {
      return Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left:20.0,right: 20,top: 20),
            child: Row(
              children: <Widget>[
                customCheckBox(offersList[index].isSelected,index),
                UIHelper.horizontalGapBetweenBox,
                checkBoxLabelText(offersList[index].name),
              ],
            ),
          ),
        ],
      );
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);

        },
        child: GestureDetector(
            onTap: () {
            },
            child: customAppbar(
                context,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text:  "Manage Offerings",
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                              AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
SizedBox(height: 12,),
                            BaseText(
                              text:  "Select all offerings you intend offer",
                              textColor: ColorValues.labelColor,
                              fontFamily: Constant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
                            SizedBox(height: 7,),
                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[

                          Column(
                            children: List.generate(offersList.length, (int index) {
                              return  InkWell(
                                child: getListItem(index),
                                onTap: () {
                                  // if (offersList[index].isSelected)
                                  //   offersList[index].isSelected = false;
                                  // else
                                  //   offersList[index].isSelected = true;
                                  //
                                  // setState(() {
                                  //   offersList;
                                  // });
                                },
                              );
                            }),
                          ),
                        ],
                      ),
                      flex: 1,
                    )
                  ],
                ), () {

                Navigator.pop(context);

            },
                isShowIcon: false,
                bottomNavigation: Stack(
                  children: [
                    PaddingWrap.paddingfromLTRB(
                      20.0,
                      20.0,
                      20.0,
                      20.0,
                      InkWell(
                        child: Container(
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppConstants.colorStyle.lightBlue,
                              border: Border.all(
                                  color: AppConstants.colorStyle.lightBlue),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Align(
                                alignment: Alignment.center,
                                // Align however you like (i.e .centerRight, centerLeft)
                                child: Text(
                                  "Save",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: ColorValues.WHITE,
                                    fontFamily: Constant.latoMedium,
                                    fontSize: 18.0,
                                  ),
                                ))),
                        onTap: () {
                          selectedList.clear();
                          for (OfferModelForLocal model in offersList) {
                            if (model.isSelected) {
                              selectedList.add(model);
                            }
                          }
                          print('Apurva selectedList size:: ${selectedList.length}');
                          if (selectedList.length > 0)
                            updateOfferingApi();
                          else
                            ToastWrap.showToast(
                                MessageConstant.MIN_1_OFFERING_SELECTED_VAL, context);
                        },
                      ),
                    ),
                  ],
                ))));



    //-------------------------------------Main Ui ------------------------------------------
    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.singin_bg_color,
            appBar:  AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Expanded(
                    child:  InkWell(
                      child: CustomViews.getBackButton(),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child:  Text(
                      "Manage Offerings",
                      textAlign: TextAlign.center,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                 InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      5.0,
                      4.0,
                      15.0,
                      0.0,
                       Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           Text(
                            "Save ",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                          )
                        ],
                      )),
                  onTap: () {
                    selectedList.clear();
                    for (OfferModelForLocal model in offersList) {
                      if (model.isSelected) {
                        selectedList.add(model);
                      }
                    }
                    print('Apurva selectedList size:: ${selectedList.length}');
                    if (selectedList.length > 0)
                      updateOfferingApi();
                    else
                      ToastWrap.showToast(
                          MessageConstant.MIN_1_OFFERING_SELECTED_VAL, context);
                  },
                )
              ],
              backgroundColor: Colors.white,
            ),
            body:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding:
                        const EdgeInsets.fromLTRB(13.0, 20.0, 13.0, 20.0),
                        child: TextViewWrap.textViewMultiLine(
                            "Select all offerings you intend offer",
                            TextAlign.start,
                             ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            2),
                      ),
                      Column(
                        children: List.generate(offersList.length, (int index) {
                          return  InkWell(
                            child: getListItem(index),
                            onTap: () {
                              if (offersList[index].isSelected)
                                offersList[index].isSelected = false;
                              else
                                offersList[index].isSelected = true;

                              setState(() {
                                offersList;
                              });
                            },
                          );
                        }),
                      ),
                    ],
                  ),
                  flex: 1,
                )
              ],
            )));
  }

  Future callApiOpporunityCategory() async {
    print('inside callApiOpporunityCategory() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCallWithAuthToken(
            context,
            Constant.ENDPOINT_OPPORTUNITY_CATEGORY,
            "get"
        );

        print('Apurva callApiOpporunityCategory() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              OpportunityCategoriesModel apiResponse =  OpportunityCategoriesModel.fromJson(response.data);
              opportunityCategoryList = apiResponse.result;
              for(int i=0; i< opportunityCategoryList.length; i++){
                offersList.add(new OfferModelForLocal(
                    offerId: opportunityCategoryList[i].oppCategoryId,
                    name: opportunityCategoryList[i].name,
                    isSelected: false));
              }
              setState(() {
                offersList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }
}
