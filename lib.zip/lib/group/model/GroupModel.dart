import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';


class GroupListModel{
  List<GroupModel> groupList;
  List<GroupModel> groupRequestList;
  List<GroupModel> groupInvitationList;
  List<InvitationModel> childInvitationList;


  GroupListModel(this.groupList, this.groupRequestList,
      this.groupInvitationList,this.childInvitationList);

}

class InvitationModel{
  String studentUserId,studentName;
  List<GroupModel> invitationList;
  String badge;
  String badgeImage;
  int gamificationPoints;

  InvitationModel(this.studentUserId, this.studentName, this.invitationList,this.badge,this.gamificationPoints,this.badgeImage);

}

class GroupModel {
String groupId,groupName,roleId,type,creationDate,createdBy,isActive ,
    aboutGroup,otherInfo,groupImage,status,studentName,studentUserId;
bool isAdmin=false;
bool isSelected=false;
String acceptCount;
List<MemberModel> memberList;
String badge;
String badgeImage;
int gamificationPoints;

GroupModel(this.groupId, this.groupName, this.type, this.creationDate,
    this.createdBy, this.isActive, this.aboutGroup, this.otherInfo,
    this.groupImage,this.memberList,this.isAdmin,this.isSelected,this.status,
    this.acceptCount,this.studentName,this.studentUserId,this.badge,this.gamificationPoints,this.badgeImage,this.roleId);


GroupModel.fromJson(Map<String, dynamic> json) {
  groupId = json['groupId'].toString();
  groupName = json['groupName'].toString();
  if (json['members'] != null) {
    memberList =  List<MemberModel>();
    json['members'].forEach((v) {
      memberList.add(new MemberModel.fromJson(v));
    });
  }
  type = json['type'].toString();
  creationDate = json['creationDate'].toString();
  createdBy = json['createdBy'].toString();
  isActive = json['isActive'].toString();
  aboutGroup = json['aboutGroup'].toString();
  otherInfo = json['otherInfo'].toString();
  groupImage = json['groupImage'].toString();
  roleId = json['roleId'].toString();

}

}

class MemberModel {
  String status,isAdmin,userId;

  MemberModel(this.status, this.isAdmin, this.userId);

  MemberModel.fromJson(Map<String, dynamic> json) {

    status = json['status'].toString();
    isAdmin = json['isAdmin'].toString();
    userId = json['userId'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();

    data['status'] = this.status;
    data['isAdmin'] = this.isAdmin;
    data['userId'] = this.userId;
    return data;
  }
}
