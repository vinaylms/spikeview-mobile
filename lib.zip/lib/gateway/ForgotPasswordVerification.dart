import 'dart:async';
import 'package:flutter/gestures.dart';
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

import 'CreatePassword.dart';

class ForgotPasswordVerification extends StatefulWidget {
  static String tag = 'login-page';
  String email;

  ForgotPasswordVerification(this.email);

  @override
  ForgotPasswordVerificationState createState() =>
      ForgotPasswordVerificationState();
}

final formKey = GlobalKey<FormState>();

class ForgotPasswordVerificationState
    extends State<ForgotPasswordVerification> {
  Color borderColor = Colors.amber;
  SharedPreferences prefs;

  TextEditingController textController = TextEditingController();

  void _checkValidation() {
    final form = formKey.currentState;
    form.save();
    if (form.validate()) {
      forgotpassworApiCalling();
    }
    setState(() {});
  }

  @override
  void initState() {
    _timerStart();
    super.initState();
  }

  int _second = 120;
  Timer _timer;

  void _timerStart() {
    if (_timer?.isActive ?? false) {
      _timer?.cancel();
    }
    _second = 120;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_second > 0) {
        _second--;
        setState(() {});
      } else {
        _timer?.cancel();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _printDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "$twoDigitMinutes:$twoDigitSeconds minutes";
  }

  showSucessMsg(msg, context, push) {
    Timer _timer = Timer(const Duration(milliseconds: 1000), () async {
      Navigator.pop(context);
      if (push) {
        Navigator.of(context).push(
          new MaterialPageRoute(
            builder: (BuildContext context) =>
                ForgotPasswordVerification(widget.email),
          ),
        );
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: Scaffold(
              backgroundColor: Colors.transparent,
              body: Stack(
                children: <Widget>[
                  Positioned(
                      right: 0.0,
                      top: 55.0,
                      left: 0.0,
                      child: Container(
                        height: 65.0,
                        padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                        color: Color(0xffF1EDC3),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: msg,
                                  style: TextStyle(
                                      color: Color(0xff408738),
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.normal,
                                      fontFamily: Constant.customRegular),
                                ),
                              )
                            ]),
                      )),
                ],
              ),
            )));
  }

  forgotpassworApiCalling() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data
        var map = {
          "email": widget.email,
          "verificationType": "forgotPassOTP",
          "otp": _code
        };
        print('map+++$map');
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_OTP_VERIFICATION,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() {});
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            var value = await Navigator.of(context).push(
              new MaterialPageRoute(
                builder: (BuildContext context) => CreatePassword(widget.email),
              ),
            );
            Navigator.pop(context, value);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          setState(() {});
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() {});
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  resendOtpApi() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data

        var map = {"email": widget.email, "type": "forgotPassOTP","actionType": "resend"};
        print('map+++$map');
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_OTP_RESEND,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() {});
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            showSucessMsg(message, context, false);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          setState(() {});
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() {});
      // CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  String _code = '';

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
      },
      child: customAppbar(
        context,
        SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Container(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                left: 0, //11.0,
                right: 0, // 11.0,
              ),
              child: Container(
                //color: Colors.black.withOpacity(0.8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 0.0, top: 24.0, bottom: 50),
                        child: RichText(
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            text: 'Email',
                            style: AppConstants
                                .txtStyle.heading400LatoRegularDarkBlue
                                .copyWith(
                                    fontSize: 28, fontWeight: FontWeight.w700),
                            children: [
                              TextSpan(
                                  text: ' verification',
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () {},
                                  style: AppConstants
                                      .txtStyle.heading40018LatoRegularDarkBlue
                                      .copyWith(
                                          fontSize: 28,
                                          fontWeight: FontWeight.w700)),
                            ],
                          ),
                        )),
                    Center(
                      child: SizedBox(
                        width: 230,
                        child: PinCodeTextField(
                          length: 4,
                          keyboardType: TextInputType.number,
                          obscureText: true,
                          animationType: AnimationType.fade,
                          pinTheme: PinTheme(
                              shape: PinCodeFieldShape.underline,
                              activeColor: Color(0xffE5EBF0),
                              inactiveColor: Color(0xffE5EBF0),
                              disabledColor: Color(0xffE5EBF0),
                              activeFillColor: Color(0xffE5EBF0),
                              selectedFillColor: Color(0xffE5EBF0),
                              inactiveFillColor: Color(0xffE5EBF0),
                              fieldWidth: 49),
                          textStyle: TextStyle(
                              fontSize: 16.0,
                              color: AppConstants.colorStyle.darkBlue),
                          animationDuration: Duration(milliseconds: 300),
                          backgroundColor: Colors.transparent,
                          enableActiveFill: false,
                          controller: textController,
                          onCompleted: (v) {
                            setState(() {
                              _code = v;
                            });
                          },
                          onChanged: (value) {
                            setState(() {
                              _code = value;
                            });
                          },
                          beforeTextPaste: (text) {
                            print("Allowing to paste $text");
                            //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                            //but you can show anything you want here, like your pop up saying wrong paste format or etc
                            return true;
                          },
                          appContext: context,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(20.0, 10, 20.0, 0.0),
                      child: InkWell(
                        child: Center(
                          child: BaseText(
                            text:
                                'Please enter the verification code sent to the email you provided',
                            textColor: AppConstants.colorStyle.lightPurple,
                            textAlign: TextAlign.center,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),
                        ),
                        onTap: () {},
                      ),
                    ),
                    Container(
                      child: Padding(
                        padding:
                            EdgeInsets.only(left: 20.0, top: 61.0, right: 20.0),
                        child: Stack(
                          children: <Widget>[
                            Container(
                                height: 44.0,
                                width: double.infinity,
                                child: FlatButton(
                                  onPressed: () async {
                                    _checkValidation();
                                  },
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10)),
                                  color: AppConstants.colorStyle.lightBlue,
                                  child: Row(
                                    // Replace with a Row for horizontal icon + text
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text('Continue',
                                          style: AppConstants.txtStyle
                                              .heading18600LatoRegularWhite),
                                    ],
                                  ),
                                )),
                            _code.length == 4
                                ? SizedBox(
                                    height: 0,
                                  )
                                : Container(
                                    height: 44.0,
                                    width: double.infinity,
                                    color: Colors.white.withOpacity(0.5),
                                  )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        () {
          Navigator.pop(context);
        },
        bottomNavigation: Container(
          margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
          color: Colors.white,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Visibility(
                  visible: _second != 0,
                  child: BaseText(
                    text: _printDuration(Duration(seconds: _second)),
                    textAlign: TextAlign.center,
                    textColor: const Color(0xff27275A),
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                    fontFamily: Constant.latoRegular,
                  )),
              const SizedBox(height: 14),
              RichText(
                maxLines: 1,
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: "Didn’t receive verification code? ",
                  style: AppConstants.txtStyle.heading400LatoRegularDarkBlue,
                  children: [
                    TextSpan(
                      text: 'Resend',
                      recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          resendOtpApi();
                        },
                      style: AppConstants
                          .txtStyle.heading400LatoRegularLightBlue
                          .copyWith(
                              color: _second != 0
                                  ? const Color(0x304684EB)
                                  : AppConstants.colorStyle.lightBlue),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
