import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:spike_view_project/recommendation/EditRecommendationPerformance.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/recommendation/recommendationReply/ThankYouPage.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class HeroDialogRoute<T> extends PageRoute<T> {
  HeroDialogRoute({this.builder}) : super();

  final WidgetBuilder builder;

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => true;

  @override
  Duration get transitionDuration => const Duration(milliseconds: 300);

  @override
  bool get maintainState => true;

  @override
  Color get barrierColor => Colors.black54;

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    return FadeTransition(
        opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
        child: child);
  }

  @override
  Widget buildPage(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation) {
    return builder(context);
  }

  // TODO: implement barrierLabel
  @override
  String get barrierLabel => null;
}

// Create a Form Widget
class RecommendationReuestReplied extends StatefulWidget {
  Recomdation recomdation;

  RecommendationReuestReplied(this.recomdation);

  @override
  RecommendationReuestRepliedState createState() {
    return RecommendationReuestRepliedState(recomdation);
  }
}

class RecommendationReuestRepliedState
    extends State<RecommendationReuestReplied> {
  Recomdation recomdation;

  RecommendationReuestRepliedState(this.recomdation);

//  ProfileInfoModal profileInfoModal;
  bool isParent = false;
  bool isSubmitRecommendation = false;
  SharedPreferences prefs;
  String userIdPref, token, roleId;
  List<Skill> skeelSelectedList = List();
  String strTitle = "", strRequest = "", strCompetency = "";
  String strSkills = "",
      strYear = "",
      strEndYear = "",
      appliedFilter = "",
      filterData = "";
  DateTime date;
  String strRecommendation = "", strPrefixPathforPhoto;
  final _formKey = GlobalKey<FormState>();
  File imagePath;
  String selectedImageType = "media";
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  List<AcvhievmentSkillModel> skillList = List();
  bool isMedaiDialog = false;
  List<Assest> assestList = List();

  Map<int, bool> filterStatus = Map();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    isParent = prefs.getBool("isParent");
    if (isParent == null) {
      isParent = false;
    }

    skeelSelectedList.addAll(recomdation.skillList);

    if (recomdation != null) {
      strTitle = recomdation.title == "null" ? "" : recomdation.title;
      strCompetency = recomdation.focusArea == null ||
              recomdation.focusArea == "null" ||
              recomdation.focusArea == ""
          ? recomdation.level3Competency
          : recomdation.focusArea;
      strRequest = recomdation.request;
      setState(() {
        strTitle;
        strCompetency;
        strRequest;
      });
      for (int i = 0; i < skillList.length; i++) {
        for (int j = 0; j < recomdation.skillList.length; j++) {
          if (skillList[i].title == recomdation.skillList[j].label) {
            filterStatus[i] = true;
            if (appliedFilter == "") {
              appliedFilter = skillList[i].title;
            } else {
              appliedFilter = appliedFilter + "," + skillList[i].title;
            }
          }
        }
      }
    }
    if (recomdation != null) {
      if (recomdation.requestedDate != "null") {
        int d = int.tryParse(recomdation.requestedDate);
        date = DateTime.fromMillisecondsSinceEpoch(d);
        var formatter = DateFormat('MMM dd, yyyy');
        strYear = formatter.format(date);
      }
      if (recomdation.interactionEndDate != "null") {
        int d = int.tryParse(recomdation.interactionEndDate);
        date = DateTime.fromMillisecondsSinceEpoch(d);
        var formatter = DateFormat('MMM dd, yyyy');
        strEndYear = formatter.format(date);
      } else {
        // var formatter =  DateFormat('MMM, yyyy');
        // strEndYear = formatter.format(new DateTime.now());
        strEndYear = "Ongoing";
      }
      setState(() {
        strEndYear;
        strYear;
      });
    }
    print("shubh test++");
    assestList.addAll(recomdation.mediaVideoList);

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  onBack() async {
    Navigator.pop(context);
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.pop(context, "push");
      //Handle version 1.1
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCall() async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "recommenderId": int.parse(userIdPref),
        "recommendationId": recomdation.recommendationId,
        "stage": "Replied",
        "recommendation": strRecommendation,
        "repliedDate": DateTime.now().millisecondsSinceEpoch.toString(),
        "skills": skeelSelectedList.map((item) => item.toJson()).toList(),
        "asset": recomdation.assestList.map((item) => item.toJson()).toList()
      };

      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_RECOMENDATION, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            //  ToastWrap.showToast(msg);

            showSucessMsg(msg, context);
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PERSONAL_INFO + recomdation.userId + "/false",
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              /*  profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                setState(() {
                  profileInfoModal;
                });
              }*/
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------Recommendation Info api ------------------

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  @override
  void initState() {
    try {
      getSharedPreferences();
      // TODO: implement initState

    } catch (e) {
      e.toString();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey we created above
    Constant.applicationContext = context;

    Padding gridSelectedImages() {
      return recomdation.assestList != null && recomdation.assestList.length > 0
          ? PaddingWrap.paddingfromLTRB(
              5.0,
              5.0,
              5.0,
              5.0,
              Container(
                  height: 135.0,
                  child: GridView.count(
                    primary: true,
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.all(5.0),
                    crossAxisCount: 1,
                    childAspectRatio: .80,
                    mainAxisSpacing: 5.0,
                    crossAxisSpacing: 2.0,
                    children: List.generate(recomdation.assestList.length,
                        (int index) {
                      return /*index == 0
                          ?  InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  5.0,
                                  0.0,
                                  15.0,
                                  10.0,
                                   Image.asset(
                                    "assets/profile/add_image.png",
                                    width: 80.0,
                                    height: 80.0,
                                  )),
                              onTap: () {
                                getImage(ImageSource.gallery);
                              })
                          : */
                          Stack(
                        children: <Widget>[
                          InkWell(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Image.network(
                                    Constant.IMAGE_PATH +
                                        recomdation.assestList[index].file,
                                    fit: BoxFit.cover,
                                    height: 85.0,
                                    width: 145.0,
                                  ),
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Expanded(
                                        child: TextViewWrap.textView(
                                            recomdation.assestList[index].tag,
                                            TextAlign.start,
                                            Colors.black,
                                            12.0,
                                            FontWeight.bold),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: recomdation
                                                    .assestList[index].tag ==
                                                "media"
                                            ? PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                15.0,
                                                0.0,
                                                Image.asset(
                                                  "assets/newIcon/general.png",
                                                  height: 20.0,
                                                  width: 20.0,
                                                ))
                                            : recomdation.assestList[index]
                                                        .tag ==
                                                    "badges"
                                                ? PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    0.0,
                                                    15.0,
                                                    0.0,
                                                    Image.asset(
                                                      "assets/newIcon/badge_black.png",
                                                      height: 20.0,
                                                      width: 20.0,
                                                    ))
                                                : recomdation.assestList[index]
                                                            .tag ==
                                                        "trophy"
                                                    ? PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            15.0,
                                                            0.0,
                                                            Image.asset(
                                                              "assets/newIcon/trophy.png",
                                                              height: 20.0,
                                                              width: 20.0,
                                                            ))
                                                    : PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            15.0,
                                                            0.0,
                                                            Image.asset(
                                                              "assets/newIcon/Certificate_black.png",
                                                              height: 20.0,
                                                              width: 20.0,
                                                            )),
                                        flex: 0,
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              onLongPress: () {
                                recomdation.assestList.removeAt(index);
                                setState(() {
                                  recomdation.assestList;
                                });
                              }),
                          Container(
                            height: 85.0,
                            width: 145.0,
                            color: Colors.black54.withOpacity(.4),
                          ),
                        ],
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              10.0,
              5.0,
              10.0,
              Container(
                height: 1.0,
              ));
    }

    void iterateFilters(key, value) {
      print('-------------$key:$value'); //string interpolation in action
      if (value) {
        if (key != 0) {
          if (filterData == "") {
            filterData = (key).toString();
            appliedFilter = skillList[key].title;

            skeelSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          } else {
            filterData = filterData + "," + (key).toString();
            appliedFilter = appliedFilter + "," + skillList[key].title;
            skeelSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          }
        }
      }
    }

    void onApplyClick() {
      filterData = "";
      appliedFilter = "";
      skeelSelectedList.clear();
      filterStatus.forEach(iterateFilters);
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());
        appliedFilter;
      });
      Navigator.pop(context);
    }

    void onCancelTap() {
      filterData = "";
      appliedFilter = "";
      skeelSelectedList.clear();
      for (int i = 0; i < filterStatus.length; i++) {
        filterStatus[i] = false;
      }
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());
        appliedFilter;
      });
      Navigator.pop(context);
    }

    final titleUi = Container(
        margin: EdgeInsets.only(top: 10.0),
        child: InkWell(
          child: TextFormField(
            enabled: false,
            maxLines: null,
            controller: TextEditingController(text: strTitle),
            keyboardType: TextInputType.text,
            style: TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 16.0),
            decoration: InputDecoration(
              contentPadding: EdgeInsets.only(top: 5),
              labelText: "Title",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              fillColor: Colors.transparent,
              border: InputBorder.none,
            ),
          ),
        ));

    final competencyUi = Container(
        margin: EdgeInsets.only(top: 10.0),
        child: InkWell(
          child: TextFormField(
            enabled: false,
            maxLines: null,
            controller: TextEditingController(text: strCompetency),
            style: TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 16.0),
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.only(top: 5),
              labelText: "Focus Area",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              fillColor: Colors.transparent,
              border: InputBorder.none,
            ),
          ),
        ));

    final interactionUi = Container(
        margin: EdgeInsets.only(top: 10.0),
        child: InkWell(
          child: TextFormField(
            enabled: false,
            maxLines: null,
            style: TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 16.0),
            controller:
                TextEditingController(text: strYear + " - " + strEndYear),
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.only(top: 5),
              labelText: "Interaction Date",
              labelStyle: TextStyle(
                  color: ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              fillColor: Colors.transparent,
              border: InputBorder.none,
            ),
          ),
        ));

    final requestUi = Container(
        child: InkWell(
      child: TextFormField(
        enabled: false,
        maxLines: null,
        controller: TextEditingController(text: strRequest),
        keyboardType: TextInputType.text,
        style: TextStyle(
            color: ColorValues.HEADING_COLOR_EDUCATION,
            fontFamily: Constant.TYPE_CUSTOMREGULAR,
            fontSize: 16.0),
        decoration: InputDecoration(
          labelText: "Request",
          labelStyle: TextStyle(
              color: ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          fillColor: Colors.transparent,
          border: InputBorder.none,
        ),
      ),
    ));

    Container writeRecommendation() {
      return Container(
          child: Padding(
              padding: EdgeInsets.only(
                  left: 10.0, top: 20.0, right: 10.0, bottom: 20.0),
              child: Container(
                  height: 50.0,
                  child: FlatButton(
                    onPressed: () {
                      setState(() {
                        isSubmitRecommendation = true;
                      });
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0)),
                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                    child: Row(
                      // Replace with a Row for horizontal icon + text
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text('WRITE RECOMMENDATION ',
                            style: TextStyle(
                                fontSize: 14.0,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                color: Colors.white)),
                      ],
                    ),
                  ))));
    }

    final submitButton = Padding(
        padding:
            EdgeInsets.only(left: 10.0, top: 20.0, right: 10.0, bottom: 20.0),
        child: Container(
            height: 50.0,
            child: FlatButton(
              onPressed: () {
                final form = _formKey.currentState;
                form.save();
                if (form.validate()) {
                  if (appliedFilter == "") {
                    ToastWrap.showToast(
                        MessageConstant.SELECT_SKILLS_VAL, context);
                    return false;
                  } else {
                    apiCall();
                  }
                }
              },
              color: ColorValues.BLUE_COLOR,
              child: Row(
                // Replace with a Row for horizontal icon + text
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text('SEND ',
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMBOLD,
                          color: Colors.white)),
                ],
              ),
            )));

    String strAzureImageUploadPath = "";

    ontapApply() async {
      if (imagePath != null) {
        strAzureImageUploadPath = await uploadImgOnAzure(
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforPhoto);

        setState(() {
          strAzureImageUploadPath;
        });
        print("azureimagepath   :-" + strAzureImageUploadPath);

        CustomProgressLoader.cancelLoader(context);
        if (strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") {
          assestList.removeLast();

          assestList.add(new Assest("image", selectedImageType,
              strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
          assestList.add(new Assest("image", selectedImageType, "", "", false));

          selectedImageType = "media";
          strAzureImageUploadPath = "";
          imagePath = null;
          setState(() {
            isMedaiDialog = false;
            assestList;
            selectedImageType;
            strAzureImageUploadPath;
            imagePath;
          });
        }
      }
    }

    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.0,
        ratioY: 1.0,
      );
    }

    final mediaImageListUI = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 0.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: assestList.map((path) {
        if (path.type == "video") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 54.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: VideoApp(Constant.IMAGE_PATH + path.file)),
              onTap: () {},
            )
          ]);
        } else {
          return Stack(
            children: <Widget>[
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  FadeInImage.assetNetwork(
                    fit: BoxFit.cover,
                    placeholder: 'assets/aerial/default_img.png',
                    image: Constant.IMAGE_PATH + path.file,
                    height: 54.0,
                    width: 54.0,
                  )
                ],
              ),
            ],
          );
        }
      }).toList(),
    ));

    _buildChoiceList() {
      List<Widget> choices = List();
      skeelSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.all(3.0),
            child: Row(
              children: <Widget>[
                Flexible(
                  child: Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),
                  flex: 1,
                ),
              ],
            )));
      });
      return choices;
    }

    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: Scaffold(
            backgroundColor: ColorValues.SCREEN_BG_COLOR,
            appBar: AppBar(
              elevation: 0.0,
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: CustomViews.getBackButton(),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Text(
                      "Recommendations",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                Container(
                  width: 30.0,
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                Expanded(
                  child: recomdation.stage == "Added" && recomdation.type=="self"?
                  Container(
                      color: ColorValues
                          .SCREEN_BG_COLOR,
                      child: Column(
                        children: <Widget>[
                          PaddingWrap
                              .paddingAll(
                              10.0,
                              Container(
                                child:
                                Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <
                                      Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        5.0,
                                        15.0,
                                        0.0,
                                        15.0,
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: <Widget>[
                                            Expanded(
                                              child: ClipOval(
                                                  child: FadeInImage.assetNetwork(
                                                    fit: BoxFit.cover,
                                                    placeholder: 'assets/profile/user_on_user.png',
                                                    image: recomdation == null || recomdation.user.profilePicture == null ? "" : Constant.IMAGE_PATH + recomdation.user.profilePicture,
                                                    height: 46.0,
                                                    width: 46.0,
                                                  )),
                                              flex: 0,
                                            ),
                                            Expanded(
                                              child: PaddingWrap.paddingfromLTRB(
                                                  5.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    children: <Widget>[
                                                      Row(
                                                        children: <Widget>[
                                                          PaddingWrap.paddingfromLTRB(
                                                            5.0,
                                                            5.0,
                                                            0.0,
                                                            2.0,
                                                            TextViewWrap.textView("From: ", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 14.0, FontWeight.normal),
                                                          ),
                                                          PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            2.0,
                                                            2.0,
                                                            TextViewWrap.textView(
                                                                recomdation.user.firstName == null
                                                                    ? ""
                                                                    : recomdation.user.firstName != "null"
                                                                    ? recomdation.user.lastName != "null"
                                                                    ? recomdation.user.firstName + " " + recomdation.user.lastName
                                                                    : recomdation.user.firstName
                                                                    : "" + recomdation.user.lastName,
                                                                TextAlign.start,
                                                                ColorValues.HEADING_COLOR_EDUCATION,
                                                                14.0,
                                                                FontWeight.bold),
                                                          ),
                                                        ],
                                                      ),
                                                      PaddingWrap.paddingfromLTRB(
                                                        5.0,
                                                        0.0,
                                                        0.0,
                                                        2.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            recomdation.user.tagline == null
                                                                ? ""
                                                                : recomdation.user.tagline == "null"
                                                                ? ""
                                                                : recomdation.user.tagline,
                                                            TextAlign.start,
                                                            ColorValues.GREY_TEXT_COLOR,
                                                            12.0,
                                                            FontWeight.normal,
                                                            3),
                                                      ),
                                                    ],
                                                  )),
                                              flex: 1,
                                            )
                                          ],
                                        )),
                                    Divider(
                                      height:
                                      2.0,
                                      color: ColorValues.DARK_GREY,
                                    ),

                                    PaddingWrap
                                        .paddingfromLTRB(
                                        5.0,
                                        20.0,
                                        0.0,
                                        0.0, TextViewWrap.textView(
                                        "Title",
                                        TextAlign.start,
                                        ColorValues.GREY__COLOR,
                                        14.0,
                                        FontWeight.w400)),
                                    PaddingWrap
                                        .paddingfromLTRB(
                                        5.0,
                                        0.0,
                                        0.0,
                                        0.0,  TextViewWrap.textView(
                                        strTitle,
                                        TextAlign.start,
                                        ColorValues.RADIO_BLACK,
                                        16.0,
                                        FontWeight.w400)),
                                  ],
                                ),
                              )),

                          Container(
                              decoration: BoxDecoration(
                                  color: Color(
                                      0xffF4F4F4),
                                  border: Border.all(
                                      width:
                                      1.0,
                                      color: Color(
                                          0xffDEDEDE))),
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                                mainAxisAlignment:
                                MainAxisAlignment
                                    .start,
                                children: <
                                    Widget>[
                                  PaddingWrap
                                      .paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    4.0,
                                    Text(
                                        "Add Recommendation",
                                        maxLines:
                                        30,
                                        style: TextStyle(
                                            color: ColorValues.HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontFamily: Constant.TYPE_CUSTOMBOLD)),
                                  ),
                                  PaddingWrap
                                      .paddingfromLTRB(
                                    13.0,
                                    0.0,
                                    13.0,
                                    4.0,
                                    Text(
                                        "Review recommendation.",
                                        maxLines:
                                        30,
                                        style: TextStyle(
                                            color: Color(0xff888888),
                                            fontSize: 12.0,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                  ),
                                  PaddingWrap
                                      .paddingfromLTRB(
                                    13.0,
                                    5.0,
                                    13.0,
                                    4.0,
                                    Text(
                                        recomdation
                                            .recommendation,
                                        maxLines:
                                        30,
                                        style: TextStyle(
                                            color: ColorValues.HEADING_COLOR_EDUCATION,
                                            fontSize: 16.0,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                  ),
                                  recomdation.recommenderFile !=
                                      "null" &&
                                      recomdation.recommenderFile !=
                                          ""
                                      ? PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      10.0,
                                      8.0,
                                      10.0,
                                      InkWell(
                                          onTap: () {
                                            launch(Constant.IMAGE_PATH + recomdation.recommenderFile);
                                          },
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: <Widget>[
                                              Expanded(child: Image.asset("assets/added_pdf.png", height: 56, width: 56), flex: 0),
                                              Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(left: 10.0, bottom: 8.0),
                                                    child: TextViewWrap.textViewMultiLine(recomdation.recommenderFileName, TextAlign.start, ColorValues.BLUE_COLOR_BOTTOMBAR, 14.0, FontWeight.normal, 1),
                                                  ),
                                                  flex: 1)
                                            ],
                                          )))
                                      : Container(
                                    height:
                                    0.0,
                                  ),

                                  Divider(
                                    height:
                                    2.0,
                                    color: ColorValues.DARK_GREY,
                                  ),


                                ],
                              )),
                        ],
                      )):
                  Container(
                      color: ColorValues.SCREEN_BG_COLOR,
                      child: Theme(
                          data: ThemeData(hintColor: Colors.grey[300]),
                          child: Stack(children: <Widget>[
                            Positioned(
                                top: 0.0,
                                left: 0.0,
                                bottom: 0.0,
                                right: 0.0,
                                child: Form(
                                    key: _formKey,
                                    child: recomdation == null
                                        ? Container()
                                        : ListView(
                                      children: <Widget>[
                                        Container(
                                            color: ColorValues
                                                .SCREEN_BG_COLOR,
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                PaddingWrap.paddingfromLTRB(
                                                    10.0,
                                                    20.0,
                                                    10.0,
                                                    20.0,
                                                    TextViewWrap.textView(
                                                        "Check what you have recommended",
                                                        TextAlign
                                                            .start,
                                                        ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        14.0,
                                                        FontWeight
                                                            .normal)),
                                                Divider(
                                                  height: 1.0,
                                                  color: Color(
                                                      0xffE9E9EC),
                                                ),
                                                Container(
                                                    width: double
                                                        .infinity,
                                                    color: Color(
                                                        0xFFF4F4F4),
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                        10.0,
                                                        20.0,
                                                        10.0,
                                                        0.0,
                                                        Container(
                                                          color: Color(
                                                              0xFFF4F4F4),
                                                          child:
                                                          Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment.start,
                                                            children: <
                                                                Widget>[
                                                              TextViewWrap.textView(
                                                                  "Recommendation replied",
                                                                  TextAlign.start,
                                                                  ColorValues.HEADING_COLOR_EDUCATION,
                                                                  12.0,
                                                                  FontWeight.normal),

                                                              recomdation.recommendation==""||recomdation.recommendation=="null"||recomdation.recommendation==null?
                                                              Container(height: 0,): PaddingWrap.paddingfromLTRB(
                                                                0.0,
                                                                15.0,
                                                                0.0,
                                                                15.0,
                                                                Text(recomdation.recommendation , maxLines: 30, style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontWeight: FontWeight.w400, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                              ),
                                                              recomdation.recommenderFile != "null" && recomdation.recommenderFile != ""
                                                                  ? PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  10.0,
                                                                  8.0,
                                                                  10.0,
                                                                  InkWell(
                                                                      onTap: () {
                                                                        launch(Constant.IMAGE_PATH + recomdation.recommenderFile);
                                                                      },
                                                                      child: Row(
                                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        children: <Widget>[
                                                                          Expanded(child: Image.asset("assets/added_pdf.png", height: 56, width: 56), flex: 0),
                                                                          Expanded(
                                                                              child: Padding(
                                                                                padding: const EdgeInsets.only(left: 10.0, bottom: 8.0),
                                                                                child: TextViewWrap.textViewMultiLine(recomdation.recommenderFileName, TextAlign.start, ColorValues.BLUE_COLOR_BOTTOMBAR, 14.0, FontWeight.normal, 1),
                                                                              ),
                                                                              flex: 1)
                                                                        ],
                                                                      )))
                                                                  : Container(
                                                                height: 0.0,
                                                              ),
                                                              PaddingWrap.paddingfromLTRB(
                                                                0.0,
                                                                10.0,
                                                                0.0,
                                                                0.0,
                                                                Divider(height: 1.0, color: ColorValues.LIGHT_GREY_TEXT_COLOR),
                                                              )
                                                            ],
                                                          ),
                                                        ))),
                                                PaddingWrap
                                                    .paddingfromLTRB(
                                                    10.0,
                                                    20.0,
                                                    10.0,
                                                    10.0,
                                                    Container(
                                                      child:
                                                      Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .start,
                                                        children: <
                                                            Widget>[
                                                          TextViewWrap.textView(
                                                              "REQUEST FOR RECOMMENDATION",
                                                              TextAlign.start,
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                              12.0,
                                                              FontWeight.normal),
                                                          strRequest == "" ||
                                                              strRequest == "null"
                                                              ? Container(
                                                            height: 0,
                                                          )
                                                              : PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            15.0,
                                                            0.0,
                                                            15.0,
                                                            Text(strRequest , maxLines: 30, style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontWeight: FontWeight.w400,fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                          ),
                                                          PaddingWrap.paddingfromLTRB(
                                                              5.0,
                                                              15.0,
                                                              0.0,
                                                              10.0,
                                                              Row(
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                children: <Widget>[
                                                                  Expanded(
                                                                    child: ClipOval(
                                                                        child: FadeInImage.assetNetwork(
                                                                          fit: BoxFit.cover,
                                                                          placeholder: 'assets/profile/user_on_user.png',
                                                                          image: recomdation.user.profilePicture == "null" ? "" : Constant.IMAGE_PATH + recomdation.user.profilePicture,
                                                                          height: 46.0,
                                                                          width: 46.0,
                                                                        )),
                                                                    flex: 0,
                                                                  ),
                                                                  Expanded(
                                                                    child: PaddingWrap.paddingfromLTRB(
                                                                        5.0,
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          children: <Widget>[
                                                                            Row(
                                                                              children: <Widget>[
                                                                                PaddingWrap.paddingfromLTRB(
                                                                                  5.0,
                                                                                  5.0,
                                                                                  0.0,
                                                                                  2.0,
                                                                                  TextViewWrap.textView("From: ", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 14.0, FontWeight.normal),
                                                                                ),
                                                                                PaddingWrap.paddingfromLTRB(
                                                                                  0.0,
                                                                                  5.0,
                                                                                  2.0,
                                                                                  2.0,
                                                                                  TextViewWrap.textView(
                                                                                      recomdation.user.firstName == "null"
                                                                                          ? ""
                                                                                          : recomdation.user.firstName != "null"
                                                                                          ? recomdation.user.lastName != "null"
                                                                                          ? recomdation.user.firstName + " " + recomdation.user.lastName
                                                                                          : recomdation.user.firstName
                                                                                          : "" + recomdation.user.lastName,
                                                                                      TextAlign.start,
                                                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                                                      14.0,
                                                                                      FontWeight.bold),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                            PaddingWrap.paddingfromLTRB(
                                                                              5.0,
                                                                              0.0,
                                                                              0.0,
                                                                              2.0,
                                                                              TextViewWrap.textView(recomdation.user.tagline == "null" ? "" : recomdation.user.tagline, TextAlign.start, ColorValues.GREY_TEXT_COLOR, 12.0, FontWeight.normal),
                                                                            ),
                                                                          ],
                                                                        )),
                                                                    flex: 1,
                                                                  )
                                                                ],
                                                              )),
                                                          Divider(
                                                            height:
                                                            1.0,
                                                            color:
                                                            Color(0xffE9E9EC),
                                                          )
                                                        ],
                                                      ),
                                                    )),
                                                recomdation != null
                                                    ? PaddingWrap
                                                    .paddingfromLTRB(
                                                    13.0,
                                                    10.0,
                                                    13.0,
                                                    10.0,
                                                    Column(
                                                      mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                      children: <
                                                          Widget>[

                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            0.0,
                                                            5.0,TextViewWrap.textView(
                                                            "Title",
                                                            TextAlign.start,
                                                            ColorValues.GREY__COLOR,
                                                            14.0,
                                                            FontWeight.w400)),

                                                        TextViewWrap.textView(
                                                            recomdation.title,
                                                            TextAlign.start,
                                                            ColorValues.RADIO_BLACK,
                                                            16.0,
                                                            FontWeight.w400),


                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            15.0,
                                                            0.0,
                                                            5.0,TextViewWrap.textView(
                                                            "Focus Area",
                                                            TextAlign.start,
                                                            ColorValues.GREY__COLOR,
                                                            14.0,
                                                            FontWeight.w400)),
                                                        TextViewWrap.textView(
                                                            strCompetency,
                                                            TextAlign.start,
                                                            ColorValues.RADIO_BLACK,
                                                            16.0,
                                                            FontWeight.w400),
                                                        // competencyUi,

                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            15.0,
                                                            0.0,
                                                            0.0,
                                                            Row(
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              children: <Widget>[
                                                                Expanded(
                                                                  child: TextViewWrap.textView("Skills",
                                                                      TextAlign.start, ColorValues.GREY__COLOR, 14.0, FontWeight.w400, ),
                                                                  flex: 1,
                                                                ),
                                                              ],
                                                            )),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            0.0,
                                                            15.0,
                                                            Row(
                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                              children: <Widget>[
                                                                Expanded(
                                                                  child: Wrap(
                                                                    children: _buildChoiceList(),
                                                                  ),
                                                                  flex: 1,
                                                                ),
                                                              ],
                                                            )),

                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            5.0,TextViewWrap.textView(
                                                            "Interaction Date",
                                                            TextAlign.start,
                                                            ColorValues.GREY__COLOR,
                                                            14.0,
                                                            FontWeight.w400)),

                                                        TextViewWrap.textView(
                                                            strYear +
                                                                " - " +
                                                                strEndYear,
                                                            TextAlign.start,
                                                            ColorValues.RADIO_BLACK,
                                                            16.0,
                                                            FontWeight.w400),
                                                        assestList.length > 0
                                                            ? PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            30.0,
                                                            0.0,
                                                            10.0,
                                                            Text(
                                                              "Media",
                                                              style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            ))
                                                            :  Container(
                                                          height: 0.0,
                                                        ),
                                                        mediaImageListUI,
                                                      ],
                                                    ))
                                                    : Container(
                                                  height: 0.0,
                                                )
                                              ],
                                            ))
                                      ],
                                    ))),
                          ]))),
                  flex: 1,
                )
              ],
            ),
            bottomNavigationBar:
            recomdation != null &&recomdation.type!="Request" && recomdation.type!="request"  && recomdation.stage == "Added"
                    ?  PaddingWrap.paddingfromLTRB(
              13.0,
              20.0,
              13.0,
              20.0,
              RichText(
                text: TextSpan(
                  style: DefaultTextStyle.of(context).style,
                  children: <TextSpan>[
                    TextSpan(
                        text:
                        'Note:If this recommendation is not accurate, please contact',
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            fontFamily: Constant.TYPE_CUSTOMITALIC,
                            color: ColorValues.HEADING_COLOR_EDUCATION,
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.w400,
                            fontSize: 14)),

                    TextSpan(
                        text: ' team@spikeview.com',

                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            final String subject = "";
                            final String stringText = "";
                            String uri = 'mailto:team@spikeview.com?subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(stringText)}';
                            launch(uri);
                          },
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.italic,
                            fontFamily: Constant.TYPE_CUSTOMITALIC)),
                  ],
                ),
              ),
            )
                    : Container(
                        height: 0,
                      )));
  }
}
