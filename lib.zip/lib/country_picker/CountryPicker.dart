import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/Constant.dart';


import 'Country.dart';

//export 'Country.dart';

const _platform = const MethodChannel('smart_landlord');
Future<List<CountryCode>> _fetchLocalizedCountryCodeNames() async {
  List<CountryCode> renamed =  List();
  Map result;
  try {
    var isoCodes = <String>[];
    CountryCode.ALL.forEach((CountryCode country) {
      isoCodes.add(country.isoCode);
    });
    result = await _platform.invokeMethod(
        'getCountryCodeNames', <String, dynamic>{'isoCodes': isoCodes});
  } on PlatformException catch (e) {
    return CountryCode.ALL;
  }

  for (var country in CountryCode.ALL) {
    renamed.add(country.copyWith(name: result[country.isoCode]));
  }
  renamed.sort((CountryCode a, CountryCode b) =>
      removeDiacritics(a.name).compareTo(b.name));

  return renamed;
}

removeDiacritics(String name) {}

/// The country picker widget exposes an dialog to select a country from a
/// pre defined list, see [CountryCode.ALL]
class CountryCodePicker extends StatelessWidget {
  const CountryCodePicker({
    Key key,
    this.selectedCountryCode,
    @required this.onChanged,
    this.dense = false,
    this.showFlag = true,
    this.showDialingCode = false,
    this.showName = true,
    this.showUnderLine = true,
    this.showDropDownIcon = true,
    this.isEnabled = true,
    this.isNew = false,
  }) : super(key: key);

  final String selectedCountryCode;
  final ValueChanged<CountryCode> onChanged;
  final bool dense;
  final bool showFlag;
  final bool showDialingCode;
  final bool showName;
  final bool showUnderLine;
  final bool showDropDownIcon;
  final bool isEnabled;
  final bool isNew;
  //final bool showName;

  @override
  Widget build(BuildContext context) {
    assert(debugCheckHasMaterial(context));
    CountryCode displayCountryCode =
    getSelectedCountryCode(selectedCountryCode);

    if (displayCountryCode == null) {
      displayCountryCode = CountryCode.findByIsoCode(
          Localizations.localeOf(context).countryCode);
    }

    return dense
        ? _renderDenseDisplay(context, displayCountryCode)
        : _renderDefaultDisplay(context, displayCountryCode);
  }

  _renderDefaultDisplay(BuildContext context, CountryCode displayCountryCode) {
    print("flag++++"+displayCountryCode.asset);
    return InkWell(
      child: Container(
          height:isNew?48: 48,

          child: Padding(
            padding:  EdgeInsets.only(top:isNew?10.0:0),
            child: Row(
              children: <Widget>[
                Container(
                    child: showFlag
                        ? displayCountryCode.dialingCode.compareTo('91') == 0
                        ? Image.asset(
                      'assets/flags/in_flag.png',
//                      package: "smart_landlord",
                      height: 26,
                      width: 26,
                      //width: 15.7,
                      fit: BoxFit.fitWidth,
                    )
                        : Image.asset(
                      displayCountryCode.asset,
                      height: 26,
                      width: 26,
                      //width: 15.7,
                      fit: BoxFit.fitWidth,
                    )
                        : Container()),
                SizedBox(
                  width: 4,
                ),
                Container(
                    child: showDialingCode
                        ? Text(
                      " +${displayCountryCode.dialingCode}",
                      style: AppTextStyle.getDynamicFonLatoFont(
                          Palette.secondaryTextColor, 16, FontType.Regular),
                    )
                        : Container()),
                Container(
                    child: showName
                        ? Text(
                      " ${displayCountryCode.name}",
                      style: TextStyle(fontSize: 22.0,fontFamily: AppConstants.stringConstant.latoMedium ),
                    )
                        : Container()),
                showDropDownIcon ? UIHelper.horizontalSpaceSmall : Container(),
                showDropDownIcon ? Image(
                  image: AssetImage(
                    ImagePath.ICON_DROP_DOWN,
                  ),
                  height: 6,
                  width: 12,
                ) : Container(),

//          Container(
//            height: double.infinity,
//            width: 1,
//            decoration: BoxDecoration(color: Palette.dividerColor),
//          ),
//          UIHelper.horizontalSpaceSmall,
              ],
            ),
          ),
          decoration:  BoxDecoration(

              border: Border(
                top: BorderSide.none,
                left: BorderSide.none,
                right: BorderSide.none,
                bottom: showUnderLine ? BorderSide(color: Palette.dividerColor, width: 1) : BorderSide.none,))),
      onTap: () {
        if(isEnabled){
          print("flag++++_renderDefaultDisplay"+displayCountryCode.asset);
          _selectCountryCode(context, displayCountryCode);
        }
      },
    );
  }

  _renderDenseDisplay(BuildContext context, CountryCode displayCountryCode) {

    return InkWell(
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Image.asset(
            displayCountryCode.asset,
//            package: "smart_landlord",
            height: 24.0,
            fit: BoxFit.fitWidth,
          ),
          Icon(Icons.arrow_drop_down,
              color: Theme.of(context).brightness == Brightness.light
                  ? Colors.grey.shade700
                  : Colors.white70),
        ],
      ),
      onTap: () {
        print("flag++++_renderDenseDisplay"+displayCountryCode.asset);
        _selectCountryCode(context, displayCountryCode);
      },
    );
  }

  Future<Null> _selectCountryCode(
      BuildContext context, CountryCode defaultCountryCode) async {
    final CountryCode picked = await showCountryCodePicker(
      context: context,
      defaultCountryCode: defaultCountryCode,
    );

    if (picked != null && picked != selectedCountryCode) onChanged(picked);
  }

  CountryCode getSelectedCountryCode(String selectedCountryCode) {
    if (selectedCountryCode == null) selectedCountryCode = '1';
    for (CountryCode code in CountryCode.ALL) {
      if (code.dialingCode == selectedCountryCode) {
        return code;
      }
    }
  }
}

/// Display an [Dialog] with the country list to selection
/// you can pass and [defaultCountryCode], see [CountryCode.findByIsoCode]
Future<CountryCode> showCountryCodePicker({
  BuildContext context,
  CountryCode defaultCountryCode,
}) async {
  assert(CountryCode.findByIsoCode(defaultCountryCode.isoCode) != null);

  return await showDialog<CountryCode>(
    context: context,
    builder: (BuildContext context) => _CountryCodePickerDialog(
      defaultCountryCode: defaultCountryCode,
    ),
  );
}

class _CountryCodePickerDialog extends StatefulWidget {
  const _CountryCodePickerDialog({
    Key key,
    CountryCode defaultCountryCode,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CountryCodePickerDialogState();
}

class _CountryCodePickerDialogState extends State<_CountryCodePickerDialog> {
  TextEditingController controller =  TextEditingController();
  String filter;
  List<CountryCode> countries;

  @override
  void initState() {
    super.initState();

    countries = CountryCode.ALL;

    _fetchLocalizedCountryCodeNames().then((renamed) {
      setState(() {
        countries = renamed;
      });
    });

    controller.addListener(() {
      setState(() {
        filter = controller.text;
      });
    });
  }

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      shadowColor: Colors.transparent,
      child: Dialog(
        child: Column(
          children: <Widget>[
            TextField(
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 20, FontType.Bold),
              decoration:  InputDecoration(
                hintText: MaterialLocalizations.of(context).searchFieldLabel,
                hintStyle: TextStyle(fontSize: 16.0,fontFamily: AppConstants.stringConstant.latoMedium ),
                contentPadding:const EdgeInsets.only(top: 17.0,left: 20.0),
                prefixIcon: Stack(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(top: 9.0),
                      child: IconButton(
                          icon: Image.asset(
                            ImagePath.ICON_BACK,
                            color: Palette.primaryTextColor,
                            height: 20,
                            width: 10,
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                          }),
                    ),
                    SizedBox(width: 2.0,),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(50.0,22.0,10.0,0.0),
                      child: Icon(Icons.search),
                    ),
                  ],
                ),
                suffixIcon: filter == null || filter == ""
                    ? Container(
                  height: 0.0,
                  width: 0.0,
                )
                    : InkWell(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(50.0,10.0,10.0,0.0),
                    child: Icon(Icons.clear)),
                  onTap: () {
                    controller.clear();
                  },
                ),
              ),
              controller: controller,
            ),
            Expanded(
              child: Scrollbar(
                child: ListView.builder(
                  itemCount: countries.length,
                  itemBuilder: (BuildContext context, int index) {
                    CountryCode country = countries[index];
                    if (filter == null ||
                        filter == "" ||
                        country.name
                            .toLowerCase()
                            .contains(filter.toLowerCase()) ||
                        country.isoCode.contains(filter)) {
                      return InkWell(
                        child: ListTile(
                          trailing: Text("+ ${country.dialingCode}"),
                          title: Row(
                            children: <Widget>[
                              country.dialingCode.compareTo('1') == 0
                                  ? Image.asset(
                                'assets/flags/us_flag.png',
                                height: 30,
//                                package: "smart_landlord",
                              )
                                  : Image.asset(
                                country.asset,
                                height: 30,
//                                package: "smart_landlord",
                              ),
                              UIHelper.horizontalSpaceSmall,
                              Expanded(
                                child: Container(
                                  child: Text(
                                    country.name,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.primaryTextColor,
                                        16,
                                        FontType.Regular),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        onTap: () {
                          Navigator.pop(context, country);
                        },
                      );
                    }
                    return Container();
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}