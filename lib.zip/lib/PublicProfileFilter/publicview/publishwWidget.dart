import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/PublicProfileFilter/ShareProfileView.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicProfilePreViewWidget.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class publishwWidget extends StatefulWidget {
  String publicUrl, isUnderThirteen;
  PublicProfileDataModel _mPublicProfileDataModel;
  bool isDisplaySocialEmail, isGPA, isLinearView, isParentCalling;
  AcoomplismentDataModel _mAcoomplismentDataModel;
  String profileType, userId;

  publishwWidget(
      this.isDisplaySocialEmail,
      this.isGPA,
      this._mPublicProfileDataModel,
      this._mAcoomplismentDataModel,
      this.profileType,
      this.isUnderThirteen,
      this.isLinearView,
      this.publicUrl,
      this.isParentCalling,
      this.userId);

  @override
  publishwWidgettState createState() {
    return   publishwWidgettState();
  }
}

class publishwWidgettState extends State<publishwWidget> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  static StreamController syncDoneController = StreamController.broadcast();

  @override
  Widget build(BuildContext context) {
    onTapPreview() async {
      if (widget.isLinearView) {
        String result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>   PublicProfilePreViewWidget(
                widget.isDisplaySocialEmail,
                widget.isGPA,
                widget._mPublicProfileDataModel,
                widget._mAcoomplismentDataModel,
                Constant.PUBLIC_URL_PATH + widget.publicUrl,
                widget.profileType,
                widget._mPublicProfileDataModel.result.userId,
                widget.isParentCalling,
                true)));
        if (result == "push") {
          Navigator.pop(context, "push");
        } else {
          Navigator.pop(context);
        }
      } else {
        try {
          print("url+++++++++++" + Constant.PUBLIC_URL_PATH + widget.publicUrl);
          /*    String result = await */
          Navigator.of(context).pushReplacement(new MaterialPageRoute(
              builder: (BuildContext context) =>   CustomPresoViewForUser(
                  widget.publicUrl,
                  "preview",
                  "Public",
                  widget.isUnderThirteen.toString(),
                  Constant.PUBLIC_URL_PATH + widget.publicUrl)));
          /*   if (result == "push") {
            Navigator.pop(context);
          }*/
        } catch (e) {
          print('Exception 111 e: $e');
        }
      }
    }

    onTapPublish() async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>   ShareProfileView(
              Constant.PUBLIC_URL_PATH + widget.publicUrl,
              widget._mPublicProfileDataModel.result.firstName,
              "public",
              widget.isParentCalling)));
      // if (result == "push") {
      Navigator.pop(context, "push");
      // }
    }

    Future updatePublicProfileStatus(bool isUrl) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "userId": int.parse(widget.userId),
            "roleId": int.parse("1"),
            "profileType": "Public",
            "isActive": isUrl
          };

          print("BADGE++++" + map.toString());
          Response response = await   ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_UPDATE_PUBLIC_PROFILE_STATUS, map);

          print("BADGE++++:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                syncDoneController.add("sucess");
                onTapPublish();
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        print("Error+++" + e.toString());
        e.toString();
      }
    }

    return Scaffold(
        backgroundColor:   ColorValues.singin_bg_color,
        appBar:   AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title:   Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
                Expanded(
                child:   InkWell(
                  child: CustomViews.getBackButton(),
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
                flex: 0,
              ),
                Expanded(
                child:   Text(
                  "",
                  textAlign: TextAlign.center,
                  style:   TextStyle(
                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              ),
            ],
          ),
          backgroundColor:   ColorValues.singin_bg_color,
        ),
        body: Container(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset('assets/newIcon/publish.png',
                    height: 65.0, width: 65.0),
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    20.0,
                    TextViewWrap.textViewMultiLine(
                        "You have successfully configured your public profile",
                        TextAlign.center,
                          ColorValues.HEADING_COLOR_EDUCATION,
                        16.0,
                        FontWeight.bold,
                        4)),
                /*PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    10.0,
                    TextViewWrap.textViewMultiLine(
                        "",
                        TextAlign.center,
                          ColorValues.GREY__COLOR,
                        14.0,
                        FontWeight.normal,
                        4)),*/
                Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 80.0),
                  child:   Row(
                    children: [
                        Expanded(
                        child:   InkWell(
                          child:   Container(
                            width: 130,
                            height: 35,
                            decoration:   BoxDecoration(
                                color: Colors.white,
                                border:   Border.all(
                                    width: 1.0,
                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR)),
                            child: Center(
                              child:   Text(
                                "PREVIEW",
                                textAlign: TextAlign.center,
                                style:   TextStyle(
                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontSize: 14,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              ),
                            ),
                          ),
                          onTap: () {
                            onTapPreview();
                          },
                        ),
                        flex: 1,
                      ),
                        Expanded(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(13.0, 0, 0, 0),
                          child:   InkWell(
                            child:   Container(
                              width: 130,
                              height: 35,
                              color:
                                    ColorValues.BLUE_COLOR_BOTTOMBAR,
                              child: Center(
                                child:   Text(
                                  "PUBLISH",
                                  textAlign: TextAlign.center,
                                  style:   TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                ),
                              ),
                            ),
                            onTap: () {
                              updatePublicProfileStatus(true);
                            },
                          ),
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ));
  }
}
