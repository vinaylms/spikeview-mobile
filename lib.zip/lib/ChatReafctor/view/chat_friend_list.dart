import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/chat/modal/ChatRoomModel.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/db/chat_model.dart';
import 'package:spike_view_project/db/db_helper_new.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/util_widget.dart';

import '../../main.dart';
import '../model/FrienndListModel.dart';
import 'package:spike_view_project/common/Util.dart';

class ChatFriendListView extends StatefulWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey;
  int notificationCount = 0;
  static StreamController syncDoneController = StreamController.broadcast();

  ChatFriendListView(this._scaffoldKey, this.notificationCount);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return ChatFriendListViewState(notificationCount);
  }
}

class ChatFriendListViewState extends State<ChatFriendListView>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {
  ChatFriendListViewState(this.notificationCount);

  String firstHalf = '';
  SharedPreferences prefs;
  int notificationCount = 0;
  int skip = 0;
  String roleId, userIdPref;
  StreamSubscription<dynamic> _streamSubscription;
  List<Friends> friendList = List();
  List<Friends> friendListSearch = List();
  TextEditingController _searchQuery = TextEditingController();
  bool focus_search = false;
  int positionOfChild = 0;
  Timer _timer;
  ScrollController _scrollController = ScrollController();
  bool isLoading = true;
  bool user_not_found = false;
  bool isLoadMore = true;
  SlidableController slidableCtrl = SlidableController();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    String skip_prefs_value;
    try {
      skip_prefs_value = prefs.getString(UserPreference.chat_skip_count);
      if (skip_prefs_value == null || skip_prefs_value == "") {
        skip_prefs_value = "0";
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "chat_friend_list", context);
      skip_prefs_value = "0";
    }
    skip = int.parse(skip_prefs_value);

    List<Student> studentList = List<Student>();
    var model = await DbHelper().getChatListDB();
    if (model != null) {
      studentList.addAll(model);
      for (int j = 0; j < studentList.length; j++) {
        Friends _mFriendModel = Friends();
        bool isActive = studentList[j].isActive.toLowerCase() == 'true';
        _mFriendModel.connectId = studentList[j].connectId;
        _mFriendModel.userId = studentList[j].userId;
        _mFriendModel.firstName = studentList[j].firstName;
        _mFriendModel.lastName = studentList[j].lastName;
        _mFriendModel.profilePicture = studentList[j].profilePicture;
        _mFriendModel.partnerId = studentList[j].partnerId;
        _mFriendModel.partnerFirstName = studentList[j].partnerFirstName;
        _mFriendModel.partnerLastName = studentList[j].partnerLastName;
        _mFriendModel.partnerRoleId = studentList[j].partnerRoleId;
        _mFriendModel.partnerProfilePicture =
            studentList[j].partnerProfilePicture;
        _mFriendModel.dateTime = studentList[j].dateTime;
        _mFriendModel.creationTime = studentList[j].creationTime;
        _mFriendModel.online = studentList[j].online;
        _mFriendModel.isActive = isActive;
        _mFriendModel.lastMessage = studentList[j].lastMessage;
        _mFriendModel.unreadMessages = studentList[j].unreadMessages;
        _mFriendModel.lastTime = studentList[j].lastTime;
        _mFriendModel.lastSeen = studentList[j].lastSeen;
        _mFriendModel.textSentBy = studentList[j].textSentBy;
        _mFriendModel.badge = studentList[j].badge;
        _mFriendModel.badgeImage = studentList[j].badgeImage;
        _mFriendModel.gamificationPoints = studentList[j].gamificationPoints;
        if (studentList[j].partnerId.toString() == "1") {
          friendList.insert(0, _mFriendModel);
        } else {
          friendList.add(_mFriendModel);
        }
      }
      _placedChatBot();
      setState(() {});
    }

    ProfileBloc.chatListController.stream.listen((value) {
      try {
        if (value != null) {
          List<Student> studentList = List<Student>();
          friendList.clear();
          if (value != null) {
            studentList.addAll(value);
            for (int j = 0; j < studentList.length; j++) {
              Friends mFriendModel = Friends();
              bool isActive = studentList[j].isActive.toLowerCase() == 'true';
              mFriendModel.connectId = studentList[j].connectId;
              mFriendModel.userId = studentList[j].userId;
              mFriendModel.firstName = studentList[j].firstName;
              mFriendModel.lastName = studentList[j].lastName;
              mFriendModel.profilePicture = studentList[j].profilePicture;
              mFriendModel.partnerId = studentList[j].partnerId;
              mFriendModel.partnerFirstName = studentList[j].partnerFirstName;
              mFriendModel.partnerLastName = studentList[j].partnerLastName;
              mFriendModel.partnerRoleId = studentList[j].partnerRoleId;
              mFriendModel.partnerProfilePicture =
                  studentList[j].partnerProfilePicture;
              mFriendModel.dateTime = studentList[j].dateTime;
              mFriendModel.creationTime = studentList[j].creationTime;
              mFriendModel.online = studentList[j].online;
              mFriendModel.isActive = isActive;
              mFriendModel.lastMessage = studentList[j].lastMessage;
              mFriendModel.unreadMessages = studentList[j].unreadMessages;
              mFriendModel.lastTime = studentList[j].lastTime;
              mFriendModel.lastSeen = studentList[j].lastSeen;
              mFriendModel.textSentBy = studentList[j].textSentBy;
              mFriendModel.badge = studentList[j].badge;
              mFriendModel.badgeImage = studentList[j].badgeImage;
              mFriendModel.gamificationPoints =
                  studentList[j].gamificationPoints;

              if (mFriendModel.partnerId.toString() == "1") {
                friendList.insert(0, mFriendModel);
              } else {
                friendList.add(mFriendModel);
              }
            }
            _placedChatBot();
          }
          setState(() {});
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "chat_friend_list", context);
      }
    });

    try {
      _streamSubscription =
          GlobalSocketConnection.updateChatController.stream.listen((data) {
            try {
              if ((userIdPref != data['sender'].toString())) {
                bool isAdded = false;

                print('update chat+++' + data.toString());
                Friends model = Friends();
                model.lastMessage = data["chat_object"]['lastMessage'];
                model.isActive = data["chat_object"]['isActive'];
                model.lastMessage = data["chat_object"]['lastMessage'];
                model.firstName = data["chat_object"]['firstName'];
                model.lastName = data["chat_object"]['lastName'];
                model.partnerId = data["chat_object"]['partnerId'];
                model.partnerFirstName =
                data["chat_object"]['partnerFirstName'];
                model.partnerLastName = data["chat_object"]['partnerLastName'];
                model.unreadMessages = data["chat_object"]['unreadMsgs'];
                model.connectId = data["connectorId"];
                model.userId = data["chat_object"]['userId'];
                model.partnerRoleId = data["chat_object"]['partnerRoleId'];
                model.textSentBy = data["sender"];
                model.online = data["chat_object"]["online"];
                model.partnerProfilePicture =
                data["chat_object"]["partnerProfilePicture"];
                model.badgeImage = data["chat_object"]["badgeImage"];
                model.gamificationPoints =
                data["chat_object"]["gamificationPoints"];
                model.profilePicture = data["chat_object"]["profilePicture"];
                model.dateTime = data["chat_object"]["dateTime"];
                model.creationTime = data["chat_object"]["creationTime"];
                model.isActive = data["chat_object"]["isActive"];
                model.lastTime = 0;
                model.lastSeen = 0;
                model.badge = data["chat_object"]["badge"];

                for (Friends model1 in friendList) {
                  if ((model1.partnerId.toString() ==
                      data['sender'].toString() &&
                      model1.partnerRoleId.toString() ==
                          data['senderRoleId'].toString()) ||
                      (model1.partnerId.toString() ==
                          data['receiver'].toString() &&
                          model1.partnerRoleId.toString() ==
                              data['receiverRoleId'].toString())) {
                    print("object..///");
                    if (data["chat_object"]['partnerId'].toString() ==
                        model1.partnerId.toString()) {
                      print("object..///...");

                      if (userIdPref == "1") {
                        friendList.remove(model1);
                        friendList.insert(0, model);
                      } else if (data['sender'].toString() == "1" ||
                          data['sender'].toString() == 1) {
                        friendList.remove(model1);
                        friendList.insert(0, model);
                      } else {
                        friendList.remove(model1);
                        friendList.insert(1, model);
                      }
                      setState(() {
                        isAdded = true;
                      });
                      break;
                    }
                  }
                }

                if (!isAdded) {
                  print("isAdded..///...");

                  if (userIdPref == "1") {
                    friendList.insert(0, model);
                  } else if (data['sender'].toString() == "1" ||
                      data['sender'].toString() == 1) {
                    friendList.insert(0, model);
                  } else {
                    friendList.insert(1, model);
                  }

                  DbHelper().deleteChatTable();
                  for (var j = 0; j < friendList.length; j++) {
                    DbHelper().add(Student(
                        null,
                        friendList[j].connectId,
                        friendList[j].userId,
                        friendList[j].firstName,
                        friendList[j].lastName,
                        friendList[j].profilePicture,
                        friendList[j].partnerId,
                        friendList[j].partnerFirstName,
                        friendList[j].partnerLastName,
                        friendList[j].partnerRoleId,
                        friendList[j].partnerProfilePicture,
                        friendList[j].dateTime,
                        friendList[j].creationTime,
                        friendList[j].online,
                        friendList[j].isActive.toString(),
                        friendList[j].lastMessage,
                        friendList[j].unreadMessages,
                        friendList[j].lastTime,
                        friendList[j].lastSeen,
                        friendList[j].textSentBy,
                        friendList[j].badge,
                        friendList[j].badgeImage,
                        friendList[j].gamificationPoints));
                  }
                } else {
                  DbHelper().deleteChatTable();
                  for (var j = 0; j < friendList.length; j++) {
                    DbHelper().add(Student(
                        null,
                        friendList[j].connectId,
                        friendList[j].userId,
                        friendList[j].firstName,
                        friendList[j].lastName,
                        friendList[j].profilePicture,
                        friendList[j].partnerId,
                        friendList[j].partnerFirstName,
                        friendList[j].partnerLastName,
                        friendList[j].partnerRoleId,
                        friendList[j].partnerProfilePicture,
                        friendList[j].dateTime,
                        friendList[j].creationTime,
                        friendList[j].online,
                        friendList[j].isActive.toString(),
                        friendList[j].lastMessage,
                        friendList[j].unreadMessages,
                        friendList[j].lastTime,
                        friendList[j].lastSeen,
                        friendList[j].textSentBy,
                        friendList[j].badge,
                        friendList[j].badgeImage,
                        friendList[j].gamificationPoints));
                  }
                }

                setState(() {});
              }
            } catch (e) {
              crashlytics_bloc.recordCrashlyticsError(
                  e, "chat_friend_list", context);
            }
          });

      _streamSubscription =
          GlobalSocketConnection.startTypingController.stream.listen((data) {
            for (Friends model in friendList) {
              if ((model.partnerId == data['sender'] &&
                  model.partnerRoleId == data['senderRoleId'])) {
                model.isTyping = true;
                setState(() {});
              }
            }
          });

      _streamSubscription =
          GlobalSocketConnection.stopTypingController.stream.listen((data) {
            for (Friends model in friendList) {
              if ((model.partnerId == data['sender'] &&
                  model.partnerRoleId == data['senderRoleId'])) {
                Timer(Duration(milliseconds: 100), () {
                  model.isTyping = false;
                  /*setState(() {
                friendList;
              });*/
                });
              }
            }
          });

      _streamSubscription =
          GlobalSocketConnection.onlineStatusController.stream.listen((data) {
            print("onlineStatusController......++++++++++");

            for (Friends model in friendList) {
              if (model.partnerId == data['userId']) {
                if (data['presence_status'] == "online") {
                  model.online = 1;
                } else if (data['presence_status'] == "offline") {
                  model.online = 0;
                }
              }
            }
            setState(() {});
          });

      isLoading = false;

      setState(() {});
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "chat_friend_list", context);
      print("Error+++" + e.toString());
    }
  }

  void _placedChatBot() {
    if (friendList.isNotEmpty) {
      final index = friendList
          .indexWhere((element) => element.partnerId.toString() == "1");
      if (index > -1) {
        Friends bot = friendList.removeAt(index);
        friendList.insert(0, bot);
      }
    }

    if (friendListSearch.isNotEmpty) {
      final index = friendListSearch
          .indexWhere((element) => element.partnerId.toString() == "1");
      if (index > -1) {
        Friends bot = friendListSearch.removeAt(index);
        friendListSearch.insert(0, bot);
      }
    }
    setState(() {});
  }

  @override
  void initState() {
    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
          if (value == "msg") {} else {
            notificationCount = int.parse(value);
            setState(() {});
          }
        });

    _streamSubscription =
        DashBoardStateParent.syncDoneController.stream.listen((value) {
          if (value == "success") {} else {
            notificationCount = int.parse(value);
            setState(() {});
          }
        });
    DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {} else {
        notificationCount = int.parse(value);
        if (mounted) setState(() {});
      }
    });
    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
          if (Constant.CONNECTIONS_PROFILE == value) {
            onRefresh();
          }
        });

    getSharedPreferences();
    _searchQuery.clear();

    _scrollController.addListener(() {
      print('-- chat list load  isLoadMore $isLoadMore');
      if (isLoadMore) {
        if (friendList.length - 1 == positionOfChild) {
          if (_scrollController.position.pixels ==
              _scrollController.position.maxScrollExtent) {
            print('-- chat list load more');
            setState(() {
              focus_search = false;
              skip = skip + 1;
              prefs.setString(UserPreference.chat_skip_count, skip.toString());
              apiCallingForTag("");
            });
          }
        }
      }
    });

    super.initState();
  }

  Widget getCellItem(Friends model, int index1) {
    bool isStudent = false;
    if (model.partnerRoleId.toString() == '1') {
      isStudent = true;
    }
    return Slidable(
      controller: slidableCtrl,
      enabled: false,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(
          children: <Widget>[
            SizedBox(
              height: 50,
              width: 50,
              child: Stack(
                children: [
                  ProfileImageView(
                    imagePath:
                    Constant.IMAGE_PATH + model.partnerProfilePicture,
                    placeHolderImage: model?.partnerRoleId == 4
                        ? "assets/profile/partner_img.png"
                        : 'assets/profile/user_on_user.png',
                    height: 48,
                    width: 48,
                    onTap: () async {},
                  ),
                  Positioned(
                    right: 0,
                    top: 0,
                    child: Image.asset(
                      model.online == 1 || model.partnerId == 1
                          ? "assets/chats/ic_online.png"
                          : "assets/chats/ic_offline.png",
                      width: 12,
                      height: 12,
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 3.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Row(
                      children: [
                        Expanded(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Flexible(
                                child: BaseText(
                                  text: (model.partnerFirstName == null
                                      ? ""
                                      : model.partnerLastName == null ||
                                      model.partnerLastName == "null"
                                      ? model.partnerFirstName == null ||
                                      model.partnerFirstName ==
                                          "null"
                                      ? ""
                                      : model.partnerFirstName
                                      : model.partnerFirstName +
                                      " " +
                                      model.partnerLastName)
                                      .trim(),
                                  textColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 1,
                                  textAlign: TextAlign.start,
                                ),
                              ),
                              const SizedBox(width: 1),
                              Padding(
                                padding: const EdgeInsets.only(top: 0),
                                child: isStudent
                                    ? Util.getStudentBadge15(
                                    model.badge, model.badgeImage)
                                    : const SizedBox.shrink(),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        BaseText(
                          text: "${UtilWidget.chatTime(model.lastTime)}",
                          textColor: const Color(0xff666B9A),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          fontFamily: Constant.latoRegular,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.end,
                          maxLines: 1,
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: BaseText(
                            text: model.isTyping
                                ? "Typing..."
                                : model.lastMessage == "null" ||
                                model.lastMessage == ""
                                ? ""
                                : getTextValue(model) + firstHalf,
                            textColor: const Color(0xff666B9A),
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            fontFamily: Constant.latoRegular,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Visibility(
                          visible: (model?.unreadMessages ?? 0) > 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: const Color(0xffF48808),
                            ),
                            child: BaseText(
                              text: "${model.unreadMessages}",
                              textColor: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w400,
                              fontFamily: Constant.latoRegular,
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      actionPane: SlidableDrawerActionPane(),
      secondaryActions: <Widget>[],
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return Scaffold(
      backgroundColor: const Color(0xffF5F6FA),
      appBar: CustomViews.getAppBar(
          '', widget._scaffoldKey, context, prefs, notificationCount),
      body: isLoading
          ? Center(child: const SizedBox.shrink())
          : RefreshIndicator(
        onRefresh: onRefresh,
        child: Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.fromLTRB(20, 5, 20, 10),
              color: AppConstants.colorStyle.white,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BaseText(
                    text: 'Chats',
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w700,
                    fontSize: 28,
                    textAlign: TextAlign.start,
                    maxLines: 1,
                  ),
                  const SizedBox(height: 15),
                  SizedBox(
                      height: 40,
                      child: TextField(
                        controller: _searchQuery,
                        autocorrect: false,
                        autofocus: false,
                        keyboardType: TextInputType.text,
                        onChanged: (s) {
                          if (_timer?.isActive ?? false) {
                            _timer?.cancel();
                          }
                          _timer =
                              Timer(Duration(milliseconds: 1000), () {
                                if (s
                                    .trim()
                                    .isNotEmpty) {
                                  friendList.clear();
                                  skip = 0;
                                  setState(() {});
                                  apiCallingForTagSearch(
                                      _searchQuery.text.trim());
                                } else {
                                  dismissSearch();
                                }
                              });
                        },
                        style: TextStyle(
                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        decoration: InputDecoration(
                          focusedBorder: OutlineInputBorder(
                            //<-- SEE HERE
                              borderSide: BorderSide(
                                  width: 1, color: Color(0xffE5EBF0)),
                              borderRadius: BorderRadius.circular(10.0)),
                          border: OutlineInputBorder(
                            //<-- SEE HERE
                              borderSide: BorderSide(
                                  width: 1, color: Color(0xffE5EBF0)),
                              borderRadius: BorderRadius.circular(10.0)),
                          disabledBorder: OutlineInputBorder(
                            //<-- SEE HERE
                              borderSide: BorderSide(
                                  width: 1, color: Color(0xffE5EBF0)),
                              borderRadius: BorderRadius.circular(10.0)),
                          enabledBorder: OutlineInputBorder(
                            //<-- SEE HERE
                              borderSide: BorderSide(
                                  width: 1, color: Color(0xffE5EBF0)),
                              borderRadius: BorderRadius.circular(10.0)),
                          fillColor: Color(0xffF3F5FF),
                          filled: true,
                          suffixIcon: _searchQuery.text.isNotEmpty
                              ? IconButton(
                              color: Colors.black,
                              icon: Icon(
                                Icons.clear,
                                size: 25.0,
                                color: ColorValues
                                    .HEADING_COLOR_EDUCATION,
                              ),
                              onPressed: () {
                                dismissSearch();
                              })
                              : IconButton(
                            onPressed: () {},
                            icon: Image.asset(
                              "assets/newDesignIcon/connections/new_search.png",
                              height: 20,
                              width: 20,
                            ),
                          ),
                          contentPadding: const EdgeInsets.only(
                              left: 13, right: 13, top: 10, bottom: 10),
                          errorStyle: Util.errorTextStyle,
                          hintText: 'Search in your connections',
                          hintStyle: TextStyle(
                              fontFamily: Constant.latoRegular,
                              fontSize: 14,
                              color: Color(0xff666B9A)),
                          labelStyle: TextStyle(
                              fontSize: 16.0,
                              color: ColorValues.GREY_TEXT_COLOR,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                      )),
                  const SizedBox(height: 12),
                ],
              ),
            ),
            user_not_found
                ? Expanded(
              child: Container(
                color: Colors.white,
                padding: EdgeInsets.fromLTRB(20, 0, 20, 60),
                alignment: Alignment.center,
                child: ListView(
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  children: [
                    Image.asset(
                      "assets/newDesignIcon/icon/no_user_found.png",
                      height: 111.0,
                    ),
                    const SizedBox(height: 10),
                    BaseText(
                      text: 'No user found',
                      textColor: ColorValues.HEADING_COLOR_CHAT_1,
                      fontFamily:
                      AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 5),
                    BaseText(
                      text:
                      'Press the Connections button at\nthe bottom and add a connection',
                      textColor:
                      AppConstants.colorStyle.lightPurple,
                      fontFamily:
                      AppConstants.stringConstant.latoRegular,
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
                : Expanded(
              child: SingleChildScrollView(
                controller: _scrollController,
                physics: const ClampingScrollPhysics(),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    friendListSearch.isNotEmpty
                        ? ListView.builder(
                      shrinkWrap: true,
                      itemCount: friendListSearch.length,
                      padding: EdgeInsets.zero,
                      physics:
                      const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            InkWell(
                              child: getCellItem(
                                  friendListSearch[index],
                                  index),
                              onTap: () {
                                onTapItem(
                                    context,
                                    friendListSearch[index],
                                    "search");
                              },
                            ),
                            _divider(),
                          ],
                        );
                      },
                    )
                        : const SizedBox.shrink(),
                    friendList.isNotEmpty
                        ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ListView.builder(
                          physics:
                          const NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.zero,
                          itemCount: friendList.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            positionOfChild = index;
                            return Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                InkWell(
                                  child: getCellItem(
                                      friendList[index],
                                      index),
                                  onTap: () {
                                    onTapItem(
                                        context,
                                        friendList[index],
                                        "list");
                                  },
                                ),
                                _divider(),
                              ],
                            );
                          },
                        ),
                        Visibility(
                          visible:
                          (friendList?.length ?? 0) <= 1,
                          child: SizedBox(
                            height: MediaQuery
                                .of(context)
                                .size
                                .height *
                                0.5,
                            child: Center(
                              child: Column(
                                mainAxisSize:
                                MainAxisSize.min,
                                children: [
                                  Image.asset(
                                    "assets/no_data_man.png",
                                    height: 111,
                                  ),
                                  const SizedBox(height: 12),
                                  BaseText(
                                    text:
                                    "No Conversation yet",
                                    textColor: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    fontFamily: AppConstants
                                        .stringConstant
                                        .latoMedium,
                                    fontWeight:
                                    FontWeight.w600,
                                    fontSize: 16,
                                    textAlign:
                                    TextAlign.center,
                                    maxLines: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                        : const SizedBox.shrink(),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void dismissSearch() {
    _searchQuery.clear();
    focus_search = false;
    user_not_found = false;
    friendListSearch.clear();
    friendList.clear();
    skip = 0;
    setState(() {});
    apiCallingForTag('');
  }

  Widget _divider() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Divider(
        color: Color(0xffE5EBF0),
        height: 0,
        thickness: 1,
      ),
    );
  }

  void onTapItem(context, Friends model, String tag) async {
    if (model.isActive) {
      ChatFriendListView.syncDoneController.add(0);
      ChatRoomModel _mChatRoomModel = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  ChatRoomWidget(model, "", "")));
      if (_mChatRoomModel != null) {
        model.lastMessage = _mChatRoomModel.text;
        model.textSentBy = int.parse(_mChatRoomModel.sender);
        model.unreadMessages = 0;
        if (_mChatRoomModel.time != null && _mChatRoomModel.time.isNotEmpty) {
          if (int.parse(_mChatRoomModel.time) > model.lastTime) {
            model.lastTime = _mChatRoomModel.time != null
                ? int.parse(_mChatRoomModel.time)
                : null;
            Friends model1 = model;
            friendList.remove(model);
            if(prefs?.getString(UserPreference.USER_ID) == '1'){
              friendList.insert(0, model1);
            }else if (model.partnerId.toString() != '1') {
              friendList.insert(1, model1);
            } else {
              friendList.insert(0, model1);
            }
          }
        } else {
          model.lastTime = null;
          Friends model1 = model;
          friendList.remove(model);
          if(prefs?.getString(UserPreference.USER_ID) == '1'){
            friendList.insert(0, model1);
          }else if (model.partnerId.toString() != '1') {
            friendList.insert(1, model1);
          } else {
            friendList.insert(0, model1);
          }
        }
        /*if (model.partnerId != 1) {
          Friends model1 = model;
          friendList.remove(model);
          friendList.insert(1, model1);
        }*/
        setState(() {});
      }
    } else {
      ToastWrap.showToast(MessageConstant.CONNECTION_INACTIVE_ERROR, context);
    }
  }

  String getTextValue(Friends model) {
    if (model.lastMessage.length > 24) {
      firstHalf = model.lastMessage.substring(0, 24) + '...';
    } else {
      firstHalf = model.lastMessage;
    }
    try {
      if (model.userId != null) {
        if (model.textSentBy == model.userId) {
          return "You: ";
        }

        if (model.textSentBy == model.partnerId) {
          // return model.partnerFirstName + ": ";
          return "";
        }
      }
      return "";
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "chat_friend_list", context);
      return "";
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<Null> onRefresh() async {
    isLoading = true;
    _searchQuery.clear();
    focus_search = false;
    user_not_found = false;
    friendListSearch.clear();
    setState(() {});
    DbHelper().deleteChatTable();
    prefs.setString(UserPreference.chat_skip_count, "0");
    skip = 0;
    friendList.clear();
    apiCallingForTag("");
  }

  Future<void> apiCallingForTagSearch(String searchKey) async {
    if (searchKey != "") {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        final response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_NEW_CHAT_LIST +
                userIdPref +
                "&roleId=" +
                prefs.getString(UserPreference.ROLE_ID) +
                "&name=" +
                searchKey,
            "get");
        print("responseresponseresponse..." + response.data.toString());
        if (response.statusCode == 200) {
          if (response != null) {
            FrienndListModel list = FrienndListModel.fromJson(response.data);
            if (list.status == "Success") {
              friendListSearch.clear();
              friendListSearch.addAll(list.friendsList);
              setState(() {
                user_not_found = false;
              });
            } else if (list.status == "Error") {
              setState(() {
                user_not_found = true;
              });
            }
          }
        }
      }
    }
  }

  Future apiCallingForTag(String searchKey) async {
    DateTime dateFormat = DateTime.now();
    CustomProgressLoader.showLoader(context);
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      final response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_NEW_CHAT_LIST +
              userIdPref +
              "&roleId=" +
              prefs.getString(UserPreference.ROLE_ID) +
              "&skip=" +
              skip.toString() +
              "&name=" +
              searchKey,
          "get");
      print('-- chat list url ${response.request.baseUrl +
          response.request.path}');
      if (response.statusCode == 200) {
        CustomProgressLoader.cancelLoader(context);
        DateTime dateFormat1 = DateTime.now();
        print(dateFormat1);
        final final_time = dateFormat1
            .difference(dateFormat)
            .inSeconds;

        if (response != null) {
          FrienndListModel _mFrienndListModel =
          FrienndListModel.fromJson(response.data);

          if (_mFrienndListModel.status == "Success") {
            for (int i = 0; i < _mFrienndListModel.friendsList.length; i++) {
              DbHelper().add(Student(
                  null,
                  _mFrienndListModel.friendsList[i].connectId,
                  _mFrienndListModel.friendsList[i].userId,
                  _mFrienndListModel.friendsList[i].firstName,
                  _mFrienndListModel.friendsList[i].lastName,
                  _mFrienndListModel.friendsList[i].profilePicture,
                  _mFrienndListModel.friendsList[i].partnerId,
                  _mFrienndListModel.friendsList[i].partnerFirstName,
                  _mFrienndListModel.friendsList[i].partnerLastName,
                  _mFrienndListModel.friendsList[i].partnerRoleId,
                  _mFrienndListModel.friendsList[i].partnerProfilePicture,
                  _mFrienndListModel.friendsList[i].dateTime,
                  _mFrienndListModel.friendsList[i].creationTime,
                  _mFrienndListModel.friendsList[i].online,
                  _mFrienndListModel.friendsList[i].isActive.toString(),
                  _mFrienndListModel.friendsList[i].lastMessage,
                  _mFrienndListModel.friendsList[i].unreadMessages,
                  _mFrienndListModel.friendsList[i].lastTime,
                  _mFrienndListModel.friendsList[i].lastSeen,
                  _mFrienndListModel.friendsList[i].textSentBy,
                  _mFrienndListModel.friendsList[i].badge,
                  _mFrienndListModel.friendsList[i].badgeImage,
                  _mFrienndListModel.friendsList[i].gamificationPoints));
              if (_mFrienndListModel.friendsList[i].partnerId.toString() ==
                  "1") {
                friendList.insert(0, _mFrienndListModel.friendsList[i]);
              } else {
                friendList.add(_mFrienndListModel.friendsList[i]);
              }
            }
            _placedChatBot();
            setState(() {});
          } else {
            setState(() {
              isLoadMore = false;
            });
          }
          if (final_time > Constant.CHAT_RESPONSE_MAX_TIME) {
            API.ApiForUpdateReportStatus(
                context,
                "get",
                Constant.ENDPOINT_NEW_CHAT_LIST,
                "userId=" +
                    userIdPref +
                    "&roleId=" +
                    "&skip=" +
                    skip.toString() +
                    prefs.getString(UserPreference.ROLE_ID) +
                    "&name=" +
                    searchKey,
                final_time.toString());
          }
        } else {
          CustomProgressLoader.cancelLoader(context);
          return null;
        }
      }
      isLoading = false;
      setState(() {});
    } else {
      isLoading = false;
      setState(() {});
    }
  }
}
