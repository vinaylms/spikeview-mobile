import 'package:flutter/material.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class Palette {
  static const primaryDarkColor = Color(0xFF1E4EA0);
  static const primaryColor = Color(0xFF2D67CA);
  static Color accentColor = ColorValues.BLUE_COLOR_BOTTOMBAR;
  static Color titleColor = ColorValues.SEARCH_CATEGORY_BOX_BG;
  static Color textIconColor = ColorValues.WHITE;
  static const primaryTextColor = Color (0xFF151515);
  static Color secondaryTextColor = ColorValues.GREY_TEXT_COLOR;
  static Color dividerColor = ColorValues.GREY__COLOR_DIVIDER;
  static Color webColor = ColorValues.singin_bg_color;
  static Color headerColor = ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP;
  static const screenBgColor = Color(0xFFA9A9A9);
  static const indicatorDotColor = Color(0xFFC4C4C4);
  static Color redColor = ColorValues.RED;

}
