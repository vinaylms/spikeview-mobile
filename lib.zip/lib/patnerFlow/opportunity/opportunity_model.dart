
import 'package:spike_view_project/modal/patner/CompanyModel.dart';
import 'package:spike_view_project/modal/patner/age_between.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/patnerFlow/opportunity/call_to_action_model.dart';

class OpportunityModel {
  String sId;
  int opportunityId;
  int userId;
  int roleId;
  String jobTitle;
  String jobType;
  String jobLocation;
  String project;
  String duration;
  String status;
  int fromDate;
  int toDate;
  int groupId;
  bool targetAudience;
  String title;
  String gender;
  int companyId;
  int offerId;
  String serviceTitle;
  String serviceDesc;

  int expiresOn;
  int shareTime;
  List<String> tags = [];
  List<String> comments = [];
  List<String> likes = [];
  List<String> userList = [];
  List<CallToActionModel> callToAction;
  List<String> interestType = [];

  List<AgeBetween> age;
  List<String> location;
  List<AssetModel> asset;
  int iV;

  String url;

  OpportunityModel({
    this.sId,
    this.opportunityId,
    this.userId,
    this.roleId,
    this.jobTitle,
    this.jobType,
    this.jobLocation,
    this.project,
    this.duration,
    this.status,
    this.fromDate,
    this.toDate,
    this.groupId,
    this.targetAudience,
    this.title,
    this.gender,
    this.companyId,
    this.offerId,
    this.serviceTitle,
    this.serviceDesc,
    this.expiresOn,
    this.shareTime,
    this.tags,
    this.comments,
    this.likes,
    this.userList,
    this.callToAction,
    this.interestType,
    this.age,
    this.location,
    this.asset,
    this.iV,
    this.url,
  });

  OpportunityModel.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    opportunityId = json['opportunityId'];
    userId = json['userId'];
    roleId = json['roleId'];
    jobTitle = json['jobTitle'];
    jobType = json['jobType'];
    jobLocation = json['jobLocation'];
    project = json['project'];
    duration = json['duration'];
    status = json['status'];
    fromDate = json['fromDate'];
    toDate = json['toDate'];
    groupId = json['groupId'];
    targetAudience = json['targetAudience'];
    title = json['title'];
    gender = json['gender'];
    if(gender=="Non-binary"||gender=="NonBinary"){
      gender="Non-Binary";
    }
    companyId = json['companyId'];
    offerId = json['offerId'];
    serviceTitle = json['serviceTitle'];
    serviceDesc = json['serviceDesc'];
    expiresOn = json['expiresOn'];
    if (json['callToAction'] != null) {
      callToAction =  List<CallToActionModel>();
      json['callToAction'].forEach((v) {
        callToAction.add(new CallToActionModel.fromJson(v));
      });
    }
    if (json['interestType'] != null) {
      interestType =  List<String>();
      json['interestType'].forEach((v) {
        interestType.add(v.toString());
      });
    }
    if (json['age'] != null) {
      age =  List<AgeBetween>();
      json['age'].forEach((v) {
        age.add(new AgeBetween.fromJson(v));
      });
    }
    location = json['location'].cast<String>();
    if (json['asset'] != null) {
      asset =  List<AssetModel>();
      json['asset'].forEach((v) {
        asset.add(new AssetModel.fromJson(v));
      });
    }
    iV = json['__v'];

    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['opportunityId'] = this.opportunityId;
    data['userId'] = this.userId;
    data['roleId'] = this.roleId;
    data['jobTitle'] = this.jobTitle;
    data['jobType'] = this.jobType;
    data['jobLocation'] = this.jobLocation;
    data['project'] = this.project;
    data['duration'] = this.duration;
    data['status'] = this.status;
    data['fromDate'] = this.fromDate;
    data['toDate'] = this.toDate;
    data['groupId'] = this.groupId;
    data['targetAudience'] = this.targetAudience;
    data['title'] = this.title;

    data['gender'] = this.gender;
    String gender=this.gender;
    if(gender=="Non-binary"||gender=="NonBinary"){
      data['gender'] ="Non-Binary";
    }
    data['companyId'] = this.companyId;
    data['offerId'] = this.offerId;
    data['serviceTitle'] = this.serviceTitle;
    data['serviceDesc'] = this.serviceDesc;
    data['expiresOn'] = this.expiresOn;
    if (this.callToAction != null) {
      data['callToAction'] = this.callToAction.map((v) => v.toJson()).toList();
    }
    if (this.age != null) {
      data['age'] = this.age.map((v) => v.toJson()).toList();
    }
    data['location'] = this.location;
    if (this.asset != null) {
      data['asset'] = this.asset.map((v) => v.toJson()).toList();
    }
    data['__v'] = this.iV;

    data['url'] = this.url;
    return data;
  }
}
