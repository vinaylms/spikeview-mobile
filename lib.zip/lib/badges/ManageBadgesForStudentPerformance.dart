import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/badges/AllBadges.dart';
import 'package:spike_view_project/badges/AllBadgesPerformance.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ManageBadgesForStudentPerformance extends StatefulWidget {
  Badges badgeModel;

  ManageBadgesForStudentPerformance(this.badgeModel);

  @override
  ManageBadgesForStudentState createState() =>
      ManageBadgesForStudentState(badgeModel);
}

class ManageBadgesForStudentState extends State<ManageBadgesForStudentPerformance> {
  Badges badgeModel;

  ManageBadgesForStudentState(this.badgeModel);

  bool isRequestChange = false;
  bool isCollectionChange = false;
  bool isMore = false;
  SharedPreferences prefs;
  String userIdPref, roleId;
  String isPerformChanges = "pop";



  Future apiCallUpdateStatus(badgeId, status, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {"badgeReqId": badgeId, "status": status};

        print(map.toString());
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_BADGE_STATUS_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges = "push";
              badgeModel.requests.removeAt(index);
              setState(() {
                badgeModel;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    void badgeDialog(index, status) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          25.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(20.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
//

                                                    RichText(
                                                      textAlign:
                                                          TextAlign.center,
                                                      text: TextSpan(
                                                        text:
                                                       "Are you sure you want to withdraw your request?",
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            fontSize: 16.0,
                                                            fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                        children: <TextSpan>[

                                                        ],
                                                      ),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Ok",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                // Delete

                                                Navigator.pop(context);

                                                apiCallUpdateStatus(
                                                    badgeModel
                                                        .requests[
                                                            index]
                                                        .badgeReqId,
                                                    status,
                                                    index);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    collectionList() {
      return ListView.builder(
          itemCount: badgeModel.collections.length > 2
              ? 2
              : badgeModel.collections.length,
          shrinkWrap: true,
          physics: ScrollPhysics(),
          itemBuilder: (context, index) {
            return  Column(
              children: <Widget>[
                 Row(
                  children: <Widget>[
                    Expanded(
                      flex: 0,
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 13.0, top: 12.50, right: 10.0),
                        child: Container(
                          height: 70,
                          width: 70,
                          decoration: BoxDecoration(
                              border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER)),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child:  ClipOval(
                                child: FadeInImage.assetNetwork(
                              fit: BoxFit.contain,
                              placeholder: 'assets/profile/user_on_user.png',
                              image: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getMediumImage(badgeModel
                                      .collections[index].image),
                              height: 50.0,
                              width: 50.0,
                            )),


                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            flex: 0,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 10.0),
                              child: Text(
                                badgeModel.collections[index].companyName
                                    .toString(),
                                maxLines: 1
                                ,overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: Constant.TYPE_CUSTOMBOLD,
                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 0,
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 5.0),
                              child: Text(
                                badgeModel.collections[index].name
                                    .toString(),
                                maxLines: 1
                                ,overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 0,
                            child:  InkWell(
                              child: Text(
                                'Received on: '  +
                                    badgeModel
                                        .collections[index].date,
                                style: TextStyle(
                                  color: ColorValues.GREY_TEXT_COLOR,
                                  fontSize: 12,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                ),
                              ),
                              onTap: () {},
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                )
              ],
            );
          });
    }

    requestedList() {
      return ListView.builder(
          itemCount: badgeModel.requests.length > 2
              ? 2
              : badgeModel.requests.length,
          shrinkWrap: true,
          physics: ScrollPhysics(),
          itemBuilder: (context, index) {
            return  Column(
              children: <Widget>[
                 Row(
                  children: <Widget>[
                    Expanded(
                      flex: 0,
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 13.0, top: 12.50, right: 10.0),
                        child: Container(
                          height: 70,
                          width: 70,
                          decoration: BoxDecoration(
                              border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER)),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child:  ClipOval(
                                child: FadeInImage.assetNetwork(
                              fit: BoxFit.contain,
                              placeholder: 'assets/profile/user_on_user.png',
                              image: Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getMediumImage(badgeModel
                                      .requests[index].image),
                              height: 50.0,
                              width: 50.0,
                            )),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                            flex: 0,
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 10.0, bottom: 0.0),
                              child: Text(
                                badgeModel.requests[index].companyName
                                    .toString(),
                                maxLines: 1
                                ,overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontFamily: Constant.TYPE_CUSTOMBOLD,
                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 0,
                            child: Padding(
                              padding:
                              const EdgeInsets.only(top: 0.0, bottom: 5.0),
                              child: Text(
                                badgeModel.requests[index].name
                                    .toString(),maxLines: 1
                                ,overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 0,
                            child:  InkWell(
                              child: Text(
                                "Withdraw",
                                style: TextStyle(
                                  color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                  fontSize: 12,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                ),
                              ),
                              onTap: () {
                                badgeDialog(index, "withdraw");
                              },
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                )
              ],
            );
          });
    }

    onTapBadgeRequest() async {
      String result = await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => AllBadgesPerformance(this.badgeModel, "requested","student")));

    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child: Scaffold(
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context, isPerformChanges);
                    },
                  )
                ],
              ),
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Badges",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              actions: <Widget>[
                 Container(
                  width: 35.0,
                ),
              ],
              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body:  Stack(
              children: <Widget>[
                 Positioned(
                    right: 0.0,
                    left: 0.0,
                    top: 0.0,
                    bottom: 0.0,
                    child: badgeModel == null
                        ?  Container(
                            height: 0.0,
                          )
                        : ListView(
                            children: <Widget>[
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 25,
                                    color: ColorValues.GREY__COLOR_DIVIDER,
                                    child:  Row(
                                      children: <Widget>[
                                        Expanded(
                                          flex: 1,
                                          child: Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                14.0, 4.0, 0.0, 4.0),
                                            child: Text(
                                              badgeModel.collections
                                                          .length >
                                                      0
                                                  ? "COLLECTION(S) (" +
                                                      badgeModel
                                                          .collections
                                                          .length
                                                          .toString() +
                                                      ")"
                                                  : "COLLECTION",
                                              style: TextStyle(
                                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                                fontSize: 12,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              ),
                                            ),
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        AllBadgesPerformance(
                                                            this.badgeModel,
                                                            "collection","student")));
                                          },
                                          child: Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0, 4.0, 10.0, 4.0),
                                            child: Text(
                                              badgeModel.collections
                                                          .length >
                                                      2
                                                  ? "View All"
                                                  : "",
                                              style: TextStyle(
                                                color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                fontSize: 14,
                                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  badgeModel.collections == null ||
                                          badgeModel
                                                  .collections.length ==
                                              0
                                      ?  Container(
height: 100.0,
                                          color: Colors.white,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(14.0,0,15,0),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[
                                               Expanded(child:   Text(
                                                  "No badges yet. Go to the partner page to make a request",maxLines: null,
                                                  style: TextStyle(
                                                      fontSize: 16.0,
                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                      fontFamily:
                                                          Constant.customBold),
                                                )),
                                              ],
                                            ),
                                          ))
                                      : collectionList(),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      top: 20,
                                    ),
                                    child: Container(
                                      height: 25,
                                      color: ColorValues.GREY__COLOR_DIVIDER,
                                      child:  Row(
                                        children: <Widget>[
                                          Expanded(
                                            flex: 1,
                                            child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  14.0, 4.0, 0.0, 4.0),
                                              child: Text(
                                                "REQUESTED  (" +
                                                    badgeModel
                                                        .requests
                                                        .length
                                                        .toString() +
                                                    ")",
                                                style: TextStyle(
                                                  color: ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize: 12,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                ),
                                              ),
                                            ),
                                          ),
                                          InkWell(
                                            onTap: () {
                                              onTapBadgeRequest();
                                            },
                                            child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 4.0, 10.0, 4.0),
                                              child: Text(
                                                badgeModel.requests
                                                            .length >
                                                        2
                                                    ? "View All"
                                                    : "",
                                                style: TextStyle(
                                                  color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 14,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                ),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  badgeModel.requests == null ||
                                          badgeModel
                                                  .requests.length ==
                                              0
                                      ?  Container(
                                          height: 100.0,
                                          color: Colors.white,
                                          child: Padding(
                                              padding: const EdgeInsets.fromLTRB(14.0,0,15,0),
                                              child:Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                             Expanded(child:   Text(
                                                "Search for partners you have worked with and on their page, request for badges to show on your profile",
                                              maxLines: 5,  style: TextStyle(
                                                    fontSize: 16.0,
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontFamily:
                                                        Constant.customBold),
                                              )),
                                            ],
                                          )))
                                      : requestedList(),
                                ],
                              ),
                            ],
                          )),
              ],
            )));
  }
}
