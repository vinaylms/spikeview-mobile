import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:confetti/confetti.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:multi_charts/multi_charts.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/SpiderAndSkillDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomViewForUser.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';

import 'package:spike_view_project/modal/SkillBarModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart'
    as profile;
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/VideoFullViewWidget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import 'package:url_launcher/url_launcher.dart';
import 'dart:math';
import 'package:auto_orientation/auto_orientation.dart';
import 'package:spike_view_project/presoView/AnimMain.dart';
import 'package:spike_view_project/presoView/BubbleParticleModel.dart';
import 'package:spike_view_project/presoView/simple_animations/rendering.dart';
import 'package:spike_view_project/presoView/scatter_dependency/flutter_scatter.dart';
import 'package:spike_view_project/presoView/scatter_dependency/src/rendering/scatter.dart';
import 'package:spike_view_project/presoView/scatter_dependency/src/widgets/scatter.dart';
import 'package:spike_view_project/PublicProfileFilter/ShareProfileView.dart';
import 'GradientBorder .dart';

// Create a Form Widget
class CustomPresoViewForUser extends StatefulWidget {
  String profileId, pageName, profileType, isUnder13, link;
  final profile.ProfileData studentProfile;

  CustomPresoViewForUser(
    this.profileId,
    this.pageName,
    this.profileType,
    this.isUnder13,
    this.link, {
    this.studentProfile,
  });

  @override
  CustomPresoViewForUserWidgetState createState() {
    return CustomPresoViewForUserWidgetState();
  }
}

class CustomPresoViewForUserWidgetState extends State<CustomPresoViewForUser>
    with TickerProviderStateMixin {
  SharedPreferences prefs;
  String userIdPref, roleId;
  ConfettiController controllerTopCenter;
  PublicProfileDataModel _mPublicProfileDataModel;
  AcoomplismentDataModel _mAcoomplismentDataModel;
  final dataKey0 = GlobalKey();

  SpiderAndSkillDataModel _mSpiderAndSkillDataModel;
  List<double> spiderChartList = List<double>();
  List<String> spiderChartName = List<String>();
  bool isSpiderChartApiCalled = true;
  bool isShowSummary = false;

  //presoview variables start
  List<AccomplimentData> narrativeListLocal = List();
  List<AccomplimentData> narrativeListLocalAll = List();

  final Random random = Random();
  String time = "2:0 min";
  final List<ParticleModel> particles = [];

  List<int> indexRemoveList = List();
  int indexData = 0;

  // Bottom Navigation Animation variable
  AnimationController _bottomNavController,
      _topNavController,
      _frame2BodyController,
      _spiderChartTextBodyController,
      _thankYouTextBodyController,
      _profilePictureController,
      _profileVideoController,
      _profilePictureControllerGone,
      _frame2ProfilePictureController,
      spideChartAnimationController;
  Animation<Offset> bottomNavOffset,
      topNavOffset,
      frame2BodyOffset,
      spiderChartTextBodyOffset;

  Animation<double> spiderChartAnimation;

  //String userIdPref;
  //int previousPage = 0;

  // Profile Picture Animation
  Animation _animation;
  bool visible = false;
  bool isShowAll = false;

  // My Sotry page Animation

  AnimationController animationControllerMyStory;
  Animation<double> animationMyStory;

  // For Frame 2
  //bool isFrame2Showing = false;
  int frameNo = 0, subFrame = 0;

  // For Education Frame 3

  double viewPortFraction = 0.22;
  double viewPortFractionClg = 0.22;

  PageController pageController;
  PageController collegePageController;

  int currentPage = 0;
  int collegeCurrentPage = 0;

  double page = 2.0;
  double pageclg = 2.0;

  int narrativeCount = 0;
  int acheivementListCount = 0;
  int reccomendationListCount = 0;

  AnimationController animationController;
  Animation animation;

  AnimationController thankYouAnimcontroller;
  Animation<Offset> thankYouAnimoffset;

  bool isPaused = false;
  bool isFilterOpen = false;
  bool isFilterOpenCollege = false;

  bool clickButtonTap = false;

  double imageWidth = 216.0, imageHeight = 216.0;

  AnimationController controller;
  Animation<Offset> offset, offset1;
  List<Widget> widgets;
  List<Widget> widgetsCircles;
  bool isBackPressed = false;
  int dataIndex = 1;
  Timer actionControllerHandlerTimer;
  bool isActionButtonShowing = true; // V2.0
  PageController _controller; // V2.0
  bool _executeFutureForSliding = true;

  int timeFrameFirst = 6,
      timeFrameAboutMe = 10,
      timeFrameSpider = 0, // Spider Chart (optional slide)
      timeFrameBarGraph = 0, // All BarGraph (optional slide)
      timeFrameCollege = 0, // Education college (optional slide)
      timeFrameSchool = 0, // Education school (optional slide)
      timeFrameTestScore = 0, // All TestScore (optional slide)
      timeFrameAchievement = 12, // All Achievement List (optional slide)
      timeFrameAchievementTotal = 0, // All Achievement List (optional slide)
      timeFrameLoveInterest = 0, // All LoveInterest (optional slide)
      timeFrameFutureGoalsInterest =
          0, // All FutureGoalsInterest (optional slide)
      timeFrameFutureGoalsInstitute =
          0, // All FutureGoals Institute (optional slide)
      timeFrameSkills = 0, // All skills (optional slide)
      timeFrameCertificates = 0, // All certificates (optional slide)
      timeFrameBadges = 0, // All badges (optional slide)
      timeFrameRecommendation = 10, // All Recommendation (optional slide)
      timeFrameRecommendationTotal = 0, // All Recommendation (optional slide)
      timeFrameThankyou = 10,
      imageSlideDuration = 4,
      educationCircleSlideDuration = 5,
      internalSlideDuration2 = 4, // for all nested list data slide pages etc
      internalSlideDuration5 = 6, // for all main data slide time pages etc
      internalSlideDuration8 = 8, // for all main data slide time pages etc
      mainSlideDuration = 10, // for all main data slide time pages etc

      updatedTimeForFrameNavigation = 0;
  double resultStamp;

  Timer t, t1, timer, educationTimer, collegeEducationTimer;

  //------------newly added by ad
  List<Schools> schoolsInfoList = List();
  List<Colleges> collegesInfoList = List();
  List<Recommendations> addedRecommendationtList = List();
  List<Certificates> certificationtList = List();
  List<SkillID> skillsList = List();
  List<SkillID> goalInterestList = List();
  List<SkillID> loveInterestList = List();
  List<SkillID> otherInterestList = List();
  List<TestScores> testScoresList = List();
  List<SocialLinks> socialLinksList = List();
  List<Collections> badgesList = List();

  List<SkillBarModel> barListModelold = List();
  List<SkillDataChart> barListModel =
      List(); //_mSpiderAndSkillDataModel.result.skillChart.length

  int _current = 0;

  UploadMedia uploadMedia;

  bool isVideoClicked = false;

  String resultStampString = "";

  bool isShowVideoSlide = false;

  final ScrollController _controllerTestScroll = ScrollController();
  final ScrollController _scrollSummaryController = ScrollController();
  final ScrollController _scrollAccController = ScrollController();

  int _firstPage = 0;
  int _firstPageBadge = 0;

  CarouselController _certificateCarouselController = CarouselController();
  CarouselController _badgeCarouselController = CarouselController();
  CarouselController _recommenCarouselController = CarouselController();

  String viewType = 'preview';

  bool isShowChart = false;

  // Thank You Page
  void timerScheduleForNavigation(int time) {
    cancelNavigationTimer();
    timer = Timer.periodic(Duration(seconds: time), (timer) {
      if (!isPaused && frameNo != 15) {
        isBackPressed = false;
        _navigationBtnClick(true);
      }
    });
  }

  void cancelNavigationTimer() {
    if (timer != null) {
      timer.cancel(); // Cancel Exsiting Timer
    }
  }

  void calculateTotalNavigationTime() {
    print("initstate 777 ++++");

    //time calculation for college

    if (collegesInfoList != null && collegesInfoList.length > 0) {
      if (collegesInfoList.length > 2) {
        timeFrameCollege = timeFrameCollege +
            collegesInfoList.length * educationCircleSlideDuration;

        timeFrameCollege = timeFrameCollege +
            5; // Addeed 5 more seconds to navigate neext slide
      } else if (collegesInfoList.length > 0) {
        timeFrameCollege = mainSlideDuration;
      }
    } else
      timeFrameCollege = 0;

    //time calculation for school
    if (schoolsInfoList != null && schoolsInfoList.length > 0) {
      if (schoolsInfoList.length > 2) {
        timeFrameSchool = timeFrameSchool +
            schoolsInfoList.length * educationCircleSlideDuration;

        timeFrameSchool = timeFrameSchool +
            5; // Addeed 5 more seconds to navigate neext slide
      } else if (schoolsInfoList.length > 0) {
        timeFrameSchool = mainSlideDuration;
      }
    } else
      timeFrameSchool = 0;

    //spider and bar graph
    //if (_mPublicProfileDataModel.result.isAccomplishment && narrativeListLocalAll != null && narrativeListLocalAll.length > 0) {
    if (_mPublicProfileDataModel.result.isAccomplishment) {
      timeFrameSpider = mainSlideDuration;
      timeFrameBarGraph = mainSlideDuration;
      print('inside time timeFrameSpider:: $timeFrameSpider');
    }

    // For Achievment
    if (narrativeListLocal != null && narrativeListLocal.length > 0) {
      for (int i = 0; i < narrativeListLocal.length; i++) {
        for (int j = 0; j < narrativeListLocal[i].achievement.length; j++) {
          if (narrativeListLocal[i].achievement[j].mediaList.length > 2) {
            updatedTimeForFrameNavigation = updatedTimeForFrameNavigation +
                ((narrativeListLocal[i].achievement[j].mediaList.length) *
                    imageSlideDuration) +
                imageSlideDuration;
          } else {
            updatedTimeForFrameNavigation =
                updatedTimeForFrameNavigation + internalSlideDuration8;
          }
        }
      }
    }
    print(
        'inside time Achievment updatedTimeForFrameNavigation:: $updatedTimeForFrameNavigation');
    // For Recommendation
    if (addedRecommendationtList != null &&
        addedRecommendationtList.length > 0) {
      updatedTimeForFrameNavigation = updatedTimeForFrameNavigation +
          (addedRecommendationtList.length * internalSlideDuration5);
    }
    print(
        'inside time Achievment and recc updatedTimeForFrameNavigation:: $updatedTimeForFrameNavigation');
    // For testscore
    if (_mPublicProfileDataModel.result.testScores != null &&
        _mPublicProfileDataModel.result.testScores.length > 0) {
      timeFrameTestScore = timeFrameTestScore +
          (_mPublicProfileDataModel.result.testScores.length *
              mainSlideDuration);
    }

    // For love intetrest
    if (loveInterestList != null && loveInterestList.length > 0) {
      timeFrameLoveInterest = mainSlideDuration;
    }

    // For future goals interest
    if (goalInterestList != null && goalInterestList.length > 0) {
      timeFrameFutureGoalsInterest = mainSlideDuration;
    }

    // For future goals institute
    if (_mPublicProfileDataModel.result != null &&
        _mPublicProfileDataModel.result.goalInterestInstitute != null &&
        _mPublicProfileDataModel.result.goalInterestInstitute != 'null' &&
        _mPublicProfileDataModel.result.goalInterestInstitute != '') {
      timeFrameFutureGoalsInstitute = mainSlideDuration;
    }

    // For skills
    if (skillsList != null && skillsList.length > 0) {
      timeFrameSkills = mainSlideDuration;
    }

    // For certificate
    if (certificationtList != null && certificationtList.length > 0) {
      if (certificationtList.length > 2) {
        timeFrameCertificates = timeFrameCertificates +
            certificationtList.length * internalSlideDuration2;

        timeFrameCertificates = timeFrameCertificates +
            0; // Addeed 5 more seconds to navigate neext slide
      } else if (certificationtList.length > 0) {
        timeFrameCertificates = mainSlideDuration;
      }
    } else
      timeFrameCertificates = 0;

    // For badges
    if (badgesList != null && badgesList.length > 0) {
      if (badgesList.length > 2) {
        timeFrameBadges =
            timeFrameBadges + badgesList.length * internalSlideDuration2;

        timeFrameBadges = timeFrameBadges +
            0; // Addeed 5 more seconds to navigate neext slide
      } else if (badgesList.length > 0) {
        timeFrameBadges = mainSlideDuration;
      }
    } else
      timeFrameBadges = 0;

    updatedTimeForFrameNavigation = updatedTimeForFrameNavigation +
        timeFrameFirst +
        timeFrameAboutMe +
        timeFrameSpider +
        timeFrameBarGraph +
        timeFrameCollege +
        timeFrameSchool +
        timeFrameTestScore +
        timeFrameLoveInterest +
        timeFrameFutureGoalsInterest +
        timeFrameFutureGoalsInstitute +
        timeFrameSkills +
        timeFrameCertificates +
        timeFrameBadges +
        timeFrameThankyou;

    /*resultStamp = updatedTimeForFrameNavigation / 60;
    int decimals = 2;
    int fac = pow(10, decimals);
    resultStamp = (resultStamp * fac).round() / fac;*/

    Duration duration = Duration(seconds: updatedTimeForFrameNavigation);
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    //resultStampString = "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
    resultStampString = "$twoDigitMinutes:$twoDigitSeconds";
    print(
        "Apurva Slide time:: ${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds");

    print('time timeFrameFirst:: $timeFrameFirst');
    print('time timeFrameAboutMe:: $timeFrameAboutMe');
    print('time timeFrameSpider:: $timeFrameSpider');
    print('time timeFrameBarGraph:: $timeFrameBarGraph');
    print('time timeFrameCollege:: $timeFrameCollege');
    print('time timeFrameSchool:: $timeFrameSchool');
    print('time timeFrameTestScore:: $timeFrameTestScore');
    print('time timeFrameLoveInterest:: $timeFrameLoveInterest');
    print('time timeFrameFutureGoalsInterest:: $timeFrameFutureGoalsInterest');
    print(
        'time timeFrameFutureGoalsInstitute:: $timeFrameFutureGoalsInstitute');
    print('time timeFrameSkills:: $timeFrameSkills');
    print('time timeFrameCertificates:: $timeFrameCertificates');
    print('time timeFrameBadges:: $timeFrameBadges');
    print('time timeFrameThankyou:: $timeFrameThankyou');
    print(
        'time updatedTimeForFrameNavigation:: $updatedTimeForFrameNavigation');
    print('time String resultStampString:: $resultStampString');
  }

  void _animateSlider(pagerList, txt) {
    //int imageSlideDuration = 4;
    /*if (pagerList == null || pagerList.length == 0 || pagerList.length == 1) {
      imageSlideDuration = 3;
    } else {
      imageSlideDuration = 4;
    }*/
    t = Timer(Duration(seconds: imageSlideDuration), () {
      print("outerLoop _executeFutureForSliding" +
          _executeFutureForSliding.toString());
      if (_executeFutureForSliding) {
        int nextPage = _controller.page.round() + 1;

        if (nextPage == pagerList.length) {
          nextPage = 0;
          if (t != null) {
            print("Cancel t here");
            t.cancel();
          }
          cancelNavigationTimer();
          _controller.jumpToPage(nextPage);

          //
          _executeFutureForSliding = false;

          isBackPressed = false;

          if (!isPaused) {
            _navigationBtnClick(true);
          } else {
            isShowAll = true;
          }
          print("outerLoop next" + nextPage.toString());

          //navigationCondition
        } else {
          print("last index called" + nextPage.toString());
          if (nextPage == pagerList.length) {
            nextPage = 0;
            print("outerLoop next last index called" + nextPage.toString());
          }

          _controller
              .animateToPage(nextPage,
                  duration: Duration(seconds: imageSlideDuration),
                  curve: Curves.linear)
              .then((_) => _animateSlider(pagerList, "continue"));

          isShowAll = false;
        }
      }
    });
  }

  void _animateEducationCircle() {
    if (schoolsInfoList != null && schoolsInfoList.length > 0) {
      educationTimer = Timer(Duration(seconds: 3), () {
        if (!isFilterOpen) {
          //pageController.hasClients ? pageController.page(2) : pagecontroller.initialPage;
          int nextPage = pageController.page.round() + 1;
          print('school nextPage:: $nextPage');
          if (nextPage >= schoolsInfoList.length) {
            // || schoolsInfoList.length == 1) {
            nextPage = 0;
            educationTimer.cancel();
          } else {
            educationTimer.cancel();
            pageController
                .animateToPage(nextPage,
                    duration: Duration(seconds: 1), curve: Curves.linear)
                .then((_) => _animateEducationCircle());
          }
          setState(() {
            currentPage;
          });
        }
      });
    }
  }

  void _animateCollegeEducationCircle() {
    if (collegesInfoList != null && collegesInfoList.length > 0) {
      educationTimer = Timer(Duration(seconds: 3), () {
        if (!isFilterOpen) {
          int nextPage = collegePageController.page.round() + 1;
          print('college nextPage:: $nextPage');
          if (nextPage >= collegesInfoList.length) {
            //  || collegesInfoList.length == 1) {
            nextPage = 0;
            educationTimer.cancel();
          } else {
            educationTimer.cancel();
            collegePageController
                .animateToPage(nextPage,
                    duration: Duration(seconds: 1), curve: Curves.linear)
                .then((_) => _animateCollegeEducationCircle());
          }
          setState(() {
            currentPage;
          });
        }
      });
    }
  }

  @override
  void dispose() {
    _bottomNavController.dispose();
    _topNavController.dispose();
    _profilePictureController.dispose();
    _profileVideoController.dispose();
    _frame2ProfilePictureController.dispose();
    _frame2BodyController.dispose();
    _profilePictureControllerGone.dispose();
    spideChartAnimationController.dispose();
    _spiderChartTextBodyController.dispose();
    animationControllerMyStory.dispose();
    _thankYouTextBodyController.dispose();

    collegePageController.dispose();
    pageController.dispose();

    super.dispose();
  }

  refresh() async {
    setState(() {
      spiderChartList;
      spiderChartName;
      narrativeListLocal;
      schoolsInfoList;
      collegesInfoList;
    });
  }

  void initBgCircleAnim() {
    controller =
        AnimationController(vsync: this, duration: Duration(seconds: 2));

    offset = Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 0.1))
        .animate(controller);

    offset1 = Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 0.1))
        .animate(controller);

    controller.addStatusListener(circleAnimationStatusListener);

    controller.forward();
  }

  void circleAnimationStatusListener(AnimationStatus status) {
    if (status == AnimationStatus.completed) {
      controller.reverse();
    } else if (status == AnimationStatus.dismissed) {
      controller.forward();
    }
  }

  void thankYouAnimationStatusListener() {
    print('thankYouAnimcontroller.status:: ${thankYouAnimcontroller.status}');
    if (thankYouAnimcontroller.status == AnimationStatus.completed) {
      thankYouAnimcontroller.reverse();
    } else if (thankYouAnimcontroller.status == AnimationStatus.dismissed) {
      thankYouAnimcontroller.forward();
    }
  }

  void initThankYouPageAnim() {
    thankYouAnimcontroller =
        AnimationController(vsync: this, duration: Duration(seconds: 1));

    thankYouAnimoffset =
        Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
            .animate(thankYouAnimcontroller);

    // thankYouAnimcontroller.addStatusListener(thankYouAnimationStatusListener);
    thankYouAnimcontroller.forward();
  }

  void timerScheduleForActionControl() {
    actionControllerHandlerTimer =
        Timer.periodic(Duration(seconds: 4), (timer) {
      // Close Bottom control after 4 seconds
      if (isActionButtonShowing) {
        _settingModalBottomSheet(context);
      }
    });
  }

  //presoview variables end

  static showToastWithPush(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(context);
      Navigator.pop(context);
      AutoOrientation.portraitAutoMode();
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                _timer.cancel();
                Navigator.pop(context);
              },
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              RichText(
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: 'ERROR: ',
                                  style: TextStyle(
                                    color: Color(0xffFF0101),
                                    height: 1.2,
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: msg,
                                      style: TextStyle(
                                          color: Color(0xffFF0101),
                                          fontSize: 13.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily: Constant.customRegular),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              onTap: () {
                // _timer.cancel();
                // Navigator.pop(context);
              },
            )));
  }

  Future skillApi(isShowLaoder, userId) async {
    try {
      print("skillApi initstate 555 ++++");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response;
        if (widget.profileType == 'Public') {
          print("skillApi data+++++++" +
              Constant.ENDPOINT_PUBLIC_AND_SKILL_DETAIL +
              "" +
              "&publicUrl=" +
              widget.profileId +
              "&profileType=" +
              widget.profileType +
              "&userId=" +
              userId.toString() +
              "&viewType=preview&isunder13=" +
              widget.isUnder13.toString());
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_PUBLIC_AND_SKILL_DETAIL +
                  "" +
                  "&publicUrl=" +
                  widget.profileId +
                  "&profileType=" +
                  widget.profileType +
                  "&userId=" +
                  userId.toString() +
                  "&viewType=preview&isunder13=" +
                  widget.isUnder13.toString(),
              "get");
        } else {
          print("skillApi data+++++++" +
              Constant.ENDPOINT_SPIDER_AND_SKILL_DETAIL +
              widget.profileId +
              "&userId=" +
              userId.toString());
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_SPIDER_AND_SKILL_DETAIL +
                  widget.profileId +
                  "&userId=" +
                  userId.toString(),
              "get");
        }

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _mSpiderAndSkillDataModel =
                  SpiderAndSkillDataModel.fromJson(response.data);

              spiderChartName.addAll(_mSpiderAndSkillDataModel.result.toName());
              spiderChartList
                  .addAll(_mSpiderAndSkillDataModel.result.toValue());

              if (spiderChartList.length > 0) {
                if (spiderChartList.length < 3) {
                  if (spiderChartList.length == 1) {
                    spiderChartList.add(0);
                    spiderChartName.add("");

                    spiderChartName.add("");
                    spiderChartList.add(0);
                  } else if (spiderChartList.length == 2) {
                    spiderChartList.add(0);
                    spiderChartName.add("");
                  }
                }
              }
              setState(() {
                _mSpiderAndSkillDataModel;
                //_mSpiderAndSkillDataModel.result.skillChart.length
                barListModel = _mSpiderAndSkillDataModel.result.skillChart;
                spiderChartList;
                spiderChartName;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("Skillapi++++" + e.toString());
    }
  }

  Future barSkillApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response;
        if (widget.profileType == 'Public') {
          response = await ApiCalling2()
              .apiCall(context, Constant.ENDPOINT_SKILL + userIdPref, "get");
        } else {
          response = await ApiCalling2()
              .apiCall(context, Constant.ENDPOINT_SKILL + userIdPref, "get");
        }

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              barListModelold =
                  ParseJson.parseMapSkillListData(response.data['message']);

              setState(() {
                barListModelold;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("barSkillApi ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  void setDataForInterestCircles() {
    print('inside setDataForWorldCloud::');
    if (loveInterestList != null)
      print('inside setDataForWorldCloud:: ${loveInterestList.length}');
    widgetsCircles = <Widget>[];
    for (var i = 0; i < loveInterestList.length; i++) {
      double textFont = 0.0;
      textFont = 14.0;
      //  20.0 + (3 * narrativeListLocalAll[i].achievement.length.toDouble());
      if (textFont > 38.0) {
        textFont = 38.0;
      }

      widgetsCircles
          .add(ScatterItemInterestCircle(loveInterestList, textFont, i));
    }
    setState(() {
      widgetsCircles;
      //_mAcoomplismentDataModel;
    });
  }

  Future getProfileDetail(isShowLaoder) async {
    try {
      print("getProfileDetail initstate 333 ++++");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        Response response;

        if (widget.profileType == 'Public') {
          //for public type profile
          //http://103.21.53.11:3001/v1/ui/user/customProfileDetail?profileId=
          // &profileType=Public&publicUrl=swad&userId=2564&roleId=1&viewType=preview&isunder13=:isunder13

          print("ENDPOINT_CUSTOM_PROFILE_DETAIL++++++" +
              Constant.ENDPOINT_CUSTOM_PROFILE_DETAIL +
              "" +
              "&profileType=Public"
                  "&publicUrl=" +
              widget.profileId +
              "&userId=" +
              userIdPref +
              "&roleId=1&viewType=" +
              viewType +
              "&isunder13=" +
              widget.isUnder13);
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_CUSTOM_PROFILE_DETAIL +
                  "" +
                  "&profileType=Public"
                      "&publicUrl=" +
                  widget.profileId +
                  "&userId=" +
                  userIdPref +
                  "&roleId=1&viewType=" +
                  viewType +
                  "&isunder13=" +
                  widget.isUnder13,
              "get");
        } else {
          //for custom type profile
          print("getProfileDetail ENDPOINT_CUSTOM_PROFILE_DETAIL++++++" +
              Constant.ENDPOINT_CUSTOM_PROFILE_DETAIL +
              widget.profileId);

          //http://103.21.53.11:3001/v1/ui/user/customProfileDetail?profileId=2285&profileType=Custom&publicUrl=&userId=&roleId=&viewtype=enduser&isunder13=false
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_CUSTOM_PROFILE_DETAIL + widget.profileId,
              "get");
        }

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("getProfileDetail ENDPOINT_CUSTOM_PROFILE_DETAIL++++" +
            response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS] == "Success") {
//              getAllAccomplishment(false);
//              getAccomplishment(false);
              Result.type = "";
              _mPublicProfileDataModel = PublicProfileDataModel.fromJson(
                  response.data,
                  isCheckRecomm: true);
              getAllAccomplishment(false);
              getAccomplishment(false);
              try {
                //_mPublicProfileDataModel.result.loveOtherInterests =   List();

                if (_mPublicProfileDataModel.result.isIntroVideo.toString() !=
                        'null' &&
                    _mPublicProfileDataModel.result.introVideo != null &&
                    _mPublicProfileDataModel.result.introVideo != '') {
                  //if(_mPublicProfileDataModel.result.introVideo != null)
                  isShowVideoSlide =
                      _mPublicProfileDataModel.result.isIntroVideo;
                      }

                if (_mPublicProfileDataModel.result.loveInterests != null &&
                    _mPublicProfileDataModel.result.loveInterests.length > 0)
                  loveInterestList
                      .addAll(_mPublicProfileDataModel.result.loveInterests);
                if (_mPublicProfileDataModel.result.otherInterests != null &&
                    _mPublicProfileDataModel.result.otherInterests.length > 0)
                  otherInterestList
                      .addAll(_mPublicProfileDataModel.result.otherInterests);
                loveInterestList.addAll(otherInterestList);

                if (_mPublicProfileDataModel.result.educations.schools !=
                        null &&
                    _mPublicProfileDataModel.result.educations.schools.length >
                        0)
                  schoolsInfoList.addAll(
                      _mPublicProfileDataModel.result.educations.schools);

                if (_mPublicProfileDataModel.result.educations.colleges !=
                        null &&
                    _mPublicProfileDataModel.result.educations.colleges.length >
                        0)
                  collegesInfoList.addAll(
                      _mPublicProfileDataModel.result.educations.colleges);

                if (_mPublicProfileDataModel.result.recommendations != null &&
                    _mPublicProfileDataModel.result.recommendations.length > 0)
                  addedRecommendationtList
                      .addAll(_mPublicProfileDataModel.result.recommendations);
                //print('getProfileDetail addedRecommendationtList length::: ${addedRecommendationtList.length}');
                if (_mPublicProfileDataModel.result.certificates != null &&
                    _mPublicProfileDataModel.result.certificates.length > 0)
                  certificationtList
                      .addAll(_mPublicProfileDataModel.result.certificates);

                if (_mPublicProfileDataModel.result.skills != null &&
                    _mPublicProfileDataModel.result.skills.length > 0)
                  skillsList.addAll(_mPublicProfileDataModel.result.skills);
                //loveInterestList.addAll(_mPublicProfileDataModel.result.loveInterests);
                //print('loveInterestList 111 size: ${loveInterestList.length}');
                //otherInterestList.addAll(_mPublicProfileDataModel.result.otherInterests);
                //loveInterestList.addAll(otherInterestList);
                //print('otherInterestList 222 size: ${otherInterestList.length}');
                //print('loveInterestList 222 size: ${loveInterestList.length}');
                if (_mPublicProfileDataModel.result.goalInterests != null &&
                    _mPublicProfileDataModel.result.goalInterests.length > 0)
                  goalInterestList
                      .addAll(_mPublicProfileDataModel.result.goalInterests);
                //print('goalInterestList 222 size: ${goalInterestList.length}');
                if (_mPublicProfileDataModel.result.socialLinks != null &&
                    _mPublicProfileDataModel.result.socialLinks.length > 0)
                  socialLinksList
                      .addAll(_mPublicProfileDataModel.result.socialLinks);
                if (_mPublicProfileDataModel.result.testScores != null &&
                    _mPublicProfileDataModel.result.testScores.length > 0)
                  testScoresList
                      .addAll(_mPublicProfileDataModel.result.testScores);

                //print('testscore::: ${testScoresList.length}');

                if (_mPublicProfileDataModel.result.badges != null &&
                    _mPublicProfileDataModel.result.badges.collections !=
                        null &&
                    _mPublicProfileDataModel.result.badges.collections.length >
                        0)
                  badgesList.addAll(
                      _mPublicProfileDataModel.result.badges.collections);
              } catch (e) {}
              setState(() {
                isShowVideoSlide;
                schoolsInfoList;
                collegesInfoList;
                addedRecommendationtList;
                _mPublicProfileDataModel;

                certificationtList;
                skillsList;
                loveInterestList;
                otherInterestList;
                goalInterestList;
                socialLinksList;
                testScoresList;
                badgesList;
              });
              //if (_mPublicProfileDataModel.result.isAccomplishment) {
              skillApi(false, _mPublicProfileDataModel.result.userId);
              setDataForInterestCircles();
              //barSkillApi(false);
              // }
            } else {
              print("Error++++++++++custom");
              showToastWithPush(
                  response.data[LoginResponseConstant.MESSAGE], context);
            }
          } else {}
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      e.toString();
      print("ENDPOINT_CUSTOM_PROFILE_DETAIL++++" + e.toString());
    }
  }

  Future getAccomplishment(isShowLaoder) async {
    try {
      print("initstate 444 ++++");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response;
        if (widget.profileType == 'Public') {
          //for public type profile
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL +
                  "" +
                  "&publicUrl=" +
                  widget.profileId +
                  "&profileType=Public&viewType=enduser&userId=" +
                  userIdPref +
                  "&roleId=" +
                  roleId,
              "get");
          print("getAccomplishment++++" +
              Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL +
              "" +
              "&publicUrl=" +
              widget.profileId +
              "&profileType=Public&viewType=enduser+userId=" +
              userIdPref +
              "roleId=" +
              roleId);
        } else {
          //for custom type profile
          // print("getAccomplishment() url::: ${Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL + widget.profileId + "&userId=" + userIdPref + "&roleId=" + roleId +
          //         //'&profileType=Custom&viewType=enduser&isunder13=false'}");
          //         '&profileType=Custom'}");
          //http://103.21.53.11:3001/v1/ui/achievement/studentAchievementByLevel2?profileId=2285&userId=&profileType=Custom&viewType=enduser&isunder13=false
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL +
                  widget.profileId +
                  "&userId=" +
                  userIdPref +
                  "&roleId=" +
                  roleId +
                  '&profileType=Custom',
              //'&userId=&profileType=Custom&viewType=enduser&isunder13=false',
              "get");
        }

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("getAccomplishment++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS].toString() ==
                "Success") {
              Achievement.callingType = "";
              List<AccomplimentData> narrativeList = List();
              //_mAcoomplismentDataModel =   AcoomplismentDataModel.fromJson(response.data);
              _mAcoomplismentDataModel =
                  AcoomplismentDataModel.fromJson(response.data, "preso");
              narrativeList.addAll(_mAcoomplismentDataModel.accomplimentData);

              for (int i = 0; i < narrativeList.length; i++) {
                if (narrativeList[i].achievement.length > 0) {
                  narrativeListLocal.add(narrativeList[i]);
                }
              }
              setState(() {
                _mAcoomplismentDataModel;
                narrativeListLocal;
                //narrativeList.addAll(_mAcoomplismentDataModel.accomplimentData);

                print(
                    'getAccomplishment inside setDataForWorldCloud narrativeListLocal size:: ${narrativeListLocal.length}');
                print(
                    'getAccomplishment inside setDataForWorldCloud narrativeList size:: ${narrativeList.length}');

                calculateTotalNavigationTime();
                //setDataForWorldCloud();
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      e.toString();
      print("getAccomplishment++++" + e.toString());
    }
  }

  Future getAllAccomplishment(isShowLaoder) async {
    try {
      print("initstate 444 all ++++");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response;
        if (widget.profileType == 'Public') {
          //for public type profile
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL +
                  "" +
                  "&publicUrl=" +
                  widget.profileId +
                  "&profileType=Public&viewType=enduser&userId=" +
                  userIdPref +
                  "&roleId=" +
                  roleId,
              "get");
          print("getAllAccomplishment++++" +
              Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL +
              "" +
              "&publicUrl=" +
              widget.profileId +
              "&profileType=Public&viewType=enduser+userId=" +
              userIdPref +
              "roleId=" +
              roleId);
        } else {
          //for custom type profile
          // print(
          //     "getAllAccomplishment() url::: ${Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL + widget.profileId + "&userId=" + userIdPref + "&roleId=" + roleId +
          //         //'&profileType=Custom&viewType=enduser&isunder13=false'}");
          //         '&profileType=Custom'}");
          //http://103.21.53.11:3001/v1/ui/achievement/studentAchievementByLevel2?profileId=2285&userId=&profileType=Custom&viewType=enduser&isunder13=false
          response = await ApiCalling2().apiCallWithouAuth(
              context,
              Constant.ENDPOINT_ACCOMPLISHMENT_PROFILE_DETAIL +
                  widget.profileId +
                  "&userId=" +
                  userIdPref +
                  "&roleId=" +
                  roleId +
                  '&profileType=Custom',
              //'&userId=&profileType=Custom&viewType=enduser&isunder13=false',
              "get");
        }

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("getAllAccomplishment++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS].toString() ==
                "Success") {
              Achievement.callingType = "";
              List<AccomplimentData> narrativeList = List();
              //_mAcoomplismentDataModel =   AcoomplismentDataModel.fromJson(response.data);
              AcoomplismentDataModel _mAcoomplismentDataModelAll =
                  AcoomplismentDataModel.fromJson(response.data, "");
              narrativeListLocalAll
                  .addAll(_mAcoomplismentDataModelAll.accomplimentData);

              setState(() {
                narrativeListLocalAll;
                //narrativeList.addAll(_mAcoomplismentDataModel.accomplimentData);
                if (_mPublicProfileDataModel != null &&
                    _mPublicProfileDataModel.result != null &&
                    _mPublicProfileDataModel.result.isAccomplishment &&
                    narrativeListLocalAll.length > 0) {
                  isShowChart = true;
                  timeFrameSpider = mainSlideDuration;
                  timeFrameBarGraph = mainSlideDuration;
                  print(
                      'inside getAllAccomplishmenttime timeFrameSpider:: $timeFrameSpider');
                } else {
                  timeFrameSpider = 0;
                  timeFrameBarGraph = 0;
                }
                isShowChart = true;
                timeFrameSpider = mainSlideDuration;
                timeFrameBarGraph = mainSlideDuration;
                print(
                    'getAllAccomplishment inside setDataForWorldCloud narrativeListLocal size:: ${narrativeListLocal.length}');
                print(
                    'getAllAccomplishment inside setDataForWorldCloud narrativeList size:: ${narrativeList.length}');

                setDataForWorldCloud();
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

      e.toString();
      print("getAccomplishment++++" + e.toString());
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    if (widget.studentProfile != null) {
      userIdPref = widget.studentProfile.userId;
      roleId = widget.studentProfile.roleId;
    } else {
      userIdPref = prefs.getString(UserPreference.USER_ID);
      roleId = prefs.getString(UserPreference.ROLE_ID);
    }
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    if (widget.pageName == 'preview')
      viewType = 'preview';
    else
      viewType = 'enduser';
    print("initstate 222 ++++");

    await getProfileDetail(false);
    initpresodata();
  }

  void initpresodata() {
    print("initstate 666++++");
    //calculateTotalNavigationTime();
    timerScheduleForNavigation(timeFrameFirst);
    timerScheduleForActionControl();
    //getSharedPreferences();
    initBgCircleAnim();
    //initThankYouPageAnim();

    //_profilePictureController = AnimationController(vsync: this, duration: Duration(seconds: 3));

    _profilePictureControllerGone =
        AnimationController(vsync: this, duration: Duration(seconds: 3));

    _frame2ProfilePictureController =
        AnimationController(vsync: this, duration: Duration(seconds: 3));

    _bottomNavController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 0));

    _topNavController =
        AnimationController(vsync: this, duration: Duration(milliseconds: 700));

    /*_frame2BodyController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 2000));*/

    _thankYouTextBodyController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 2000));

    bottomNavOffset = Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
        .animate(_bottomNavController);

    topNavOffset = Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
        .animate(_topNavController);

    /*frame2BodyOffset = Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
        .animate(_frame2BodyController);*/

    /*_spiderChartTextBodyController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 2000));

    spiderChartTextBodyOffset =
        Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
            .animate(_spiderChartTextBodyController);

    spideChartAnimationController = AnimationController(
        duration: Duration(milliseconds: 3000), vsync: this);*/

    /*_animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
      parent: _profilePictureController,
      curve: Curves.fastOutSlowIn,
    ));*/

    _profilePictureController.forward();
    //_profileVideoController.forward();
    _frame2BodyController.forward();
    spideChartAnimationController.forward();
    //_spiderChartTextBodyController.forward();
    _thankYouTextBodyController.forward();
    //thankYouAnimcontroller.forward();
    _topNavController.forward();

    _bottomNavController.forward();

    // Animate the Profile Information
    Timer _timer = Timer(const Duration(milliseconds: 2500), () {
      setState(() {
        visible = true;
      });
    });

    /*// Spider Chart Animation Initilization

    spiderChartAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: spideChartAnimationController,
        curve: Interval(
          0,
          0.5,
          curve: Curves.decelerate,
        ),
      ),
    );*/

    pageController = PageController(
        initialPage: 0, viewportFraction: viewPortFraction, keepPage: false);

    collegePageController = PageController(
        initialPage: 0, viewportFraction: viewPortFractionClg, keepPage: false);

    /*setState(() {
      narrativeListLocal;
    });

    print("wid get.achievement" + narrativeListLocal.length.toString());*/
  }

  void initController() {
    controllerTopCenter =
        ConfettiController(duration: const Duration(seconds: 2));
  }

  @override
  void initState() {
    super.initState();
    AutoOrientation.landscapeAutoMode();
    initController();
    print("initstate 111 ++++");
    uploadMedia = UploadMedia(context);
    _profilePictureController =
        AnimationController(vsync: this, duration: Duration(seconds: 3));

    _profileVideoController =
        AnimationController(vsync: this, duration: Duration(seconds: 3));

    _animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
      parent: _profilePictureController,
      curve: Curves.fastOutSlowIn,
    ));

    _frame2BodyController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 2000));
    frame2BodyOffset = Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
        .animate(_frame2BodyController);

    _spiderChartTextBodyController = AnimationController(
        vsync: this, duration: Duration(milliseconds: 2000));

    spiderChartTextBodyOffset =
        Tween<Offset>(begin: Offset.zero, end: Offset(0.0, 1.0))
            .animate(_spiderChartTextBodyController);

    spideChartAnimationController = AnimationController(
        duration: Duration(milliseconds: 3000), vsync: this);

    // Spider Chart Animation Initilization
    _spiderChartTextBodyController.forward();

    spiderChartAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: spideChartAnimationController,
        curve: Interval(
          0,
          0.5,
          curve: Curves.decelerate,
        ),
      ),
    );
    initThankYouPageAnim();
    getSharedPreferences();
  }

  Widget _errorn(String placeHolderImage, double width, double height) {
    return SizedBox(
      width: width,
      height: height,
      child: Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  //---------- presoview methods start----------------------------
  @override
  Widget build(BuildContext context) {
    // Get Profile Picture View

    final double width = MediaQuery.of(context).size.width;

    print(width);

    var profilePictureView = AnimatedBuilder(
        animation:
            /*frameNo == 1
            ? _frame2ProfilePictureController
            : frameNo == 2 || frameNo == 3
            ? _profilePictureControllerGone
            : */
            _profilePictureController,
        builder: (BuildContext context, Widget child) {
          return isBackPressed
              ? /*new Container(
            height: imageHeight,
            width: imageWidth,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(100),
              child: FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/profile/user_on_user.png',
                image: _mPublicProfileDataModel.result != null
                    ? Constant.IMAGE_PATH_SMALL +
                    ParseJson.getMediumImage(_mPublicProfileDataModel
                        .result.profilePicture)
                    : "",
              ),
            ),
          )*/
              Container(
                  height: imageHeight,
                  width: imageWidth,
                  //color: Colors.redAccent,
                  child: Card(
                    elevation: 4,
                    clipBehavior: Clip.antiAlias,
                    //color: Colors.transparent,
                    shape: CircleBorder(
                        side: BorderSide(color: Colors.transparent, width: 5)),
                    child: FadeInImage.assetNetwork(
                      height: imageHeight,
                      width: imageWidth,
                      fit: BoxFit.cover,
                      //placeholder: 'assets/profile/user_on_user.png',
                      placeholder: '',
                      image: _mPublicProfileDataModel.result != null
                          ? Constant.IMAGE_PATH_SMALL +
                              ParseJson.getMediumImage(_mPublicProfileDataModel
                                  .result.profilePicture)
                          : "",
                    ),
                  ),
                )
              : Transform(
                  transform: Matrix4.translationValues(
                      _animation.value * width, 0.0, 0.0),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(
                        0.0, 0.0, frameNo == 1 ? 100.0 : 0.0, 0.0),
                    child:
                        /*new Container(
                    height: imageHeight,
                    width: imageWidth,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(100),
                      child: FadeInImage.assetNetwork(
                        fit: BoxFit.cover,
                        placeholder: 'assets/profile/user_on_user.png',
                        image: _mPublicProfileDataModel.result != null
                            ? Constant.IMAGE_PATH_SMALL +
                            ParseJson.getMediumImage(
                                _mPublicProfileDataModel
                                    .result.profilePicture)
                            : "",
                      ),
                    ),
                  )
                  */
                        Container(
                      height: imageHeight,
                      width: imageWidth,
                      //color: Colors.redAccent,
                      child: Card(
                        elevation: 4,
                        clipBehavior: Clip.antiAlias,
                        //color: Colors.transparent,
                        shape: CircleBorder(
                            side: BorderSide(
                                color: Colors.transparent, width: 5)),
                        child: FadeInImage.assetNetwork(
                          height: imageHeight,
                          width: imageWidth,
                          fit: BoxFit.cover,
                          //placeholder: 'assets/profile/user_on_user.png',
                          placeholder: '',
                          image: _mPublicProfileDataModel.result != null
                              ? Constant.IMAGE_PATH_SMALL +
                                  ParseJson.getMediumImage(
                                      _mPublicProfileDataModel
                                          .result.profilePicture)
                              : "",
                        ),
                      ),
                    ),
                  ));
        });

    var profileIntroView = AnimatedBuilder(
        animation: _profileVideoController,
        builder: (BuildContext context, Widget child) {
          return Transform(
              transform:
                  Matrix4.translationValues(_animation.value * width, 0.0, 0.0),
              child: Container(
                padding: const EdgeInsets.only(left: 76.0),
                child: Container(
                  //color: Colors.redAccent,
                  height: 210,
                  width: 229,
                  child: Stack(
                    children: <Widget>[
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Padding(
                          padding: const EdgeInsets.all(0.0),
                          child: Container(
                            height: 210,
                            width: 194,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                    'assets/preso_view_new/video_frame.png'),
                                fit: BoxFit.fill,
                              ),
                            ),
                            child: _mPublicProfileDataModel
                                            .result.introVideo.thumbnailUrl !=
                                        null &&
                                    _mPublicProfileDataModel
                                            .result.introVideo.thumbnailUrl !=
                                        '' &&
                                    _mPublicProfileDataModel
                                            .result.introVideo.thumbnailUrl !=
                                        "null"
                                ? Center(
                                    child: _mPublicProfileDataModel
                                                .result.introVideo.thumbnailUrl
                                                .toLowerCase()
                                                .contains("http") ||
                                            _mPublicProfileDataModel
                                                .result.introVideo.thumbnailUrl
                                                .toLowerCase()
                                                .contains("www.")
                                        ? Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                17.0, 0.0, 0.0, 0.0),
                                            child: Container(
                                              height: 177,
                                              width: 177,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(100),
                                                child: FadeInImage.assetNetwork(
                                                  fit: BoxFit.cover,
                                                  placeholder:
                                                      'assets/profile/user_on_user.png',
                                                  image: _mPublicProfileDataModel
                                                                  .result !=
                                                              null &&
                                                          _mPublicProfileDataModel
                                                                  .result
                                                                  .introVideo !=
                                                              null
                                                      ? _mPublicProfileDataModel
                                                          .result
                                                          .introVideo
                                                          .thumbnailUrl
                                                      : "",
                                                ),
                                              ),
                                            ))
                                        : Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                17.0, 0.0, 0.0, 0.0),
                                            child: Container(
                                              height: 177,
                                              width: 177,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(100),
                                                child: FadeInImage.assetNetwork(
                                                  fit: BoxFit.cover,
                                                  placeholder:
                                                      'assets/profile/user_on_user.png',
                                                  image: _mPublicProfileDataModel
                                                                  .result !=
                                                              null &&
                                                          _mPublicProfileDataModel
                                                                  .result
                                                                  .introVideo !=
                                                              null
                                                      ? Constant.IMAGE_PATH +
                                                          _mPublicProfileDataModel
                                                              .result
                                                              .introVideo
                                                              .thumbnailUrl
                                                      : "",
                                                ),
                                              ),
                                            )),
                                  )
                                : Container(
                  height: imageHeight,
                  width: imageWidth,
                  //color: Colors.redAccent,
                  child: Card(
                    elevation: 4,
                    clipBehavior: Clip.antiAlias,
                    //color: Colors.transparent,
                    shape: CircleBorder(
                        side: BorderSide(color: Colors.transparent, width: 5)),
                    child: FadeInImage.assetNetwork(
                      height: imageHeight,
                      width: imageWidth,
                      fit: BoxFit.cover,
                      //placeholder: 'assets/profile/user_on_user.png',
                      placeholder: '',
                      image: _mPublicProfileDataModel.result != null
                          ? Constant.IMAGE_PATH_SMALL +
                              ParseJson.getMediumImage(_mPublicProfileDataModel
                                  .result.profilePicture)
                          : "",
                    ),
                  ),
                ),
                          ),
                        ),
                      ),
                      Positioned(
                        left: 159,
                        top: 70,
                        child: InkWell(
                          onTap: () {
                            if (_mPublicProfileDataModel
                                        .result.introVideo.videoUrl !=
                                    null ||
                                _mPublicProfileDataModel
                                        .result.introVideo.videoUrl !=
                                    '') {
                              if (_mPublicProfileDataModel
                                      .result.introVideo.videoUrl
                                      .toLowerCase()
                                      .contains("http") ||
                                  _mPublicProfileDataModel
                                      .result.introVideo.videoUrl
                                      .toLowerCase()
                                      .contains("www.")) {
                                //for url launcher
                                if (_mPublicProfileDataModel
                                    .result.introVideo.videoUrl
                                    .toLowerCase()
                                    .contains("http")) {
                                  launch(_mPublicProfileDataModel
                                      .result.introVideo.videoUrl);
                                } else {
                                  String url = "http://" +
                                      _mPublicProfileDataModel
                                          .result.introVideo.videoUrl;
                                  launch(url);
                                }
                              } else {
                                //for video player navigation
                                Navigator.of(context).push(new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        VideoFullViewWidget(
                                            '',
                                            MessageConstant
                                                .VIEWER_END_REWCOMMENDATION_HEDING,
                                            '${_mPublicProfileDataModel.result.introVideo.videoUrl}')));
                              }
                            }
                          },
                          child: Image.asset(
                            'assets/preso_view_new/img_play.png',
                            width: 70,
                            height: 70,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ));
        });

    var profileTextInfo = Padding(
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 30.0, 0.0),
        child: AnimatedOpacity(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              //   Text(
              //   //"Hello, I am",
              //   "Hello I’m",
              //   textAlign: TextAlign.left,
              //   style: TextStyle(
              //       fontFamily: Constant.customRegular,
              //       color: ColorValues.HEADING_COLOR_EDUCATION,
              //       fontSize: 28.0),
              // ),
              Padding(
                padding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 7.0),
                child: _mPublicProfileDataModel != null
                    ? Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Flexible(
                              //flex: getLenthOfName() > 15?1:0,
                              //flex: 0,
                              child: Text(
                            _mPublicProfileDataModel.result == null
                                ? ""
                                : _mPublicProfileDataModel.result.lastName ==
                                            "" ||
                                        _mPublicProfileDataModel
                                                .result.lastName ==
                                            "null"
                                    ? _mPublicProfileDataModel.result.firstName
                                    : _mPublicProfileDataModel
                                            .result.firstName +
                                        " " +
                                        _mPublicProfileDataModel
                                            .result.lastName,
                            textAlign: TextAlign.left,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontFamily: Constant.customRegular,
                                fontWeight: FontWeight.w700,
                                color: ColorValues.WHITE,
                                fontSize: 48.0),
                          )),
                          /*_mPublicProfileDataModel.result.roleId == "1"
                  //true
                      ? Util.getStudentBadgeProfile(_mPublicProfileDataModel.result.badge,_mPublicProfileDataModel.result.badgeImage):Container(),*/

                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              10.0,
                              0.0,
                              Util.getStudentBadgeProfile(
                                  _mPublicProfileDataModel.result.badge,
                                  _mPublicProfileDataModel.result.badgeImage)),
                        ],
                      )
                    : Container(),
              ),
              _mPublicProfileDataModel != null
                  ?  PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,Text(
                      _mPublicProfileDataModel.result == null
                          ? ""
                          : _mPublicProfileDataModel.result.tagline == null ||
                                  _mPublicProfileDataModel.result.tagline ==
                                      "null"
                              ? ""
                              : _mPublicProfileDataModel.result.tagline,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          fontFamily: Constant.customRegular,
                          color: ColorValues.pressotitle,
                          fontWeight: FontWeight.w400,
                          fontSize: 20.0),
                    ))
                  : Container(),
            ],
          ),
          duration: Duration(seconds: 1),
          opacity: visible ? 1.0 : 0.0,
        ));

    AnimatedOpacity getHeader(String title) {
      double textSize = 100;
      if (title.length > 11)
        textSize = 85;
      else
        textSize = 95;
      return AnimatedOpacity(
        child: Text(
          title,
          textAlign: TextAlign.left,
          style: TextStyle(
              fontSize: textSize,
              color: frameNo == 2 || frameNo == 3
                  ? ColorValues.WHITE.withOpacity(0.18)
                  : ColorValues.GRAY_HEADER_PRESSO_VIEW.withOpacity(0.34),
              fontFamily: Constant.customRegular),
        ),
        duration: Duration(seconds: 1),
        opacity: frameNo == 1 ||
                frameNo == 4 ||
                frameNo == 5 ||
                frameNo == 7 ||
                frameNo == 2 ||
                frameNo == 3
            ? 1.0
            : 1.0,
      );
    }

    AnimatedOpacity getHeaderTitle(String title, Color presoHeading) {
      double textSize = 36;

      return AnimatedOpacity(
        child: Text(
          title,
          textAlign: TextAlign.left,
          style: TextStyle(
              fontSize: textSize,
              color: presoHeading,
              fontWeight: FontWeight.bold,
              fontFamily: Constant.customRegular),
        ),
        duration: Duration(seconds: 1),
        opacity: frameNo == 1 ||
                frameNo == 4 ||
                frameNo == 5 ||
                frameNo == 7 ||
                frameNo == 2 ||
                frameNo == 3
            ? 1.0
            : 1.0,
      );
    }

    AnimatedOpacity getHeaderNew(String title) {
      double textSize = 250;
      // if (title.length > 11)
      //   textSize = 85;
      // else
      //   textSize = 95;
      return AnimatedOpacity(
        child: Text(
          title,
          textAlign: TextAlign.left,
          style: TextStyle(
              fontSize: textSize,
              color: frameNo == 2 || frameNo == 3
                  ? ColorValues.WHITE.withOpacity(0.18)
                  : ColorValues.GRAY_HEADER_PRESSO_VIEW.withOpacity(0.34),
              fontFamily: Constant.customRegular),
        ),
        duration: Duration(seconds: 1),
        opacity: frameNo == 1 ||
                frameNo == 4 ||
                frameNo == 5 ||
                frameNo == 7 ||
                frameNo == 2 ||
                frameNo == 3
            ? 1.0
            : 1.0,
      );
    }

    var fram2BodyText = _mPublicProfileDataModel != null
        ? Container(
            child: SlideTransition(
            position: frame2BodyOffset,
            child: Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                child: Scrollbar(
                  controller: _scrollSummaryController,
                  // <---- Here, the controller
                  isAlwaysShown: true,
                  child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      controller: _scrollSummaryController,
                      child: Text(
                        _mPublicProfileDataModel.result != null ||
                                _mPublicProfileDataModel.result != "null"
                            ? _mPublicProfileDataModel.result.summary == null ||
                                    _mPublicProfileDataModel.result.summary ==
                                        "null"
                                ? ""
                                : _mPublicProfileDataModel.result.summary
                            : "",
                        textAlign: TextAlign.left,
                        maxLines: null,
                        style: TextStyle(
                            fontFamily: Constant.customRegular,
                            fontSize: 14.0,
                            fontWeight: FontWeight.bold,
                            color: ColorValues.black),
                      )),
                )),
          ))
        : Container(
            width: 0,
            height: 0,
          );

    var spiderChartView = ScaleTransition(
      scale: spiderChartAnimation,
      child: spiderChartList.length > 0
          ? Padding(
              padding: EdgeInsets.only(top: 10.0),
              child: spiderChartList.length == 0
                  ? Container(
                      padding: EdgeInsets.all(0.0),
                      height: 300.0,
                      width: double.infinity,
                      child: Container(
                          child: Stack(
                        children: <Widget>[
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Image.asset("assets/radar.png",
                                  width: double.infinity, height: 221),
                            ],
                          ),
                        ],
                      )))
                  : Container(
                      width: 500,
                      height: 500,
                      //Radar Chart
                      child: RadarChart(
                        values: spiderChartList,
                        labels: spiderChartName,
                        maxWidth: 500,
                        maxLinesForLabels: 5,
                        labelWidth: 80,
                        strokeColor: ColorValues.GREY__COLOR,
                        maxValue: 9,
                        animate: false,
                        textScaleFactor: 0.035,
                        size: Size.infinite,
                        fillColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                        chartRadiusFactor: 0.6,
                        labelColor: Colors.black,
                      ),
                    ))
          : Container(
              height: 0.0,
            ),
    );

    Align buildConfettiWidget(
        ConfettiController controller, double blastDirection) {
      return Align(
        alignment: Alignment.topCenter,
        child: ConfettiWidget(
          minimumSize: Size(4, 4),
          maximumSize: Size(16, 6),

          shouldLoop: false,
          confettiController: controller,
          particleDrag: 0.05,
          blastDirection: blastDirection,
          blastDirectionality: BlastDirectionality.directional,
          maxBlastForce: 20,
          // set a lower max blast force
          minBlastForce: 8,
          // set a lower min blast force
          emissionFrequency: 0.05,
          numberOfParticles: 25,
          // a lot of particles at once
          gravity: 0.05,
          colors: [
            ColorValues.confetti1,
            ColorValues.confetti2,
            ColorValues.confetti3,
            ColorValues.confetti4,
            ColorValues.confetti5,
            ColorValues.confetti6,
            ColorValues.confetti7,
          ],
        ),
      );
    }

    Widget thankYouPage() {
      //   Timer(const Duration(milliseconds: 400), () {
      //     print("SSS timer call");
      //   controllerTopCenter.stop();
      // });
      return Padding(
          padding: EdgeInsets.fromLTRB(00.0, 0.0, 20.0, 20.0),
          child: ListView(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            children: <Widget>[
              Center(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Padding(
                          padding: EdgeInsets.only(top: 0.0),
                          child: Text(
                            "Thanks for watching",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontFamily: Constant.customRegular,
                                fontWeight: FontWeight.w800,
                                color: ColorValues.WHITE,
                                fontSize: 37.0),
                          )),
                      Padding(
                          padding:
                              EdgeInsets.only(top: 0.0, right: 100, left: 100),
                          child: Text(
                            "To access external links included in the experiences, please review the linear view of the profile.",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontFamily: Constant.customRegular,
                                fontWeight: FontWeight.w500,
                                color: ColorValues.WHITE,
                                fontSize: 18.0),
                          )),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            onTap: () {
                              //code for getting url in linear view
                              //if (widget.pageName != 'preview') {
                              onTapLinearView(false);
                              //}
                            },
                            child: Padding(
                                padding: EdgeInsets.only(top: 20.0, bottom: 20),
                                child: Container(
                                  decoration: BoxDecoration(
                                    //  border: Border.all(color: Colors.white),
                                    color: ColorValues.MY_MSG_BORDER_COLOR,
                                  ),
                                  width: 170,
                                  height: 40.0,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 13.0),
                                    child: Row(
                                      children: <Widget>[
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              8.0, 0.0, 8.0, 0.0),
                                          child: Image.asset(
                                              'assets/preso_view_new/linear_view_img.png',
                                              width: 22.0,
                                              height: 22.0),
                                        ),
                                        Padding(
                                            padding: EdgeInsets.only(left: 0.0),
                                            child: Text(
                                              "Linear View",
                                              style: TextStyle(
                                                  fontFamily:
                                                      Constant.customRegular,
                                                  fontSize: 16,
                                                  color: Colors.white),
                                            )),
                                        // Container(
                                        //   width: 1.0,
                                        //   height: 40.0,
                                        //   color: Colors.white,
                                        // ),
                                      ],
                                    ),
                                  ),
                                )),
                          ),
                          _mPublicProfileDataModel != null &&
                                  _mPublicProfileDataModel.result != null &&
                                  _mPublicProfileDataModel.result.resume !=
                                      null &&
                                  _mPublicProfileDataModel
                                          .result.resume.displayName !=
                                      "null" &&
                                  _mPublicProfileDataModel
                                          .result.resume.displayName !=
                                      "" &&
                                  _mPublicProfileDataModel.result.isResume
                              ? Padding(
                                  padding: const EdgeInsets.only(left: 15.0),
                                  child: InkWell(
                                    onTap: () {
                                      //if (widget.pageName != 'preview') {
                                      onTapLinearView(true);
                                      //}
                                    },
                                    child: Padding(
                                        padding: EdgeInsets.only(
                                            top: 20.0, bottom: 20),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            // border:
                                            //     Border.all(color: Colors.white),
                                            color: ColorValues.light_green_new,
                                          ),
                                          width: 178,
                                          height: 40.0,
                                          child: Padding(
                                            padding:
                                                EdgeInsets.only(left: 13.0),
                                            child: Row(
                                              children: <Widget>[
                                                Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      8.0, 0.0, 8.0, 0.0),
                                                  child: Image.asset(
                                                      'assets/add_resume.png',
                                                      width: 22.0,
                                                      height: 22.0),
                                                ),
                                                Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 0.0),
                                                    child: Text(
                                                      "View Resume",
                                                      style: TextStyle(
                                                          fontFamily: Constant
                                                              .customRegular,
                                                          fontSize: 16,
                                                          color: Colors.white),
                                                    )),
                                              ],
                                            ),
                                          ),
                                        )),
                                  ),
                                )
                              : new Container(height: 0.0),
                        ],
                      ),
                      _mPublicProfileDataModel == null ||
                              _mPublicProfileDataModel.result == null ||
                              _mPublicProfileDataModel.result.socialLinks ==
                                  null ||
                              _mPublicProfileDataModel
                                      .result.socialLinks.length ==
                                  0 ||
                              !_mPublicProfileDataModel.result.isSocialLinks
                          ? Container(
                              height: 0.0,
                            )
                          : Padding(
                              padding: const EdgeInsets.fromLTRB(17, 0, 17, 0),
                              child: Column(
                                children: <Widget>[
                                  Padding(
                                      padding: EdgeInsets.only(
                                          top: 4.0, bottom: 15.0),
                                      child: Text(
                                        "My social links:",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontWeight: FontWeight.w400,
                                            color: ColorValues.BLUE_COLOR,
                                            fontSize: 14.0),
                                      )),
                                  Container(
                                    height: 40.0,
                                    child: ListView(
                                        scrollDirection: Axis.horizontal,
                                        shrinkWrap: true,
                                        children: List.generate(
                                            _mPublicProfileDataModel
                                                .result
                                                .socialLinks
                                                .length, (int index) {
                                          return !_mPublicProfileDataModel
                                                  .result
                                                  .socialLinks[index]
                                                  .isProfileDisplay
                                              ? Container(
                                                  height: 0.0,
                                                )
                                              : Padding(
                                                  padding:
                                                      const EdgeInsets.fromLTRB(
                                                          2.0, 0, 0, 0),
                                                  child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              4.0),
                                                      child: InkWell(
                                                          onTap: () {
                                                            if (_mPublicProfileDataModel
                                                                .result
                                                                .socialLinks[
                                                                    index]
                                                                .socialUrl
                                                                .toLowerCase()
                                                                .contains(
                                                                    "http")) {
                                                              launch(_mPublicProfileDataModel
                                                                  .result
                                                                  .socialLinks[
                                                                      index]
                                                                  .socialUrl);
                                                            } else {
                                                              String url = "http://" +
                                                                  _mPublicProfileDataModel
                                                                      .result
                                                                      .socialLinks[
                                                                          index]
                                                                      .socialUrl;
                                                              launch(url);
                                                            }
                                                          },
                                                          child: ClipOval(
                                                              child: Container(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                              fit: BoxFit.fill,
                                                              placeholder:
                                                                  'assets/profile/img_default.png',
                                                              image: _mPublicProfileDataModel
                                                                              .result
                                                                              .socialLinks[
                                                                                  index]
                                                                              .image ==
                                                                          "" ||
                                                                      _mPublicProfileDataModel
                                                                              .result
                                                                              .socialLinks[
                                                                                  index]
                                                                              .image ==
                                                                          "null"
                                                                  ? ""
                                                                  : Constant
                                                                          .IMAGE_PATH +
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .socialLinks[
                                                                              index]
                                                                          .image,
                                                            ),
                                                          )))));
                                        })),
                                  ),
                                ],
                              ),
                            )
                    ],
                  ),
                ),
              ),
            ],
          ));
    }

    var educationListView = Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/preso_view_new/light_bg_presso.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 250,
              height: double.infinity,
              decoration: BoxDecoration(
                color: ColorValues.presoBgColor.withOpacity(0.9),
                image: DecorationImage(
                  image: AssetImage(
                    "assets/preso_view_new/education_img.png",
                  ),
                  fit: BoxFit.fill,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 20.0, 0, 0),
                child: Text(
                  "Education",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.w700,
                      fontFamily: Constant.customRegular,
                      color: ColorValues.WHITE),
                ),
              ),
            ),
            SizedBox(
              width: 40,
            ),
            Expanded(
              flex: 1,
              child: ListView.separated(
                itemBuilder: (context, index) {
                  var schoolInfoListNew = schoolsInfoList.reversed.toList();
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          OutlinedButton(
                            onPressed: () {},
                            style: OutlinedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              backgroundColor: ColorValues.pressotitle,
                              side: BorderSide(
                                  width: 1.0, color: ColorValues.pressotitle),
                              minimumSize: Size(70, 25),
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            child: Text(
                                schoolInfoListNew.length > 0
                                    ? schoolInfoListNew[index].fromYear +
                                        " - " +
                                        (schoolInfoListNew[index].toYear ==
                                                    "null" ||
                                                schoolInfoListNew[index]
                                                        .toYear ==
                                                    ""
                                            ? "Ongoing"
                                            : schoolInfoListNew[index]
                                                .toYear
                                                .substring(
                                                    schoolInfoListNew[index]
                                                            .toYear
                                                            .length -
                                                        2))
                                    : "",
                                style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  color: ColorValues.WHITE,
                                )),
                          ),
                          const SizedBox(height: 2),
                          Text(
                              index == 0
                                  ? "Primary"
                                  : index == 1
                                      ? "Middle"
                                      : "High",
                              style: TextStyle(
                                fontSize: 12.0,
                                fontWeight: FontWeight.w400,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                color: ColorValues.pressotitle,
                              )),
                          const SizedBox(height: 2),
                          SizedBox(
                              height: 60,
                              child: VerticalDivider(
                                color: ColorValues.pressotitle,
                                thickness: 1,
                              ),
                          )
                        ],
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              schoolInfoListNew.length > 0
                                  ? schoolInfoListNew[index].institute
                                  : "",
                              textAlign: TextAlign.start,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  height: 1.5,
                                  fontFamily: Constant.customRegular,
                                  color: ColorValues.presoHeading),
                            ),
                            schoolInfoListNew[index].city != null &&
                                    schoolInfoListNew[index].city != "null"
                                &&
                                schoolInfoListNew[index].city != ""
                                ? Text(
                                    schoolInfoListNew[index].city != null &&
                                            schoolInfoListNew[index].city !=
                                                "null"
                                        ? schoolInfoListNew[index].city
                                        : "",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: Constant.customRegular,
                                        height: 1.4,
                                        color: Colors.black),
                                  )
                                : const SizedBox.shrink(),
                            Text(
                              schoolInfoListNew.length > 0
                                  ? schoolInfoListNew[index].fromGrade +
                                      " - " +
                                      schoolInfoListNew[index].toGrade
                                  : "",
                              textAlign: TextAlign.start,
                               maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: Constant.customRegular,
                                  height: 1.4,
                                  color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
                shrinkWrap: true,
                itemCount: schoolsInfoList.length,
                padding:  EdgeInsets.zero,
                separatorBuilder: ( context,  index) => SizedBox(height: 4),
              ),
            ),
          ],
        ));

    var educationListCollegeView = Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/preso_view_new/light_bg_presso.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 250,
              height: double.infinity,
              decoration: BoxDecoration(
                color: ColorValues.presoBgColor.withOpacity(0.9),
                image: DecorationImage(
                  image: AssetImage(
                    "assets/preso_view_new/education_img.png",
                  ),
                  fit: BoxFit.fill,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 20.0, 0, 0),
                child: Text(
                  "Education",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.w700,
                      fontFamily: Constant.customRegular,
                      color: ColorValues.WHITE),
                ),
              ),
            ),
            SizedBox(
              width: 40,
            ),
            Expanded(
              flex: 1,
              child: ListView.builder(
                itemBuilder: (context, index) {
                  var collegesInfoListNew = collegesInfoList.reversed.toList();
                  return Container(
                    height: 130,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            SizedBox(
                              height: 10,
                            ),
                            OutlinedButton(
                              onPressed: () {},
                              style: OutlinedButton.styleFrom(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                backgroundColor: ColorValues.pressotitle,
                                side: BorderSide(
                                    width: 1.0, color: ColorValues.pressotitle),
                                minimumSize: Size(70, 25),
                              ),
                              child: Text(
                                  collegesInfoListNew.length > 0
                                      ? collegesInfoListNew[index].fromYear +
                                          " - " +
                                          (collegesInfoListNew[index].toYear ==
                                                      "null" ||
                                                  collegesInfoListNew[index]
                                                          .toYear ==
                                                      ""
                                              ? "Ongoing"
                                              : collegesInfoListNew[index]
                                                  .toYear
                                                  .substring(
                                                      collegesInfoListNew[index]
                                                              .toYear
                                                              .length -
                                                          2))
                                      : "",
                                  style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    color: ColorValues.WHITE,
                                  )),
                            ),
                            // Text(
                            //     index == 0
                            //         ? "Primary"
                            //         : index == 1
                            //             ? "Middle"
                            //             : "High",
                            //     style: TextStyle(
                            //       fontSize: 12.0,
                            //       fontWeight: FontWeight.w400,
                            //       fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            //       color: ColorValues.pressotitle,
                            //     )),
                            SizedBox(
                                height: 70,
                                child: VerticalDivider(
                                  color: ColorValues.pressotitle,
                                  thickness: 1,
                                ))
                          ],
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: Container(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 20,
                                ),
                                Text(
                                  collegesInfoListNew.length > 0
                                      ? collegesInfoListNew[index].institute
                                      : "",
                                  textAlign: TextAlign.start,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: Constant.customRegular,
                                      color: ColorValues.presoHeading),
                                ),
                                collegesInfoListNew[index].city != Null &&
                                        collegesInfoListNew[index].city !=
                                            "null"
                                    ? Text(
                                        collegesInfoListNew[index].city !=
                                                    Null &&
                                                collegesInfoListNew[index]
                                                        .city !=
                                                    "null"
                                            ? collegesInfoListNew[index].city
                                            : "",
                                        textAlign: TextAlign.start,
                                          maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: Constant.customRegular,
                                            color: Colors.black),
                                      )
                                    : Container(height: 0),
                                Text(
                                  collegesInfoListNew.length > 0
                                      ? collegesInfoListNew[index].degree
                                      // +
                                      //     " - " +
                                      //     schoolInfoListNew[index].toGrade
                                      : "",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: Constant.customRegular,
                                      color: Colors.black),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
                shrinkWrap: true,
                itemCount: collegesInfoList.length,
              ),
            ),
          ],
        ));

    barList(int listnumber) {
      List<SkillDataChart> barListModelnew = List();
      if (listnumber == 1) {
        print("sss length ${barListModel.length}");
        barListModelnew = barListModel.sublist(0, barListModel.length ~/ 2);
      } else {
        barListModelnew = barListModel.sublist(barListModel.length ~/ 2);
      }
      return SingleChildScrollView(
        child: Container(
            //   color: Colors.white,
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(barListModelnew.length, (int index) {
            return Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(left: 15),
                    child: Text(
                      barListModelnew[index].name,
                      style: TextStyle(
                          fontSize: 14,
                          color: Colors.white,
                          fontWeight: FontWeight.w400),
                    ),
                  ),
                  Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0.0, 0, 20),
                      child: InkWell(
                        child: Padding(
                          padding: EdgeInsets.only(
                              top: 3,
                              //right: 0,
                              left: 5,
                              bottom:
                                  barListModelnew.length - 1 == index ? 10 : 0),
                          child: LinearPercentIndicator(
                            width: MediaQuery.of(context).size.width / (2.5),
                            animation: true,
                            backgroundColor: ColorValues.WHITE.withOpacity(0.2),
                            lineHeight: 5.0,
                            animationDuration: 100,
                            percent: barListModelnew[index].value,
                            linearStrokeCap: LinearStrokeCap.butt,
                            progressColor: barListModelnew[index].color,
                          ),
                        ),
                      )),
                ],
              ),
            );
          }),
        )),
      );
    }

    Widget getLoveInterestCircleView() {
      print("getworldCloudView;;;;;;;;;;; ");
      final screenSize = MediaQuery.of(context).size;
      final ratio = screenSize.width / screenSize.height;

      return loveInterestList.length > 0
          ? Center(
              child: FittedBox(
                child: Scatter(
                  fillGaps: true,
                  delegate: ArchimedeanSpiralScatterDelegate(ratio: ratio),
                  children: widgetsCircles,
                ),
              ),
            )
          : Container(
              width: 0,
              height: 0,
            );
    }

    String getConvertedDateStamppreso(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        var now = DateTime.fromMillisecondsSinceEpoch(millis);
        var formatter = DateFormat('MMM dd, yyyy');
        String formatted = formatter.format(now);
        return formatted;
      } else {
        //  strEnd = getConvertedDateStamp(new DateTime.now().millisecondsSinceEpoch.toString());
        var formatter = DateFormat('MMM dd, yyyy');
        //return formatter.format(new DateTime.now());
        return "Ongoing";
      }
    }

    Widget getViewBasedOnTheIndex(child) {
      //print("Child Info" + child);
      //print("Child frame no" + frameNo.toString());
      switch (frameNo) {
        case 0:
          return Container(
            color: ColorValues.presoBgColor.withOpacity(0.9),
            child: Stack(
              children: <Widget>[
                getHeader(""),
                Center(
                    child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    SizedBox(
                      width: 40.0,
                    ),
                    Expanded(
                      child: _mPublicProfileDataModel == null
                          ? Container()
                          : profilePictureView,
                      flex: 0,
                    ),
                    SizedBox(
                      width: 30.0,
                    ),
                    Expanded(
                        child: _mPublicProfileDataModel == null
                            ? Container()
                            : Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 30.0, 30.0, 0.0),
                                child: Container(
                                  padding:
                                      EdgeInsets.fromLTRB(12.0, 10.0, 0.0, 0.0),
                                  decoration: BoxDecoration(
                                    //color: Colors.white,
                                    borderRadius: BorderRadius.circular(11.0),
                                    image: DecorationImage(
                                      image: AssetImage(
                                          "assets/preso_view_new/preso_img_backgrnd.png"),
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  child: profileTextInfo,
                                )),
                        flex: 1),
                  ],
                )),
              ],
            ),
          );

          break;

        case 1:

          return isShowVideoSlide
              ? Container(
                  color: ColorValues.WHITE.withOpacity(0.9),
                  child: Stack(
                    children: <Widget>[
                      Positioned(top: 20, right: 300, child: getHeaderNew("“")),
                      Center(
                          child: Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Row(
                          // crossAxisAlignment: CrossAxisAlignment.center,
                          // mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(
                              width: 0.0,
                            ),
                            _mPublicProfileDataModel == null
                                ? Container()
                                : profileIntroView,
                            SizedBox(
                              width: 35, //22.0,
                            ),
                            _mPublicProfileDataModel.result.summary == null ||
                                    _mPublicProfileDataModel.result.summary ==
                                        "null"
                                ? Container()
                                : Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                          height: 0,
                                        ),
                                        Text(
                                          "Summary",
                                          textAlign: TextAlign.left,
                                          style: TextStyle(
                                              fontSize: 36,
                                              fontWeight: FontWeight.bold,
                                              color: ColorValues.presoHeading,
                                              fontFamily:
                                                  Constant.customRegular),
                                        ),
                                        SizedBox(
                                          height: 20,
                                        ),
                                        _mPublicProfileDataModel == null
                                            ? Container()
                                            : fram2BodyText,
                                      ],
                                    ),
                                    flex: 1),
                            SizedBox(
                              width: 76.0,
                            ),
                          ],
                        ),
                      )),
                    ],
                  ))
              : Container(
                  color: ColorValues.WHITE.withOpacity(0.9),
                  child: Stack(
                    children: <Widget>[
                      Positioned(top: 20, right: 300, child: getHeaderNew("“")),
                      Positioned(
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 20.0),
                          child: Row(
                            // crossAxisAlignment: CrossAxisAlignment.center,
                            // mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.all(0.0),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      10.0,
                                      0.0,
                                      Container(
                                        //color: Colors.blue,
                                        width: imageWidth + 40,
                                        child: Padding(
                                            padding: EdgeInsets.only(top: 0.0),
                                            child: AnimatedBuilder(
                                                animation: //frameNo == 1 ?
                                                    _frame2ProfilePictureController,
                                                builder: (BuildContext context,
                                                    Widget child) {
                                                  return Transform(
                                                    transform: Matrix4
                                                        .translationValues(
                                                            _animation.value *
                                                                300,
                                                            0.0,
                                                            0.0),
                                                    child: Stack(
                                                      children: [
                                                        Container(
                                                          height: imageHeight,
                                                          width: imageWidth,
                                                          decoration:
                                                              BoxDecoration(
                                                            image:
                                                                DecorationImage(
                                                              image: AssetImage(
                                                                "assets/preso_view_new/video_frame.png",
                                                              ),
                                                              fit: BoxFit.fill,
                                                            ),
                                                          ),
                                                          //color: Colors.redAccent,
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    10.0,
                                                                    20.0,
                                                                    10.0,
                                                                    20.0),
                                                            child: Card(
                                                              elevation: 4,
                                                              clipBehavior: Clip
                                                                  .antiAlias,
                                                              //color: Colors.transparent,
                                                              shape: CircleBorder(
                                                                  side: BorderSide(
                                                                      color: Colors
                                                                          .transparent,
                                                                      width:
                                                                          5)),
                                                              child: FadeInImage
                                                                  .assetNetwork(
                                                                height:
                                                                    imageHeight -
                                                                        50,
                                                                width:
                                                                    imageWidth -
                                                                        50,
                                                                fit:
                                                                    BoxFit.fill,
                                                                placeholder:
                                                                    'assets/profile/user_on_user.png',
                                                                image: _mPublicProfileDataModel
                                                                            .result !=
                                                                        null
                                                                    ? Constant
                                                                            .IMAGE_PATH_SMALL +
                                                                        ParseJson.getMediumImage(_mPublicProfileDataModel
                                                                            .result
                                                                            .profilePicture)
                                                                    : "",
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          right: 10.0,
                                                          top: 80.0,
                                                          child: SizedBox(
                                                              width: 70,
                                                              height: 70,
                                                              child: Image.asset(
                                                                  'assets/preso_view_new/img_play.png',
                                                                  fit: BoxFit.cover)),
                                                        )
                                                      ],
                                                    ),
                                                  );
                                                })),
                                      )),
                                ),
                              ),

                              SizedBox(
                                width: 80.0,
                              ),
                              _mPublicProfileDataModel.result.summary == null ||
                                      _mPublicProfileDataModel.result.summary ==
                                          "null"
                                  ? Container()
                                  : Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                         
                                          Text(
                                            "Summary",
                                            textAlign: TextAlign.left,
                                            style: TextStyle(
                                                fontSize: 36,
                                                fontWeight: FontWeight.bold,
                                                color: ColorValues.presoHeading,
                                                fontFamily:
                                                    Constant.customRegular),
                                          ),
                                          SizedBox(
                                            height: 20,
                                          ),
                                          _mPublicProfileDataModel == null
                                              ? Container()
                                              : fram2BodyText,
                                        ],
                                      ),
                                      flex: 1),
                              //   SizedBox(
                              //   width: 292.0,//300
                              // ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ));

          break;

        case 2: //spider chart
          // Second View Called with Animation
          //V2.0
          return Container(
              color: ColorValues.WHITE.withOpacity(0.9),
              child: Stack(
                children: <Widget>[
                  Positioned(
                      top: 20,
                      left: 20,
                      child:
                          getHeaderTitle("My Story", ColorValues.presoHeading)),
                  Row(
                    //  crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      //   SizedBox(width: 35.0),
                      Expanded(
                        flex: 0,
                        child: Container(
                          //color: Colors.green,
                          child: PaddingWrap.paddingfromLTRB(
                              35.0, 0.0, 0.0, 0.0, spiderChartView),
                        ),
                      ),
                    ],
                  )
                ],
              ));
          break;

        case 3: //bar graph
          // Second View Called with Animation
          //V2.0
          return Container(
              color: ColorValues.presoBgColor.withOpacity(0.9),
              child: Stack(
                children: <Widget>[
                  Positioned(
                      top: 20,
                      left: 20,
                      child: getHeaderTitle("My Story", ColorValues.WHITE)),
                  Center(
                      child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            20.0, 80.0, 0.0, 0.0, barList(1)),
                        flex: 0,
                      ),
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            20.0, 80.0, 0.0, 0.0, barList(2)),
                        flex: 0,
                      ),
                    ],
                  )),
                ],
              ));
          break;

        case 4: // for college ui

          _animateCollegeEducationCircle();
          return Stack(children: <Widget>[
            Positioned(
                top: 20,
                left: 20,
                child: getHeaderTitle("Education", ColorValues.WHITE)),
            Center(
                child: Padding(
              padding: EdgeInsets.only(top: 0.0),
              child: collegesInfoList != null && collegesInfoList.length > 0
                  ?

                  // pagerViewForCollegeEducation
                  educationListCollegeView
                  : Container(),
            ))
          ]);

          break;

        case 5: // for school ui

          // _animateEducationCircle();
          return Stack(children: <Widget>[
            Positioned(
                top: 20,
                left: 20,
                child: getHeaderTitle("Education", ColorValues.WHITE)),
            Center(
                child: Padding(
              padding: EdgeInsets.only(top: 0.0),
              child: schoolsInfoList != null && schoolsInfoList.length > 0
                  ? educationListView
                  //   pagerViewForEducation
                  //Container(child: Text('testing school'),)
                  : Container(),
            ))
          ]);

          break;

        case 6: //ui for test score
          return Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/preso_view_new/new_bg_presso.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Container(
                color: ColorValues.presoBgColor.withOpacity(0.9),
                child: Stack(children: <Widget>[
                  Positioned(
                      top: 20,
                      left: 30,
                      child: getHeaderTitle("Test Scores", ColorValues.WHITE)),
                  Padding(
                      padding: EdgeInsets.only(top: 80.0),
                      child: pagerViewForGridAutoScrollTestScore()),
                ]),
              ));
          break;

        case 7:
          // Maintain the Achievement List
          // V2.0

          print("Case 5 Called ${narrativeListLocal.length}");
          if (t != null) {
            print("Cancel t here");
            t.cancel();
          }

          _controller = PageController(initialPage: 0, keepPage: false);
          _executeFutureForSliding = true;

          setState(() {
            _controller;
          });

          _animateSlider(
              narrativeListLocal[narrativeCount]
                  .achievement[acheivementListCount]
                  .mediaList,
              "next");

          // Set Navigation Timer According to the Images
          if (narrativeListLocal[narrativeCount]
                  .achievement[acheivementListCount]
                  .mediaList
                  .length >
              2) {
            timerScheduleForNavigation(narrativeListLocal[narrativeCount]
                        .achievement[acheivementListCount]
                        .mediaList
                        .length *
                    imageSlideDuration +
                imageSlideDuration); // Automatic Navigate After all Image visited
          } else {
            timerScheduleForNavigation(timeFrameAchievement);
          }

          return InkWell(
            /*onTap: (){
              print('Apurva dabade case 7 clicked:: $isVideoClicked');
              setState(() {
                isVideoClicked = false;
                //isActionButtonShowing = true;
                //isPaused = true;
              });
              print('Apurva dabade case 777 clicked:: $isVideoClicked');
            },*/
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image:
                      AssetImage("assets/preso_view_new/light_bg_presso.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Stack(children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(top: 0.0), //70
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      // This makes the blue container full width.
                      Expanded(
                        child: Container(
                          child: SingleChildScrollView(
                            child: Center(
                              child: PaddingWrap.paddingfromLTRB(
                                  30.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Expanded(
                                              child: SafeArea(
                                                right: true,
                                                child: Scrollbar(
                                                  controller:
                                                      _scrollAccController,
                                                  // <---- Here, the controller
                                                  isAlwaysShown: true,

                                                  child: SingleChildScrollView(
                                                    scrollDirection:
                                                        Axis.vertical,
                                                    controller:
                                                        _scrollAccController,
                                                    child: Container(
                                                      margin: EdgeInsets.only(
                                                          top: 0.0),
                                                      child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        0.0,
                                                                        0.0,
                                                                        30.0,
                                                                        0.0),
                                                                child: getHeaderTitle(
                                                                    "Experience",
                                                                    ColorValues
                                                                        .presoHeading)),
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        0.0,
                                                                        30.0,
                                                                        30.0,
                                                                        0.0),
                                                                child: Text(
                                                                    '${narrativeListLocal[narrativeCount].name}',
                                                                    textAlign:
                                                                        TextAlign
                                                                            .start,
                                                                    style: TextStyle(
                                                                        fontFamily: Constant
                                                                            .customRegular,
                                                                        height:
                                                                            1.1,
                                                                        fontWeight: FontWeight
                                                                            .w700,
                                                                        fontSize:
                                                                            16.0,
                                                                        color: ColorValues
                                                                            .DARK_YELLOW))),
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        0.0,
                                                                        0.0,
                                                                        30.0,
                                                                        0.0),
                                                                child: Text(
                                                                    '${narrativeListLocal[narrativeCount].achievement[acheivementListCount].title}',
                                                                    textAlign:
                                                                        TextAlign
                                                                            .start,
                                                                    style: TextStyle(
                                                                        fontFamily: Constant
                                                                            .customRegular,
                                                                        height:
                                                                            1.1,
                                                                        fontWeight: FontWeight
                                                                            .w600,
                                                                        fontSize:
                                                                            24.0,
                                                                        color: ColorValues
                                                                            .presoSubHeading))),
                                                            Padding(
                                                                padding:
                                                                    EdgeInsets.fromLTRB(
                                                                        0.0,
                                                                        5.0,
                                                                        30.0,
                                                                        5.0),
                                                                child: Text(
                                                                    narrativeListLocal[narrativeCount].achievement[acheivementListCount].fromDate ==
                                                                            "null"
                                                                        ? ""
                                                                        : getConvertedDateStamppreso(narrativeListLocal[narrativeCount].achievement[acheivementListCount].fromDate) +
                                                                            " - " +
                                                                            getConvertedDateStamppreso(narrativeListLocal[narrativeCount]
                                                                                .achievement[
                                                                                    acheivementListCount]
                                                                                .toDate),
                                                                    textAlign:
                                                                        TextAlign
                                                                            .start,
                                                                    style: TextStyle(
                                                                        fontFamily:
                                                                            Constant.customRegular,
                                                                        fontSize: 12.0,
                                                                        fontWeight: FontWeight.w400,
                                                                        color: ColorValues.labelColor))),
                                                            narrativeListLocal[narrativeCount]
                                                                            .achievement[
                                                                                acheivementListCount]
                                                                            .hoursWorkedPerWeek !=
                                                                        null &&
                                                                    narrativeListLocal[narrativeCount]
                                                                            .achievement[
                                                                                acheivementListCount]
                                                                            .hoursWorkedPerWeek !=
                                                                        "null" &&
                                                                    narrativeListLocal[narrativeCount]
                                                                            .achievement[
                                                                                acheivementListCount]
                                                                            .hoursWorkedPerWeek !=
                                                                        ""
                                                                ? PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        5.0,
                                                                        Text(
                                                                          "Hours Worked Per Week: " +
                                                                              narrativeListLocal[narrativeCount].achievement[acheivementListCount].hoursWorkedPerWeek,
                                                                          textAlign:
                                                                              TextAlign.left,
                                                                          maxLines:
                                                                              null,
                                                                          style: TextStyle(
                                                                              color: Color(0xFF404040),
                                                                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                                              fontSize: 14.0),
                                                                        ))
                                                                : Container(
                                                                    height: 0.0,
                                                                  ),
                                                            narrativeListLocal[
                                                                            narrativeCount]
                                                                        .achievement[
                                                                            acheivementListCount]
                                                                        .all_badge_trophy_certificate
                                                                        .length >
                                                                    0
                                                                ? Container(
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsets.fromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          30.0,
                                                                          0.0),
                                                                      child:
                                                                          Column(
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        children: <
                                                                            Widget>[
                                                                          PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              0.0,
                                                                              5.0,
                                                                              Container(
                                                                                  height: 48.0,
                                                                                  child: GridView.count(
                                                                                    primary: true,
                                                                                    scrollDirection: Axis.horizontal,
                                                                                    padding: const EdgeInsets.all(0.0),
                                                                                    crossAxisCount: 1,
                                                                                    childAspectRatio: 0.87,
                                                                                    mainAxisSpacing: 13.0,
                                                                                    crossAxisSpacing: 4.0,
                                                                                    children: List.generate(narrativeListLocal[narrativeCount].achievement[acheivementListCount].all_badge_trophy_certificate.length, (int index2) {
                                                                                      return InkWell(
                                                                                        onTap: () {},
                                                                                        child: Card(
                                                                                          semanticContainer: true,
                                                                                          clipBehavior: Clip.antiAliasWithSaveLayer,
                                                                                          shape: RoundedRectangleBorder(
                                                                                            borderRadius: BorderRadius.circular(10.0),
                                                                                          ),
                                                                                          elevation: 5,
                                                                                          child: CachedNetworkImage(
                                                                                            height: 45.0,
                                                                                            width: narrativeListLocal[narrativeCount].achievement[acheivementListCount].all_badge_trophy_certificate[index2].tag == 'certificates' ? 67.0 : 55,
                                                                                            imageUrl: Constant.IMAGE_PATH + narrativeListLocal[narrativeCount].achievement[acheivementListCount].all_badge_trophy_certificate[index2].file,
                                                                                            fit: BoxFit.fill,
                                                                                            placeholder: (context, url) => _loader(context, "assets/profile/default_achievement.png"),
                                                                                            errorWidget: (context, url, error) => _error("assets/profile/default_achievement.png"),
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    }),
                                                                                  ))),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  )
                                                                : Container(
                                                                    height: 0.0,
                                                                  ),
                                                          ]),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              flex: 1),
                                          Expanded(
                                            child: Card(
                                              semanticContainer: true,
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                              ),
                                              elevation: 5,
                                              child: Container(
                                                height: 220.0,
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                10))),
                                                child: narrativeListLocal[
                                                                narrativeCount]
                                                            .achievement[
                                                                acheivementListCount]
                                                            .mediaList
                                                            .length ==
                                                        0
                                                    ? Padding(
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                        child: Container(
                                                          height: 220.0,
                                                          decoration: BoxDecoration(
                                                              borderRadius: BorderRadius
                                                                  .all(Radius
                                                                      .circular(
                                                                          10))),
                                                          child: Image.asset(
                                                            "assets/aerial/default_img.png",
                                                            height: 220.0,
                                                            fit: BoxFit.fill,
                                                          ),
                                                        ))
                                                    : PageIndicatorContainer(
                                                        pageView:
                                                            PageView.builder(
                                                          controller:
                                                              _controller,

                                                          itemBuilder: (context,
                                                              position) {
                                                            return Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        0.0,
                                                                        0.0,
                                                                        0.0,
                                                                        0.0),
                                                                child: Stack(
                                                                  children: <
                                                                      Widget>[
                                                                    narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList[position].type ==
                                                                            'video'
                                                                        ? Container(
                                                                            width:
                                                                                double.infinity,
                                                                            height:
                                                                                220.0,
                                                                            decoration:
                                                                                BoxDecoration(color: Colors.black, borderRadius: BorderRadius.all(Radius.circular(10))),
                                                                            child: FutureBuilder(
                                                                                future: getVideoThumb(narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList[position].file),
                                                                                builder: (BuildContext context, AsyncSnapshot<Image> image) {
                                                                                  if (image.hasData) {
                                                                                    return Stack(
                                                                                      children: <Widget>[
                                                                                        Container(width: double.infinity, height: 220.0, decoration: BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(10))), child: image.data),
                                                                                        InkWell(
                                                                                          onTap: () {
                                                                                            print('Apurva Dabade onTap video play button ');
                                                                                            //Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) =>   VideoFullViewWidget('', MessageConstant.VIEWER_END_REWCOMMENDATION_HEDING, Constant.IMAGE_PATH + narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList[position].file)));
                                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => VideoFullViewWidget('', MessageConstant.VIEWER_END_REWCOMMENDATION_HEDING, narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList[position].file)));
                                                                                          },
                                                                                          child: Center(
                                                                                              child: Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                                                            children: <Widget>[
                                                                                              PaddingWrap.paddingfromLTRB(
                                                                                                  0.0,
                                                                                                  0.0,
                                                                                                  0.0,
                                                                                                  0.0,
                                                                                                  Image.asset(
                                                                                                    //'assets/pre_login/video_play_button.png',
                                                                                                    'assets/newDesignIcon/circle_play.png',
                                                                                                    width: 50.0,
                                                                                                    height: 50.0,
                                                                                                  ))
                                                                                            ],
                                                                                          )),
                                                                                        ),
                                                                                      ],
                                                                                    ); // image is ready
                                                                                  } else {
                                                                                    return Container(
                                                                                        height: 220.0,
                                                                                        decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.all(Radius.circular(10))),
                                                                                        child: CachedNetworkImage(
                                                                                          width: double.infinity,
                                                                                          height: 220.0,
                                                                                          imageUrl: "",
                                                                                          fit: BoxFit.fill,
                                                                                          placeholder: (context, url) => _loader(context, "assets/aerial/default_img.png"),
                                                                                          errorWidget: (context, url, error) => _error("assets/aerial/default_img.png"),
                                                                                        )); // placeholder
                                                                                  }
                                                                                }),
                                                                          )
                                                                        : Container(
                                                                            height:
                                                                                220.0,
                                                                            decoration:
                                                                                BoxDecoration(color: Colors.black, borderRadius: BorderRadius.all(Radius.circular(10))),
                                                                            child: FadeInImage.assetNetwork(
                                                                              fit: BoxFit.fitHeight,
                                                                              width: double.infinity,
                                                                              height: 220.0,
                                                                              placeholder: 'assets/aerial/default_img.png',
                                                                              image: Constant.IMAGE_PATH + narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList[position].file,
                                                                            )),
                                                                    narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList.length ==
                                                                                1 ||
                                                                            narrativeListLocal[narrativeCount].achievement[acheivementListCount].mediaList[position].type ==
                                                                                'video'
                                                                        ? Container(
                                                                            height:
                                                                                0.0,
                                                                          )
                                                                        : Container(
                                                                            height:
                                                                                220.0,
                                                                            decoration:
                                                                                BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(10))),
                                                                            width:
                                                                                double.infinity,
                                                                            child:
                                                                                Image.asset(
                                                                              "assets/newDesignIcon/navigation/layer_image.png",
                                                                              fit: BoxFit.fill,
                                                                            ),
                                                                          )
                                                                  ],
                                                                ));
                                                          },
                                                          itemCount: narrativeListLocal[
                                                                  narrativeCount]
                                                              .achievement[
                                                                  acheivementListCount]
                                                              .mediaList
                                                              .length, // Can be null
                                                        ),
                                                        align: IndicatorAlign
                                                            .bottom,
                                                        length: narrativeListLocal[
                                                                narrativeCount]
                                                            .achievement[
                                                                acheivementListCount]
                                                            .mediaList
                                                            .length,
                                                        indicatorSpace: 5.0,
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                10.0,
                                                                10.0,
                                                                10.0,
                                                                25.0),
                                                        indicatorColor: narrativeListLocal[
                                                                        narrativeCount]
                                                                    .achievement[
                                                                        acheivementListCount]
                                                                    .mediaList
                                                                    .length ==
                                                                1
                                                            ? Colors.transparent
                                                            : Color(0xffc4c4c4),

                                                        indicatorSelectorColor:
                                                            narrativeListLocal[
                                                                            narrativeCount]
                                                                        .achievement[
                                                                            acheivementListCount]
                                                                        .mediaList
                                                                        .length ==
                                                                    1
                                                                ? Colors
                                                                    .transparent
                                                                : Colors.white,
                                                        shape: IndicatorShape
                                                            .circle(size: 5),
                                                        // shape: IndicatorShape.roundRectangleShape(size: Size.square(12),cornerSize: Size.square(3)),
                                                        // shape: IndicatorShape.oval(size: Size(12, 8)),
                                                      ),
                                              ),
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          30.0,
                                          0.0,
                                          Text(
                                            narrativeListLocal[narrativeCount]
                                                        .achievement[
                                                            acheivementListCount]
                                                        .description ==
                                                    null
                                                ? ""
                                                : narrativeListLocal[
                                                        narrativeCount]
                                                    .achievement[
                                                        acheivementListCount]
                                                    .description,
                                            maxLines: narrativeListLocal[
                                                        narrativeCount]
                                                    .achievement[
                                                        acheivementListCount]
                                                    .isShowMore
                                                ? 5
                                                : 3,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontFamily:
                                                    Constant.customRegular,
                                                fontWeight: FontWeight.w400,
                                                fontSize: 14.0,
                                                color: ColorValues.black),
                                          )),
                                      Container(
                                          //height: 150.0,
                                          child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 30.0, 0.0),
                                        child: narrativeListLocal[
                                                        narrativeCount]
                                                    .achievement[
                                                        acheivementListCount]
                                                    .description ==
                                                null
                                            ? Container(
                                                height: 0.0,
                                              )
                                            : narrativeListLocal[narrativeCount]
                                                        .achievement[
                                                            acheivementListCount]
                                                        .description
                                                        .length >
                                                    130
                                                ? InkWell(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            15.0,
                                                            15.0,
                                                            Text(
                                                              narrativeListLocal[
                                                                          narrativeCount]
                                                                      .achievement[
                                                                          acheivementListCount]
                                                                      .isShowMore
                                                                  ? "Less"
                                                                  : "More",
                                                              maxLines: 1,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign:
                                                                  TextAlign
                                                                      .start,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  fontSize:
                                                                      14.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                    onTap: () {
                                                      if (narrativeListLocal[
                                                              narrativeCount]
                                                          .achievement[
                                                              acheivementListCount]
                                                          .isShowMore)
                                                        narrativeListLocal[
                                                                narrativeCount]
                                                            .achievement[
                                                                acheivementListCount]
                                                            .isShowMore = false;
                                                      else
                                                        narrativeListLocal[
                                                                narrativeCount]
                                                            .achievement[
                                                                acheivementListCount]
                                                            .isShowMore = true;
                                                      setState(() {
                                                        narrativeListLocal[
                                                                narrativeCount]
                                                            .achievement[
                                                                acheivementListCount]
                                                            .isShowMore;
                                                      });
                                                    },
                                                  )
                                                : Container(
                                                    height: 0.0,
                                                  ),
                                      )),
                                    ],
                                  )),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ]),
            ),
          );

          break;

        case 8: //ui for love and other interest
          return Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image:
                      AssetImage("assets/preso_view_new/interest_bg_new.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Stack(children: <Widget>[
                // Positioned(top: -30, child: getHeader("interests")),
                Positioned(
                    top: 20,
                    left: 30,
                    child: getHeaderTitle("Interest", ColorValues.WHITE)),
                Padding(
                  padding: EdgeInsets.only(top: 80.0),
                  child:
                      getLoveInterestCircleView(), //getLoveAndOtherInterest()//getLoveAndOtherInterestCircles(),//
                  //       Scatter(
                  // delegate:
                  //     LogarithmicSpiralScatterDelegate(
                  //         ratio: 1, a: 1, b: 1, step: 0.01, rotation: 0.3),
                  //     children: getLoveAndOtherInterestCircles())//getLoveAndOtherInterest()
                ),
              ]));
          break;

        case 9: //ui for future goals
          return Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image:
                      AssetImage("assets/preso_view_new/light_bg_presso.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Stack(children: <Widget>[
                //Positioned(top: -30, child: getHeader("future goals")),
                Positioned(
                    top: 0,
                    left: 30,
                    child: getHeaderTitle(
                        "Future goal", ColorValues.presoHeading)),
                Padding(
                  padding: EdgeInsets.only(top: 50.0),
                  child: PaddingWrap.paddingfromLTRB(
                      30.0,
                      0.0,
                      38.0,
                      0.0,
                      TextViewWrap.textViewSingleLine(
                          "What’s next after high school?",
                          TextAlign.start,
                          ColorValues.presoSubHeading,
                          20.0,
                          FontWeight.bold)),
                ),
                Padding(
                    padding: EdgeInsets.only(left: 40.0, top: 80),
                    child: getGoalsViewNew()),
              ]));

          break;

        case 10: //ui for future goals institute
          return Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/preso_view_new/target_cldg.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Container(
                  color: ColorValues.presoBgColor.withOpacity(0.9),
                  child: Stack(children: <Widget>[
                    Positioned(
                        top: 0,
                        left: 30,
                        child: getHeaderTitle(
                            "My Target Institutes", ColorValues.WHITE)),
                    Padding(
                      padding: EdgeInsets.only(top: 80.0),
                      child:
                          getGoalsViewInstituteNew(), //getGoalsViewInstitute()
                    ),
                  ])));
          break;

        case 11: //ui for skills
          return Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/preso_view_new/light_bg_presso.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Stack(children: <Widget>[
              Positioned(
                  top: 15,
                  left: 30,
                  child: getHeaderTitle("My Skills", ColorValues.presoHeading)),
              Padding(
                  padding: EdgeInsets.only(top: 80.0, left: 20),
                  child: getSkillsViewNew() //getSkillsColorCircles()//
                  ),
            ]),
          );
          break;

        case 12: // for certificates ui
          return Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/preso_view_new/new_bg_presso.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              color: ColorValues.presoBgColor.withOpacity(0.9),
              child: Stack(children: <Widget>[
                Positioned(
                    top: 20,
                    left: 30,
                    child: getHeaderTitle("Certification", ColorValues.WHITE)),
                Padding(
                    padding: EdgeInsets.only(top: 150.0),
                    child: Container(
                        height: double.infinity, color: Colors.white)),
                Center(
                    child: Padding(
                        padding: EdgeInsets.only(top: 60.0),
                        child: pagerViewForGridAutoScrollCertificate()))
              ]),
            ),
          );

          break;

        case 13: // for badges ui
          return Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/preso_view_new/new_bg_presso.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              color: ColorValues.presoBgColor.withOpacity(0.9),
              child: Stack(children: <Widget>[
                Positioned(
                    top: 20,
                    left: 30,
                    child: getHeaderTitle("Badges", ColorValues.WHITE)),
                Center(
                    child: Padding(
                        padding: EdgeInsets.only(top: 60.0),
                        child: pagerViewForGridAutoScrollBadges()))
              ]),
            ),
          );

          break;

        case 14:
          // Maintain the recommendation View  List

          //timerScheduleForNavigation(timeFrameRecommendation);
          return Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/preso_view_new/light_bg_presso.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Stack(children: <Widget>[
              // Positioned(top: -30, child: getHeader("recommendations")),
              Positioned(
                  top: 0,
                  left: 30,
                  child: getHeaderTitle(
                      "Recommendations", ColorValues.presoHeading)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 25.0, right: 30, left: 30, bottom: 5),
                    child: Center(
                      child: ListView(
                        shrinkWrap: true,
                        children: <Widget>[
                          // recommendationsView(addedRecommendationtList[
                          //     reccomendationListCount]),
                          pagerViewForGridAutoScrollRecommendations(),
                        ],
                      ),
                    ),
                  ),
                ],
              )
            ]),
          );

          break;

        case 15:
          // Thanks View
          //initThankYouPageAnim();
          //  controllerTopCenter.play();
          print("sss 111 sss");

          return Container(
            color: ColorValues.presoBgColor,
            child: Stack(
              children: <Widget>[
                buildConfettiWidget(controllerTopCenter, pi / 1),
                buildConfettiWidget(controllerTopCenter, pi / 4),
                Center(
                  child: thankYouPage(),
                ),
              ],
            ),
          );
      }
    }

    Widget getNavigationBottomView(isFirstChild) {
      //if (isFirstChild) {
      return Positioned(
          top: 0.0,
          left: 0.0,
          bottom: 0.0,
          right: 0.0,
          child: SlideTransition(
            position: bottomNavOffset,
            child: Container(
                //color: Colors.black45.withOpacity(0.4),
                // decoration: BoxDecoration(
                //   image: DecorationImage(
                //     image: AssetImage(
                //         //"assets/newDesignIcon/aerialView/pressoview_controller_filterbg.png"
                //         'assets/preso_view_new/dimmer.png'),
                //     fit: BoxFit.fill,
                //   ),
                // ),
                child: Column(
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                        child: FlatButton(
                            onPressed: () {
                              // Fake ICon for manage sapce
                            },
                            child: Image.asset(
                              '',
                              width: 35.0,
                              height: 35.0,
                            ))),
                    Expanded(
                      child: Text(""),
                      flex: 1,
                    ),
                    widget.pageName == 'preview'
                        ? //chat
                        Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                            child: InkWell(
                              child: Row(
                                children: <Widget>[
                                  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 0.0),
                                      child: Image.asset(
                                          'assets/preso_view_new/publish.png',
                                          width: 21.0,
                                          height: 21.0)),
                                  Padding(
                                      padding: EdgeInsets.only(
                                        left: 6.0,
                                      ),
                                      child: Text(
                                        "Publish",
                                        style: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontSize: 14,
                                            color: ColorValues.labelColor),
                                      ))
                                ],
                              ),
                              onTap: () async {
                                onTapShare();
                              },
                            ))
                        : Container(
                            width: 0,
                            height: 0,
                          ),
                    Expanded(
                      child: Text(""),
                      flex: 1,
                    ),
                    Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                        child: FlatButton(
                            onPressed: () {
                              finish();
                            },
                            child: Image.asset(
                              'assets/preso_view_new/cross.png',
                              width: 40.0,
                              height: 40.0,
                            ))),
                  ],
                ),
                Expanded(
                  child: Text(""),
                  flex: 1,
                ),
                Row(
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                        child: FlatButton(
                            onPressed: () {
                              setState(() {
                                clickButtonTap = true;
                              });

                              if (clickButtonTap) {
                                Future.delayed(
                                    const Duration(milliseconds: 1000), () {
                                  setState(() {
                                    clickButtonTap = false;
                                  });
                                  if (frameNo != 0) {
                                    _backNavigationBtnClick();
                                  } else {
                                    //finish();
                                  }
                                });
                              }
                            },
                            child: Image.asset(
                                frameNo > 0
                                    ? 'assets/newDesignIcon/aerialView/av_previous.png'
                                    : "",
                                width: 35.0,
                                height: 35.0))),
                    Expanded(
                      child: Text(
                        //resultStamp.toString().replaceAll(".", ":") +
                        //widget.pageName != 'preview' ?
                        //resultStampString + " Min":
                        '',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.white,
                            fontFamily: Constant.customRegular),
                      ),
                      flex: 1,
                    ),
                    Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                        child: FlatButton(
                            onPressed: () {
                              setState(() {
                                clickButtonTap = true;
                              });

                              if (clickButtonTap) {
                                Future.delayed(
                                    const Duration(milliseconds: 1000), () {
                                  setState(() {
                                    clickButtonTap = false;
                                  });
                                  if (frameNo != 15) _navigationBtnClick(true);
                                });
                              }
                            },
                            child: Image.asset(
                              frameNo != 15
                                  ? 'assets/newDesignIcon/aerialView/av_next.png'
                                  : "",
                              width: 35.0,
                              height: 35.0,
                            ))),
                  ],
                ),
              ],
            )),
          ));
    }

    return WillPopScope(
        onWillPop: () {
          /*if (widget.pageName == "main") {
            onBack();
          } else {
            finish();
          }*/
          finish();
        },
        child: Material(
            child: _mPublicProfileDataModel != null
            //&& _mAcoomplismentDataModel != null
            //&& _mSpiderAndSkillDataModel != null
            //|| _mPublicProfileDataModel.result != null
                ? Container(
              child: InkWell(
                child: //frameNo == 7 || frameNo == 4 || frameNo == 5
                //frameNo == 4 || frameNo == 5 || frameNo == 6 || frameNo == 7 || frameNo == 8 || frameNo == 9 || frameNo == 10 || frameNo == 11 || frameNo == 12 || frameNo == 13 || frameNo == 14 || frameNo == 15
                frameNo != 0 &&
                    frameNo != 1 &&
                    frameNo != 2 &&
                    frameNo != 3 &&
                    frameNo != 15
                    ? Container(
                  child: Stack(
                    children: <Widget>[
                      frameNo == 9 || frameNo == 10
                          ? Positioned(
                        left: 0.0,
                        bottom: 0.0,
                        top: 0.0,
                        right: 0.0,
                        child: Image.asset(
                          "",
                          fit: BoxFit.cover,
                        ),
                      )
                          : Positioned(
                        left: 0.0,
                        bottom: 0.0,
                        top: 0.0,
                        right: 0.0,
                        child: FadeInImage.assetNetwork(
                          fit: BoxFit.cover,
                          placeholder: "",
                          image: _mPublicProfileDataModel
                              .result !=
                              null
                              ? Constant.IMAGE_PATH_SMALL +
                              ParseJson.getMediumImage(
                                  _mPublicProfileDataModel
                                      .result
                                      .coverImage)
                              : "",
                        ),
                      ),

                      frameNo == 9 || frameNo == 10
                          ? Container()
                          : Positioned(
                        left: 0.0,
                        bottom: 0.0,
                        top: 0.0,
                        right: 0.0,
                        child: Container(
                          color: ColorValues.SCREEN_BG_COLOR
                              .withOpacity(0.9),
                        ),
                      ),

                      // getCircleViewForBackGround(
                      //     Color(0xffC3DBED).withOpacity(0.4),
                      //     statusBarHeight),
                      //background: #C3DBED;
                      //getCircleViewForBackGround(Color(0xffC3DBED).withOpacity(0.3)),
                      //  getShareTopView(),
                      Positioned(
                          left: 0.0,
                          bottom: 0.0,
                          top: 0,
                          right: 0.0,
                          child: getViewBasedOnTheIndex("")),

                      getNavigationBottomView(true)
                    ],
                  ),
                )
                    : AnimatedCrossFade(
                    duration: Duration(milliseconds: 3000),
                    firstChild: Container(
                      child: Stack(
                        children: <Widget>[
                       /*   Positioned(
                            left: 0.0,
                            bottom: 0.0,
                            top: 0.0,
                            right: 0.0,
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: "",
                              image:
                              _mPublicProfileDataModel.result !=
                                  null
                                  ? ""
                                  : "",
                            ),
                          ),*/
                          Positioned(
                              left: 0.0,
                              bottom: 0.0,
                              top: 0.0,
                              right: 0.0,
                              child: Image.asset(
                                frameNo == 2 ||
                                    frameNo == 3 ||
                                    frameNo == 15
                                    ? "assets/preso_view_new/new_bg_presso.png" //"assets/newDesignIcon/aerialView/bg_black.png"
                                    : "assets/preso_view_new/new_bg_presso.png",
                                //"assets/newDesignIcon/aerialView/bg_white.png",
                                fit: BoxFit.fill,
                              )),
                          Positioned(
                              left: 0.0,
                              bottom: 0.0,
                              top: 0,
                              right: 0.0,
                              child: Rendering(
                                builder: (context, time) {
                                  //_simulateParticles(time);
                                  return CustomPaint(
                                    //painter: ParticlePainter(particles, time, false),
                                      child: getViewBasedOnTheIndex(
                                          "First"));
                                },
                              )),
                          getNavigationBottomView(true)
                        ],
                      ),
                    ),
                    secondChild: Container(
                      child: Stack(
                        children: <Widget>[
                          Positioned(
                            left: 0.0,
                            bottom: 0.0,
                            top: 0.0,
                            right: 0.0,
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: "",
                              image: _mPublicProfileDataModel
                                  .result !=
                                  null
                                  ? ""
                              //  Constant.IMAGE_PATH_SMALL +
                              //     ParseJson.getMediumImage(
                              //         _mPublicProfileDataModel
                              //             .result.coverImage)
                                  : "",
                            ),
                          ),
                          Positioned(
                              left: 0.0,
                              bottom: 0.0,
                              top: 0.0,
                              right: 0.0,
                              child: Image.asset(
                                frameNo == 15 ||
                                    frameNo == 2 ||
                                    frameNo == 3
                                    ? "assets/preso_view_new/new_bg_presso.png"
                                    : "assets/preso_view_new/new_bg_presso.png",
                                fit: BoxFit.fill,
                              )),

                          /*frameNo == 2 ||
                            frameNo == 3 ||
                            frameNo == 15
                            ?    Image.asset(
                          "assets/newDesignIcon/aerialView/bg_black.png",
                          fit: BoxFit.fill,
                        )
                            :   Positioned(
                          left: 0.0,
                          bottom: 0.0,
                          top: 0.0,
                          right: 0.0,
                          child: Container(color: ColorValues.SCREEN_BG_COLOR.withOpacity(0.9),),),*/

                          // frameNo == 15 ||
                          //     frameNo == 2 ||
                          //     frameNo == 3
                          //     ? getCircleViewForBackGround(
                          //     Color(0xffC3DBED)
                          //         .withOpacity(0.4),
                          //     statusBarHeight)
                          // //? getCircleViewForBackGround(Color(0xffC3DBED).withOpacity(0.3))
                          // //Color(0xffbdc7ce).withOpacity(0.3))
                          //     : getCircleViewForBackGround(
                          //     Color(0xffC3DBED)
                          //         .withOpacity(0.4),
                          //     statusBarHeight),
                          //: getCircleViewForBackGround(Color(0xffC3DBED).withOpacity(0.3)),
                          Positioned(
                              left: 0.0,
                              bottom: 0.0,
                              top: 0,
                              right: 0.0,
                              child: Rendering(
                                builder: (context, time) {
                                  // _simulateParticles(time);
                                  return CustomPaint(
                                    //  painter:ParticlePainter(particles, time, true),
                                      child: getViewBasedOnTheIndex(
                                          "Second"));
                                },
                              )),
                          getNavigationBottomView(false)
                        ],
                      ),
                    ),
                    crossFadeState: frameNo == 3 ||
                        frameNo ==
                            2 //apurva dabade commented frameNo == 15 beacuse now no spider on frame =15 thank you page and adding on frame no = 3 that is bar graph page
                        ? CrossFadeState.showSecond
                        : CrossFadeState.showFirst),
                onTap: () {
                  //if(!isVideoClicked){
                  _settingModalBottomSheet(context);
                  _settingModalTopSheet(context);
                  //}
                },
              ),
            )
                : Container(
              child: Center(
                // Aligns the container to center
                child: Container(
                  // A simplified version of dialog.
                    width: 30.0,
                    height: 30.0,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(
                          ColorValues.BLUE_COLOR_BOTTOMBAR),
                      strokeWidth: 2.0,
                    )),
              ),
            ),));
  }

  onBack() async {
    if (widget.studentProfile != null) {
      Navigator.pop(context);
    } else {
      try {
        if (prefs.getBool("loginStatus") != null &&
            prefs.getBool("loginStatus")) {
          if (roleId == "2") {
            Navigator.of(context).popUntil((route) => route.isFirst);
            Navigator.of(context).pushReplacement(new MaterialPageRoute(
                builder: (BuildContext context) => DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
          } else if (roleId == "4") {
            Navigator.of(context).popUntil((route) => route.isFirst);
            Navigator.of(context).pushReplacement(new MaterialPageRoute(
                builder: (BuildContext context) => DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
          } else {
            Navigator.of(context).popUntil((route) => route.isFirst);
            Navigator.of(context).pushReplacement(new MaterialPageRoute(
                builder: (BuildContext context) => DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
          }
        } else {
          prefs.setBool(UserPreference.LOGIN_STATUS, false);
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => LoginPage(
                    null,
                    isRedirectToRecommendation: false,
                    pageName: "main",
                    showSignup: false,
                  )));
        }
      } catch (e) {
        print("Error+++++++++++" + e.toString());
      }
    }
  }

 void exitConfirmationDialog() {
   showModalBottomSheet(
     context: context,
     backgroundColor: Colors.transparent,
     isDismissible: false,
     builder: (_) {
       return ConfirmationDialog(
         msg: 'Are you sure you want to exit from Presentation view?',
         positiveText: "Yes",
         negativeText: "No",
         positiveTextColor: ColorValues
             .BLUE_COLOR_BOTTOMBAR,
         onPositiveTap: () {
           AutoOrientation.portraitAutoMode();
           if (widget.pageName == "main" ||
               widget.pageName ==
                   "notification") {
             onBack();
           } else {
             refresh();
             Navigator.pop(context);
           }
         },
       );
     },
   );
    /*showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 193.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                "Are you sure you want to exit from Presentation view?",
                                                textAlign: TextAlign.center,
                                                maxLines: 5,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    height: 1.2,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                            ]),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color:
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.of(context,
                                              rootNavigator: true)
                                              .pop('dialog');
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.pop(context);
                                          print(
                                              "Calling+++++++++++++++++++++++++++++" +
                                                  widget.pageName);
                                          AutoOrientation.portraitAutoMode();
                                          if (widget.pageName == "main" ||
                                              widget.pageName ==
                                                  "notification") {
                                            print(
                                                "onBack Calling+++++++++++++++++++++++++++++");
                                            onBack();
                                          } else {
                                            refresh();
                                            Navigator.pop(context);
                                          }
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));*/
  }

  void finish() {
    exitConfirmationDialog();
  }

  void _settingModalBottomSheet(context) {
    print("control chnages " + isActionButtonShowing.toString());

    if (isActionButtonShowing) {
      isPaused = false;
      isActionButtonShowing = false;
    } else {
      isActionButtonShowing = true;
      isPaused = true;
      if (actionControllerHandlerTimer != null)
        actionControllerHandlerTimer.cancel();
    }
    print("control chnages after " + isActionButtonShowing.toString());
    print(
        "control chnages after _bottomNavController.status:: ${_bottomNavController.status}");

    if (frameNo != 15) {
      setState(() {
        isPaused;
      });
    }
    switch (_bottomNavController.status) {
      case AnimationStatus.completed:
        _bottomNavController.reverse();

        break;
      case AnimationStatus.dismissed:
        _bottomNavController.forward();

        break;
      default:
    }
  }

  void _settingModalTopSheet(context) {
    print(_topNavController.status);
    switch (_topNavController.status) {
      case AnimationStatus.completed:
        _topNavController.reverse();
        break;
      case AnimationStatus.dismissed:
        _topNavController.forward();
        break;
      default:
    }
  }

  void showFrame2BodyText() {
    switch (_frame2BodyController.status) {
      case AnimationStatus.completed:
        _frame2BodyController.reverse();
        break;
      case AnimationStatus.dismissed:
        _frame2BodyController.forward();
        break;
      default:
    }
  }

  void showSpiderChartTextBodyText() {
    switch (_spiderChartTextBodyController.status) {
      case AnimationStatus.completed:
        _spiderChartTextBodyController.reverse();
        break;
      case AnimationStatus.dismissed:
        _spiderChartTextBodyController.forward();
        break;
      default:
    }
  }

  stopConfetti() async {
    controllerTopCenter.play();
    await Future.delayed(Duration(seconds: 4));
    controllerTopCenter.stop();
    print("SSS timer call");
  }

  _navigationBtnClick(bool isNext) {
    print('Apurva inside _navigationBtnClick() frameNo::: $frameNo');
    isBackPressed = false;
    if (frameNo == 7) {
      // here we have to maintain the Acheivement list and data

      print(
          'Apurva inside _navigationBtnClick() narrativeCount::: ${narrativeCount}');
      print(
          'Apurva inside _navigationBtnClick() acheivementListCount::: ${acheivementListCount}');
      print(
          'Apurva inside _navigationBtnClick() narrativeListLocal.length::: ${narrativeListLocal.length}');

      if (narrativeListLocal.length > 0)
        timerScheduleForNavigation(timeFrameAchievement);

      if (narrativeListLocal.length > 0 &&
          narrativeCount <= narrativeListLocal.length - 1) {
        print(
            'Apurva inside _navigationBtnClick() if narrativeListLocal.length::: ${narrativeListLocal.length}');

        //if (narrativeListLocal[narrativeCount].achievement.length > 0 && acheivementListCount < narrativeListLocal[narrativeCount].achievement.length - 1) {
        if (acheivementListCount <
            narrativeListLocal[narrativeCount].achievement.length - 1) {
          acheivementListCount = acheivementListCount + 1;
          print(
              'Apurva inside _navigationBtnClick() if narrativeListLocal[narrativeCount].achievement.length::: ${narrativeListLocal[narrativeCount].achievement.length}');
        } else if (narrativeCount < narrativeListLocal.length - 1) {
          narrativeCount = narrativeCount + 1;
          acheivementListCount = 0;
          print(
              'Apurva inside _navigationBtnClick() else narrativeCount::: ${narrativeCount},acheivementListCount::: ${acheivementListCount} ');
        } else {
          // All Achievements Visited  then navigate to the recommendation
          frameNo = frameNo + 1;
          if (frameNo == 8 && loveInterestList.length == 0) {
            print("no data love other interest");
            frameNo = frameNo + 1;
          }
          if (frameNo == 9 && goalInterestList.length == 0) {
            print("no data goalInterestList");
            frameNo = frameNo + 1;
          }
          if (frameNo == 10 &&
              (_mPublicProfileDataModel.result.goalInterestInstitute == null &&
                  _mPublicProfileDataModel.result.goalInterestInstitute ==
                      'null' &&
                  _mPublicProfileDataModel.result.goalInterestInstitute ==
                      '')) {
            print("no data goalInterestList institude");
            frameNo = frameNo + 1;
          }
          if (frameNo == 11 && skillsList.length == 0) {
            print("no data skills");
            frameNo = frameNo + 1;
          }
          if (frameNo == 12 && certificationtList.length == 0) {
            print("no data certificate");
            frameNo = frameNo + 1;
          }
          if (frameNo == 13 && badgesList.length == 0) {
            print("no data badges");
            frameNo = frameNo + 1;
          }
          if (frameNo == 14 && addedRecommendationtList.length > 0) {
            //frameNo = frameNo + 1;
            //narrativeCount = 0;
            timerScheduleForNavigation(timeFrameRecommendation);
          } else if (frameNo == 14 && addedRecommendationtList.length == 0)
            frameNo = frameNo + 1;
        }
      } else {
        // All Achievements Visited  then navigate to the recommendation
        frameNo = frameNo + 1;
        if (frameNo == 8 && loveInterestList.length == 0) {
          print("no data love other interest");
          frameNo = frameNo + 1;
        }
        if (frameNo == 9 && goalInterestList.length == 0) {
          print("no data goalInterestList");
          frameNo = frameNo + 1;
        }
        if (frameNo == 10 &&
            (_mPublicProfileDataModel.result.goalInterestInstitute == null &&
                _mPublicProfileDataModel.result.goalInterestInstitute ==
                    'null' &&
                _mPublicProfileDataModel.result.goalInterestInstitute == '')) {
          print("no data goalInterestList institude");
          frameNo = frameNo + 1;
        }
        if (frameNo == 11 && skillsList.length == 0) {
          print("no data skills");
          frameNo = frameNo + 1;
        }
        if (frameNo == 12 && certificationtList.length == 0) {
          print("no data certificate");
          frameNo = frameNo + 1;
        }
        if (frameNo == 13 && badgesList.length == 0) {
          print("no data badges");
          frameNo = frameNo + 1;
        }
        if (frameNo == 14 && addedRecommendationtList.length > 0) {
          //frameNo = frameNo + 1;
          //narrativeCount = 0;
          timerScheduleForNavigation(timeFrameRecommendation);
          print(
              "inside frameNo 14 reccomendationListCount:: $reccomendationListCount");
          timerScheduleForNavigation(timeFrameRecommendation);
        } else if (frameNo == 14 && addedRecommendationtList.length == 0)
          frameNo = frameNo + 1;
      }
    } else if (frameNo == 14) {
      frameNo = frameNo + 1;
      // For Recommendation
      // if (addedRecommendationtList.length > 0 &&
      //     reccomendationListCount < addedRecommendationtList.length - 1) {
      //   //start recommendation frame if list has size more than 1
      //   print(
      //       "before reccomendation frame call reccomendationListCount:: ${reccomendationListCount}, recmm length:: ${addedRecommendationtList.length}");

      //   print(
      //       "after reccomendation frame call reccomendationListCount:: ${reccomendationListCount}, recmm length:: ${addedRecommendationtList.length}");
      //   if (reccomendationListCount < addedRecommendationtList.length - 1) {
      //     reccomendationListCount = reccomendationListCount + 1;
      //   }
      //   /*else {
      //     reccomendationListCount = 0;
      //   }*/
      // } else {
      //   //All Recommendation's visited then Navigate to the Thank you page
      //   frameNo = frameNo + 1;
      //   // Start Frame No 7
      //   print("Start Thank you page  " + frameNo.toString());
      // }
    } else {
      frameNo = frameNo + 1;
      print("frame no sk" + frameNo.toString());

      //if (frameNo == 2 && (!_mPublicProfileDataModel.result.isAccomplishment || narrativeListLocalAll.length == 0)) {
      if (frameNo == 2 && !isShowChart) {
        print("no spider data");
        frameNo = frameNo + 2;
      }
      if (frameNo == 4 && collegesInfoList.length == 0) {
        print("no college data education");
        frameNo = frameNo + 1;
      }
      if (frameNo == 5 && schoolsInfoList.length == 0) {
        print("no data education");
        frameNo = frameNo + 1;
      }
      if (frameNo == 6 && _mPublicProfileDataModel.result.testScores == 0) {
        print("no data testScoresList");
        frameNo = frameNo + 1;
      }
      if (frameNo == 7 && narrativeListLocal.length == 0) {
        print("no data accomplishment");
        frameNo = frameNo + 1;
      }

      if (frameNo == 8 && loveInterestList.length == 0) {
        print("no data love other interest");
        frameNo = frameNo + 1;
      }
      if (frameNo == 9 && goalInterestList.length == 0) {
        print("no data goalInterestList");
        frameNo = frameNo + 1;
      }
      if (frameNo == 10 &&
          (_mPublicProfileDataModel.result.goalInterestInstitute == null &&
              _mPublicProfileDataModel.result.goalInterestInstitute == 'null' &&
              _mPublicProfileDataModel.result.goalInterestInstitute == '')) {
        print("no data goalInterestList institude");
        frameNo = frameNo + 1;
      }
      if (frameNo == 11 && skillsList.length == 0) {
        print("no data skills");
        frameNo = frameNo + 1;
      }
      if (frameNo == 12 && certificationtList.length == 0) {
        print("no data certificate");
        frameNo = frameNo + 1;
      }
      if (frameNo == 13 && badgesList.length == 0) {
        print("no data badges");
        frameNo = frameNo + 1;
      }
      /*if (frameNo == 14 && addedRecommendationtList.length == 0) {
        print("no data recommendation");
        frameNo = frameNo + 1;
      }*/

      if (frameNo == 14 && addedRecommendationtList.length > 0) {
        // frameNo = frameNo + 1;
        //narrativeCount = 0;
        //timerScheduleForNavigation(timeFrameRecommendation);
      } else if (frameNo == 14 && addedRecommendationtList.length == 0)
        frameNo = frameNo + 1;
    }

    if (frameNo == 4 || frameNo == 5) {
      setState(() {
        collegeCurrentPage = 0;
        currentPage = 0;
      });
    }
    /*else if (frameNo == 12 || frameNo == 13) {
      _badgeCarouselController.jumpToPage(0);
      _certificateCarouselController.jumpToPage(0);
    }*/

    switch (frameNo) {
      case 0:
        // First Frame Left to right
        //previousPage = 0;
        _animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
          parent: _profilePictureController,
          curve: Curves.fastOutSlowIn,
        ));

        break;
      case 1:
        // About Me
        //previousPage = 0;
        print("sss ch videoUrl ${isShowVideoSlide}");
        if ((_mPublicProfileDataModel.result.summary == null ||
                _mPublicProfileDataModel.result.summary == "null") &&
            !isShowVideoSlide) {
          frameNo = frameNo + 1;
        }
        visible = false;
        //print("sss ch summary ${_mPublicProfileDataModel.result.summary}");

        if (isShowVideoSlide) {
          _animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
            parent: _profileVideoController,
            curve: Curves.fastOutSlowIn,
          ));
          _profileVideoController.forward();
        } else {
          _animation = Tween(begin: 0.0, end: 0.2).animate(CurvedAnimation(
            parent: _frame2ProfilePictureController,
            curve: Curves.fastOutSlowIn,
          ));
          _frame2ProfilePictureController.forward();
        }

        _frame2BodyController.value = 1.0; //Apurva Dabade

        timerScheduleForNavigation(timeFrameAboutMe);
        break;

      case 2:
        // For Frame 3 change background first
        //previousPage = 1;
        animationControllerMyStory = AnimationController(
          vsync: this,
          duration: Duration(seconds: 5),
        )..addListener(() => setState(() {}));
        animationMyStory = CurvedAnimation(
          parent: animationControllerMyStory,
          curve: Curves.easeInOut,
        );

        animationControllerMyStory.forward();

        _animation = Tween(begin: 0.3, end: 1.0).animate(CurvedAnimation(
          parent: _profilePictureControllerGone,
          curve: Curves.fastOutSlowIn,
        ));
        _profilePictureControllerGone.forward();

        // Spider Chart Animation Initilization

        spiderChartAnimation = Tween<double>(
          begin: 0.0,
          end: 1.0,
        ).animate(
          CurvedAnimation(
            parent: spideChartAnimationController,
            curve: Interval(
              0,
              0.5,
              curve: Curves.decelerate,
            ),
          ),
        );

        showSpiderChartTextBodyText();
        timerScheduleForNavigation(timeFrameSpider);
        break;

      case 3:
        //apurva dabade added
        // For Frame 3 change background first
        //previousPage = 2;
        animationControllerMyStory = AnimationController(
          vsync: this,
          duration: Duration(seconds: 5),
        )..addListener(() => setState(() {}));
        animationMyStory = CurvedAnimation(
          parent: animationControllerMyStory,
          curve: Curves.easeInOut,
        );

        animationControllerMyStory.forward();
        timerScheduleForNavigation(timeFrameBarGraph);
        break;

      case 4:
        //previousPage = 3;
        //.Education Page view college
        print('time framee::  school $timeFrameCollege');
        timerScheduleForNavigation(timeFrameCollege);
        break;

      case 5:
        //previousPage = 4;
        //.Education Page view
        print('time framee:: $timeFrameSchool');
        timerScheduleForNavigation(timeFrameSchool);
        break;

      case 6:
        //previousPage = 5;
        //apurva dabade added Test score Page view
        setState(() {
          _current = 0;
        });
        timerScheduleForNavigation(timeFrameTestScore);
        break;

      case 7:
        //previousPage = 5;
        //apurva dabade added Test score Page view
        timerScheduleForNavigation(timeFrameAchievement);
        break;

      case 8:
        //previousPage = 7;
        //apurva dabade added intereset Page view
        timerScheduleForNavigation(timeFrameLoveInterest);
        break;

      case 9:
        //previousPage = 8;
        //apurva dabade added future goals intereset Page view
        timerScheduleForNavigation(timeFrameFutureGoalsInterest);
        break;

      case 10:
        //previousPage = 10;
        //apurva dabade added future goals institute Page view
        timerScheduleForNavigation(timeFrameFutureGoalsInstitute);
        break;

      case 11:
        //previousPage = 10;
        //apurva dabade added skills Page view
        timerScheduleForNavigation(timeFrameSkills);
        break;

      case 12:
        //previousPage = 11;
        //apurva dabade added certificate Page view
        timerScheduleForNavigation(timeFrameCertificates);
        break;

      case 13:
        //previousPage = 12;
        //apurva dabade added badges Page view
        timerScheduleForNavigation(timeFrameBadges);
        break;

      /*case 14:
      //previousPage = 12;
      //apurva dabade added badges Page view
        timerScheduleForNavigation(timeFrameRecommendation);
        break;*/

      case 15:
        // Thank You Screen
        //thankYouAnimationStatusListener();
        stopConfetti();
        break;
    }
    setState(() {
      showFrame2BodyText();
    });
  }

  _backNavigationBtnClick() {
    //timerScheduleForNavigation(mainSlideDuration);

    //APURVA DABADE ADDED
    if (frameNo == 7) {
      // here we have to maintain the Acheivement list and data

      print(
          'Apurva inside _navigationBtnClick() narrativeCount::: ${narrativeCount}');
      print(
          'Apurva inside _navigationBtnClick() acheivementListCount::: ${acheivementListCount}');
      print(
          'Apurva inside _navigationBtnClick() narrativeListLocal.length::: ${narrativeListLocal.length}');

      //if (narrativeListLocal.length > 0)
      timerScheduleForNavigation(timeFrameAchievement);

      if (narrativeListLocal.length > 0 &&
          narrativeCount >= 0 &&
          acheivementListCount >= 0) {
        if (acheivementListCount > 0) {
          acheivementListCount = acheivementListCount - 1;
          print(
              'Apurva inside _navigationBtnClick() if narrativeListLocal[narrativeCount].achievement.length::: ${narrativeListLocal[narrativeCount].achievement.length}');
        } else if (narrativeCount > 0) {
          narrativeCount = narrativeCount - 1;
          acheivementListCount =
              narrativeListLocal[narrativeCount].achievement.length - 1;
          print(
              'Apurva inside _navigationBtnClick() else if narrativeCount::: ${narrativeCount},acheivementListCount::: ${acheivementListCount} ');
        } else {
          // All Achievements Visited  then navigate to the recommendation
          print(
              'Apurva inside _navigationBtnClick() else narrativeCount::: ${narrativeCount},acheivementListCount::: ${acheivementListCount} ');

          frameNo = frameNo - 1;

          if (frameNo == 6 &&
                  _mPublicProfileDataModel.result.testScores.length == 0
              //&& !_mPublicProfileDataModel.result.isTestScore
              ) {
            print("no data testScoresList");
            frameNo = frameNo - 1;
          }
          if (frameNo == 5 && schoolsInfoList.length == 0) {
            print("no data education");
            frameNo = frameNo - 1;
          }
          if (frameNo == 4 && collegesInfoList.length == 0) {
            print("no college 11 data education");
            frameNo = frameNo - 1;
          }
          //if (frameNo == 3 && (!_mPublicProfileDataModel.result.isAccomplishment || narrativeListLocalAll.length == 0)) {
          if (frameNo == 3 && !isShowChart) {
            print("no spider data");
            frameNo = frameNo - 2;
          }
        }
      } else {
        // All Achievements Visited  then navigate to the recommendation
        frameNo = frameNo - 1;

        if (frameNo == 6 &&
                _mPublicProfileDataModel.result.testScores.length == 0
            //&& !_mPublicProfileDataModel.result.isTestScore
            ) {
          print("no data testScoresList");
          frameNo = frameNo - 1;
        }
        if (frameNo == 5 && schoolsInfoList.length == 0) {
          print("no data education");
          frameNo = frameNo - 1;
        }
        if (frameNo == 4 && collegesInfoList.length == 0) {
          print("no college 11 data education");
          frameNo = frameNo - 1;
        }
        //if (frameNo == 3 && (!_mPublicProfileDataModel.result.isAccomplishment || narrativeListLocalAll.length == 0)) {
        if (frameNo == 3 && !isShowChart) {
          print("no spider data");
          frameNo = frameNo - 2;
        }
      }
    } else if (frameNo == 14) {
      // For Recommendation
      print(
          "inside frameNo 14 reccomendationListCount:: $reccomendationListCount");
      timerScheduleForNavigation(timeFrameRecommendation);
      if (addedRecommendationtList.length > 0 && reccomendationListCount > 0) {
        //start recommendation frame if list has size more than 1
        print(
            "before reccomendation frame call reccomendationListCount:: ${reccomendationListCount}, recmm length:: ${addedRecommendationtList.length}");
        reccomendationListCount = reccomendationListCount - 1;
        print(
            "after reccomendation frame call reccomendationListCount:: ${reccomendationListCount}, recmm length:: ${addedRecommendationtList.length}");
      } else {
        //All Recommendation's visited then Navigate to the Thank you page
        frameNo = frameNo - 1;
        print("recc end now next frameNo:::  " + frameNo.toString());

        //chaeck for all frames
        if (frameNo == 13 && badgesList.length == 0) {
          print("no data badges");
          frameNo = frameNo - 1;
        }
        if (frameNo == 12 && certificationtList.length == 0) {
          print("no data certificate");
          frameNo = frameNo - 1;
        }
        if (frameNo == 11 && skillsList.length == 0) {
          print("no data skills");
          frameNo = frameNo - 1;
        }
        if (frameNo == 10 &&
            (_mPublicProfileDataModel.result.goalInterestInstitute == null ||
                _mPublicProfileDataModel.result.goalInterestInstitute ==
                    'null' ||
                _mPublicProfileDataModel.result.goalInterestInstitute == '')) {
          print("no data goalInterestList institude");
          frameNo = frameNo - 1;
        }
        if (frameNo == 9 && goalInterestList.length == 0) {
          print("no data goalInterestList");
          frameNo = frameNo - 1;
        }
        if (frameNo == 8 && loveInterestList.length == 0) {
          print("no data love other interest");
          frameNo = frameNo - 1;
        }
        if (frameNo == 7 && narrativeListLocal.length == 0) {
          frameNo = frameNo - 1;
        }
        if (frameNo == 6 &&
                _mPublicProfileDataModel.result.testScores.length == 0
            //&& !_mPublicProfileDataModel.result.isTestScore
            ) {
          print("no data testScoresList");
          frameNo = frameNo - 1;
        }
        if (frameNo == 5 && schoolsInfoList.length == 0) {
          print("no data education");
          frameNo = frameNo - 1;
        }
        if (frameNo == 4 && collegesInfoList.length == 0) {
          print("no college 11 data education");
          frameNo = frameNo - 1;
        }
        //if (frameNo == 3 && (!_mPublicProfileDataModel.result.isAccomplishment || narrativeListLocalAll.length == 0)) {
        if (frameNo == 3 && !isShowChart) {
          print("no spider data");
          frameNo = frameNo - 2;
        }
      }
    } else {
      frameNo = frameNo - 1;

      print("_backNavigationBtnClick frame number add " + frameNo.toString());
      if (frameNo == 14 && addedRecommendationtList.length == 0) {
        frameNo = frameNo - 1;
        //acheivementListCount = 0;
        //narrativeCount = 0;
        print("frame number addedRecommendationtList " + frameNo.toString());
      }
      if (frameNo == 13 && badgesList.length == 0) {
        print("no data badges");
        frameNo = frameNo - 1;
      }
      if (frameNo == 12 && certificationtList.length == 0) {
        print("no data certificate");
        frameNo = frameNo - 1;
      }
      if (frameNo == 11 && skillsList.length == 0) {
        print("no data skills");
        frameNo = frameNo - 1;
      }
      if (frameNo == 10 &&
          (_mPublicProfileDataModel.result.goalInterestInstitute == null ||
              _mPublicProfileDataModel.result.goalInterestInstitute == 'null' ||
              _mPublicProfileDataModel.result.goalInterestInstitute == '')) {
        print("no data goalInterestList institude");
        frameNo = frameNo - 1;
      }
      if (frameNo == 9 && goalInterestList.length == 0) {
        print("no data goalInterestList");
        frameNo = frameNo - 1;
      }
      if (frameNo == 8 && loveInterestList.length == 0) {
        print("no data love other interest");
        frameNo = frameNo - 1;
      }
      if (frameNo == 7 && narrativeListLocal.length == 0) {
        frameNo = frameNo - 1;
      }
      if (frameNo == 6 && _mPublicProfileDataModel.result.testScores.length == 0
          //&& !_mPublicProfileDataModel.result.isTestScore
          ) {
        print("no data testScoresList");
        frameNo = frameNo - 1;
      }
      if (frameNo == 5 && schoolsInfoList.length == 0) {
        print("no data education");
        frameNo = frameNo - 1;
      }
      if (frameNo == 4 && collegesInfoList.length == 0) {
        print("no college 11 data education");
        frameNo = frameNo - 1;
      }
      //if (frameNo == 3 && (!_mPublicProfileDataModel.result.isAccomplishment || narrativeListLocalAll.length == 0)) {
      if (frameNo == 3 && !isShowChart) {
        print("no spider data");
        frameNo = frameNo - 2;
      }
    }

    isBackPressed = true;

    if (frameNo == 4 || frameNo == 5) {
      setState(() {
        collegeCurrentPage = 0;
        currentPage = 0;
      });
    }

    switch (frameNo) {
      case 0:
        // First Frame Left to right
        //Apurva Dabade
        timerScheduleForNavigation(timeFrameFirst);
        _animation = Tween(begin: 0.3, end: 1.0).animate(CurvedAnimation(
          parent: _profilePictureControllerGone,
          curve: Curves.fastOutSlowIn,
        ));
        _profilePictureControllerGone.forward();

        spideChartAnimationController.stop(canceled: true);
        _spiderChartTextBodyController.stop(canceled: true);

        spideChartAnimationController.stop(canceled: true);
        _thankYouTextBodyController.stop(canceled: true);
        visible = true;

        break;
      case 1:
        // About Me
        if ((_mPublicProfileDataModel.result.summary == null ||
                _mPublicProfileDataModel.result.summary == "null") &&
            !isShowVideoSlide) {
          frameNo = frameNo - 1;
           timerScheduleForNavigation(timeFrameFirst);
            visible = true;
        }
        else{
 timerScheduleForNavigation(timeFrameAboutMe);
        visible = false;
        }
       

        if (!isShowVideoSlide) {
          _profilePictureControllerGone.reverse();
        } else {
          _animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
            parent: _profileVideoController,
            curve: Curves.fastOutSlowIn,
          ));
          _profileVideoController.forward();
        }
        _frame2BodyController.value = 1.0;

        _spiderChartTextBodyController.stop();
        _spiderChartTextBodyController.value = 1.0;

        break;
      case 2:
        // For Frame 3 change background first
        timerScheduleForNavigation(timeFrameSpider);
        print("Canceld Spider chart");
        _frame2BodyController.stop();
        _spiderChartTextBodyController.stop(canceled: true);

        break;

      case 3:
        // For Frame 4 change background first
        timerScheduleForNavigation(timeFrameBarGraph);
        print("Canceld bar graph chart");
        _frame2BodyController.stop();
        //_spiderChartTextBodyController.stop(canceled: true);
        break;

      //common case will execute for case 4 5 6
      case 4:
        timerScheduleForNavigation(timeFrameCollege);
        setState(() {
          narrativeCount = 0;
          acheivementListCount = 0;
        });
        break;
      case 5:
        timerScheduleForNavigation(timeFrameSchool);
        setState(() {
          narrativeCount = 0;
          acheivementListCount = 0;
        });
        break;
      case 6:
        //.Education Page view
        setState(() {
          _current = 0;
          narrativeCount = 0;
          acheivementListCount = 0;
        });
        timerScheduleForNavigation(timeFrameTestScore);
        break;

      //common case will execute for case 7 8 9 10 11 12 13 14
      //case 7:
      case 8:
      case 9:
      case 10:
      case 11:
        timerScheduleForNavigation(mainSlideDuration);
        setState(() {
          reccomendationListCount = 0;
        });
        break;
      case 12:
        timerScheduleForNavigation(timeFrameCertificates);
        setState(() {
          reccomendationListCount = 0;
        });
        break;
      case 13:
        //case 14:
        timerScheduleForNavigation(timeFrameBadges);
        setState(() {
          reccomendationListCount = 0;
        });
        break;

      case 15:
        // Thank You Screen
        //_thankYouTextBodyController.stop(canceled: true);
        stopConfetti();
        break;
    }

    setState(() {
      showFrame2BodyText();
    });
  }

  // SHare ICon
  String shareName = "", shareEmail = "", shareLastName = "";

  showConformationDialogNew() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 200.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                "Do you really want to switch?",
                                                textAlign: TextAlign.center,
                                                maxLines: 5,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    height: 1.2,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                            ]),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "No",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color:
                                                  ColorValues.GREY_TEXT_COLOR,
                                              fontSize: 16.0,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop('dialog');
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "Yes",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 16.0,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.pop(context);
                                          SystemChrome
                                              .setPreferredOrientations([
                                            DeviceOrientation.portraitUp,
                                            DeviceOrientation.portraitDown,
                                          ]);
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");
      AutoOrientation.portraitAutoMode();
      Navigator.pop(context);
      Navigator.pop(context);
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  void setDataForWorldCloud() {
    print('inside setDataForWorldCloud::');
    if (narrativeListLocalAll != null)
      print('inside setDataForWorldCloud:: ${narrativeListLocalAll.length}');
    widgets = <Widget>[];
    for (var i = 0; i < narrativeListLocalAll.length; i++) {
      double textFont = 0.0;
      textFont =
          20.0 + (3 * narrativeListLocalAll[i].achievement.length.toDouble());
      if (textFont > 38.0) {
        textFont = 38.0;
      }

      widgets.add(ScatterItemnew(narrativeListLocalAll[i], textFont));
    }
    setState(() {
      widgets;
      //_mAcoomplismentDataModel;
    });
  }

  void setDataForWorldCloudOld() {
    print('inside setDataForWorldCloud::');
    if (narrativeListLocal != null)
      print('inside setDataForWorldCloud:: ${narrativeListLocal.length}');
    widgets = <Widget>[];
    for (var i = 0; i < narrativeListLocal.length; i++) {
      double textFont = 0.0;
      textFont =
          20.0 + (3 * narrativeListLocal[i].achievement.length.toDouble());
      if (textFont > 38.0) {
        textFont = 38.0;
      }

      widgets.add(ScatterItemnew(narrativeListLocal[i], textFont));
    }
    setState(() {
      widgets;
      //_mAcoomplismentDataModel;
    });
  }

  int getLenthOfName() {
    int lenght = 0;
    if (_mPublicProfileDataModel.result == null) {
      return 0;
    } else {
      if (_mPublicProfileDataModel.result.lastName == null ||
          _mPublicProfileDataModel.result.lastName == "" ||
          _mPublicProfileDataModel.result.lastName == "null") {
        lenght = 0;
      } else {
        lenght = _mPublicProfileDataModel.result.firstName.length +
            _mPublicProfileDataModel.result.lastName.length;
      }
    }

    return lenght;
  }

  //---------- presoview methods end----------------------------

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      //  var formatter =   DateFormat('MMM dd, yyyy');
      //return formatter.format(new DateTime.now());
      return "Ongoing";
    }
  }

  getGoalsViewNew() {
    if (_mPublicProfileDataModel.result != null &&
        _mPublicProfileDataModel.result.goalInterests != null) {
      return Center(
        child: Container(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5.0),
            child: SingleChildScrollView(
              child: Wrap(
                // mainAxisAlignment: MainAxisAlignment.center,
                // crossAxisAlignment: CrossAxisAlignment.center,
                runSpacing: 1,
                spacing: 1,
                alignment: WrapAlignment.center,
                children: List.generate(
                    _mPublicProfileDataModel.result.goalInterests.length,
                    (index2) {
                  // if (index2 % 2 == 0) {
                  //   if (scoreBgColor == '0xFFFAFAFA')
                  //     scoreBgColor = '0xFFF3F1F3';
                  //   else
                  //     scoreBgColor = '0xFFFAFAFA';
                  // }

                  return Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Container(
                      width: 290,
                      height: 70,
                      child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            image: DecorationImage(
                              image: AssetImage(
                                  "assets/preso_view_new/bg_goal.png"),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: PaddingWrap.paddingfromLTRB(
                              18.0,
                              0.0,
                              18.0,
                              0.0,
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                //crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 8.0),
                                      child: Text(
                                        '${_mPublicProfileDataModel.result.goalInterests[index2].name}',
                                        style: TextStyle(
                                            color: Color(0xFFFFFFFF),
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 22.0,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    flex: 1,
                                  ),
                                  Image.asset(
                                    "assets/preso_view_new/blue_logo.png",
                                    width: 50,
                                    height: 50,
                                  )
                                ],
                              ))),
                    ),
                  );
                }),
              ),
            ),
          ),
        ),
      );
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  getGoalsView() {
    if (_mPublicProfileDataModel.result != null &&
        _mPublicProfileDataModel.result.goalInterests != null) {
      return Container(
        child: Padding(
          padding: const EdgeInsets.only(left: 38.0, right: 38),
          child: ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: _mPublicProfileDataModel.result.goalInterests.length,
            itemBuilder: (context, index) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 4.0, vertical: 4.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(right: 12.0),
                      child: Container(
                        width: 8.0,
                        height: 8.0,
                        margin: EdgeInsets.symmetric(
                            vertical: 0.0, horizontal: 0.0),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    Text(
                      '${_mPublicProfileDataModel.result.goalInterests[index].name}',
                      overflow: TextOverflow.clip,
                      style: TextStyle(
                        fontSize: 24.0,
                        fontFamily: Constant.customRegular,
                        color: ColorValues.RADIO_BLACK,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      );
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  pagerViewForGridAutoScrollTestScore() {
    if (_mPublicProfileDataModel.result.testScores != null &&
        _mPublicProfileDataModel.result.testScores.length > 0) {
      print(
          'inside pagerViewForGridAutoScrollTestScore _mPublicProfileDataModel.result.testScores size:: ${_mPublicProfileDataModel.result.testScores.length}');
      return Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Center(
            child: CarouselSlider.builder(
              //physics: NeverScrollableScrollPhysics(),
              //scrollDirection: Axis.horizontal,
              //shrinkWrap: true,
              //controller: _controller,
              itemCount: _mPublicProfileDataModel.result.testScores.length,
              options: CarouselOptions(
                //height: 227,
                height: double.infinity - 80,
                //aspectRatio: 16/9,
                viewportFraction: 1.0,
                initialPage: 0,
                enableInfiniteScroll: false,
                reverse: false,
                autoPlay: true,
                autoPlayInterval: Duration(seconds: mainSlideDuration),
                autoPlayAnimationDuration: Duration(milliseconds: 800),
                autoPlayCurve: Curves.fastOutSlowIn,
                //enlargeCenterPage: true,
                //onPageChanged: callbackFunction,
                scrollDirection: Axis.horizontal,
                pauseAutoPlayOnTouch: true,

                onPageChanged: (index, reason) {
                  setState(() {
                    _current = index;
                  });
                },
              ),
              itemBuilder: (context, index) {
                return Container(
                  child: Stack(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 0.0, bottom: 45.0, left: 0.0, right: 0.0),
                        child: Scrollbar(
                          isAlwaysShown: true,
                          controller: _controllerTestScroll,
                          child: SingleChildScrollView(
                            controller: _controllerTestScroll,
                            child: Container(
                              /*decoration:   BoxDecoration(
                      border:   Border.all(color: ColorValues.SCREEN_BG_COLOR,),
                      color: ColorValues.SCREEN_BG_COLOR,
                      borderRadius: BorderRadius.circular(5),
                    ),*/
                              padding: const EdgeInsets.only(
                                  top: 8.0,
                                  bottom: 12.0,
                                  left: 14.0,
                                  right: 8.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.all(0.0),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 0.0, bottom: 5),
                                          child: Text(
                                            _mPublicProfileDataModel.result
                                                        .testScores.length >
                                                    0
                                                ? _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .name
                                                : "",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.w600,
                                                fontFamily:
                                                    Constant.customRegular,
                                                color: ColorValues.WHITE),
                                          ),
                                        ),
                                        getTestScoreGridItem(index),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Positioned(
            bottom: 12.0,
            left: 0.0,
            right: 0.0,
            child: _mPublicProfileDataModel.result.testScores.length > 1
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children:
                        _mPublicProfileDataModel.result.testScores.map((url) {
                      int index = _mPublicProfileDataModel.result.testScores
                          .indexOf(url);
                      return Padding(
                        padding: EdgeInsets.only(
                            right: _mPublicProfileDataModel
                                            .result.testScores.length -
                                        1 !=
                                    index
                                ? 8
                                : 0.0),
                        child: Container(
                          width: 8.0,
                          height: 8.0,
                          margin: EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 2.0),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _current == index
                                ? Color.fromRGBO(255, 255, 255, 1)
                                : Color.fromRGBO(196, 196, 196, 1),
                          ),
                        ),
                      );
                    }).toList(),
                  )
                : Container(
                    width: 0.0,
                    height: 0.0,
                  ),
          ),
        ],
      );
    } else
      return Container();
  }

  Container getTestScoreGridItemOld(index) {
    return Container(
        //color: Colors.white,
        child: PaddingWrap.paddingfromLTRB(
            17.0,
            0.0,
            13.0,
            0.0,
            Column(
                children: List.generate(
                    _mPublicProfileDataModel
                        .result.testScores[index].scores.length, (index3) {
              String scoreBgColor = '0xFFF3F1F3';
              print('apurva testscore index3::: $index3');
              return /*!_mPublicProfileDataModel
                      .result.testScores[index].scores[index3].isProfileDisplay  //&& index3 != 0
                      ?   Container(
                    height: 0.0,
                  )
                      : */
                  Container(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    Container(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                            padding: EdgeInsets.only(top: 5.0),
                            child: Text(
                              getConvertedDateStamp2(_mPublicProfileDataModel
                                  .result
                                  .testScores[index]
                                  .scores[index3]
                                  .dateTaken
                                  .toString()),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: Constant.customRegular,
                                  color: ColorValues.RADIO_BLACK),
                            )),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 15.0),
                          child: Wrap(
                            runSpacing: 1,
                            spacing: 1,
                            alignment: WrapAlignment.center,
                            children: List.generate(
                                _mPublicProfileDataModel
                                    .result
                                    .testScores[index]
                                    .scores[index3]
                                    .subjects
                                    .length, (index2) {
                              print(
                                  'test score sub length:: ${_mPublicProfileDataModel.result.testScores[index].scores[index3].subjects.length}');

                              if (index2 % 2 == 0) {
                                if (scoreBgColor == '0xFFFAFAFA')
                                  scoreBgColor = '0xFFF3F1F3';
                                else
                                  scoreBgColor = '0xFFFAFAFA';
                              }

                              return Container(
                                width: 293,
                                height: 40,
                                child: Container(
                                    color: Color(int.parse(scoreBgColor)),
                                    child: PaddingWrap.paddingfromLTRB(
                                        18.0,
                                        0.0,
                                        18.0,
                                        0.0,
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          //crossAxisAlignment: CrossAxisAlignment.center,
                                          children: <Widget>[
                                            Expanded(
                                              child: Text(
                                                _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .scores[index3]
                                                    .subjects[index2]
                                                    .subject,
                                                style: TextStyle(
                                                    color: Color(0xFF404040),
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0),
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 8.0),
                                                child: Text(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .testScores[index]
                                                      .scores[index3]
                                                      .subjects[index2]
                                                      .score
                                                      .toString(),
                                                  style: TextStyle(
                                                      color: Color(0XFF151515),
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontSize: 16.0,
                                                      fontWeight:
                                                          FontWeight.w700),
                                                ),
                                              ),
                                              flex: 0,
                                            )
                                          ],
                                        ))),
                              );
                            }),
                          ),
                        ),
                      ],
                    ))),
              );
            }))));
  }

  Container getTestScoreGridItem(index) {
    return Container(
        //color: Colors.white,
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            13.0,
            0.0,
            Column(
                children: List.generate(1, (index3) {
              String scoreBgColor = '0xFFF3F1F3';
              return
                  Container(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    Container(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                            padding: EdgeInsets.only(top: 5.0),
                            child: Text(
                              getConvertedDateStamp2(_mPublicProfileDataModel
                                  .result
                                  .testScores[index]
                                  .scores[index3]
                                  .dateTaken
                                  .toString()),
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: Constant.customRegular,
                                  color: ColorValues.pressotitle),
                            )),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5.0),
                          child: Wrap(
                            runSpacing: 1,
                            spacing: 1,
                            alignment: WrapAlignment.center,
                            children: List.generate(
                                _mPublicProfileDataModel
                                    .result
                                    .testScores[index]
                                    .scores[index3]
                                    .subjects
                                    .length, (index2) {
                              print(
                                  'test score sub length:: ${_mPublicProfileDataModel.result.testScores[index].scores[index3].subjects.length}');

                              if (index2 % 2 == 0) {
                                if (scoreBgColor == '0xFFFAFAFA')
                                  scoreBgColor = '0xFFF3F1F3';
                                else
                                  scoreBgColor = '0xFFFAFAFA';
                              }

                              return Padding(
                                padding: const EdgeInsets.fromLTRB(0,10.0,20.0,10.0),
                                child: Container(
                                  width: 293,
                                  height: 70,
                                  child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)),
                                        image: DecorationImage(
                                          image: AssetImage(
                                              "assets/preso_view_new/score_background.png"),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      child: PaddingWrap.paddingfromLTRB(
                                          18.0,
                                          0.0,
                                          18.0,
                                          0.0,
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            //crossAxisAlignment: CrossAxisAlignment.center,
                                            children: <Widget>[
                                              Expanded(
                                                child: Text(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .testScores[index]
                                                      .scores[index3]
                                                      .subjects[index2]
                                                      .subject,
                                                  style: TextStyle(
                                                      color: Color(0xFFFFFFFF),
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontSize: 16.0),
                                                ),
                                                flex: 1,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: Text(
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .testScores[index]
                                                        .scores[index3]
                                                        .subjects[index2]
                                                        .score
                                                        .toString(),
                                                    style: TextStyle(
                                                        color:
                                                            Color(0xFFFFFFFF),
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                        fontSize: 32.0,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                  ),
                                                ),
                                                flex: 0,
                                              )
                                            ],
                                          ))),
                                ),
                              );
                            }),
                          ),
                        ),
                      ],
                    ))),
              );
            },
                ),
            ),
        ),
    );
  }

  getGoalsViewInstituteNew() {
    if (_mPublicProfileDataModel.result != null &&
        _mPublicProfileDataModel.result.goalInterestInstitute != null &&
        _mPublicProfileDataModel.result.goalInterestInstitute != 'null' &&
        _mPublicProfileDataModel.result.goalInterestInstitute != '') {
      return Container(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 50),
          child: SingleChildScrollView(
            child: Wrap(
              // mainAxisAlignment: MainAxisAlignment.center,
              // crossAxisAlignment: CrossAxisAlignment.center,
              runSpacing: 1,
              spacing: 1,
              alignment: WrapAlignment.center,
              children: List.generate(1,
                  // _mPublicProfileDataModel.result.goalInterestInstitute.length, check for data, not list getting
                  (index2) {
                // if (index2 % 2 == 0) {
                //   if (scoreBgColor == '0xFFFAFAFA')
                //     scoreBgColor = '0xFFF3F1F3';
                //   else
                //     scoreBgColor = '0xFFFAFAFA';
                // }

                return Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: Container(
                    width: 290,
                    height: 75,
                    child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          image: DecorationImage(
                            image:
                                AssetImage("assets/preso_view_new/bg_goal.png"),
                            fit: BoxFit.cover,
                          ),
                        ),
                        child: PaddingWrap.paddingfromLTRB(
                            18.0,
                            0.0,
                            18.0,
                            0.0,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              //crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Text(
                                      '${_mPublicProfileDataModel.result.goalInterestInstitute}',
                                      style: TextStyle(
                                          color: ColorValues.pressotitle,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Image.asset(
                                  "assets/preso_view_new/target_flag.png",
                                  width: 50,
                                  height: 50,
                                )
                              ],
                            ))),
                  ),
                );
              }),
            ),
          ),
        ),
      );
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  getGoalsViewInstitute() {
    if (_mPublicProfileDataModel.result != null &&
        _mPublicProfileDataModel.result.goalInterestInstitute != null &&
        _mPublicProfileDataModel.result.goalInterestInstitute != 'null' &&
        _mPublicProfileDataModel.result.goalInterestInstitute != '') {
      return Container(
          child: Padding(
        padding: const EdgeInsets.only(left: 38.0, right: 38),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // PaddingWrap.paddingfromLTRB(
            //     0.0,
            //     0.0,
            //     0.0,
            //     0.0,
            //     TextViewWrap.textViewSingleLine(
            //         "My Target Institutes",
            //         TextAlign.start,
            //         ColorValues.HEADING_COLOR_EDUCATION,
            //         28.0,
            //         FontWeight.bold)),
            PaddingWrap.paddingfromLTRB(
                0.0,
                24.0, //34
                0.0,
                0.0,
                TextViewWrap.textViewSingleLine(
                    "${_mPublicProfileDataModel.result.goalInterestInstitute}",
                    TextAlign.start,
                    ColorValues.HEADING_COLOR_EDUCATION,
                    24.0,
                    FontWeight.normal)),
          ],
        ),
      ));
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  getLoveAndOtherInterest() {
    if (_mPublicProfileDataModel.result != null &&
        loveInterestList != null &&
        loveInterestList.length > 0) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40.0, vertical: 0.0),
        child: Center(
          child: Container(
            //color: Colors.redAccent,
            child: MediaQuery.removePadding(
              context: context,
              removeTop: true,
              removeBottom: true,
              child: ListView(
                //physics: const NeverScrollableScrollPhysics(),
                primary: true,
                shrinkWrap: true,
                children: <Widget>[
                  Center(
                    child: Wrap(
                      spacing: 24.0,
                      runSpacing: 0.0,
                      alignment: WrapAlignment.center,
                      children: List<Widget>.generate(loveInterestList.length,
                          // place the length of the array here
                          (int index) {
                        //int h = _items[index].name.toString().length % 36;
                        //print('Height h:::: $h');
                        print(
                            "inside skills getLoveAndOtherInterest loveInterestList.name.... ${loveInterestList[index].name}");
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 20.0),
                          child: InputChip(
                            avatar: CircleAvatar(
                              backgroundColor: Colors.transparent,
                              child: CachedNetworkImage(
                                height: 25,
                                width: 25,
                                imageUrl: Constant.IMAGE_PATH +
                                    loveInterestList[index].image,
                                fit: BoxFit.fitHeight,
                                placeholder: (context, url) {
                                  return Center(
                                      child: Container(
                                    height: 25,
                                    width: 25,
                                    color: Colors.transparent,
                                  ));
                                },
                                errorWidget: (context, url, error) => _errorn(
                                    "assets/profile/img_default.png", 25, 25),
                              ),
                            ),
                            label: Text(
                              '${loveInterestList[index].name}',
                              overflow: TextOverflow.clip,
                              style: TextStyle(
                                  color: ColorValues.HEADING_COLOR_EDUCATION,
                                  fontSize: 16,
                                  fontFamily: Constant.customRegular,
                                  fontWeight: FontWeight.w700),
                            ),
                            // softWrap: true,maxLines: 100,
                            //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            backgroundColor: Color(0xffF1F3F1),
                            shape: StadiumBorder(
                              side: BorderSide(
                                color: ColorValues.WHITE,
                                width: 1.0,
                              ),
                            ),

                            onSelected: (bool value) {},

                            labelStyle: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontSize: 16,
                                fontFamily: Constant.customRegular,
                                fontWeight: FontWeight.w700),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20.0, vertical: 10.0),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  getSkillsViewNew() {
    if (_mPublicProfileDataModel.result != null &&
        skillsList != null &&
        skillsList.length > 0) {
      return Container(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 5.0,
          ),
          child: SingleChildScrollView(
            child: Wrap(
              // mainAxisAlignment: MainAxisAlignment.center,
              // crossAxisAlignment: CrossAxisAlignment.center,
              runSpacing: 1,
              spacing: 1,
              alignment: WrapAlignment.center,
              children: List.generate(skillsList.length, (index2) {
                // if (index2 % 2 == 0) {
                //   if (scoreBgColor == '0xFFFAFAFA')
                //     scoreBgColor = '0xFFF3F1F3';
                //   else
                //     scoreBgColor = '0xFFFAFAFA';
                // }

                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Container(
                    width: 210,
                    height: 45,
                    child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          image: DecorationImage(
                            image: AssetImage(
                                "assets/preso_view_new/skills_bg.png"),
                            fit: BoxFit.cover,
                          ),
                        ),
                        child: Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              // Expanded(
                              //   child:
                              Text(
                                '${skillsList[index2].name}',
                                style: TextStyle(
                                    color: Color(0xFFFFFFFF),
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.w600),
                              ),
                              //   flex: 1,
                              // ),
                              // Image.asset(
                              //   "assets/preso_view_new/blue_logo.png",
                              //   width: 50,
                              //   height: 50,
                              // )
                            ],
                          ),
                        )),
                  ),
                );
              }),
            ),
          ),
        ),
      );
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  getSkillsColorCircles() {
    if (_mPublicProfileDataModel.result != null &&
        skillsList != null &&
        skillsList.length > 0) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40.0, vertical: 0.0),
        child: Center(
          child: Container(
            //color: Colors.redAccent,
            child: MediaQuery.removePadding(
              context: context,
              removeTop: true,
              removeBottom: true,
              child: ListView(
                //physics: const NeverScrollableScrollPhysics(),
                primary: true,
                shrinkWrap: true,
                children: <Widget>[
                  Center(
                    child: Wrap(
                      spacing: 45.0, //50
                      runSpacing: 0.0,
                      alignment: WrapAlignment.center,
                      children: List<Widget>.generate(skillsList.length,
                          // place the length of the array here
                          (int index) {
                        //int h = _items[index].name.toString().length % 36;
                        //print('Height h:::: $h');

                        Color
                            circleOutlineColor; // = ColorValues.randomColor();
                        int colorNo = index % 7;

                        switch (colorNo) {
                          case 0:
                            circleOutlineColor = ColorValues.circle1;
                            break;
                          case 1:
                            circleOutlineColor = ColorValues.circle2;
                            break;
                          case 2:
                            circleOutlineColor = ColorValues.circle3;
                            break;
                          case 3:
                            circleOutlineColor = ColorValues.circle4;
                            break;
                          case 4:
                            circleOutlineColor = ColorValues.circle5;
                            break;
                          case 5:
                            circleOutlineColor = ColorValues.circle6;
                            break;
                          case 6:
                            circleOutlineColor = ColorValues.circle7;
                            break;
                        }

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 20.0),
                          child: ClipOval(
                            child: Container(
                              /*width: 115,
                                  height: 115,*/
                              width: 118,
                              height: 118,
                              color: circleOutlineColor,
                              child: Center(
                                child: Padding(
                                    padding: const EdgeInsets.all(0.0),
                                    child: ClipOval(
                                      child: Container(
                                          /*width: 110,
                                              height: 110,*/
                                          width: 113,
                                          height: 113,
                                          color: Color(0xffF1F3F1),
                                          child: Center(
                                            child: Text(
                                              '${skillsList[index].name}',
                                              overflow: TextOverflow.clip,
                                              softWrap: true,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontSize: 14.0,
                                                  fontFamily:
                                                      Constant.customRegular,
                                                  fontWeight: FontWeight.w700),
                                            ),
                                          )),
                                    )),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } else
      return Container(
        width: 0,
        height: 0,
        //color: Colors.amber,
      );
  }

  pagerViewForGridAutoScrollSchoolScore() {
    if (schoolsInfoList != null && schoolsInfoList.length > 0) {
      print(
          'inside pagerViewForGridAutoScrollTestScore schoolsInfoList size:: ${schoolsInfoList.length}');
      return Stack(
        fit: StackFit.expand,
        children: <Widget>[
          CarouselSlider.builder(
            //physics: NeverScrollableScrollPhysics(),
            //scrollDirection: Axis.horizontal,
            //shrinkWrap: true,
            //controller: _controller,
            itemCount: schoolsInfoList.length,
            options: CarouselOptions(
              //height: 227,
              height: double.infinity - 200,
              //aspectRatio: 16/9,
              viewportFraction: 0.2,
              initialPage: 0,
              enableInfiniteScroll: false,
              reverse: false,
              autoPlay: true,
              autoPlayInterval: Duration(seconds: 2),
              autoPlayAnimationDuration: Duration(milliseconds: 800),
              autoPlayCurve: Curves.fastOutSlowIn,
              //enlargeCenterPage: true,
              //onPageChanged: callbackFunction,
              scrollDirection: Axis.horizontal,
              pauseAutoPlayOnTouch: true,

              onPageChanged: (index, reason) {
                setState(() {
                  _current = index;
                });
              },
            ),
            itemBuilder: (context, index) {
              double scale = 1;
              if (_current != index) {
                scale = 0.6;
              }
              return Center(
                  child: Container(
                child: Stack(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 0.0, bottom: 45.0, left: 0.0, right: 0.0),
                      child: Center(
                        child: Align(
                            alignment: Alignment.center,
                            child: Stack(
                              children: <Widget>[
                                Container(
                                  //margin: EdgeInsets.only(bottom: 10),
                                  height: PAGER_HEIGHT * scale,
                                  width: PAGER_HEIGHT * scale,
                                  //color: Colors.redAccent,
                                  child: Card(
                                      elevation: 4,
                                      clipBehavior: Clip.antiAlias,
                                      //color: Colors.transparent,
                                      shape: CircleBorder(
                                          side: BorderSide(
                                              color: Colors.transparent,
                                              width: 5)),
                                      child: Stack(
                                        children: <Widget>[
                                          FadeInImage.assetNetwork(
                                            fit: BoxFit.cover,
                                            height: PAGER_HEIGHT * scale,
                                            width: PAGER_HEIGHT * scale,
                                            placeholder:
                                                'assets/profile/img_default.png',
                                            image: Constant.IMAGE_PATH +
                                                schoolsInfoList[index].logo,
                                          ),
                                          _current != index
                                              ? Container(
                                                  color: Colors.white
                                                      .withOpacity(0.6))
                                              : Container(
                                                  color: Colors.transparent)
                                        ],
                                      )),
                                ),
                              ],
                            )),
                      ),
                    ),
                  ],
                ),
              ));
            },
          ),
          Positioned(
            bottom: 12.0,
            left: 0.0,
            right: 0.0,
            child: schoolsInfoList.length > 1
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      //_current < schoolsInfoList.length ?
                      Padding(
                        padding: const EdgeInsets.only(
                            bottom: 15.0, left: 5, right: 5, top: 15),
                        child: Column(
                          children: <Widget>[
                            Text(
                              schoolsInfoList.length > 0
                                  ? schoolsInfoList[_current].institute
                                  : "",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 30,
                                  fontFamily: Constant.customRegular),
                            ),
                            Padding(
                                padding: EdgeInsets.only(top: 5.0),
                                child: Text(
                                  schoolsInfoList.length > 0
                                      ? schoolsInfoList[_current].fromYear +
                                          " - " +
                                          (schoolsInfoList[_current]
                                                          .toYear ==
                                                      "null" ||
                                                  schoolsInfoList[_current]
                                                          .toYear ==
                                                      ""
                                              ? "Ongoing"
                                              : schoolsInfoList[_current]
                                                  .toYear) +
                                          " | " +
                                          schoolsInfoList[_current].fromGrade +
                                          " - " +
                                          schoolsInfoList[_current].toGrade +
                                          ((_mPublicProfileDataModel
                                                      .result.isGpa &&
                                                  schoolsInfoList[_current]
                                                          .gpa !=
                                                      null &&
                                                  schoolsInfoList[_current]
                                                          .gpa !=
                                                      '')
                                              ? " | GPA: " +
                                                  schoolsInfoList[_current]
                                                      .gpa
                                                      .toString()
                                              : '')
                                      : "",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 17,
                                      fontFamily: Constant.customRegular),
                                )),
                          ],
                        ),
                      )
                      //  : Container(),
                    ],
                  )
                : Container(
                    width: 0.0,
                    height: 0.0,
                  ),
          ),
        ],
      );
    } else
      return Container();
  }

  pagerViewForGridAutoScrollCertificate() {
    //bool isAutoPlay = true;
    if (certificationtList != null && certificationtList.length > 0) {
      print(
          'inside pagerViewForGridAutoScrollCertificate certificationtList size:: ${certificationtList.length}');
      /*return SizedBox(
        // you may want to use an aspect ratio here for tablet support
        height: 227,
        child: PageView.builder(
          // store this controller in a State to save the carousel scroll position
          controller: PageController(viewportFraction: 0.35),
          itemBuilder: (BuildContext context, int itemIndex) {
            return _buildCarouselItem(context, carouselIndex, itemIndex);
          },
        ),
      );*/

      int _index = 0;
      int _time = internalSlideDuration2;
      bool isAutoPlay = true;
      /*if(certificationtList.length <= 2) {
        _time = 4;
        isAutoPlay = false;
      }
      else if(certificationtList.length == 1) {
        _time = 8;
        isAutoPlay = false;
      }*/

      if (certificationtList.length <= 2) {
        return Container(
          height: 227, //(9 / 16) * screenWidth,
          //width: 211,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: certificationtList.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 12.0, right: 12.0),
                child: Container(
                  height: 227,
                  //(9 / 16) * screenWidth,
                  width: 211,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: ColorValues.LIST_BOTTOM_BG,
                    ),
                    color: ColorValues.LIST_BOTTOM_BG,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  padding: const EdgeInsets.only(
                      top: 8.0, bottom: 12.0, left: 8.0, right: 8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(0.0),
                          child: Column(
                            children: <Widget>[
                              CachedNetworkImage(
                                height: 140,
                                width: 195,
                                imageUrl: Constant.IMAGE_PATH +
                                    certificationtList[index].image,
                                fit: BoxFit.contain,
                                /*placeholder: (context, url) => _loader(
                      context,
                      "assets/aerial/default_img.png",
                      double.infinity,
                      double.infinity),*/
                                placeholder: (context, url) {
                                  return Center(
                                      child: Container(
                                    height: 140,
                                    width: 195,
                                    color: Colors.black,
                                  ));
                                },
                                errorWidget: (context, url, error) => _errorn(
                                    "assets/newDesignIcon/userprofile/add_certificate.png",
                                    195,
                                    140),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  certificationtList.length > 0
                                      ? certificationtList[index].title
                                      : "",
                                  textAlign: TextAlign.center,
                                  softWrap: true,
                                  maxLines: 2,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontFamily: Constant.customRegular,
                                      fontWeight: FontWeight.bold,
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION),
                                ),
                              ),
                              Padding(
                                  padding: EdgeInsets.only(top: 5.0),
                                  child: Text(
                                    certificationtList.length > 0
                                        ? "Issued on: ${Util.getConvertedDateStamp(certificationtList[index].date.toString())}"
                                        : "",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontFamily: Constant.customRegular,
                                        fontWeight: FontWeight.bold,
                                        color:
                                            ColorValues.presoCertificationDate),
                                  ))
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      } else {
        setState(() {});
        return CarouselSlider.builder(
          //physics: NeverScrollableScrollPhysics(),
          //scrollDirection: Axis.horizontal,
          //shrinkWrap: true,
          //controller: _controller,
          itemCount: certificationtList.length,
          carouselController: _certificateCarouselController,

          options: CarouselOptions(
            height: 227,
            //aspectRatio: 16/9,
            viewportFraction: 0.35,
            initialPage: _firstPage,
            enableInfiniteScroll: false,
            reverse: false,
            autoPlay: isAutoPlay,
            autoPlayInterval: Duration(seconds: _time),
            autoPlayAnimationDuration: Duration(milliseconds: 800),
            autoPlayCurve: Curves.fastOutSlowIn,
            //enlargeCenterPage: true,
            //onPageChanged: callbackFunction,
            scrollDirection: Axis.horizontal,
            pauseAutoPlayOnTouch: true,
            /*onPageChanged: (index, reason) {
              setState(() {
                return _index = index;
              });
            },*/
          ),
          itemBuilder: (context, index) {
            /*if(index == certificationtList.length - 1){
            isAutoPlay = false;
          }*/
            return Container(
              //height: 227,//(9 / 16) * screenWidth,
              width: 211, //screenWidth,
              child: Stack(
                children: <Widget>[
                  Positioned(
                    top: 0.0,
                    left: 0.0,
                    right: 0.0,
                    bottom: 0.0,
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: ColorValues.LIST_BOTTOM_BG,
                        ),
                        color: ColorValues.LIST_BOTTOM_BG,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      padding: const EdgeInsets.only(
                          top: 8.0, bottom: 12.0, left: 8.0, right: 8.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.all(0.0),
                              child: Column(
                                children: <Widget>[
                                  CachedNetworkImage(
                                    height: 140,
                                    width: 195,
                                    imageUrl: Constant.IMAGE_PATH +
                                        certificationtList[index].image,
                                    fit: BoxFit.contain,
                                    /*placeholder: (context, url) => _loader(
                    context,
                    "assets/aerial/default_img.png",
                    double.infinity,
                    double.infinity),*/
                                    placeholder: (context, url) {
                                      return Center(
                                          child: Container(
                                        height: 140,
                                        width: 195,
                                        color: Colors.black,
                                      ));
                                    },
                                    errorWidget: (context, url, error) => _errorn(
                                        "assets/newDesignIcon/userprofile/add_certificate.png",
                                        195,
                                        140),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 8.0),
                                    child: Text(
                                      certificationtList.length > 0
                                          ? certificationtList[index].title
                                          : "",
                                      textAlign: TextAlign.center,
                                      softWrap: true,
                                      maxLines: 2,
                                      style: TextStyle(
                                          fontSize: 12,
                                          fontFamily: Constant.customRegular,
                                          fontWeight: FontWeight.bold,
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION),
                                    ),
                                  ),
                                  Padding(
                                      padding: EdgeInsets.only(top: 5.0),
                                      child: Text(
                                        certificationtList.length > 0
                                            ? "Issued on: ${Util.getConvertedDateStamp(certificationtList[index].date.toString())}"
                                            : "",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily: Constant.customRegular,
                                            fontWeight: FontWeight.bold,
                                            color: ColorValues
                                                .presoCertificationDate),
                                      ))
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      }
    } else
      return Container();
  }

  pagerViewForGridAutoScrollBadges() {
    if (badgesList != null && badgesList.length > 0) {
      print(
          'inside pagerViewForGridAutoScrollBadges badgesList size:: ${badgesList.length}');
      int _time = internalSlideDuration2;
      bool isAutoPlay = true;

      /*if(badgesList.length == 2){
        _time = 4;
        isAutoPlay = false;
      }
      else if(badgesList.length == 1) {
        _time = 8;
        isAutoPlay = false;
      }*/
      if (badgesList.length <= 2) {
        return Container(
          height: 200, //(9 / 16) * screenWidth,
          //width: 211,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: badgesList.length,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 12.0, right: 12.0),
                child: Container(
                  height: 200, //(9 / 16) * screenWidth,
                  width: 211, //screenWidth,
                  child: Stack(
                    children: <Widget>[
                      Positioned(
                        top: 0.0,
                        left: 0.0,
                        right: 0.0,
                        bottom: 0.0,
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: ColorValues.SCREEN_BG_COLOR,
                            ),
                            color: ColorValues.SCREEN_BG_COLOR,
                            borderRadius: BorderRadius.circular(5),
                          ),
                          padding: const EdgeInsets.only(
                              top: 8.0, bottom: 12.0, left: 8.0, right: 8.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(0.0),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      CachedNetworkImage(
                                        height: 100,
                                        width: 140,
                                        imageUrl: Constant.IMAGE_PATH +
                                            badgesList[index].image,
                                        fit: BoxFit.contain,
                                        /*placeholder: (context, url) => _loader(
                    context,
                    "assets/aerial/default_img.png",
                    double.infinity,
                    double.infinity),*/
                                        placeholder: (context, url) {
                                          return Center(
                                              child: Container(
                                            height: 100,
                                            width: 140,
                                            color: Colors.black,
                                          ));
                                        },
                                        errorWidget: (context, url, error) =>
                                            _errorn(
                                                "assets/profile/img_default.png",
                                                140,
                                                100),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            top: 10.0, bottom: 0.0),
                                        child: Text(
                                          badgesList.length > 0
                                              ? badgesList[index].name
                                              : "",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w700,
                                              fontFamily:
                                                  Constant.customRegular,
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1),
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(top: 0.0),
                                        child: Text(
                                          badgesList.length > 0
                                              ? badgesList[index].companyName
                                              : "",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 12,
                                              fontFamily:
                                                  Constant.customRegular,
                                              color: ColorValues.pressotitle,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ),
                                      Padding(
                                          padding: EdgeInsets.only(top: 4.0),
                                          child: Text(
                                            badgesList.length > 0
                                                ? badgesList[index].status ==
                                                        "created"
                                                    ? "Sent On: " +
                                                        "${Util.getConvertedDateStamp(badgesList[index].date.toString())}"
                                                    : "" +
                                                        "${Util.getConvertedDateStamp(badgesList[index].date.toString())}"
                                                : "",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w400,
                                                fontFamily:
                                                    Constant.customRegular,
                                                color: ColorValues.labelColor),
                                          ))
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      } else {
        setState(() {});
        return NotificationListener<ScrollNotification>(
          onNotification: (ScrollNotification notification) {
            if (notification is ScrollUpdateNotification) {}
          },
          child: CarouselSlider.builder(
            //physics: NeverScrollableScrollPhysics(),
            //scrollDirection: Axis.horizontal,
            //shrinkWrap: true,
            //controller: _controller,
            itemCount: badgesList.length,
            carouselController: _badgeCarouselController,
            options: CarouselOptions(
              height: 210,
              //aspectRatio: 16/9,
              viewportFraction: 0.35,
              initialPage: _firstPageBadge,
              enableInfiniteScroll: false,
              reverse: false,
              autoPlay: isAutoPlay,
              autoPlayInterval: Duration(seconds: _time),
              autoPlayAnimationDuration: Duration(milliseconds: 800),
              autoPlayCurve: Curves.fastOutSlowIn,
              //enlargeCenterPage: true,
              //onPageChanged: callbackFunction,
              scrollDirection: Axis.horizontal,
              pauseAutoPlayOnTouch: true,
            ),
            itemBuilder: (context, index) {
              return Container(
                //height: 227,//(9 / 16) * screenWidth,
                width: 211, //screenWidth,
                child: Stack(
                  children: <Widget>[
                    Positioned(
                      top: 0.0,
                      left: 0.0,
                      right: 0.0,
                      bottom: 0.0,
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: ColorValues.SCREEN_BG_COLOR,
                          ),
                          color: ColorValues.SCREEN_BG_COLOR,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        padding: const EdgeInsets.only(
                            top: 8.0, bottom: 12.0, left: 8.0, right: 8.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.all(0.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    CachedNetworkImage(
                                      height: 100,
                                      width: 140,
                                      imageUrl: Constant.IMAGE_PATH +
                                          badgesList[index].image,
                                      fit: BoxFit.contain,
                                      /*placeholder: (context, url) => _loader(
                      context,
                      "assets/aerial/default_img.png",
                      double.infinity,
                      double.infinity),*/
                                      placeholder: (context, url) {
                                        return Center(
                                            child: Container(
                                          height: 100,
                                          width: 140,
                                          color: Colors.black,
                                        ));
                                      },
                                      errorWidget: (context, url, error) =>
                                          _errorn(
                                              "assets/profile/img_default.png",
                                              140,
                                              100),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 10.0, bottom: 10.0),
                                      child: Text(
                                        badgesList.length > 0
                                            ? badgesList[index].name
                                            : "",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: Constant.customRegular,
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 0.0),
                                      child: Text(
                                        badgesList.length > 0
                                            ? badgesList[index].companyName
                                            : "",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily: Constant.customRegular,
                                            color: ColorValues.pressotitle,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    Padding(
                                        padding: EdgeInsets.only(top: 4.0),
                                        child: Text(
                                          badgesList.length > 0
                                              ? "${Util.getConvertedDateStamp(badgesList[index].date.toString())}"
                                              : "",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w400,
                                              fontFamily:
                                                  Constant.customRegular,
                                              color: ColorValues.labelColor),
                                        ))
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      }
    } else
      return Container();
  }

  pagerViewForGridAutoScrollRecommendations() {
    if (addedRecommendationtList != null &&
        addedRecommendationtList.length > 0) {
      print(
          'inside addedRecommendationtList.length sss size:: ${addedRecommendationtList.length}');
      int _time = internalSlideDuration2;
      bool isAutoPlay = true;

      /*if(badgesList.length == 2){
        _time = 4;
        isAutoPlay = false;
      }
      else if(badgesList.length == 1) {
        _time = 8;
        isAutoPlay = false;
      }*/
      // if (addedRecommendationtList.length <= 2) {

      //   return ListView.builder(
      //     scrollDirection: Axis.horizontal,
      //     itemCount: addedRecommendationtList.length,
      //     shrinkWrap: true,
      //     itemBuilder: (context, index) {
      //       return Stack(
      //         alignment: Alignment.center,
      //         overflow: Overflow.visible,
      //         children: [
      //           Column(
      //             children: [
      //               Container(
      //                 width: 450,
      //                 height: 115,
      //                 child: SingleChildScrollView(
      //                   child: Column(
      //                     mainAxisAlignment: MainAxisAlignment.center,
      //                     crossAxisAlignment: CrossAxisAlignment.start,
      //                     children: [
      //                       Padding(
      //                           padding: const EdgeInsets.fromLTRB(
      //                               15.0, 10.0, 10.0, 10.0),
      //                           child: Text(
      //                               addedRecommendationtList[index].stage ==
      //                                       "Requested"
      //                                   ? "" +
      //                                       addedRecommendationtList[index]
      //                                           .request
      //                                           .trim() +
      //                                       ""
      //                                   : "" +
      //                                       addedRecommendationtList[index]
      //                                           .recommendation
      //                                           .trim() +
      //                                       "",
      //                               textAlign: TextAlign.justify,
      //                               style: TextStyle(
      //                                   fontFamily: Constant.customRegular,
      //                                   fontSize: 14.0,
      //                                   fontWeight: FontWeight.w400,
      //                                   color: ColorValues
      //                                       .HEADING_COLOR_EDUCATION_1))),
      //                     ],
      //                   ),
      //                 ),
      //                 decoration: BoxDecoration(
      //                   border: GradientBorder.uniform(
      //                       width: 2.0,
      //                       gradient: LinearGradient(colors: <Color>[
      //                         ColorValues.BLUE_COLOR,
      //                         Colors.grey.withOpacity(0.1)
      //                       ], stops: [
      //                         0.9,
      //                         0.5
      //                       ])),
      //                   borderRadius:
      //                       const BorderRadius.all(Radius.circular(15)),
      //                 ),
      //               ),
      //               SizedBox(
      //                 height: 12,
      //               )
      //             ],
      //           ),
      //           Positioned(
      //             bottom: 0,
      //             child: InkWell(
      //                 radius: 50,
      //                 onTap: () {},
      //                 child: Container(
      //                   height: 35,
      //                   width: 280,
      //                   decoration: BoxDecoration(
      //                     color: ColorValues.HEADING_COLOR_EDUCATION_1,
      //                     border: Border.all(
      //                         color: ColorValues.HEADING_COLOR_EDUCATION_1),
      //                     borderRadius:
      //                         const BorderRadius.all(Radius.circular(10)),
      //                   ),
      //                   child: PaddingWrap.paddingfromLTRB(
      //                       10.0,
      //                       8.0,
      //                       10.0,
      //                       10.0,
      //                       Text(
      //                           addedRecommendationtList[index]
      //                                       .recommender[0]
      //                                       .firstName ==
      //                                   "null"
      //                               ? addedRecommendationtList[index].title
      //                               : addedRecommendationtList[index]
      //                                           .recommender[0]
      //                                           .lastName ==
      //                                       "null"
      //                                   ? addedRecommendationtList[index]
      //                                           .recommender[0]
      //                                           .firstName +
      //                                       ", " +
      //                                       addedRecommendationtList[index]
      //                                           .title
      //                                   : addedRecommendationtList[index]
      //                                           .recommender[0]
      //                                           .firstName +
      //                                       " " +
      //                                       addedRecommendationtList[index]
      //                                           .recommender[0]
      //                                           .lastName +
      //                                       ", " +
      //                                       addedRecommendationtList[index]
      //                                           .title,
      //                           textAlign: TextAlign.start,
      //                           style: TextStyle(
      //                               fontFamily: Constant.customRegular,
      //                               fontWeight: FontWeight.bold,
      //                               fontSize: 13.0,
      //                               color: ColorValues.WHITE))),
      //                 )),
      //           ),
      //         ],
      //       );
      //     },
      //   );
      // } else {
      setState(() {});
      return NotificationListener<ScrollNotification>(
        onNotification: (ScrollNotification notification) {
          if (notification is ScrollUpdateNotification) {}
        },
        child: CarouselSlider.builder(
          //physics: NeverScrollableScrollPhysics(),
          //scrollDirection: Axis.horizontal,
          //shrinkWrap: true,
          //controller: _controller,
          itemCount: addedRecommendationtList.length,
          carouselController: _recommenCarouselController,
          options: CarouselOptions(
            height: 200,
            //aspectRatio: 16/9,
            viewportFraction: 0.75,
            initialPage: _firstPageBadge,
            enableInfiniteScroll: false,
            reverse: false,
            autoPlay: isAutoPlay,
            autoPlayInterval: Duration(seconds: _time),
            autoPlayAnimationDuration: Duration(milliseconds: 800),
            autoPlayCurve: Curves.fastOutSlowIn,
            //enlargeCenterPage: true,
            //onPageChanged: callbackFunction,
            scrollDirection: Axis.horizontal,
            pauseAutoPlayOnTouch: true,
          ),
          itemBuilder: (context, index) {
            //       if (addedRecommendationtList.length > 0 ) {
            // reccomendationListCount = reccomendationListCount + 1;
            // }
            print(
                "sss recom ${addedRecommendationtList[index].recommendation}");
            return Padding(
                padding: const EdgeInsets.all(10.0),
                child: Stack(
                  alignment: Alignment.center,
                  overflow: Overflow.visible,
                  children: [
                    Container(
                      width: 850,
                      height: 170,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    15.0, 10.0, 10.0, 10.0),
                                child: Text(
                                    addedRecommendationtList[index].stage ==
                                            "Requested"
                                        ? "" +
                                            addedRecommendationtList[index]
                                                .request
                                                .trim() +
                                            ""
                                        : "" +
                                            addedRecommendationtList[index]
                                                .recommendation
                                                .trim() +
                                            "",
                                    textAlign: TextAlign.justify,
                                    style: TextStyle(
                                        fontFamily: Constant.customRegular,
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.w400,
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1))),
                          ],
                        ),
                      ),
                      decoration: BoxDecoration(
                        border: GradientBorder.uniform(
                            width: 2.0,
                            gradient: LinearGradient(colors: <Color>[
                              Color(0xff4684EB),
                              Color(0x00000000),
                            ],
                             begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              //stops: [0.9, 0.5],
                            ),
                        ),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(15)),
                      ),
                    ),
                    Positioned(
                      bottom: -20,
                      left: 10,
                      child: InkWell(
                          radius: 50,
                          onTap: () {},
                          child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 35,
                                width: 420,
                                decoration: BoxDecoration(
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                  border: Border.all(
                                      color: ColorValues
                                          .HEADING_COLOR_EDUCATION_1),
                                  borderRadius: const BorderRadius.all(
                                      Radius.circular(10)),
                                ),
                                child: PaddingWrap.paddingfromLTRB(
                                    18.0,
                                    8.0,
                                    18.0,
                                    10.0,
                                    Text(
                                        addedRecommendationtList[index]
                                                    .recommender[0]
                                                    .firstName ==
                                                "null"
                                            ? addedRecommendationtList[index]
                                                .title
                                            : addedRecommendationtList[index]
                                                        .recommender[0]
                                                        .lastName ==
                                                    "null"
                                                ? addedRecommendationtList[
                                                            index]
                                                        .recommender[0]
                                                        .firstName +
                                                    ", " +
                                                    addedRecommendationtList[
                                                            index]
                                                        .title
                                                : addedRecommendationtList[
                                                            index]
                                                        .recommender[0]
                                                        .firstName +
                                                    " " +
                                                    addedRecommendationtList[
                                                            index]
                                                        .recommender[0]
                                                        .lastName +
                                                    ", " +
                                                    addedRecommendationtList[
                                                            index]
                                                        .title,
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 13.0,
                                            color: ColorValues.WHITE))),
                              ))),
                    ),
                  ],
                ));
          },
        ),
      );
      //}
    } else
      return Container();
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  Future<Image> getVideoThumb(path) async {
    print('getVideoThumb() path:::: ${path}');
    final thumbnailFile =
        await uploadMedia.getVideoThumbnailFromUrl(Constant.IMAGE_PATH + path);
    print('getData() thumbnailFile:::: ${thumbnailFile}');
    return Image.file(
      thumbnailFile,
      fit: BoxFit.contain,
    );
  }

  onTapShare() async {
    // onChatWithHeader("shubh.jain", "305");

    AutoOrientation.portraitAutoMode();
    String pagename = "custom";
    if (widget.profileType == 'Public') pagename = "public";
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => ShareProfileView(widget.link,
            _mPublicProfileDataModel.result.firstName, pagename, false)));
    if (result == "push") {
      Navigator.pop(context, "push");
    } else {
      AutoOrientation.landscapeAutoMode();
    }
  }

  void onTapLinearView(bool isResume) {
    AutoOrientation.portraitAutoMode();
    if (widget.profileType == 'Public') {
      Navigator.of(context)
          .push(
            new MaterialPageRoute(
              builder: (context) => PublicViewForUser(
                widget.profileId,
                "preso",
                "Public",
                false,
                studentProfile: widget.studentProfile,
              ),
            ),
          )
          .then((value) => AutoOrientation.landscapeAutoMode());
    } else {
      Navigator.of(context)
          .push(
            new MaterialPageRoute(
              builder: (BuildContext context) => CustomViewForUser(
                widget.profileId,
                "preso",
                isResume: isResume,
                studentProfile: widget.studentProfile,
              ),
            ),
          )
          .then((value) => AutoOrientation.landscapeAutoMode());
    }
  }
}

class ScatterItemInterestCircle extends StatelessWidget {
  ScatterItemInterestCircle(this.loveInterestList, this.textFont, this.index);

// List<SkillID> loveInterestList = List();
  List<SkillID> loveInterestList;

//  final int index;
  double heightDefault = 100.0;
  double widthDefault = 100.0;
  double textFont;
  int index;

  @override
  Widget build(BuildContext context) {
    final TextStyle textStyle = Theme.of(context).textTheme.body1.copyWith(
        fontSize: textFont,
        color: Colors.white,
        fontWeight: FontWeight.bold,
        fontFamily: Constant.customRegular);

    final TextStyle Circlestyle = Theme.of(context).textTheme.body1.copyWith(
        fontSize: 16.0,
        color: ColorValues.WHITE,
        fontFamily: Constant.customBold);

    //print('inside ScatterItemnew asset length:: ${narrativeListLocal.achievement.length}');
    //print('inside ScatterItemnew name:: ${narrativeListLocal.name}');
    return RotatedBox(
      //quarterTurns: hashtag.rotated ? 1 : 0,
      quarterTurns: 0,
      child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                alignment: Alignment.center,
                height: heightDefault +
                    5 * (loveInterestList[index].name.length.toDouble()),
                width: widthDefault +
                    5 * (loveInterestList[index].name.length.toDouble()),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      // transform: GradientRotation(pi / 2),
                      colors: [
                        ColorValues.presoGradientColor1,
                        ColorValues.presoGradientColor2,
                        // ColorValues.presoGradientColor3,
                      ]),
                  shape: BoxShape.circle,
                ),
                child: Align(
                  child: Text(
                    loveInterestList[index].name,
                    style: Circlestyle,
                  ),
                  alignment: Alignment.center,
                ),
              ),
              // SizedBox(
              //   width: 10.0,
              // ),
              // Text(
              //   loveInterestList[index].name,
              //   style: textStyle,
              // )
            ],
          )),
    );
  }
}

class ScatterItemnew extends StatelessWidget {
  ScatterItemnew(this.narrativeListLocal, this.textFont);

  AccomplimentData narrativeListLocal;

//  final int index;
  double heightDefault = 30.0;
  double widthDefault = 30.0;
  double textFont;

  @override
  Widget build(BuildContext context) {
    final TextStyle textStyle = Theme.of(context).textTheme.body1.copyWith(
        fontSize: textFont,
        color: Colors.white,
        fontFamily: Constant.customRegular);

    final TextStyle Circlestyle = Theme.of(context).textTheme.body1.copyWith(
        fontSize: 15.0 + (3 * narrativeListLocal.achievement.length.toDouble()),
        color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
        fontFamily: Constant.customBold);

    //print('inside ScatterItemnew asset length:: ${narrativeListLocal.achievement.length}');
    //print('inside ScatterItemnew name:: ${narrativeListLocal.name}');
    return RotatedBox(
      //quarterTurns: hashtag.rotated ? 1 : 0,
      quarterTurns: 0,
      child: Padding(
          padding: EdgeInsets.all(10.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                alignment: Alignment.center,
                height: heightDefault +
                    5 * (narrativeListLocal.achievement.length.toDouble()),
                width: widthDefault +
                    5 * (narrativeListLocal.achievement.length.toDouble()),
                decoration: BoxDecoration(
                  color: Colors.black,
                  shape: BoxShape.circle,
                ),
                child: Align(
                  child: Text(
                    narrativeListLocal.achievement.length > 9
                        ? narrativeListLocal.achievement.length.toString()
                        : "0" +
                            narrativeListLocal.achievement.length.toString(),
                    style: Circlestyle,
                  ),
                  alignment: Alignment.center,
                ),
              ),
              SizedBox(
                width: 10.0,
              ),
              Text(
                narrativeListLocal.name,
                style: textStyle,
              )
            ],
          )),
    );
  }
}
