import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/home/group_list_for_post.dart';
import 'package:spike_view_project/linkPreview/whatsapp/view.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:chewie/src/material_controls.dart';
import 'package:flutter/foundation.dart';

///
/// Toggles play/pause on tap (accompanied by a fading status icon).
///
/// Plays (looping) on initialization, and mutes on deactivation.

class VideoPlayPauseNew extends StatefulWidget {
  final String path;
  bool isPlay = false;
  String feedId;

  VideoPlayPauseNew(this.path, this.feedId);

  @override
  State createState() {
    return  _VideoPlayPauseState();
  }
}

class _VideoPlayPauseState extends State<VideoPlayPauseNew> {
  FadeAnimation imageFadeAnim =
   FadeAnimation(child:  Icon(Icons.play_arrow, size: 100.0));
  VoidCallback listener;
  bool isApiNeedToCall = true;

  VideoPlayerController  controller;
  ChewieController _chewieController;
  _VideoPlayPauseState() {
    print("clicked data---------> +++++ ");
    listener = () {

    };
  }


  // ChewieController _chewieController;

  @override
  void initState() {
    super.initState();

    controller = VideoPlayerController.network(
        Constant.PATH_FOR_VIDEO+widget.path.replaceAll(" ", "%20"));

    controller.addListener(listener);

    controller.setVolume(1.0);

    controller.pause();
    controller.initialize();

  }

  @override
  void deactivate() {
    controller.setVolume(0.0);
    controller.removeListener(listener);
    //_chewieController.dispose();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    final List<Widget> children = <Widget>[
       GestureDetector(
        child:  Container(
            width: double.infinity,
            child:  Stack(
              children: <Widget>[
                 Center(
                  child: controller.value.initialized
                      ? Chewie(
                    controller: ChewieController(
                      videoPlayerController: controller,
                      autoPlay: false,
                      aspectRatio: controller.value.aspectRatio,
                      looping: false,
                      allowFullScreen: false,
                      showControls: true,
                      // Try playing around with some of these other options:
                      placeholder: Container(
                        child: Center(child: Image.asset("assets/img/mw.png")),
                      ),
                    ),
                  )


                      :  Center(
                      child:  Container(
                        child:  CircularProgressIndicator(),
                      )),
                ),
              ],
            )),
        onTap: () {
          print("Play Data+++++");
          if (!controller.value.initialized) {
            return;
          }
          if (controller.value.isPlaying) {
            imageFadeAnim =
             FadeAnimation(child:  Icon(Icons.pause, size: 100.0));
            controller.pause();
          } else {
            imageFadeAnim =  FadeAnimation(
                child:  Icon(Icons.play_arrow, size: 100.0));
            controller.play();

            print("Play Data+++++");
          }
        },
      ),
       Center(child: imageFadeAnim),
    ];


    return  Stack(
      alignment: Alignment.bottomCenter,
      fit: StackFit.passthrough,
      children: children,
    );
  }


}

class FadeAnimation extends StatefulWidget {
  final Widget child;
  final Duration duration;

  FadeAnimation({this.child, this.duration: const Duration(milliseconds: 500)});

  @override
  _FadeAnimationState createState() =>  _FadeAnimationState();
}

class _FadeAnimationState extends State<FadeAnimation>
    with SingleTickerProviderStateMixin {
  AnimationController animationController;

  @override
  void initState() {
    super.initState();
    animationController =
         AnimationController(duration: widget.duration, vsync: this);
    animationController.addListener(() {
      if (mounted) {
        setState(() {});
      }
    });
    animationController.forward(from: 0.0);
  }

  @override
  void deactivate() {
    animationController.stop();
    super.deactivate();
  }

  @override
  void didUpdateWidget(FadeAnimation oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.child != widget.child) {
      animationController.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return animationController.isAnimating
        ?  Opacity(
            opacity: 1.0 - animationController.value,
            child: widget.child,
          )
        :  Container();
  }
}

typedef Widget VideoWidgetBuilder(
    BuildContext context, VideoPlayerController controller);

/// A widget connecting its life cycle to a [VideoPlayerController].
class PlayerLifeCycle extends StatefulWidget {
  final VideoWidgetBuilder childBuilder;
  final String uri;

  PlayerLifeCycle(this.uri, this.childBuilder);

  @override
  _PlayerLifeCycleState createState() =>  _PlayerLifeCycleState();
}

class _PlayerLifeCycleState extends State<PlayerLifeCycle> {
  VideoPlayerController controller;

  _PlayerLifeCycleState();

  @override
  void initState() {
    super.initState();
    controller =  VideoPlayerController.network(widget.uri.replaceAll(" ", "%20"));
    controller.addListener(() {
      if (controller.value.isBuffering) {
        print(controller.value.errorDescription);
      }
    });
    controller.initialize();
    controller.setLooping(false);
    controller.play();
  }

  @override
  void deactivate() {
    super.deactivate();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.childBuilder(context, controller);
  }
}

// Create a Form Widget
class SharePostWidget extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  UserPostModal userPostModal;
  String page, groupId;

  SharePostWidget(
      this.profileInfoModal, this.userPostModal, this.page, this.groupId);

  @override
  SharePostWidgetState createState() {
    return  SharePostWidgetState(userPostModal);
  }
}

class SharePostWidgetState extends State<SharePostWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, token, userProfilePath,companyImagePath;
  String isType = "Community";
  TextEditingController edtController;
  UserPostModal userPostModal;
  String sasToken, containerName, strPrefixPathforFeed;
  List<TagsPost> selectedtScopeList =  List();
  List<TagModel> selectedUerTagLIst1 =  List();
  RegExp exp =  RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");
  SharePostWidgetState(this.userPostModal);

  List<TagsPost> selectedUerTagLIst =  List();
  List<String> groupidList =  List();

  static const platform = const MethodChannel('samples.flutter.io/battery');

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyImagePath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    setState(() {
      userProfilePath;
      companyImagePath;
    });
    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
  }

  bool showMore = false;

  @override
  void initState() {
    getSharedPreferences();

    edtController =  TextEditingController(text: '');
    // TODO: implement initState
    edtController.addListener(() {
      if (edtController.text.length > 20) {
        setState(() {
          showMore = true;
        });
      } else {
        setState(() {
          showMore = false;
        });
      }
    });

    super.initState();
  }

  //-------------------------------------Api Calling for feed--------------------------

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        bool isCommunityPost = false;
        if (isType == "Community") {
          isCommunityPost = true;
        }
        Map map = {
          "feedId": userPostModal.feedId,
          "postedBy": int.parse(userIdPref),
          "postOwner": int.parse(userPostModal.postedBy),
          "postOwnerRoleId":userPostModal.postOwnerRoleId!="null"||userPostModal.postOwnerRoleId!=""?"": int.parse(userPostModal.postOwnerRoleId),
          "visibility": isType,
          "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
          "shareTime":  DateTime.now().millisecondsSinceEpoch,
          "shareText": edtController.text,
          "isActive": widget.profileInfoModal.isActive,
          "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "ShareFeed",
          "roleId": int.parse(roleId),
          "groupId": widget.groupId == "0" ? "" : int.parse(widget.groupId),
          "groupIds": groupidList.map((item) => int.parse(item)).toList(),
          "isCommunityPost": isCommunityPost,
        };



        print("Map:-" + map.toString());
        Response response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_SHARE_FEED, map);

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast("Feed shared successfully.");

              Navigator.pop(context, "push");
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("error"+e.toString());
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {

    onClickGroup() async {
      List<String> groupData = await Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => GroupListForPost(groupidList,widget.groupId)),
      );
      if (groupData != null && groupData.length > 0) {
        selectedtScopeList.clear();
        groupidList.clear();
        groupidList.addAll(groupData);
        isType = "Group";
        setState(() {
          isType;
        });
      }
    }

    void conformationDialogForCommunityPost() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "spikeview community post has to be reviewed by the community admin. It will be visible once approved.",
                                                      textAlign: TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Post",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);

                                                apiCalling();
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }


    onTapPostButton() async {
      if (isType == "Community") {
        conformationDialogForCommunityPost();
      } else {
        apiCalling();
      }
    }


    void onTapTagSelectedConnection() async {
      List<TagsPost> result = await Navigator.of(context).push(
           MaterialPageRoute(
              builder: (BuildContext context) =>  AddMyConnectionSharePost(
                  "Select Connections", selectedtScopeList)));

      if (result != null) {
        selectedtScopeList.clear();
        groupidList.clear();
        selectedtScopeList = result;
        setState(() {

        });
      }
    }


    void _settingModalBottomSheet(context) {

      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: <Widget>[
                          Container(
                            child: Column(children: <Widget>[
                              PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  20.0,
                                  13.0,
                                  0.0,
                                  Container(
                                    padding: EdgeInsets.all(10.0),
                                    width: double.infinity,
                                    color: Colors.white,
                                    child:  Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              0.0,
                                              13.0,
                                              15.0,
                                              TextViewWrap.textView(
                                                  "Who can see your Post?",
                                                  TextAlign.center,
                                                  ColorValues.HEADING_COLOR_EDUCATION,
                                                  16.0,
                                                  FontWeight.normal)),

                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                        "assets/profile/post/community.png",
                                                        width:
                                                        25.0,
                                                        height:
                                                        25.0,color:isType == "Community"
                                                          ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          8.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Community",
                                                              TextAlign
                                                                  .center,
                                                              isType == "Community"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          Text(
                                                              "Visible to all spikeview community members",
                                                              textAlign:
                                                              TextAlign
                                                                  .start,
                                                              style:  TextStyle(
                                                                  color:  ColorValues.GREY__COLOR,
                                                                  fontSize:
                                                                  14.0,
                                                                  fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR))

                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              selectedtScopeList.clear();
                                              groupidList.clear();
                                              isType = "Community";
                                              setState(() {
                                                isType;
                                              });
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                          "assets/profile/post/group_data.png",
                                                          width:
                                                          25.0,
                                                          height:
                                                          25.0,color:isType == "Group"
                                                          ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                      ColorValues.HEADING_COLOR_EDUCATION
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          8.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Group",
                                                              TextAlign
                                                                  .center,
                                                              isType == "Group"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          4.0,
                                                          13.0,
                                                          TextViewWrap.textViewMultiLine(
                                                              "Visible to all members in selected groups",
                                                              TextAlign
                                                                  .start,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal,
                                                              2)),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              onClickGroup();
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                          "assets/profile/post/connection.png",
                                                          width:
                                                          25.0,
                                                          height:
                                                          25.0, color: isType == "AllConnections"
                                                          ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                      ColorValues.HEADING_COLOR_EDUCATION
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Connections",
                                                              TextAlign
                                                                  .center,
                                                              isType == "AllConnections"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          TextViewWrap.textView(
                                                              "Your connections on spikeview",
                                                              TextAlign
                                                                  .center,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal)),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              selectedtScopeList.clear();
                                              groupidList.clear();
                                              isType =
                                              "AllConnections";
                                              setState(() {
                                                isType;
                                              });
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      10.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                          "assets/profile/post/selected_connection.png",
                                                          width:
                                                          25.0,
                                                          height:
                                                          25.0,color: isType == "SelectedConnections"
                                                          ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                      null
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Selected Connections",
                                                              TextAlign
                                                                  .center,
                                                              isType == "SelectedConnections"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          TextViewWrap.textView(
                                                              "Only visible to some connections",
                                                              TextAlign
                                                                  .center,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal)),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              onTapTagSelectedConnection();
                                              isType =
                                              "SelectedConnections";
                                              setState(() {
                                                isType;
                                              });
                                            },
                                          ),
                                          CustomViews
                                              .getSepratorLine(),
                                          InkWell(
                                            child:  Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                Expanded(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      13.0,
                                                      15.0,
                                                      19.0,
                                                      10.0,
                                                      Image
                                                          .asset(
                                                          "assets/profile/post/private_new.png",
                                                          width:
                                                          20.0,
                                                          height:
                                                          20.0,color:isType == "Private"
                                                          ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                      AppConstants
                                                          .colorStyle
                                                          .darkBlue
                                                      )),
                                                  flex: 0,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          3.0,
                                                          TextViewWrap.textView(
                                                              "Make it Private",
                                                              TextAlign
                                                                  .center,
                                                              isType == "Private"
                                                                  ?  ColorValues.BLUE_COLOR_BOTTOMBAR:
                                                              ColorValues.HEADING_COLOR_EDUCATION,
                                                              16.0,
                                                              FontWeight
                                                                  .normal)),
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          13.0,
                                                          TextViewWrap.textView(
                                                              "Only visible to me",
                                                              TextAlign
                                                                  .center,
                                                              ColorValues.GREY__COLOR,
                                                              14.0,
                                                              FontWeight
                                                                  .normal)),
                                                    ],
                                                  ),
                                                  flex: 0,
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              Navigator.pop(context);
                                              selectedtScopeList.clear();
                                              groupidList.clear();
                                              selectedUerTagLIst1
                                                  .clear();
                                              selectedUerTagLIst
                                                  .clear();
                                              isType = "Private";
                                              setState(() {
                                                isType;
                                                selectedUerTagLIst1;
                                                selectedUerTagLIst;
                                              });
                                            },
                                          ),
                                        ]),
                                  )),
                              PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  10.0,
                                  13.0,
                                  10.0,
                                  Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                          Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.customRegular),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      )))

                            ],)
                            ,
                          ),
                        ],
                      )))));

    }





    Widget _loader(BuildContext context) => Center(
            child: Container(
          child:  Image.asset(
            "assets/aerial/feed_default_img.png",
            fit: BoxFit.cover,
          ),
        ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    Padding getListViewForOpportunity(userPostModal) {
      return PaddingWrap.paddingAll(
          0.0,
           Container(
              color:  ColorValues.SCREEN_BG_COLOR,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  //  getEvent(userPostModal),
                  PaddingWrap.paddingfromLTRB(
                      15.0,
                      15.0,
                      13.0,
                      10.0,
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  InkWell(
                              child:  Center(
                                child:  Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child: ClipOval(
                                        child: FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      placeholder:
                                      userPostModal.roleId=="4"?"assets/profile/partner_img.png": 'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(userPostModal
                                              .opportunityModelForFeed
                                              .profilePicture),
                                    ))),
                              ),
                              onTap: () {},
                            ),
                            flex: 0,
                          ),
                           Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                8.0,
                                0.0,
                                15.0,
                                0.0,
                                 Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                     InkWell(
                                      child:  Container(
                                          child: RichText(
                                        maxLines: 2,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          text: userPostModal
                                              .opportunityModelForFeed
                                              .companyName,
                                          style:  TextStyle(
                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                            fontSize: 15.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      )),
                                      onTap: () {},
                                    ),
                                    TextViewWrap.textView(
                                        userPostModal.dateTime,
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        12.0,
                                        FontWeight.normal),
                                  ],
                                )),
                            flex: 4,
                          ),
                        ],
                      )),

                   InkWell(
                    child: Container(
                      width: double.infinity,
                      child: Card(
                        elevation: 0.0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0.0)),
                        color: ColorValues.WHITE,
                        child: Column(
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                //
                                userPostModal.opportunityModelForFeed
                                            .assestVideoAndImage.length >
                                        0
                                    ?  SizedBox(
                                        // Pager view
                                        height: 215.50,
                                        child: PageIndicatorContainer(
                                          pageView:  PageView.builder(
                                            itemCount: userPostModal
                                                .opportunityModelForFeed
                                                .assestVideoAndImage
                                                .length,
                                            controller:  PageController(),
                                            itemBuilder: (context, index2) {
                                              return  Stack(
                                                children: <Widget>[
                                                  userPostModal
                                                              .opportunityModelForFeed
                                                              .assestVideoAndImage[
                                                                  index2]
                                                              .type ==
                                                          "image"
                                                      ?

                                                       CachedNetworkImage(
                                                          width:
                                                              double.infinity,
                                                          height: 215.50,
                                                          imageUrl: Constant
                                                                  .IMAGE_PATH +
                                                              userPostModal
                                                                  .opportunityModelForFeed
                                                                  .assestVideoAndImage[
                                                                      index2]
                                                                  .file,
                                                          fit: BoxFit.fill,
                                                          placeholder:(context, url) =>
                                                              _loader(context),
                                                          errorWidget:(context, url, error) => _error(),
                                                        )
                                                      :  Container(
                                                          height: 215.50,
                                                    color: Colors.black,
                                                          child:  Center(
                                                            child:  VideoPlayPauseNew(
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .assestVideoAndImage[
                                                                index2]
                                                                    .file,
                                                                ""),
                                                          ),
                                                        ),
                                                  userPostModal
                                                              .opportunityModelForFeed
                                                              .assestVideoAndImage
                                                              .length ==
                                                          1
                                                      ?  Container(
                                                          height: 0.0,
                                                        )
                                                      :  Container(
                                                          height: 215.50,
                                                          width:
                                                              double.infinity,
                                                          child:
                                                               Image.asset(
                                                            "assets/newDesignIcon/navigation/layer_image.png",
                                                            fit: BoxFit.fill,
                                                          ),
                                                        )
                                                ],
                                              );
                                            },
                                            onPageChanged: (index) {},
                                          ),
                                          align: IndicatorAlign.bottom,
                                          length: userPostModal
                                              .opportunityModelForFeed
                                              .assestVideoAndImage
                                              .length,
                                          indicatorSpace: 10.0,
                                          indicatorColor: userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage
                                                      .length ==
                                                  1
                                              ? Colors.transparent
                                              :  Color(0xffc4c4c4),
                                          indicatorSelectorColor: userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage
                                                      .length ==
                                                  1
                                              ? Colors.transparent
                                              :  ColorValues.WHITE,
                                          shape:
                                              IndicatorShape.circle(size: 5.0),
                                        ))
                                    :  Stack(children: <Widget>[
                                         Image.asset(
                                          "assets/profile/default_achievement.png",
                                          fit: BoxFit.cover,
                                          height: 215.50,
                                          width: double.infinity,
                                        ),
                                         Container(
                                          height: 215.50,
                                          color: Colors.black54.withOpacity(.4),
                                        )
                                      ])),
                            Container(
                              height: 80,
                              color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 13, top: 16.0),
                                        child: Image.asset(
                                          "assets/newDesignIcon/patner/spike_grey.png",
                                          height: 12.0,
                                          width: 12.0,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 3.0, top: 16.0),
                                        child: Text(
                                          "OPPORTUNITY",
                                          style: TextStyle(
                                              color: ColorValues.GREY_TEXT_COLOR,
                                              fontSize: 12),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: <Widget>[
                                       Expanded(
                                        child: Container(
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                13.0, 2.0, 10.0, 10.0),
                                            child: Text(
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .jobTitle,
                                              style:  TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 14.0,
                                                  fontFamily: Constant.TYPE_CUSTOMBOLD,
                                                  fontWeight: FontWeight.bold),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ),
                                        flex: 1,
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    onTap: () {},
                  ),
                ],
              )));
    }

    Padding getListView(userPostModal) {
      return PaddingWrap.paddingfromLTRB(
          10.0,
          10.0,
          10.0,
          10.0,
           Card(
              color: Colors.white,
              elevation: 0.0,
              child:  Container(
                  decoration:  BoxDecoration(
                      border:  Border.all(
                          width: 1.0,
                          color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: PaddingWrap.paddingfromLTRB(
                      17.0,
                      10.0,
                      17.0,
                      10.0,
                       Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              10.0,
                              10.0,
                              10.0,
                               Row(
                                children: <Widget>[
                                   Expanded(
                                    child:  Center(
                                        child:  Container(
                                            width: 50.0,
                                            height: 50.0,
                                            child: ClipOval(
                                                child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                              placeholder:
                                              userPostModal.roleId=="4"?"assets/profile/partner_img.png": 'assets/profile/user_on_user.png',
                                              image: Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getSmallImage(
                                                      userPostModal
                                                          .profilePicture),
                                            )))),
                                    flex: 0,
                                  ),
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        8.0,
                                        5.0,
                                        5.0,
                                        5.0,
                                         Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                             Container(
                                                child: RichText(
                                              maxLines: 2,
                                              textAlign: TextAlign.start,
                                              text: TextSpan(
                                                text: userPostModal.lastName ==
                                                        "null"
                                                    ? userPostModal.firstName
                                                    : userPostModal.firstName +
                                                        " " +
                                                        userPostModal.lastName,
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 14.0,
                                                    fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                children: userPostModal
                                                            .tagList.length ==
                                                        0
                                                    ? null
                                                    : <TextSpan>[
                                                        TextSpan(
                                                            text: ' with ',
                                                            style:  TextStyle(
                                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                fontSize: 14.0,
                                                                fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR)),
                                                        TextSpan(
                                                          text: userPostModal
                                                              .tagList[0].name,
                                                          style:  TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize: 14.0,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                        ),
                                                        userPostModal.tagList
                                                                    .length >
                                                                1
                                                            ? TextSpan(
                                                                text: ' and ',
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              )
                                                            : TextSpan(
                                                                text: "",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                        userPostModal.tagList
                                                                    .length >
                                                                1
                                                            ? TextSpan(
                                                                text: (userPostModal
                                                                            .tagList
                                                                            .length -
                                                                        1)
                                                                    .toString(),
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              )
                                                            : TextSpan(
                                                                text: "",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                        userPostModal.tagList
                                                                    .length >
                                                                1
                                                            ? TextSpan(
                                                                text:
                                                                    " others ",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              )
                                                            : TextSpan(
                                                                text: "",
                                                                style:  TextStyle(
                                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                      ],
                                              ),
                                            )),
                                            TextViewWrap.textView(
                                                userPostModal.dateTime,
                                                TextAlign.center,
                                                ColorValues.GREY_TEXT_COLOR,
                                                12.0,
                                                FontWeight.normal),
                                          ],
                                        )),
                                    flex: 1,
                                  )
                                ],
                              )),

                          userPostModal.postdata == null ||
                              userPostModal.postdata.text == null ||
                              userPostModal.postdata.text == "null"
                              ?  Container(
                            height: 0.0,
                          )
                              : PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              10.0,
                              0.0,
                               Container(
                                  color: Colors.transparent,
                                  child:  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        userPostModal.postdata.text == "" ||
                                            userPostModal.postdata.text ==
                                                "null" ||
                                            userPostModal.postdata.text == "\n"
                                            ?  Container(
                                          height: 1.0,
                                        )
                                            :

                                        userPostModal.postdata.imageList.length ==
                                            0 &&
                                            (userPostModal.postdata.media ==
                                                null ||
                                                userPostModal
                                                    .postdata.media ==
                                                    "" ||
                                                userPostModal
                                                    .postdata.media ==
                                                    "null")&&(userPostModal.postdata.metaUrl != ""&&userPostModal.postdata.metaImage!="")
                                            ? exp
                                            .allMatches(
                                            userPostModal
                                                .postdata
                                                .text)
                                            .length ==
                                            1 &&
                                            userPostModal.postdata.text
                                                .toString()
                                                .replaceAll(exp, '')
                                                .length ==
                                                0
                                            ?  Container(
                                          height: 0.0,
                                        )
                                            : PaddingWrap.paddingfromLTRB(
                                            4.0,
                                            10.0,
                                            13.0,
                                            0.0,
                                             Container(
                                              child: Linkify(
                                                onOpen: (link) async {
                                                  print("onclick +++" +
                                                      link.url
                                                          .toLowerCase());


                                                  Navigator.push(
                                                      context,
                                                       MaterialPageRoute(
                                                        //   builder: (context) =>  DashBoardWidget()));
                                                          builder: (context) =>
                                                           WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                                },
                                                text: exp
                                                    .allMatches(
                                                    userPostModal
                                                        .postdata
                                                        .text)
                                                    .length >
                                                    1
                                                    ? userPostModal
                                                    .postdata.text
                                                    : userPostModal
                                                    .postdata.text
                                                    .toString()
                                                    .replaceAll(
                                                    exp, ''),
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0),
                                                linkStyle:  TextStyle(
                                                    color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0),
                                              ),
                                            ))
                                            :  Container(
                                          child: Linkify(
                                            onOpen: (link) async {
                                              print("onclick +++" +
                                                  link.url.toLowerCase());

                                              Navigator.push(
                                                  context,
                                                   MaterialPageRoute(
                                                    //   builder: (context) =>  DashBoardWidget()));
                                                      builder: (context) =>
                                                       WebViewWidget(
                                                          link.url,
                                                          "spikeview")));
                                            },
                                            text: userPostModal
                                                .postdata.text,
                                            style:  TextStyle(
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 14.0),
                                            linkStyle:  TextStyle(
                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 14.0),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ))),




                          userPostModal.postdata.imageList.length == 0
                              ?  Container(
                                  height: 0.0,
                                )
                              :  Container(
                                  height: 215.50,
                                  child:  SizedBox(
                                      // Pager view
                                      height: 215.50,
                                      child: PageIndicatorContainer(
                                        pageView:  PageView.builder(
                                          itemCount: userPostModal
                                              .postdata.imageList.length,
                                          controller:  PageController(),
                                          itemBuilder: (context, index2) {
                                            return  InkWell(
                                              child:
                                                   Stack(children: <Widget>[
                                                 Container(
                                                    height: 215.50,
                                                    child: FadeInImage
                                                        .assetNetwork(
                                                      fit: BoxFit.cover,
                                                      width: double.infinity,
                                                      height: 215.50,
                                                      placeholder:
                                                          'assets/aerial/default_img.png',
                                                      image: Constant
                                                              .IMAGE_PATH_SMALL +
                                                          ParseJson.getMediumImage(
                                                              userPostModal
                                                                      .postdata
                                                                      .imageList[
                                                                  index2]),
                                                    )),
                                                userPostModal.postdata.imageList
                                                            .length ==
                                                        1
                                                    ?  Container(
                                                        height: 0.0,
                                                      )
                                                    :  Container(
                                                        height: 215.50,
                                                        width: double.infinity,
                                                        child:  Image.asset(
                                                          "assets/newDesignIcon/navigation/layer_image.png",
                                                          fit: BoxFit.fill,
                                                        ),
                                                      )
                                              ]),
                                              onTap: () {},
                                            );
                                          },
                                          onPageChanged: (index) {},
                                        ),
                                        align: IndicatorAlign.bottom,
                                        length: userPostModal
                                            .postdata.imageList.length,
                                        indicatorSpace: 10.0,
                                        indicatorColor: userPostModal.postdata
                                                    .imageList.length ==
                                                1
                                            ? Colors.transparent
                                            :  Color(0xffc4c4c4),
                                        indicatorSelectorColor: userPostModal
                                                    .postdata
                                                    .imageList
                                                    .length ==
                                                1
                                            ? Colors.transparent
                                            :  ColorValues.WHITE,
                                        shape: IndicatorShape.circle(size: 5.0),
                                      ))),
                          userPostModal.postdata.imageList.length > 0 ||
                                  userPostModal.postdata.media == null ||
                                  userPostModal.postdata.media == "" ||
                                  userPostModal.postdata.media == "null"
                              ?  Container(
                                  height: 1.0,
                                )
                              :  Container(
                                  height: 215.50,
                            color: Colors.black,
                                  child:  Center(
                                    child:  VideoPlayPauseNew(
                                        userPostModal.postdata.media, ""),
                                  ),
                                ),

                          userPostModal.postdata.imageList.length == 0 &&
                              (userPostModal.postdata.media == null ||
                                  userPostModal.postdata.media == "" ||
                                  userPostModal.postdata.media == "null")
                              ? userPostModal.postdata == null ||
                              userPostModal.postdata.text == null ||
                              userPostModal.postdata.text == "null"
                              ?  Container(
                            height: 0.0,
                          )
                              : userPostModal.postdata.metaUrl != ""
                              ? Container(
                              margin: EdgeInsets.symmetric(vertical: 4.0),
//                                  child: userPostModal.webLinkModel.imageUrl ==
//                                          ""
//                                      ?new WhatsAppLinkPreview().build(
//                                          getLinkUrl(
//                                              userPostModal.postdata.text),
//                                          userPostModal)
//                                      :

                              child:  WhatsAppView(
                                imageUrl: userPostModal.postdata.metaImage,
                                feedId: userPostModal.feedId,
                                title: userPostModal.postdata.metaTitle,
                                url: userPostModal.postdata.metaUrl,
                                metaHeight: userPostModal.postdata.metaHeight,
                                metaWidth: userPostModal.postdata.metaWidth,
                                description:
                                userPostModal.postdata.metaDescription,
                              ))
                              :  Container(
                            height: 0.0,
                          )
                              :  Container(
                            height: 0.0,
                          ),


                        ],
                      )))));
    }

    Padding getTextView(String text) {
      return  Padding(
          padding: EdgeInsets.fromLTRB(20.0, 10.0, 0.0, 0.0),
          child:  Align(
              alignment: Alignment.centerLeft,
              child:  Text(
                text,
                style: TextStyle(
                    fontSize: 12.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.GREY_TEXT_COLOR),
                textAlign: TextAlign.left,
              )));
    }

    _buildChoiceList() {
      List<Widget> choices = List();
      selectedUerTagLIst1.forEach((item) {
        if (item.isSelected) {
          choices.add(PaddingWrap.paddingAll(
              5.0,
              Container(
                decoration:  BoxDecoration(
                    border:  Border.all(
                        width: 1.0,
                        color:  ColorValues.GREY_TEXT_COLOR)),
                padding: const EdgeInsets.all(3.0),
                child: Wrap(
                  children: <Widget>[
                     Text(
                      item.firstName + " " + item.lastName,
                      overflow: TextOverflow.ellipsis,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                     InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          5.0,
                          3.0,
                          0.0,
                          0.0,
                           Icon(
                            Icons.clear,
                            color: Colors.black,
                            size: 17.0,
                          )),
                      onTap: () {
                        setState(() {
                          selectedUerTagLIst1.remove(item);
                          selectedUerTagLIst.remove(item);
                        });
                      },
                    )
                  ],
                ), /*  Row(
              children: <Widget>[
                 Text(
                    item.firstName,
                    overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),

              */ /*   Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                         Icon(
                          Icons.cancel,
                          color: Colors.transparent,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        item.isSelected = false;
                      });
                    },
                  ),
                  flex: 0,
                ),*/ /*
              ],
            ) */ /*ChoiceChip(
            selectedColor: Colors.transparent,

            label: Wrap(
              children: <Widget>[
                 Row(children: <Widget>[
                   Flexible(child:     Text(
                   item.label,overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),flex: 1,)
                  ,
           Expanded(child:   PaddingWrap.paddingfromLTRB(
                      5.0,
                      3.0,
                      0.0,
                      0.0,
                       Icon(
                        Icons.cancel,
                        color:  ColorValues.BG_CIRCLE_COLOR,
                        size: 17.0,
                      )),flex: 0,),
                ],)

              ],
            ),
            selected: true,
            onSelected: (selected) {
              setState(() {
                skeelSelectedList.remove(item);
                filterStatus[item.index] = false;
              });
              filterData = "";
              appliedFilter = "";
              skeelSelectedList.clear();
              filterStatus.forEach(iterateFilters);
            },
          ),*/
              )));
        }
      });
      return choices;
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar:  AppBar(
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  )
                ],
              ),
              actions: <Widget>[
                 InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      13.0,
                      0.0,
                       Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           Text(
                            "Post",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                          )
                        ],
                      )),
                  onTap: () {
                    onTapPostButton();
                  },
                )
              ],
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Share",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              backgroundColor: Colors.white,
            ),
            body:  Column(children: <Widget>[
              CustomViews.getSepratorLine(),
               Expanded(
                child:  ListView(
                  children: <Widget>[
                     Container(
                        child:  Column(
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            15.0,
                            30.0,
                            5.0,
                            0.0,
                             Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                 Expanded(
                                  child:  Center(
                                      child:  Container(
                                          width: 55.0,
                                          height: 55.0,
                                          child: ClipOval(
                                              child: FadeInImage.assetNetwork(
                                            fit: BoxFit.cover,
                                            width: double.infinity,
                                            placeholder:
                                            roleId=="4"?"assets/profile/partner_img.png": 'assets/profile/user_on_user.png',
                                            image: /*Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                  userProfilePath,
                                                )*/Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    roleId=="4"?  companyImagePath:userProfilePath/*userPostModal.profilePicture*/),
                                          )))),
                                  flex: 0,
                                ),
                                 Expanded(
                                  child:  TextField(
                                    maxLines: showMore ? 3 : 1,
                                    cursorColor: Constant.CURSOR_COLOR,
                                    controller: edtController,
                                    maxLength: 2000,
                                    autofocus: true,
                                    keyboardType: TextInputType.text,  style:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                    textAlign: TextAlign.start,
                                    decoration:  InputDecoration(
                                      counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),        border: InputBorder.none,
                                      filled: true,
                                      hintText: "Share your thoughts",
                                      hintStyle:
                                           TextStyle(color: ColorValues.hintColor),
                                      fillColor: Colors.transparent,
                                    ),
                                  ),
                                ),
                              ],
                            )),
                        userPostModal.isOpportunity
                            ? getListViewForOpportunity(userPostModal)
                            : getListView(userPostModal),
                        /*   selectedUerTagLIst1.length > 0
                            ? getTextView("Tags(" +
                                selectedUerTagLIst1.length.toString() +
                                ")")
                            :  Container(
                                height: 0.0,
                              ),
                         Container(
                            alignment: Alignment.centerLeft,
                            child:  Padding(
                              padding:
                                  EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 0.0),
                              child: Wrap(
                                children: _buildChoiceList(),
                              ),
                            ))*/
                      ],
                    ))
                  ],
                ),
                flex: 1,
              ),
             /* widget.page != ""
                  ?  Container(
                      height: 0.0,
                    )
                  :*/  Container(
                      height: 63.0,
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                           Container(
                            height: 1.0,
                            color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                          ),
                           Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: <Widget>[
                               Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 15.0, 10.0, 0.0),
                                child:new Container(
                                  child:  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.end,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.end,
                                    children: <Widget>[
                                      isType == "Public"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <Widget>[
                                               Expanded(
                                                child:  Container(
                                                    width: 65.0,
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        5.0,
                                                        5.0,
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Public",
                                                            TextAlign
                                                                .start,
                                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            12.0,
                                                            FontWeight
                                                                .normal,
                                                            2))),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                child: Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:
                                                   Image.asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "Private"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <Widget>[
                                               Expanded(
                                                child:  Container(
                                                    width: 65.0,
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        5.0,
                                                        5.0,
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Private",
                                                            TextAlign
                                                                .start,
                                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            12.0,
                                                            FontWeight
                                                                .normal,
                                                            2))),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                child: Padding(
                                                  padding:
                                                  const EdgeInsets
                                                      .fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:  Image
                                                      .asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "AllConnections"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                               Expanded(
                                                child:  Container(
                                                    width:
                                                    85.0,
                                                    child: PaddingWrap.paddingAll(
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Connections",
                                                            TextAlign.start,
                                                             ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                            12.0,
                                                            FontWeight.normal,
                                                            2))),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                child:
                                                Padding(
                                                  padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:  Image
                                                      .asset(
                                                    "assets/profile/post/arrow.png",
                                                    height:
                                                    14.0,
                                                    width:
                                                    14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "Community"
                                          ?  InkWell(
                                          child:  Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                               Expanded(
                                                child:  Container(
                                                    width:
                                                    85.0,
                                                    child: PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        5.0,
                                                        5.0,
                                                        5.0,
                                                        TextViewWrap.textViewMultiLine("Community", TextAlign.start,  ColorValues.BLUE_COLOR_BOTTOMBAR, 12.0, FontWeight.normal, 2))),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                child:
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:  Image
                                                      .asset(
                                                    "assets/profile/post/arrow.png",
                                                    height:
                                                    14.0,
                                                    width:
                                                    14.0,
                                                  ),
                                                ),
                                                flex: 0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          : isType == "Group"
                                          ?  InkWell(
                                          child:
                                           Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                               Expanded(
                                                child:  Container(
                                                    width: 65.0,
                                                    child: PaddingWrap.paddingfromLTRB(10.0, 5.0, 5.0, 5.0, TextViewWrap.textViewMultiLine("Group", TextAlign.start,  ColorValues.BLUE_COLOR_BOTTOMBAR, 12.0, FontWeight.normal, 2))),
                                                flex:
                                                0,
                                              ),
                                               Expanded(
                                                child:
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:
                                                   Image.asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex:
                                                0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          })
                                          :  InkWell(
                                          child:
                                           Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .center,
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                               Expanded(
                                                child:  Container(
                                                    width: 85.0,
                                                    child: PaddingWrap.paddingAll(5.0, TextViewWrap.textViewMultiLine("Selected Connections", TextAlign.start,  ColorValues.BLUE_COLOR_BOTTOMBAR, 12.0, FontWeight.normal, 2))),
                                                flex:
                                                0,
                                              ),
                                               Expanded(
                                                child:
                                                Padding(
                                                  padding: const EdgeInsets.fromLTRB(
                                                      0,
                                                      0,
                                                      7,
                                                      0.0),
                                                  child:
                                                   Image.asset(
                                                    "assets/profile/post/arrow.png",
                                                    height: 14.0,
                                                    width: 14.0,
                                                  ),
                                                ),
                                                flex:
                                                0,
                                              ),
                                            ],
                                          ),
                                          onTap: () {
                                            _settingModalBottomSheet(
                                                context);
                                          }),
                                    ],
                                  ),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Color(0xfff4684EB),
                                      width: 1.0,
                                    ),
                                    borderRadius:
                                    BorderRadius.circular(0),
                                  ),
                                )
                              )
                            ],
                          )
                        ],
                      ),
                    )
            ])));
  }
}
