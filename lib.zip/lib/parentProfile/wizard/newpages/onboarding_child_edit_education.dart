import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:keyboard_visibility/keyboard_visibility.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';

import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/util/KeyboardOverlay.dart';

import 'package:spike_view_project/common/util/appbar_file.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/color_resources.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/education/model/PursuingYearModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/new_onboarding/PrimaryEducation.dart';
import 'package:spike_view_project/new_onboarding/onboarding_education_added_list.dart';
import 'package:spike_view_project/new_onboarding/grad_model.dart';
import 'package:spike_view_project/parentProfile/wizard/AddEducation_Widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class EditEducationWeightChild extends StatefulWidget {
  PrimaryEducation mPrimaryEducation;
  final StudentDataModel studModel;
  final int startYear, endYear;
  final String ScreenName;

  EditEducationWeightChild({
    this.studModel,
    this.mPrimaryEducation,
    this.startYear,
    this.endYear,
    this.ScreenName,
    Key key,
  }) : super(key: key);

  @override
  State<EditEducationWeightChild> createState() => EditEducationState();
}

const Color blueColor = Color(0xFF4684EB);
const Color violetColor = Color(0xFF27275A);

class EditEducationState extends State<EditEducationWeightChild> {
  int educationClickEvent = 0;

  TextEditingController _controllerSchoolGrad = TextEditingController();

  TextEditingController _controllerSchoolGPA = TextEditingController();
  TextEditingController _controllerCollegeGPA = TextEditingController();

  final TextEditingController _searchQueryCollegeName = TextEditingController();
  final TextEditingController _searchQuerySchoolName = TextEditingController();

  final TextEditingController _controllerSchoolClassOff =
  TextEditingController();
  final TextEditingController _controllerCollegeClassOff =
  TextEditingController();

  List<OrganizationModal> organizationLstCollege = List<OrganizationModal>();
  List<OrganizationModal> organizationLstSchool = List<OrganizationModal>();
  List<graditemModel> _primaryGradList = [];
  List<graditemModel> _middleGradList = [];
  List<graditemModel> _highGradList = [];

  String strDegreeYear;
  List<String> yearList = List();
  bool _IsSearchingSchool;
  bool _IsSearchingCollege;
  String selectedTextSchoolName = "",
      _searchTextSchoolCity = "",
      strOrganizationTypeSchool = "School";

  String previousTextSchool = "",
      strOrganizationIdSchool = "",
      year1,
      stryear1 = "";

  String yearCollege, stryearCollege = "";

  String selectedTextCollege = "",
      _searchTextCollegeCity = "",
      strOrganizationTypeCollege = "college";
  String previousTextCollege = "", strOrganizationIdCollege = "";

  Timer _timer;
  int skipIndexSchool = 0;
  bool isAllDataLoadedSchool = false;
  bool isLoadMoreSchool = false;

  bool showPrimaryGradView = false;
  bool showMiddleGradView = false;
  bool showHighGradView = false;

  int skipIndexCollege = 0;
  bool isAllDataLoadedCollege = false;
  bool isLoadMoreCollege = false;
  String userIdPref;

  String primaryFirstGrad = "", primarySecondGrad = "";
  int primaryFirstIndex = 0, primarySecondIndex = 0;

  String middleFirstGrad = "", middleSecondGrad = "";
  int middleFirstIndex = 0, middleSecondIndex = 0;

  String highFirstGrad = "", highSecondGrad = "";
  int highFirstIndex = 0, highSecondIndex = 0;

  SharedPreferences prefs;

  FocusNode SchoolGradPrimaryFocusNode = new FocusNode();
  FocusNode SchoolGradMiddelFocusNode = new FocusNode();
  FocusNode SchoolGradHighFocusNode = new FocusNode();
  FocusNode SchoolYearFocusNode = new FocusNode();

  FocusNode gpaFocus = new FocusNode();
  FocusNode togpaFocus = new FocusNode();

  ScrollController _controller = new ScrollController();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);

    getSchoolName('');
  }

  bool duplicateYear = false;
  bool duplicateGrade = false;
  final _formKey = GlobalKey<FormState>();

  List<int> years;
  bool visiblePrimary = false;
  bool visibleMiddel = false;
  bool visibleHigh = false;
  bool visibleCollege = false;
  FocusNode classOffFocusNode = new FocusNode();

  void setTextFieldValue() {
    if (endYear == null) {
      if (startYear == null) {
        ControllerPrimary.text = "";
      } else {
        ControllerPrimary.text = '$startYear';
      }
    } else {
      if (startYear == null || startYear == 0 || startYear == "null") {
        ControllerPrimary.text = "";
      } else {
        ControllerPrimary.text = '$startYear-$endYear';
      }
    }
    setState(() {});
  }

  void setIndex(int index) {
    print('checking Index $index');
    setState(() {
      if (startIndex == -1) {
        startYear = years[index];
      } else if (startIndex == index) {
        startYear = null;
        endYear = null;
      } else if (endIndex == -1) {
        if (startIndex > index) {
        } else {
          endYear = years[index];
        }
      } else if (endIndex == index) {
        endYear = null;
      } else if (endIndex < index) {
        endYear = years[index];
      } else if (startIndex > index) {
        startYear = years[index];
      } else if (endIndex > index) {
        endYear = years[index];
      }
    });
    if (startYear != null && endYear != null) {
    } else {
      setState(() {
        ControllerPrimary.text = "";
      });
    }

    if (duplicateYear) {
      setState(() {
        duplicateYear = false;
      });
    }
  }

  bool classOffVisible = false;
  bool collageclassOffVisible = false;
  FocusNode SchoolNameFocusNode = new FocusNode();
  FocusNode CollegeNameFocusNode = new FocusNode();

  final ControllerPrimary = TextEditingController();

  int getEndYear() => widget.endYear ?? startYear + 4;
  int startYear, endYear;

  int get startIndex => years.indexWhere((e) => e == startYear);

  int get endIndex => years.indexWhere((e) => e == endYear);

  Color getFontColour(int index) {
    final year = years[index];
    if (startYear == year || endYear == year) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorder(index)) {
      return Color(0xFF4684EB);
    }
    return violetColor;
  }

  Color getBoxColour(int index) {
    final year = years[index];
    if (startYear == year || endYear == year) {
      return blueColor;
    } else if (showBorder(index)) {
      return Color(0xFFF3F5FF);
    }
    return Colors.white;
  }

  bool showBorder(int index) {
    if (index > startIndex && index < endIndex) {
      return true;
    }
    return false;
  }

  int checkFormType;

  bool showBorderGradPrimary(int index) {
    if (index > primaryFirstIndex && index < primarySecondIndex) {
      return true;
    }
    return false;
  }

  Color getBoxColourGradPrimary(int index) {
    final year = _primaryGradList[index].name;
    if (primaryFirstGrad == year || primarySecondGrad == year) {
      return blueColor;
    } else if (showBorderGradPrimary(index)) {
      return Color(0xFFF3F5FF);
    }
    return Colors.white;
  }

  Color getFontColourGradPrimary(int index) {
    final year = _primaryGradList[index];
    if (_primaryGradList[index].selected) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorderGradPrimary(index)) {
      return Color(0xFF4684EB);
    }
    return AppConstants.colorStyle.darkBlue;
  }

  Color getBoxColourGradMiddle(int index) {
    final year = _middleGradList[index].name;
    if (middleFirstGrad == year || middleSecondGrad == year) {
      return blueColor;
    } else if (showBorderGradMiddle(index)) {
      return Color(0xFFF3F5FF);
    }
    return Colors.white;
  }

  bool showBorderGradMiddle(int index) {
    if (index > middleFirstIndex && index < middleSecondIndex) {
      return true;
    }
    return false;
  }

  Color getFontColourGradMiddle(int index) {
    final year = _middleGradList[index];
    if (_middleGradList[index].selected) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorderGradMiddle(index)) {
      return Color(0xFF4684EB);
    }
    return AppConstants.colorStyle.darkBlue;
  }

  bool showBorderGradHigh(int index) {
    if (index > highFirstIndex && index < highSecondIndex) {
      return true;
    }
    return false;
  }

  Color getBoxColourGradHighe(int index) {
    final year = _highGradList[index].name;
    if (highFirstGrad == year || highSecondGrad == year) {
      return blueColor;
    } else if (showBorderGradHigh(index)) {
      return Color(0xFFF3F5FF);
    }
    return Colors.white;
  }

  Color getFontColourGradHigh(int index) {
    final year = _highGradList[index];
    if (_highGradList[index].selected) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorderGradHigh(index)) {
      return Color(0xFF4684EB);
    }
    return AppConstants.colorStyle.darkBlue;
  }

  @override
  void initState() {
    getSharedPreferences();

    setTextFieldValue();

    getCalendarList(widget.endYear);

    KeyboardVisibilityNotification().addNewListener(
      onChange: (bool visible) {
        if(!visible){
          gpaFocus.unfocus();
          togpaFocus.unfocus();
        }
      },
    );


    gpaFocus.addListener(() {
      bool hasFocus = gpaFocus.hasFocus;
      if (hasFocus) {
        KeyboardOverlay.showOverlay(context);
      } else {
        KeyboardOverlay.removeOverlay();
      }
    });

    togpaFocus.addListener(() {
      bool hasFocus = togpaFocus.hasFocus;
      if (hasFocus) {
        KeyboardOverlay.showOverlay(context);
      } else {
        KeyboardOverlay.removeOverlay();
      }
    });

    addPrimaryGrad();
    addMiddleGrad();
    addHighGrad();

    if (widget.mPrimaryEducation.educationType == "Primary") {
      setState(() {
        educationClickEvent = 1;
        checkFormType = 1;
        if (widget.mPrimaryEducation.school?.city == null ||
            widget.mPrimaryEducation.school?.city == "" ||
            widget.mPrimaryEducation.school?.city == "null") {
          _searchQuerySchoolName.text = widget.mPrimaryEducation.institute;
        } else {
          _searchQuerySchoolName.text =
              widget.mPrimaryEducation.institute /*+
                  "," +
                  widget.mPrimaryEducation.school.address +
                  ", " +
                  widget.mPrimaryEducation.school.city*/;
        }

        ControllerPrimary.text = widget.mPrimaryEducation.fromYear.toString() + "-" + widget.mPrimaryEducation.toYear.toString();
        selectedTextSchoolName = widget.mPrimaryEducation.institute.toString();
        startYear = int.parse(widget.mPrimaryEducation.fromYear);
        endYear = int.parse(widget.mPrimaryEducation.toYear);

        _controllerSchoolGrad.text =
            widget.mPrimaryEducation.fromGrade.toString() +
                "-" +
                widget.mPrimaryEducation.toGrade.toString();
        try {
          _searchTextSchoolCity =
              widget.mPrimaryEducation.school?.city.toString();
        }catch(e){
          _searchTextSchoolCity ='';
        }

        for (int i = 0; i < _primaryGradList.length; i++) {
          if (_primaryGradList[i].name.toString() ==
              widget.mPrimaryEducation.fromGrade.toString()) {
            primaryFirstGrad = widget.mPrimaryEducation.fromGrade.toString();
            primaryFirstIndex = i;
            _primaryGradList[i].number = 1;
            _primaryGradList[i].selected = true;
            getBoxColourGradPrimary(i);
            showBorderGradPrimary(i);
          } else if (_primaryGradList[i].name.toString() ==
              widget.mPrimaryEducation.toGrade.toString()) {
            primarySecondGrad = widget.mPrimaryEducation.toGrade.toString();
            primarySecondIndex = i;
            _primaryGradList[i].number = 2;
            _primaryGradList[i].selected = true;
            getBoxColourGradPrimary(i);
            showBorderGradPrimary(i);
          }
        }
      });

      setState(() {
        _primaryGradList;
      });
    } else if (widget.mPrimaryEducation.educationType == "Middle") {
      setState(() {
        educationClickEvent = 2;
        checkFormType = 2;


        if (widget.mPrimaryEducation.school?.city == null || widget.mPrimaryEducation.school.city == "" ||
            widget.mPrimaryEducation.school?.city == "null") {
          _searchQuerySchoolName.text = widget.mPrimaryEducation.institute;
        } else {
          _searchQuerySchoolName.text =
              widget.mPrimaryEducation.institute /*+
                  "," +
                  widget.mPrimaryEducation.school.address +
                  ", " +
                  widget.mPrimaryEducation.school?.city*/;
        }

        ControllerPrimary.text = widget.mPrimaryEducation.fromYear.toString() +
            "-" +
            widget.mPrimaryEducation.toYear.toString();
        _controllerSchoolGrad.text =
            widget.mPrimaryEducation.fromGrade.toString() +
                "-" +
                widget.mPrimaryEducation.toGrade.toString();
        selectedTextSchoolName = widget.mPrimaryEducation.institute.toString();
        startYear = int.parse(widget.mPrimaryEducation.fromYear);
        endYear = int.parse(widget.mPrimaryEducation.toYear);
        _searchTextSchoolCity = widget.mPrimaryEducation.school?.city.toString();

        for (int i = 0; i < _middleGradList.length; i++) {
          if (_middleGradList[i].name.toString() ==
              widget.mPrimaryEducation.fromGrade.toString()) {
            middleFirstGrad = widget.mPrimaryEducation.fromGrade.toString();
            middleFirstIndex = i;
            _middleGradList[i].number = 1;
            _middleGradList[i].selected = true;
            getBoxColourGradMiddle(i);
            showBorderGradMiddle(i);
          } else if (_middleGradList[i].name.toString() ==
              widget.mPrimaryEducation.toGrade.toString()) {
            middleSecondGrad = widget.mPrimaryEducation.toGrade.toString();
            middleSecondIndex = i;
            _middleGradList[i].number = 2;
            _middleGradList[i].selected = true;
            getBoxColourGradMiddle(i);
            showBorderGradMiddle(i);
          }
        }
      });

      setState(() {
        _middleGradList;
      });
    } else if (widget.mPrimaryEducation.educationType == "High") {
      setState(() {
        educationClickEvent = 3;
        checkFormType = 3;
        if (widget.mPrimaryEducation.year.toString() != "") {
          year1 = widget.mPrimaryEducation.year.toString();
          stryear1 = widget.mPrimaryEducation.year.toString();
          _controllerSchoolClassOff.text =
              widget.mPrimaryEducation.year.toString();
        }


        if (widget.mPrimaryEducation.school?.city == null ||
            widget.mPrimaryEducation.school?.city == "" ||
            widget.mPrimaryEducation.school?.city == "null") {
          _searchQuerySchoolName.text = widget.mPrimaryEducation.institute;
        } else {
          _searchQuerySchoolName.text =
              widget.mPrimaryEducation.institute /*+
                  "," +
                  widget.mPrimaryEducation.school.address +
                  ", " +
                  widget.mPrimaryEducation.school?.city*/;
        }

        selectedTextSchoolName = widget.mPrimaryEducation.institute.toString();


        ControllerPrimary.text = widget.mPrimaryEducation.fromYear.toString() +
            "-" +
            widget.mPrimaryEducation.toYear.toString();
        _controllerSchoolGrad.text =
            widget.mPrimaryEducation.fromGrade.toString() +
                "-" +
                widget.mPrimaryEducation.toGrade.toString();
        _searchTextSchoolCity = widget.mPrimaryEducation.school?.city.toString();
        startYear = int.parse(widget.mPrimaryEducation.fromYear);
        endYear = int.parse(widget.mPrimaryEducation.toYear);
        if (widget.mPrimaryEducation.gpa.toString() == "null" ||
            widget.mPrimaryEducation.gpa.toString().isEmpty) {
          _controllerSchoolGPA.text = "";
        } else {
          _controllerSchoolGPA.text = widget.mPrimaryEducation.gpa.toString();
        }

        for (int i = 0; i < _highGradList.length; i++) {
          if (_highGradList[i].name.toString() ==
              widget.mPrimaryEducation.fromGrade.toString()) {
            highFirstGrad = widget.mPrimaryEducation.fromGrade.toString();
            highFirstIndex = i;
            _highGradList[i].number = 1;
            _highGradList[i].selected = true;
            getBoxColourGradHighe(i);
            showBorderGradHigh(i);
          } else if (_highGradList[i].name.toString() ==
              widget.mPrimaryEducation.toGrade.toString()) {
            highSecondGrad = widget.mPrimaryEducation.toGrade.toString();
            highSecondIndex = i;
            _highGradList[i].number = 2;
            _highGradList[i].selected = true;
            getBoxColourGradHighe(i);
            showBorderGradHigh(i);
          }
        }
      });
      setState(() {
        _highGradList;
      });
    } else if (widget.mPrimaryEducation.educationType == "College") {
      setState(() {
        educationClickEvent = 4;
        checkFormType = 4;
        _searchQueryCollegeName.text =
            widget.mPrimaryEducation.institute.toString();
        selectedTextCollege = widget.mPrimaryEducation.institute.toString();
        ControllerPrimary.text = widget.mPrimaryEducation.fromYear.toString() +
            "-" +
            widget.mPrimaryEducation.toYear.toString();
        if (widget.mPrimaryEducation.gpa.toString() == "null" ||
            widget.mPrimaryEducation.gpa.toString().isEmpty) {
          _controllerCollegeGPA.text = "";
        } else {
          _controllerCollegeGPA.text = widget.mPrimaryEducation.gpa.toString();
        }
        startYear = int.parse(widget.mPrimaryEducation.fromYear);
        endYear = int.parse(widget.mPrimaryEducation.toYear);
        if (widget.mPrimaryEducation.year.toString() != "") {
          yearCollege = widget.mPrimaryEducation.year.toString();
          _controllerCollegeClassOff.text =
              widget.mPrimaryEducation.year.toString();
          stryearCollege = widget.mPrimaryEducation.year.toString();
        }

        //
      });
      if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "high school diploma".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "high school diploma".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 5;
          checkFormType = 5;

          //_controller.jumpTo(1);
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Undergraduate Degree".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Undergraduate Degree".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 6;
          checkFormType = 6;
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Masters Degree".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Masters Degree".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 7;
          checkFormType = 7;
        });

        Timer(const Duration(milliseconds: 1000), () async {
          _controller.animateTo(
            //here specifing position= 100 mean 100px
            250,
            curve: Curves.ease,
            duration: Duration(seconds: 1),
          );
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "PhD".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "PhD".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 8;
          checkFormType = 8;

          Timer(const Duration(milliseconds: 1000), () async {
            _controller.animateTo(
              //here specifing position= 100 mean 100px
              300,
              curve: Curves.ease,
              duration: Duration(seconds: 1),
            );
          });
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Associate Degree".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Associate Degree".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 9;
          checkFormType = 9;
        });

        Timer(const Duration(milliseconds: 1000), () async {
          _controller.animateTo(
            //here specifing position= 100 mean 100px
            350,
            curve: Curves.ease,
            duration: Duration(seconds: 1),
          );
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Transfer Degree".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Transfer Degree".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 10;
          checkFormType = 10;
        });

        Timer(const Duration(milliseconds: 1000), () async {
          _controller.animateTo(
            //here specifing position= 100 mean 100px
            400,
            curve: Curves.ease,
            duration: Duration(seconds: 1),
          );
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Professional Certificate".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Professional Certificate".toLowerCase().toString()) {
        setState(() {
          checkFormType = 11;
          educationClickEvent = 11;
        });

        Timer(const Duration(milliseconds: 1000), () async {
          _controller.animateTo(
            //here specifing position= 100 mean 100px
            700,
            curve: Curves.ease,
            duration: Duration(seconds: 1),
          );
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Professional Degree".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Professional Degree".toLowerCase().toString()) {
        setState(() {
          educationClickEvent = 12;
          checkFormType = 12;
        });

        Timer(const Duration(milliseconds: 1000), () async {
          _controller.animateTo(
            //here specifing position= 100 mean 100px
            800,
            curve: Curves.ease,
            duration: Duration(seconds: 1),
          );
        });
      } else if (widget.mPrimaryEducation.degree.toLowerCase().toString() ==
          "Specialist Degree".toLowerCase().toString() ||
          widget.mPrimaryEducation.gradeType.toLowerCase().toString() ==
              "Specialist Degree".toLowerCase().toString()) {
        setState(() {
          checkFormType = 13;
          educationClickEvent = 13;
        });

        Timer(const Duration(milliseconds: 1000), () async {
          _controller.animateTo(
            //here specifing position= 100 mean 100px
            1000,
            curve: Curves.ease,
            duration: Duration(seconds: 1),
          );
        });
      }
    }

    for (int i = widget.startYear; i <= DateTime.now().year + 10; i++) {
      yearList.add(i.toString());
    }
    setState(() {
      yearList = yearList.reversed.toList();
    });

    //  collegePursuingApi();
    _IsSearchingSchool = false;
    _IsSearchingCollege = false;

    _searchQuerySchoolName.addListener(() {
      setState(() {
        visiblePrimary = false;
        visibleMiddel = false;
        visibleHigh = false;
        classOffVisible = false;
        showPrimaryGradView = false;
        showMiddleGradView = false;
        showHighGradView = false;
      });

      if (_searchQuerySchoolName.text.isEmpty) {
        setState(() {
          _IsSearchingSchool = false;
          _searchTextSchoolCity = "";
          previousTextSchool = "";
          organizationLstSchool.clear();
        });
      } else {
        if (selectedTextSchoolName.trim() !=
            _searchQuerySchoolName.text.trim()) {
          if (_searchQuerySchoolName.text.trim().length > 1) {
            if (_timer != null) {
              print("data++++++timer cancel");
              _timer.cancel();
            }
            _timer = Timer(const Duration(milliseconds: 600), () {
              if (previousTextSchool.trim() !=
                  _searchQuerySchoolName.text.trim()) {
                previousTextSchool = _searchQuerySchoolName.text;
                if (!_IsSearchingSchool) {
                  _IsSearchingSchool = true;
                  skipIndexSchool = 0;
                  isAllDataLoadedSchool = false;
                  if (schoolApiCalling) {
                    apiSchoolList(_searchQuerySchoolName.text.trim(), 'school');
                  }
                }
              }
            });
          }
        }
      }
    });

    _searchQueryCollegeName.addListener(() {
      setState(() {
        visibleCollege = false;
        collageclassOffVisible = false;
      });

      if (_searchQueryCollegeName.text.isEmpty) {
        setState(() {
          _IsSearchingCollege = false;
          _searchTextCollegeCity = "";
          previousTextCollege = "";
          organizationLstCollege.clear();
        });
      } else {
        if (selectedTextCollege.trim() != _searchQueryCollegeName.text.trim()) {
          if (_searchQueryCollegeName.text.trim().length > 1) {
            if (_timer != null) {
              print("data++++++timer cancel");
              _timer.cancel();
            }
            _timer = Timer(const Duration(milliseconds: 600), () {
              if (previousTextCollege.trim() !=
                  _searchQueryCollegeName.text.trim()) {
                previousTextCollege = _searchQueryCollegeName.text;
                if (!_IsSearchingCollege) {
                  _IsSearchingCollege = true;
                  skipIndexCollege = 0;
                  isAllDataLoadedCollege = false;

                  apiCallegeList(
                      _searchQueryCollegeName.text.trim(), 'college');
                }
              }
            });
          }
        }
      }
    });

    super.initState();
  }

  bool isSchoolEnable = true;
  bool schoolApiCalling = true;

  Future getSchoolName(schoolCode) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("data++++++searchText===" + schoolCode.toString());
        Response response = await ApiCalling2().apiCall(
            context, Constant.SCHOOL_DETAIL_SCHOOLCODE + schoolCode, "get");
        print("data++++++searchText===" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], 'school');
              if (organizationLst1.length > 0) {
                for (int i = 0; i < organizationLst1.length; i++) {
                  if (prefs.getString(UserPreference.SCHOOL_CODE) ==
                      organizationLst1[i].schoolCode) {
                    setState(() {
                      _searchQuerySchoolName.text = organizationLst1[i].name;
                      /*     strOrganizationId = organizationLst1[i].organizationId;
                      previousOrganizationId =
                          organizationLst1[i].organizationId;
                      schoolName = organizationLst1[i].name;
                      _IsSearching = false;*/
                      schoolApiCalling = false;
                      isSchoolEnable = false;
                    });
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future apiSchoolList(searchText, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {

        Map map = {
          "name": searchText,
          "type":type,
        };


        Response response = await ApiCalling()
            .apiCallPostWithMapDataWithout(mContext, Constant.ENDPOINT_ORGANIZATION_LIST , map);

        _IsSearchingSchool = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              organizationLstSchool.clear();
              organizationLstSchool =
                  ParseJson.parseMapOrganization(response.data['result'], type);

              if (organizationLstSchool.length > 0) {
                setState(() {
                  organizationLstSchool;
                  print("List Lenght ---------" +
                      organizationLstSchool.length.toString());
                });
              }
            }else {
              organizationLstSchool.clear();
            }
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future apiCallegeList(searchText, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {

        Map map = {
          "name": searchText,
          "type":type,
        };


        Response response = await ApiCalling()
            .apiCallPostWithMapDataWithout(mContext, Constant.ENDPOINT_ORGANIZATION_LIST , map);

        _IsSearchingCollege = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              organizationLstCollege.clear();
              organizationLstCollege =
                  ParseJson.parseMapOrganization(response.data['result'], type);
              if (organizationLstCollege.length > 0) {
                setState(() {
                  organizationLstCollege;
                  print("List Lenght ---------" +
                      organizationLstCollege.length.toString());
                });
              }
            }else {
              organizationLstCollege.clear();
            }
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  BuildContext mContext;

  @override
  Widget build(BuildContext context) {
    mContext = context;
    return WillPopScope(
        onWillPop: () async {
       Navigator.pop(context);
        },
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: Colors.white,
          body: FormKeyboardActions(
              nextFocus: false,
              keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
              //optional
              keyboardBarColor: Colors.grey[200],
              //optional
              actions: [
                KeyboardAction(
                  focusNode: gpaFocus,
                ),
                KeyboardAction(
                  focusNode: togpaFocus,
                ),
              ],
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                        "assets/new_onboarding/background_screen.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Column(
                  children: [
                    PaddingWrap.paddingfromLTRB(
                        20.0,
                        50.0,
                        20.0,
                        0.0,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkWell(
                              child: SizedBox(
                                height: 32.0,
                                width: 32.0,
                                child: Center(
                                    child: Image.asset(
                                        "assets/new_onboarding/back_blue_icon.png",
                                        height: 32.0,
                                        width: 32.0,
                                        fit: BoxFit.fitHeight)),
                              ),
                              onTap: () {
                               Navigator.pop(context);


                              },
                            ),
                            const HelpButtonWidget(),
                          ],
                        )),
                    Form(
                        key: _formKey,
                        child: Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            22.0,
                            0.0,
                            0.0,
                            Container(
                                height: MediaQuery.of(mContext).size.height,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(35),
                                      topRight: Radius.circular(35)),
                                ),
                                child: Stack(
                                  children: [
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        18.0,
                                        0.0,
                                        0.0,
                                        Align(
                                          child: Container(
                                            height: 300,
                                            width: 150,
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                image: AssetImage(
                                                  "assets/new_onboarding/education_icon.png",
                                                ),
                                              ),
                                            ),
                                          ),
                                          alignment: Alignment.topRight,
                                        )),
                                    PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        25.0,
                                        20.0,
                                        0.0,
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          children: [
                                            Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              children: [


                                                Text(
                                                  MessageConstant
                                                      .EDIT_EDUCATION_HEDING_1,

    textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 28.0,
                                        fontWeight: FontWeight.w700,
                                        fontFamily: AppConstants
                                            .stringConstant
                                            .latoRegular,
                                      ),

                                            
                                                  // style: TextStyle(
                                                  //   color: ColorValues
                                                  //       .HEADING_COLOR_EDUCATION_1,
                                                  //   fontSize: 28.0,
                                                  //   fontWeight: FontWeight.w700,
                                                  //   fontFamily: AppConstants
                                                  //       .stringConstant
                                                  //       .PoppinsMedium,
                                                  // ),
                                                ),
                                                Text(
                                                  MessageConstant
                                                      .ADD_EDUCATION_HEDING_2,
                                                  textAlign: TextAlign.center,
                                                          style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 28.0,
                                        fontWeight: FontWeight.w700,
                                        fontFamily: AppConstants
                                            .stringConstant
                                            .latoRegular,
                                      ),
                                                  // style: TextStyle(
                                                  //   color: ColorValues
                                                  //       .HEADING_COLOR_EDUCATION_1,
                                                  //   fontSize: 28.0,
                                                  //   fontWeight: FontWeight.w700,
                                                  //   fontFamily: AppConstants
                                                  //       .stringConstant
                                                  //       .PoppinsMedium,
                                                  // ),
                                                ),
                                              ],
                                            ),
                                            educationClickEvent == 0 ||
                                                educationClickEvent == 3 ||
                                                educationClickEvent == 2 ||
                                                educationClickEvent == 1
                                                ? PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                30.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  children: [
                                                    InkWell(
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                            context)
                                                            .size
                                                            .width *
                                                            0.23,
                                                        child: Text(
                                                          'Primary',
                                                          maxLines: 1,
                                                          textAlign:
                                                          TextAlign
                                                              .center,
                                                          style: TextStyle(
                                                            color: educationClickEvent ==
                                                                1
                                                                ? ColorValues
                                                                .WHITE
                                                                : ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontSize: 14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .w500,
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoMedium,
                                                          ),
                                                        ),
                                                        padding:
                                                        EdgeInsets.only(
                                                            top: 9,
                                                            bottom: 9,
                                                            left: 9,
                                                            right: 9),
                                                        decoration:
                                                        BoxDecoration(
                                                          color: educationClickEvent ==
                                                              1
                                                              ? AppConstants
                                                              .colorStyle
                                                              .btn_selected_color
                                                              : AppConstants
                                                              .colorStyle
                                                              .btnBgBorder,
                                                          border: Border.all(
                                                              color: educationClickEvent ==
                                                                  1
                                                                  ? AppConstants
                                                                  .colorStyle
                                                                  .btn_selected_color
                                                                  : AppConstants
                                                                  .colorStyle
                                                                  .btnBg),
                                                          borderRadius: const BorderRadius
                                                              .only(
                                                              topLeft: Radius
                                                                  .circular(
                                                                  10),
                                                              bottomLeft: Radius
                                                                  .circular(
                                                                  10)),
                                                        ),
                                                      ),
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                            context)
                                                            .size
                                                            .width *
                                                            0.20,
                                                        child: Text(
                                                          'Middle',
                                                          maxLines: 1,
                                                          textAlign:
                                                          TextAlign
                                                              .center,
                                                          style: TextStyle(
                                                            color: educationClickEvent ==
                                                                2
                                                                ? ColorValues
                                                                .WHITE
                                                                : ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontSize: 14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .w500,
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoMedium,
                                                          ),
                                                        ),
                                                        padding:
                                                        EdgeInsets.only(
                                                            top: 9,
                                                            bottom: 9,
                                                            left: 9,
                                                            right: 9),
                                                        decoration:
                                                        BoxDecoration(
                                                          color: educationClickEvent ==
                                                              2
                                                              ? AppConstants
                                                              .colorStyle
                                                              .btn_selected_color
                                                              : AppConstants
                                                              .colorStyle
                                                              .btnBgBorder,
                                                          border: Border.all(
                                                              color: educationClickEvent ==
                                                                  2
                                                                  ? AppConstants
                                                                  .colorStyle
                                                                  .btn_selected_color
                                                                  : AppConstants
                                                                  .colorStyle
                                                                  .btnBg),
                                                        ),
                                                      ),
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                            context)
                                                            .size
                                                            .width *
                                                            0.20,
                                                        child: Text(
                                                          'High',
                                                          maxLines: 1,
                                                          textAlign:
                                                          TextAlign
                                                              .center,
                                                          style: TextStyle(
                                                            color: educationClickEvent ==
                                                                3
                                                                ? ColorValues
                                                                .WHITE
                                                                : ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontSize: 14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .w500,
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoMedium,
                                                          ),
                                                        ),
                                                        padding:
                                                        EdgeInsets.only(
                                                            top: 9,
                                                            bottom: 9,
                                                            left: 9,
                                                            right: 9),
                                                        decoration:
                                                        BoxDecoration(
                                                          color: educationClickEvent ==
                                                              3
                                                              ? AppConstants
                                                              .colorStyle
                                                              .btn_selected_color
                                                              : AppConstants
                                                              .colorStyle
                                                              .btnBgBorder,
                                                          border: Border.all(
                                                              color: educationClickEvent ==
                                                                  3
                                                                  ? AppConstants
                                                                  .colorStyle
                                                                  .btn_selected_color
                                                                  : AppConstants
                                                                  .colorStyle
                                                                  .btnBg),
                                                        ),
                                                      ),
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                            context)
                                                            .size
                                                            .width *
                                                            0.25,
                                                        child: Text(
                                                          'College',
                                                          maxLines: 1,
                                                          textAlign:
                                                          TextAlign
                                                              .center,
                                                          style: TextStyle(
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontSize: 14.0,
                                                            fontWeight:
                                                            FontWeight
                                                                .w500,
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoMedium,
                                                          ),
                                                        ),
                                                        padding:
                                                        EdgeInsets.only(
                                                            top: 9,
                                                            bottom: 9,
                                                            left: 9,
                                                            right: 9),
                                                        decoration:
                                                        BoxDecoration(
                                                          color: AppConstants
                                                              .colorStyle
                                                              .btnBgBorder,
                                                          border: Border.all(
                                                              color: AppConstants
                                                                  .colorStyle
                                                                  .btnBg),
                                                          borderRadius: const BorderRadius
                                                              .only(
                                                              topRight: Radius
                                                                  .circular(
                                                                  10),
                                                              bottomRight: Radius
                                                                  .circular(
                                                                  10)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ))
                                                : Container(
                                              height: 0,
                                            ),
                                            educationClickEvent == 4 ||
                                                educationClickEvent == 5 ||
                                                educationClickEvent == 6 ||
                                                educationClickEvent == 7 ||
                                                educationClickEvent == 11 ||
                                                educationClickEvent == 12 ||
                                                educationClickEvent == 8 ||
                                                educationClickEvent == 9 ||
                                                educationClickEvent == 10 ||
                                                educationClickEvent == 13
                                                ? PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                30.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  children: [
                                                    InkWell(
                                                      child: Container(
                                                        child: Center(
                                                          child: Image.asset(
                                                              "assets/new_onboarding/college.png",
                                                              height:
                                                              20.0,
                                                              width:
                                                              20.0,
                                                              fit: BoxFit
                                                                  .fitHeight),
                                                        ),
                                                        height: 37,
                                                        width: 45,
                                                        padding: EdgeInsets
                                                            .only(
                                                            top: 2,
                                                            bottom:
                                                            2,
                                                            left: 3,
                                                            right:
                                                            3),
                                                        decoration:
                                                        BoxDecoration(
                                                          color: AppConstants
                                                              .colorStyle
                                                              .btnBgBorder,
                                                          border: Border.all(
                                                              color: AppConstants
                                                                  .colorStyle
                                                                  .btnBg),
                                                          borderRadius: const BorderRadius
                                                              .only(
                                                              topLeft: Radius
                                                                  .circular(
                                                                  10),
                                                              bottomLeft:
                                                              Radius.circular(
                                                                  10)),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(child:   SingleChildScrollView(
                                                        scrollDirection:
                                                        Axis.horizontal,
                                                        controller: _controller,
                                                        child: Row(
                                                          children: [

                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'High School Diploma',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        5
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      5
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent == 5
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Undergraduate Degree',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        6
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      6
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent == 6
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Masters Degree',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        7
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      7
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent == 7
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'PhD',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        8
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      8
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent == 8
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Associate Degree',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        9
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      9
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent == 9
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Transfer Degree',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        10
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      10
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent ==
                                                                          10
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Professional Certificate',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        11
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      11
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent ==
                                                                          11
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Professional Degree',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        12
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      12
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent ==
                                                                          12
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                ),
                                                              ),
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                child: Text(
                                                                  'Specialist Degree',
                                                                  maxLines: 1,
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:
                                                                  TextStyle(
                                                                    color: educationClickEvent ==
                                                                        13
                                                                        ? ColorValues
                                                                        .WHITE
                                                                        : ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                    fontSize:
                                                                    14.0,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoMedium,
                                                                  ),
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 9,
                                                                    bottom:
                                                                    9,
                                                                    left: 9,
                                                                    right:
                                                                    9),
                                                                decoration:
                                                                BoxDecoration(
                                                                  color: educationClickEvent ==
                                                                      13
                                                                      ? AppConstants
                                                                      .colorStyle
                                                                      .btn_selected_color
                                                                      : AppConstants
                                                                      .colorStyle
                                                                      .btnBgBorder,
                                                                  border: Border.all(
                                                                      color: educationClickEvent ==
                                                                          13
                                                                          ? AppConstants
                                                                          .colorStyle
                                                                          .btn_selected_color
                                                                          : AppConstants
                                                                          .colorStyle
                                                                          .btnBg),
                                                                  borderRadius: const BorderRadius
                                                                      .only(
                                                                      topRight:
                                                                      Radius.circular(
                                                                          10),
                                                                      bottomRight:
                                                                      Radius.circular(
                                                                          10)),
                                                                ),
                                                              ),
                                                            )
                                                          ],
                                                        ))),
                                                  ],
                                                ))
                                                : Container(
                                              height: 0,
                                            ),
                                            SizedBox(height: 5,),
                                            educationClickEvent == 1
                                                ? primaryView()
                                                : Container(
                                              height: 0,
                                            ),
                                            educationClickEvent == 2
                                                ? middleView()
                                                : Container(
                                              height: 0,
                                            ),
                                            educationClickEvent == 3
                                                ? highClassView()
                                                : Container(
                                              height: 0,
                                            ),
                                            educationClickEvent == 5 ||
                                                educationClickEvent == 6 ||
                                                educationClickEvent == 7 ||
                                                educationClickEvent == 11 ||
                                                educationClickEvent == 12 ||
                                                educationClickEvent == 8 ||
                                                educationClickEvent == 9 ||
                                                educationClickEvent == 10 ||
                                                educationClickEvent == 13
                                                ? collageView()
                                                : Container(
                                              height: 0,
                                            ),
                                            Container(
                                              height: 50,
                                              child: Align(
                                                alignment: FractionalOffset
                                                    .bottomCenter,
                                                child: educationClickEvent ==
                                                    1 &&
                                                    _searchQuerySchoolName
                                                        .text !=
                                                        '' &&
                                                    startYear != null &&
                                                    endYear != null &&
                                                    _controllerSchoolGrad
                                                        .text !=
                                                        ''
                                                    ? updateButton(1, mContext)
                                                    : educationClickEvent == 2 &&
                                                    _searchQuerySchoolName
                                                        .text !=
                                                        '' &&
                                                    startYear != null &&
                                                    endYear != null &&
                                                    _controllerSchoolGrad
                                                        .text !=
                                                        ''
                                                    ? updateButton(
                                                    1, mContext)
                                                    :  educationClickEvent == 3 &&eventHighButton(3)
                                                    ? updateButton(
                                                    1, mContext)
                                                    : eventButton(5)
                                                    ? updateButton(
                                                    1, mContext)
                                                    : eventButton(6)
                                                    ? updateButton(
                                                    1,
                                                    mContext)
                                                    : eventButton(
                                                    7)
                                                    ? updateButton(
                                                    1,
                                                    mContext)
                                                    : eventButton(
                                                    8)
                                                    ? updateButton(1,
                                                    mContext)
                                                    : eventButton(9)
                                                    ? updateButton(1, mContext)
                                                    : eventButton(10)
                                                    ? updateButton(1, mContext)
                                                    : eventButton(11)
                                                    ? updateButton(1, mContext)
                                                    : eventButton(12)
                                                    ? updateButton(1, mContext)
                                                    : eventButton(13)
                                                    ? updateButton(1, mContext)
                                                    : updateButton(0, mContext), //Your widget here,
                                              ),
                                            ),
                                            Container(
                                              height: 50,
                                              child: Align(
                                                alignment: FractionalOffset
                                                    .bottomCenter,
                                                child: deleteButton(mContext),
                                              ),
                                            )
                                          ],
                                        ))
                                  ],
                                )),
                          ),
                        )),
                  ],
                ) /* add child content here */,
              )),
        ));
  }

  updateButton(int visible, BuildContext mContext) {
    return Container(
        height: 50,
        child: Padding(
            padding: EdgeInsets.only(bottom: 0.0, left: 20, right: 20),
            child: Stack(
              children: [
                Container(
                    height: 44.0,
                    child: FlatButton(
                      onPressed: () {
                        if (visible == 1) {
                          final form = _formKey.currentState;
                          form.save();
                          if (form.validate()) {
                            if (educationClickEvent == 1) {
                              if (primaryFirstGrad == "") {
                                primaryFirstGrad =
                                    widget.mPrimaryEducation.fromGrade;
                                primarySecondGrad =
                                    widget.mPrimaryEducation.toGrade;
                              }
                            }

                            if (educationClickEvent == 2) {
                              if (middleFirstGrad == "") {
                                middleFirstGrad =
                                    widget.mPrimaryEducation.fromGrade;
                                middleSecondGrad =
                                    widget.mPrimaryEducation.toGrade;
                              }
                            }

                            if (educationClickEvent == 3) {
                              if (highFirstGrad == "") {
                                highFirstGrad =
                                    widget.mPrimaryEducation.fromGrade;
                                highSecondGrad =
                                    widget.mPrimaryEducation.toGrade;
                              }
                            }

                            addEducationApi(mContext);
                          } else {
                            print('Form is invalid');
                          }
                        }
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: AppConstants.colorStyle.lightBlue,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(AppConstants.stringConstant.str_btn_update,
                              style: AppConstants
                                  .txtStyle.heading18600LatoRegularWhite),
                        ],
                      ),
                    )),
                visible == 0
                    ? Container(
                    color: Colors.white60,
                    height: 44.0,
                    child: FlatButton(
                      onPressed: () {},
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: Colors.transparent,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(AppConstants.stringConstant.str_btn_update,
                              style: AppConstants
                                  .txtStyle.heading18600LatoRegularWhite),
                        ],
                      ),
                    ))
                    : Container(
                  height: 0,
                ),
              ],
            )));
  }

  deleteButton(BuildContext mContext) {
    return Container(
        height: 50,
        child: Padding(
            padding: EdgeInsets.only(bottom: 0.0, left: 20, right: 20),
            child: Stack(
              children: [
                Container(
                    height: 44.0,
                    child: FlatButton(
                      onPressed: () {
                        deleteEducationApi(mContext);
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: AppConstants.colorStyle.white,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(AppConstants.stringConstant.str_btn_delete,
                              style: AppConstants
                                  .txtStyle.heading18600LatoRegularRed),
                        ],
                      ),
                    )),
              ],
            )));
  }

  Text getTextLabel1(txt, size, color, fontWeight) {
    return Text(
      txt,
      textAlign: TextAlign.start,
      style: TextStyle(
        color: ColorValues.HEADING_COLOR_EDUCATION,
        fontSize: 14.0,
        fontWeight: FontWeight.w500,
        fontFamily: AppConstants.stringConstant.latoMedium,
      ),
    );
  }

  List<InkWell> _buildSearchListSchool() {
    return List.generate(organizationLstSchool.length, (int index) {
      return InkWell(
          child: Container(
            height: 57,
            margin: EdgeInsets.only(top: 3, bottom: 3, left: 5, right: 5),
            padding: EdgeInsets.only(top: 3, bottom: 2, left: 10, right: 10),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.tabBg,
              border: Border.all(color: AppConstants.colorStyle.btnBg),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center ,//Center Column contents vertically,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Align(
                  child: Text(
                    organizationLstSchool[index].name,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),
                organizationLstSchool[index].address.toString() == null ||
                    organizationLstSchool[index].address.toString() ==
                        "null" ||
                    organizationLstSchool[index].address.toString() == ""
                    ? Container(
                  height: 0,
                )
                    : Align(
                  child: Text(
                    organizationLstSchool[index].address +
                        ", " +
                        organizationLstSchool[index].city +
                        ", " +
                        organizationLstSchool[index].state,
                    maxLines: 1,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 14.0,
                      fontWeight: FontWeight.w500,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),
                /* ListTile(
                  title:
                  subtitle:

                ),*/
              ],
            ),
          ),
          onTap: () {
            setState(() {
              selectedTextSchoolName = organizationLstSchool[index].name;

              _searchTextSchoolCity = organizationLstSchool[index].city;
              _searchQuerySchoolName.text = organizationLstSchool[index].name;
              if (organizationLstSchool[index].city == null ||
                  organizationLstSchool[index].city == "" ||
                  organizationLstSchool[index].city == "null") {
                _searchQuerySchoolName.text = organizationLstSchool[index].name;
              } else {
                _searchQuerySchoolName.text =
                    organizationLstSchool[index].name /*+
                        "," +
                        organizationLstSchool[index].address +
                        ", " +
                        organizationLstSchool[index].city*/;
              }
              strOrganizationIdSchool =
                  organizationLstSchool[index].organizationId;
              strOrganizationTypeSchool = organizationLstSchool[index].type;

              _searchQuerySchoolName.selection = TextSelection.collapsed(
                  offset: _searchQuerySchoolName.text.length);
              organizationLstSchool.clear();
              _IsSearchingSchool = false;
            });
          });
    });
  }

  List<InkWell> _buildSearchListCollege() {
    return List.generate(organizationLstCollege.length, (int index) {
      return InkWell(
          child: Container(
            height: 45,
            margin: EdgeInsets.only(top: 3, bottom: 3, left: 5, right: 5),
            padding: EdgeInsets.only(top: 7, bottom: 2, left: 10, right: 10),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.tabBg,
              border: Border.all(color: AppConstants.colorStyle.btnBg),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center ,//Center Column contents vertically,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Align(
                  child: Text(
                    organizationLstCollege[index].name,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),

                /* subtitle: Text(
                    organizationLstCollege[index].city +
                        "," +
                        organizationLstCollege[index].state,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 14.0,
                      fontWeight: FontWeight.w500,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),*/

                /*organizationLstCollege.length > 20 &&
                        organizationLstCollege.length - 1 == index
                    ? isLoadMoreCollege
                        ? Container(
                            child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(
                                  ColorValues.BLUE_COLOR_BOTTOMBAR),
                              strokeWidth: 2.0,
                            ),
                          ))
                        : isAllDataLoadedCollege
                            ? SizedBox(
                                height: 0,
                              )
                            : ListTile(
                                onTap: () {
                                  skipIndexCollege++;
                                  setState(() {
                                    isLoadMoreCollege = true;
                                  });
                                  recommendationApiLoadMoreCollege();
                                },
                                title: Text(
                                  'View More',
                                  style: TextStyle(
                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                ))
                    : SizedBox()*/
              ],
            ),
          ),
          onTap: () {
            setState(() {
              selectedTextCollege = organizationLstCollege[index].name;
              _searchQueryCollegeName.text = organizationLstCollege[index].name;
              strOrganizationIdCollege =
                  organizationLstCollege[index].organizationId;
              strOrganizationTypeCollege = organizationLstCollege[index].type;
              _searchQueryCollegeName.selection = TextSelection.collapsed(
                  offset: _searchQueryCollegeName.text.length);
              organizationLstCollege.clear();
              _IsSearchingCollege = false;
            });
          });
    });
  }

  Container getClassOfData() {
    return Container(
        child: Column(
          children: <Widget>[
            PaddingWrap.paddingfromLTRB(
                0.0,
                20.0,
                0.0,
                0.0,
                TextField(
                  controller: _controllerSchoolClassOff,
                  showCursor: false,
                  readOnly: true,
                  onTap: () {
                    print("classOffVisible..222.."+classOffVisible.toString());
                    if(classOffVisible){
                      print("classOffVisible..111.."+classOffVisible.toString());
                      setState(() {
                        visibleHigh= false;
                        classOffVisible = false;
                        organizationLstSchool.clear();
                        SchoolNameFocusNode.unfocus();
                      });
                    }else {
                      print("classOffVisible...."+classOffVisible.toString());
                      setState(() {
                        visibleHigh= false;
                        classOffVisible = true;
                        organizationLstSchool.clear();
                        SchoolNameFocusNode.unfocus();
                      });
                    }

                  },
                  focusNode: classOffFocusNode,
                  style:  AppConstants.txtStyle.txtStyleTextForm,
                  decoration: InputDecoration(
                      labelText: AppConstants.stringConstant.str_School_class_of,
labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg, width: 1.0)),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.lightBlue,
                              width: 1.0)),
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg, width: 1.0)),
                      disabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg, width: 1.0)),
                      suffixIconConstraints: BoxConstraints(
                        minWidth: 18,
                        minHeight: 18,
                      ),
                      suffixIcon: GestureDetector(
                        child: SizedBox(
                            width: 18.0,
                            height: 18.0,
                            child: Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                              child: classOffVisible == true
                                  ? new Image.asset(
                                'assets/new_onboarding/arrow_up.png',
                              )
                                  : new Image.asset(

                                'assets/new_onboarding/arrow_down.png',
                              ),
                            )),
                      )),
                )),
            classOffVisible == true
                ? PaddingWrap.paddingfromLTRB(
              5.0,
              3.0,
              5.0,
              0.0,
              Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black12,
                            offset: Offset(0, 2),
                            blurRadius: 12)
                      ]),
                  height: yearList.length == 0
                      ? 0.0
                      : yearList.length == 1
                      ? 68.0
                      : yearList.length == 2
                      ? 143.0
                      : yearList.length == 3
                      ? 143.0
                      : 143.0,
                  child: MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: ListView(children: _buildClassOf()))),
            )
                : Container(
              height: 0,
            )
          ],
        ));
  }

  List<InkWell> _buildClassOf() {
    return List.generate(yearList.length, (int index) {
      return InkWell(
          child: Container(
            height: 40,
            margin: EdgeInsets.only(top: 3, bottom: 3, left: 5, right: 5),
            padding: EdgeInsets.only(top: 7, bottom: 2, left: 10, right: 10),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.tabBg,
              border: Border.all(color: AppConstants.colorStyle.btnBg),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: <Widget>[
                Align(
                  child: Text(
                    yearList[index],
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),
              ],
            ),
          ),
          onTap: () {
            setState(() {
              setState(() {
                FocusScope.of(context).requestFocus(new FocusNode());
                SchoolNameFocusNode.unfocus();
                _controllerSchoolClassOff.text = yearList[index];
                year1 = yearList[index];
                stryear1 = yearList[index];
                classOffVisible = false;
                getCalendarList(int.parse(year1));

                startYear = int.parse(year1) - 4;
                endYear = int.parse(year1);
                setTextFieldValue();
              });
            });
          });
    });
  }

  Container getOrganizationUiSchool() {
    return Container(
        child: Column(
          children: <Widget>[
            PaddingWrap.paddingfromLTRB(
                0.0,
                20.0,
                0.0,
                0.0,
                TextFormField(
                    controller: _searchQuerySchoolName,
                    autocorrect: false,
                    enabled: isSchoolEnable,
                    focusNode: SchoolNameFocusNode,
                    enableInteractiveSelection: false,
                    enableSuggestions: false,
                    cursorColor: Constant.CURSOR_COLOR,
                    keyboardType: TextInputType.visiblePassword,
                    style:  AppConstants.txtStyle.txtStyleTextForm,
                    onSaved: (String value) {
                      // firstName.text = value!;
                    },
                    decoration: InputDecoration(
                        labelText: AppConstants.stringConstant.str_School_name,
                        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        suffixIconConstraints: BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        suffixIcon: GestureDetector(
                          child: SizedBox(
                              width: 15.0,
                              height: 15.0,
                              child: Padding(
                                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                  child: Image.asset(
                                    "assets/new_onboarding/search_blue_icon.png",
                                  ))),
                        )))),
            _searchQuerySchoolName.text.trim().length > 1
                ? PaddingWrap.paddingfromLTRB(
                5.0,
                3.0,
                5.0,
                0.0,
                Container(
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 2),
                              blurRadius: 12)
                        ]),
                    height: organizationLstSchool.length == 0
                        ? 0.0
                        : organizationLstSchool.length == 1
                        ? 70.0
                        : organizationLstSchool.length == 2
                        ? 145.0
                        : organizationLstSchool.length == 3
                        ? 190.0
                        : 190.0,
                    child: MediaQuery.removePadding(
                        context: context,
                        removeTop: true,
                        child: ListView(children: _buildSearchListSchool()))))
                : Container(
              height: 0.0,
            )
          ],
        ));
  }

  Container getClassOfDataCollage() {
    return Container(
        child: Column(
          children: <Widget>[
            PaddingWrap.paddingfromLTRB(
              0.0,
              15.0,
              0.0,
              0.0,
              TextField(
                controller: _controllerCollegeClassOff,
                showCursor: false,
                readOnly: true,
                onTap: () {
                  setState(() {
                    if(collageclassOffVisible){
                      setState(() {
                        collageclassOffVisible = false;
                        visibleCollege = false;

                        organizationLstCollege.clear();
                      });
                    }else {
                      setState(() {
                        collageclassOffVisible = true;
                        visibleCollege = false;
                        organizationLstCollege.clear();
                      });
                    }

                  });
                },

                focusNode: classOffFocusNode,
                style:  AppConstants.txtStyle.txtStyleTextForm,
                decoration: InputDecoration(
                    labelText: AppConstants.stringConstant.str_School_class_of,
                    labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                    border: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: AppConstants.colorStyle.btnBg, width: 1.0)),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: AppConstants.colorStyle.lightBlue,
                            width: 1.0)),
                    enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: AppConstants.colorStyle.btnBg, width: 1.0)),
                    disabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: AppConstants.colorStyle.btnBg, width: 1.0)),
                    suffixIconConstraints: BoxConstraints(
                      minWidth: 18,
                      minHeight: 18,
                    ),
                    suffixIcon: GestureDetector(
                      child: SizedBox(
                          width: 18.0,
                          height: 18.0,
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                            child: collageclassOffVisible == true
                                ? new Image.asset(
                              'assets/new_onboarding/arrow_up.png',
                            )
                                : new Image.asset(

                              'assets/new_onboarding/arrow_down.png',
                            ),
                          )),
                    )),
              ),),
            collageclassOffVisible == true
                ? PaddingWrap.paddingfromLTRB(
              5.0,
              3.0,
              5.0,
              0.0,
              Container(
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black12,
                            offset: Offset(0, 2),
                            blurRadius: 12)
                      ]),
                  height: yearList.length == 0
                      ? 0.0
                      : yearList.length == 1
                      ? 68.0
                      : yearList.length == 2
                      ? 143.0
                      : yearList.length == 3
                      ? 143.0
                      : 143.0,
                  child: MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: ListView(children: _buildClassOfCollage()))),
            )
                : Container(
              height: 0,
            )
          ],
        ));
  }

  List<InkWell> _buildClassOfCollage() {
    return List.generate(yearList.length, (int index) {
      return InkWell(
          child: Container(
            height: 40,
            margin: EdgeInsets.only(top: 3, bottom: 3, left: 5, right: 5),
            padding: EdgeInsets.only(top: 7, bottom: 2, left: 10, right: 10),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.tabBg,
              border: Border.all(color: AppConstants.colorStyle.btnBg),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: <Widget>[
                Align(
                  child: Text(
                    yearList[index],
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),
              ],
            ),
          ),
          onTap: () {
            setState(() {
              setState(() {
                FocusScope.of(context).requestFocus(new FocusNode());
                collageclassOffVisible = false;
                CollegeNameFocusNode.unfocus();
                yearCollege = yearList[index];
                stryearCollege = yearList[index];
                getCalendarList(int.parse(yearCollege));

                startYear = int.parse(yearCollege) - 4;
                endYear = int.parse(yearCollege);
                setTextFieldValue();
                _controllerCollegeClassOff.text = yearList[index];
              });
            });
          });
    });
  }

  Container getOrganizationUiCollege() {
    return Container(
        child: Column(
          children: <Widget>[
            PaddingWrap.paddingfromLTRB(
                0.0,
                25.0,
                0.0,
                0.0,
                TextFormField(
                    controller: _searchQueryCollegeName,
                    autocorrect: false,
                    enableInteractiveSelection: false,
                    enableSuggestions: false,
                    focusNode: CollegeNameFocusNode,
                    cursorColor: Constant.CURSOR_COLOR,
                    keyboardType: TextInputType.visiblePassword,
                    style:  AppConstants.txtStyle.txtStyleTextForm,
                    onSaved: (String value) {
                      // firstName.text = value!;
                    },
                    decoration: InputDecoration(
                        labelText: AppConstants.stringConstant.str_College_name,
                        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        suffixIconConstraints: BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        suffixIcon: GestureDetector(
                          child: SizedBox(
                              width: 18.0,
                              height: 18.0,
                              child: Padding(
                                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                  child: Image.asset(
                                    "assets/new_onboarding/search_blue_icon.png",
                                  ))),
                        )))),
            _searchQueryCollegeName.text.trim().length > 1
                ? PaddingWrap.paddingfromLTRB(
                5.0,
                3.0,
                5.0,
                0.0,
                Container(
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 2),
                              blurRadius: 12)
                        ]),
                    height: organizationLstCollege.length == 0
                        ? 0.0
                        : organizationLstCollege.length == 1
                        ? 70.0
                        : organizationLstCollege.length == 2
                        ? 145.0
                        : organizationLstCollege.length == 3
                        ? 145.0
                        : 145.0,
                    child: MediaQuery.removePadding(
                        context: context,
                        removeTop: true,
                        child: ListView(children: _buildSearchListCollege()))))
                : Container(
              height: 0.0,
            )
          ],
        ));
  }

  Future ApiLoadMoreSchool() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": previousTextSchool,
          "type": "School",
          "skip": skipIndexSchool,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(context, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());
        isLoadMoreSchool = false;
        _IsSearchingSchool = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], "School");
              if (organizationLst1.length > 0) {
                setState(() {
                  organizationLstSchool.addAll(organizationLst1);
                });
              } else {
                isAllDataLoadedSchool = true;
              }
            }
          }
        }
        setState(() {});
      } else {
        isLoadMoreSchool = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadMoreSchool = false;
      setState(() {});
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future recommendationApiLoadMoreCollege() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": previousTextCollege,
          "type": "collage",
          "skip": skipIndexCollege,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(context, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());
        isLoadMoreCollege = false;
        _IsSearchingCollege = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], "School");
              if (organizationLst1.length > 0) {
                setState(() {
                  organizationLstCollege.addAll(organizationLst1);
                });
              } else {
                isAllDataLoadedCollege = true;
              }
            }
          }
        }
        setState(() {});
      } else {
        isLoadMoreCollege = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadMoreCollege = false;
      setState(() {});
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  primaryView() {
    return Expanded(
        child: Container(
          color: Colors.transparent,
          child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  getOrganizationUiSchool(),

                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        controller: ControllerPrimary,
                        showCursor: false,
                        readOnly: true,
                        onTap: () {
                          setState(() {


                            organizationLstSchool.clear();
                            visiblePrimary = true;
                            showPrimaryGradView = false;
                            //FocusManager.instance.primaryFocus.unfocus();
                          });
                        },
                        focusNode: SchoolYearFocusNode,
                        style:  AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                              isDense: true,
                              contentPadding:
                              const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelText:
                          AppConstants.stringConstant.str_School_year,
                        ),
                      )),

                  Visibility(
                    visible: visiblePrimary,
                    child: Container(
                      padding: const EdgeInsets.only(top: 0, right: 10, left: 10),
                      decoration: const BoxDecoration(color: Colors.white, boxShadow: [
                        BoxShadow(
                            color: Colors.black12, offset: Offset(0, 2), blurRadius: 12)
                      ]),
                      height: 150,
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.only(top: 10),
                              // physics: const NeverScrollableScrollPhysics(),
                              itemCount: years.length,
                              gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 5,
                                crossAxisSpacing: 0.5,
                                childAspectRatio: 3 / 2,
                              ),
                              itemBuilder: (context, index) {
                                final year = years[index];
                                return InkWell(
                                  onTap: () => setIndex(index),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: getBoxColour(index),
                                      border: showBorder(index)
                                          ? const Border.symmetric(
                                        horizontal:
                                        BorderSide(color: Color(0xFFE5EBF0)),
                                      )
                                          : null,
                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                      borderRadius: showBorder(index)
                                          ? null
                                          : BorderRadius.horizontal(
                                        left: startYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        right: endYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        // right: Radius.circular(25),
                                      ),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 5),
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      years[index].toString(),
                                      style: TextStyle(
                                        color: getFontColour(index),
                                        fontSize: 16,
                                        fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          duplicateYear
                              ? SizedBox(
                            width: double.maxFinite,
                            height: 60,
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                10.0,
                                BaseText(
                                  text:
                                  "You already have school with the same year",
                                  textAlign: TextAlign.center,
                                  textColor: AppConstants.colorStyle.btn_text_red,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 2,
                                )),
                          )
                              : SizedBox(
                            width: double.maxFinite,
                            child: TextButton(
                              onPressed: () {
                                visiblePrimary = false;
                                if (startYear != null && endYear != null) {
                                  setTextFieldValue();
                                } else {
                                  setState(() {
                                    ControllerPrimary.text = "";
                                  });
                                }
                                setState(() {});
                                //  Navigator.pop(context);
                              },
                              child: Text(
                                startYear != null && endYear != null
                                    ? "Apply"
                                    : 'Cancel',
                                style: TextStyle(
                                  color: startYear != null && endYear != null
                                      ? AppConstants.colorStyle.lightBlue
                                      : AppConstants.colorStyle.lightPurple,
                                  fontSize: 16,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      15.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: AppConstants.stringConstant.str_btn_year_hint_primary,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoItalic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        maxLines: 2,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        controller: _controllerSchoolGrad,
                        showCursor: false,
                        readOnly: true,
                        onTap: () {
                          setState(() {
                            showPrimaryGradView = true;
                            visiblePrimary = false;
                            organizationLstSchool.clear();
                          });
                        },
                        focusNode: SchoolGradPrimaryFocusNode,
                        style:  AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelText: AppConstants.stringConstant.str_School_Grad,
                        ),
                      )),
                  showPrimaryGradView
                      ? PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      Container(
                        margin: EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.only(top: 0, right: 10, left: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(1.0),
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 2),
                                blurRadius: 12)
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                                height: 90,
                                child: GridView.builder(
                                    padding: EdgeInsets.only(top: 15),
                                    gridDelegate:
                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 5,
                                      mainAxisSpacing: 1,
                                      crossAxisSpacing: 0.5,
                                      childAspectRatio: 1.9,
                                    ),
                                    itemCount: _primaryGradList.length,
                                    itemBuilder: (BuildContext ctx, index) {
                                      return InkWell(
                                        onTap: ()  {

                                          if (duplicateGrade) {
                                            setState(() {
                                              duplicateGrade = false;
                                            });
                                          }

                                          if (_primaryGradList[index].selected) {
                                            if (primaryFirstGrad ==
                                                _primaryGradList[index].name) {
                                              setState(() {
                                                primaryFirstGrad = "";
                                                primarySecondGrad = "";
                                                primaryFirstIndex = 0;
                                                primarySecondIndex = 0;
                                                _controllerSchoolGrad.text = "";
                                                _primaryGradList.clear();
                                                addPrimaryGrad();
                                              });
                                            }

                                            if (primarySecondGrad ==
                                                _primaryGradList[index].name) {
                                              setState(() {
                                                _primaryGradList[primarySecondIndex]
                                                    .number = 0;
                                                primarySecondIndex = 0;
                                                primarySecondGrad = "";
                                              });
                                            }

                                            setState(() {
                                              _primaryGradList[index].selected =
                                              false;
                                              _primaryGradList[index].number = 0;
                                            });
                                          } else {
                                            setState(() {
                                              if (primaryFirstGrad == "") {
                                                _primaryGradList[index].selected =
                                                true;
                                                _primaryGradList[index].number = 1;
                                                primaryFirstGrad =
                                                    _primaryGradList[index].name;
                                                primaryFirstIndex = index;
                                              } else {
                                                if (primaryFirstIndex > index) {
                                                } else if (primarySecondGrad ==
                                                    "") {
                                                  _primaryGradList[index].selected =
                                                  true;
                                                  primarySecondIndex = index;
                                                  _primaryGradList[index].number =
                                                  2;
                                                  primarySecondGrad =
                                                      _primaryGradList[index].name;
                                                } else {
                                                  setState(() {
                                                    _primaryGradList[
                                                    primarySecondIndex]
                                                        .number = 0;
                                                    _primaryGradList[
                                                    primarySecondIndex]
                                                        .selected = false;
                                                    primarySecondIndex = 0;
                                                    primarySecondGrad = "";
                                                  });
                                                  _primaryGradList[index].selected =
                                                  true;
                                                  primarySecondIndex = index;
                                                  _primaryGradList[index].number =
                                                  2;
                                                  primarySecondGrad =
                                                      _primaryGradList[index].name;
                                                }
                                              }
                                            });
                                          }
                                        },
                                        child: Container(
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color: getBoxColourGradPrimary(index),
                                            border: showBorderGradPrimary(index)
                                                ? const Border.symmetric(
                                              horizontal: BorderSide(
                                                  color: Color(0xFFE5EBF0)),
                                            )
                                                : null,
                                            // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                            borderRadius: showBorderGradPrimary(
                                                index)
                                                ? null
                                                : BorderRadius.horizontal(
                                              left: primaryFirstGrad ==
                                                  _primaryGradList[index]
                                                      .name
                                                  ? const Radius.circular(10)
                                                  : Radius.zero,
                                              right: primarySecondGrad ==
                                                  _primaryGradList[index]
                                                      .name
                                                  ? const Radius.circular(10)
                                                  : Radius.zero,
                                              // right: Radius.circular(25),
                                            ),
                                          ),
                                          child: PaddingWrap.paddingfromLTRB(
                                              5.0,
                                              3.0,
                                              5.0,
                                              3.0,
                                              Text(
                                                _primaryGradList[index].name,
                                                style: TextStyle(
                                                  color: getFontColourGradPrimary(
                                                      index) /* _primaryGradList[index]
                                                      .selected
                                                  ? AppConstants
                                                      .colorStyle.white
                                                  : AppConstants
                                                      .colorStyle.darkBlue*/
                                                  ,
                                                  fontSize: 16.0,
                                                  fontWeight: FontWeight.w600,
                                                  fontFamily: AppConstants
                                                      .stringConstant.latoMedium,
                                                ),
                                              )),
                                        ),
                                      );
                                    })),
                            duplicateGrade
                                ? SizedBox(
                              width: double.maxFinite,
                              height: 60,
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  10.0,
                                  BaseText(
                                    text:
                                    "You already have school with the same grade",
                                    textAlign: TextAlign.center,
                                    textColor: AppConstants.colorStyle.btn_text_red,
                                    fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    maxLines: 2,
                                  )),
                            )
                                : InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  15.0,
                                  0.0,
                                  15.0,
                                  BaseText(
                                    text: primaryFirstGrad == null ||
                                        primaryFirstGrad == ""
                                        ? "Cancel"
                                        : "Apply",
                                    textColor: primaryFirstGrad == null ||
                                        primaryFirstGrad == ""
                                        ? AppConstants.colorStyle.lightPurple
                                        : AppConstants.colorStyle.lightBlue,
                                    fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16,
                                    maxLines: 1,
                                  )),
                              onTap: () {
                                setState(() {
                                  showPrimaryGradView = false;

                                  if (primarySecondGrad == "") {
                                    _controllerSchoolGrad.text = primaryFirstGrad;
                                  } else {
                                    _controllerSchoolGrad.text =
                                        primaryFirstGrad + "-" + primarySecondGrad;
                                  }
                                });
                              },
                            ),
                          ],
                        ),
                      ))
                      : Container(
                    height: 0,
                  )
                ],
              )),
        ));
  }

  middleView() {
    return Expanded(
        child: Container(
          color: Colors.transparent,
          child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  getOrganizationUiSchool(),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        controller: ControllerPrimary,
                        showCursor: false,
                        readOnly: true,
                        onTap: () {

                          visibleMiddel = true;
                          organizationLstSchool.clear();
                          showMiddleGradView = false;
                          setState(() {});
                        },
                        focusNode: SchoolYearFocusNode,
                        style:  AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(
                               isDense: true,
                              contentPadding:
                              const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          labelText:
                          AppConstants.stringConstant.str_School_year,
                        ),
                      )),
                  Visibility(
                    visible: visibleMiddel,
                    child: Container(
                      padding: const EdgeInsets.only(top: 0, right: 10, left: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.0),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 2),
                              blurRadius: 12)
                        ],
                      ),
                      height: 150,
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.only(top: 10),
                              // physics: const NeverScrollableScrollPhysics(),
                              itemCount: years.length,
                              gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 5,
                                crossAxisSpacing: 0.5,
                                childAspectRatio: 3 / 2,
                              ),
                              itemBuilder: (context, index) {
                                final year = years[index];
                                return InkWell(
                                  onTap: () => setIndex(index),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: getBoxColour(index),
                                      border: showBorder(index)
                                          ? const Border.symmetric(
                                        horizontal:
                                        BorderSide(color: Color(0xFFE5EBF0)),
                                      )
                                          : null,
                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                      borderRadius: showBorder(index)
                                          ? null
                                          : BorderRadius.horizontal(
                                        left: startYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        right: endYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        // right: Radius.circular(25),
                                      ),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 5),
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      years[index].toString(),
                                      style: TextStyle(
                                        color: getFontColour(index),
                                        fontSize: 16,
                                        fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          duplicateYear
                              ? SizedBox(
                            width: double.maxFinite,
                            height: 60,
                            child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              10.0,
                              0.0,
                              10.0,
                              Text(
                                "You already have school with the same year",
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                style: TextStyle(
                                  color: AppConstants.colorStyle.btn_text_red,
                                  fontSize: 16,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          )
                              : SizedBox(
                            width: double.maxFinite,
                            child: TextButton(
                              onPressed: () {
                                visibleMiddel = false;

                                if (startYear != null && endYear != null) {
                                  setTextFieldValue();
                                } else {
                                  setState(() {
                                    ControllerPrimary.text = "";
                                  });
                                }
                                setState(() {});
                                //  Navigator.pop(context);
                              },
                              child: Text(
                                startYear != null && endYear != null
                                    ? "Apply"
                                    : 'Cancel',
                                style: TextStyle(
                                  color: startYear != null && endYear != null
                                      ? AppConstants.colorStyle.lightBlue
                                      : AppConstants.colorStyle.lightPurple,
                                  fontSize: 16,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      15.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: AppConstants.stringConstant.str_btn_year_hint_middle,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoItalic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        maxLines: 2,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        controller: _controllerSchoolGrad,
                        showCursor: false,
                        readOnly: true,
                        onTap: () {
                          setState(() {
                            showMiddleGradView = true;
                            visibleMiddel = false;
                            organizationLstSchool.clear();
                          });
                        },
                        focusNode: SchoolGradMiddelFocusNode,
                        style:  AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelText: AppConstants.stringConstant.str_School_Grad,
                        ),
                      )),
                  showMiddleGradView == true
                      ? PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      Container(
                          margin: EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1.0),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black12,
                                  offset: Offset(0, 2),
                                  blurRadius: 12)
                            ],
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                  height: 60,
                                  child: GridView.builder(
                                      gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 5,
                                          childAspectRatio: 1.9,
                                          crossAxisSpacing: 0.5,
                                          mainAxisSpacing: 1),
                                      itemCount: _middleGradList.length,
                                      padding: EdgeInsets.only(
                                          top: 15, left: 10, right: 10),
                                      itemBuilder: (BuildContext ctx, index) {
                                        return InkWell(
                                          onTap: () {


                                            if (duplicateGrade) {
                                              setState(() {
                                                duplicateGrade = false;
                                              });
                                            }

                                            if (_middleGradList[index].selected) {
                                              if (middleFirstGrad ==
                                                  _middleGradList[index].name) {
                                                setState(() {
                                                  middleFirstGrad = "";
                                                  middleSecondGrad = "";
                                                  middleFirstIndex = 0;
                                                  middleSecondIndex = 0;
                                                  _controllerSchoolGrad.text = "";
                                                  _middleGradList.clear();
                                                  addMiddleGrad();
                                                  middleFirstGrad = "";
                                                });
                                              }

                                              if (middleSecondGrad ==
                                                  _middleGradList[index].name) {
                                                setState(() {
                                                  _middleGradList[middleSecondIndex]
                                                      .number = 0;
                                                  middleSecondIndex = 0;
                                                  middleSecondGrad = "";
                                                });
                                              }

                                              setState(() {
                                                _middleGradList[index].selected =
                                                false;
                                                _middleGradList[index].number = 0;
                                              });
                                            } else {
                                              setState(() {
                                                if (middleFirstGrad == "") {
                                                  _middleGradList[index].selected =
                                                  true;
                                                  _middleGradList[index].number = 1;
                                                  middleFirstGrad =
                                                      _middleGradList[index].name;
                                                  middleFirstIndex = index;
                                                } else {
                                                  if (middleFirstIndex > index) {
                                                  } else if (middleSecondGrad ==
                                                      "") {
                                                    _middleGradList[index]
                                                        .selected = true;
                                                    middleSecondIndex = index;
                                                    _middleGradList[index].number =
                                                    2;
                                                    middleSecondGrad =
                                                        _middleGradList[index].name;
                                                  } else {
                                                    setState(() {
                                                      _middleGradList[
                                                      middleSecondIndex]
                                                          .number = 0;
                                                      _middleGradList[
                                                      middleSecondIndex]
                                                          .selected = false;
                                                      middleSecondIndex = 0;
                                                      middleSecondGrad = "";
                                                    });
                                                    _middleGradList[index]
                                                        .selected = true;
                                                    middleSecondIndex = index;
                                                    _middleGradList[index].number =
                                                    2;
                                                    middleSecondGrad =
                                                        _middleGradList[index].name;
                                                  }
                                                }
                                              });
                                            }
                                          },
                                          child: Container(
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                              color: getBoxColourGradMiddle(index),
                                              border: showBorderGradMiddle(index)
                                                  ? const Border.symmetric(
                                                horizontal: BorderSide(
                                                    color: Color(0xFFE5EBF0)),
                                              )
                                                  : null,
                                              // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                              borderRadius: showBorderGradMiddle(
                                                  index)
                                                  ? null
                                                  : BorderRadius.horizontal(
                                                left: middleFirstGrad ==
                                                    _middleGradList[index]
                                                        .name
                                                    ? const Radius.circular(
                                                    10)
                                                    : Radius.zero,
                                                right: middleSecondGrad ==
                                                    _middleGradList[index]
                                                        .name
                                                    ? const Radius.circular(
                                                    10)
                                                    : Radius.zero,
                                                // right: Radius.circular(25),
                                              ),
                                            ),
                                            child: PaddingWrap.paddingfromLTRB(
                                                5.0,
                                                3.0,
                                                5.0,
                                                3.0,
                                                Text(
                                                  _middleGradList[index].name,
                                                  style: TextStyle(
                                                    color: getFontColourGradMiddle(
                                                        index),
                                                    fontSize: 16.0,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: AppConstants
                                                        .stringConstant.latoMedium,
                                                  ),
                                                )),
                                          ),
                                        );
                                      })),
                              duplicateGrade
                                  ? SizedBox(
                                width: double.maxFinite,
                                height: 60,
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                    BaseText(
                                      text:
                                      "You already have school with the same grade",
                                      textAlign: TextAlign.center,
                                      textColor: AppConstants.colorStyle.btn_text_red,
                                      fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      maxLines: 2,
                                    )),
                              )
                                  : InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                    BaseText(
                                      text: middleFirstGrad == null ||
                                          middleFirstGrad == ""
                                          ? "Cancel"
                                          : "Apply",
                                      textColor:
                                      AppConstants.colorStyle.lightPurple,
                                      fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      maxLines: 1,
                                    )),
                                onTap: () {
                                  setState(() {
                                    showMiddleGradView = false;

                                    if (middleSecondGrad == "") {
                                      _controllerSchoolGrad.text = middleFirstGrad;
                                    } else {
                                      _controllerSchoolGrad.text =
                                          middleFirstGrad + "-" + middleSecondGrad;
                                    }
                                  });
                                },
                              ),
                            ],
                          )))
                      : Container(
                    height: 0,
                  )
                ],
              )),
        ));
  }

  highClassView() {
    return Expanded(
        child: Container(
          color: Colors.transparent,
          child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  getOrganizationUiSchool(),


                  getClassOfData(),
                  PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    0.0,
                    TextField(
                      controller: ControllerPrimary,
                      readOnly: true,
                      onTap: () {
                        setState(() {

                          visibleHigh = true;
                          classOffVisible = false;
                          showHighGradView = false;
                          organizationLstSchool.clear();
                        });
                      },
                      focusNode: SchoolYearFocusNode,
                      style: TextStyle(
                        color:  violetColor,
                        fontSize: 18.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                      ),
                      decoration: InputDecoration(
                        labelText: 'Year',
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                      ),
                    ),
                  ),
                  Visibility(
                    visible: visibleHigh,
                    child: Container(
                      padding: const EdgeInsets.only(top: 0, right: 10, left: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.0),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 2),
                              blurRadius: 12)
                        ],
                      ),
                      height: 150,
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.only(top: 10),
                              // physics: const NeverScrollableScrollPhysics(),
                              itemCount: years.length,
                              gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 5,
                                crossAxisSpacing: 0.5,
                                childAspectRatio: 3 / 2,
                              ),
                              itemBuilder: (context, index) {
                                final year = years[index];
                                return InkWell(
                                  onTap: () => setIndex(index),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: getBoxColour(index),
                                      border: showBorder(index)
                                          ? const Border.symmetric(
                                        horizontal:
                                        BorderSide(color: Color(0xFFE5EBF0)),
                                      )
                                          : null,
                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                      borderRadius: showBorder(index)
                                          ? null
                                          : BorderRadius.horizontal(
                                        left: startYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        right: endYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        // right: Radius.circular(25),
                                      ),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 5),
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      years[index].toString(),
                                      style: TextStyle(
                                        color: getFontColour(index),
                                        fontSize: 16,
                                        fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          duplicateYear
                              ? SizedBox(
                            height: 60,
                            width: double.maxFinite,
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                10.0,
                                5.0,
                                BaseText(
                                  text:
                                  "You already have school with the same year",
                                  textAlign: TextAlign.center,
                                  textColor: AppConstants.colorStyle.btn_text_red,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 2,
                                )),
                          )
                              : SizedBox(
                            width: double.maxFinite,
                            child: TextButton(
                              onPressed: () {
                                visibleHigh = false;
                                setState(() {});

                                if (startYear != null && endYear != null) {
                                  setTextFieldValue();
                                } else {
                                  setState(() {
                                    ControllerPrimary.text = "";
                                  });
                                }
                                //  Navigator.pop(context);
                              },
                              child: Text(
                                startYear != null && endYear != null
                                    ? "Apply"
                                    : 'Cancel',
                                style: TextStyle(
                                  color: startYear != null && endYear != null
                                      ? AppConstants.colorStyle.lightBlue
                                      : AppConstants.colorStyle.lightPurple,
                                  fontSize: 16,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      15.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: AppConstants.stringConstant.str_btn_year_hint_high,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoItalic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        maxLines: 2,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        onTap: () {
                          setState(() {
                            showHighGradView = true;
                            visibleHigh = false;
                            classOffVisible = false;
                            organizationLstSchool.clear();
                          });
                        },
                        controller: _controllerSchoolGrad,
                        focusNode: SchoolGradHighFocusNode,
                        readOnly: true,
                        style:  AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg, width: 1.0)),
                          labelText: AppConstants.stringConstant.str_School_Grad,
                        ),
                      )),
                  showHighGradView == true
                      ? PaddingWrap.paddingfromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                      Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(1.0),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black12,
                                  offset: Offset(0, 2),
                                  blurRadius: 12)
                            ],
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                  height: 60,
                                  child: GridView.builder(
                                      gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 5,
                                          childAspectRatio: 1.9,
                                          crossAxisSpacing: 0.5,
                                          mainAxisSpacing: 1),
                                      padding: EdgeInsets.only(top: 15),
                                      itemCount: _highGradList.length,
                                      itemBuilder: (BuildContext ctx, index) {
                                        return InkWell(
                                          onTap: () {

                                            if (duplicateGrade) {
                                              setState(() {
                                                duplicateGrade = false;
                                              });
                                            }

                                            if (_highGradList[index].selected) {
                                              if (highFirstGrad ==
                                                  _highGradList[index].name) {
                                                setState(() {
                                                  highFirstGrad = "";
                                                  highSecondGrad = "";
                                                  highFirstIndex = 0;
                                                  highSecondIndex = 0;
                                                  _controllerSchoolGrad.text = "";
                                                  _highGradList.clear();
                                                  addHighGrad();
                                                  highFirstGrad = "";
                                                });
                                              }

                                              if (highSecondGrad ==
                                                  _highGradList[index].name) {
                                                setState(() {
                                                  _highGradList[highSecondIndex]
                                                      .number = 0;
                                                  highSecondIndex = 0;
                                                  highSecondGrad = "";
                                                });
                                              }

                                              setState(() {
                                                _highGradList[index].selected =
                                                false;
                                                _highGradList[index].number = 0;
                                              });
                                            } else {
                                              setState(() {
                                                if (highFirstGrad == "") {
                                                  _highGradList[index].selected =
                                                  true;
                                                  _highGradList[index].number = 1;
                                                  highFirstGrad =
                                                      _highGradList[index].name;
                                                  highFirstIndex = index;
                                                } else {
                                                  if (highFirstIndex > index) {
                                                  } else if (highSecondGrad == "") {
                                                    _highGradList[index].selected =
                                                    true;
                                                    highSecondIndex = index;
                                                    _highGradList[index].number = 2;
                                                    highSecondGrad =
                                                        _highGradList[index].name;
                                                  } else {
                                                    setState(() {
                                                      _highGradList[highSecondIndex]
                                                          .number = 0;
                                                      _highGradList[highSecondIndex]
                                                          .selected = false;
                                                      highSecondIndex = 0;
                                                      highSecondGrad = "";
                                                    });
                                                    _highGradList[index].selected =
                                                    true;
                                                    highSecondIndex = index;
                                                    _highGradList[index].number = 2;
                                                    highSecondGrad =
                                                        _highGradList[index].name;
                                                  }
                                                }
                                              });
                                            }
                                          },
                                          child: Container(
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                              color: getBoxColourGradHighe(index),
                                              border: showBorderGradHigh(index)
                                                  ? const Border.symmetric(
                                                horizontal: BorderSide(
                                                    color: Color(0xFFE5EBF0)),
                                              )
                                                  : null,
                                              // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                              borderRadius: showBorderGradHigh(
                                                  index)
                                                  ? null
                                                  : BorderRadius.horizontal(
                                                left: highFirstGrad ==
                                                    _highGradList[index]
                                                        .name
                                                    ? const Radius.circular(
                                                    10)
                                                    : Radius.zero,
                                                right: highSecondGrad ==
                                                    _highGradList[index]
                                                        .name
                                                    ? const Radius.circular(
                                                    10)
                                                    : Radius.zero,
                                                // right: Radius.circular(25),
                                              ),
                                            ),
                                            child: PaddingWrap.paddingfromLTRB(
                                                5.0,
                                                3.0,
                                                5.0,
                                                3.0,
                                                Text(
                                                  _highGradList[index].name,
                                                  style: TextStyle(
                                                    color: getFontColourGradHigh(
                                                        index),
                                                    fontSize: 16.0,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: AppConstants
                                                        .stringConstant.latoMedium,
                                                  ),
                                                )),
                                          ),
                                        );
                                      })),
                              duplicateGrade
                                  ? SizedBox(
                                width: double.maxFinite,
                                height: 60,
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                    BaseText(
                                      text:
                                      "You already have school with the same grade",
                                      textAlign: TextAlign.center,
                                      textColor: AppConstants.colorStyle.btn_text_red,
                                      fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      maxLines: 2,
                                    )),
                              )
                                  : InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    15.0,
                                    0.0,
                                    15.0,
                                    BaseText(
                                      text: highFirstGrad == null ||
                                          highFirstGrad == ""
                                          ? "Cancel"
                                          : "Apply",
                                      textColor: highFirstGrad == null ||
                                          highFirstGrad == ""
                                          ? AppConstants.colorStyle.lightPurple
                                          : AppConstants.colorStyle.lightBlue,
                                      fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      maxLines: 1,
                                    )),
                                onTap: () {
                                  setState(() {
                                    showHighGradView = false;

                                    if (highSecondGrad == "") {
                                      _controllerSchoolGrad.text = highFirstGrad;
                                    } else {
                                      _controllerSchoolGrad.text =
                                          highFirstGrad + "-" + highSecondGrad;
                                    }
                                  });
                                },
                              ),
                            ],
                          )))
                      : Container(
                    height: 0,
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      80.0,
                      Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom),
                        child: TextFormField(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(4),// for mobile
                          ],
                          controller: _controllerSchoolGPA,
                          cursorColor: Colors.black,
                          focusNode: gpaFocus,
                          onTap: () {
                            setState(() {
                              classOffVisible = false;
                              organizationLstSchool.clear();
                            });
                          },
                          onChanged: (s){
                            if(s.length==1&& s=="."){
                              setState(() {
                                _controllerSchoolGPA.clear();
                              });
                            }
                          },
                          scrollPadding: EdgeInsets.only(
                              bottom: MediaQuery.of(context).viewInsets.bottom),
                          style: TextStyle(
                            color: AppConstants.colorStyle.darkBlue,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w500,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                          ),

                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            labelText: AppConstants.stringConstant.str_School_gpa,
                            labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                            border: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg, width: 1.0)),
                            focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.lightBlue,
                                    width: 1.0)),
                            enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg, width: 1.0)),
                            disabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg, width: 1.0)),
                            suffixIcon: Padding(
                              padding: EdgeInsets.only(bottom: 10.0),
                              child: Align(
                                alignment: Alignment.bottomCenter,
                                widthFactor: 1.0,
                                heightFactor: 1.0,
                                child: Text(
                                  '${'Optional'}',
                                  style: TextStyle(
                                    color: AppConstants.colorStyle.darkBlue,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: AppConstants.stringConstant.latoItalic,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          validator: (val) {
                            return val.trim().length == 0
                                ? null
                                : !ValidationWidget.isValidaGPA(val)
                                ? MessageConstant.ENTER_gpa_out_of_less
                                : null;
                          },
                        ),
                      )),
                ],
              )),
        ));
  }

  collageView() {
    return Expanded(
        child: Container(
            color: Colors.transparent,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  getOrganizationUiCollege(),
                  getClassOfDataCollage(),


                  PaddingWrap.paddingfromLTRB(
                    0.0,
                    25.0,
                    0.0,
                    0.0,
                    TextField(
                      controller: ControllerPrimary,
                      readOnly: true,
                      onTap: () {

                        visibleCollege = true;
                        collageclassOffVisible = false;
                        organizationLstCollege.clear();
                        setState(() {});
                      },
                      focusNode: SchoolYearFocusNode,
                      style: TextStyle(
                        color:  violetColor,
                        fontSize: 18.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                      ),
                      decoration: InputDecoration(
                        labelText: 'Year',
                        contentPadding:
                        const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg, width: 1.0)),
                      ),
                    ),
                  ),
                  Visibility(
                    visible: visibleCollege,
                    child: Container(
                      padding:
                      const EdgeInsets.only(top: 0, right: 10, left: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(1.0),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 2),
                              blurRadius: 12)
                        ],
                      ),
                      height: 150,
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.only(top: 10),
                              // physics: const NeverScrollableScrollPhysics(),
                              itemCount: years.length,
                              gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 5,
                                crossAxisSpacing: 0.5,
                                childAspectRatio: 3 / 2,
                              ),
                              itemBuilder: (context, index) {
                                final year = years[index];
                                return InkWell(
                                  onTap: () => setIndex(index),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: getBoxColour(index),
                                      border: showBorder(index)
                                          ? const Border.symmetric(
                                        horizontal: BorderSide(
                                            color: Color(0xFFE5EBF0)),
                                      )
                                          : null,
                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                      borderRadius: showBorder(index)
                                          ? null
                                          : BorderRadius.horizontal(
                                        left: startYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        right: endYear == year
                                            ? const Radius.circular(10)
                                            : Radius.zero,
                                        // right: Radius.circular(25),
                                      ),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 5),
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      years[index].toString(),
                                      style: TextStyle(
                                        color: getFontColour(index),
                                        fontSize: 16,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          duplicateYear
                              ? SizedBox(
                            height: 60,
                            width: double.maxFinite,
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                10.0,
                                BaseText(
                                  text:
                                  "You already have college with the same year",
                                  textAlign: TextAlign.center,
                                  textColor: AppConstants
                                      .colorStyle.btn_text_red,
                                  fontFamily: AppConstants
                                      .stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 2,
                                )),
                          )
                              : SizedBox(
                            width: double.maxFinite,
                            child: TextButton(
                              onPressed: () {
                                visibleCollege = false;

                                if (startYear != null &&
                                    endYear != null) {
                                  setTextFieldValue();
                                } else {
                                  setState(() {
                                    ControllerPrimary.text = "";
                                  });
                                }
                                setState(() {});

                                //  Navigator.pop(context);
                              },
                              child: Text(
                                startYear != null && endYear != null
                                    ? "Apply"
                                    : 'Cancel',
                                style: TextStyle(
                                  color: startYear != null &&
                                      endYear != null
                                      ? AppConstants.colorStyle.lightBlue
                                      : AppConstants
                                      .colorStyle.lightPurple,
                                  fontSize: 16,
                                  fontFamily: AppConstants
                                      .stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: AppConstants
                            .stringConstant.str_btn_year_hint_college,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoItalic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        maxLines: 2,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      25.0,
                      0.0,
                      0.0,
                      Padding(
                        padding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom),
                        child: TextFormField(
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          onChanged: (s){
                            if(s.length==1&& s=="."){
                              setState(() {
                                _controllerCollegeGPA.clear();
                              });
                            }
                          },
                          scrollPadding: EdgeInsets.only(
                              bottom: MediaQuery.of(context).viewInsets.bottom),
                          controller: _controllerCollegeGPA,
                          onTap: () {
                            setState(() {
                              collageclassOffVisible = false;
                              organizationLstCollege.clear();
                            });
                          },
                          inputFormatters: [
                            new LengthLimitingTextInputFormatter(4),// for mobile
                          ],
                          cursorColor: Colors.black,
                          focusNode: togpaFocus,
                          style:  AppConstants.txtStyle.txtStyleTextForm,

                          decoration: InputDecoration(
                            contentPadding:
                            const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                            border: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg, width: 1.0)),
                            focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.lightBlue,
                                    width: 1.0)),
                            enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg, width: 1.0)),
                            disabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg, width: 1.0)),
                            labelText:
                            AppConstants.stringConstant.str_School_gpa,
                            errorStyle: Util.errorTextStyle,
                            suffixIcon: Padding(
                              padding: EdgeInsets.only(bottom: 10.0),
                              child: Align(
                                alignment: Alignment.bottomCenter,
                                widthFactor: 1.0,
                                heightFactor: 1.0,
                                child: Text(
                                  '${'Optional'}',
                                  style: TextStyle(
                                    color: AppConstants.colorStyle.darkBlue,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily:
                                    AppConstants.stringConstant.latoItalic,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          validator: (val) {
                            return val.trim().length == 0
                                ? null
                                : !ValidationWidget.isValidaGPA(val)
                                ? MessageConstant.ENTER_gpa_out_of_less
                                : null;
                          },
                        ),
                      )),
                ],
              ),
            )));
  }

  Future<void> deleteEducationApi(BuildContext mContext) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          'educationId': widget.mPrimaryEducation.educationId,
        };
        print("updateEducation///////////" + map.toString());
        Response response = await ApiCalling()
            .apiCallDeleteWithMapData(mContext, '/ui/education', map);

        print("response///////////" + jsonEncode(response.data));

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
            Navigator.pop(context,'push');
            } else {}
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, mContext);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", mContext);
      e.toString();
    }
  }

  Future<void> addEducationApi(BuildContext mContext) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (primarySecondIndex == 0 || primarySecondIndex == null) {
          primarySecondGrad = primaryFirstGrad;
        }
        if (middleSecondIndex == 0 || middleSecondIndex == null) {
          middleSecondGrad = middleFirstGrad;
        }
        if (highSecondIndex == 0 || highSecondIndex == null) {
          highSecondGrad = highFirstGrad;
        }

        if(selectedTextSchoolName.toString()==""){
          selectedTextSchoolName = _searchQuerySchoolName.text;
        } if(selectedTextCollege.toString()==""){
          selectedTextCollege = _searchQueryCollegeName.text;
        }


        Map map = {
          'educationId': widget.mPrimaryEducation.educationId,
          "userId": userIdPref,
          "roleId": "1",
          "gpa": educationClickEvent == 1 || educationClickEvent == 2
              ? ""
              : educationClickEvent == 3
              ? _controllerSchoolGPA.text
              : _controllerCollegeGPA.text,
          'classOf': educationClickEvent == 3
              ? stryear1
              : educationClickEvent == 1 || educationClickEvent == 2
              ? ""
              : stryearCollege,
          "institute": educationClickEvent == 1 ||
              educationClickEvent == 2 ||
              educationClickEvent == 3
              ? selectedTextSchoolName.toString()
              : selectedTextCollege.toString(),
          "city": educationClickEvent == 1 ||
              educationClickEvent == 2 ||
              educationClickEvent == 3
              ? _searchTextSchoolCity
              : '',
          "fromYear": startYear,
          "toYear": endYear,
          "fromGrade": educationClickEvent == 1
              ? primaryFirstGrad
              : educationClickEvent == 2
              ? middleFirstGrad
              : educationClickEvent == 3
              ? highFirstGrad
              : primarySecondGrad == ""
              ? primaryFirstGrad
              : middleSecondGrad == ""
              ? middleFirstGrad
              : highSecondGrad == ""
              ? highFirstGrad
              : "",
          "toGrade": educationClickEvent == 1
              ? primarySecondGrad
              : educationClickEvent == 2
              ? middleSecondGrad
              : educationClickEvent == 3
              ? highSecondGrad
              : "",
          "type": educationClickEvent == 1 ||
              educationClickEvent == 2 ||
              educationClickEvent == 3
              ? "School"
              : "College",
          "gradeType": educationClickEvent == 1
              ? "primary"
              : educationClickEvent == 2
              ? "middle"
              : educationClickEvent == 3
              ? "high"
              : "",
          "degree": educationClickEvent == 5
              ? "high school diploma"
              : educationClickEvent == 6
              ? "Undergraduate Degree"
              : educationClickEvent == 7
              ? "Masters Degree"
              : educationClickEvent == 8
              ? "PhD"
              : educationClickEvent == 9
              ? "Associate Degree"
              : educationClickEvent == 10
              ? "Transfer Degree"
              : educationClickEvent == 11
              ? "Professional Certificate"
              : educationClickEvent == 12
              ? "Professional Degree"
              : educationClickEvent == 13
              ? "Specialist Degree"
              : ""
        };

        Response response = await ApiCalling()
            .apiCallPutWithMapData(context, '/ui/updateEducation', map);
        print("updateEducation///////////" + map.toString());
        print("response///////////" + jsonEncode(response.data.toString()));

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              Navigator.pop(context,'push');
            } else {
              if (msg == "Year entry already exists and can’t be duplicated.") {
                setState(() {
                  if (educationClickEvent == 1) {
                    visiblePrimary = true;
                  } else if (educationClickEvent == 2) {
                    visibleMiddel = true;
                  } else if (educationClickEvent == 3) {
                    visibleHigh = true;
                  } else {
                    visibleCollege = true;
                  }
                  duplicateYear = true;
                });
              }
              if(msg == "Grade entry already exists and can’t be duplicated."){
                setState(() {
                  if (educationClickEvent == 1) {
                    showPrimaryGradView = true;
                  } else if (educationClickEvent == 2) {
                    showMiddleGradView = true;
                  } else if (educationClickEvent == 3) {
                    showHighGradView = true;
                  }
                  duplicateGrade = true;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", mContext);
      e.toString();
    }
  }

  eventButton(int clicEvent) {
    if(_controllerCollegeGPA.text!=""){
      if(ValidationWidget.isValidaGPA(_controllerCollegeGPA.text)){
        return
          educationClickEvent == clicEvent &&
              _searchQueryCollegeName.text != '' &&
              stryearCollege != '' &&
              startYear != null &&
              endYear != null;
      }
      return false;
    }else {
      return
        educationClickEvent == clicEvent &&
            _searchQueryCollegeName.text != '' &&
            stryearCollege != '' &&
            startYear != null &&
            endYear != null;
    }
  }



  void addPrimaryGrad() {
    graditemModel mgraditemModel13 = graditemModel('KG', false, 0);
    _primaryGradList.add(mgraditemModel13);
    graditemModel mgraditemModel = graditemModel('1st', false, 0);
    _primaryGradList.add(mgraditemModel);
    graditemModel mgraditemModel1 = graditemModel('2nd', false, 0);
    _primaryGradList.add(mgraditemModel1);
    graditemModel mgraditemModel2 = graditemModel('3rd', false, 0);
    _primaryGradList.add(mgraditemModel2);
    graditemModel mgraditemModel3 = graditemModel('4th', false, 0);
    _primaryGradList.add(mgraditemModel3);
    graditemModel mgraditemModel4 = graditemModel('5th', false, 0);
    _primaryGradList.add(mgraditemModel4);
    graditemModel mgraditemModel5 = graditemModel('6th', false, 0);
    _primaryGradList.add(mgraditemModel5);
    setState(() {
      _primaryGradList;
    });
  }

  void addMiddleGrad() {
    graditemModel mgraditemModel5 = graditemModel('6th', false, 0);
    _middleGradList.add(mgraditemModel5);
    graditemModel mgraditemModel6 = graditemModel('7th', false, 0);
    _middleGradList.add(mgraditemModel6);
    graditemModel mgraditemModel7 = graditemModel('8th', false, 0);
    _middleGradList.add(mgraditemModel7);

    setState(() {
      _middleGradList;
    });
  }

  void addHighGrad() {
    graditemModel mgraditemModel8 = graditemModel('9th', false, 0);
    _highGradList.add(mgraditemModel8);
    graditemModel mgraditemModel9 = graditemModel('10th', false, 0);
    _highGradList.add(mgraditemModel9);
    graditemModel mgraditemModel10 = graditemModel('11th', false, 0);
    _highGradList.add(mgraditemModel10);
    graditemModel mgraditemModel11 = graditemModel('12th', false, 0);
    _highGradList.add(mgraditemModel11);
    setState(() {
      _highGradList;
    });
  }

  void getCalendarList(int endYearClassOff) {
    years = List.generate(endYearClassOff - widget.startYear + 1,
            (index) => widget.startYear + index);

    setState(() {});
  }

  eventHighButton(int i) {

    if(_controllerSchoolGPA.text!=""){

      if(ValidationWidget.isValidaGPA(_controllerSchoolGPA.text)){
        return
          educationClickEvent == 3 &&
              _searchQuerySchoolName.text != '' &&
              stryear1 != "" &&
              startYear != null &&
              endYear != null &&
              _controllerSchoolGrad.text != '';
      }

      return false;

    }else {
      return
        educationClickEvent == 3 &&
            _searchQuerySchoolName.text != '' &&
            stryear1 != "" &&
            startYear != null &&
            endYear != null &&
            _controllerSchoolGrad.text != '';
    }

  }
}