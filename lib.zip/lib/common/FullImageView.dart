import 'dart:io';
import 'dart:typed_data';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:thumbnails/thumbnails.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';

class FullImageView extends StatefulWidget {
  String image;
  String pageName;

  FullImageView(this.image, {this.pageName});

  @override
  State createState() {
    return  FullImageViewState();
  }
}

class FullImageViewState extends State<FullImageView> {
  // ChewieController _chewieController;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar:  AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Expanded(
                child:  InkWell(
                  child: CustomViews.getBackButton(),
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
                flex: 0,
              ),
               Expanded(
                child:  Text(
                  widget.pageName == null
                      ? "Certificate"
                      : widget.pageName == "Media"
                          ? "Media"
                          : widget.pageName == MessageConstant.EDUCATION_HEDING
                              ? MessageConstant.EDUCATION_HEDING
                              : "",
                  textAlign: TextAlign.center,
                  style:  TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              ),
               Expanded(
                child:  SizedBox(
    height: 40.0,
    width: 40.0,),
                flex: 0,
              ),
            ],
          ),
          backgroundColor: Colors.white,
        ),
        body: Container(
          color: Colors.black,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
              child:  CachedNetworkImage(
                imageUrl: Constant.IMAGE_PATH + widget.image,
                fit: BoxFit.contain,
                placeholder: (context, url) =>
                    _loader(context, "assets/portfolio/certificate.png"),
                errorWidget: (context, url, error) =>
                    _error("assets/portfolio/certificate.png"),
              ),
            ),
          ),
        ));
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child:  Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }
}
