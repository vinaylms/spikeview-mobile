import 'package:flutter/material.dart';

class ClubTeamModel {
  String selectedCountryCode = '1';
  String selectedcoachPhoneCode = "US";
  TextEditingController clubNameController =
           TextEditingController(text: ""),
      teamController =  TextEditingController(text: ""),
      cityController =  TextEditingController(text: ""),
      stateController =  TextEditingController(text: ""),
      jerseyController =  TextEditingController(text: ""),
      coachNameController =  TextEditingController(text: ""),
      coachEmailController =  TextEditingController(text: ""),
      coachPhoneNumberController =  TextEditingController(text: "");

  ClubTeamModel(
      this.clubNameController,
      this.teamController,
      this.cityController,
      this.stateController,
      this.jerseyController,
      this.coachNameController,
      this.coachEmailController,
      this.coachPhoneNumberController,
      {this.selectedCountryCode,
      this.selectedcoachPhoneCode});

  Map<String, dynamic> toJson() => {
        "orgName": this.clubNameController.text == null
            ? ""
            : this.clubNameController.text,
        "teamName":
            this.teamController.text == null ? "" : this.teamController.text,
        "city":
            this.cityController.text == null ? "" : this.cityController.text,
        "state":
            this.stateController.text == null ? "" : this.stateController.text,
        "jersey": this.jerseyController.text == null
            ? ""
            : this.jerseyController.text,
        "coachName": this.coachNameController.text == null
            ? ""
            : this.coachNameController.text,
        "coachEmail": this.coachEmailController.text == null
            ? ""
            : this.coachEmailController.text,
        "coachPhoneNo": this.coachPhoneNumberController.text == null
            ? ""
            : this.coachPhoneNumberController.text,
        "coachCountryCode":
            this.selectedCountryCode == null || this.selectedCountryCode == ""
                ? "1"
                : this.selectedCountryCode,
        "coachPhoneCode": this.selectedcoachPhoneCode == null ||
                this.selectedcoachPhoneCode == ""
            ? "US"
            : this.selectedcoachPhoneCode,
      };
}
