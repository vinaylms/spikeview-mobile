import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/gallery/ChooseAccomplishment.dart';
import 'package:spike_view_project/gallery/SelectCompetencyWidget.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class Accomplishment_Add_Screen extends StatefulWidget {
  String userId;
  List<Assest> assestList;

  Accomplishment_Add_Screen(this.userId, this.assestList);

  @override
  Accomplishment_Add_ScreenState createState() =>
       Accomplishment_Add_ScreenState();
}

class Accomplishment_Add_ScreenState extends State<Accomplishment_Add_Screen> {
  bool chooseExistingAccomplishment = false;
  bool createNewAccomplishment = false;
  String selectedAccomplishment;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    selectWidget() {
      return Container(
        padding: EdgeInsets.fromLTRB(0, 21, 12, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            InkWell(
              child: Row(
                children: <Widget>[
                  Image.asset(
                      chooseExistingAccomplishment
                          ? "assets/newDesignIcon/group/check_radio.png"
                          : "assets/newDesignIcon/group/uncheck_radio.png",
                      height: 22,
                      width: 22),
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0),
                    child: Text(
                      "Choose existing accomplishment",
                      style: TextStyle(fontSize: 14,),
                    ),
                  )
                ],
              ),
              onTap: () {
                if (selectedAccomplishment != null) {
                } else {
                  setState(() {
                    selectedAccomplishment = null;
                    chooseExistingAccomplishment =
                        !chooseExistingAccomplishment;
                    createNewAccomplishment = !chooseExistingAccomplishment;
                  });
                }
              },
            ),
            chooseExistingAccomplishment
                ? InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ChooseAccomplishment(widget.userId,widget.assestList

                              )));
                    },
                    child: Padding(
                        padding: EdgeInsets.only(left: 33, bottom: 2),
                        child: Text('Choose accomplishment',
                            style: TextStyle(
                              fontSize: 12,
                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                            ))),
                  )
                : Container(),
            SizedBox(
              height: 28,
            ),
            InkWell(
              child: Row(
                children: <Widget>[
                  Image.asset(
                      createNewAccomplishment
                          ? "assets/newDesignIcon/group/check_radio.png"
                          : "assets/newDesignIcon/group/uncheck_radio.png",
                      height: 22,
                      width: 22),
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Text(
                      "Create  accomplishment",
                      style: TextStyle(fontSize: 14),
                    ),
                  )
                ],
              ),
              onTap: () {
                if (selectedAccomplishment != null) {
                } else {
                  setState(() {
                    selectedAccomplishment = null;
                    createNewAccomplishment = !createNewAccomplishment;
                    chooseExistingAccomplishment = !createNewAccomplishment;
                  });
                }
              },
            ),
            createNewAccomplishment
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                     SelectCompetencyWidget(
                                        widget.userId, widget.assestList)));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 33),
                            child: Text('Create accomplishment',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: ColorValues.BLUE_COLOR,
                                )),
                          )),
                    ],
                  )
                : Container(),
          ],
        ),
      );
    }

    return  Scaffold(
      appBar:  AppBar(
        automaticallyImplyLeading: false,
        titleSpacing: 0.0,
        brightness: Brightness.light,
        leading:  Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
             InkWell(
              child:  SizedBox(
                height: 40.0,
                width: 40.0,
                child: PaddingWrap.paddingfromLTRB(
                    10.0,
                    5.0,
                    0.0,
                    3.0,
                     Center(
                        child:  Image.asset(
                            "assets/newDesignIcon/navigation/back.png",
                            height: 20.0,
                            width: 10.0,
                            fit: BoxFit.fitHeight))),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            )
          ],
        ),
        title:  Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
             Text(
              "Accomplishment ",
              style:  TextStyle(
                  fontSize: 18.0,
                  fontFamily: Constant.customRegular,
                  color:  ColorValues.HEADING_COLOR_EDUCATION),
            )
          ],
        ),
        actions: <Widget>[
           Container(
            width: 35.0,
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      backgroundColor: ColorValues.singin_bg_color,
      body: SingleChildScrollView(
          child: Padding(
        padding: const EdgeInsets.fromLTRB(13.0, 19.5, 13.0, 0.0),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                 Text(
                  "How would you like to Add media?",
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Row(
              children: <Widget>[
                selectWidget(),
              ],
            )
          ],
        ),
      )),
    );
  }
}
