// Updated COde

import 'dart:async';

import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/more_data.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/studentWizard/CongratulationMobile.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class ChangePassword extends StatefulWidget {
  static String tag = 'login-page';
  String activity;
  String rollId;
  String userId;

  ProfileInfoModal profileInfoModal;

  ChangePassword(this.activity, this.rollId, {this.userId});

  @override
  ChangePasswordState createState() => ChangePasswordState(activity);
}

final formKey = GlobalKey<FormState>();
String strNewPassword = "", strConformPassword = "", strOldPassword = "";
bool _isLoading = false;

class ChangePasswordState extends State<ChangePassword> {
  Color borderColor = Colors.amber;
  String activity, userPassWord, userIdPref;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  TextEditingController txtOldPasswordController;
  TextEditingController txtNewPasswordController =
      TextEditingController(text: "");
  TextEditingController txtConfPasswordController =
      TextEditingController(text: "");
  bool _oldPassObscureText = true;
  bool _newPassObscureText = true;
  bool _confirmPassPassObscureText = true;

  String sasToken = '';

  ProfileInfoModal profileInfoModal;

  ChangePasswordState(this.activity);

  SharedPreferences prefs;
  String
      minimu_chara_icon = /*Icons.radio_button_off_outlined*/ "assets/newDesignIcon/profile_radio_deselected.png";
  Color minimu_chara_color = ColorValues.TEXT_COLOR;

  String special_chara_icon =
      "assets/newDesignIcon/profile_radio_deselected.png"

      /*Icons.radio_button_off_outlined*/;

  String number_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png"

      /*Icons.radio_button_off_outlined*/;

  String Lower_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png"

      /*Icons.radio_button_off_outlined*/;

  Color special_chara_color = ColorValues.TEXT_COLOR;
  Color number_chara_color = ColorValues.TEXT_COLOR;
  Color Lower_chara_color = ColorValues.TEXT_COLOR;

  bool minimu_value = false;
  bool number_value = false;
  bool special_value = false;
  bool lower_value = false;
  bool upper_value = false;
  bool button_click = false;
  bool allFieldCompleted = false;

  checkAllFieldSubmitter() {
    if (txtOldPasswordController.text.length>0 &&
        txtNewPasswordController.text.length>0 &&
        txtConfPasswordController.text.length>0){
      allFieldCompleted = true;
      setState(() {});
    } else {
      allFieldCompleted = false;
      setState(() {});
    }


  }


  void _checkValidation() async {
    final form = formKey.currentState;
    setState(() => _isLoading = true);
    form.save();
    if (form.validate()) {
      print("SUCCESS 00");
      // if (userPassWord == strOldPassword) {
      if (strNewPassword == strConformPassword) {
        changePasswordApiCall();
      } else {
        ToastWrap.showToast("Password does not match.", context);
      }
      // } else {
      //   ToastWrap.showToast("Current password is wrong", context);
      // }
    } else {
      setState(() => _isLoading = false);
      print("Failure 00");
    }
  }

  bool isAdded = true;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    isAdded = prefs.getBool(UserPreference.IS_ADDED_DOB);
    userIdPref = prefs.getString(UserPreference.USER_ID);

    userPassWord = prefs.getString(UserPreference.PASSWORD);
    print("password+++55++" + userPassWord);

    if (activity == "") {
      txtOldPasswordController = TextEditingController(text: "");
    } else {
      txtOldPasswordController = TextEditingController(text: userPassWord);
      strOldPassword = userPassWord;
    }
    setState(() {
      txtOldPasswordController;
      strOldPassword;
    });
  }

  @override
  void initState() {
    super.initState();

    getSharedPreferences();
  }

  onTapSignOut() async {
    try {
      Constant.isAlreadyLoggedIn = false;

      Map map = {
        "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
        "deviceId": prefs.getString("deviceId")
      };
      GlobalSocketConnection.socket
          .emitWithAck("disconnect1", [map]).then((data) {
        print("chat-login++++" + data.toString());
      });

      GlobalSocketConnection.socket.emit("disconnect2", []);
      /*   await GlobalSocketConnection.manager
          .clearInstance(GlobalSocketConnection.socket);*/
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
      prefs.setBool(UserPreference.IS_USER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      prefs.setString(UserPreference.NAME, "");
      prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
      bloc.resetData(prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage(null)),
      );
    } catch (e) {
      print("Error++++" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  Future apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
        };

        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "ParentDashboard", context);
    }
  }

  showSucessMsg(msg, context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
    {
      return ConfirmationDialog(
        headingText: msg,
      //  headingText: 'Successfully change',
        negativeText: 'OK',
        isSucessPopup: true,
        onNegativeTap: () {
          if (activity == "login" || activity == "reset") {
            if (widget.rollId == "2") {
              if (!isAdded) {
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (BuildContext context) => MoreData()));
              } else {
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            DashBoardWidgetParent(
                                prefs.getString(UserPreference.IS_PARENT_ROLE),
                                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                prefs.getString(UserPreference.IS_USER_ROLE))));
              }
            } else if (widget.rollId == "4") {
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          DashBoardWidgetPartner(
                              prefs.getString(UserPreference.IS_PARENT_ROLE),
                              prefs.getString(UserPreference.IS_PARTNER_ROLE),
                              prefs.getString(UserPreference.IS_USER_ROLE))));
            } else {
              print(
                  'changesPassword widget.profileInfoModal::: ${widget
                      .profileInfoModal}');
              if (activity == "login" || activity == "reset") {
                print(
                    'before going to onboarding widget.userId:: ${widget
                        .userId}');
                if (!prefs.getBool(UserPreference.IS_ADDED_DOB)) {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (BuildContext context) => MoreData()));
                } else {
                  StudentOnBoarding().getStudentOnBoardingInit(
                      context, profileInfoModal, sasToken, widget.userId);
                }
                ////navigate to onboarding process
              } else {
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            DashBoardWidget(
                                prefs.getString(UserPreference.IS_PARENT_ROLE),
                                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                                prefs.getString(UserPreference.IS_USER_ROLE))));
              }
            }
          } else {
            // Navigator.pop(context);
            apiCallForLogout();
          }
        },
      );
    });
  }

  changePasswordApiCall() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        final String encryptedstrOldPassword =
            await platform.invokeMethod('encryption', {
          "password": strOldPassword,
        });

        final String encryptedstrNewPassword =
            await platform.invokeMethod('encryption', {
          "password": strNewPassword,
        });
        SharedPreferences prefs = await SharedPreferences.getInstance();
        String token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token};
        // Prepare Data
        Map map = {
          "oldPassword": encryptedstrOldPassword,
          "newPassword": encryptedstrNewPassword,
          'requestType': activity == "" ? "" : "onboarding"
        };

        print("........map..." + map.toString());
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_CHANGE_PASSWORD,
            data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setString(UserPreference.PATHURL, '');
            prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
            prefs.setString(UserPreference.PASSWORD, strNewPassword);
            showSucessMsg(message, context);

            //  ToastWrap.showToast(message);
          } else {
            ToastWrap.showToastLong(message, context);
          }
        } else {
          //CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ChangePassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      // CustomProgressLoader.cancelLoader(context);
      setState(() => _isLoading = false);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final oldPassUi = CustomFormField(
      // maxLength: 35,
      onSaved: (val) => strOldPassword = (val),
      controller: txtOldPasswordController,
      autovalidateMode: AutovalidateMode.disabled,
      prefixWidget: Image.asset(
        getAssetsPNGImg('password'),
        height: 20,
        width: 20,
      ),
      onType: (v) {
        checkAllFieldSubmitter();
      },
      label: "Current password",
      isObsecure: _oldPassObscureText,

      suffixWidget: GestureDetector(
        child: _oldPassObscureText
            ? Padding(
                padding: EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
                child: Image.asset(
                  "assets/newDesignIcon/login/hide.png",
                  width: 25.0,
                  height: 25.0,
                ))
            : Padding(
            padding: EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
            child: Image.asset(
              "assets/newDesignIcon/login/unhide.png",
              width: 25.0,
              height: 25.0,color: AppConstants.colorStyle.lightPurple,
            )),
        onTap: () {
          if (_oldPassObscureText)
            _oldPassObscureText = false;
          else
            _oldPassObscureText = true;

          setState(() {
            _oldPassObscureText;
          });
        },
      ),
      validation: (val) => val.trim().length == 0
          ? MessageConstant.ENTER_CURRENT_PASSWORD_VAL
          /*         : !ValidationWidget.isPass(val)
                  ? MessageConstant.ENTER_CORRECT_CURRENT_PASSWORD_VAL*/
          : null,
    );


    final newPassUi = CustomFormField(
      // maxLength: 35,
      onSaved: (val) => strNewPassword = (val),
      controller: txtNewPasswordController,
      autovalidateMode: AutovalidateMode.disabled,
      prefixWidget: Image.asset(
        getAssetsPNGImg('password'),
        height: 20,
        width: 20,
      ),
      onType: (s) {
        checkAllFieldSubmitter();
        if (s.length >= 8) {
          setState(() {
            minimu_value = true;
            minimu_chara_icon = "assets/newIcon/right.png";
            minimu_chara_color = ColorValues.light_green_new;
          });
        } else if (s.length < 8) {
          setState(() {
            if (button_click) {
              minimu_value = false;

              minimu_chara_icon = "assets/generateScript/cross_close.png";
              minimu_chara_color = ColorValues.circle4;
            } else {
              minimu_value = false;
              minimu_chara_icon =
                  "assets/newDesignIcon/profile_radio_deselected.png";
              minimu_chara_color = ColorValues.light_grey;
            }
          });
        }

        if (ValidationWidget.NumberChara(s)) {
          setState(() {
            number_value = true;
            number_chara_icon = "assets/newIcon/right.png";
            number_chara_color = ColorValues.light_green_new;
          });
        } else if (!ValidationWidget.NumberChara(s)) {
          setState(() {
            if (button_click) {
              number_value = false;
              number_chara_icon = "assets/generateScript/cross_close.png";
              number_chara_color = ColorValues.circle4;
            } else {
              number_value = false;
              number_chara_icon =
                  "assets/newDesignIcon/profile_radio_deselected.png";
              number_chara_color = ColorValues.light_grey;
            }
          });
        }

        if (ValidationWidget.upper_case(s)) {
          if (ValidationWidget.lower_case(s)) {
            setState(() {
              lower_value = true;
              upper_value = true;
              Lower_chara_icon = "assets/newIcon/right.png";
              Lower_chara_color = ColorValues.light_green_new;
            });
          }
        } else if (!ValidationWidget.upper_case(s)) {
          setState(() {
            if (button_click) {
              upper_value = false;
              lower_value = false;
              Lower_chara_icon = "assets/generateScript/cross_close.png";
              Lower_chara_color = ColorValues.circle4;
            } else {
              upper_value = false;
              lower_value = false;
              Lower_chara_icon =
                  "assets/newDesignIcon/profile_radio_deselected.png";
              Lower_chara_color = ColorValues.light_grey;
            }
          });
        }

        if (ValidationWidget.lower_case(s)) {
          if (ValidationWidget.upper_case(s)) {
            setState(() {
              lower_value = true;
              upper_value = true;
              Lower_chara_icon = "assets/newIcon/right.png";
              Lower_chara_color = ColorValues.light_green_new;
            });
          }
        } else if (!ValidationWidget.lower_case(s)) {
          setState(() {
            if (button_click) {
              upper_value = false;
              lower_value = false;
              Lower_chara_icon = "assets/generateScript/cross_close.png";
              Lower_chara_color = ColorValues.circle4;
            } else {
              upper_value = false;
              lower_value = false;
              Lower_chara_icon =
                  "assets/newDesignIcon/profile_radio_deselected.png";
              Lower_chara_color = ColorValues.light_grey;
            }
          });
        }

        if (ValidationWidget.specialCha(s)) {
          setState(() {
            special_value = true;
            special_chara_icon = "assets/newIcon/right.png";
            special_chara_color = ColorValues.light_green_new;
          });
        } else if (!ValidationWidget.specialCha(s)) {
          setState(() {
            if (button_click) {
              special_value = false;
              special_chara_icon = "assets/generateScript/cross_close.png";
              special_chara_color = ColorValues.circle4;
            } else {
              special_value = false;
              special_chara_icon =
                  "assets/newDesignIcon/profile_radio_deselected.png";
              special_chara_color = ColorValues.light_grey;
            }
          });
        }
      },
      label: "New password",
      isObsecure: _newPassObscureText,

      suffixWidget: GestureDetector(
        child: _newPassObscureText
            ?  Padding(
            padding: EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
            child: Image.asset(
              "assets/newDesignIcon/login/hide.png",
              width: 25.0,
              height: 25.0,
            ))
            : Padding(
            padding: EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
            child: Image.asset(
              "assets/newDesignIcon/login/unhide.png",
              width: 25.0,
              height: 25.0,color: AppConstants.colorStyle.lightPurple,
            )),
        onTap: () {
          if (_newPassObscureText)
            _newPassObscureText = false;
          else
            _newPassObscureText = true;

          setState(() {
            _newPassObscureText;
          });
        },
      ),
    );

    final conformPasUi = CustomFormField(
      // maxLength: 35,
      onSaved: (val) => strConformPassword = (val),
      controller: txtConfPasswordController,
      autovalidateMode: AutovalidateMode.disabled,
      prefixWidget: Image.asset(
        getAssetsPNGImg('password'),
        height: 20,
        width: 20,
      ),
      onType: (v) {
        checkAllFieldSubmitter();
      },
      label: "Confirm new password",
      isObsecure: _confirmPassPassObscureText,

      suffixWidget: GestureDetector(
        child: _confirmPassPassObscureText
            ?  Padding(
            padding: EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
            child: Image.asset(
              "assets/newDesignIcon/login/hide.png",
              width: 25.0,
              height: 25.0,
            ))
            : Padding(
            padding: EdgeInsets.fromLTRB(10.0, 18.0, 0.0, 6.0),
            child: Image.asset(
              "assets/newDesignIcon/login/unhide.png",
              width: 25.0,
              height: 25.0,color: AppConstants.colorStyle.lightPurple,
            )),
        onTap: () {
          if (_confirmPassPassObscureText)
            _confirmPassPassObscureText = false;
          else
            _confirmPassPassObscureText = true;

          setState(() {
            _confirmPassPassObscureText;
          });
        },
      ),
      validation: (val) => val.trim().length == 0
          ? MessageConstant.ENTER_CONFIRM_PASSWORD_VAL
          : (strNewPassword != strConformPassword)
              ? MessageConstant.ENTER_CONFIRM_PASSWORD
              : null,
    );



    return WillPopScope(
        onWillPop: () {},
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(FocusNode());
            },
            child: customAppbar(
                context,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Change password ',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: Padding(
                          padding: const EdgeInsets.only(left: 20.0, right: 20,top: 40),
                          child: Container(
                            child: Column(
                              children: <Widget>[
                                Expanded(
                                  child: Container(
                                      child: Container(
                                    padding: EdgeInsets.all(0.0),
                                    child: Form(
                                        key: formKey,
                                        child: ListView(
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          children: <Widget>[
                                            oldPassUi,
                                            SizedBox(
                                              height: 25,
                                            ),
                                            newPassUi,
                                            SizedBox(
                                              height: 25,
                                            ),
                                            conformPasUi,
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                35.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    BaseText(
                                                      text:
                                                          'Your password must have:',
                                                      textColor:
                                                          ColorValues.blackish,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoMedium,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 18,
                                                      textAlign:
                                                          TextAlign.start,
                                                      maxLines: 3,
                                                    )
                                                  ],
                                                )),
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                15.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Image.asset(
                                                      minimu_chara_icon,
                                                      width: 20.0,
                                                      height: 20.0,
                                                    ),
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    BaseText(
                                                      text:
                                                          "Minimum of 8 characters",
                                                      textColor:
                                                          minimu_chara_color,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize: 16,
                                                      textAlign:
                                                          TextAlign.start,
                                                      maxLines: 3,
                                                    )
                                                  ],
                                                )),
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                12.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Image.asset(
                                                      special_chara_icon,
                                                      width: 20.0,
                                                      height: 20.0,
                                                    ),
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    BaseText(
                                                      text:
                                                          "One special character",
                                                      textColor:
                                                          special_chara_color,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize: 16,
                                                      textAlign:
                                                          TextAlign.start,
                                                      maxLines: 3,
                                                    )
                                                  ],
                                                )),
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                12.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Image.asset(
                                                      number_chara_icon,
                                                      width: 20.0,
                                                      height: 20.0,
                                                    ),
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    BaseText(
                                                      text: "One number",
                                                      textColor:
                                                          number_chara_color,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize: 16,
                                                      textAlign:
                                                          TextAlign.start,
                                                      maxLines: 3,
                                                    )
                                                  ],
                                                )),
                                            PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                12.0,
                                                0.0,
                                                0.0,
                                                Row(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Image.asset(
                                                      Lower_chara_icon,
                                                      width: 20.0,
                                                      height: 20.0,
                                                    ),
                                                    SizedBox(
                                                      width: 10,
                                                    ),
                                                    BaseText(
                                                      text:
                                                          "Lower case and upper case letter",
                                                      textColor:
                                                          Lower_chara_color,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoRegular,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize: 16,
                                                      textAlign:
                                                          TextAlign.start,
                                                      maxLines: 3,
                                                    )
                                                  ],
                                                )),
                                          ],
                                        )),
                                  )),
                                  flex: 1,
                                )
                              ],
                            ),
                          )),
                      flex: 1,
                    ),
                  ],
                ), () {
              if (activity == "login" || activity == "reset") {
                prefs.setBool(UserPreference.LOGIN_STATUS, false);
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => LoginPage(null)));
              } else {
                Navigator.pop(context);
              }
            },
                isShowIcon: false,
                bottomNavigation: Stack(
                  children: [
                    PaddingWrap.paddingfromLTRB(
                      20.0,
                      20.0,
                      20.0,
                      20.0,
                      InkWell(
                        child: Container(
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppConstants.colorStyle.lightBlue,
                              border: Border.all(
                                  color: AppConstants.colorStyle.lightBlue),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Align(
                                alignment: Alignment.center,
                                // Align however you like (i.e .centerRight, centerLeft)
                                child: Text(
                                  "Save",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: ColorValues.WHITE,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontSize: 18.0,
                                  ),
                                ))),
                        onTap: () {
                          if (minimu_value) {
                          } else {
                            setState(() {
                              minimu_value = false;
                              minimu_chara_icon =
                                  "assets/generateScript/cross_close.png";
                              minimu_chara_color = ColorValues.circle4;
                            });
                          }
                          if (number_value) {
                          } else {
                            setState(() {
                              number_value = false;
                              number_chara_icon =
                                  "assets/generateScript/cross_close.png";
                              number_chara_color = ColorValues.circle4;
                            });
                          }

                          if (special_value) {
                          } else {
                            setState(() {
                              special_value = false;
                              special_chara_icon =
                                  "assets/generateScript/cross_close.png";
                              special_chara_color = ColorValues.circle4;
                            });
                          }

                          if (lower_value && upper_value) {
                          } else {
                            setState(() {
                              lower_value = false;
                              Lower_chara_icon = "assets/generateScript/cross_close.png";
                              Lower_chara_color = ColorValues.circle4;
                            });
                          }

                          if (minimu_value) {
                            if (number_value) {
                              if (special_value) {
                                if (lower_value) {
                                  FocusScope.of(context).unfocus();

                                  _checkValidation();
                                } else {
                                  button_click = true;
                                }
                              } else {
                                button_click = true;
                              }
                            } else {
                              button_click = true;
                            }
                          } else {
                            button_click = true;
                          }
                        },
                      ),
                    ),
                    allFieldCompleted
                        ? SizedBox(
                      height: 0,
                    )
                        :Container(
                      height: 70.0,
                      width: double.infinity,
                      color: Colors.white.withOpacity(0.75),
                    )
                  ],
                ))));
  }
}
