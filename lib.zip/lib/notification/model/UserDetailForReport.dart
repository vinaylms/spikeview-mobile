import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';

class UserDetailForReport {
  String status;
  Result result;

  UserDetailForReport({this.status, this.result});

  UserDetailForReport.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    result =
    json['result'] != null ? new Result.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class Result {
  String sId;
  String firstName;
  String lastName;
  List<Role> role;
  int userId;
  bool isShowSummary;
  bool isArchived;
  String profilePicture;
  int roleId;
  String coverImage;
  String tagline;
  String summary;
  Report report;

  Result(
      {this.sId,
        this.firstName,
        this.lastName,
        this.role,
        this.userId,
        this.profilePicture,
        this.roleId,
        this.coverImage,
        this.summary,
        this.report});

  Result.fromJson(Map<String, dynamic> json) {
    print("json+++++"+json.toString());
    sId = json['_id'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    tagline = json['tagline'].toString();
    if (json['role'] != null) {
      role = <Role>[];
      json['role'].forEach((v) {
        role.add(new Role.fromJson(v));
      });
    }
    isShowSummary=false;
    userId = json['userId'];
    isArchived = json['isArchived']==null?true:json['isArchived'];
    profilePicture = json['profilePicture'];
    roleId = json['roleId'];
    coverImage = json['coverImage'];
    summary = json['summary']==null?"":json['summary'];
    report =
    json['report'] != null  ?new Report.fromJson(json['report']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    if (this.role != null) {
      data['role'] = this.role.map((v) => v.toJson()).toList();
    }
    data['userId'] = this.userId;
    data['profilePicture'] = this.profilePicture;
    data['roleId'] = this.roleId;
    data['coverImage'] = this.coverImage;
    data['summary'] = this.summary;
    if (this.report != null) {
      data['report'] = this.report.toJson();
    }
    return data;
  }
}

class Role {
  int id;

  Role({this.id});

  Role.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    return data;
  }
}

class Report {
  List<String> reasonType;
  String sId;
  int reportId;
  int reportedBy;
  int reportedRoleId;
  String reportType;
  ReportTypeId reportTypeId;
  String reason;
  int reportDate;
  int iV;

  Report(
      {this.reasonType,
        this.sId,
        this.reportId,
        this.reportedBy,
        this.reportedRoleId,
        this.reportType,
        this.reportTypeId,
        this.reason,
        this.reportDate,
        this.iV});

  Report.fromJson(Map<String, dynamic> json) {
    reasonType = json['reasonType'].cast<String>();
    sId = json['_id'];
    reportId = json['reportId'];
    reportedBy = json['reportedBy'];
    reportedRoleId = json['reportedRoleId'];
    reportType = json['reportType'];
    reportTypeId = json['reportTypeId'] != null?
         new ReportTypeId.fromJson(json['reportTypeId'])
        : null;
    reason = json['reason'];
    reportDate = json['reportDate'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['reasonType'] = this.reasonType;
    data['_id'] = this.sId;
    data['reportId'] = this.reportId;
    data['reportedBy'] = this.reportedBy;
    data['reportedRoleId'] = this.reportedRoleId;
    data['reportType'] = this.reportType;
    if (this.reportTypeId != null) {
      data['reportTypeId'] = this.reportTypeId.toJson();
    }
    data['reason'] = this.reason;
    data['reportDate'] = this.reportDate;
    data['__v'] = this.iV;
    return data;
  }
}

class ReportTypeId {
  int groupId;

  ReportTypeId({this.groupId});

  ReportTypeId.fromJson(Map<String, dynamic> json) {
    groupId = json['groupId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['groupId'] = this.groupId;
    return data;
  }
}