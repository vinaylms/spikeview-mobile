import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';

import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/CustomDropdownButtonNew.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/new_onboarding/grad_model.dart';
import 'package:spike_view_project/parentProfile/wizard/AddEducation_Widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'onboarding_education_added_list_student.dart';

class AddEducationWidgetParentChild extends StatefulWidget {
  const AddEducationWidgetParentChild({
    this.studModel,
    this.startYear,
    this.endYear,
    this.userId,
    this.pageName,
    Key key,
  }) : super(key: key);

  final int startYear, endYear;
  final String userId;
  final String pageName;
  final StudentDataModel studModel;

  @override
  State<AddEducationWidgetParentChild> createState() =>
      AddEducationWidgetParentChildState();
}

const Color blueColor = Color(0xFF4684EB);
const Color violetColor = Color(0xFF27275A);

class AddEducationWidgetParentChildState
    extends State<AddEducationWidgetParentChild> {
  int educationClickEvent = 0;

  TextEditingController _controllerSchoolGrad = TextEditingController();
  final TextEditingController _controllerSchoolClassOff =
      TextEditingController();
  bool classOffVisible = false;
  FocusNode classOffFocusNode = new FocusNode();
  FocusNode focusSchoolGPA = FocusNode();
  FocusNode focusCollegeGPA = FocusNode();
  TextEditingController _controllerSchoolGPA = TextEditingController();
  TextEditingController _controllerCollegeGPA = TextEditingController();

  final TextEditingController _searchQueryCollegeName = TextEditingController();
  final TextEditingController _searchQuerySchoolName = TextEditingController();

  List<OrganizationModal> organizationLstCollege = List<OrganizationModal>();
  List<OrganizationModal> organizationLstSchool = List<OrganizationModal>();

  List<graditemModel> _primaryGradList = [];
  List<graditemModel> _middleGradList = [];
  List<graditemModel> _highGradList = [];

  String strDegreeYear;

  bool _IsSearchingSchool;
  bool _IsSearchingCollege;
  String selectedTextSchoolName = "",
      _searchTextSchoolCity = "",
      strOrganizationTypeSchool = "School";

  String previousTextSchool = "",
      strOrganizationIdSchool = "",
      year1,
      stryear1 = "";

  String yearCollege, stryearCollege = "";

  String selectedTextCollege = "",
      _searchTextCollegeCity = "",
      strOrganizationTypeCollege = "college";
  String previousTextCollege = "", strOrganizationIdCollege = "";

  Timer _timer;
  int skipIndexSchool = 0;
  bool isAllDataLoadedSchool = false;
  bool isLoadMoreSchool = false;

  bool showPrimaryGradView = false;
  bool showMiddleGradView = false;
  bool showHighGradView = false;

  int skipIndexCollege = 0;
  bool isAllDataLoadedCollege = false;
  bool isLoadMoreCollege = false;
  String dob = "760818600000", userIdPref;

  String primaryFirstGrad = "", primarySecondGrad = "";
  int primaryFirstIndex = 0, primarySecondIndex = 0;

  String middleFirstGrad = "", middleSecondGrad = "";
  int middleFirstIndex = 0, middleSecondIndex = 0;

  String highFirstGrad = "", highSecondGrad = "";
  int highFirstIndex = 0, highSecondIndex = 0;

  SharedPreferences prefs;

  FocusNode SchoolGradPrimaryFocusNode = new FocusNode();
  FocusNode SchoolGradMiddelFocusNode = new FocusNode();
  FocusNode SchoolGradHighFocusNode = new FocusNode();
  FocusNode SchoolYearFocusNode = new FocusNode();

  FocusNode SchoolNameFocusNode = new FocusNode();
  FocusNode CollegeNameFocusNode = new FocusNode();
  bool isSchoolEnable = true;
  bool schoolApiCalling = true;
  int diffrenceInDob = 14;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.userId;

    if (widget.studModel.dob != null && widget.studModel.dob != 'null') {
      int millis = int.tryParse(widget.studModel.dob);
      DateTime dobDate = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
    }
    setState(() {});
  }

  final _formKey = GlobalKey<FormState>();

  bool showBorderGradPrimary(int index) {
    if (index > primaryFirstIndex && index < primarySecondIndex) {
      return true;
    }
    return false;
  }

  Color getFontColourGradPrimary(int index) {
    final year = _primaryGradList[index];
    if (_primaryGradList[index].selected) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorderGradPrimary(index)) {
      return Color(0xFF4684EB);
    }
    return AppConstants.colorStyle.darkBlue;
  }

  bool showBorderGradMiddle(int index) {
    if (index > middleFirstIndex && index < middleSecondIndex) {
      return true;
    }
    return false;
  }

  Color getFontColourGradMiddle(int index) {
    final year = _middleGradList[index];
    if (_middleGradList[index].selected) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorderGradMiddle(index)) {
      return Color(0xFF4684EB);
    }
    return AppConstants.colorStyle.darkBlue;
  }

  bool showBorderGradHigh(int index) {
    if (index > highFirstIndex && index < highSecondIndex) {
      return true;
    }
    return false;
  }

  Color getFontColourGradHigh(int index) {
    final year = _highGradList[index];
    if (_highGradList[index].selected) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorderGradHigh(index)) {
      return Color(0xFF4684EB);
    }
    return AppConstants.colorStyle.darkBlue;
  }

  String newText;
  List<String> yearList = List();

  List<int> years;
  bool visiblePrimary = false;
  bool visibleMiddel = false;
  bool visibleHigh = false;
  bool visibleCollege = false;

  bool duplicateYear = false;

  final ControllerPrimary = TextEditingController();

  int getEndYear() => widget.endYear ?? startYear + 4;
  int startYear, endYear;

  int get startIndex => years.indexWhere((e) => e == startYear);

  int get endIndex => years.indexWhere((e) => e == endYear);

  Color getFontColour(int index) {
    final year = years[index];
    if (startYear == year || endYear == year) {
      print('MS Testing :- $year');
      return Colors.white;
    } else if (showBorder(index)) {
      return Color(0xFF4684EB);
    }
    return violetColor;
  }

  Color getBoxColour(int index) {
    final year = years[index];
    if (startYear == year || endYear == year) {
      return blueColor;
    } else if (showBorder(index)) {
      return Color(0xFFE5EBF0);
    }
    return Colors.white;
  }

  Color getBoxColourGradPrimary(int index) {
    final year = _primaryGradList[index].name;
    if (primaryFirstGrad == year || primarySecondGrad == year) {
      return blueColor;
    } else if (showBorderGradPrimary(index)) {
      return Color(0xFFE5EBF0);
    }
    return Colors.white;
  }

  Color getBoxColourGradMiddle(int index) {
    final year = _middleGradList[index].name;
    if (middleFirstGrad == year || middleSecondGrad == year) {
      return blueColor;
    } else if (showBorderGradMiddle(index)) {
      return Color(0xFFE5EBF0);
    }
    return Colors.white;
  }

  Color getBoxColourGradHighe(int index) {
    final year = _highGradList[index].name;
    if (highFirstGrad == year || highSecondGrad == year) {
      return blueColor;
    } else if (showBorderGradHigh(index)) {
      return Color(0xFFE5EBF0);
    }
    return Colors.white;
  }

  void setIndex(int index) {
    print('checking Index $index');
    setState(() {
      if (startIndex == -1) {
        startYear = years[index];
      } else if (startIndex == index) {
        startYear = null;
        endYear = null;
      } else if (endIndex == -1) {
        if (startIndex > index) {
        } else {
          endYear = years[index];
        }
      } else if (endIndex == index) {
        endYear = null;
      } else if (endIndex < index) {
        endYear = years[index];
      } else if (startIndex > index) {
        startYear = years[index];
      } else if (endIndex > index) {
        endYear = years[index];
      }
    });

    if (startYear != null && endYear != null) {
      setTextFieldValue();
    } else {
      setState(() {
        ControllerPrimary.text = "";
      });
    }

    if (duplicateYear) {
      setState(() {
        duplicateYear = false;
      });
    }
  }

  void setTextFieldValue() {
    if (endYear == null) {
      if (startYear == null) {
        ControllerPrimary.text = "";
      } else {
        ControllerPrimary.text = '$startYear';
      }
    } else {
      if (startYear == null || startYear == 0 || startYear == "null") {
        ControllerPrimary.text = "";
      } else {
        ControllerPrimary.text = '$startYear-$endYear';
      }
    }
    setState(() {});
  }

  bool showBorder(int index) {
    if (index > startIndex && index < endIndex) {
      return true;
    }
    return false;
  }

  DateTime dateA = DateTime(1900);
  DateTime dateB = DateTime(2000);

  DateTime dateC = DateTime(1800);
  DateTime dateD = DateTime.now();

  @override
  void initState() {
    print("startYear///////////" + widget.startYear.toString());

    getSharedPreferences();

    getCalendarList(widget.endYear);

    DateTime date = DateTime.fromMillisecondsSinceEpoch(int.tryParse(dob));

    for (int i = date.year; i <= DateTime.now().year + 10; i++) {
      yearList.add(i.toString());
    }
    setState(() {
      yearList = yearList.reversed.toList();
    });

    addPrimaryGrad();
    addMiddleGrad();
    addHighGrad();

    //  collegePursuingApi();
    _IsSearchingSchool = false;
    _IsSearchingCollege = false;

    _searchQuerySchoolName.addListener(() {
      setState(() {
        visiblePrimary = false;
        visibleMiddel = false;
        visibleHigh = false;
        showPrimaryGradView = false;
        showMiddleGradView = false;
        showHighGradView = false;
        classOffVisible = false;
      });
      if (_searchQuerySchoolName.text.isEmpty) {
        setState(() {
          _IsSearchingSchool = false;
          _searchTextSchoolCity = "";
          previousTextSchool = "";
          organizationLstSchool.clear();
        });
      } else {
        if (selectedTextSchoolName.trim() !=
            _searchQuerySchoolName.text.trim()) {
          if (_searchQuerySchoolName.text.trim().length > 1) {
            if (_timer != null) {
              print("data++++++timer cancel");
              _timer.cancel();
            }
            _timer = Timer(const Duration(milliseconds: 600), () {
              if (previousTextSchool.trim() !=
                  _searchQuerySchoolName.text.trim()) {
                previousTextSchool = _searchQuerySchoolName.text;
                if (!_IsSearchingSchool) {
                  _IsSearchingSchool = true;
                  skipIndexSchool = 0;
                  isAllDataLoadedSchool = false;
                  if (schoolApiCalling) {
                    apiSchoolList(_searchQuerySchoolName.text.trim(), 'school');
                  }
                }
              }
            });
          }
        }
      }
    });

    _searchQueryCollegeName.addListener(() {
      setState(() {
        visibleCollege = false;
      });

      if (_searchQueryCollegeName.text.isEmpty) {
        setState(() {
          _IsSearchingCollege = false;
          _searchTextCollegeCity = "";
          previousTextCollege = "";
          organizationLstCollege.clear();
        });
      } else {
        if (selectedTextCollege.trim() != _searchQueryCollegeName.text.trim()) {
          if (_searchQueryCollegeName.text.trim().length > 1) {
            if (_timer != null) {
              print("data++++++timer cancel");
              _timer.cancel();
            }
            _timer = Timer(const Duration(milliseconds: 600), () {
              if (previousTextCollege.trim() !=
                  _searchQueryCollegeName.text.trim()) {
                previousTextCollege = _searchQueryCollegeName.text;
                if (!_IsSearchingCollege) {
                  _IsSearchingCollege = true;
                  skipIndexCollege = 0;
                  isAllDataLoadedCollege = false;

                  apiCallegeList(
                      _searchQueryCollegeName.text.trim(), 'college');
                }
              }
            });
          }
        }
      }
    });

    super.initState();
  }

  Future apiSchoolList(searchText, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": searchText,
          "type": type,
        };

        Response response = await ApiCalling().apiCallPostWithMapDataWithout(
            mContext, Constant.ENDPOINT_ORGANIZATION_LIST, map);

        _IsSearchingSchool = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              organizationLstSchool.clear();
              organizationLstSchool =
                  ParseJson.parseMapOrganization(response.data['result'], type);

              if (organizationLstSchool.length > 0) {
                setState(() {
                  organizationLstSchool;
                  print("List Lenght ---------" +
                      organizationLstSchool.length.toString());
                });
              }
            }
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future apiCallegeList(searchText, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall4(
            context,
            Constant.ENDPOINT_ORGANIZATION_LIST +
                '?name=' +
                searchText +
                '&type=' +
                type,
            "get" /*context, Constant.ENDPOINT_ORGANIZATION_LIST, map*/);
        MessageConstant.printWrapped("data++++++searchText===" +
            Constant.ENDPOINT_ORGANIZATION_LIST +
            '?name=' +
            searchText +
            '&type=' +
            type);
        MessageConstant.printWrapped(
            "data++++++searchText===" + response.toString());

        _IsSearchingCollege = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              organizationLstCollege.clear();
              organizationLstCollege =
                  ParseJson.parseMapOrganization(response.data['result'], type);
              if (organizationLstCollege.length > 0) {
                setState(() {
                  organizationLstCollege;
                  print("List Lenght ---------" +
                      organizationLstCollege.length.toString());
                });
              }
            }
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  BuildContext mContext;

  @override
  Widget build(BuildContext context) {
    mContext = context;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/new_onboarding/background_screen.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: FormKeyboardActions(
          nextFocus: false,
          keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
          //optional
          keyboardBarColor: Colors.grey[200],
          //optional
          actions: [
            KeyboardAction(
              focusNode: focusSchoolGPA,
            ),
            KeyboardAction(
              focusNode: focusCollegeGPA,
            ),
          ],
          child: Column(
            children: [
              PaddingWrap.paddingfromLTRB(
                  20.0,
                  50.0,
                  20.0,
                  22.0,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        child: SizedBox(
                          height: 32.0,
                          width: 32.0,
                          child: Center(
                              child: Image.asset(
                                  "assets/new_onboarding/back_blue_icon.png",
                                  height: 32.0,
                                  width: 32.0,
                                  fit: BoxFit.fitHeight)),
                        ),
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      const HelpButtonWidget(),
                    ],
                  )),
              Form(
                key: _formKey,
                child: Expanded(
                  child: Container(
                    height: MediaQuery.of(mContext).size.height,
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(20, 25, 20, 0),
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(35),
                          topRight: Radius.circular(35)),
                      image: DecorationImage(
                        image: AssetImage(
                            "assets/new_onboarding/background_screen_two.png"),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Add education",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 28.0,
                                fontWeight: FontWeight.w700,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                              ),
                            ),
                          ],
                        ),
                        educationClickEvent == 0 ||
                                educationClickEvent == 3 ||
                                educationClickEvent == 2 ||
                                educationClickEvent == 1
                            ? PaddingWrap.paddingfromLTRB(
                                0.0,
                                30.0,
                                0.0,
                                0.0,
                                Row(
                                  children: [
                                    InkWell(
                                      child: Container(
                                        width:
                                            MediaQuery.of(mContext).size.width *
                                                0.23,
                                        child: Text(
                                          'Primary',
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: educationClickEvent == 1
                                                ? ColorValues.WHITE
                                                : ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                          ),
                                        ),
                                        padding: EdgeInsets.only(
                                            top: 9,
                                            bottom: 9,
                                            left: 9,
                                            right: 9),
                                        decoration: BoxDecoration(
                                          color: educationClickEvent == 1
                                              ? AppConstants
                                                  .colorStyle.btn_selected_color
                                              : AppConstants
                                                  .colorStyle.btnBgBorder,
                                          border: Border.all(
                                              color: educationClickEvent == 1
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBg),
                                          borderRadius: const BorderRadius.only(
                                              topLeft: Radius.circular(10),
                                              bottomLeft: Radius.circular(10)),
                                        ),
                                      ),
                                      onTap: () {
                                        setState(() {
                                          _primaryGradList.clear();
                                          addPrimaryGrad();

                                          _searchQuerySchoolName.text = "";
                                          ControllerPrimary.text = "";
                                          _controllerSchoolGrad.text = "";

                                          showPrimaryGradView = false;
                                          showMiddleGradView = false;
                                          showHighGradView = false;

                                          primaryFirstGrad = "";
                                          primarySecondGrad = "";

                                          primaryFirstIndex = 0;
                                          primarySecondIndex = 0;
                                          educationClickEvent = 1;

                                          visiblePrimary = false;
                                          visibleMiddel = false;
                                          visibleHigh = false;
                                          visibleCollege = false;
                                          SchoolYearFocusNode.unfocus();
                                          getCalendarList(widget.endYear);

                                          startYear = null;
                                          endYear = null;
                                          duplicateYear = false;
                                          setTextFieldValue();
                                        });
                                        getSchoolName('');
                                      },
                                    ),
                                    InkWell(
                                      child: Container(
                                        width:
                                            MediaQuery.of(mContext).size.width *
                                                0.20,
                                        child: Text(
                                          'Middle',
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: educationClickEvent == 2
                                                ? ColorValues.WHITE
                                                : ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                          ),
                                        ),
                                        padding: EdgeInsets.only(
                                            top: 9,
                                            bottom: 9,
                                            left: 9,
                                            right: 9),
                                        decoration: BoxDecoration(
                                          color: educationClickEvent == 2
                                              ? AppConstants
                                                  .colorStyle.btn_selected_color
                                              : AppConstants
                                                  .colorStyle.btnBgBorder,
                                          border: Border.all(
                                              color: educationClickEvent == 2
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBg),
                                        ),
                                      ),
                                      onTap: () {
                                        setState(() {
                                          _middleGradList.clear();
                                          addMiddleGrad();
                                          SchoolYearFocusNode.unfocus();
                                          middleFirstGrad = "";
                                          middleSecondGrad = "";
                                          middleFirstIndex = 0;
                                          middleSecondIndex = 0;
                                          ControllerPrimary.text = "";
                                          educationClickEvent = 2;
                                          _searchQuerySchoolName.text = "";
                                          ControllerPrimary.text = "";
                                          _controllerSchoolGrad.text = "";
                                          showHighGradView = false;
                                          showMiddleGradView = false;
                                          showPrimaryGradView = false;
                                          visiblePrimary = false;
                                          visibleMiddel = false;
                                          visibleHigh = false;
                                          visibleCollege = false;
                                          getCalendarList(widget.endYear);
                                          startYear = null;
                                          endYear = null;
                                          duplicateYear = false;
                                          setTextFieldValue();
                                        });
                                        getSchoolName('');
                                      },
                                    ),
                                    InkWell(
                                      child: Container(
                                        width:
                                            MediaQuery.of(mContext).size.width *
                                                0.20,
                                        child: Text(
                                          'High',
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: educationClickEvent == 3
                                                ? ColorValues.WHITE
                                                : ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                          ),
                                        ),
                                        padding: EdgeInsets.only(
                                            top: 9,
                                            bottom: 9,
                                            left: 9,
                                            right: 9),
                                        decoration: BoxDecoration(
                                            color: educationClickEvent == 3
                                                ? AppConstants.colorStyle
                                                    .btn_selected_color
                                                : AppConstants
                                                    .colorStyle.btnBgBorder,
                                            border: Border.all(
                                                color: educationClickEvent == 3
                                                    ? AppConstants.colorStyle
                                                        .btn_selected_color
                                                    : AppConstants
                                                        .colorStyle.btnBg),
                                            borderRadius: diffrenceInDob > 13
                                                ? BorderRadius.zero
                                                : const BorderRadius.only(
                                                    topRight:
                                                        Radius.circular(10),
                                                    bottomRight:
                                                        Radius.circular(10))),
                                      ),
                                      onTap: () {
                                        setState(() {
                                          _highGradList.clear();
                                          addHighGrad();
                                          duplicateYear = false;
                                          highFirstGrad = "";
                                          highSecondGrad = "";
                                          highFirstIndex = 0;
                                          highSecondIndex = 0;
                                          ControllerPrimary.text = "";
                                          SchoolYearFocusNode.unfocus();
                                          _controllerSchoolGrad.text = "";
                                          educationClickEvent = 2;
                                          _searchQuerySchoolName.text = "";
                                          ControllerPrimary.text = "";
                                          showHighGradView = false;
                                          showMiddleGradView = false;
                                          showPrimaryGradView = false;
                                          educationClickEvent = 3;
                                          visiblePrimary = false;
                                          visibleMiddel = false;
                                          visibleHigh = false;
                                          visibleCollege = false;
                                          startYear = null;
                                          endYear = null;

                                          setTextFieldValue();
                                        });
                                        getSchoolName('');
                                      },
                                    ),
                                    diffrenceInDob > 13
                                        ? InkWell(
                                            child: Container(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.25,
                                              child: Text(
                                                'College',
                                                maxLines: 1,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                ),
                                              ),
                                              padding: EdgeInsets.only(
                                                  top: 9,
                                                  bottom: 9,
                                                  left: 9,
                                                  right: 9),
                                              decoration: BoxDecoration(
                                                color: AppConstants
                                                    .colorStyle.btnBgBorder,
                                                border: Border.all(
                                                    color: AppConstants
                                                        .colorStyle.btnBg),
                                                borderRadius:
                                                    const BorderRadius.only(
                                                        topRight:
                                                            Radius.circular(10),
                                                        bottomRight:
                                                            Radius.circular(
                                                                10)),
                                              ),
                                            ),
                                            onTap: () {
                                              setState(() {
                                                ControllerPrimary.text = "";
                                                _controllerSchoolClassOff.text =
                                                    "";
                                                classOffVisible = false;
                                                educationClickEvent = 4;
                                                visiblePrimary = false;
                                                SchoolYearFocusNode.unfocus();
                                                visibleMiddel = false;
                                                visibleHigh = false;
                                                visibleCollege = false;
                                                startYear = null;
                                                endYear = null;
                                                duplicateYear = false;

                                                setTextFieldValue();
                                              });
                                            },
                                          )
                                        : SizedBox(),
                                  ],
                                ))
                            : Container(
                                height: 0,
                              ),
                        educationClickEvent == 4 ||
                                educationClickEvent == 5 ||
                                educationClickEvent == 6 ||
                                educationClickEvent == 7 ||
                                educationClickEvent == 11 ||
                                educationClickEvent == 12 ||
                                educationClickEvent == 8 ||
                                educationClickEvent == 9 ||
                                educationClickEvent == 10 ||
                                educationClickEvent == 13
                            ? PaddingWrap.paddingfromLTRB(
                                0.0,
                                30.0,
                                0.0,
                                0.0,
                                SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: [
                                        InkWell(
                                          child: Container(
                                            child: Center(
                                              child: Image.asset(
                                                  "assets/new_onboarding/college.png",
                                                  height: 17.0,
                                                  width: 14.0,
                                                  fit: BoxFit.fitHeight),
                                            ),
                                            height: 37,
                                            width: 37,
                                            padding: EdgeInsets.only(
                                                top: 2,
                                                bottom: 2,
                                                left: 3,
                                                right: 3),
                                            decoration: BoxDecoration(
                                              color: AppConstants
                                                  .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: AppConstants
                                                      .colorStyle.btnBgBorder),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                      topLeft:
                                                          Radius.circular(10),
                                                      bottomLeft:
                                                          Radius.circular(10)),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 0;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'High School Diploma',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 5
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 5
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          5
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 5;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Undergraduate Degree',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 6
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 6
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          6
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 6;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Masters Degree',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 7
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 7
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          7
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 7;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'PhD',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 8
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 8
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          8
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 8;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Associate Degree',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 9
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 9
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          9
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 9;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Transfer Degree',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 10
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 10
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          10
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 10;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Professional Certificate',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 11
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 11
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          11
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 11;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Professional Degree',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 12
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 12
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          12
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 12;
                                            });
                                          },
                                        ),
                                        InkWell(
                                          child: Container(
                                            child: Text(
                                              'Specialist Degree',
                                              maxLines: 1,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: educationClickEvent == 13
                                                    ? ColorValues.WHITE
                                                    : ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                              ),
                                            ),
                                            padding: EdgeInsets.only(
                                                top: 9,
                                                bottom: 9,
                                                left: 9,
                                                right: 9),
                                            decoration: BoxDecoration(
                                              color: educationClickEvent == 13
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.btnBgBorder,
                                              border: Border.all(
                                                  color: educationClickEvent ==
                                                          13
                                                      ? AppConstants.colorStyle
                                                          .btn_selected_color
                                                      : AppConstants.colorStyle
                                                          .btnBgBorder),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                      topRight:
                                                          Radius.circular(10),
                                                      bottomRight:
                                                          Radius.circular(10)),
                                            ),
                                          ),
                                          onTap: () {
                                            setState(() {
                                              educationClickEvent = 13;
                                            });
                                          },
                                        )
                                      ],
                                    )))
                            : Container(
                                height: 0,
                              ),
                        SizedBox(
                          height: 5,
                        ),
                        educationClickEvent == 1
                            ? primaryView()
                            : const SizedBox.shrink(),
                        educationClickEvent == 2
                            ? middleView()
                            : const SizedBox.shrink(),
                        educationClickEvent == 3
                            ? highClassView()
                            : const SizedBox.shrink(),
                        educationClickEvent == 5 ||
                                educationClickEvent == 6 ||
                                educationClickEvent == 7 ||
                                educationClickEvent == 11 ||
                                educationClickEvent == 12 ||
                                educationClickEvent == 8 ||
                                educationClickEvent == 9 ||
                                educationClickEvent == 10 ||
                                educationClickEvent == 13
                            ? collageView()
                            : const SizedBox.shrink(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomSheet: Container(
        height: 80,
        color: Colors.white,
        child: educationClickEvent == 1 &&
                _searchQuerySchoolName.text != '' &&
                startYear != null &&
                endYear != null &&
                _controllerSchoolGrad.text != ''
            ? submitButton(1, mContext)
            : educationClickEvent == 2 &&
                    _searchQuerySchoolName.text != '' &&
                    startYear != null &&
                    endYear != null &&
                    _controllerSchoolGrad.text != ''
                ? submitButton(1, mContext)
                : educationClickEvent == 3 &&
                        _searchQuerySchoolName.text != '' &&
                        stryear1 != "" &&
                        startYear != null &&
                        endYear != null &&
                        _controllerSchoolGrad.text != ''
                    ? submitButton(1, mContext)
                    : eventButton(5)
                        ? submitButton(1, mContext)
                        : eventButton(6)
                            ? submitButton(1, mContext)
                            : eventButton(7)
                                ? submitButton(1, mContext)
                                : eventButton(8)
                                    ? submitButton(1, mContext)
                                    : eventButton(9)
                                        ? submitButton(1, mContext)
                                        : eventButton(10)
                                            ? submitButton(1, mContext)
                                            : eventButton(11)
                                                ? submitButton(1, mContext)
                                                : eventButton(12)
                                                    ? submitButton(1, mContext)
                                                    : eventButton(13)
                                                        ? submitButton(
                                                            1, mContext)
                                                        : submitButton(0,
                                                            mContext), //Your widget here,
      ),
    );
  }

  submitButton(int visible, BuildContext mContext) {
    return Container(
        height: 60,
        child: Padding(
            padding: EdgeInsets.only(bottom: 10.0, left: 20, right: 20),
            child: Stack(
              children: [
                Container(
                    height: 44.0,
                    child: FlatButton(
                      onPressed: () {
                        if (visible == 1) {
                          final form = _formKey.currentState;
                          form.save();
                          if (form.validate()) {
                            addEducationApi(mContext);
                          } else {
                            print('Form is invalid');
                          }
                        }
                      },
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      color: AppConstants.colorStyle.lightBlue,
                      child: Row(
                        // Replace with a Row for horizontal icon + text
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(AppConstants.stringConstant.str_btn_submit,
                              style: AppConstants
                                  .txtStyle.heading18600LatoRegularWhite),
                        ],
                      ),
                    )),
                visible == 0
                    ? Container(
                        color: Colors.white60,
                        height: 44.0,
                        child: FlatButton(
                          onPressed: () {},
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          color: Colors.transparent,
                          child: Row(
                            // Replace with a Row for horizontal icon + text
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(AppConstants.stringConstant.str_btn_submit,
                                  style: AppConstants
                                      .txtStyle.heading18600LatoRegularWhite),
                            ],
                          ),
                        ))
                    : Container(
                        height: 0,
                      ),
              ],
            )));
  }

  Text getTextLabel1(txt, size, color, fontWeight) {
    return Text(
      txt,
      textAlign: TextAlign.start,
      style: TextStyle(
        fontSize: 12.0,
        fontWeight: FontWeight.w500,
        fontFamily: AppConstants.stringConstant.latoMedium,
      ),
    );
  }

  List<InkWell> _buildSearchListSchool() {
    return List.generate(organizationLstSchool.length, (int index) {
      return InkWell(
          child: Container(
            margin: EdgeInsets.only(top: 2, bottom: 2, left: 5, right: 5),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.box_bg_color,
              border: Border.all(color: AppConstants.colorStyle.box_bg_color),
              borderRadius: BorderRadius.circular(10),
            ),
            child: ListTile(
              title: Text(
                organizationLstSchool[index].name,
                style: TextStyle(
                  color: AppConstants.colorStyle.darkBlue,
                  fontSize: 16.0,
                  fontWeight: FontWeight.w600,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                ),
              ),
              subtitle:
                  organizationLstSchool[index].address.toString() == null ||
                          organizationLstSchool[index].address.toString() ==
                              "null" ||
                          organizationLstSchool[index].address.toString() == ""
                      ? Container(
                          height: 0,
                        )
                      : Text(
                          organizationLstSchool[index].address +
                              ", " +
                              organizationLstSchool[index].city +
                              ", " +
                              organizationLstSchool[index].state,
                          style: TextStyle(
                            color: AppConstants.colorStyle.darkBlue,
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                          ),
                        ),
            ),
          ),
          onTap: () {
            setState(() {
              selectedTextSchoolName = organizationLstSchool[index].name;

              _searchTextSchoolCity = organizationLstSchool[index].city;
              _searchQuerySchoolName.text = organizationLstSchool[index].name;
              if (organizationLstSchool[index].city == null ||
                  organizationLstSchool[index].city == "" ||
                  organizationLstSchool[index].city == "null") {
                _searchQuerySchoolName.text =
                    organizationLstSchool[index].name/* +
                        "," +
                        organizationLstSchool[index].address*/;
              } else {
                _searchQuerySchoolName.text =
                    organizationLstSchool[index].name /*+
                        "," +
                        organizationLstSchool[index].address +
                        ", " +
                        organizationLstSchool[index].city*/;
              }
              strOrganizationIdSchool =
                  organizationLstSchool[index].organizationId;
              strOrganizationTypeSchool = organizationLstSchool[index].type;

              _searchQuerySchoolName.selection = TextSelection.collapsed(
                  offset: _searchQuerySchoolName.text.length);
              organizationLstSchool.clear();
              _IsSearchingSchool = false;
            });
          });
    });
  }

  List<InkWell> _buildSearchListCollege() {
    return List.generate(organizationLstCollege.length, (int index) {
      return InkWell(
          child: Container(
            margin: EdgeInsets.only(top: 2, bottom: 2, left: 5, right: 5),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.box_bg_color,
              border: Border.all(color: AppConstants.colorStyle.box_bg_color),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: <Widget>[
                ListTile(
                  title: Text(
                    organizationLstCollege[index].name,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                ),
              ],
            ),
          ),
          onTap: () {
            setState(() {
              selectedTextCollege = organizationLstCollege[index].name;
              _searchQueryCollegeName.text = organizationLstCollege[index].name;
              strOrganizationIdCollege =
                  organizationLstCollege[index].organizationId;
              strOrganizationTypeCollege = organizationLstCollege[index].type;
              _searchQueryCollegeName.selection = TextSelection.collapsed(
                  offset: _searchQueryCollegeName.text.length);
              organizationLstCollege.clear();
              _IsSearchingCollege = false;
            });
          });
    });
  }

  Container getOrganizationUiSchool() {
    return Container(
      child: Column(
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
            0.0,
            15.0,
            0.0,
            0.0,
            TextFormField(
              controller: _searchQuerySchoolName,
              autocorrect: false,
              focusNode: SchoolNameFocusNode,
              enableInteractiveSelection: false,
              enableSuggestions: false,
              enabled: isSchoolEnable,
              cursorColor: Constant.CURSOR_COLOR,
              keyboardType: TextInputType.visiblePassword,
              style: AppConstants.txtStyle.txtStyleTextForm,
              onSaved: (String value) {
                // firstName.text = value!;
              },
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                labelText: AppConstants.stringConstant.str_School_name,
                isDense: true,
                alignLabelWithHint: true,
                labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                suffixIconConstraints: BoxConstraints(
                    minWidth: 15, minHeight: 15, maxHeight: 24, maxWidth: 24),
                border: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.btnBg, width: 1.0)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.lightBlue, width: 1.0)),
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.btnBg, width: 1.0)),
                disabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.btnBg, width: 1.0)),
                suffixIcon: Align(
                  alignment: Alignment.bottomCenter,
                  child: Image.asset(
                    'assets/new_onboarding/search_blue_icon.png',
                    height: 20,
                    width: 20,
                  ),
                ),
              ),
            ),
          ),
          _searchQuerySchoolName.text.trim().length > 1
              ? PaddingWrap.paddingfromLTRB(
                  0.0,
                  3.0,
                  0.0,
                  0.0,
                  Container(
                    decoration: BoxDecoration(
                        border: Border.all(
                            color: organizationLstSchool.length > 0
                                ? ColorValues.LIGHT_GREY_TEXT_COLOR
                                : Colors.transparent,
                            width: 1.0)),
                    height: organizationLstSchool.length == 0
                        ? 0.0
                        : organizationLstSchool.length == 1
                            ? 70.0
                            : organizationLstSchool.length == 2
                                ? 145.0
                                : organizationLstSchool.length == 3
                                    ? 190.0
                                    : 190.0,
                    child: MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: ListView(
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        children: _buildSearchListSchool(),
                      ),
                    ),
                  ),
                )
              : const SizedBox.shrink()
        ],
      ),
    );
  }

  Container getOrganizationUiCollege() {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
            0.0,
            25.0,
            0.0,
            0.0,
            TextFormField(
              controller: _searchQueryCollegeName,
              autocorrect: false,
              focusNode: CollegeNameFocusNode,
              enableInteractiveSelection: false,
              enableSuggestions: false,
              cursorColor: Constant.CURSOR_COLOR,
              keyboardType: TextInputType.visiblePassword,
              style: AppConstants.txtStyle.txtStyleTextForm,
              onSaved: (String value) {
                // firstName.text = value!;
              },
              decoration: InputDecoration(
                  contentPadding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                  labelText: AppConstants.stringConstant.str_College_name,
                  labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                  alignLabelWithHint: true,
                  border: UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: AppConstants.colorStyle.btnBg, width: 1.0)),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: AppConstants.colorStyle.lightBlue,
                          width: 1.0)),
                  enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: AppConstants.colorStyle.btnBg, width: 1.0)),
                  disabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                          color: AppConstants.colorStyle.btnBg, width: 1.0)),
                  suffixIcon: Align(
                    alignment: Alignment.bottomCenter,
                    child: Image.asset(
                      'assets/new_onboarding/search_blue_icon.png',
                      height: 20,
                      width: 20,
                    ),
                  ),
                  suffixIconConstraints: BoxConstraints(
                    maxWidth: 24,
                    maxHeight: 24,
                  )),
            ),
          ),
          _searchQueryCollegeName.text.trim().length > 1
              ? PaddingWrap.paddingfromLTRB(
                  0.0,
                  3.0,
                  0.0,
                  0.0,
                  Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: organizationLstCollege.length > 0
                                  ? ColorValues.LIGHT_GREY_TEXT_COLOR
                                  : Colors.transparent,
                              width: 1.0)),
                      height: organizationLstCollege.length == 0
                          ? 0.0
                          : organizationLstCollege.length == 1
                              ? 70.0
                              : organizationLstCollege.length == 2
                                  ? 145.0
                                  : organizationLstCollege.length == 3
                                      ? 145.0
                                      : 145.0,
                      child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child:
                              ListView(children: _buildSearchListCollege()))),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Future ApiLoadMoreSchool() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": previousTextSchool,
          "type": "School",
          "skip": skipIndexSchool,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(mContext, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText response===" + response.toString());
        print("data++++++searchText response.statusCode===" +
            response.statusCode.toString());
        isLoadMoreSchool = false;
        _IsSearchingSchool = false;

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], "School");
              if (organizationLst1.length > 0) {
                setState(() {
                  organizationLstSchool.addAll(organizationLst1);
                });
              } else {
                isAllDataLoadedSchool = true;
              }
            }
          }
        }
        setState(() {});
      } else {
        isLoadMoreSchool = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadMoreSchool = false;
      setState(() {});
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future recommendationApiLoadMoreCollege() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": previousTextCollege,
          "type": "collage",
          "skip": skipIndexCollege,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(mContext, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());
        isLoadMoreCollege = false;
        _IsSearchingCollege = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], "School");
              if (organizationLst1.length > 0) {
                setState(() {
                  organizationLstCollege.addAll(organizationLst1);
                });
              } else {
                isAllDataLoadedCollege = true;
              }
            }
          }
        }
        setState(() {});
      } else {
        isLoadMoreCollege = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, mContext);
      }
    } catch (e) {
      isLoadMoreCollege = false;
      setState(() {});
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", mContext);
      e.toString();
    }
  }

  primaryView() {
    return Expanded(
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            0.0,
            80.0,
            Container(
              color: Colors.transparent,
              child: SingleChildScrollView(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  getOrganizationUiSchool(),
                  PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    0.0,
                    TextField(
                      controller: ControllerPrimary,
                      showCursor: false,
                      readOnly: true,
                      onTap: () {
                        setState(() {
                          visiblePrimary = true;
                          showPrimaryGradView = false;
                          SchoolNameFocusNode.unfocus();
                          //FocusManager.instance.primaryFocus.unfocus();
                        });
                      },
                      focusNode: SchoolYearFocusNode,
                      style: AppConstants.txtStyle.txtStyleTextForm,
                      decoration: InputDecoration(
                        isDense: true,
                        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                        labelText: AppConstants.stringConstant.str_School_year,
                      ),
                    ),
                  ),
                  Visibility(
                    visible: visiblePrimary,
                    child: Container(
                      padding:
                          const EdgeInsets.only(top: 0, right: 10, left: 10),
                      decoration: const BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 2),
                                blurRadius: 12)
                          ]),
                      height: 150,
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.only(top: 10),
                              itemCount: years.length,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 5,
                                childAspectRatio: 3 / 2,
                              ),
                              itemBuilder: (context, index) {
                                final year = years[index];
                                return InkWell(
                                  onTap: () => setIndex(index),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: getBoxColour(index),
                                      border: showBorder(index)
                                          ? const Border.symmetric(
                                              horizontal: BorderSide(
                                                  color: Color(0xFFE5EBF0)),
                                            )
                                          : null,
                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                      borderRadius: showBorder(index)
                                          ? null
                                          : BorderRadius.horizontal(
                                              left: startYear == year
                                                  ? const Radius.circular(5)
                                                  : Radius.zero,
                                              right: endYear == year
                                                  ? const Radius.circular(5)
                                                  : Radius.zero,
                                              // right: Radius.circular(25),
                                            ),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 5),
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      years[index].toString(),
                                      style: TextStyle(
                                        color: getFontColour(index),
                                        fontSize: 16,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          duplicateYear
                              ? SizedBox(
                                  height: 45,
                                  width: double.maxFinite,
                                  child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                    Text(
                                      "You already have school with the same year",
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      style: TextStyle(
                                        color: AppConstants
                                            .colorStyle.btn_text_red,
                                        fontSize: 14,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    /*BaseText(
                                        text:
                                            "You already have school with the same year",
                                        textColor: AppConstants
                                            .colorStyle.btn_text_red,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14,
                                        maxLines: 2,
                                      )*/
                                  ),
                                )
                              : SizedBox(
                                  width: double.maxFinite,
                                  child: TextButton(
                                    onPressed: () {
                                      visiblePrimary = false;

                                      setState(() {});
                                      //  Navigator.pop(context);
                                    },
                                    child: Text(
                                      startYear != null && endYear != null
                                          ? "Apply"
                                          : 'Cancel',
                                      style: TextStyle(
                                        color: startYear != null &&
                                                endYear != null
                                            ? AppConstants.colorStyle.lightBlue
                                            : AppConstants
                                                .colorStyle.lightPurple,
                                        fontSize: 16,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      15.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: AppConstants
                            .stringConstant.str_btn_year_hint_primary,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoItalic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        maxLines: 2,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        controller: _controllerSchoolGrad,
                        showCursor: false,
                        readOnly: true,
                        onTap: () {
                          setState(() {
                            SchoolNameFocusNode.unfocus();
                            visiblePrimary = false;
                            showPrimaryGradView = true;
                          });
                        },
                        focusNode: SchoolGradPrimaryFocusNode,
                        style: AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(
                          contentPadding:
                              const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg,
                                  width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg,
                                  width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg,
                                  width: 1.0)),
                          labelText:
                              AppConstants.stringConstant.str_School_Grad,
                        ),
                      )),
                  showPrimaryGradView && SchoolGradPrimaryFocusNode.hasFocus
                      ? PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Container(
                            margin: EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.only(
                                top: 0, right: 0, left: 0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(1.0),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black12,
                                    offset: Offset(0, 2),
                                    blurRadius: 12)
                              ],
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                    height: 80,
                                    child: GridView.builder(
                                        padding: EdgeInsets.only(top: 15),
                                        gridDelegate:
                                            const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 5,
                                          mainAxisSpacing: 1,
                                          childAspectRatio: 1.9,
                                        ),
                                        itemCount: _primaryGradList.length,
                                        itemBuilder: (BuildContext ctx, index) {
                                          return InkWell(
                                            onTap:
                                                () /* => setIndexPrimary(index),*/ {
                                              if (_primaryGradList[index]
                                                  .selected) {
                                                if (primaryFirstGrad ==
                                                    _primaryGradList[index]
                                                        .name) {
                                                  setState(() {
                                                    primaryFirstGrad = "";
                                                    primarySecondGrad = "";
                                                    primaryFirstIndex = 0;
                                                    primarySecondIndex = 0;
                                                    _controllerSchoolGrad.text =
                                                        "";
                                                    _primaryGradList.clear();
                                                    addPrimaryGrad();
                                                  });
                                                }

                                                if (primarySecondGrad ==
                                                    _primaryGradList[index]
                                                        .name) {
                                                  setState(() {
                                                    _primaryGradList[
                                                            primarySecondIndex]
                                                        .number = 0;
                                                    primarySecondGrad = "";
                                                    primarySecondIndex = 0;
                                                    _controllerSchoolGrad.text =
                                                        primaryFirstGrad;
                                                  });
                                                }

                                                setState(() {
                                                  _primaryGradList[index]
                                                      .selected = false;
                                                  _primaryGradList[index]
                                                      .number = 0;
                                                });
                                              } else {
                                                setState(() {
                                                  if (primaryFirstGrad == "") {
                                                    _primaryGradList[index]
                                                        .selected = true;
                                                    _primaryGradList[index]
                                                        .number = 1;
                                                    primaryFirstGrad =
                                                        _primaryGradList[index]
                                                            .name;
                                                    primaryFirstIndex = index;
                                                  } else {
                                                    if (primaryFirstIndex >
                                                        index) {
                                                    } else if (primarySecondGrad ==
                                                        "") {
                                                      _primaryGradList[index]
                                                          .selected = true;
                                                      primarySecondIndex =
                                                          index;
                                                      _primaryGradList[index]
                                                          .number = 2;
                                                      primarySecondGrad =
                                                          _primaryGradList[
                                                                  index]
                                                              .name;
                                                    } else {
                                                      setState(() {
                                                        _primaryGradList[
                                                                primarySecondIndex]
                                                            .number = 0;
                                                        _primaryGradList[
                                                                primarySecondIndex]
                                                            .selected = false;
                                                        primarySecondIndex = 0;
                                                        primarySecondGrad = "";
                                                        _controllerSchoolGrad
                                                                .text =
                                                            primaryFirstGrad;
                                                      });
                                                      _primaryGradList[index]
                                                          .selected = true;
                                                      primarySecondIndex =
                                                          index;
                                                      _primaryGradList[index]
                                                          .number = 2;
                                                      primarySecondGrad =
                                                          _primaryGradList[
                                                                  index]
                                                              .name;
                                                    }
                                                  }
                                                });
                                              }
                                            },
                                            child: Container(
                                              alignment: Alignment.center,
                                              decoration: BoxDecoration(
                                                color: getBoxColourGradPrimary(
                                                    index),
                                                border: showBorderGradPrimary(
                                                        index)
                                                    ? const Border.symmetric(
                                                        horizontal: BorderSide(
                                                            color: Color(
                                                                0xFFE5EBF0)),
                                                      )
                                                    : null,
                                                // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                                borderRadius:
                                                    showBorderGradPrimary(index)
                                                        ? null
                                                        : BorderRadius
                                                            .horizontal(
                                                            left: primaryFirstGrad ==
                                                                    _primaryGradList[
                                                                            index]
                                                                        .name
                                                                ? const Radius
                                                                    .circular(5)
                                                                : Radius.zero,
                                                            right: primarySecondGrad ==
                                                                    _primaryGradList[
                                                                            index]
                                                                        .name
                                                                ? const Radius
                                                                    .circular(5)
                                                                : Radius.zero,
                                                            // right: Radius.circular(25),
                                                          ),
                                              ),
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      5.0,
                                                      3.0,
                                                      5.0,
                                                      3.0,
                                                      Text(
                                                        _primaryGradList[index]
                                                            .name,
                                                        style: TextStyle(
                                                          color: getFontColourGradPrimary(
                                                              index) /* _primaryGradList[index]
                                                      .selected
                                                  ? AppConstants
                                                      .colorStyle.white
                                                  : AppConstants
                                                      .colorStyle.darkBlue*/
                                                          ,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                        ),
                                                      )),
                                            ),
                                          );
                                        })),
                                InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      15.0,
                                      0.0,
                                      15.0,
                                      BaseText(
                                        text: primaryFirstGrad == null ||
                                                primaryFirstGrad == ""
                                            ? "Cancel"
                                            : "Apply",
                                        textColor: primaryFirstGrad == null ||
                                                primaryFirstGrad == ""
                                            ? AppConstants
                                                .colorStyle.lightPurple
                                            : AppConstants.colorStyle.lightBlue,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        maxLines: 1,
                                      )),
                                  onTap: () {
                                    setState(() {
                                      showPrimaryGradView = false;
                                      setState(() {
                                        if (primarySecondGrad == "") {
                                          _controllerSchoolGrad.text =
                                              primaryFirstGrad;
                                        } else {
                                          _controllerSchoolGrad.text =
                                              primaryFirstGrad +
                                                  "-" +
                                                  primarySecondGrad;
                                        }
                                      });
                                    });
                                  },
                                ),
                              ],
                            ),
                          ))
                      : Container(
                          height: 0,
                        )
                ],
              )),
            )));
  }

  middleView() {
    return Expanded(
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            0.0,
            80.0,
            Container(
              color: Colors.transparent,
              child: SingleChildScrollView(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  getOrganizationUiSchool(),
                  PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    0.0,
                    TextField(
                      controller: ControllerPrimary,
                      readOnly: true,
                      showCursor: false,
                      onTap: () {
                        visibleMiddel = true;
                        showMiddleGradView = false;
                        SchoolNameFocusNode.unfocus();
                        setState(() {});
                      },
                      focusNode: SchoolYearFocusNode,
                      style: AppConstants.txtStyle.txtStyleTextForm,
                      decoration: InputDecoration(
                        isDense: true,
                        contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                        labelText: 'Year',
                        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                      ),
                    ),
                  ),
                  Visibility(
                    visible: visibleMiddel,
                    child: Container(
                      padding:
                          const EdgeInsets.only(top: 0, right: 10, left: 10),
                      decoration: const BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 2),
                                blurRadius: 12)
                          ]),
                      height: 150,
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Expanded(
                            child: GridView.builder(
                              padding: EdgeInsets.only(top: 10),
                              // physics: const NeverScrollableScrollPhysics(),
                              itemCount: years.length,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 5,
                                childAspectRatio: 3 / 2,
                              ),
                              itemBuilder: (context, index) {
                                final year = years[index];
                                return InkWell(
                                  onTap: () => setIndex(index),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: getBoxColour(index),
                                      border: showBorder(index)
                                          ? const Border.symmetric(
                                              horizontal: BorderSide(
                                                  color: Color(0xFFE5EBF0)),
                                            )
                                          : null,
                                      // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                      borderRadius: showBorder(index)
                                          ? null
                                          : BorderRadius.horizontal(
                                              left: startYear == year
                                                  ? const Radius.circular(5)
                                                  : Radius.zero,
                                              right: endYear == year
                                                  ? const Radius.circular(5)
                                                  : Radius.zero,
                                              // right: Radius.circular(25),
                                            ),
                                    ),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 5),
                                    margin: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    alignment: Alignment.center,
                                    child: Text(
                                      years[index].toString(),
                                      style: TextStyle(
                                        color: getFontColour(index),
                                        fontSize: 16,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          duplicateYear
                              ? SizedBox(
                                  width: double.maxFinite,
                                  height: 45,
                                  child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                    Text(
                                      "You already have school with the same year",
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      style: TextStyle(
                                        color: AppConstants
                                            .colorStyle.btn_text_red,
                                        fontSize: 14,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                )
                              : SizedBox(
                                  width: double.maxFinite,
                                  child: TextButton(
                                    onPressed: () {
                                      visibleMiddel = false;
                                      setState(() {});
                                      //  Navigator.pop(context);
                                    },
                                    child: Text(
                                      startYear != null && endYear != null
                                          ? "Apply"
                                          : 'Cancel',
                                      style: TextStyle(
                                        color: startYear != null &&
                                                endYear != null
                                            ? AppConstants.colorStyle.lightBlue
                                            : AppConstants
                                                .colorStyle.lightPurple,
                                        fontSize: 16,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      15.0,
                      0.0,
                      0.0,
                      BaseText(
                        text: AppConstants
                            .stringConstant.str_btn_year_hint_middle,
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoItalic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        maxLines: 2,
                      )),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      20.0,
                      0.0,
                      0.0,
                      TextField(
                        controller: _controllerSchoolGrad,
                        showCursor: false,
                        readOnly: true,
                        onTap: () {
                          setState(() {
                            visibleMiddel = false;
                            showMiddleGradView = true;
                            SchoolNameFocusNode.unfocus();
                          });
                        },
                        focusNode: SchoolGradMiddelFocusNode,
                        style: AppConstants.txtStyle.txtStyleTextForm,
                        decoration: InputDecoration(
                          contentPadding:
                              const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                          border: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg,
                                  width: 1.0)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.lightBlue,
                                  width: 1.0)),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg,
                                  width: 1.0)),
                          disabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                  color: AppConstants.colorStyle.btnBg,
                                  width: 1.0)),
                          labelText:
                              AppConstants.stringConstant.str_School_Grad,
                        ),
                      )),
                  showMiddleGradView == true &&
                          SchoolGradMiddelFocusNode.hasFocus
                      ? PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Container(
                              margin: EdgeInsets.only(bottom: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(1.0),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.black12,
                                      offset: Offset(0, 2),
                                      blurRadius: 12)
                                ],
                              ),
                              child: Column(
                                children: [
                                  SizedBox(
                                      height: 50,
                                      child: GridView.builder(
                                          padding: EdgeInsets.only(top: 15),
                                          gridDelegate:
                                              const SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: 5,
                                                  childAspectRatio: 1.9,
                                                  mainAxisSpacing: 1),
                                          itemCount: _middleGradList.length,
                                          itemBuilder:
                                              (BuildContext ctx, index) {
                                            return InkWell(
                                              onTap: () {
                                                if (_middleGradList[index]
                                                    .selected) {
                                                  if (middleFirstGrad ==
                                                      _middleGradList[index]
                                                          .name) {
                                                    setState(() {
                                                      middleFirstGrad = "";
                                                      middleSecondGrad = "";
                                                      middleFirstIndex = 0;
                                                      middleSecondIndex = 0;
                                                      _controllerSchoolGrad
                                                          .text = "";
                                                      _middleGradList.clear();
                                                      addMiddleGrad();
                                                      middleFirstGrad = "";
                                                    });
                                                  }

                                                  if (middleSecondGrad ==
                                                      _middleGradList[index]
                                                          .name) {
                                                    setState(() {
                                                      _middleGradList[
                                                              middleSecondIndex]
                                                          .number = 0;
                                                      middleSecondGrad = "";
                                                      middleSecondIndex = 0;
                                                      _controllerSchoolGrad
                                                              .text =
                                                          middleFirstGrad;
                                                    });
                                                  }

                                                  setState(() {
                                                    _middleGradList[index]
                                                        .selected = false;
                                                    _middleGradList[index]
                                                        .number = 0;
                                                  });
                                                } else {
                                                  setState(() {
                                                    if (middleFirstGrad == "") {
                                                      _middleGradList[index]
                                                          .selected = true;
                                                      _middleGradList[index]
                                                          .number = 1;
                                                      middleFirstGrad =
                                                          _middleGradList[index]
                                                              .name;
                                                      middleFirstIndex = index;
                                                    } else {
                                                      if (middleFirstIndex >
                                                          index) {
                                                      } else if (middleSecondGrad ==
                                                          "") {
                                                        _middleGradList[index]
                                                            .selected = true;
                                                        middleSecondIndex =
                                                            index;
                                                        _middleGradList[index]
                                                            .number = 2;
                                                        middleSecondGrad =
                                                            _middleGradList[
                                                                    index]
                                                                .name;
                                                      } else {
                                                        setState(() {
                                                          _middleGradList[
                                                                  middleSecondIndex]
                                                              .number = 0;
                                                          _middleGradList[
                                                                  middleSecondIndex]
                                                              .selected = false;
                                                          middleSecondIndex = 0;
                                                          middleSecondGrad = "";
                                                          _controllerSchoolGrad
                                                                  .text =
                                                              middleFirstGrad;
                                                        });
                                                        _middleGradList[index]
                                                            .selected = true;
                                                        middleSecondIndex =
                                                            index;
                                                        _middleGradList[index]
                                                            .number = 2;
                                                        middleSecondGrad =
                                                            _middleGradList[
                                                                    index]
                                                                .name;
                                                      }
                                                    }
                                                  });
                                                }
                                              },
                                              child: Container(
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                  color: getBoxColourGradMiddle(
                                                      index),
                                                  border: showBorderGradMiddle(
                                                          index)
                                                      ? const Border.symmetric(
                                                          horizontal: BorderSide(
                                                              color: Color(
                                                                  0xFFE5EBF0)),
                                                        )
                                                      : null,
                                                  // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                                  borderRadius:
                                                      showBorderGradMiddle(
                                                              index)
                                                          ? null
                                                          : BorderRadius
                                                              .horizontal(
                                                              left: middleFirstGrad ==
                                                                      _middleGradList[
                                                                              index]
                                                                          .name
                                                                  ? const Radius
                                                                      .circular(5)
                                                                  : Radius.zero,
                                                              right: middleSecondGrad ==
                                                                      _middleGradList[
                                                                              index]
                                                                          .name
                                                                  ? const Radius
                                                                      .circular(5)
                                                                  : Radius.zero,
                                                              // right: Radius.circular(25),
                                                            ),
                                                ),
                                                child:
                                                    PaddingWrap.paddingfromLTRB(
                                                        5.0,
                                                        3.0,
                                                        5.0,
                                                        3.0,
                                                        Text(
                                                          _middleGradList[index]
                                                              .name,
                                                          style: TextStyle(
                                                            color: getFontColourGradMiddle(
                                                                index) /*_middleGradList[index]
                                                        .selected
                                                    ? AppConstants
                                                        .colorStyle.white
                                                    : AppConstants
                                                        .colorStyle.darkBlue*/
                                                            ,
                                                            fontSize: 16.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                            fontFamily:
                                                                AppConstants
                                                                    .stringConstant
                                                                    .latoMedium,
                                                          ),
                                                        )),
                                              ),
                                            );
                                          })),
                                  InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        15.0,
                                        BaseText(
                                          text: middleFirstGrad == null ||
                                                  middleFirstGrad == ""
                                              ? "Cancel"
                                              : "Apply",
                                          textColor: middleFirstGrad == null ||
                                                  middleFirstGrad == ""
                                              ? AppConstants
                                                  .colorStyle.lightPurple
                                              : AppConstants
                                                  .colorStyle.lightBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                          maxLines: 1,
                                        )),
                                    onTap: () {
                                      setState(() {
                                        showMiddleGradView = false;
                                        setState(() {
                                          if (middleSecondGrad == "") {
                                            _controllerSchoolGrad.text =
                                                middleFirstGrad;
                                          } else {
                                            _controllerSchoolGrad.text =
                                                middleFirstGrad +
                                                    "-" +
                                                    middleSecondGrad;
                                          }
                                        });
                                      });
                                    },
                                  ),
                                ],
                              )))
                      : Container(
                          height: 0,
                        )
                ],
              )),
            )));
  }

  highClassView() {
    return Expanded(
      child: PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        80.0,
        Container(
          color: Colors.transparent,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                getOrganizationUiSchool(),
                getClassOfData(),
                PaddingWrap.paddingfromLTRB(
                  0.0,
                  20.0,
                  0.0,
                  0.0,
                  TextField(
                    controller: ControllerPrimary,
                    readOnly: true,
                    showCursor: false,
                    onTap: () {
                      visibleHigh = true;
                      showHighGradView = false;
                      SchoolNameFocusNode.unfocus();
                      setState(() {});
                    },
                    focusNode: SchoolYearFocusNode,
                    style: AppConstants.txtStyle.txtStyleTextForm,
                    decoration: InputDecoration(
                      labelText: 'Year',
                      alignLabelWithHint: true,
                      contentPadding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                      border: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg,
                              width: 1.0)),
                      focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.lightBlue,
                              width: 1.0)),
                      enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg,
                              width: 1.0)),
                      disabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: AppConstants.colorStyle.btnBg,
                              width: 1.0)),
                      labelStyle: AppConstants.txtStyle
                          .labelStyleTextForm, /*TextStyle(
                  color: violetColor.withOpacity(.8),
                  fontSize: 16,
                  // fontWeight: FontWeight.w400,
                ) */
                    ),
                  ),
                ),
                Visibility(
                  visible: visibleHigh,
                  child: Container(
                    padding: const EdgeInsets.only(top: 0, right: 10, left: 10),
                    decoration: const BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black12,
                              offset: Offset(0, 2),
                              blurRadius: 12)
                        ]),
                    height: 150,
                    width: double.maxFinite,
                    child: Column(
                      children: [
                        Expanded(
                          child: GridView.builder(
                            padding: EdgeInsets.only(top: 10),
                            // physics: const NeverScrollableScrollPhysics(),
                            itemCount: years.length,
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 5,
                              childAspectRatio: 3 / 2,
                            ),
                            itemBuilder: (context, index) {
                              final year = years[index];
                              return InkWell(
                                onTap: () => setIndex(index),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: getBoxColour(index),
                                    border: showBorder(index)
                                        ? const Border.symmetric(
                                            horizontal: BorderSide(
                                                color: Color(0xFFE5EBF0)),
                                          )
                                        : null,
                                    // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                    borderRadius: showBorder(index)
                                        ? null
                                        : BorderRadius.horizontal(
                                            left: startYear == year
                                                ? const Radius.circular(5)
                                                : Radius.zero,
                                            right: endYear == year
                                                ? const Radius.circular(5)
                                                : Radius.zero,
                                            // right: Radius.circular(25),
                                          ),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5, horizontal: 5),
                                  margin: const EdgeInsets.symmetric(
                                      vertical: 5, horizontal: 5),
                                  alignment: Alignment.center,
                                  child: Text(
                                    years[index].toString(),
                                    style: TextStyle(
                                      color: getFontColour(index),
                                      fontSize: 16,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        duplicateYear
                            ? SizedBox(
                                width: double.maxFinite,
                                height: 45,
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    10.0,
                                    Text(
                                      "You already have school with the same year",
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      style: TextStyle(
                                        color: AppConstants
                                            .colorStyle.btn_text_red,
                                        fontSize: 14,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    )),
                              )
                            : SizedBox(
                                width: double.maxFinite,
                                child: TextButton(
                                  onPressed: () {
                                    visibleHigh = false;
                                    setState(() {});
                                    //  Navigator.pop(context);
                                  },
                                  child: Text(
                                    startYear != null && endYear != null
                                        ? "Apply"
                                        : 'Cancel',
                                    style: TextStyle(
                                      color: startYear != null &&
                                              endYear != null
                                          ? AppConstants.colorStyle.lightBlue
                                          : AppConstants.colorStyle.lightPurple,
                                      fontSize: 16,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                      ],
                    ),
                  ),
                ),
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    0.0,
                    BaseText(
                      text: AppConstants.stringConstant.str_btn_year_hint_high,
                      textColor: AppConstants.colorStyle.darkBlue,
                      fontFamily: AppConstants.stringConstant.latoItalic,
                      fontWeight: FontWeight.w400,
                      fontSize: 14,
                      maxLines: 2,
                    )),
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    20.0,
                    0.0,
                    0.0,
                    TextField(
                      onTap: () {
                        setState(() {
                          showHighGradView = true;
                          visibleHigh = false;
                          SchoolNameFocusNode.unfocus();
                        });
                      },
                      controller: _controllerSchoolGrad,
                      focusNode: SchoolGradHighFocusNode,
                      readOnly: true,
                      style: AppConstants.txtStyle.txtStyleTextForm,
                      decoration: InputDecoration(
                        alignLabelWithHint: true,
                        contentPadding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        labelText: AppConstants.stringConstant.str_School_Grad,
                      ),
                    )),
                showHighGradView == true && SchoolGradHighFocusNode.hasFocus
                    ? PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(1.0),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black12,
                                    offset: Offset(0, 2),
                                    blurRadius: 12)
                              ],
                            ),
                            child: Column(
                              children: [
                                SizedBox(
                                    height: 50,
                                    child: GridView.builder(
                                        padding: EdgeInsets.only(top: 15),
                                        gridDelegate:
                                            const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 5,
                                          mainAxisSpacing: 1,
                                          childAspectRatio: 1.9,
                                        ),
                                        itemCount: _highGradList.length,
                                        itemBuilder: (BuildContext ctx, index) {
                                          return InkWell(
                                            onTap: () {
                                              if (_highGradList[index]
                                                  .selected) {
                                                if (highFirstGrad ==
                                                    _highGradList[index].name) {
                                                  setState(() {
                                                    highFirstGrad = "";
                                                    highSecondGrad = "";
                                                    highFirstIndex = 0;
                                                    highSecondIndex = 0;
                                                    _controllerSchoolGrad.text =
                                                        "";
                                                    _highGradList.clear();
                                                    addHighGrad();
                                                    highFirstGrad = "";
                                                  });
                                                }

                                                if (highSecondGrad ==
                                                    _highGradList[index].name) {
                                                  setState(() {
                                                    _highGradList[
                                                            highSecondIndex]
                                                        .number = 0;
                                                    highSecondGrad = "";
                                                    highSecondIndex = 0;
                                                    _controllerSchoolGrad.text =
                                                        highFirstGrad;
                                                  });
                                                }

                                                setState(() {
                                                  _highGradList[index]
                                                      .selected = false;
                                                  _highGradList[index].number =
                                                      0;
                                                });
                                              } else {
                                                setState(() {
                                                  if (highFirstGrad == "") {
                                                    _highGradList[index]
                                                        .selected = true;
                                                    _highGradList[index]
                                                        .number = 1;
                                                    highFirstGrad =
                                                        _highGradList[index]
                                                            .name;
                                                    highFirstIndex = index;
                                                  } else {
                                                    if (highFirstIndex >
                                                        index) {
                                                    } else if (highSecondGrad ==
                                                        "") {
                                                      _highGradList[index]
                                                          .selected = true;
                                                      highSecondIndex = index;
                                                      _highGradList[index]
                                                          .number = 2;
                                                      highSecondGrad =
                                                          _highGradList[index]
                                                              .name;
                                                    } else {
                                                      setState(() {
                                                        _highGradList[
                                                                highSecondIndex]
                                                            .number = 0;
                                                        _highGradList[
                                                                highSecondIndex]
                                                            .selected = false;
                                                        highSecondIndex = 0;
                                                        highSecondGrad = "";
                                                        _controllerSchoolGrad
                                                                .text =
                                                            highFirstGrad;
                                                      });
                                                      _highGradList[index]
                                                          .selected = true;
                                                      highSecondIndex = index;
                                                      _highGradList[index]
                                                          .number = 2;
                                                      highSecondGrad =
                                                          _highGradList[index]
                                                              .name;
                                                    }
                                                  }
                                                });
                                              }
                                            },
                                            child: Container(
                                              alignment: Alignment.center,
                                              decoration: BoxDecoration(
                                                color: getBoxColourGradHighe(
                                                    index),
                                                border: showBorderGradHigh(
                                                        index)
                                                    ? const Border.symmetric(
                                                        horizontal: BorderSide(
                                                            color: Color(
                                                                0xFFE5EBF0)),
                                                      )
                                                    : null,
                                                // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                                borderRadius:
                                                    showBorderGradHigh(index)
                                                        ? null
                                                        : BorderRadius
                                                            .horizontal(
                                                            left: highFirstGrad ==
                                                                    _highGradList[
                                                                            index]
                                                                        .name
                                                                ? const Radius
                                                                    .circular(5)
                                                                : Radius.zero,
                                                            right: highSecondGrad ==
                                                                    _highGradList[
                                                                            index]
                                                                        .name
                                                                ? const Radius
                                                                    .circular(5)
                                                                : Radius.zero,
                                                            // right: Radius.circular(25),
                                                          ),
                                              ),
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      5.0,
                                                      3.0,
                                                      5.0,
                                                      3.0,
                                                      Text(
                                                        _highGradList[index]
                                                            .name,
                                                        style: TextStyle(
                                                          color:
                                                              getFontColourGradHigh(
                                                                  index),
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoMedium,
                                                        ),
                                                      )),
                                            ),
                                          );
                                        })),
                                InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      10.0,
                                      0.0,
                                      10.0,
                                      BaseText(
                                        text: highFirstGrad == null ||
                                                highFirstGrad == ""
                                            ? "Cancel"
                                            : "Apply",
                                        textColor: highFirstGrad == null ||
                                                highFirstGrad == ""
                                            ? AppConstants
                                                .colorStyle.lightPurple
                                            : AppConstants.colorStyle.lightBlue,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        maxLines: 1,
                                      )),
                                  onTap: () {
                                    setState(() {
                                      showHighGradView = false;

                                      setState(() {
                                        if (highSecondGrad == "") {
                                          _controllerSchoolGrad.text =
                                              highFirstGrad;
                                        } else {
                                          _controllerSchoolGrad.text =
                                              highFirstGrad +
                                                  "-" +
                                                  highSecondGrad;
                                        }
                                      });
                                    });
                                  },
                                ),
                              ],
                            )))
                    : Container(
                        height: 0,
                      ),
                PaddingWrap.paddingfromLTRB(
                  0.0,
                  20.0,
                  0.0,
                  80.0,
                  Padding(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: TextFormField(
                      autovalidateMode: AutovalidateMode.onUserInteraction,
                      keyboardType:
                          TextInputType.numberWithOptions(decimal: true),
                      textInputAction: TextInputAction.done,
                      scrollPadding: EdgeInsets.only(
                          bottom: MediaQuery.of(context).viewInsets.bottom),
                      controller: _controllerSchoolGPA,
                      focusNode: focusSchoolGPA,
                      style: AppConstants.txtStyle.txtStyleTextForm,
                      inputFormatters: [
                        DecimalTextInputFormatter(decimalRange: 2)
                      ],
                      decoration: InputDecoration(
                        alignLabelWithHint: true,
                        contentPadding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                        labelText: AppConstants.stringConstant.str_School_gpa,
                        labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.lightBlue,
                                width: 1.0)),
                        enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        disabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: AppConstants.colorStyle.btnBg,
                                width: 1.0)),
                        suffixIcon: Padding(
                          padding: EdgeInsets.only(bottom: 10.0),
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            widthFactor: 1.0,
                            heightFactor: 1.0,
                            child: Text(
                              '${'Optional'}',
                              style: TextStyle(
                                color: AppConstants.colorStyle.darkBlue,
                                fontSize: 16.0,
                                fontWeight: FontWeight.w500,
                                fontFamily:
                                    AppConstants.stringConstant.latoItalic,
                              ),
                            ),
                          ),
                        ),
                      ),
                      validator: (val) {
                        return val.trim().length == 0
                            ? null
                            : !ValidationWidget.isValidaGPA(val)
                                ? MessageConstant.ENTER_gpa_out_of_less
                                : null;
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

// dropdown class of
  Container getClassOfData() {
    return Container(
      child: Column(
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
            0.0,
            20.0,
            0.0,
            0.0,
            TextField(
              controller: _controllerSchoolClassOff,
              showCursor: false,
              readOnly: true,
              onTap: () {
                print("classOffVisible..222.." + classOffVisible.toString());
                if (classOffVisible) {
                  print("classOffVisible..111.." + classOffVisible.toString());
                  setState(() {
                    visibleHigh = false;
                    classOffVisible = false;
                    organizationLstSchool.clear();
                    SchoolNameFocusNode.unfocus();
                  });
                } else {
                  print("classOffVisible...." + classOffVisible.toString());
                  setState(() {
                    visibleHigh = false;
                    classOffVisible = true;
                    organizationLstSchool.clear();
                    SchoolNameFocusNode.unfocus();
                  });
                }
              },
              focusNode: classOffFocusNode,
              style: AppConstants.txtStyle.txtStyleTextForm,
              decoration: InputDecoration(
                isDense: true,
                alignLabelWithHint: true,
                contentPadding: const EdgeInsets.fromLTRB(0, 0, 0, 10),
                labelText: AppConstants.stringConstant.str_School_class_of,
                suffixIconConstraints:
                    BoxConstraints(maxHeight: 24, maxWidth: 24),
                labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                border: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.btnBg, width: 1.0)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.lightBlue, width: 1.0)),
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.btnBg, width: 1.0)),
                disabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: AppConstants.colorStyle.btnBg, width: 1.0)),
                suffixIcon: GestureDetector(
                  child: Align(
                    alignment: Alignment.bottomRight,
                    child: classOffVisible == true
                        ? Image.asset(
                            'assets/new_onboarding/arrow_up.png',
                          )
                        : Image.asset(
                            'assets/new_onboarding/arrow_down.png',
                          ),
                  ),
                ),
              ),
            ),
          ),
          classOffVisible == true
              ? PaddingWrap.paddingfromLTRB(
                  5.0,
                  8.0,
                  5.0,
                  0.0,
                  Container(
                      decoration: const BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 2),
                                blurRadius: 12)
                          ]),
                      height: yearList.length == 0
                          ? 0.0
                          : yearList.length == 1
                              ? 68.0
                              : yearList.length == 2
                                  ? 142.0
                                  : yearList.length == 3
                                      ? 142.0
                                      : 142.0,
                      child: MediaQuery.removePadding(
                          context: context,
                          removeTop: true,
                          child: ListView(children: _buildClassOf()))),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }

  List<InkWell> _buildClassOf() {
    return List.generate(yearList.length, (int index) {
      return InkWell(
          child: Container(
            height: 40,
            margin: EdgeInsets.only(top: 3, bottom: 3, left: 5, right: 5),
            padding: EdgeInsets.only(top: 7, bottom: 2, left: 10, right: 10),
            decoration: BoxDecoration(
              color: AppConstants.colorStyle.tabBg,
              border: Border.all(color: AppConstants.colorStyle.btnBg),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: <Widget>[
                Align(
                  child: Text(
                    yearList[index],
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: AppConstants.colorStyle.darkBlue,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                    ),
                  ),
                  alignment: Alignment.centerLeft,
                ),
              ],
            ),
          ),
          onTap: () {
            setState(() {
              setState(() {
                classOffVisible = false;
                FocusScope.of(context).requestFocus(new FocusNode());
                SchoolNameFocusNode.unfocus();
                _controllerSchoolClassOff.text = yearList[index];
                year1 = yearList[index];
                stryear1 = yearList[index];

                getCalendarList(int.parse(year1));

                startYear = int.parse(year1) - 4;
                endYear = int.parse(year1);
                setTextFieldValue();
              });
            });
          });
    });
  }

  Widget _collegeOfYearDropdown() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        PaddingWrap.paddingfromLTRB(
          0.0,
          20.0,
          0.0,
          0.0,
          TextField(
            controller: _controllerSchoolClassOff,
            showCursor: false,
            readOnly: true,
            onTap: () {
              setState(() {
                classOffVisible = !classOffVisible;
                CollegeNameFocusNode.unfocus();
              });
            },
            focusNode: classOffFocusNode,
            style: AppConstants.txtStyle.txtStyleTextForm,
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
              labelText: AppConstants.stringConstant.str_School_class_of,
              suffixIconConstraints: BoxConstraints(
                  minWidth: 18, minHeight: 18, maxHeight: 25, maxWidth: 25),
              labelStyle: AppConstants.txtStyle.labelStyleTextForm,
              border: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: AppConstants.colorStyle.btnBg, width: 1.0)),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: AppConstants.colorStyle.lightBlue, width: 1.0)),
              enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: AppConstants.colorStyle.btnBg, width: 1.0)),
              disabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: AppConstants.colorStyle.btnBg, width: 1.0)),
              suffixIcon: GestureDetector(
                child: Container(
                  width: 18.0,
                  height: 18.0,
                  padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                  child: classOffVisible == true
                      ? new Image.asset(
                          'assets/new_onboarding/arrow_up.png',
                        )
                      : new Image.asset(
                          'assets/new_onboarding/arrow_down.png',
                        ),
                ),
              ),
            ),
          ),
        ),
        classOffVisible == true
            ? PaddingWrap.paddingfromLTRB(
                5.0,
                8.0,
                5.0,
                0.0,
                Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black12,
                            offset: Offset(0, 2),
                            blurRadius: 12)
                      ],
                    ),
                    height: yearList.length == 0
                        ? 0.0
                        : yearList.length == 1
                            ? 68.0
                            : yearList.length == 2
                                ? 142.0
                                : yearList.length == 3
                                    ? 142.0
                                    : 142.0,
                    child: MediaQuery.removePadding(
                        context: context,
                        removeTop: true,
                        child: ListView(children: _buildClassOf()))),
              )
            : const SizedBox.shrink(),
      ],
    );
  }

  collageView() {
    return Expanded(
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            0.0,
            0.0,
            80.0,
            Container(
                color: Colors.transparent,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      getOrganizationUiCollege(),
                      //_collegeOfYearDropdown(),
                      PaddingWrap.paddingfromLTRB(
                        0.0,
                        25.0,
                        0.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            yearCollege != null
                                ? getTextLabel1(
                                    AppConstants
                                        .stringConstant.str_School_class_of,
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal)
                                : getTextLabel1(
                                    "",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal),
                            Container(
                              height: 38.0,
                              padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 5.0),
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom: BorderSide(
                                          color: ColorValues.DARK_GREY,
                                          width: 1.0))),
                              width: double.infinity,
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  hint: Text(
                                    AppConstants
                                        .stringConstant.str_School_class_of,
                                    style: TextStyle(
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        color: ColorValues.GREY_TEXT_COLOR),
                                  ),
                                  value: yearCollege,
                                  items: yearList
                                      .map(
                                        (String item) =>
                                            DropdownMenuItem<String>(
                                          value: item,
                                          child: PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            0.0,
                                            5.0,
                                            Text(
                                              item,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontSize: 18.0,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium),
                                            ),
                                          ),
                                        ),
                                      )
                                      .toList(),
                                  onChanged: (s) {
                                    setState(() {
                                      FocusScope.of(context)
                                          .requestFocus(new FocusNode());
                                      CollegeNameFocusNode.unfocus();
                                      yearCollege = s;
                                      stryearCollege = s;
                                      getCalendarList(int.parse(yearCollege));

                                      startYear = int.parse(yearCollege) - 4;
                                      endYear = int.parse(yearCollege);
                                      setTextFieldValue();
                                    });
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      PaddingWrap.paddingfromLTRB(
                        0.0,
                        25.0,
                        0.0,
                        0.0,
                        TextField(
                          controller: ControllerPrimary,
                          readOnly: true,
                          onTap: () {
                            visibleCollege = true;
                            CollegeNameFocusNode.unfocus();

                            setState(() {});
                          },
                          showCursor: false,
                          focusNode: SchoolYearFocusNode,
                          style: TextStyle(
                            color: violetColor,
                            fontSize: 18.0,
                            fontWeight: FontWeight.w500,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                          ),
                          decoration: InputDecoration(
                            labelText: 'Year',
                            labelStyle:
                                AppConstants.txtStyle.labelStyleTextForm,
                            border: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg,
                                    width: 1.0)),
                            focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.lightBlue,
                                    width: 1.0)),
                            enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg,
                                    width: 1.0)),
                            disabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                    color: AppConstants.colorStyle.btnBg,
                                    width: 1.0)),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: visibleCollege,
                        child: Container(
                          padding: const EdgeInsets.only(
                              top: 0, right: 10, left: 10),
                          decoration: const BoxDecoration(
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black12,
                                    offset: Offset(0, 2),
                                    blurRadius: 12)
                              ]),
                          height: 150,
                          width: double.maxFinite,
                          child: Column(
                            children: [
                              Expanded(
                                child: GridView.builder(
                                  padding: EdgeInsets.only(top: 10),
                                  // physics: const NeverScrollableScrollPhysics(),
                                  itemCount: years.length,
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 5,
                                    childAspectRatio: 3 / 2,
                                  ),
                                  itemBuilder: (context, index) {
                                    final year = years[index];
                                    return InkWell(
                                      onTap: () => setIndex(index),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: getBoxColour(index),
                                          border: showBorder(index)
                                              ? const Border.symmetric(
                                                  horizontal: BorderSide(
                                                      color: Color(0xFFE5EBF0)),
                                                )
                                              : null,
                                          // border: Border.symmetric(horizontal: BorderSide(color: Colors.grey)),
                                          borderRadius: showBorder(index)
                                              ? null
                                              : BorderRadius.horizontal(
                                                  left: startYear == year
                                                      ? const Radius.circular(5)
                                                      : Radius.zero,
                                                  right: endYear == year
                                                      ? const Radius.circular(5)
                                                      : Radius.zero,
                                                  // right: Radius.circular(25),
                                                ),
                                        ),
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 5, horizontal: 5),
                                        margin: const EdgeInsets.symmetric(
                                            vertical: 5, horizontal: 0),
                                        alignment: Alignment.center,
                                        child: Text(
                                          years[index].toString(),
                                          style: TextStyle(
                                            color: getFontColour(index),
                                            fontSize: 16,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                              duplicateYear
                                  ? SizedBox(
                                      height: 45,
                                      width: double.maxFinite,
                                      child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        10.0,
                                        Text(
                                          "You already have college with the same year",
                                          textAlign: TextAlign.center,
                                          maxLines: 2,
                                          style: TextStyle(
                                            color: AppConstants
                                                .colorStyle.btn_text_red,
                                            fontSize: 14,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    )
                                  : SizedBox(
                                      width: double.maxFinite,
                                      child: TextButton(
                                          onPressed: () {
                                            visibleCollege = false;
                                            setState(() {});
                                            //  Navigator.pop(context);
                                          },
                                          child: Text(
                                            startYear != null && endYear != null
                                                ? "Apply"
                                                : 'Cancel',
                                            style: TextStyle(
                                              color: startYear != null &&
                                                      endYear != null
                                                  ? AppConstants
                                                      .colorStyle.lightBlue
                                                  : AppConstants
                                                      .colorStyle.lightPurple,
                                              fontSize: 16,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoMedium,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          )),
                                    ),
                            ],
                          ),
                        ),
                      ),
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          20.0,
                          0.0,
                          0.0,
                          BaseText(
                            text: AppConstants
                                .stringConstant.str_btn_year_hint_college,
                            textColor: AppConstants.colorStyle.darkBlue,
                            fontFamily: AppConstants.stringConstant.latoItalic,
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            maxLines: 2,
                          )),
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          25.0,
                          0.0,
                          80.0,
                          Padding(
                            padding: EdgeInsets.only(
                                bottom:
                                    MediaQuery.of(context).viewInsets.bottom),
                            child: TextFormField(
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              scrollPadding: EdgeInsets.only(
                                  bottom:
                                      MediaQuery.of(context).viewInsets.bottom),
                              keyboardType: TextInputType.numberWithOptions(
                                  decimal: true),
                              controller: _controllerCollegeGPA,
                              focusNode: focusCollegeGPA,
                              textInputAction: TextInputAction.done,
                              style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 18.0,
                                fontWeight: FontWeight.w500,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                              ),
                              inputFormatters: [
                                DecimalTextInputFormatter(decimalRange: 2)
                              ],
                              decoration: InputDecoration(
                                contentPadding:
                                    const EdgeInsets.fromLTRB(0, 10, 0, 10),
                                labelStyle:
                                    AppConstants.txtStyle.labelStyleTextForm,
                                labelText:
                                    AppConstants.stringConstant.str_School_gpa,
                                errorStyle: Util.errorTextStyle,
                                suffixIcon: Padding(
                                  padding: EdgeInsets.only(bottom: 10.0),
                                  child: Align(
                                    alignment: Alignment.bottomCenter,
                                    widthFactor: 1.0,
                                    heightFactor: 1.0,
                                    child: Text(
                                      '${'Optional'}',
                                      style: TextStyle(
                                        color: AppConstants.colorStyle.darkBlue,
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: AppConstants
                                            .stringConstant.latoItalic,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              validator: (val) {
                                return val.trim().length == 0
                                    ? null
                                    : !ValidationWidget.isValidaGPA(val)
                                        ? MessageConstant.ENTER_gpa_out_of_less
                                        : null;
                              },
                            ),
                          )),
                    ],
                  ),
                ))));
  }

  Future<void> addEducationApi(BuildContext mContext) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (primarySecondIndex == 0 || primarySecondIndex == null) {
          primarySecondGrad = primaryFirstGrad;
        }
        if (middleSecondIndex == 0 || middleSecondIndex == null) {
          middleSecondGrad = middleFirstGrad;
        }
        if (highSecondIndex == 0 || highSecondIndex == null) {
          highSecondGrad = highFirstGrad;
        }

        Map map = {
          "userId": widget.studModel.userId,
          "roleId": "1",
          "gpa": educationClickEvent == 1 || educationClickEvent == 2
              ? ""
              : educationClickEvent == 3
                  ? _controllerSchoolGPA.text
                  : _controllerCollegeGPA.text,
          "institute": educationClickEvent == 1 ||
                  educationClickEvent == 2 ||
                  educationClickEvent == 3
              ? _searchQuerySchoolName.text.toString()
              : _searchQueryCollegeName.text.toString(),
          "city": educationClickEvent == 1 ||
                  educationClickEvent == 2 ||
                  educationClickEvent == 3
              ? _searchTextSchoolCity
              : '',
          "year": educationClickEvent == 3
              ? stryear1
              : educationClickEvent == 1 || educationClickEvent == 2
                  ? ""
                  : stryearCollege,
          "fromYear": startYear,
          "toYear": endYear,
          "fromGrade": educationClickEvent == 1
              ? primaryFirstGrad
              : educationClickEvent == 2
                  ? middleFirstGrad
                  : educationClickEvent == 3
                      ? highFirstGrad
                      : "",
          "toGrade": educationClickEvent == 1
              ? primarySecondGrad
              : educationClickEvent == 2
                  ? middleSecondGrad
                  : educationClickEvent == 3
                      ? highSecondGrad
                      : "",
          "type": educationClickEvent == 1 ||
                  educationClickEvent == 2 ||
                  educationClickEvent == 3
              ? "School"
              : "College",
          "gradeType": educationClickEvent == 1
              ? "primary"
              : educationClickEvent == 2
                  ? "middle"
                  : educationClickEvent == 3
                      ? "high"
                      : educationClickEvent == 5
                          ? "high school diploma"
                          : educationClickEvent == 6
                              ? "Undergraduate Degree"
                              : educationClickEvent == 7
                                  ? "Masters Degree"
                                  : educationClickEvent == 8
                                      ? "PhD"
                                      : educationClickEvent == 9
                                          ? "Associate Degree"
                                          : educationClickEvent == 10
                                              ? "Transfer Degree"
                                              : educationClickEvent == 11
                                                  ? "Professional Certificate"
                                                  : educationClickEvent == 12
                                                      ? "Professional Degree"
                                                      : educationClickEvent ==
                                                              13
                                                          ? "Specialist Degree"
                                                          : "",
        };

        Response response = await ApiCalling()
            .apiCallPostWithMapData(mContext, '/ui/addEducation', map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              if (widget.pageName == null) {
                apiCallingUpdate();
              } else {
                Navigator.pop(context, 'push');
              }
            } else {
              if (msg ==
                  "Grade entry already exists and can’t be duplicated.") {
                setState(() {
                  if (educationClickEvent == 1) {
                    visiblePrimary = true;
                  } else if (educationClickEvent == 2) {
                    visibleMiddel = true;
                  } else if (educationClickEvent == 3) {
                    visibleHigh = true;
                  } else {
                    visibleCollege = true;
                  }
                  duplicateYear = true;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, mContext);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", mContext);
      e.toString();
    }
  }

  Future apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userIdPref, "stage": "4"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              String result = await Navigator.of(context).push(
                  new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          EducationAddedWeightParentChild(
                            studModel: widget.studModel,
                            screenName: "onBoarding",
                            userId: widget.studModel.userId,
                          )));
              if (result == "push") {}
            } else {}
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  eventButton(int clicEvent) {
    return educationClickEvent == clicEvent &&
        _searchQueryCollegeName.text != '' &&
        stryearCollege != '' &&
        startYear != null &&
        endYear != null;
  }

  void addPrimaryGrad() {
    graditemModel mgraditemModel13 = graditemModel('KG', false, 0);
    _primaryGradList.add(mgraditemModel13);
    graditemModel mgraditemModel = graditemModel('1st', false, 0);
    _primaryGradList.add(mgraditemModel);
    graditemModel mgraditemModel1 = graditemModel('2nd', false, 0);
    _primaryGradList.add(mgraditemModel1);
    graditemModel mgraditemModel2 = graditemModel('3rd', false, 0);
    _primaryGradList.add(mgraditemModel2);
    graditemModel mgraditemModel3 = graditemModel('4th', false, 0);
    _primaryGradList.add(mgraditemModel3);
    graditemModel mgraditemModel4 = graditemModel('5th', false, 0);
    _primaryGradList.add(mgraditemModel4);
    graditemModel mgraditemModel5 = graditemModel('6th', false, 0);
    _primaryGradList.add(mgraditemModel5);
    setState(() {});
  }

  void addMiddleGrad() {
    graditemModel mgraditemModel5 = graditemModel('6th', false, 0);
    _middleGradList.add(mgraditemModel5);
    graditemModel mgraditemModel6 = graditemModel('7th', false, 0);
    _middleGradList.add(mgraditemModel6);
    graditemModel mgraditemModel7 = graditemModel('8th', false, 0);
    _middleGradList.add(mgraditemModel7);

    setState(() {});
  }

  void addHighGrad() {
    graditemModel mgraditemModel8 = graditemModel('9th', false, 0);
    _highGradList.add(mgraditemModel8);
    graditemModel mgraditemModel9 = graditemModel('10th', false, 0);
    _highGradList.add(mgraditemModel9);
    graditemModel mgraditemModel10 = graditemModel('11th', false, 0);
    _highGradList.add(mgraditemModel10);
    graditemModel mgraditemModel11 = graditemModel('12th', false, 0);
    _highGradList.add(mgraditemModel11);
    setState(() {
      _highGradList;
    });
  }

  void getCalendarList(int endYearClassOff) {
    years = List.generate(endYearClassOff - widget.startYear + 1,
        (index) => widget.startYear + index);

    setState(() {});
  }

  Future getSchoolName(schoolCode) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("data++++++searchText===" + schoolCode.toString());
        Response response = await ApiCalling2().apiCall(
            context, Constant.SCHOOL_DETAIL_SCHOOLCODE + schoolCode, "get");
        print("data++++++searchText===" + response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 = ParseJson.parseMapOrganization(
                  response.data['result'], 'school');
              if (organizationLst1.length > 0) {
                for (int i = 0; i < organizationLst1.length; i++) {
                  if (prefs.getString(UserPreference.SCHOOL_CODE) ==
                      organizationLst1[i].schoolCode) {
                    setState(() {
                      _searchQuerySchoolName.text = organizationLst1[i].name;
                      /*     strOrganizationId = organizationLst1[i].organizationId;
                      previousOrganizationId =
                          organizationLst1[i].organizationId;
                      schoolName = organizationLst1[i].name;
                      _IsSearching = false;*/
                      schoolApiCalling = false;
                      isSchoolEnable = false;
                    });
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }
}
