import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:keyboard_visibility/keyboard_visibility.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/education/model/UniversityModel.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';
import 'package:spike_view_project/skill/model/SkillModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/positive_button.dart';

// Create a Form Widget
class AddEditFutureGoalsWidget extends StatefulWidget {
  SkillIntrestDataModel _mSkillModel;
  bool isFirstTimeCalling;
  ProfileInfoModal profileInfoModal;
  final ProfileData mProfileInfoModal;
  final String studentId;

  AddEditFutureGoalsWidget(
      this._mSkillModel,
      this.isFirstTimeCalling,
      this.profileInfoModal,
      this.mProfileInfoModal, {
        this.studentId,
      });

  @override
  AddEditFutureGoalsWidgetState createState() {
    return AddEditFutureGoalsWidgetState();
  }
}

class AddEditFutureGoalsWidgetState extends State<AddEditFutureGoalsWidget>
    with BaseCommonWidget {
  final _formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, token;

  SkillModel _skillModel = SkillModel();

  List<SkillData> selectedLoveInterestsList = List<SkillData>();

  String strInstitute = '';
  int optionCount = 0;

  TextEditingController instituteController = TextEditingController(text: "");
  String popString = '';
  TextEditingController otherController = TextEditingController(text: "");

  final FocusNode _otherInterestFocus = FocusNode();

  Color bottomViewColor = Palette.dividerColor;

  bool showList = false;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();

  bool isNeedCounselorYes = false;
  bool isNeedCounselorNo = false;

  bool isNotShare = false;
  bool isNo = false;
  bool isYes = false;

  bool isFinancialSupportSelected = false;
  bool isCounselerSupportSelected = false;


  Timer _timer;

  TextEditingController _textFieldController = TextEditingController(text: "");
  final FocusNode _textFieldFocus = FocusNode();

  List<SkillData> _searchedUniversityList = List<SkillData>();

  List<String> selectedUniversityOption = [];

  List<SkillData> _universityList = List();

  List<SkillData> removedUniversiyList = List<SkillData>();
  List<SkillData> origanalUniversiyList = List<SkillData>();
  ScrollController controller;
  int listIndexFrom = 0;

  List<UniversityResult> selectedUniversityList = List<UniversityResult>();

  //List<SkillData> removedUniversiyList=new List<SkillData>();
//------------------------------------Retrive data ( Userid nd token ) ---------------------

  ///First Top Goals Intrest
  List<SkillData> selectedLoveInterestsList1 = List<SkillData>();
  SkillModel _skillModel1 = SkillModel();
  SkillIntrestDataModel widgetSkillModel;
  List<GoalUniversity> selectedUniversityOption1 = List<GoalUniversity>();
  List<UniversityResult> selectedUniversityList1 = List<UniversityResult>();
  List<UniversityResult> _universityListUniversity;

  List<UniversityResult> removedUniversiyList1 = List<UniversityResult>();
  List<UniversityResult> _universityCollegeList;
  List<UniversityResult> _searchedUniversityCollegeList =
  List<UniversityResult>();
  List<GoalUniversity> selectedUniversityCollegeOption = List<GoalUniversity>();
  List<UniversityResult> removedUniversiyCollegeList = List<UniversityResult>();
  List<UniversityResult> selectedUniversityCollegeList =
  List<UniversityResult>();
  List<UniversityResult> origanalUniversiyCollegeList =
  List<UniversityResult>();

  TextEditingController _textFieldControllerAddCollege =
  TextEditingController(text: "");
  FocusNode _textFieldFocusCollege = FocusNode();
  int listIndexFromCollege = 0;

  bool showUniversityCollegeList = false;

  UniversityModel _universityModel = UniversityModel();

  ScrollController _scrollController = ScrollController();

  bool isScroled = true;

  ScrollController _scrollControllerCollection = ScrollController();
  int positionOfCollection = 0;
  int skipCollection = 0;

  getSharedPreferences() async {
    KeyboardVisibilityNotification().addNewListener(
      onChange: (bool visible) {
        if (!visible) {
          setState(() {});
        }
      },
    );

    prefs = await SharedPreferences.getInstance();
    if (widget.studentId != null) {
      userIdPref = widget.studentId;
    } else {
      userIdPref = widget.mProfileInfoModal.userId;
    }

    token = prefs.getString(UserPreference.USER_TOKEN);
    setState(() {
      if (widget.mProfileInfoModal != null) {
        if (widget.mProfileInfoModal.goalInterestInstitute != null &&
            widget.mProfileInfoModal.goalInterestInstitute != "" &&
            widget.mProfileInfoModal.goalInterestInstitute != "null") {
          instituteController.text =
              widget.mProfileInfoModal.goalInterestInstitute;
          strInstitute = widget.mProfileInfoModal.goalInterestInstitute;
        }
      }

      if (widget.mProfileInfoModal != null) {
        if (widget.mProfileInfoModal.goalInterestInstitute != null &&
            widget.mProfileInfoModal.goalInterestInstitute != "" &&
            widget.mProfileInfoModal.goalInterestInstitute != "null") {
          instituteController.text =
              widget.mProfileInfoModal.goalInterestInstitute;
          strInstitute = widget.mProfileInfoModal.goalInterestInstitute;
        }

        //to init needCounselor
        if (widget.mProfileInfoModal.needCounselor != null) {

          isNeedCounselorYes = false;
          isNeedCounselorNo = false;
          if (widget.mProfileInfoModal.needCounselor) {
            isNeedCounselorYes = true;
            isCounselerSupportSelected = true;

          } else {
            isCounselerSupportSelected = true;

            isNeedCounselorNo = true;
          }
        }else{
          isCounselerSupportSelected = false;
        }

        //to init financialSupport
        if (widget.mProfileInfoModal.financialSupport != null) {

          //isYes ? "Yes" : isNo ? "No" : "Notshare" ,
          isYes = false;
          isNotShare = false;
          isNo = false;
          if (widget.mProfileInfoModal.financialSupport == 'Yes'){
            isFinancialSupportSelected = true;
            isYes = true;

          }
          else if (widget.mProfileInfoModal.financialSupport == 'No'){
            isFinancialSupportSelected = true;
            isNo = true;

          }
          else if (widget.mProfileInfoModal.financialSupport == 'Notshare'){
            isFinancialSupportSelected = true;
            isNotShare = true;

          }
          setState(() {});
        }else{
          isFinancialSupportSelected = false;

        }
      }
    });

    await callLoveInterestApi1();
    await callCollegeListApi("");
    await callLoveInterestApi();

    for (University goalUniversities
    in widget.mProfileInfoModal.universityList) {
      selectedUniversityCollegeOption.add(GoalUniversity(
          universityId: goalUniversities.universityId,
          name: goalUniversities.name));
      selectedUniversityCollegeList.add(UniversityResult(
          name: goalUniversities.name,
          universityId: goalUniversities.universityId));
    }
    _scrollControllerCollection.addListener(() {
      if (_searchedUniversityCollegeList.length - 1 == positionOfCollection) {
        if (_scrollControllerCollection.position.pixels ==
            _scrollControllerCollection.position.maxScrollExtent) {
          setState(() {
            skipCollection = skipCollection + 1;
            callCollegeListApiOnPullRefresh(
                _textFieldControllerAddCollege.text.trim());
          });
        }
      }
    });
  }

  void setUniversityData() {
    try {
      _searchedUniversityCollegeList.clear();
      _searchedUniversityCollegeList
          .addAll(_universityCollegeList.sublist(0, 10));
      listIndexFromCollege = 10;

      for (GoalUniversity goalUniversities
      in widgetSkillModel.result[0].goalUniversities) {
        selectedUniversityCollegeOption.add(goalUniversities);
        selectedUniversityCollegeList.add(UniversityResult(
            name: goalUniversities.name,
            universityId: goalUniversities.universityId));
      }

      if (_universityCollegeList != null && _universityCollegeList.isNotEmpty) {
        origanalUniversiyCollegeList.addAll(_universityCollegeList);
        for (var selectedOption in selectedUniversityCollegeOption) {
          for (var universityResultModel in origanalUniversiyCollegeList) {
            print('universityResultModel:::::: ${universityResultModel.name}');
            if (selectedOption.universityId.toString() ==
                universityResultModel.universityId.toString()) {
              removedUniversiyCollegeList.add(UniversityResult(
                //sId: universityResultModel.sId,
                  name: universityResultModel.name,
                  universityId: universityResultModel.universityId));
            }
          }
        }
      }

      _universityCollegeList.clear();
      for (final e in origanalUniversiyCollegeList) {
        bool found = false;
        for (final f in removedUniversiyCollegeList) {
          if (e.universityId.toString() == f.universityId.toString()) {
            found = true;
            break;
          }
        }
        if (!found) {
          _universityCollegeList.add(e);
        }
      }

      setState(() {});
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "EditGoalsinterestWidget", context);
    }
  }

  void _positiveButtonTap() {
    _checkValidation();
  }

  void _checkValidation() async {
    FocusScope.of(context).requestFocus(new FocusNode());
    final form = _formKey.currentState;

    form.save();
    if (form.validate()) {
      if (widget.isFirstTimeCalling) {
        if (Util.dobCheck(widget.mProfileInfoModal.dob) &&
            widget.profileInfoModal.publicUrl != null &&
            widget.profileInfoModal.publicUrl != "null" &&
            widget.profileInfoModal.publicUrl != "") {
          conformationDialogForAddIntoProfile();
        } else {
          editInterest(false);
        }
      } else {
        editInterest(false);
      }
    } else {
      print("Failure 00");
    }
  }

  //=========================================================Api Calling =======================================

  Future<String> callLoveInterestApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling().apiCall(context,
            Constant.ENDPOINT_GET_HOBBY_TYPE_API + "major_interests", "get");
        print("Love Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _skillModel = SkillModel.fromJson(response.data);
              try {
                _universityList = _skillModel.skillList;
                _searchedUniversityList = _skillModel.skillList;

                for (SkillID skills
                in widget.mProfileInfoModal.majorInterestsList) {
                  selectedUniversityOption.add(skills.name);
                }

                if (_universityList != null && _universityList.isNotEmpty) {
                  origanalUniversiyList.addAll(_universityList);
                  for (SkillID selectedOption
                  in widget.mProfileInfoModal.majorInterestsList) {
                    if (selectedOption.hobbyId != "" &&
                        selectedOption.hobbyId != null &&
                        selectedOption.hobbyId.toString() != 'null') {
                      for (var universityResultModel in origanalUniversiyList) {
                        print(
                            'universityResultModel:::::: ${universityResultModel.name}');
                        if (selectedOption.name.toString() ==
                            universityResultModel.name.toString()) {
                          removedUniversiyList.add(SkillData(
                            //sId: universityResultModel.sId,
                              name: universityResultModel.name,
                              hobbyId: universityResultModel.hobbyId));

                          selectedLoveInterestsList.add(SkillData(
                              name: universityResultModel.name,
                              hobbyId: universityResultModel.hobbyId));
                        }
                      }
                    } else {
                      selectedLoveInterestsList.add(SkillData(
                        name: selectedOption.name.toString(),
                      ));
                    }
                  }
                }
                _universityList.clear();
                for (final e in origanalUniversiyList) {
                  bool found = false;
                  for (final f in removedUniversiyList) {
                    if (e.hobbyId.toString() == f.hobbyId.toString()) {
                      found = true;
                      break;
                    }
                  }
                  if (!found) {
                    _universityList.add(e);
                  }
                }

                setState(() {});
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AddEditFutureGoalsWidget", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEditFutureGoalsWidget", context);
      e.toString();
    }
  }

  Future<Null> onRefreshPending() async {
    setState(() {
      skipCollection = 0;
      _universityCollegeList.clear();
      _searchedUniversityCollegeList.clear();
    });
    callCollegeListApiOnPullRefresh(_textFieldControllerAddCollege.text.trim());
  }

  //--------------------------Edit Data ------------------

  void conformationDialogForAddIntoProfile() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Do you want to publish this interest to your public profile?',
          positiveText: "Yes",
          negativeText: "No",
          positiveTextColor: ColorValues
              .BLUE_COLOR_BOTTOMBAR,
          onPositiveTap: () {
            editInterest(true);
          },
          onNegativeTap: (){
            editInterest(false);
          },
        );
      },
    );
  }

  Future<String> callCollegeListApi(String searchText) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling().apiCall(
            context,
            'app/masters/universities?skip=' +
                "0" +
                '&name=' +
                searchText +
                '&limit=20',
            "get");

        print("ENDPOINT_universities_list Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _universityModel = UniversityModel.fromJson(response.data);
              try {
                print("inside Success try block  ");

                //shubham search

                _universityCollegeList = _universityModel.result;
                _searchedUniversityCollegeList = _universityModel.result;

                // Remove elements from searchedUniversityCollegeList that are also in selectedUniversityCollegeOption



                Timer(Duration(seconds: 1), () {
                  print("Yeah, this line is printed after 3 seconds");
                  for (UniversityResult element in _searchedUniversityCollegeList.toList()) {
                    if (selectedUniversityCollegeList.any((selectedElement) => selectedElement.name == element.name)) {
                      // If an element with the same name is in selectedUniversityCollegeList, skip it.
                      print("Element with name ${element.name} is already selected.");
                      _universityCollegeList.remove(element);
                      _searchedUniversityCollegeList.remove(element);

                    }
                  }
                  setState(() {});

                });
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "EditGoalsinterestWidget", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "EditGoalsinterestWidget", context);
      e.toString();
    }
  }

  Future<String> callCollegeListApiOnPullRefresh(String searchText) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling().apiCall(
            context,
            'app/masters/universities?skip=' +
                skipCollection.toString() +
                '&name=' +
                searchText +
                '&limit=20',
            "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _universityModel = UniversityModel.fromJson(response.data);
              try {
                _universityCollegeList.addAll(_universityModel.result);
                _searchedUniversityCollegeList.addAll(_universityModel.result);
                setState(() {});
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "EditGoalsinterestWidget", context);
                print(
                    'inside ENDPOINT_universities_list catch error:: ${e.toString()}');
              }
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "EditGoalsinterestWidget", context);
      e.toString();
    }
  }

  Future editInterest(addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //  CustomProgressLoader.showLoader(context);

        //await getSelectedData();;
        var finacialSupport = "";
        if  (isFinancialSupportSelected == true){
          if (isYes == true ){
            finacialSupport = "Yes";

          }else if (isNo == true){
            finacialSupport = "No";

          }else{
            finacialSupport = "Notshare";

          }
        }else{
          finacialSupport = null;

        }
        for (var model in selectedLoveInterestsList1) {
          if (model.name.toLowerCase() == 'other') {
            model.otherValue = otherController.text;
          }
        }


        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": 1, //int.parse(roleId),
          "goal_interests":
          selectedLoveInterestsList1.map((item) => item.toJson()).toList(),
          "goalUniversities": selectedUniversityCollegeList
              .map((item) => item.toJson())
              .toList(),

          "major_interests":
          selectedLoveInterestsList.map((item) => item.toJson()).toList(),
          "financialSupport":finacialSupport,

          // "financialSupport": isFinancialSupportSelected ?  isYes
          //     ? "Yes"
          //     : isNo
          //         ? "No"
          //         : "Notshare" : null,

          "needCounselor": isCounselerSupportSelected ? isNeedCounselorYes : null,
          "addIntoProfile": addIntoProfile
        };

        print("map future goal +++" + map.toString());


        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_SKILL_API, map);
        print("response:-" + response.toString());
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                if (widget.studentId != null) {
                  Navigator.pop(context);
                } else {
                  bloc.loadData(userIdPref, context, prefs);
                  Timer _timer = Timer(const Duration(milliseconds: 1000), () {
                    // CustomProgressLoader.cancelLoader(context);
                    Navigator.pop(context);
                    // Navigator.of(context).popUntil((route) => route.isFirst);
                    // Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    //     builder: (BuildContext context) => DashBoardWidget(
                    //         prefs.getString(UserPreference.IS_PARENT_ROLE),
                    //         prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    //         prefs.getString(UserPreference.IS_USER_ROLE)))
                    // );
                  });
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(
              e, "AddEditFutureGoalsWidget", context);
        }



      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEditFutureGoalsWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<String> callLoveInterestApi1() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling().apiCall(context,
            Constant.ENDPOINT_GET_HOBBY_TYPE_API + "goal_interests", "get");
        print("Love Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _skillModel1 = SkillModel.fromJson(response.data);

              if (widget.mProfileInfoModal != null) {
                try {
                  if (widget.mProfileInfoModal.goalInterestsList.length > 0) {
                    for (SkillID _mSkills
                    in widget.mProfileInfoModal.goalInterestsList) {
                      if (_mSkills.hobbyId.toString() == 'null' ||
                          _mSkills.hobbyId.toString() == "") {
                        selectedLoveInterestsList1.add(new SkillData(
                          name: _mSkills.name,
                        ));
                      } else {
                        for (int i = 0;
                        i < _skillModel1.skillList.length;
                        i++) {
                          try {
                            if (_mSkills.hobbyId.toString() ==
                                _skillModel1.skillList[i].hobbyId.toString()) {
                              _skillModel1.skillList[i].isSelected = true;
                              print("other++++"+_mSkills.name+"     "+_mSkills.otherValue);
                              if (_mSkills.name.toLowerCase().contains('other')) {
                                if(_mSkills.otherValue!=null&&_mSkills.otherValue!='null') {
                                  otherController.text = _mSkills.otherValue;
                                }
                              }
                              selectedLoveInterestsList1.add(new SkillData(
                                  hobbyId: _skillModel1.skillList[i].hobbyId,
                                  name: _skillModel1.skillList[i].name,
                                  type: i.toString()));
                            }
                          } catch (e) {
                            crashlytics_bloc.recordCrashlyticsError(
                                e, "EditGoalsinterestWidget", context);
                          }
                        }
                      }
                    }
                  }
                } catch (e) {
                  crashlytics_bloc.recordCrashlyticsError(
                      e, "EditGoalsinterestWidget", context);
                }
              }
              setState(() {
                optionCount = selectedLoveInterestsList1.length;
              });

              //====================================
              //await getUnSelectedList();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "EditGoalsinterestWidget", context);
      e.toString();
    }
  }

  Future<String> apiCallForSkill(context) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GET_SKILL_API + userIdPref + "&roleId=" + roleId,
            "get");
        print("Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widgetSkillModel = SkillIntrestDataModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "EditGoalsinterestWidget", context);
      e.toString();
    }
  }

  void getSaveDataForUniversity() {
    // Fetch already saved and decode data
    print('inside getSaveDataForUniversity() Student');
    final String universityString =
    prefs.getString(UserPreference.UNIVERSITY_LIST);
    if (universityString != '' && universityString != null)
      _universityListUniversity = UniversityResult.decode(universityString);

    // setUniversityData();
  }

  ///

  @override
  void initState() {
    widgetSkillModel = widget._mSkillModel;
    // TODO: implement initState
    try {
      getSharedPreferences();
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddEditFutureGoalsWidget", context);
      print(e.toString());
    }
    super.initState();
  }

  collegeDropdownView1() {
    //shubham
    return Padding(
      padding: const EdgeInsets.only(right: 0.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: bottomBorderDynamic(bottomViewColor),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            showUniversityCollegeList =
                            !showUniversityCollegeList;
                          });
                        },
                        child: Container(
                            padding: const EdgeInsets.only(bottom: 0.0),
                            child:

                            /*
                            CustomFormField(
                              controller: _textFieldControllerAddCollege,
                              // focusNode: fNameNode,
                              textInputType: TextInputType.text,
                              // readOnly: widget.action == RecommendationAction.edit,
                              onType: (value) {
                                print(
                                    'onChanged called... text:: ${_textFieldController.text}');
                                callListSearchCollege();
                              },
                              onSaved: (term) {
                                _textFieldFocusCollege.unfocus();
                                showUniversityCollegeList = false;


                                if (_textFieldControllerAddCollege.text !=
                                    null &&
                                    _textFieldControllerAddCollege.text
                                        .trim() !=
                                        "") {
                                  //if (!findPersonUsingWhere(_textFieldControllerAddCollege.text)) {

                                  List<UniversityResult> _searched =
                                  _universityCollegeList
                                      .where((food) => food.name
                                      .toLowerCase()
                                      .startsWith(
                                      _textFieldControllerAddCollege
                                          .text
                                          .toLowerCase()))
                                      .toList();

                                  List<UniversityResult> _searchedSelected =
                                  selectedUniversityCollegeList
                                      .where((food) => food.name
                                      .toLowerCase()
                                      .startsWith(
                                      _textFieldControllerAddCollege
                                          .text
                                          .toLowerCase()))
                                      .toList();

                                  //  if (_searched.length==0){

                                  if (_searchedSelected.length == 0 ||
                                      _searchedSelected.isEmpty) {
                                    selectedUniversityCollegeOption.add(
                                        GoalUniversity(
                                            name:
                                            _textFieldControllerAddCollege
                                                .text,
                                            universityId: ''));
                                    selectedUniversityCollegeList.add(
                                        UniversityResult(
                                            universityId: '',
                                            name:
                                            _textFieldControllerAddCollege
                                                .text
                                                .trim()));
                                    removedUniversiyCollegeList.add(
                                        UniversityResult(
                                            universityId: '',
                                            name:
                                            _textFieldControllerAddCollege
                                                .text
                                                .trim()));
                                  } else {
                                    _textFieldControllerAddCollege.clear();
                                  }
                                  /* }else {
                                      ToastWrap.showToast(MessageConstant.ALREADY_ORGANIZATION_ADDEDD, context);
                                    }*/

                                }

                                //  }

                                _textFieldControllerAddCollege.clear();

                                setState(() {
                                  selectedUniversityCollegeOption;
                                  selectedUniversityCollegeList;
                                  _universityCollegeList;
                                  //_searchedUniversityCollegeList = _universityCollegeList;
                                  _searchedUniversityCollegeList.clear();
                                  _searchedUniversityCollegeList.addAll(
                                      _universityCollegeList.sublist(0, 10));
                                  listIndexFromCollege = 10;
                                  showUniversityCollegeList = false;
                                });
                              },

                              label: "Select colleges",
                              //  hint: "Search issuer",
                              alignLabelWithHint: true,
                              // validation: (val) => val.trim().length == 0
                              //     ? MessageConstant.ENTER_FIRST_NAME_VAL
                              //     : !ValidationWidget.isName(val)
                              //     ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                              //     : null,
                            ),
                                */



                            TextField(
                                controller: _textFieldControllerAddCollege,
                                style: TextStyle(
                                    fontFamily: Constant.latoRegular,
                                    color: _textFieldFocusCollege.hasFocus
                                        ? ColorValues
                                        .HEADING_COLOR_EDUCATION_1 // Set text color to blue when focused
                                        : ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.w500),
                                //autofocus: true,
                                onChanged: (value) {
                                  print(
                                      'onChanged called... text:: ${_textFieldController.text}');
                                  callListSearchCollege();
                                },
                                onEditingComplete: () {
                                  setState(() {});
                                },

                                textInputAction: TextInputAction.done,
                                focusNode: _textFieldFocusCollege,
                                autocorrect: false,

                                onSubmitted: (term) {
                                  _textFieldFocusCollege.unfocus();
                                  showUniversityCollegeList = false;


                                  if (_textFieldControllerAddCollege.text !=
                                      null &&
                                      _textFieldControllerAddCollege.text
                                          .trim() !=
                                          "") {
                                    //if (!findPersonUsingWhere(_textFieldControllerAddCollege.text)) {

                                    List<UniversityResult> _searched =
                                    _universityCollegeList
                                        .where((food) => food.name
                                        .toLowerCase()
                                        .startsWith(
                                        _textFieldControllerAddCollege
                                            .text
                                            .toLowerCase()))
                                        .toList();

                                    List<UniversityResult> _searchedSelected =
                                    selectedUniversityCollegeList
                                        .where((food) => food.name
                                        .toLowerCase()
                                        .startsWith(
                                        _textFieldControllerAddCollege
                                            .text
                                            .toLowerCase()))
                                        .toList();

                                    //  if (_searched.length==0){

                                    if (_searchedSelected.length == 0 ||
                                        _searchedSelected.isEmpty) {
                                      selectedUniversityCollegeOption.add(
                                          GoalUniversity(
                                              name:
                                              _textFieldControllerAddCollege
                                                  .text,
                                              universityId: ''));
                                      selectedUniversityCollegeList.add(
                                          UniversityResult(
                                              universityId: '',
                                              name:
                                              _textFieldControllerAddCollege
                                                  .text
                                                  .trim()));
                                      removedUniversiyCollegeList.add(
                                          UniversityResult(
                                              universityId: '',
                                              name:
                                              _textFieldControllerAddCollege
                                                  .text
                                                  .trim()));
                                    } else {
                                      _textFieldControllerAddCollege.clear();
                                    }
                                    /* }else {
                                      ToastWrap.showToast(MessageConstant.ALREADY_ORGANIZATION_ADDEDD, context);
                                    }*/

                                  }

                                  //  }

                                  _textFieldControllerAddCollege.clear();

                                  setState(() {
                                    selectedUniversityCollegeOption;
                                    selectedUniversityCollegeList;
                                    _universityCollegeList;
                                    //_searchedUniversityCollegeList = _universityCollegeList;
                                    _searchedUniversityCollegeList.clear();
                                    _searchedUniversityCollegeList.addAll(
                                        _universityCollegeList.sublist(0, 10));
                                    listIndexFromCollege = 10;
                                    showUniversityCollegeList = false;
                                  });
                                },
                                cursorColor:
                                ColorValues.HEADING_COLOR_EDUCATION_2,
                                decoration: InputDecoration(
                                  focusColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_2,
                                  contentPadding: const EdgeInsets.fromLTRB(
                                      0.0, 5.0, 5.0, 5.0),
                                  border: InputBorder.none,
                                  hintText:"Add college",
                                  /*hintText:
                                      selectedUniversityOption //spikeViewUserList //selectedUniversityOption
                                                  .length ==
                                              0
                                          ? 'Add colleges'
                                          //: "",
                                  : '${selectedUniversityOption[selectedUniversityOption.length - 1]}',*/
//                                   suffixIconConstraints: BoxConstraints(
//                                       minHeight: 30, minWidth: 30),
//                                   suffixIcon: Padding(
//                                     padding: const EdgeInsets.only(
//                                         left: 15.0, top: 0),
//                                     child: Icon(
//                                       Icons.keyboard_arrow_down,
//                                       color: ColorValues.labelColor,
//                                       size: 30,
//                                     ),
// //shubham
//                                   )
                                  // Image.asset('assets/newDesignIcon/icons/ic_dropdown.jpg',
                                  //     fit: BoxFit.contain,


                                  // Replace 'my_icon.png' with your asset image path

                                  labelText: "Select colleges",
                                  labelStyle: TextStyle(
                                      fontSize: 18.0,
                                      color:
                                      ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      fontWeight: FontWeight.w500),
                                ))

                        ),



                      ),
                    ),

                    IconButton(
                      onPressed: () {

                        _textFieldControllerAddCollege.clear();

                        _universityCollegeList.clear();
                        showUniversityCollegeList = false;
                        isScroled = true;
                        _searchedUniversityCollegeList.clear();
                        setState(() {

                        });


                      },
                      icon: Padding(
                        padding: const EdgeInsets.only(left: 10.0, top: 0),
                        child: Icon(showUniversityCollegeList
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down,
                            color: ColorValues.labelColor,
                            size: 30),

                      ),
                    ),
                  ],
                ),





                /*selectedUniversityOption.length > 0
                              ? selectOtherCategoryTextField()
                              : Container(),*/
              ],
            ),
          ),
          _universityCollegeList != null && _universityCollegeList.length > 0
              ? universityCollegeListWidget()
              : Container(),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    //-------------------------------------Main Ui ------------------------------------------
    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, popString);
        },
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: Colors.white,
              body: Stack(
                children: <Widget>[
                  Container(
                    height: double.infinity,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(
                                "assets/generateScript/script_background.png"),
                            fit: BoxFit.fill)),
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.only(top: 40, left: 20, right: 20),
                    child: SizedBox(
                      height: 103,
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              Navigator.pop(context, 'back');
                            },
                            child: Image.asset(
                              "assets/generateScript/back.png",
                              height: 32.0,
                              width: 32.0,
                            ),
                          ),
                          const HelpButtonWidget(),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        ),
                      ),
                      margin: const EdgeInsets.only(top: 115),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Expanded(
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(30),
                                    topRight: Radius.circular(30),
                                  ),
                                ),
                                child: Column(

                                  children: <Widget>[
                                    const SizedBox(height: 18),


                                    Align(
                                        alignment: Alignment.topLeft,
                                        child: BaseText(
                                          text: "Future goals",
                                          textColor:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                          fontFamily:
                                          AppConstants.stringConstant.latoMedium,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 28,
                                          maxLines: 1,
                                        )),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Align(
                                        alignment: Alignment.topLeft,
                                        child: BaseText(
                                          text: "What's next after high school?",
                                          textColor:
                                          AppConstants.colorStyle.lightPurple,
                                          fontFamily:
                                          AppConstants.stringConstant.latoMedium,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                          maxLines: 2,
                                        )),

                                    SizedBox(
                                      height: 14,
                                    ),

                                    Expanded(
                                      child: ListView(

                                        padding: EdgeInsets.zero,

                                        controller: _scrollController,
                                        children: <Widget>[
                                          Form(
                                            key: _formKey,
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 0.0, left: 0.0),

                                              child: Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                children: <Widget>[


                                                  Padding(
                                                    padding:
                                                    const EdgeInsets.only(
                                                        left: 0.0),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      children: <Widget>[


                                                        Container(
                                                          height: 0.0,
                                                        ),

                                                        getUserInterestSelectedChips1(
                                                            selectedLoveInterestsList1,
                                                            true),

                                                        _skillModel1 != null
                                                            ? getUserInterestChips(
                                                            _skillModel1
                                                                .skillList,
                                                            false)
                                                            : Container(
                                                          height: 0.0,
                                                        ),
                                                      ],
                                                    ),
                                                  ),




                                                  selectedLoveInterestsList1.any((item) =>
                                                      item.name
                                                          .toLowerCase()
                                                          .contains('other'))
                                                      ?  Padding(
                                                        padding: const EdgeInsets.only(top:10.0,bottom: 10),
                                                        child: CustomFormField(
                                                    autovalidateMode: AutovalidateMode.disabled,
                                                    textInputType: TextInputType.text,
                                                    controller: otherController,
                                                    maxLength: 15,
                                                    onType: (val) {
                                                        setState(() {});
                                                    },
                                                    label: 'Other',
                                                    validation: (val) => val
                                                          .trim()
                                                          .isEmpty
                                                          ? MessageConstant
                                                          .ENTER_Other_VAL
                                                          : null,
                                                  ),
                                                      )
                                                      : Container(height: 0.0),


                                                  selectedLoveInterestsList1
                                                      .any((item) => item
                                                      .name
                                                      .toLowerCase()
                                                      .contains('year'))
                                                      ? Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .only(
                                                        left: 0.0),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      children: <Widget>[
                                                        collegeDropdownView1(),
                                                        selectedUniversityCollegeOption !=
                                                            null &&
                                                            selectedUniversityCollegeOption
                                                                .length >
                                                                0
                                                            ? Padding(
                                                            padding: const EdgeInsets
                                                                .only(
                                                                top:
                                                                5.0),
                                                            child: getUniversityCollegeSelectedChips(
                                                                selectedUniversityCollegeList,
                                                                true))
                                                            : Container(
                                                          width: 0,
                                                          height: 0,
                                                        ),
                                                        Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              left:
                                                              0.0,
                                                              top:
                                                              15),
                                                          child: Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                            children: <
                                                                Widget>[
                                                              _skillModel !=
                                                                  null
                                                                  ? collegeDropdownView()
                                                                  : Container(
                                                                height:
                                                                0.0,
                                                              ),
                                                              selectedLoveInterestsList !=
                                                                  null &&
                                                                  selectedLoveInterestsList.length >
                                                                      0
                                                                  ? Padding(
                                                                  padding:
                                                                  const EdgeInsets.only(top: 5.0),
                                                                  child: getMajorInterestSelectedChips(selectedLoveInterestsList, true))
                                                                  : Container(
                                                                width:
                                                                0,
                                                                height:
                                                                0,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          height: 15.0,
                                                        ),
                                                        Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              left:
                                                              0.0),
                                                          child: Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[

                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  15.0,
                                                                  0.0,
                                                                  15.0,

                                                                  Text(
                                                                    "Do you need financial support?",overflow: TextOverflow.ellipsis,maxLines:3,
                                                                    textAlign:  TextAlign.start,
                                                                    style:  TextStyle(
                                                                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 18,
                                                                        fontFamily: Constant.latoRegular),
                                                                  )),




                                                              Column(
                                                                // crossAxisAlignment:
                                                                // CrossAxisAlignment.center,
                                                                mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                                children: <
                                                                    Widget>[
                                                                  InkWell(
                                                                    child:
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment.center,
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        Image.asset(isYes ? "assets/future_goals/future_check.png" : "assets/future_goals/future_Uncheck.png", height: 20, width: 20),
                                                                        Padding(
                                                                          padding: const EdgeInsets.only(left: 10.0),
                                                                          child: Text(
                                                                            "Yes",
                                                                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, fontFamily: Constant.latoRegular, color: ColorValues.labelColor),
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap:
                                                                        () {
                                                                      setState(() {
                                                                        isFinancialSupportSelected = true;

                                                                        isYes = true;
                                                                        isNo = false;
                                                                        isNotShare = false;
                                                                      });
                                                                    },
                                                                  ),
                                                                  Container(
                                                                    width:
                                                                    11,
                                                                    height:
                                                                    10,
                                                                  ),
                                                                  InkWell(
                                                                    child:
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment.center,
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        Image.asset(isNo ? "assets/future_goals/future_check.png" : "assets/future_goals/future_Uncheck.png", height: 20, width: 20),
                                                                        Padding(
                                                                          padding: const EdgeInsets.only(left: 10.0),
                                                                          child: Text(
                                                                            "No",
                                                                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, fontFamily: Constant.latoRegular, color: ColorValues.labelColor),
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap:
                                                                        () {
                                                                      setState(() {
                                                                        isFinancialSupportSelected = true;

                                                                        isYes = false;
                                                                        isNo = true;
                                                                        isNotShare = false;
                                                                      });
                                                                    },
                                                                  ),
                                                                  Container(
                                                                    width:
                                                                    11,
                                                                    height:
                                                                    10,
                                                                  ),
                                                                  InkWell(
                                                                    child:
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment.center,
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        Image.asset(isNotShare ? "assets/future_goals/future_check.png" : "assets/future_goals/future_Uncheck.png", height: 20, width: 20),
                                                                        Padding(
                                                                          padding: const EdgeInsets.only(left: 10.0),
                                                                          child: Text(
                                                                            "Don't want to share",
                                                                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, fontFamily: Constant.latoRegular, color: ColorValues.labelColor),
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap:
                                                                        () {
                                                                      setState(() {

                                                                        isFinancialSupportSelected = true;
                                                                        isYes = false;
                                                                        isNo = false;
                                                                        isNotShare = true;
                                                                      });
                                                                    },
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          height: 15.0,
                                                        ),
                                                        Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                            left: 0.0,
                                                          ),
                                                          child: Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[

                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  15.0,
                                                                  0.0,
                                                                  15.0,

                                                                  Text(
                                                                    "Do you need counselor support?",overflow: TextOverflow.ellipsis,maxLines:3,
                                                                    textAlign:  TextAlign.start,
                                                                    style:  TextStyle(
                                                                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                                                        fontWeight: FontWeight.w500,
                                                                        fontSize: 18,
                                                                        fontFamily: Constant.latoRegular),
                                                                  )),





                                                              Column(
                                                                // crossAxisAlignment:
                                                                // CrossAxisAlignment.center,
                                                                mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                                children: <
                                                                    Widget>[
                                                                  InkWell(
                                                                    child:
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment.center,
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        Image.asset(isNeedCounselorYes ? "assets/future_goals/future_check.png" : "assets/future_goals/future_Uncheck.png", height: 20, width: 20),
                                                                        Padding(
                                                                          padding: const EdgeInsets.only(left: 10.0),
                                                                          child: Text(
                                                                            "Yes",
                                                                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, fontFamily: Constant.latoRegular, color: ColorValues.labelColor),
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap:
                                                                        () {
                                                                      setState(() {
                                                                        isCounselerSupportSelected = true;

                                                                        isNeedCounselorYes = true;
                                                                        isNeedCounselorNo = false;
                                                                      });
                                                                    },
                                                                  ),
                                                                  Container(
                                                                    width:
                                                                    11,
                                                                    height:
                                                                    10,
                                                                  ),
                                                                  InkWell(
                                                                    child:
                                                                    Row(
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment.center,
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.start,
                                                                      children: <Widget>[
                                                                        Image.asset(isNeedCounselorNo ? "assets/future_goals/future_check.png" : "assets/future_goals/future_Uncheck.png", height: 20, width: 20),
                                                                        Padding(
                                                                          padding: const EdgeInsets.only(left: 10.0),
                                                                          child: Text(
                                                                            "No",
                                                                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, fontFamily: Constant.latoRegular, color: ColorValues.labelColor),
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                    onTap:
                                                                        () {
                                                                      setState(() {
                                                                        isCounselerSupportSelected = true;

                                                                        isNeedCounselorYes = false;
                                                                        isNeedCounselorNo = true;
                                                                      });
                                                                    },
                                                                  ),
                                                                ],
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                                      : Container(height: 0.0),
                                                ],
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 20,
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              bottomNavigationBar: Container(
                color: Colors.white,
                height: 44,
                margin: const EdgeInsets.fromLTRB(20, 30, 20, 25),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      flex: 63,
                      child: PositiveButton(
                        onTap: () => _positiveButtonTap(),
                        isEnable: true,
                        title: widget.isFirstTimeCalling ? 'Add' : 'Update',
                      ),
                    ),
                  ],
                ),
              ),
            )));
  }

  String formatString(String input) {
    List<String> words = input.toLowerCase().split(' ');
    String formattedString = words.map((word) {
      if (word.isNotEmpty) {
        return '${word[0].toUpperCase()}${word.substring(1)}';
      }
      return '';
    }).join(' ');

    return formattedString;
  }

  getUserInterestSelectedChips1(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 5.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(
              _items.length,
                  (int index) {
                return Padding(
                    padding: const EdgeInsets.only(top: 5,bottom: 5,right: 5,left: 2),
                    child: Container(
                      decoration: BoxDecoration(
                        color: isSelected == true
                            ? ColorValues.DARK_YELLOW
                            : ColorValues.TAB_BACKGROUND_COLOR,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10,right: 10,top: 5,bottom: 5),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            InkWell(
                              onTap: () {
                                // Handle selection here
                                print('Selected: ${_items[index].name}');
                                toggalSelection1(isSelected, index);
                              },
                              child: Text(
                                '${_items[index].name}',
                                style: TextStyle(
                                  fontSize: 16.0,
                                  fontFamily: Constant.latoRegular,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ));
              },
            ).toList(),
          ),
        ],
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }

  getUniversitySelectedChips1(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 5.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(
                _items.length, // place the length of the array here
                    (int index) {
                  return Padding(
                      padding: const EdgeInsets.only(top: 5.0),
                      child: InputChip(
                        label: Container(
                          padding: const EdgeInsets.all(0.0),
                          //color: Colors.red,
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width - 113,
                          ),

                          child: Text(
                            '${_items[index].name}',
                            maxLines: 4,
                            softWrap: true,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                        shape: StadiumBorder(
                          side: BorderSide(
                              color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                        ),
                        onSelected: (bool value) {},
                        deleteIcon: Icon(
                          Icons.clear,
                          color: ColorValues.WHITE,
                          size: 16.0,
                        ),
                        onDeleted: () {
                          print("selected index:: $index");
                          updateList(_items[index], index);
                        },
                        labelStyle: TextStyle(
                          color: ColorValues.WHITE,
                          fontSize: 16,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12.0, vertical: 3.0),
                      ));
                }).toList(),
          ),
        ],
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }

  getUserInterestSelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 5.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(
                _items.length, // place the length of the array here
                    (int index) {
                  return Container(
                    decoration: BoxDecoration(
                      color: isSelected == true
                          ? ColorValues.DARK_YELLOW
                          : ColorValues.TAB_BACKGROUND_COLOR,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          InkWell(
                            onTap: () {
                              // Handle selection here
                              print('Selected: ${_items[index].name}');
                            },
                            child: Text(
                              '${_items[index].name}',
                              style: TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.latoRegular,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 2, left: 3),
                            child: InkWell(
                              onTap: () {
                                // Handle deletion here
                                print('Deleted: ${_items[index].name}');

                                print("selected index:: $index");
                                toggalSelection(isSelected, index);
                              },
                              child: Icon(
                                Icons.clear,
                                color: Colors.white,
                                size: 16.0,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
          ),
        ],
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }

  void toggalSelection(bool isSelected, int index) {
    if (isSelected) {
      //add item to unselected list and remove from selected list
      SkillData item = selectedLoveInterestsList[index];
      if (item.type != null && item.type != "") {
        _skillModel.skillList[int.parse(item.type)].isSelected = false;
      }
      selectedLoveInterestsList.removeAt(index);
      setState(() {});
    } else {
      //add item to selected list and remove from unselected list
      _skillModel.skillList[index].isSelected = true;
      selectedLoveInterestsList.add(new SkillData(
          hobbyId: _skillModel.skillList[index].hobbyId,
          name: _skillModel.skillList[index].name,
          type: index.toString()));

      setState(() {});
    }
    setState(() {
      optionCount = selectedLoveInterestsList.length;
      if (optionCount == 0) instituteController.text = '';
    });
  }

  void toggalSelection1(bool isSelected, int index) {
    if (isSelected) {
      //add item to unselected list and remove from selected list
      SkillData item = selectedLoveInterestsList1[index];
      if (item.type != null && item.type != "") {
        _skillModel1.skillList[int.parse(item.type)].isSelected = false;
      }
      selectedLoveInterestsList1.removeAt(index);
      setState(() {});
    } else {
      //add item to selected list and remove from unselected list
      _skillModel1.skillList[index].isSelected = true;
      selectedLoveInterestsList1.add(new SkillData(
          hobbyId: _skillModel1.skillList[index].hobbyId,
          name: _skillModel1.skillList[index].name,
          type: index.toString()));

      setState(() {});
    }
    setState(() {
      optionCount = selectedLoveInterestsList1.length;
      if (optionCount == 0) instituteController.text = '';
    });
  }

  getMajorInterestSelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 5.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(
                _items.length, // place the length of the array here
                    (int index) {
                  return Padding(
                      padding: const EdgeInsets.only(top: 5,bottom: 5,right: 5,left: 2),

                      child: Container(
                        decoration: BoxDecoration(
                          color: isSelected == true
                              ? ColorValues.DARK_YELLOW
                              : ColorValues.TAB_BACKGROUND_COLOR,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(top: 6,bottom: 6,right: 10,left: 10),

                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${_items[index].name}');
                                  },
                                  child: Text(
                                    '${_items[index].name}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here
                                    print('Deleted: ${_items[index].name}');
                                    print("selected index:: $index");
                                    updateList(_items[index], index);
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));
                }).toList(),
          ),
        ],
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }

  getUserInterestChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 0.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(
                _items.length, // place the length of the array here
                    (int index) {
                  return _items[index].isSelected && !isSelected
                      ? Container(
                    height: 0.0,
                    width: 0.0,
                  )
                      : Padding(
                      padding: const EdgeInsets.only(top: 5,bottom: 5,right: 5,left: 2),
                      child: Container(
                        decoration: BoxDecoration(
                          color: isSelected == true
                              ? ColorValues.DARK_YELLOW
                              : ColorValues.TAB_BACKGROUND_COLOR,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10,right: 10,top: 5,bottom: 5),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              InkWell(
                                onTap: () {
                                  if (!isSelected) {
                                    //print("selected index:: $index");
                                    toggalSelection1(isSelected, index);
                                  }
                                },
                                child: Text(
                                  '${_items[index].name}',
                                  style: TextStyle(
                                    fontSize: 16.0,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));
                }).toList(),
          ),
        ],
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }

  //shubham
  collegeDropdownView() {
    return Padding(
      padding: const EdgeInsets.only(right: 0.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: bottomBorderDynamic(bottomViewColor),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              showList = !showList;
                            });
                          },
                          child: TextField(
                              controller: _textFieldController,
                              //autofocus: true,
                              onChanged: (value) {
                                //print('onChanged called... text:: ${_textFieldController.text}');
                                callListSearch();
                              },
                              style: TextStyle(
                                  fontFamily: Constant.latoRegular,
                                  color: _textFieldFocus.hasFocus
                                      ? ColorValues
                                      .HEADING_COLOR_EDUCATION_2 // Set text color to blue when focused
                                      : ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.w500),
                              onEditingComplete: () {
                                setState(() {});
                              },
                              textInputAction: TextInputAction.done,
                              focusNode: _textFieldFocus,
                              autocorrect: false,
                              onSubmitted: (term) {
                                _textFieldFocus.unfocus();
                                _textFieldController.text =
                                    _textFieldController.text.trim();

                                if (_textFieldController.text != null &&
                                    _textFieldController.text != "") {
                                  List<SkillData> _searchedSelected =
                                  selectedLoveInterestsList
                                      .where((food) => food.name
                                      .toLowerCase()
                                      .startsWith(_textFieldController
                                      .text
                                      .trim()
                                      .toLowerCase()))
                                      .toList();
                                  if (_searchedSelected.length == 0 ||
                                      _searchedSelected.isEmpty) {
                                    if (!findPersonUsingWhere(
                                        _textFieldController.text.trim())) {
                                      selectedUniversityOption.add(
                                          _textFieldController.text.trim());
                                      selectedLoveInterestsList.add(SkillData(
                                          name: _textFieldController.text
                                              .trim()));
                                      //removedUniversiyList.add(SkillData(name: _textFieldController.text.trim()));
                                    }
                                  }
                                }
                                _textFieldController.clear();
                                setState(() {
                                  _searchedUniversityList = _universityList;
                                  showList = false;
                                });
                              },
                              cursorColor:
                              ColorValues.HEADING_COLOR_EDUCATION_2,
                              decoration: InputDecoration(
                                contentPadding: const EdgeInsets.fromLTRB(
                                    0.0, 5.0, 5.0, 5.0),
                                border: InputBorder.none,
                                suffixIconConstraints:
                                BoxConstraints(minHeight: 35, minWidth: 35),
                                labelText: "What do you want to study (major)?",

                                labelStyle: TextStyle(
                                    fontSize: 18.0,
                                    color:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontWeight: FontWeight.w500),
                              ))),
                    ),
                    IconButton(
                      onPressed: () {
                        showList = !showList;
                        setState(() {});
                      },
                      icon: Padding(
                        padding: const EdgeInsets.only(left: 10.0, top: 0),
                        child: Icon(
                          showList
                              ? Icons.keyboard_arrow_up
                              : Icons.keyboard_arrow_down,
                          color: ColorValues.labelColor,
                          size: 30,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          _skillModel.skillList != null && _skillModel.skillList.length > 0

              ? universityListWidget()
              : Container(),
        ],
      ),
    );
  }

  universityListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? _searchedUniversityList.length > 0
            ? Card(
          elevation: 4, // Add elevation to create a shadow

          child: Container(
            height: _searchedUniversityList.length == 1
                ? 70.0
                : _searchedUniversityList.length == 2
                ? 130.0
                : _searchedUniversityList.length == 3
                ? 210
                : 250.0,
            padding: _searchedUniversityList.length > 0
                ? EdgeInsets.all(10)
                : EdgeInsets.all(0),
            child: ListView.builder(
              padding: EdgeInsets.zero,
              //controller: controller,
              key: _listKey,
              itemCount: _searchedUniversityList.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return _searchedUniversityList[index].isSelected
                    ? Container(
                  width: 0,
                  height: 0,
                )
                    : _buildAddedItem(
                    _searchedUniversityList[index], index);
              },
            ),
          ),
        )
            : Container()
            : Container(),
      ],
    );
  }

  Widget _buildAddedItemCollege(
      BuildContext context, UniversityResult item, int index) {
    return item.name != null
        ? Padding(
      padding: const EdgeInsets.only(top: 5, bottom: 3),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: ColorValues.TAB_BACKGROUND_COLOR,
          border: Border.all(
            color: ColorValues.BORDER_COLOR_NEW, // Border color
            width: 1.0, // Border width
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: InkWell(
            onTap: () {
              print("item++++" + item.name);
              onListItemTapCollege(item);
            },
            child: AnimatedContainer(
              curve: Curves.easeIn,
              duration: Duration(milliseconds: 500),
              width: MediaQuery.of(context).size.width,
              child: Text(item.name,
                  style: TextStyle(
                      fontFamily: Constant.latoRegular,
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: ColorValues.HEADING_COLOR_EDUCATION_1)),
              padding: EdgeInsets.all(8),
            ),
          ),
        ),
      ),
    )
        : Container(
      width: 0,
      height: 0,
    );
  }

  //shubham search
  void onListItemTapCollege(UniversityResult item) {
    _textFieldFocusCollege.unfocus();
    removedUniversiyCollegeList.add(item);

    selectedUniversityCollegeList.add(
        UniversityResult(name: item.name, universityId: item.universityId));

    selectedUniversityCollegeOption
        .add(GoalUniversity(name: item.name, universityId: item.universityId));

    if (_universityCollegeList.length > 0) {
      _searchedUniversityCollegeList.remove(item);
      _universityCollegeList.remove(item);
    }
    showUniversityCollegeList = !showUniversityCollegeList;
    _textFieldControllerAddCollege.text = '';
    //_searchedUniversityCollegeList = _universityCollegeList;
    _searchedUniversityCollegeList.clear();

    _searchedUniversityCollegeList
        .addAll(_universityCollegeList.sublist(0, 10));

    listIndexFromCollege = 10;
    setState(() {
      bottomViewColor = Palette.dividerColor;
    });
  }

  Widget _buildAddedItem(SkillData item, int index) {
    return item.name != null
        ? Padding(
      padding: const EdgeInsets.only(top: 5, bottom: 3),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: ColorValues.TAB_BACKGROUND_COLOR,
          border: Border.all(
            color: ColorValues.BORDER_COLOR_NEW, // Border color
            width: 1.0, // Border width
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(4.0),
          child: InkWell(
            onTap: () {
              print("item++++" + item.name);
              //toggalSelection(false, index);
              onListItemTap(item);
            },
            child: AnimatedContainer(
              curve: Curves.easeIn,
              duration: Duration(milliseconds: 500),
              width: MediaQuery.of(context).size.width,
              child: Text(item.name,
                  style: TextStyle(
                      fontFamily: Constant.latoRegular,
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: ColorValues.HEADING_COLOR_EDUCATION_1)),
              padding: EdgeInsets.all(8),
            ),
          ),
        ),
      ),
    )
        : Container(
      width: 0,
      height: 0,
    );
  }

  List<UniversityResult> callListSearchCollege() {
    if (_textFieldControllerAddCollege.text.isEmpty) {
      setState(() {
        _universityCollegeList.clear();
        showUniversityCollegeList = false;
        isScroled = true;
        _searchedUniversityCollegeList.clear();
      });
    } else {
      if (_textFieldControllerAddCollege.text.trim().length > 1) {
        if (_timer != null) {
          print("data++++++timer cancel");
          _timer.cancel();
        }
        _timer = Timer(const Duration(milliseconds: 700), () {
          showUniversityCollegeList = true;

          callCollegeListApi(_textFieldControllerAddCollege.text.trim());
        });
      }
    }

    setState(() {
      showUniversityCollegeList = true;
    });

    print("shubh text++");
    if (isScroled && _searchedUniversityCollegeList.length > 0) {
      isScroled = false;
      _scrollController.jumpTo((_scrollController.offset + 200.0));
    } else {
      // isScroled=true;
    }

    return _searchedUniversityCollegeList;
  }

  List<SkillData> callListSearch() {
    print(
        'inside callListSearch() search text::: ${_textFieldController.text.trim()}');

    showList = false;

    if (_textFieldController.text.trim() != '') {
      _searchedUniversityList = _skillModel.skillList
          .where((food) => food.name
          .toLowerCase()
          .startsWith(_textFieldController.text.toLowerCase()))
          .toList();
    } else {
      _searchedUniversityList = _skillModel.skillList;
    }
    setState(() {
      showList = true;
    });

    if (isScroled && _searchedUniversityList.length > 0) {
      isScroled = false;
      _scrollController.jumpTo((_scrollController.offset + 200.0));
    } else {
      // isScroled=true;
    }

    return _searchedUniversityList;
  }

  bool findPersonUsingWhere(String personName) {
    // Return list of people matching the condition
    final foundPeople = selectedLoveInterestsList
        .where((element) => element.name == personName);

    if (foundPeople.isNotEmpty) {
      print('Using where: ${foundPeople.first}');
      return true;
    } else
      return false;
  }

  void onListItemTap(SkillData item) {
    _textFieldFocus.unfocus();
    removedUniversiyList.add(item);
    selectedLoveInterestsList.add(
        SkillData(name: item.name, hobbyId: item.hobbyId, type: item.type));

    selectedUniversityOption.add(item.name);
    if (_universityList.length > 0) {
      _searchedUniversityList.remove(item);
      _universityList.remove(item);
    }
    showList = !showList;
    _textFieldController.text = '';
    //
    _searchedUniversityList = _universityList;
    /*_searchedUniversityList.clear();
    _searchedUniversityList.addAll(_skillModel.skillList.sublist(0, 10));
    listIndexFrom = 10;*/
    setState(() {
      bottomViewColor = Palette.dividerColor;
    });
  }

  void updateList(SkillData item, int index) {
    print('inside updateList');
    int indexR = 0;

    for (int i = 0; i < removedUniversiyList.length; i++) {
      if (item.name == removedUniversiyList[i].name && item.hobbyId != "") {
        _universityList.add(removedUniversiyList[i]);
        indexR = i;
      }
    }

    if (item.hobbyId != null && item.hobbyId != "") {
      removedUniversiyList.removeAt(indexR);
    }

    //removedUniversiyList.removeAt(index);
    selectedLoveInterestsList.removeAt(index);
    selectedUniversityOption.removeAt(index);
    setState(() {
      if (showList) showList = !showList;
    });
  }

  void updateListCollege(UniversityResult item, int index) {
    selectedUniversityCollegeList.removeAt(index);

    setState(() {
      if (showUniversityCollegeList)
        showUniversityCollegeList = !showUniversityCollegeList;
    });

    /// old before pagination
  }

  universityCollegeListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showUniversityCollegeList
            ? _searchedUniversityCollegeList.length > 0
            ? Card(
          elevation: 4, // Add elevation to create a shadow

          child: Container(

            // decoration: const BoxDecoration(
            //   color: Colors.white,
            //   borderRadius: BorderRadius.all(
            //     Radius.circular(2),
            //   ),
            //   boxShadow: [
            //     BoxShadow(
            //       color: Color(0xffDDDDDD),
            //       blurRadius: 3.0,
            //       spreadRadius: 3.0,
            //       offset: Offset(0.0, 0.0),
            //     )
            //   ],
            // ),

            height: _searchedUniversityCollegeList.length == 1
                ? 70.0
                : _searchedUniversityCollegeList.length == 2
                ? 130.0
                : _searchedUniversityCollegeList.length == 3
                ? 200
                : 250.0,
            padding: _searchedUniversityCollegeList.length > 0
                ? EdgeInsets.all(10)
                : EdgeInsets.all(0),
            child: RefreshIndicator(
              onRefresh: onRefreshPending,
              child: ListView.builder(
                  physics: AlwaysScrollableScrollPhysics(),
                  controller: _scrollControllerCollection,
                  padding: EdgeInsets.zero,
                  // controller: controller,
                  key: _listKey,
                  //initialItemCount: _searchedUniversityCollegeList.length,
                  shrinkWrap: true,
                  itemCount: _searchedUniversityCollegeList.length,
                  itemBuilder: (BuildContext context, int index) {
                    positionOfCollection = index;
                    return _searchedUniversityCollegeList.length >=
                        index
                        ? _buildAddedItemCollege(
                        context,
                        _searchedUniversityCollegeList[index],
                        index)
                        : Container(
                      width: 0,
                      height: 0,
                    );
                  }),
            ),
          ),
        )
            : Container()
            : Container()
      ],
    );
  }

  getUniversityCollegeSelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
      context: context,
      removeTop: true,
      removeBottom: true,
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        primary: true,
        shrinkWrap: true,
        children: <Widget>[
          Wrap(
            spacing: 5.0,
            runSpacing: 0.0,
            children: List<Widget>.generate(
                _items.length, // place the length of the array here
                    (int index) {
                  return Padding(
                      padding: const EdgeInsets.only(top: 5,bottom: 5,right: 5,left: 2),

                      child: Container(
                        decoration: BoxDecoration(
                          color: isSelected == true
                              ? ColorValues.DARK_YELLOW
                              : ColorValues.TAB_BACKGROUND_COLOR,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10,right: 10,top: 6,bottom: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Flexible(
                                child: InkWell(
                                  onTap: () {
                                    // Handle selection here
                                    print('Selected: ${_items[index].name}');
                                  },
                                  child: Text(
                                    '${_items[index].name}',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                    // maxLines: 1,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 2, left: 3),
                                child: InkWell(
                                  onTap: () {
                                    // Handle deletion here
                                    print('Deleted: ${_items[index].name}');
                                    print("selected index:: $index");
                                    updateListCollege(_items[index], index);
                                  },
                                  child: Icon(
                                    Icons.clear,
                                    color: Colors.white,
                                    size: 16.0,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ));
                }).toList(),
          ),
        ],
      ),
    )
        : Container(
      height: 0,
      width: 0,
    );
  }
}
