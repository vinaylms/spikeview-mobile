import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

// Create a Form Widget
class EditTestScoreWidget extends StatefulWidget {
  TestDataModel testDatModel;
String userId;
  EditTestScoreWidget(this.testDatModel,this.userId);

  @override
  EditTestScoreWidgetState createState() {
    return     EditTestScoreWidgetState(testDatModel);
  }
}

class EditTestScoreWidgetState extends State<EditTestScoreWidget> {
  EditTestScoreWidgetState(this.testDatModel);

  String strPrefixPathOrganization;
  SharedPreferences prefs;
  String userIdPref, sasToken, containerName;
  TestDataModel testDatModel;
  TextEditingController dobController;
  int strDateOfBirth = 0;
  DateTime pickedDate;
  bool isValid = true;
  File imagePath;
  List<String> mediaDocumentList =     List();
  static const platform = const MethodChannel('samples.flutter.io/battery');
  final formKey = GlobalKey<FormState>();
  DateTime startDate;
  Map<int, String> dataValue = {};
  File mediaImage;
  List<String> mediaImagesList =     List();

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.userId;
    String dob = prefs.getString(UserPreference.DOB);
    if (dob != null) {
      int d = int.tryParse(dob);
      startDate =     DateTime.fromMillisecondsSinceEpoch(d);
      setState(() {
        startDate;
      });
    } else {
      startDate =     DateTime.now();
    }
    callApiForSaas();
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";

    mediaDocumentList.add(null);
    mediaImagesList.add(null);
    for (SubjectListModel subject in testDatModel.subjectListModel) {
      dataValue[subject.testSubId] = subject.score;
    }

    dobController =     TextEditingController(text: testDatModel.dateTaken);
    strDateOfBirth = testDatModel.dateTakenInt;

    mediaDocumentList.addAll(testDatModel.docList);
    mediaImagesList.addAll(testDatModel.imgList);
    setState(() {});
  }

  //=========================================================Api Calling =======================================
  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await     ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  showSucessMsg(msg, context) {
    /*Timer _timer;

    print("timer on");
    _timer =     Timer(const Duration(milliseconds: 2000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>     WillPopScope(
            onWillPop: () {},
            child:     GestureDetector(
              child:     Scaffold(
                backgroundColor: Colors.transparent,
                body:     Stack(
                  children: <Widget>[
                        Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:     Container(
                          height: 65.0,
                          padding:     EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:     Color(0xffF1EDC3),
                          child:     Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:     TextStyle(
                                        color:     Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));*/

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            negativeText: 'OK',
            msg: msg,
            isSucessPopup: true,
            onNegativeTap: (){
              Navigator.pop(context, "push");
            },
          );
        });
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        mediaDocumentList.removeAt(0);
        mediaImagesList.removeAt(0);
        List<ScoreModel> scoreList =     List();
        dataValue.forEach((k, v) {
          scoreList.add(new ScoreModel(v, k));
        });
        Map map = {
          "testId": testDatModel.testId,
          "userTestId": testDatModel.userTestId,
          "userId": userIdPref,
          "dateTaken": strDateOfBirth,
          "docUrl": mediaDocumentList.map((item) => item).toList(),
          "imageUrl": mediaImagesList.map((item) => item).toList(),
          "score": scoreList.map((item) => item.toJson()).toList()
        };

        print("map+++" + map.toString());
        response = await     ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_TEST_SCORE_DATA, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        mediaDocumentList.add("");
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      mediaDocumentList.add("");
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    try {
      getSharedPreferences();
    } catch (e) {
      print(e.toString());
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Future<Null> selectDob(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime:     DateTime.now(),
        initialDateTime: pickedDate == null ?     DateTime.now() : pickedDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());

          if (dateTime != null) {
            pickedDate = dateTime;
            strDateOfBirth = dateTime.millisecondsSinceEpoch;
            String date = Util.getDate(dateTime);

            setState(() {
              isValid = true;
              pickedDate;

              dobController =     TextEditingController(text: date);
            });
          } else {
            FocusScope.of(context).requestFocus(new FocusNode());
          }
        },
      );
    }

    final dateOBUI =     InkWell(
      child:     Container(
        padding:
                EdgeInsets.only(left: 0.0, top: 5.0, right: 0.0, bottom: 0.0),
        child:     TextField(
          keyboardType: TextInputType.text,
          controller: dobController,
          enabled: (!isValid),
          onTap: () {
            setState(() {
              selectDob(context);
            });
          },
          style:
                  TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
          decoration:     InputDecoration(
            labelText: MessageConstant.TEXT_SCORE_DATE_TAKEN,
            contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            errorText:
                (!isValid) ? MessageConstant.SELECT_DATE_TAKEN_VAL : null,
            focusedBorder:     UnderlineInputBorder(
                borderSide:     BorderSide(
                    color:     ColorValues.DARK_GREY,width: 1.0)),
            disabledBorder:     UnderlineInputBorder(
                borderSide:     BorderSide(
                    color:     ColorValues.DARK_GREY,width: 1.0)),
            labelStyle:     TextStyle(
                color:     ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 14.0),
          ),
        ),
      ),
      onTap: () {
        selectDob(context);
      },
    );
    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});

      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathOrganization);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        String path = strPrefixPathOrganization + strAzureImageUploadPath;
        mediaDocumentList.add(path);
        setState(() {
          mediaDocumentList;
        });

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    getDocuments() async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if(path!=null&&path!="") {
            if ((Util.getFileExtension(path) == ".pdf") && path != null) {
              print("path+++++" + path.toString());

              CustomProgressLoader.showLoader(context);
              Timer _timer =     Timer(const Duration(milliseconds: 400), () {
                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    type: "doc");
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.INVALID_FILE_FORMAT_VAL, context);
            }
          }
        } catch (e) {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    }

    void conformationDialog(type, file) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>     WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:     SafeArea(
                  child:     Scaffold(
                      backgroundColor: Colors.black38,
                      body:     Stack(
                        children: <Widget>[
                              Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:     Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:     Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                                Container(
                                              height: 145.0,
                                              padding:     EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:     Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                        Text(
                                                      MessageConstant.REMOVE_NAME,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:     AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,16.0,FontType.Regular), /*TextStyle(
                                                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),*/
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                              Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:     Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                      Container(
                                      color: Colors.white,
                                      padding:     EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:     Row(
                                        children: <Widget>[
                                              Expanded(
                                            child:     InkWell(
                                              child:     Container(
                                                  child:     Text(
                                               MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style:     AppTextStyle.getDynamicStyleGroup(ColorValues.GREY_TEXT_COLOR,16.0,FontType.Regular), /*TextStyle(
                                                    color:     ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                              Expanded(
                                            child:     InkWell(
                                              child:     Container(
                                                  child:     Text(
                                                MessageConstant.REMOVE,
                                                textAlign: TextAlign.center,
                                                style:     AppTextStyle.getDynamicStyleGroup(ColorValues.BLUE_COLOR_BOTTOMBAR,16.0,FontType.Regular),/* TextStyle(
                                                    color:     ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "image") {
                                                  mediaImagesList.remove(file);
                                                  setState(() {
                                                    mediaImagesList;
                                                  });
                                                } else if (type == "doc") {
                                                  mediaDocumentList
                                                      .remove(file);
                                                  setState(() {
                                                    mediaDocumentList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    onTapImageAddButton() async {
      mediaImage = await UploadMedia(context).pickImageFromGallery();

     // mediaImage = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (mediaImage != null) {
        imagePath=mediaImage;
       // await _cropImage(mediaImage);
        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =     Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    final mediaImageListUIData =     Container(
        child:     GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaImagesList.map((file) {
        if (file == null) {
          return     Stack(children: <Widget>[
                InkWell(
              child:     Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:     BoxDecoration(
                      border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:     Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () async{
                var status = await Permission.photos.status;
                if (status.isGranted) {
                  onTapImageAddButton();
                }  else {
                  checkPermissionPhoto(context);
                }
              },
            )
          ]);
        } else {
          return     Container(
              child:     Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + file,
                height: 54.0,
                width: 80.0,
              ),
                  Container(
                height: 54.0,
                width: 84.0,
                color:     Color(0XFFC0C0C0).withOpacity(.4),
              ),

                  Positioned(
                  right: 20.0,
                  top: 0.0,bottom: 0.0,left: 0.0,
                  child:     Container(
                      height: 20.0,
                      width: 20.0,
                      child:     Center(
                          child:     Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                                  InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                          Image.asset(
                                        "assets/remove_grey.png",
                                        width: 20.0,
                                        height: 20.0,
                                      )),
                                  onTap: () {
                                    conformationDialog("image", file);
                                  })
                            ],
                          )))),


            ],
          ));
        }
      }).toList(),
    ));

    final docListUiData =     Container(
        padding:     EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 20.0),
        child:     GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: mediaDocumentList.map((file) {
            if (file == null) {
              return     Stack(children: <Widget>[
                    InkWell(
                  child:     Container(
                      height: 54.0,
                      width: 68.0,
                      decoration:     BoxDecoration(
                          border:     Border.all(color:     ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:     Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      )),
                  onTap: ()async {
                    if (mediaDocumentList.length <= 5) {
                      getDocuments();
                   /*   var status = await Permission.storage.status;
                      if (status.isGranted) {
                        getDocuments();
                      }  else {
                        checkStoragePermissionStorage(context);
                      }*/
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);
            } else {
              return     Container(
                  child:     Stack(
                children: <Widget>[
                      Container(
                      height: 54.0,
                      width: 62.0,
                      child:     Image.asset(
                        "assets/newDesignIcon/patner/pdf.png",
                        height: 54.0,
                        width: 62.0,
                      )),
                      Container(
                      height: 54.0,
                      width: 62.0,
                      child:     Center(
                          child:     Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                              InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                      Image.asset(
                                    "assets/newDesignIcon/achievment/remove.png",
                                    width: 35.0,
                                    height: 35.0,
                                  )),
                              onTap: () {
                                conformationDialog("doc", file);
                              })
                        ],
                      ))),
                ],
              ));
            }
          }).toList(),
        ));
    validateMethod(SubjectListModel model, value) {
      if (value >= model.minScore && value <= model.maxScore) {
        return null;
      }

      return "Please enter value between " +
          model.minScore.toString() +
          "-" +
          model.maxScore.toString();
    }

    void takeNumber(String text, int name) {
      try {
      //  int number = int.parse(text);
        dataValue[name] = text;

        print(dataValue);
      } on FormatException {}
    }

    void _checkValidation() async {
      final form = formKey.currentState;
      form.save();

      if (form.validate()) {
        apiCalling();
      }
    }

    //-------------------------------------Main Ui ------------------------------------------
    return     GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child:     Scaffold(
            backgroundColor:     ColorValues.SCREEN_BG_COLOR,
            appBar:     AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              elevation: 0.0,
              titleSpacing: 0.0,
              title:     Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                      Expanded(
                    child:     InkWell(
                      child:     SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                                Center(
                                child:     Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                    flex: 0,
                  ),
                      Expanded(
                    child:     Text(
                   MessageConstant.TEXT_SCORE_UPDATE_TEST_SCORE,
                      textAlign: TextAlign.center,
                      style:     AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,18.0,FontType.Regular),/* TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                    Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                        InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          13.0,
                          0.0,
                          TextViewWrap.textView(
                              MessageConstant.SAVE,
                              TextAlign.start,
                                  ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal)),
                      onTap: () {
                        _checkValidation();
                      },
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  FocusScopeNode currentFocus = FocusScope.of(context);

                  if (!currentFocus.hasPrimaryFocus &&
                      currentFocus.focusedChild != null) {
                    FocusManager.instance.primaryFocus.unfocus();
                  }
                },
                child:PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                5.0,
                    Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                        Expanded(
                      child: ListView(
                        children: <Widget>[
                              Container(
                              width: double.infinity,
                              child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                10.0,
                                13.0,
                                20.0,
                                Form(
                                    key: formKey,
                                    child:     Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[

                                          dateOBUI,

                                              Column(
                                              children:     List.generate(
                                            testDatModel
                                                .subjectListModel.length,
                                            (int subjectIndex) {
                                              SubjectListModel modelData =
                                                  testDatModel.subjectListModel[
                                                      subjectIndex];
                                              return     Padding(
                                                padding:     EdgeInsets.only(
                                                    left: 0.0,
                                                    top: 15.0,
                                                    right: 0.0,
                                                    bottom: 0.0),
                                                child:     TextFormField(
                                                  controller:
                                                          TextEditingController(
                                                          text: modelData.score
                                                              .toString()=="N/A"?"":modelData.score
                                                              .toString()),
                                                  keyboardType:
                                                      TextInputType.number,
                                                  inputFormatters: <TextInputFormatter>[
                                                    WhitelistingTextInputFormatter.digitsOnly

                                                  ],
                                                  maxLength: 10,
                                                  cursorColor:
                                                      Constant.CURSOR_COLOR,
                                                  validator: (val) =>   modelData.isOptional?null:
                                                      validateMethod(
                                                          modelData,
                                                          val != null &&
                                                                  val != ""
                                                              ? int.parse(val)
                                                              : 0),
                                                  onSaved: (text) {
                                                    try {
                                                      modelData.score =
                                                          text;
                                                      takeNumber(text,
                                                          modelData.testSubId);
                                                    } catch (e) {}
                                                  },
                                                  onFieldSubmitted: (v) {
                                                    try {
                                                      modelData.score =
                                                        v;
                                                    } catch (e) {}
                                                  },
                                                  style:     TextStyle(
                                                      color: Colors.black,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                  decoration:
                                                          InputDecoration(
                                                    contentPadding:
                                                        const EdgeInsets
                                                                .fromLTRB(
                                                            0.0, 5.0, 5.0, 5.0),
                                                    counterText: "",

                                                        counterStyle:      TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            labelText:
                                                        modelData.subjectName +
                                                            "(" +
                                                            modelData.minScore
                                                                .toString() +
                                                            "-" +
                                                            modelData.maxScore
                                                                .toString() +
                                                            ")",
                                                    labelStyle:     TextStyle(
                                                        color:     ColorValues.GREY_TEXT_COLOR,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR,
                                                        fontSize: 14.0),
                                                        focusedBorder:     UnderlineInputBorder(
                                                            borderSide:     BorderSide(
                                                                color:     ColorValues.DARK_GREY,width: 1.0)),
                                                        enabledBorder:     UnderlineInputBorder(
                                                            borderSide:     BorderSide(
                                                                color:     ColorValues.DARK_GREY,width: 1.0)),
                                                  ),
                                                ),
                                              );
                                            },
                                          )),
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              20.0,
                                              0.0,
                                              10.0,
                                              Text(
                                                "Documents (PDF only)",
                                                style: AppTextStyle
                                                    .getDynamicFontStyle(
                                                        Palette
                                                            .secondaryTextColor,
                                                        14,
                                                        FontType.Regular),
                                              )),
                                          docListUiData,
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              20.0,
                                              0.0,
                                              10.0,
                                              Text(
                                                MessageConstant.TEXT_SCORE_PHOTOS,
                                                style: AppTextStyle
                                                    .getDynamicFontStyle(
                                                        Palette
                                                            .secondaryTextColor,
                                                        14,
                                                        FontType.Regular),
                                              )),
                                          mediaImageListUIData,
                                        ])),
                              )),
                        ],
                      ),
                      flex: 1,
                    )
                  ],
                )))));
  }
}
