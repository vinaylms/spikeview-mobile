import 'dart:io';

class AcvhievmentSkillModel {
  String skillId, title, description;
  bool isSelected;

  AcvhievmentSkillModel(this.skillId, this.title, this.description,{this.isSelected});
}