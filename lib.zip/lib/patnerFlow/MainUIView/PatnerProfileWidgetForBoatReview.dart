import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/presoView/simple_animations/controlled_animation.dart';
import 'package:smooth_star_rating/smooth_star_rating.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/badges/BadgesRequestForm.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/gateway/BusinessCategoryResponse.dart';

import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/BadgeDataModel.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ConnectionModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';

import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/notification/ApproveOpportunity.dart';

import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/ImageUpdate/EditCompanyImages.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/CompanyDetailPage.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/ManageOfferingWidget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/rating/EditRating.dart';
import 'package:spike_view_project/rating/Rating.dart';
import 'package:spike_view_project/rating/RatingModel.dart';

import 'package:spike_view_project/report/ReportWidget.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

class PatnerProfileWidgetForBoatReview extends StatefulWidget {
  String userId, callingType;
  String requestStatus,opportunityId;

  PatnerProfileWidgetForBoatReview(this.userId, this.callingType,
      {this.requestStatus, this.opportunityId});

  @override
  PatnerProfileWidgetForBoatReviewState createState() =>
       PatnerProfileWidgetForBoatReviewState(userId);
}

class PatnerProfileWidgetForBoatReviewState
    extends State<PatnerProfileWidgetForBoatReview> {
  int notificationCount = 0;

  String rejectionReason = '';

  String selectedCountryCode='';
  String partnerName='';
  String email='';
  String phone='';
  String companyName='';
  String companyAddress='';
  String companyPhone='';
  String webUrl='';
  String aboutCompany='';
  String companyid='';

  List<String> mediaImagesList =  List();
  List<AssetModel> assetModelMap =  List();
  List<FileModel> mediaVideosList =  List();

  List<String> googleDoclinkList =  List();

  UploadMedia uploadMedia;

  List<CategoryModel> selectedCategoryList=new List<CategoryModel>();

  List<Assest> assestVideoAndImage =  List();

  var style = TextStyle(
      color: ColorValues.GREY_TEXT_COLOR, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblack =
  TextStyle(color: Colors.black, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var stylextreLarge =
  TextStyle(color: Colors.black, fontSize: 24, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblackText =
  TextStyle(color: Colors.black, fontSize: 14, fontFamily: Constant.TYPE_CUSTOMBOLD);

  //static var mediaDocumentList;
  List<String> mediaDocumentList =  List();

  TextEditingController reasonTxtController =  TextEditingController();

  final FocusNode _reasonFocus = FocusNode();


  PatnerProfileWidgetForBoatReviewState(this.userIdPref);

  bool isCallStudentRequestApi = false;

  Color borderColor = Colors.amber;
  bool isRememberMe = false;
  bool isDataRember = false;
  File imagePath, imagePathCover;
  String strNetworkImage = "";
  String userIdPref, roleId, token;
  ProfileInfoModal profileInfoModal;
  List<StudentDataModel> listStudent =  List();
  List<ProfileEducationModal> userEducationList =
       List<ProfileEducationModal>();
  List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  List<Recomdation> recommendationtList =  List<Recomdation>();
  BuildContext context;
  SharedPreferences prefs;
  bool isSentRequest = true;
  bool isNarativeShow = false;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto,
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strSummary;
  String strAccCount = "", strRecCount = "";
  bool isActive = false;
  StreamSubscription<dynamic> _streamSubscription;
  StreamSubscription<dynamic> _streamSubscriptionWizard;
  ScrollController _scrollController =  ScrollController();
  bool isTitleVisible = false;
  bool _isAppbar = true;
  final _formKey = GlobalKey<FormState>();

  String strDoB = "";
  String strFirstName = "", strLastName = "", strEmail = "";
  bool isLoading = true;
  bool isRatingLodaing = true;
  static String isAchivmentAdded = "false";
  static String isEducationAdded = "false";
  bool isShowAllActiveOpportunity = false;
  bool isShowAllExpireOpportunity = false;
  static StreamController syncDoneController = StreamController.broadcast();

  bool isConnected = false;
  bool isRejected = false;
  bool isApproved = false;
  bool isPending = false;
  bool isParentApprovalPending = false;

  final GlobalKey<FormState> _companyProfileFormKey = GlobalKey<FormState>();

  bool isAccepetd = false;
  String connectId = "0";
  bool isSubscribe = false;
  int subsCriberId = 0;
  ConnectionModel connectionModel;
  bool isDataLoading = true;
  CompanyProfileModel companyModel;
  List<OpportunityModel> activeOpportunityList =  List();
  List<OpportunityModel> expireOpportunityList =  List();
  List<BadgeDataModel> badgeList =  List();
  bool isViewAllBadges = false;
  List<RequestedTagModel> pendinForParentDataList =  List();
  List<RequestedTagModel> receivedRequestList =  List();

  //-----------for rating------------
  var rating = 4.0;
  bool isSelectTap = false;
  var ratingCalculation = 0.0;
  String creationDate = "";
  bool isView = false;
  List<RatingModel> reviewList =  List();
  RatingModel myRating;

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await  ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_PERSONAL_INFO_NEW +
              userIdPref +
              "/false/" +
              "4/" +
              roleId,
          "get");


      print("profileApi is null ${Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/" + "4/" + roleId}");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response parent data++++" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            profileInfoModal =
                ParseJson.parseMapUserProfile(response.data['result']);

            print("profileInfoModal is null ${profileInfoModal != null}");

            if (profileInfoModal.isActive == "true") {
              isActive = true;
            }

            if (profileInfoModal != null) {
              strNetworkImage = profileInfoModal.profilePicture;
              setState(() {
                strNetworkImage;
                profileInfoModal;
              });
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future companyInfoApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await  ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_COMPANY_INFO + userIdPref + "&roleId=" + roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny" + response.toString());
      print("response comapny userIdPref" + userIdPref + " &roleId " + roleId);

      if (response != null) {

        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {

            var map = response.data['result'];
            if (map != null) {
              companyModel = ParseJson.parseCompanyInfoData(map);

              print(companyModel);

              if (companyModel != null) {

                print("companyModel.partnerStatus.toString() ${companyModel.partnerStatus.toString()}");

                companyModel;
                if(companyModel.partnerStatus.toString() == 'Pending'){
                  isApproved = false;
                  isRejected = false;
                  isPending = true;
                }else if(companyModel.partnerStatus.toString() == 'Active'){
                  isApproved = true;
                  isRejected = false;
                  isPending = false;
                  //ToastWrap.showToastLong(MessageConstant.ACTIVE_PARTNER_VAL, context);
                }else if(companyModel.partnerStatus.toString() == 'Decline'){
                  isApproved = false;
                  isRejected = true;
                  isPending = false;
                  //ToastWrap.showToastLong(MessageConstant.DECLINE_PARTNER_VAL, context);
                }

                print("companyModel != null - ${companyModel != null}");

                setData(companyModel);
                /*
                  isRejected=true && !isApproved= false
                  *
                  * */

                setState(() {


                });
              }
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await  ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;

            print("sastoken:===" + sasToken);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

//***************************************************************************************************************

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    setState(() {
      isDataLoading = true;
    });
    prefs = await SharedPreferences.getInstance();

    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);

    CustomProgressLoader.showLoader2(context);

    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {

      await profileApi(false);
      await companyInfoApi(false);
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
    isDataLoading = false;
    CustomProgressLoader.cancelLoader(context);

    if (isConnect) {

      await callApiForSaas();
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }

    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_COVER +
        "/";

    strPrefixPathforProfilePhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";

    if(isApproved){
      ToastWrap.showToastGreen(MessageConstant.ACTIVE_PARTNER_VAL, context);
    }else if(isRejected){
      ToastWrap.showToastGreen(MessageConstant.DECLINE_PARTNER_VAL, context);
    }

  }

  void appBarStatus(bool status) {
    setState(() {
      _isAppbar = status;
    });
  }


  @override
  void initState() {
    print("changes");
    print("partner user+++" + widget.userId);
    print("partner user+++" + userIdPref);

    uploadMedia = UploadMedia(context);

    _scrollController.addListener(() {
      if (_scrollController.offset < 150.0) {
        setState(() {
          isTitleVisible = false;
        });
      } else {
        setState(() {
          isTitleVisible = true;
        });
      }

      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        appBarStatus(false);
      }
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        appBarStatus(true);
      }
    });

    getSharedPreferences();

    super.initState();
  }

  //--------------------------  api ------------------

  Future apiCallApprovePartner(bool isActive) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map;
        if(isActive){
          map = {
            "userId": int.parse(widget.userId),
            "isActive": isActive,
          };
        }else{
          map = {
            "userId": int.parse(widget.userId),
            "isActive": isActive,
            "declineReason": reasonTxtController.text,
          };
        }


        print('Apurva apiCallApprovePartner API call url::: ${Constant.ENDPOINT_UPDATE_PARTNER_COMPANY}, userID:: ${int.parse(widget.userId)}');
        Response response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_PARTNER_COMPANY, map);

        print("apiCallApprovePartner response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToastGreen(msg,context);
              reasonTxtController.text = '';
              /*setState(() {
                if(isActive){
                  isApproved = true;
                  isRejected = false;
                  isPending = false;
                }else{
                  isApproved = false;
                  isRejected = true;
                  isPending = false;
                }

              });
              Timer _timer;
              print("apiCallApprovePartner timer on");
              _timer =  Timer(const Duration(milliseconds: 5000), () async {
                print("apiCallApprovePartner timer off");

                //onBack();
              });
              //onBack();*/
              if (widget.opportunityId == null||(!isActive)) {
                print("In showSucessMsgLong");

               // Navigator.pop(context);

                showSucessMsgLong(msg);
              } else {

                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>  Approveopportunity(
                        widget.callingType, widget.opportunityId)));
              }
            } else {
              ToastWrap.showToastLong(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }


  void showSucessMsgLong(msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,

      builder: (_) {
        return ConfirmationDialog(
          msg: msg,
          isSucessPopup: true,
          onPositiveTap: (){

          },
          onNegativeTap: (){
            onBack();

          },
        );
      },
    );
  }


  showSucessMsgLongold(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");

     // Navigator.pop(context);
      Navigator.pop(context, "push");
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }


  Widget _negativeButton({@required String title}) {
    return InkWell(
      onTap: () {
       // showRejectionAlert();
        showRejectWithReasonPopUp(context);
      },
      child: Container(
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          border: Border.all(color: Color(0xffB2BDDB)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: AppConstants.txtStyle.heading18600LatoRegularLightPurple,

        ),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Main View for return final Output
    this.context = context;
    Widget _loader(BuildContext context, String placeHolderImage) =>
        Center(
            child: Container(
              child: Image.asset(
                placeHolderImage,
                fit: BoxFit.cover,
              ),
            ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }


    InkWell isImageSelectedView() {

      return InkWell(
        child: Container(
          width: 80.0,
          height: 80.0,
          child: Stack(
            children: <Widget>[
              Center(
                child: Stack(
                  children: [
                    Container(
                      width: 80.0,
                      height: 80.0,

                      decoration: BoxDecoration(
                        color: ColorValues.DARK_YELLOW,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: ColorValues.DARK_YELLOW,
                            offset: Offset(0, 0),
                            blurRadius: 6,
                          ),
                        ],
                        border: Border.all(
                          color: ColorValues.DARK_YELLOW,
                          width: 5,
                        ),
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(15),
                        child: companyModel != null
                            ? CachedNetworkImage(
                          imageUrl: companyModel != null
                              ? Constant.IMAGE_PATH_SMALL +
                              ParseJson.getMediumImage(companyModel.profilePicture)
                              : "",
                          fit: BoxFit.cover,
                          placeholder: (context, url) => _loader(
                              context, 'assets/profile/user_on_user.png'),
                          errorWidget: (context, url, error) =>
                              _error('assets/profile/user_on_user.png'),
                        )
                            : Image.asset('assets/profile/user_on_user.png'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        onTap: () {
          //  onTapEditProfile();
        },
      );
    }

    InkWell isImageSelectedViewsss() {

      return InkWell(
        child:  ProfileImageView(
          imagePath: (companyModel != null && companyModel.profilePicture != null)
              ? Constant.IMAGE_PATH_SMALL +
              ParseJson.getMediumImage(companyModel.profilePicture)
              : 'assets/profile/user_on_user.png',
          placeHolderImage:
          'assets/profile/user_on_user.png',

          height: 80.0,
          width:80.0,

          onTap: () async {},
          borderRadius: 10,

        ),
        onTap: () {},
      );


    }

    int getLenthOfName() {
      int lenght = 0;
      if (companyModel == null) {
        return 0;
      } else {
        lenght = companyModel.name.length;
      }
      return lenght;
    }


    Widget headerUiDesign() {
      return Container(
        height: 100.0,
        color: Colors.white,
        //ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
              PaddingWrap.paddingfromLTRB(
                  20.0, 10.0, 5.0, 10.0, isImageSelectedView()),
              PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  0.0,
                  8.0,
                  Container(
                      child:  Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingAll(
                            2.0,
                            TextViewWrap.textViewMultiLine(
                                companyModel == null
                                    ? ""
                                    : companyModel.name,
                                TextAlign.start,
                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                getLenthOfName() > 24 ? 18.0 : 20.0,
                                FontWeight.w600,
                                2),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: Container(
                              decoration:  BoxDecoration(
                                  color:
                                  isApproved ?
                                  Color(0xffD1E7DD)
                                      :  Color(0xffFCEAE2),
                                  borderRadius: BorderRadius.circular(12) ),
                              height: 22.0,
                              child: PaddingWrap.paddingfromLTRB(
                                12.0,
                                3.0,
                                12.0,
                                3.0,  TextViewWrap.textViewSingleLine(
                                  isApproved ?
                                  "Active".toUpperCase()

                                      : "Pending Approval".toUpperCase(),
                                  TextAlign.start,
                                  isApproved ? Color(0xff198754)
                                      : Color(0xffC87C5B),
                                  12.0,
                                  FontWeight.normal),),
                            ),
                          ),
                        ],
                      )
                  )
              ),

            //   flex: 1,
            // )
          ],
        )
      );
    }

    /*
    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:
        customAppbar(
          context,
          GestureDetector(

              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child:
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 24, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox()
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Padding(
                        padding: const EdgeInsets.only(left: 0.0, right: 0),
                        child: SingleChildScrollView(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 7 ,right: 7),
                            child: Container(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[

                                  /*
                                  Padding(
                                    padding:
                                    const EdgeInsets.only(
                                        top: 20.0, bottom: 20,left: 20),
                                    child: Text(companyModel != null ?
                                    "${companyModel.name}'s Profile" : "Profile",
                                      style: TextStyle(
                                          fontSize: 28,
                                          fontFamily: Constant
                                              .latoSemibold,
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1),
                                    ),
                                  ),
                                   */

                                  SizedBox(height: 0,),
                                  headerUiDesign(),
                                  companyModel != null ? partnerDetails() : Container(),
                                  companyModel != null && (googleDoclinkList.length > 0 || mediaDocumentList.length > 0 || assestVideoAndImage.length > 0) ? getMediaDetails() : Container(width: 0,height: 20,),
                                  SizedBox(height: 20,),

                                ],
                              ),
                            ),
                          ),
                        )
                    ),
                    flex: 1,
                  ),
                ],
              )
          ),
              () {
            Navigator.pop(context);
          },
          isShowIcon: false,
          bottomNavigation: isPending ? approveRejectButtonsNew() : Container(height: 30,),
          //approveRejectButtons()
        )
    );
    */


    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: Padding(
              padding: const EdgeInsets.only(left: 10,top: 10),
              child: IconButton(
                  icon: Image.asset("assets/newDesignIcon/icon/back_icon.png",
                      height: 32.0, width: 32.0, fit: BoxFit.fill),
                  onPressed: () {
                    Navigator.pop(context);
                  }),
            ),
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: Colors.white,
          body:  Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 0.0, right: 0, top: 10, bottom: 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox()
                    ],
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: Padding(
                    padding: const EdgeInsets.only(left: 0.0, right: 0),
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 0 ,right: 0),
                        child: Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[

                              /*
                                  Padding(
                                    padding:
                                    const EdgeInsets.only(
                                        top: 20.0, bottom: 20,left: 20),
                                    child: Text(companyModel != null ?
                                    "${companyModel.name}'s Profile" : "Profile",
                                      style: TextStyle(
                                          fontSize: 28,
                                          fontFamily: Constant
                                              .latoSemibold,
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1),
                                    ),
                                  ),
                                   */

                              SizedBox(height: 0,),
                              headerUiDesign(),
                              companyModel != null ? partnerDetails() : Container(),
                              companyModel != null && (googleDoclinkList.length > 0 || mediaDocumentList.length > 0 || assestVideoAndImage.length > 0) ? getMediaDetails() : Container(width: 0,height: 20,),
                              SizedBox(height: 20,),

                            ],
                          ),
                        ),
                      ),
                    )
                ),
                flex: 1,
              ),
            ],
          ),

          bottomNavigationBar: isPending ? approveRejectButtonsNew() : Container(height: 30,),
        )
    );





  }

  void onBack() {
    print('OnBack partner isDataLoading:: $isDataLoading');
    if (!isDataLoading) {
      if (widget.callingType == "main" ) {
        // For Partner DashBoard
        print('inside Partner if 111 widget.pageRedirect:: ${widget.callingType}, roleID:: $roleId');
        if (roleId == "1") {
          // For Studenet
          Navigator.pushReplacement(
            //Constant.applicationContext,
              context,
               MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) =>  DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));
        } else if (roleId == "2") {
          Navigator.pushReplacement(
            //Constant.applicationContext,
              context,
               MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) =>  DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Parent
        } else if (roleId == "4") {
          Navigator.pushReplacement(
            //Constant.applicationContext,
              context,
               MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                  builder: (context) =>  DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.PROFILE_TYPE)));

          // For Partner
        }
      } else {
        print('inside Partner else 111 widget.pageRedirect:: ${widget.callingType}, roleID:: $roleId');
        Navigator.pop(context);
      }
    } else {
      print("Not partner perform");
    }
  }

  partnerDetails() {
    print("partnerName - ${partnerName}");
    return Container(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Company name'),
            ),

            getValueText('$companyName'),

            partnerName.trim() != "" ? Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Partner’s name'),
            ) : Container(),
            partnerName.trim() != "" ? getValueText('$partnerName') : Container(),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0,4),
              child: getLabelText('Business category'),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
              child: Wrap(
                children: getSelectedWidgets(selectedCategoryList, "mainCategory"),
              ),
            ),

            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Company address'),
            ),
            getValueText('$companyAddress'),

            companyPhone != "" ?
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
              child: getLabelText('Phone number'),
            ) : Container(),
            companyPhone != "" ?
            Row(
              children: <Widget>[
                // CountryCodePicker(
                //   dense: false,
                //   showFlag: true,
                //   //displays flag, true by default
                //   showDialingCode: true,
                //   //displays dialing code, false by default
                //   showName: false,
                //   showDropDownIcon: false,
                //   showUnderLine: false,
                //   isEnabled: false,
                //   selectedCountryCode: selectedCountryCode,
                // ),
                Padding(
                  padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: getValueText('+${selectedCountryCode} ${Util.getPhoneNoFormate(companyPhone)}'),
                ),

              ],
            ): Container(),

            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Email'),
            ),



            getValueText('$email'),
            webUrl != "" ? Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Website url'),
            ): Container(),
            webUrl != "" ?
            InkWell(
              onTap: (){
                Navigator.push(
                    context,
                     MaterialPageRoute(
                      //   builder: (context) =>  DashBoardWidget()));
                        builder: (context) =>  WebViewWidget(
                            webUrl, "spikeview")));
              },
              child: getValueTextBlue('$webUrl')
            )

                : Container(),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('About company'),
            ),
            getValueText('$aboutCompany'),
          ],
        ),
      ),
    );
  }



  approveRejectButtonsNew() {
    return
      Container(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
        height: 90,
        //currentStep == 0 ? 0 : 90,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Color.fromRGBO(204, 220, 247, 0.46),
              blurRadius: 13,
              spreadRadius: 10,
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              flex: 30 ,
              child: _negativeButton(
                  title: 'Reject'),
            ),


            Expanded(
              flex: 66,
              child: Padding(
                padding: const EdgeInsets.only(left: 12),
                child: SizedBox(
                  height: 44,
                  child: PositiveButton(
                    onTap: () {
                      apiCallApprovePartner(true);
                      print("Aprove");


                    },
                    // isEnable: true,
                    isEnable:true,
                    title: "Approve",
                  ),
                ),
              ),
            ),
          ],
        ),
      );

  }

  approveRejectButtons() {
    return PaddingWrap.paddingfromLTRB(
      10.0,
      10.0,
      10.0,
      10.0,
      Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Expanded(
            child:  InkWell(
              child: Padding(
                padding:
                const EdgeInsets.fromLTRB(
                    0.0, 20.0, 0.0, 14.0),
                child:  Container(
                    height: 44.0,
                    //width: 226.0,
                    decoration:  BoxDecoration(
                      border:  Border.all(
                          color:  ColorValues.BORDER_COLOR_NEW, width: 1.0)
                      ,
                        borderRadius: BorderRadius.circular(10)
                    ),
                    child:
                    Row(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .center,
                      mainAxisAlignment:
                      MainAxisAlignment
                          .center,
                      children: <Widget>[
                         Text(
                          "Reject",
                          style:  TextStyle(
                              color:  ColorValues.labelColor,
                              fontFamily: Constant.latoMedium,
                              fontWeight: FontWeight.w600,
                              fontSize: 18.0),
                        )
                      ],
                    )
                ),
              ),
              onTap: () {
                //if(!isApproved)
               // showRejectionAlert();

                showRejectWithReasonPopUp(context);

              },
            ),
          ),
          Container(width: 16.0,),
          Expanded(child:  InkWell(
            child: Padding(
              padding:
              const EdgeInsets.fromLTRB(
                  0.0, 20.0, 0.0, 14.0),
              child:  Container(
                  height: 44.0,
                  //width: 226.0,

                  decoration:  BoxDecoration(
                    color:  ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED,
                      border:  Border.all(
                          color:  ColorValues.BORDER_COLOR_NEW, width: 1.0)
                      ,
                      borderRadius: BorderRadius.circular(10)
                  ),
                  child:  Row(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .center,
                    mainAxisAlignment:
                    MainAxisAlignment
                        .center,
                    children: <Widget>[
                       Text(
                        "Approve",
                        style:  TextStyle(
                            color: Colors.white,
                            fontFamily: Constant.latoMedium,
                            fontWeight: FontWeight.w600,
                            fontSize: 18.0),
                      )
                    ],
                  )),
            ),
            onTap: () {
                //if(!isRejected)
                apiCallApprovePartner(true);
            },
          ),),

        ],
      ),);
  }

  getLabelText(String textString) {
    return  Text(
      "$textString",
      textAlign: TextAlign.left,
      style:  TextStyle(
          color:  ColorValues.HEADING_COLOR_EDUCATION_1,
          fontSize: 12.0,
          fontWeight: FontWeight.w600,
          fontFamily: Constant.latoRegular),
    );
  }
  getValueText(String textString) {
    return  Text(
      "$textString",
      textAlign: TextAlign.left,
      style:  TextStyle(
          color:  ColorValues.labelColor,
          fontSize: 14.0,
          fontWeight: FontWeight.w600,
          fontFamily: Constant.latoMedium,
    ));
  }
  getValueTextBlue(String textString) {
    return  Text(
      "$textString",
      textAlign: TextAlign.left,
      style:  TextStyle(
          color:  ColorValues.BLUE_COLOR,
          fontSize: 14.0,
          fontWeight: FontWeight.w500,
          fontFamily:Constant.latoRegular),
    );
  }

  void setData(CompanyProfileModel companyProfileModel) async {
    String firstName='', lastname='';

    if (companyProfileModel.countryCode != null)
      selectedCountryCode = companyProfileModel.countryCode;

    if (companyProfileModel.firstName != null &&
        companyProfileModel.firstName != "null")
      firstName = companyProfileModel.firstName;

    if (companyProfileModel.lastName != null &&
        companyProfileModel.lastName != "null"){
      lastname = companyProfileModel.lastName;
    }

    partnerName = firstName+" "+ lastname;
    print('firstName:: $firstName, lastName:: $lastname');

    print("partnerName - ${partnerName}");

    if (companyProfileModel.email != null)
      email= companyProfileModel.email;

    if (companyProfileModel.mobileNo != null &&
        companyProfileModel.mobileNo != '0' &&
        companyProfileModel.mobileNo != 'null')
      phone = companyProfileModel.mobileNo;

    if (companyProfileModel.name != null &&
        companyProfileModel.name != "null")
      companyName = companyProfileModel.name;

    if (companyProfileModel.address != null &&
        companyProfileModel.address != "null")
      companyAddress = companyProfileModel.address;

    if (companyProfileModel.phone != null)
      companyPhone = companyProfileModel.phone;

    if (companyProfileModel.url != null)
      webUrl = companyProfileModel.url;

    if (companyProfileModel.about != null)
      aboutCompany = companyProfileModel.about;

    /*zipCode = companyProfileModel.zipCode == null ||
          companyProfileModel.zipCode == "null"
          ? "0"
          : companyProfileModel.zipCode;

      if (companyProfileModel.gender != null &&
          companyProfileModel.gender != "null" &&
          companyProfileModel.gender != "") {
        gender = companyProfileModel.gender;
      }*/

    companyid = companyProfileModel.companyId;
    print("compant Id---------" + companyid);

    for (Assest assest in companyModel.mediaList) {
      assestVideoAndImage.add(assest);
    }

    for (Assest assest in companyModel.docList) {
      mediaDocumentList.add(assest.file);
    }

    for (Assest assest in companyModel.videoList) {
      assestVideoAndImage.add(assest);
    }

    for (Assest assest in companyModel.googleLinkList) {
      googleDoclinkList.add(assest.file);
    }

    print("assestVideoAndImage length - ${assestVideoAndImage.length}");

    print("assestVideoAndImage length - ${assestVideoAndImage.length}");

    print("googleDoclinkList length - ${googleDoclinkList.length}");


    /*for (Assest assest in companyModel.videoList) {
        final thumbnailFile = await uploadMedia
            .getVideoThumbnailFromUrl(Constant.IMAGE_PATH + assest.file);

        mediaVideosList.add(new FileModel(thumbnailFile, assest.file));
      }
      print('mediaVideosList size:: ${mediaVideosList.length}');*/

    if(companyProfileModel.categoryModel != null && companyProfileModel.categoryModel.length > 0){
      bool first=true;
      for (var categoryModel in companyProfileModel.categoryModel) {
        print('categoryModel:::::: ${categoryModel.name}');

        selectedCategoryList.add(categoryModel);
      }
    }
    else{
      print('inside else companyProfileModel.categoryModel size:: ${companyProfileModel.categoryModel.length}');
      print('inside else no category selected');
    }



    setState(() {
      companyName;
      partnerName;
      webUrl;
      email;
      selectedCountryCode;
      phone;
      companyAddress;
      companyPhone;
      companyid;
      aboutCompany;

      mediaVideosList;
      selectedCategoryList;
      mediaDocumentList;
      googleDoclinkList;
      assestVideoAndImage;
    });
  }

  getMediaDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(20.0,20,20,14),
          child: Container(
              height: 1,
              width: MediaQuery.of(context).size.width,
              color: ColorValues.BORDER_COLOR
          ),
        ),

        Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 12, 7),
          child: getLabelText('Media'),
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(
                left: 20.0, right: 20.0, top: 10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                assestVideoAndImage.length > 0 ?
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    //
                    assestVideoAndImage.length > 0
                        ?  SizedBox(
                      // Pager view
                        height: 215.50,
                        child: PageIndicatorContainer(
                          pageView:  PageView.builder(
                            itemCount:
                            assestVideoAndImage.length,
                            controller:  PageController(),
                            itemBuilder: (context, index2) {
                              return  InkWell(
                                child:  Stack(
                                    children: <Widget>[
                                      assestVideoAndImage[
                                      index2]
                                          .type ==
                                          "image"
                                          ?  InkWell(
                                          onTap: () {
                                            Navigator.of(context).push(new MaterialPageRoute(
                                                builder: (BuildContext context) =>  CommonFullViewWidget(
                                                    assestVideoAndImage,
                                                    MessageConstant
                                                        .ACCOMPLISHMENT_HEDING,
                                                    index2,
                                                    MessageConstant
                                                        .COMPANY_PROFILE_HEDING)));
                                          },
                                          child:
                                          Container(
                                            decoration:
                                            BoxDecoration(
                                                color:
                                                Colors.black,
                                                borderRadius: BorderRadius.circular(10)
                                            ),
                                            child:
                                             CachedNetworkImage(
                                              width: double
                                                  .infinity,
                                              height:
                                              215.50,
                                              imageUrl: Constant
                                                  .IMAGE_PATH +
                                                  assestVideoAndImage[index2]
                                                      .file,
                                              fit: BoxFit
                                                  .contain,
                                              placeholder: (context,
                                                  url) =>
                                                  _loader(
                                                      context),
                                              errorWidget: (context,
                                                  url,
                                                  error) =>
                                                  _error(),
                                            ),
                                          ))
                                          :  Container(
                                        decoration:
                                        BoxDecoration(
                                            color:
                                            Colors.black,
                                            borderRadius: BorderRadius.circular(10)
                                        ),
                                        height: 215.50,
                                        child:
                                         Center(
                                          child:  VideoPlayPause(
                                              assestVideoAndImage[
                                              index2]
                                                  .file,
                                              "",
                                              true),
                                        ),
                                      ),

                                      assestVideoAndImage
                                          .length ==
                                          1 ||
                                          assestVideoAndImage[
                                          index2]
                                              .type ==
                                              "video"
                                          ?  Container(
                                        height: 0.0,
                                      )
                                          :  Container(
                                        height: 215.50,
                                        width: double
                                            .infinity,
                                        child:  Image
                                            .asset(
                                          "assets/newDesignIcon/navigation/layer_image.png",
                                          fit: BoxFit
                                              .fill,
                                        ),
                                      )

                                    ]),
                                onTap: () {},
                              );
                            },
                            onPageChanged: (index) {},
                          ),
                          align: IndicatorAlign.bottom,
                          length: assestVideoAndImage.length,
                          indicatorSpace: 10.0,
                          indicatorColor:
                          assestVideoAndImage.length == 1
                              ? Colors.transparent
                              :  Color(0xffc4c4c4),
                          indicatorSelectorColor:
                          assestVideoAndImage.length == 1
                              ? Colors.transparent
                              :  ColorValues.WHITE,
                          shape: IndicatorShape.circle(
                              size: 5.0),
                        ))
                        :  Stack(children: <Widget>[
                       Image.asset(
                        "assets/profile/default_achievement.png",
                        fit: BoxFit.cover,
                        height: 215.50,
                        width: double.infinity,
                      ),
                       Container(
                        height: 215.50,
                       decoration:
                         BoxDecoration(
                             color: Colors.black54.withOpacity(.4),
                             borderRadius: BorderRadius.circular(10)
                         ),
                      )
                    ])):  Container(
                  height: 0.0,
                ),

                mediaDocumentList.length == 0
                    ?  Container(
                  height: 0.0,
                )
                    : Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 30.0, 13.0, 0.0),
                    child:  Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      children: <Widget>[
                        getLabelText(
                            'Attached documents'),

                        const SizedBox(height: 5,),

                        docListUiDataNew(),
                      ],
                    )),

                googleDoclinkList.length == 0
                    ?  Container(
                  height: 0.0,
                )
                    : Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 20.0, 0.0, 0.0),
                    child:  Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      children: <Widget>[
                        getLabelText('Document link'),
                        uploadGoogleDocLink(),
                      ],
                    )
                ),

              ],
            ),
          ),
        ),
      ],
    );
  }


  docListUiDataNew(){
    return  Wrap(
      runSpacing: 10,
      spacing: 10,
      // primary: false,
      // shrinkWrap: true,
      // padding: const EdgeInsets.all(0.0),
      // crossAxisSpacing: 10.0,
      // childAspectRatio: 0.7,
      // scrollDirection: Axis.vertical,
      // crossAxisCount: 4,
      children: mediaDocumentList.map((file) {
        var fileName;
        String docName = "";
        if (file != null) {
          fileName = file.split("/");
          if (fileName != null && fileName.length > 0) {
            docName = fileName[fileName.length - 1];
          }
        }
        print('Apurva docListUiData docName:: $docName, file:: $file');

        return InkWell(
          onTap: () {
            print("DOC++++" + Constant.IMAGE_PATH + file);
            String url=Constant.IMAGE_PATH + file;
            launch(url.replaceAll(" ", "%20"));
          },
          child: Container(
              height: 60.0,
              width: 62.0,
              child: Image.asset(
                "assets/resume/ic_doc_pdf.png",
                height: 60.0,
                width: 62.0,
              )),
        );
      }).toList() ??
          [],
    );
  }

  docListUiDataold(){
    return  Container(
        padding: const EdgeInsets.fromLTRB(0.0, 18.0, 0.0, 0.0),
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.3,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: mediaDocumentList.map((file) {
            return  Container(
                child:  Stack(
                  children: <Widget>[
                     InkWell(
                      onTap: () {
                        print("DOC++++" + Constant.IMAGE_PATH + file);
                        String url=Constant.IMAGE_PATH + file;
                        launch(url.replaceAll(" ", "%20"));
                      },
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          5.0,
                           Container(
                              height: 80.0,
                              width: 62.0,
                              child:  Column(
                                children: <Widget>[
                                   Expanded(
                                    child:
                                    Container(
                                        height: 54.0,
                                        width: 62.0,
                                        child:
                                        Image.asset(
                                          "assets/resume/ic_doc_pdf.png",
                                          height: 54.0,
                                          width: 62.0,
                                        )
                                    ),
                                    flex: 1,
                                  ),
                                   Expanded(
                                    child:  Text(
                                      file.substring(
                                          (file.lastIndexOf("/") + 1), file.length),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                    ),
                                    flex: 0,
                                  )
                                ],
                              ))),
                    ),
                  ],
                ));
          }).toList(),
        ));
  }

  mediaLabelText(String label) {
    return Text(
      label,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
    );
  }
  uploadGoogleDocLink() {
    return Column(
      children: <Widget>[
         Column(
          children: List.generate(googleDoclinkList.length, (index) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                    child:  InkWell(
                      child: Text(
                        googleDoclinkList[index],
                        style: TextStyle(
                            color: Palette.accentColor, fontSize: 16,fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      ),
                      onTap: () {
                        Navigator.push(
                            context,
                             MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) =>  WebViewWidget(
                                    googleDoclinkList[index], "spikeview")));
                      },
                    ),
                  ),
                ),
              ],
            );
          }),
        )
      ],
    );
  }


  Widget _loader(BuildContext context) => Center(
      child: Container(
        child:  Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }




  List<Widget> getSelectedWidgets(List<CategoryModel> selectedOption, String from) {
    List<Widget> widgets = [];
    for (CategoryModel item in selectedOption) {
      print("Name+++++" + item.name);
      double width = item.name.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {

            return
              ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return Container(
                  margin: EdgeInsets.only(right: 10,top:0,bottom: 0),
                  child:

                  // old code

                  /*
                  InputChip(
                    label: Text('${item.name}',softWrap: true,style: TextStyle(
                      color: ColorValues.labelColor,
                      fontSize: 16,
                        fontWeight: FontWeight.w400,
                        fontFamily: Constant.latoRegular
                    ),),
                    backgroundColor: Colors.white,
                    //shape: StadiumBorder(side: BorderSide(color: ColorValues.GREY_TEXT_COLOR,),),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(3),bottomRight: Radius.circular(0)),side: BorderSide(color: ColorValues.labelColor,)),
                    labelStyle: TextStyle(
                      color: ColorValues.labelColor,
                      fontSize: 16,
                        fontWeight: FontWeight.w400,
                        fontFamily: Constant.latoRegular
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12.0,vertical: 3.0),
                    disabledColor: Colors.white,
                  ),

                   */


                    Padding(
                        padding: const EdgeInsets.all(3),
                        child: Container(
                          decoration: BoxDecoration(
                            color: ColorValues.DARK_YELLOW,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 7,right: 7,top: 5,bottom: 5),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Flexible(
                                  child: InkWell(
                                    onTap: () {
                                      // Handle selection here
                                      print('Selected: ${item.name}');
                                    },
                                    child: Text(
                                      '${item.name}',
                                      style: TextStyle(
                                        fontSize: 15.0,
                                        fontFamily: Constant.latoRegular,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.white,
                                      ),
                                      // maxLines: 1,
                                      // overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),

                              ],
                            ),
                          ),
                        )
                    )



                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }


  Widget showRejectWithReasonPopUp(context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter myState
                  /*You can rename this!*/) {
                return customAppbar(
                    context,

                    SingleChildScrollView(
                      child: Form(
                          key: _companyProfileFormKey,
                          child: Container(
                            padding: EdgeInsets.only(
                              bottom: MediaQuery.of(context).viewInsets.bottom,
                              left: 0, //11.0,
                              right: 0, // 11.0,
                            ),

                            child: Container(
                              // height: 275.0,
                              //color: Colors.black.withOpacity(0.8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                      padding: const EdgeInsets.only(
                                          left: 20.0,
                                          right: 0.0,
                                          top: 25.0,
                                          bottom: 0),
                                      child: RichText(
                                        maxLines: 1,
                                        textAlign: TextAlign.center,
                                        text: TextSpan(
                                          text: 'Account not approved',
                                          style: AppConstants.txtStyle
                                              .heading400LatoRegularDarkBlue
                                              .copyWith(
                                              fontSize: 28,
                                              fontWeight: FontWeight.w700),
                                          children: [
                                            TextSpan(
                                                text: '',
                                                recognizer: TapGestureRecognizer()
                                                  ..onTap = () {},
                                                style: AppConstants.txtStyle
                                                    .heading40018LatoRegularDarkBlue
                                                    .copyWith(
                                                    fontSize: 28,
                                                    fontWeight:
                                                    FontWeight.w700)),
                                          ],
                                        ),
                                      )),

                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20.0,
                                        right: 10.0,
                                        top: 10.0,
                                        bottom: 10),
                                    child:Text(
                                      "Please enter reason for rejecting the account.",
                                      textAlign:
                                      TextAlign.left,
                                      maxLines: 5,
                                      style: TextStyle(
                                          color: ColorValues
                                              .labelColor,
                                          fontSize: 15.0,
                                          fontWeight:
                                          FontWeight.w500,
                                          fontFamily: Constant
                                              .latoRegular),
                                    ),
                                  ),


                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20.0,
                                        right: 20.0,
                                        top: 15.0,
                                        bottom: 0),
                                    child:

                                    Container(
                                      //  height: 300,
                                      //   decoration: BoxDecoration(
                                      //     color:
                                      //     Color(0xffFEFEFE),
                                      //       borderRadius:
                                      //       BorderRadius.circular(
                                      //           10),
                                      //     border: Border.all(
                                      //         color: ColorValues
                                      //             .BORDER_GENERATE_SCRIPT,
                                      //         width: 1.0
                                      //     ),
                                      //   ),
                                      padding: const EdgeInsets
                                          .symmetric(
                                          horizontal: 0.0,
                                          vertical: 0.0),
                                      child:

                                      CustomFormField(
                                        decoration: InputDecoration(
                                          hintStyle: TextStyle(
                                            color: Colors.black.withOpacity(0.20),
                                            fontFamily: Constant.latoRegular,

                                          ),

                                          border: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: ColorValues
                                                      .BORDER_GENERATE_SCRIPT,
                                                  width: 1.0),
                                              borderRadius: BorderRadius.circular(10)

                                          ),
                                          focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppConstants.colorStyle.lightBlue,
                                                  width: 1.0),
                                              borderRadius: BorderRadius.circular(10)

                                          ),
                                          enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppConstants.colorStyle.btnBg, width: 1.0),
                                              borderRadius: BorderRadius.circular(10)

                                          ),
                                          disabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: AppConstants.colorStyle.btnBg, width: 1.0),
                                              borderRadius: BorderRadius.circular(10)
                                          ),

                                        ),
                                        minLines: 12,

                                        textInputType: TextInputType.text,
                                        label: "",
                                        hint: "Write your reason",
                                        // onType: (value) => _checkValidation(),
                                        maxLength: 500,
                                        maxLines: 12 ,
                                        onSaved: (val){
                                          rejectionReason = val;
                                          setState(() {

                                          });
                                        },
                                        alignLabelWithHint: true,
                                        //focusNode: aboutNode,
                                        controller: reasonTxtController,
                                        // helperText:"",
                                        // helperTextStyle: TextStyle(
                                        //   color: const Color(0xff828282),
                                        //   fontFamily: Constant.latoRegular,
                                        //   fontWeight: FontWeight.w400,
                                        //   fontSize: 10,
                                        //   fontStyle: FontStyle.italic,
                                        // ),
                                        validation: (String arg) {
                                          if (arg.length > 0) {
                                            /*if (ValidationWidget.isName(arg)) {
                                                              return null;
                                                            } else {
                                                              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
                                                            }*/
                                            return null;
                                          } else {
                                            return MessageConstant.ENTER_PARTNER_REJECTION;
                                          }
                                        },
                                      ),

                                    ),

                                  ),


                                ],
                              ),
                            ),
                          )),
                    ), () {

                  Navigator.pop(context);
                },
                    bottomNavigation: Container(
                        child: Padding(
                            padding: EdgeInsets.only(
                                left: 20.0, top: 0.0, right: 20.0, bottom: 40.0),
                            child: Stack(
                              children: <Widget>[
                                Container(
                                    height: 44.0,
                                    width: double.infinity,
                                    child: FlatButton(
                                      onPressed: () async {
                                        //callZip();
                                        // callApiToValidateTheaReferalCode('');
                                        //
                                        if (_companyProfileFormKey.currentState.validate()) {
                                        _companyProfileFormKey.currentState.save();
                                            Navigator.pop(context);
                                            apiCallApprovePartner(false);
                                           }
                                        },

                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(10)),
                                      color: AppConstants.colorStyle.lightBlue,
                                      child: Row(
                                        // Replace with a Row for horizontal icon + text
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: <Widget>[
                                          Text("Add",
                                              style: AppConstants.txtStyle
                                                  .heading18600LatoRegularWhite
                                          ),
                                        ],
                                      ),
                                    )),

                              ],
                            ))),
                    isShowExplanation: true,isShowIcon: false
                );
              });
        }).then((value) => (value) {});
  }


  showRejectionAlert() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 280.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 235.0,///145
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Form(
                                              key: _companyProfileFormKey,
                                              child:  Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Account not approved",
                                                      textAlign: TextAlign.left,
                                                      //maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontWeight: FontWeight.w600,
                                                          fontFamily: Constant.latoMedium),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets.only(top: 10.0,bottom: 20.0),
                                                      child:  Text(
                                                        "Please enter reason(s) for rejecting the account.",
                                                        textAlign: TextAlign.left,
                                                        maxLines: 5,
                                                        style:  TextStyle(
                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                            height: 1.2,
                                                            fontSize: 12.0,
                                                            fontWeight: FontWeight.w400,
                                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                      ),
                                                    ),
                                                    Container(
                                                      decoration:  BoxDecoration(
                                                        color:  Color(0xffFEFEFE),
                                                        border:  Border.all(
                                                            color:  ColorValues.BORDER_COLOR, width: 1.0), ),
                                                      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 12.0),
                                                      child:  TextFormField(
                                                        controller: reasonTxtController,
                                                        keyboardType: TextInputType.text,
                                                        maxLines: 4,

                                                        textInputAction: TextInputAction.done,
                                                        focusNode: _reasonFocus,
                                                        onFieldSubmitted: (term) {
                                                          //_fieldFocusChange(context, _emailFocus, _passwordFocus);
                                                        },
                                                        validator: (String arg) {
                                                          if (arg.length > 0) {
                                                            /*if (ValidationWidget.isName(arg)) {
                                                              return null;
                                                            } else {
                                                              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
                                                            }*/
                                                            return null;
                                                          } else {
                                                            return MessageConstant.ENTER_PARTNER_REJECTION;
                                                          }
                                                        },

                                                        onSaved: (val) => rejectionReason = val,
                                                        cursorColor: Constant.CURSOR_COLOR,
                                                        style:  TextStyle(color: Color(0xff000000), fontFamily: Constant.TYPE_CUSTOMREGULAR,fontSize: 16,fontWeight: FontWeight.w400),
                                                        decoration:  InputDecoration(

                                                            contentPadding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                          border: InputBorder.none,
                                                          //hintText: "Type reason here",
                                                          hintText: "",
                                                          hintStyle:  TextStyle(color: Color(0xff000000), fontFamily: Constant.TYPE_CUSTOMREGULAR,fontSize: 16,fontWeight: FontWeight.w400),
                                                        ),

                                                      ),
                                                    ),

                                                  ]),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color: ColorValues.GREY__COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              //Navigator.of(context, rootNavigator: true).pop('dialog');

                                                Navigator.pop(context);
                                                reasonTxtController.text = '';

                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Submit",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
    if (_companyProfileFormKey.currentState.validate()) {
      _companyProfileFormKey.currentState.save();
      Navigator.pop(context);
      apiCallApprovePartner(false);
    }
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

}


