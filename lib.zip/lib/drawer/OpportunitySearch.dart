import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';

import 'package:spike_view_project/home/OpportunityDetaill.dart';

import 'package:spike_view_project/modal/OpportunityCategoryModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';

import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class OpportunitySearch extends StatefulWidget {
  String text;
  String pageName;

  OpportunitySearch(this.text, {this.pageName});

  @override
  State<StatefulWidget> createState() {
    return OpportunitySearchState();
  }
}

class OpportunitySearchState extends State<OpportunitySearch> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController _searchQuery = TextEditingController(text: "");
  bool _IsSearching;
  String _searchText = "", previousText = "";
  SharedPreferences prefs;
  String userIdPref, token, roleId;
  bool isParent = false;
  int previousLength = 0;
  String categoryType = "";
  List<OpportunityModelForFeed> _mOpportunityModelList = List();
  List<OpportunityCategory> searchFilterNameList = List();
  int offset = 0;
  bool isApiCalling = false;
  bool isApiCallingLoader = true;
  bool isLoadMore = true;
  UploadMedia uploadMedia;

  bool isCategoryClicked = false;

  Future filterList() async {
    try {
      Response response = await ApiCalling()
          .apiCall(context, Constant.ENDPOINT_OPPORTUNITY_CATEGORY, "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];

          if (status == "Success") {
            searchFilterNameList.clear();
            OpportunityCategoryModel model =
                OpportunityCategoryModel.fromJson(response.data);
            print(
                "response++++categoryList+++" + model.categoryList.toString());
            searchFilterNameList.addAll(model.categoryList);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForFrindList2(String searchText) async {
    try {
      setState(() {
        isApiCallingLoader = true;
      });
      previousText = _searchQuery.text;
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_SEARCH_RESKIN_OPPORTUNITY +
              searchText + //_searchQuery.text.toString() +
              "&like=true" +
              "&category=" +
              categoryType +
              "&skip=" +
              offset.toString() +
              "&limit=10" +
              "&userId=" +
              userIdPref +
              "&roleId=" +
              roleId +
              "&opportunityId=",
          "get");

      isApiCalling = false;

      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var result = response.data['result'];
            _mOpportunityModelList.clear();
            var opportunityListMap = result['data'] as List;
            if (opportunityListMap.length > 0) {
              _mOpportunityModelList =
                  ParseJson.parseOpportunity(opportunityListMap, userIdPref);
            }
            if (_mOpportunityModelList.length == 0) {
              setState(() {
                isLoadMore = false;
              });
            }
            if (_mOpportunityModelList.length > 0) {
              setState(() {});
            }
          }
        }
      }
      isApiCalling = false;

      setState(() {
        isApiCalling;
        isApiCallingLoader = false;
      });
    } catch (e) {
      isApiCalling = false;
      setState(() {
        isApiCallingLoader = false;
      });

      e.toString();
    }
  }

  Future apiCallingLoadMore() async {
    try {
      previousText = _searchQuery.text;
      /* Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SEARCH_RESKIN_OPPORTUNITY +
              _searchQuery.text.toString() +
              "&like=true" +
              "&skip=" +
              offset.toString() +
              "&limit=10" +
              "&opportunityId=",
          "get");*/
      Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SEARCH_RESKIN_OPPORTUNITY +
              _searchQuery.text.toString() +
              "&like=true" +
              "&category=" +
              categoryType +
              "&skip=" +
              offset.toString() +
              "&limit=10" +
              "&userId=" +
              userIdPref +
              "&roleId=" +
              roleId +
              "&opportunityId=",
          "get");
      isApiCalling = false;
      setState(() {});

      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var result = response.data['result'];

            var opportunityListMap = result['data'] as List;
            List<OpportunityModelForFeed> _Loacl =
                List<OpportunityModelForFeed>();
            if (opportunityListMap.length > 0) {
              _Loacl =
                  ParseJson.parseOpportunity(opportunityListMap, userIdPref);
            }
            if (_Loacl.length == 0) {
              setState(() {
                isLoadMore = false;
              });
            }
            if (_Loacl.length > 0) {
              setState(() {
                _mOpportunityModelList.addAll(_Loacl);
              });
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {});
    } catch (e) {
      isApiCalling = false;
      setState(() {});
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    isParent = prefs.getBool("isParent");

    if (isParent == null) {
      isParent = false;
    }
    await filterList();
    apiCallingForFrindList2("");
    getOppoId();
    //anaylytics.setCurrentSreen(ScreenNameConstant.search_opportunity);
  }

  ScrollController _controller = ScrollController();

  _scrollListener() {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_controller.offset >= _controller.position.maxScrollExtent &&
        !_controller.position.outOfRange) {
      ++offset;
      if (isLoadMore) apiCallingLoadMore();
    }
  }

  @override
  void initState() {
    uploadMedia = UploadMedia(context);
    _controller = ScrollController();
    _controller.addListener(_scrollListener);
    _searchQuery.text = widget.text;
    getSharedPreferences();
    _IsSearching = false;
    _searchQuery.addListener(() {
      isApiCalling = false;
      setState(() {

      });
      if (_searchQuery.text.isEmpty) {
        setState(() {
          isApiCalling = false;
          _IsSearching = false;
          isLoadMore = true;
          _searchText = "";
        });
      } else {
        if (_searchQuery.text.trim().length >= 1) {
          if (previousText != _searchQuery.text) {
            Timer _timer = Timer(const Duration(milliseconds: 1000), () {
              previousText = _searchQuery.text;
              isApiCalling = true;
              isLoadMore = true;
              setState(() {
                _mOpportunityModelList.clear();

              });
              apiCallingForFrindList2("");
              setState(() {
                _IsSearching = true;
                _searchText = _searchQuery.text;
              });
            });
          }
          _searchQuery.clear();
        } else {
          isApiCalling = false;
        }
      }
    });
    super.initState();
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
      child: SizedBox(
        width: 106.0,
        height: 146.0,
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.contain,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return SizedBox(
      width: 106.0,
      height: 146.0,
      child: Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.contain,
        ),
      ),
    );
  }

  Future<File> getData(path, int index) async {
    return await UploadMedia
        .getThumbnailFromUrl(Constant.IMAGE_PATH + path);

  }

  List<InkWell> _buildOpportunityList() {
    return List.generate(_mOpportunityModelList.length, (int index) {
      return InkWell(
        child: PaddingWrap.paddingfromLTRB(
            0.0,
            16.0,
            0.0,
            0.0,
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Container(
                color: ColorValues.SELECTION_BG,
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Stack(
                            children: [
                              _mOpportunityModelList[index]
                                  .assestVideoAndImage
                                  .length >
                                  0
                                  ? _mOpportunityModelList[index]
                                  .assestVideoAndImage[0]
                                  .type ==
                                  "video" ||
                                  _mOpportunityModelList[index]
                                      .assestVideoAndImage[0]
                                      .tag ==
                                      "video"
                                  ? Container(
                                width: 106.0,
                                height: 146.0,
                                color: Colors.black,
                                child: FutureBuilder(
                                    future: getData(
                                        _mOpportunityModelList[
                                        index]
                                            .assestVideoAndImage[0]
                                            .file,
                                        index),
                                    builder: ( context, image) {
                                      if (image.hasData && image.data != null) {
                                        return Container(
                                            width: 106.0,
                                            height: 146.0,
                                            child: Image.file(
                                              image.data,
                                              fit: BoxFit.contain,
                                            ),
                                        ); // image is ready
                                      } else {
                                        return CachedNetworkImage(
                                          width: 106.0,
                                          height: 146.0,
                                          imageUrl: "",
                                          fit: BoxFit.fill,
                                          placeholder: (context,
                                              url) =>
                                              _loader(context,
                                                  "assets/aerial/default_img.png"),
                                          errorWidget: (context,
                                              url, error) =>
                                              _error(
                                                  "assets/aerial/default_img.png"),
                                        ); // placeholder
                                      }
                                    }),
                              )
                                  : Container(
                                color: Colors.black,
                                child: CachedNetworkImage(
                                  width: 106.0,
                                  height: 146.0,
                                  imageUrl: Constant.IMAGE_PATH +
                                      _mOpportunityModelList[index]
                                          .assestVideoAndImage[0]
                                          .file,
                                  fit: BoxFit.fitHeight,
                                  placeholder: (context, url) =>
                                      _loader(context,
                                          "assets/aerial/default_img.png"),
                                  errorWidget: (context, url,
                                      error) =>
                                      _error(
                                          "assets/aerial/default_img.png"),
                                ),
                              )
                                  : CachedNetworkImage(
                                width: 106.0,
                                height: 146.0,
                                imageUrl: "",
                                fit: BoxFit.fitHeight,
                                placeholder: (context, url) => _loader(
                                    context,
                                    "assets/aerial/default_img.png"),
                                errorWidget: (context, url, error) =>
                                    _error(
                                        "assets/aerial/default_img.png"),
                              ),
                              Container(
                                width: 106.0,
                                height: 146.0,
                                color: Colors.black.withOpacity(.2),
                              ),
                              Positioned(
                                bottom: 0.0,
                                left: 0.0,
                                right: 0.0,
                                child: _mOpportunityModelList[index]
                                    .assestVideoAndImage
                                    .length >
                                    1
                                    ? Center(
                                    child: Image.asset(
                                      "assets/newDesignIcon/three_dots.png",
                                      height: 20,
                                      width: 30.0,
                                      color: Colors.white,
                                    ))
                                    : Container(
                                  height: 0.0,
                                ),
                              )
                            ],
                          ),
                          flex: 0,
                        ),
                       Expanded(
                         child:
                          Padding(
                            padding:
                            const EdgeInsets.fromLTRB(10.0, 10.0, 0, 0.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                BaseText(
                                  text: _mOpportunityModelList[index]
                                      .category ==
                                      "Services" ||
                                      _mOpportunityModelList[index]
                                          .category ==
                                          "Programs"
                                      ? _mOpportunityModelList[index]
                                      .serviceTitle
                                      .replaceAll("null", "")
                                      : _mOpportunityModelList[index]
                                      .jobTitle
                                      .replaceAll("null", ""),
                                  textColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  textAlign: TextAlign.start,
                                ),
                                const SizedBox(height: 10,),
                                BaseText(
                                  text: _mOpportunityModelList[index].name +
                                      " | " +
                                      _mOpportunityModelList[index].category,
                                  textColor: ColorValues.labelColor,
                                  fontFamily:
                                  AppConstants.stringConstant.latoRegular,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  textAlign: TextAlign.start,
                                ),

                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 10.0, 0, 0
                                  ),
                                  child: BaseText(
                                    text: _mOpportunityModelList[index]
                                        .offerId ==
                                        "1" ||
                                        _mOpportunityModelList[index]
                                            .offerId ==
                                            "2" ||
                                        _mOpportunityModelList[index]
                                            .offerId ==
                                            "3"
                                        ? _mOpportunityModelList[index]
                                        .project
                                        : _mOpportunityModelList[index]
                                        .offerId ==
                                        "5" ||
                                        _mOpportunityModelList[index]
                                            .offerId ==
                                            "4"
                                        ? _mOpportunityModelList[index]
                                        .serviceDesc
                                        : _mOpportunityModelList[index]
                                        .description,
                                    textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily: AppConstants
                                        .stringConstant.latoMedium,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    textAlign: TextAlign.start,
                                    maxLines: 4,
                                  ),
                                ),
                                //const SizedBox(height: 10,),

                              ],
                            ),
                          ),
                          flex: 1,
                        ),
                      ],
                    )),
              ),
            )),
        onTap: () {
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) => OpportunityDetaill(
                  _mOpportunityModelList[index].opportunityId,
                  roleId,
                  _searchQuery.text.toString(),
                  categoryType)));
        },
      );
    });
  }

  Widget getSearchFilterView() {
    return Container(
      color: ColorValues.WHITE,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 0, 5, 10),
        child: Row(
          children: [
            Expanded(
              child: Padding(
                padding:
                const EdgeInsets.only(top: 12.0, left: 0.0, right: 0.0),
                child: Center(
                  child: Container(
                    height: 35.0,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: List.generate(searchFilterNameList.length,
                              (int index) {
                            return InkWell(
                                onTap: () {
                                  setState(() {
                                    isCategoryClicked = true;
                                    if (categoryType ==
                                        searchFilterNameList[index]
                                            .oppCategoryId
                                            .toString()) {
                                    } else {
                                      categoryType = searchFilterNameList[index]
                                          .oppCategoryId
                                          .toString();
                                    }
                                    offset = 0;
                                    apiCallingForFrindList2("");
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 0.0, right: 0.0),
                                  child: Container(
                                    height: 35.0,
                                    decoration: BoxDecoration(
                                      color: categoryType ==
                                          searchFilterNameList[index]
                                              .oppCategoryId
                                              .toString()
                                          ? ColorValues.DARK_YELLOW
                                          : ColorValues.SELECTION_BG,
                                      border: Border.all(
                                          color: categoryType ==
                                              searchFilterNameList[index]
                                                  .oppCategoryId
                                                  .toString()
                                              ? ColorValues.DARK_YELLOW
                                              : ColorValues.BORDER_COLOR_NEW,
                                          width: 1.0),
                                      borderRadius: index == 0
                                          ? BorderRadius.only(
                                          topLeft:
                                          const Radius.circular(10.0),
                                          bottomLeft:
                                          const Radius.circular(10.0))
                                          : (searchFilterNameList.length - 1) ==
                                          index
                                          ? BorderRadius.only(
                                          topRight:
                                          const Radius.circular(10.0),
                                          bottomRight:
                                          const Radius.circular(10.0))
                                          : BorderRadius.only(
                                          topLeft:
                                          const Radius.circular(0.0),
                                          bottomLeft:
                                          const Radius.circular(0.0)),
                                    ),
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            8.0, 0, 8, 0),
                                        child: Text(
                                          searchFilterNameList[index].name,
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500,
                                              color: categoryType ==
                                                  searchFilterNameList[index]
                                                      .oppCategoryId
                                                      .toString()
                                                  ? Colors.white
                                                  : ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontFamily: Constant.latoMedium),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                  ),
                                ));
                          }),
                    ),
                  ),
                ),
              ),
              flex: 1,
            )
          ],
        ),
      ),
    );
  }

  Widget appBar() {
    return Container(
      margin: EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          BaseText(
            text: 'Opportunity',
            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
            fontFamily: AppConstants.stringConstant.latoMedium,
            fontWeight: FontWeight.w700,
            fontSize: 28,
            maxLines: 1,
          ),
          SizedBox(height: 4),
          BaseText(
            text: 'Go ahead and embellish!',
            textColor: ColorValues.labelColor,
            fontFamily: AppConstants.stringConstant.latoRegular,
            fontWeight: FontWeight.w400,
            fontSize: 16,
            maxLines: 1,
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return WillPopScope(
        onWillPop: () {
          FocusScope.of(context).requestFocus(new FocusNode());
          backCalled();
          return Future.value(false);
        },
        child: Scaffold(
            key: _scaffoldKey,
            resizeToAvoidBottomInset: false,
            backgroundColor: ColorValues.WHITE,
            appBar: AppBar(
              automaticallyImplyLeading: false,
              elevation: 0,
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              titleSpacing: 20,
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    child: SizedBox(
                      height: 32.0,
                      width: 32.0,
                      child: Center(
                          child: Image.asset(
                              "assets/new_onboarding/back_blue_icon.png",
                              height: 32.0,
                              width: 32.0,
                              fit: BoxFit.fitHeight)),
                    ),
                    onTap: () => Navigator.pop(context),
                  ),
                  const HelpButtonWidget(),
                ],
              ),
            ),
            body: _mOpportunityModelList.length > 0
                ? Container(
                    margin: EdgeInsets.only(top: 15, left: 20, right: 20),
                    color: ColorValues.WHITE,
                    child: ListView(
                      controller: _controller,
                      padding: EdgeInsets.zero,
                      children: <Widget>[
                        appBar(),
                        getSearchFilterView(),
                        Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: _buildOpportunityList())
                      ],
                    ),
                  )
                : isApiCalling
                    ? Container(
                        margin: EdgeInsets.only(top: 25, left: 20, right: 20),
                        color: ColorValues.WHITE,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            appBar(),
                            getSearchFilterView(),
                            PaddingWrap.paddingAll(
                                10.0,
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation(
                                          Colors.black54),
                                      strokeWidth: 2.0,
                                    )
                                  ],
                                ))
                          ],
                        ),
                      )
                    : Container(
                        margin: EdgeInsets.only(top: 25, left: 20, right: 20),
                        color: ColorValues.WHITE,
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                          appBar(),
                          getSearchFilterView(),
                          isApiCallingLoader
                              ? Container()
                              : Container(
                                  color: Colors.white,
                                  child: Center(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            80.0,
                                            0.0,
                                            0.0,
                                            Image.asset(
                                              "assets/newDesignIcon/share/brifcase.png",
                                              width: 90,
                                              height: 90.0,
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            40.0,
                                            24.0,
                                            40.0,
                                            5.0,
                                            BaseText(
                                              text:
                                                  "Stay tuned! We’ll come back with some opportunities",
                                              textColor: Colors.black,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoMedium,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18,
                                              textAlign: TextAlign.center,
                                              maxLines: 3,
                                            )),
                                      ],
                                    ),
                                  ),
                                ),
                        ]),
                      )));
  }

  void backCalled() async {
    if (widget.pageName != null && widget.pageName == 'welcome') {
      Navigator.of(Constant.applicationContext)
          .popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
              builder: (context) => DashBoardWidget(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                  )));
    } else {
      Navigator.pop(context);
    }
  }

  void getOppoId() {
    for (int i = 0; i < _mOpportunityModelList.length; i++) {
      print(
          'getOppoId() index:::: $i, title::: ${_mOpportunityModelList[i].title}, url::: ${_mOpportunityModelList[i].url}');
    }
  }
}
