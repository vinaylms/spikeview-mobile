import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(),
        body: Stack(
          children: [
            Positioned(
              top: 27,
              left: 275,
              child: Image.asset('assets/Group 4527.png', height: 56, width: 56),
            ),
            Positioned(
              top: 50.98,
              left: 185,
              child: Image.asset('assets/Group 4528.png', height: 104.9, width: 85.96),
            ),
            Positioned(
              top: 184,
              left: 270,
              child: Image.asset('assets/Group 4529.png', height: 56, width: 56),
            ),
            Positioned(
              top: 243,
              left: 244,
              child: Image.asset('assets/Group 4530.png', height: 108.72, width: 102.12),
            ),
            Positioned(
              top: 141,
              left: 114,
              child: Center(
                child: Text('Explore Opportunity',
                    style: TextStyle(fontSize: 18, fontFamily: 'Nunito', fontWeight: FontWeight.w600, color: Colors.white)),
              ),
            ),
            Positioned(
              top: 351,
              left: 196,
              child: Center(
                child: Text('Reward Points',
                    style: TextStyle(fontSize: 18, fontFamily: 'Nunito', fontWeight: FontWeight.w600, color: Colors.white)),
              ),
            ),
            Positioned(
              top: 163,
              left: 87,
              child: Center(
                child: Text('Ac amet non adipiscing, vitae, habitasse.',
                    style: TextStyle(fontSize: 12, fontFamily: 'Nunito', fontWeight: FontWeight.w600, color: Colors.white)),
              ),
            ),
            Positioned(
              top: 373,
              left: 146,
              child: Center(
                child: Text('Ac amet non adipiscing, vitae, habitasse.',
                    style: TextStyle(fontSize: 12, fontFamily: 'Nunito', fontWeight: FontWeight.w600, color: Colors.white)),
              ),
            ),
          ],
        )
    );
  }
}
