import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/modal/LinkUrlModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:path/path.dart' as path;
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

// Create a Form Widget
class AddAchievmentForm extends StatefulWidget {
  List<Level3Competencies> level3Competencylist;
  String strCompetencyTypeId, strcompetencyTypeName;
  String sasToken, userId, dob, profilePicture, publicUrl;
  String level1Name;
  List<Level2Competencies> level2Competencylist;

  AddAchievmentForm(
      this.level1Name,
      this.level3Competencylist,
      this.strCompetencyTypeId,
      this.strcompetencyTypeName,
      this.sasToken,
      this.userId,
      this.dob,
      this.profilePicture,
      this.publicUrl,
      this.level2Competencylist);

  @override
  AddAchievmentFormState createState() {
    return AddAchievmentFormState();
  }
}

class AddAchievmentFormState extends State<AddAchievmentForm> with BaseCommonWidget {
  List<LinkUrlModel> linkUrlListData = [];
  bool isThirLevelField = true;
  bool isValidHeight = true;
  final _formKey = GlobalKey<FormState>();
  final _formKey2 = GlobalKey<FormState>();
  String strAchievement = "",
      strFromDate = "",
      strToDate = "",
      strName = "",
      strEmail = "",
      strTitle = "",
      strWorkingHours = "",
      strCoachLastName = "",
      strCoachFirstName = "",
      strRecommendationTitle = "",
      strRecommendationRequest = "",
      strRecommenderTitle = "",
      strCoachEmail = "",
      strWeight = "",
      strFootValue = "1\'",
      strInchValue = "0\"",
  strDeascription = "";

  final List<String> footList = [
    "1\'",
    "2\'",
    "3\'",
    "4\'",
    "5\'",
    "6\'",
    "7\'",
    "8\'",
    "9\'",
    "10\'",
  ].toList();
  final List<String> inchList = [
    "0\"",
    "1\"",
    "2\"",
    "3\"",
    "4\"",
    "5\"",
    "6\"",
    "7\"",
    "8\"",
    "9\"",
    "10\"",
    "11\"",
    "12\"",
  ].toList();
  static TextStyle styleForHeight = TextStyle(
      color: ColorValues.HEADING_COLOR_EDUCATION,
      fontSize: 18.0,
      fontFamily: Constant.TYPE_CUSTOMREGULAR);

  FocusNode workinHoursFocusNode = FocusNode();
  TextEditingController fromDateController, toDateController;
  TextEditingController descController = TextEditingController(text: "");
  TextEditingController titleController = TextEditingController(text: "");
  FocusNode weightFocusNode = FocusNode();
  TextEditingController personalReflectionController =
      TextEditingController(text: "");
  String strpersonalReflection = '';

  TextEditingController heightController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  List<AchievementImportanceModal> levelList = List();
  List<AcvhievmentSkillModel> skillList = List();
  List<Skill> skillsSelectedList = List();
  List<Level3Competencies> level3Competencylist = List();
  List<Assest> assestList = List();
  List<String> mediaList = List();
  List<String> certificateList = List();
  List<Assest> badgeAndTrophyList = List();
  Map<String, List<Level3Competencies>> competencyList = Map();
  int selectedIndexCover = 0;
  SharedPreferences prefs;
  Level3Competencies competencySelected;
  String userIdPref,
      userEmail,
      token,
      strCompetencyValue = "",
      strCompetencyId = "",
      strLevelValue = "",
      filterData = "",
      appliedFilter = "";
  Map<int, bool> filterStatus = Map();
  File imagePath;
  UploadMedia uploadMedia;
  AchievementImportanceModal levelSelected;
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "";
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<FileModel> mediaVideosList = List();
  List<String> mediaAndVideoList = List();

  BuildContext context;
  DateTime fromDate, toDate;
  bool isMedaiDialog = false;
  bool isShowMedia = true;
  bool isPrompt = false;
  ScrollController _controller = ScrollController();
  FocusNode _focus = FocusNode();
  DateTime startDate;
  bool isPresent = false;
  bool isPredefinedMediaSelected = true;
  List<String> imageList = List();
  TextEditingController secondLevelCompetencyController = TextEditingController();
  bool isOtherCategory = false;

  //=============

  //--------------------------Recommendation Info api ------------------
  Future mediaApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_MEDIA_ACCOM, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              imageList = ParseJson.parseMedia(response.data['result']);
              if (imageList != null) {
                setState(() {
                  imageList;
                  if (imageList.length > 0) {
                    mediaList.removeLast();
                    mediaList.add(imageList[0]);
                    mediaList.add("");
                  }
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallMaster() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_MASTER_DATA, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              skillList.clear();
              competencyList.clear();
              prefs.setString(
                  "skill", json.encode(response.data['result']['skills']));
              prefs.setString(
                  "level", json.encode(response.data['result']['importance']));

              prefs.setString("competencies",
                  json.encode(response.data['result']['competencies']));

              levelList = ParseJson.parseMapLevelList(
                  response.data['result']['importance']);
              skillList = ParseJson.parseMapSkillList(
                  response.data['result']['skills']);

              competencyList = ParseJson.parseMapMasterCompetency(
                  response.data['result']['competencies']);

              if (competencyList.length > 0) {
                level3Competencylist.clear();
                setState(() {
                  competencyList;

                  level3Competencylist =
                      competencyList[widget.strcompetencyTypeName];
                });
              }

              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }

              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      e.toString();
    }
  }

  Future apiCallLevelList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_LEVEL_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              prefs.setString("level", json.encode(response.data['result']));
              levelList = ParseJson.parseMapLevelList(response.data['result']);
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": widget.sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      return "";
    }
  }

  //--------------------------Api Call for skills ------------------
  Future apiCallSkill() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_SKILLS, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              skillList.clear();
              prefs.setString("skill", json.encode(response.data['result']));
              skillList = ParseJson.parseMapSkillList(response.data['result']);
              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      e.toString();
    }
  }

  //--------------------------Upload Acchievment Data ------------------

  bool validationCheck() {
    if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    } else if (appliedFilter == "") {
      return false;
    } else if (strLevelValue == "") {
      return false;
    } else if (strFromDate == "") {
      ToastWrap.showToast(MessageConstant.SELECT_FROM_DATE_VAL, context);
      return false;
    } else if (strToDate == "" && (!isPresent)) {
      ToastWrap.showToast(MessageConstant.SELECT_TO_DATE_VAL, context);
      return false;
    } else if (strCompetencyValue == "Other" &&
        thirdLevelController.text.trim().length == 0) {
      return false;
    }
    return true;
  }

  showSucessMsg(msg, context) {
    /*Timer _timer;

    _timer = Timer(const Duration(milliseconds: 3000), () async {
      Navigator.pop(context);
      //Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
*/
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            negativeText: 'OK',
            msg: msg,
            isSucessPopup: true,
            onNegativeTap: (){
            },
          );
        });
  }

  void conformationDialogForCommunityPost() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Do you want to publish this accomplishment to your public profile?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCalling(false);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCalling(true);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCalling(addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        mediaList.removeLast();
        //  badgeList.removeLast();
        certificateList.removeLast();
        badgeAndTrophyList.removeLast();
        mediaVideosList.removeLast();
        assestList.clear();
        for (var file in mediaList) {
          assestList.add(new Assest("image", "media", file, "", false));
        }

        for (FileModel item in mediaVideosList) {
          assestList.add(new Assest("video", "media", item.path, "", false));
        }

        for (var file in certificateList) {
          assestList.add(new Assest("image", "certificates", file, "", false));
        }

        for (var file in badgeAndTrophyList) {
          assestList.add(new Assest("image", file.tag, file.file, "", false));
        }

        if (linkUrlListData.length == 1 &&
            linkUrlListData[0].urlController.text.trim() == '') {
          //linkUrlListData[0].urlController.text.trim() == '';
          linkUrlListData.clear();
          print('linkUrlListData len::: ${linkUrlListData.length}');
        }

        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "height": heightController.text,
          "weight": weightController.text,
          "external_links":
              linkUrlListData.map((item) => item.toJson()).toList(),
          "achievementId": "",
          "competencyTypeId":
              widget.level1Name == "Sports" || widget.level1Name == "Arts"
                  ? strCompetencyId
                  : widget.strCompetencyTypeId,
          "level2Competency":
              widget.level1Name == "Sports" || widget.level1Name == "Arts"
                  ? secondLevelCompetencyController.text.toString()
                  : widget.strcompetencyTypeName,
          "level3Competency": strCompetencyValue,
          "focusArea": thirdLevelController.text,
          "userId": userIdPref,
          "badge": [],
          "certificate": [],
          "asset": assestList.map((item) => item.toJson()).toList(),
          "skills": skillsSelectedList.map((item) => item.toJson()).toList(),
          "title": strTitle,
          "description": strDeascription,
          "personalReflection": personalReflectionController.text.trim(),
          // "sheight": strHeight,
          // "sweight": strWeight,
          "fromDate": strFromDate,
          "toDate": strToDate,
          "importance": strLevelValue,

          "hoursWorkedPerWeek": strWorkingHours,
          "guide": {
            "promptRecommendation": isPrompt,
            "firstName": strCoachFirstName,
            "lastName": strCoachLastName,
            "email": strCoachEmail,

            "title": strRecommenderTitle,
            "recommenderTitle": strRecommendationTitle,
            "request": strRecommendationRequest,
          },
          "stories": "",
          "isActive": "true",
          "addIntoProfile": addIntoProfile
        };


        print("map++++" + map.toString());
        print("heightController++++" + heightController.text.toString());
        print("weightController++++" + weightController.text.toString());
        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              // showSucessMsg("Nice Work! You’ve successfully done something that makes you great.", context);
              if (isPrompt) {
                showSucessMsg(
                    MessageConstant
                        .SUCCESSFULLY_SEND_RECOMMENDATION_REQUEST_SUCCESS,
                    context);
              } else {
                showSucessMsg(
                    MessageConstant.SUCCESSFULLY_DONE_SOMETHING_SUCCESS,
                    context);
              }
              RewardStatus rewardStatus;
              if (!isPrompt)
                rewardStatus = RewardStatus.fromJson(
                    response.data['result']['rewardStatus']);
              else
                rewardStatus =
                    RewardStatus.fromJson(response.data['rewardStatus']);
              if (rewardStatus != null) {
                print('rewardStatus msg:: ${rewardStatus.msg}');
              } else
                print('rewardStatus obj:: ${rewardStatus}');
              await Util.showRewardPointPush(rewardStatus, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  getEditCategoryTextField(isEnabled, label, isEdit) {
    return Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 5.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          autofocus: isEnabled,
          maxLength: isEnabled
              ? TextLength.OTHER_MAX_LENGTH
              : TextLength.OTHER_COMPETENCY_MAX_LENGTH,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
          controller: isEnabled ? otherCategory : thirdLevelController,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              label, isEnabled ? "" : MessageConstant.FOCUS_AREA_HINT_TEXT),
          validator: (val) =>
              /*isEdit?
        val.trim().isEmpty||  val.trim()=="Other"||val.trim()=="General"?MessageConstant.ENTER_TITLE_VAL_CHANGE:null
              :*/
              val.trim().isEmpty
                  ? label == "Focus Area"
                      ? MessageConstant.FOCUS_AREA_VALIDATION
                      : widget.strcompetencyTypeName == "General"
                          ? MessageConstant.ENTER_TITLE_VAL_GENERAL_CHANGE
                          : MessageConstant.ENTER_TITLE_VAL_OTHER_CHANGE
                  : null,
        ));
  }

  competencySelectionDialog() {
    double heightItem = ((widget.level2Competencylist.length * 30.0) + 70.0);
    double systemHeight = MediaQuery.of(context).size.height - 150;
    if (heightItem > systemHeight) {
      heightItem = systemHeight;
    }
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 38.0,
                            child: Container(
                                height: heightItem,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    Container(
                                      height: heightItem - 30.0,
                                      color: Colors.transparent,
                                      child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              13.0, 0, 13, 0),
                                          child: Container(
                                            color: Colors.white,
                                            child: ListView(
                                              children: [
                                                Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: List.generate(
                                                        widget
                                                            .level2Competencylist
                                                            .length,
                                                        (int index) {
                                                      return InkWell(
                                                        onTap: () {
                                                          secondLevelCompetencyController
                                                                  .text =
                                                              widget
                                                                  .level2Competencylist[
                                                                      index]
                                                                  .name;
                                                          level3Competencylist = widget
                                                              .level2Competencylist[
                                                                  index]
                                                              .level3Competencylist;
                                                          competencySelected =
                                                              level3Competencylist[
                                                                  0];
                                                          strCompetencyValue =
                                                              level3Competencylist[
                                                                      0]
                                                                  .name;
                                                          strCompetencyId = widget
                                                              .level2Competencylist[
                                                                  index]
                                                              .competencyTypeId;
                                                          if (strCompetencyValue ==
                                                                  "Other" ||
                                                              strCompetencyValue ==
                                                                  "General") {
                                                            isOtherCategory =
                                                                true;

                                                            otherCategory =
                                                                TextEditingController(
                                                                    text: "");
                                                          } else {
                                                            isOtherCategory =
                                                                false;
                                                          }
                                                          setState(() {
                                                            competencySelected;
                                                            strCompetencyValue;
                                                            strCompetencyId;
                                                          });
                                                          setState(() {});
                                                          Navigator.pop(
                                                              context);
                                                          if (strCompetencyValue ==
                                                                  "Other" ||
                                                              strCompetencyValue ==
                                                                  "General") {
                                                            editCategoryDialog(
                                                                false,
                                                                true,
                                                                false);
                                                          }
                                                        },
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: [
                                                            PaddingWrap.paddingfromLTRB(
                                                                15.0,
                                                                10.0,
                                                                13.0,
                                                                10.0,
                                                                TextViewWrap.textView(
                                                                    widget
                                                                        .level2Competencylist[
                                                                            index]
                                                                        .name,
                                                                    TextAlign
                                                                        .center,
                                                                    ColorValues
                                                                        .HEADING_COLOR_EDUCATION,
                                                                    16.0,
                                                                    FontWeight
                                                                        .normal)),
                                                            widget.level2Competencylist
                                                                            .length -
                                                                        1 ==
                                                                    index
                                                                ? Container(
                                                                    height: 0.0,
                                                                  )
                                                                : CustomViews
                                                                    .getSepratorLine(),
                                                          ],
                                                        ),
                                                      );
                                                    }))
                                              ],
                                            ),
                                          )),
                                    )
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:
                                                      Constant.customRegular),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  editCategoryDialog(isEdit, isPortfolio, isCompulsary) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            top: 43.0,
                            child: Container(
                                height: 170.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        Container(
                                            height: 170.0,
                                            decoration: BoxDecoration(
                                              color: Colors.transparent,
                                              image: DecorationImage(
                                                image: AssetImage(
                                                    "assets/container.png"),
                                                fit: BoxFit.fill,
                                              ),
                                            ),
                                            padding: EdgeInsets.fromLTRB(
                                                13.0, 0, 13, 0),
                                            width: double.infinity,
                                            // color: Colors.white,
                                            child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  13.0, 0, 0, 0),
                                              child: Form(
                                                  key: _formKey2,
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: <Widget>[
                                                        isCompulsary
                                                            ? InkWell(
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                },
                                                                child:
                                                                    Container(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              13.0,
                                                                              5.0,
                                                                              0.0),
                                                                          child:
                                                                              Icon(
                                                                            Icons.close,
                                                                            color:
                                                                                ColorValues.search_error_text,
                                                                            size:
                                                                                20.0,
                                                                          )),
                                                                ))
                                                            : InkWell(
                                                                onTap: () {
                                                                  if (isPortfolio) {
                                                                    Navigator.pop(
                                                                        context);
                                                                    competencySelectionDialog();
                                                                  } else if (isEdit) {
                                                                    Navigator.pop(
                                                                        context);
                                                                  } else {
                                                                    Navigator.pop(
                                                                        context);
                                                                    Navigator.pop(
                                                                        context);
                                                                  }
                                                                },
                                                                child:
                                                                    Container(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              13.0,
                                                                              5.0,
                                                                              0.0),
                                                                          child:
                                                                              Icon(
                                                                            Icons.close,
                                                                            color:
                                                                                ColorValues.search_error_text,
                                                                            size:
                                                                                20.0,
                                                                          )),
                                                                )),
                                                        Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(0.0,
                                                                    0, 10, 0),
                                                            child: Container(
                                                              height: 84,
                                                              child: getEditCategoryTextField(
                                                                  true,
                                                                  widget.strcompetencyTypeName ==
                                                                          "General"
                                                                      ? MessageConstant
                                                                          .ENTER_GENERAL_DISPLAY_TITLE
                                                                      : MessageConstant
                                                                          .ENTER_OTHER_DISPLAY_TITLE,
                                                                  isCompulsary),
                                                            )),
                                                        Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(0.0,
                                                                    0, 10, 0),
                                                            child: InkWell(
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top:
                                                                            0.0,
                                                                        bottom:
                                                                            6.0),
                                                                child: Container(
                                                                    width: 80.0,
                                                                    height: 30.0,
                                                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    child: Center(
                                                                      child:
                                                                          Text(
                                                                        isCompulsary
                                                                            ? "UPDATE"
                                                                            : "ADD",
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                        style: TextStyle(
                                                                            color: Colors
                                                                                .white,
                                                                            fontSize:
                                                                                12.0,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                    )),
                                                              ),
                                                              onTap: () {
                                                                final form1 =
                                                                    _formKey2
                                                                        .currentState;

                                                                form1.save();
                                                                if (form1
                                                                    .validate()) {
                                                                  Navigator.pop(
                                                                      context);
                                                                  setState(() {
                                                                    strCompetencyValue =
                                                                        otherCategory
                                                                            .text;
                                                                  });
                                                                }
                                                              },
                                                            ))
                                                      ])),
                                            )))
                                  ],
                                )))
                      ],
                    )))));
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.userId;
    userEmail = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);
    if (widget.strcompetencyTypeName == "Other" ||
        widget.strcompetencyTypeName == "General") {
      editCategoryDialog(false, false, false);
    }

    // await apiCallLevelList();
    try {
      if (prefs.getString("competencies") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("competencies"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          competencyList.clear();
          competencyList = ParseJson.parseMapMasterCompetency(data);
          if (competencyList.length > 0) {
            level3Competencylist.clear();
            setState(() {
              competencyList;

              level3Competencylist =
                  competencyList[widget.strcompetencyTypeName];
            });
          }
        }
      }

      if (prefs.getString("level") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("level"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          levelList.clear();
          levelList = ParseJson.parseMapLevelList(data);
          if (levelList.length > 0) {
            setState(() {
              levelList;
            });
          }
        }
      }

      if (prefs.getString("skill") == null) {
        await apiCallMaster();
      } else {
        final skill = json.decode(prefs.getString("skill"));
        if (skill == null || skill.length == 0) {
          await apiCallMaster();
        } else {
          skillList.clear();
          skillList = ParseJson.parseMapSkillList(skill);
          if (skillList.length > 0) {
            for (int i = 0; i < skillList.length; i++) {
              filterStatus[i] = false;
            }
            setState(() {
              filterStatus;
              skillList;
            });
          }
        }
      }

      if (widget.level1Name == "Sports" || widget.level1Name == "Arts") {
      } else {
        if (level3Competencylist.length == 1) {
          competencySelected = level3Competencylist[0];
          strCompetencyValue = level3Competencylist[0].name;
          setState(() {
            competencySelected;
            strCompetencyValue;
          });
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      e.toString();
    }
    mediaApi(true);
    //await apiCallSkill();
    // await callApiForSaas();

    mediaList.add("");
    mediaVideosList.add(null);
    certificateList.add("");

    // badgeList.addAll(achivmentModel.badgeList);
    // badgeList.add("");

    badgeAndTrophyList.add(new Assest("image", "badges", "", "", false));

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    //anaylytics.setCurrentSreen(ScreenNameConstant.add_accomplishment);
  }

  void _onFocusChange() {
    debugPrint("Focus: " + _focus.hasFocus.toString());
  }

  TextEditingController otherCategory;
  TextEditingController thirdLevelController = TextEditingController(text: "");
  bool addSkillsError = false;
  bool selectAchivmentLevel = false;

  @override
  void initState() {
    level3Competencylist.addAll(widget.level3Competencylist);
    String date = widget.dob;

    if (widget.strcompetencyTypeName == "Other" ||
        widget.strcompetencyTypeName == "General") {
      isOtherCategory = true;
      strCompetencyValue = widget.strcompetencyTypeName;
      otherCategory = TextEditingController(text: "");
    }

    if (date != "" || date != null) {
      startDate = DateTime.fromMillisecondsSinceEpoch(int.parse(widget.dob));
    } else {
      startDate = DateTime.now();
    }
    descController.addListener(() {
      setState(() {
        descController.text.length;
      });
    });

    getSharedPreferences();
    uploadMedia = UploadMedia(context);
    _focus.addListener(_onFocusChange);

    linkUrlListData.add(LinkUrlModel(
        labelController: TextEditingController(),
        urlController: TextEditingController(),
        descController: TextEditingController()));
    //assestList.add(new Assest("b", "fv", "fvf", false));
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    this.context = context;
    final dropdownMenuCompetency = level3Competencylist
        .map((Level3Competencies item) => DropdownMenuItem<Level3Competencies>(
            value: item,
            child: Text(item.name,
                style: TextStyle(
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                ))))
        .toList();

    final dropdownMenuLevel = levelList
        .map((AchievementImportanceModal item) =>
            DropdownMenuItem<AchievementImportanceModal>(
                value: item,
                child: Text(item.title,
                    style: TextStyle(
                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                    ))))
        .toList();

    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );

      //final options = await getImageOptions(file: imageFile);
      var decodedImage = await decodeImageFromList(imageFile.readAsBytesSync());
      print(decodedImage.width);
      print(decodedImage.height);
      print(
          'Apurva image width: ${decodedImage.width}, height: ${decodedImage.height}');
      //final crop = cropKey.currentState;
// or
      /*final crop = Crop.of(context);
      //final scale = crop.scale;
      //final area = crop.area;
      //print('Apurva image width: ${decodedImage.width}, height: ${decodedImage.height}, crop.scale:: ${crop.scale}');
      imagePath = await ImageCrop.sampleImage(
        file: imageFile,
        preferredWidth: decodedImage.width,
        //preferredWidth: (decodedImage.width / crop.scale).round(),
        preferredHeight: decodedImage.height,
        //preferredHeight: (decodedImage.height / crop.scale).round(),

      );*/
    }

    //---------------------------------Skill Core Logic nd ui -----------------------
    void iterateFilters(key, value) {
      print('-------------$key:$value'); //string interpolation in action
      if (value) {
        if (key != 0) {
          if (filterData == "") {
            filterData = (key).toString();
            appliedFilter = skillList[key].title;

            skillsSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          } else {
            filterData = filterData + ", " + (key).toString();
            appliedFilter = appliedFilter + ",\n" + skillList[key].title;
            skillsSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          }
        }
      }
    }

    void onApplyClick() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      filterStatus.forEach(iterateFilters);
      setState(() {});
      FocusScope.of(context).requestFocus(new FocusNode());

      appliedFilter;

      Navigator.pop(context);
    }

    void onCancelTap() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      for (int i = 0; i < filterStatus.length; i++) {
        filterStatus[i] = false;
      }
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());

        appliedFilter;
      });
      Navigator.pop(context);
    }

    void conformationDialog(type, path) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Are you sure you want to delete?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "media") {
                                                  mediaList.remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    mediaList;
                                                    assestList;
                                                  });
                                                  if (mediaList.length == 1 &&
                                                      mediaVideosList.length ==
                                                          1) {
                                                    selectedIndexCover = 0;
                                                    mediaList.removeLast();
                                                    mediaList.add(imageList[0]);
                                                    mediaList.add("");
                                                    isPredefinedMediaSelected =
                                                        true;
                                                  }
                                                } else if (type == "video") {
                                                  mediaVideosList.remove(path);
                                                  //assestList.removeLast();
                                                  setState(() {
                                                    mediaVideosList;
                                                    //assestList;
                                                  });
                                                  if (mediaList.length == 1 &&
                                                      mediaVideosList.length ==
                                                          1) {
                                                    selectedIndexCover = 0;
                                                    mediaList.removeLast();
                                                    mediaList.add(imageList[0]);
                                                    mediaList.add("");
                                                    isPredefinedMediaSelected =
                                                        true;
                                                  }
                                                } else if (type ==
                                                    "certificate") {
                                                  certificateList.remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    certificateList;
                                                    assestList;
                                                  });
                                                } else {
                                                  badgeAndTrophyList
                                                      .remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    badgeAndTrophyList;
                                                    assestList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

//================== ==== ==== ==== ====== ==== ==== ==== === === ==== ============================

    //---------------------Add media View and core logics  ---------------------
    ontapApply(type) async {
      if (imagePath != null) {
        strAzureImageUploadPath = await uploadImgOnAzure(
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforPhoto);
        setState(() {
          strAzureImageUploadPath;
        });
        CustomProgressLoader.cancelLoader(context);
        if (strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") {
          if (type != "video")
            assestList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
          else
            assestList.add(new Assest(type, "media",
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));

          if (type == "media") {
            if (isPredefinedMediaSelected) {
              isPredefinedMediaSelected = false;
              mediaList.removeLast();
            }
            mediaList.removeLast();
            mediaList.add(strPrefixPathforPhoto + strAzureImageUploadPath);
            mediaList.add("");
          } else if (type == "certificates") {
            certificateList.removeLast();

            certificateList
                .add(strPrefixPathforPhoto + strAzureImageUploadPath);
            certificateList.add("");
          } else if (type == "badges") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "", false));
          } else if (type == "trophy") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "", false));
          }

          selectedImageType = "media";
          strAzureImageUploadPath = "";
          imagePath = null;
          setState(() {
            mediaList;
            isMedaiDialog = false;
            assestList;
            selectedImageType;
            strAzureImageUploadPath;
            imagePath;
          });
        }
      }
    }

    //------------------------Image Sewlection ---------------------------

    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();

    //  imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null && imagePath != "") {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          //  await _cropImage(imagePath);
          if (imagePath != null) {
            setState(() {
              imagePath;
            });

            CustomProgressLoader.showLoader(context);
            Timer _timer = Timer(const Duration(milliseconds: 400), () {
              ontapApply(type);
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    String getFileExtension2(File file) {
      return path.extension(file.path);
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      File file =
          await uploadMedia.compresssData(new File(imagePath), true, type);
      imagePath = file.path;

      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        if (type == "video") {
          mediaAndVideoList.add("");

          //final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(path);
          final thumbnailFile =
              await uploadMedia.getVideoThumbnailFromUrl(imagePath);
          //final thumbnailFile = await uploadMedia.getVideoThumbnailFromFile(path);

          print('view thumbnailFile:: ${thumbnailFile}');

          if (isPredefinedMediaSelected) {
            isPredefinedMediaSelected = false;
            /*mediaList.removeLast();
            mediaList.add("");*/
            mediaList.removeAt(0);
          }

          mediaVideosList.removeLast();
          mediaVideosList.add(new FileModel(
              thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
          mediaVideosList.add(null);
          setState(() {
            mediaVideosList;
          });
        } else if (type == "image") {
          mediaAndVideoList.add("");
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        } else {
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        }

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    onTapVideoAddButton() async {
      imagePath = await uploadMedia.pickVideoFromGallery();

      ///mediaVideo = await uploadMedia.pickVideoFromGallery();
      print('Apurva inside onTapVideoAddButton() imagePath:: imagePath' +
          imagePath.toString());

      if (imagePath != null) {
        if (imagePath != null &&
            getFileExtension2(imagePath) != null &&
            getFileExtension2(imagePath).length > 0) {
          CustomProgressLoader.showLoader(context);
          Timer _timer = Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "video");

            //ontapApply("video");
          });
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    final secondLevelCompetency = InkWell(
        onTap: () {
          competencySelectionDialog();
        },
        child: PaddingWrap.paddingfromLTRB(
            12.0,
            5.0,
            12.0,
            5.0,
            Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  color: Colors.white,
                  border: Border.all(
                    color: Color(0xFFFDEDEDE),
                    style: BorderStyle.solid,
                    width: 1.0,
                  ),
                ),
                child: Container(
                    padding: EdgeInsets.fromLTRB(13.0, 10.0, 13.0, 0.0),
                    margin: EdgeInsets.all(0.0),
                    child: TextFormField(
                      keyboardType: TextInputType.text,
                      controller: secondLevelCompetencyController,
                      maxLength: TextLength.TESTSCORE_DESC_MAX_LENGTH,
                      cursorColor: Constant.CURSOR_COLOR,
                      style: AppTextStyle.getDynamicStyleAddPortfolia(
                          ColorValues.HEADING_COLOR_EDUCATION,
                          null,
                          FontType.Regular),
                      /*TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
                      textCapitalization: TextCapitalization.sentences,
                      maxLines: null,
                      enabled: false,
                      decoration:
                          /*  BaseCommonWidget.textFormFieldDecorationAchievment("",
                          widget.level1Name == "Arts"
                          ? "Select Arts"
                          : "Select Sports"),*/
                          InputDecoration(
                        contentPadding: const EdgeInsets.fromLTRB(
                          0.0,
                          8.0,
                          5.0,
                          0.0,
                        ),
                        counterStyle:
                            TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        counterText: "",
                        enabledBorder: InputBorder.none,
                        disabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        hintText: widget.level1Name == "Arts"
                            ? "Select Arts"
                            : "Select Sports",
                        suffixIcon: Icon(Icons.arrow_drop_down),
                        hintStyle: TextStyle(
                            color: ColorValues.hintColor,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            fontSize: 16),
                        fillColor: Colors.transparent,
                      ),
                    )))));

    final competencyDropDownUi = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<Level3Competencies>(
                hint: Text(
                  "Focus Area",
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: competencySelected,
                items: dropdownMenuCompetency,
                onChanged: (Level3Competencies item) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    competencySelected = item;
                    strCompetencyValue = item.name;
                    if (strCompetencyValue == "Other") {
                      //   editCategoryDialogForOther(false);

                    }
                  });
                })));

    final competencyDropLevel = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<AchievementImportanceModal>(
                hint: Text(
                  widget.level1Name == "Life Experiences"
                      ? "Experiences Level"
                      : "Achievement Level",
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: levelSelected,
                items: dropdownMenuLevel,
                onChanged: (AchievementImportanceModal level) {
                  setState(() {
                    selectAchivmentLevel = false;
                    FocusScope.of(context).requestFocus(new FocusNode());
                    levelSelected = level;
                    strLevelValue = level.importanceId;
                  });
                })));

    final titleUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 20.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
          focusNode: _focus,
          controller: titleController,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
            color: ColorValues.HEADING_COLOR_EDUCATION,
          ),
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_TITLE, ''),
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_TITLE_VAL : null,
          onSaved: (val) => strTitle = val.trim(),
        ));

    final workingHours = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.number,
          maxLength: TextLength.WORKING_HOURS_MAX_LENGTH,
          focusNode: workinHoursFocusNode,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_HOURS_WORKED, ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            labelText: "",
            errorStyle: Util.errorTextStyle,
            counterText: "",
            labelStyle:
                 TextStyle(color:  ColorValues.GREY_TEXT_COLOR),
            fillColor: Colors.transparent,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),

          ),*/
          onSaved: (val) => strWorkingHours = val.trim(),
        ));

    final recommenderTitle = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_TITLE, "eg.Science Teacher"),
          /*InputDecoration(
            labelText: "Title",
            errorStyle: Util.errorTextStyle,
            hintText: "eg.Science Teacher",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? MessageConstant.ENTER_TITLE_VAL
                  : null
              : null,
          onSaved: (val) => strRecommenderTitle = val.trim(),
        ));

    final recommendationTitle = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          autofocus: true,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_RECOMMENDATION_TITLE, ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelText: "Recommendation Title",
            errorStyle: Util.errorTextStyle,
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? MessageConstant.ENTER_RECOMMENDATION_TITLE_VAL
                  : null
              : null,
          onSaved: (val) => strRecommendationTitle = val.trim(),
        ));

    final recommendationRequest = Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 15, 0, 0),
        child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(0),
              border: Border.all(
                color: Color(0xFFFDEDEDE),
                style: BorderStyle.solid,
                width: 1.0,
              ),
            ),
            padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child: TextFormField(
              keyboardType: TextInputType.multiline,
              cursorColor: Constant.CURSOR_COLOR,
              maxLength: TextLength.RECOMMENDATION_REQUEST_MSG_LENGTH,
              textCapitalization: TextCapitalization.sentences,
              maxLines: 3,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  MessageConstant.ADD_ACHIEVMENT_RECOMMENDATION_REQUEST,
                  MessageConstant.ADD_ACHIEVMENT_GREATE_SOCCER_SEASON),
              /*InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                hintText:
                    "Hi Coach, What a great soccer season. Can you please take a few min to recommend me on my soccer, leadership, and team building skills.",
                counterText: "",
                floatingLabelBehavior: FloatingLabelBehavior.always,
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 10.0),
                labelText: "Recommendation Request",
                errorStyle: Util.errorTextStyle,
                counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                fillColor: Colors.transparent,

              ),*/
              validator: (val) => val.trim().isEmpty
                  ? isPrompt
                      ? MessageConstant.ENTER_REQUEST_VAL
                      : null
                  : null,
              onSaved: (val) => strRecommendationRequest = val.trim(),
            )));

    final coachFirstName = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_FIRST_NAME,
              MessageConstant.ADD_ACHIEVMENT_FIRST_NAME),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelText: "First Name",
            errorStyle: Util.errorTextStyle,
            hintText: "First Name",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_FIRST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_FIRST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachFirstName = val.trim(),
        ));
    final coachLastName = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACHIEVMENT_LAST_NAME,
              MessageConstant.ADD_ACHIEVMENT_LAST_NAME),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelText: "Last Name",
            errorStyle: Util.errorTextStyle,
            hintText: "Last Name",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,

          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_LAST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_LAST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachLastName = val.trim(),
        ));

    bool isEmail(String em) {
      String emailRegexp =
          r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

      RegExp regExp = RegExp(emailRegexp);

      return regExp.hasMatch(em.trim());
    }

    final coachEmail = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.emailAddress,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),

          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_AACHIEVMENT_EMAIL, 'abc@xyz.com'),

          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_EMAIL_VAL
                      : val.toString().toLowerCase() == userEmail.toLowerCase()
                          ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
                          : !ValidationWidget.isEmail(val)
                              ? MessageConstant.VALID_EMAIL_VAL
                              : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_EMAIL_VAL
                  : val.toString().toLowerCase() == userEmail.toLowerCase()
                      ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
                      : !ValidationWidget.isEmail(val)
                          ? MessageConstant.VALID_EMAIL_VAL
                          : null,
          onSaved: (val) => strCoachEmail = val.trim(),
        ));

    final descriptrionUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: descController,
          maxLength: TextLength.TESTSCORE_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_AACHIEVMENT_DESCRIPTION,
              MessageConstant.ADD_AACHIEVMENT_HIGHLIGHT_KAY_LEARNING),

          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_DESCRIPTION_VAL : null,
          onSaved: (val) => strDeascription = val.trim(),
        ));

    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Future<Null> selectFromDate(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: fromDate == null ? DateTime.now() : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {},
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime != null) {
            fromDate = dateTime;
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime);
            print(date);
            setState(() {
              strFromDate = (dateTime.millisecondsSinceEpoch).toString();
              fromDateController = TextEditingController(text: date);
              toDateController = TextEditingController(text: "");
            });
          }
        },
      );
    }

    showHeight() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 38.0,
                              child: Container(
                                  height: 190.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 0, 13, 0),
                                        child: Container(
                                          color: Colors.white,
                                          height: 155.0,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  color: Colors.white,
                                                  height: 40.0,
                                                  child: Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          13.0, 8, 0, 0),
                                                      child: Text(
                                                        MessageConstant
                                                            .ADD_ACCOMPLISHMENT_HEIGHT,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            fontSize: 18.0,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR),
                                                      ))),
                                              Container(
                                                color: ColorValues.GREY__COLOR,
                                                height: 0.3,
                                              ),
                                              Container(
                                                  height: 113.0,
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                            Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              print(
                                                                  "CupertinoPicker Value+++++");
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strFootValue =
                                                                footList[
                                                                value];
                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:
                                                            List.generate(
                                                                footList
                                                                    .length,
                                                                    (int
                                                                index) {
                                                                  return Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                    child: Text(
                                                                      footList[
                                                                      index],
                                                                      style:
                                                                      styleForHeight,
                                                                    ),
                                                                  );
                                                                })),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                            Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strInchValue = inchList[
                                                                value];
                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:
                                                            List.generate(
                                                                inchList.length,
                                                                    (int
                                                                index) {
                                                                  return Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                    child: Text(
                                                                      inchList[
                                                                      index],
                                                                      style:
                                                                      styleForHeight,
                                                                    ),
                                                                  );
                                                                })),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  )),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                    MessageConstant.CANCEL,
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {


                                                Navigator.of(context,
                                                    rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                    MessageConstant
                                                        .ADD_ACCOMPLISHMENT_SAVE,
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                isValidHeight = true;

                                                heightController.text = strFootValue + strInchValue;
                                                Navigator.pop(context);
                                                setState(() {});
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final heightUi = InkWell(
        onTap: () {
          FocusScope.of(context).unfocus();
          showHeight();
        },
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
            margin: EdgeInsets.all(0.0),
            child: TextFormField(
                keyboardType: TextInputType.text,
                controller: heightController,
                maxLength: 10,
                cursorColor: Constant.CURSOR_COLOR,
                style: AppTextStyle.getDynamicStyleAddPortfolia(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    null,
                    FontType.Regular),
                /*TextStyle(
                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
                textCapitalization: TextCapitalization.sentences,
                maxLines: null,
                enabled: (!isValidHeight),
                onTap: () {
                  showHeight();
                },
                decoration:
                BaseCommonWidget.textFormFieldDecorationAccomplishment(
                    MessageConstant.ADD_ACCOMPLISHMENT_HEIGHT,
                    MessageConstant.ADD_ACCOMPLISHMENT_HEIGHT))));
    final weightUi = Container(
        padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.number,
          controller: weightController,
          focusNode: weightFocusNode,
          maxLength: 10,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              "Weight (in pounds)", ""),
          /* validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,*/
          onSaved: (val) => strWeight = val.trim(),
        ));

    final fromDateUi = InkWell(
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            child: TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              controller: fromDateController,
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  MessageConstant.ADD_AACHIEVMENT_DATE_FROM,
                  ""),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());

            selectFromDate(context);
          });
        });

    Future<Null> selectToDate(BuildContext context) async {
      DateTime dateTime2;
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: toDateController == null || toDateController.text == ""
            ? fromDate
            : toDate != null
                ? toDate
                : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime2 != null) {
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime2);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime2);
            print(date);
            var differenceStartDate = dateTime2.difference(fromDate);

            if (differenceStartDate.inDays >= 0) {
              toDate = dateTime2;

              setState(() {
                isPresent = false;
                strToDate = (dateTime2.millisecondsSinceEpoch).toString();
                toDateController = TextEditingController(text: date);
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.ENTER_CORRECT_DATE_RANGE_VAL, context);
            }
          }
        },
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          dateTime2 = dateTime;
        },
      );
    }

    final toDateUi = InkWell(
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            child: TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              controller: toDateController,
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  MessageConstant.ADD_AACHIEVMENT_DATE_TO,
                  ""),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
            if (fromDate != null) {
              selectToDate(context);
            } else {
              ToastWrap.showToast(
                  MessageConstant.SELECT_FROM_DATE_VAL, context);
            }
          });
        });

    _buildChoiceList() {
      List<Widget> choices = List();
      skillsSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.all(3.0),
            child: Row(
              children: <Widget>[
                Flexible(
                  child: Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyle.getDynamicStyleAddPortfolia(
                        ColorValues.HEADING_COLOR_EDUCATION,
                        16.0,
                        FontType
                            .Regular), /*TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
                  ),
                  flex: 1,
                ),
                Expanded(
                  child: InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                        Icon(
                          Icons.cancel,
                          color: ColorValues.BG_CIRCLE_COLOR,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        skillsSelectedList.remove(item);
                        filterStatus[item.index] = false;
                        filterStatus[0] = false;
                      });
                      filterData = "";
                      appliedFilter = "";
                      skillsSelectedList.clear();
                      filterStatus.forEach(iterateFilters);
                    },
                  ),
                  flex: 0,
                ),
              ],
            )));
      });
      return choices;
    }

    void selectSkillDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Center(
                          child: PaddingWrap.paddingAll(
                              10.0,
                              ListView(children: <Widget>[
                                Container(
                                    padding: EdgeInsets.all(0.0),
                                    color: Colors.white,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Container(
                                          color: Color(0XFFEDEDED),
                                          child: PaddingWrap.paddingfromLTRB(
                                              19.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Text(
                                                MessageConstant
                                                    .ADD_AACHIEVMENT_EACH_EXPERIENCE,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                        ),
                                        PaddingWrap.paddingfromLTRB(
                                            19.0,
                                            20.0,
                                            10.0,
                                            10.0,
                                            Text(
                                              MessageConstant
                                                  .ADD_AACHIEVMENT_SELECT_ALL_SKILLS,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  fontSize: 14.0,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            19.0,
                                            0.0,
                                            10.0,
                                            10.0,
                                            ListView.builder(
                                                // itemCount: myData.lenght(),
                                                shrinkWrap: true,
                                                itemCount: skillList.length,
                                                itemBuilder:
                                                    (BuildContext context,
                                                        int index) {
                                                  if ((skillList.length - 1) ==
                                                      index) {
                                                    return Column(
                                                      children: <Widget>[
                                                        InkWell(
                                                          child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          8.0,
                                                                          0.0,
                                                                          8.0),
                                                              child: Row(
                                                                children: <
                                                                    Widget>[
                                                                  filterStatus[
                                                                          index]
                                                                      ? Expanded(
                                                                          child: Padding(
                                                                              padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                              child: Image.asset(
                                                                                "assets/newDesignIcon/navigation/check.png",
                                                                                height: 20.0,
                                                                                width: 20.0,
                                                                              )),
                                                                          flex: 0)
                                                                      : Expanded(
                                                                          child: Padding(
                                                                              padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                              child: Image.asset(
                                                                                "assets/newDesignIcon/navigation/uncheck.png",
                                                                                height: 20.0,
                                                                                width: 20.0,
                                                                              )),
                                                                          flex: 0),
                                                                  Expanded(
                                                                      child:
                                                                          Text(
                                                                    skillList[
                                                                            index]
                                                                        .title,
                                                                    maxLines: 3,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            14.0,
                                                                        color: ColorValues
                                                                            .HEADING_COLOR_EDUCATION,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                                ],
                                                              )),
                                                          onTap: () {
                                                            bool value =
                                                                filterStatus[
                                                                    index];

                                                            if (index == 0) {
                                                              for (int i = 0;
                                                                  i <
                                                                      filterStatus
                                                                          .length;
                                                                  i++) {
                                                                if (value)
                                                                  filterStatus[
                                                                          i] =
                                                                      false;
                                                                else
                                                                  filterStatus[
                                                                      i] = true;
                                                              }
                                                            } else {
                                                              // filterStatus[0] = false; // Set All false
                                                              if (filterStatus[
                                                                  index]) {
                                                                filterStatus[
                                                                        index] =
                                                                    false;
                                                              } else {
                                                                filterStatus[
                                                                        index] =
                                                                    true;
                                                              }
                                                            }

                                                            // Refresh the All Check
                                                            int count = 0;
                                                            for (int i = 1;
                                                                i <
                                                                    filterStatus
                                                                        .length;
                                                                i++) {
                                                              if (!filterStatus[
                                                                  i]) count++;
                                                            }

                                                            if (count > 0) {
                                                              filterStatus[0] =
                                                                  false;
                                                            } else {
                                                              filterStatus[0] =
                                                                  true;
                                                            }

                                                            setState(() {
                                                              filterStatus;
                                                            });
                                                            Navigator.pop(
                                                                context);
                                                            selectSkillDialog();
                                                          },
                                                        ),
                                                        Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: <Widget>[
                                                            Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                15.0,
                                                                20.0,
                                                                0.0,
                                                                20.0,
                                                                InkWell(
                                                                  child: Text(
                                                                    MessageConstant
                                                                        .CANCEL,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            16.0,
                                                                        color: ColorValues
                                                                            .GREY_TEXT_COLOR),
                                                                  ),
                                                                  onTap: () {
                                                                    onCancelTap();
                                                                  },
                                                                ),
                                                              ),
                                                              flex: 0,
                                                            ),
                                                            Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                0.0,
                                                                20.0,
                                                                20.0,
                                                                20.0,
                                                                InkWell(
                                                                  child: Text(
                                                                    '',
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            16.0,
                                                                        color: ColorValues
                                                                            .GREY_TEXT_COLOR),
                                                                  ),
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            ),
                                                            Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                10.0,
                                                                20.0,
                                                                30.0,
                                                                20.0,
                                                                InkWell(
                                                                  child: Text(
                                                                    MessageConstant
                                                                        .ADD_AACHIEVMENT_DONE,
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                            16.0,
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR),
                                                                  ),
                                                                  onTap: () {
                                                                    print("filterData..." +
                                                                        filterData
                                                                            .toString());
                                                                    print("appliedFilter..." +
                                                                        appliedFilter
                                                                            .toString());
                                                                    print("skillsSelectedList..." +
                                                                        skillsSelectedList
                                                                            .toString());
                                                                    print("filterStatus..." +
                                                                        filterStatus
                                                                            .toString());
                                                                    bool
                                                                        checkFilterSrarus =
                                                                        false;
                                                                    for (int i =
                                                                            0;
                                                                        i < filterStatus.length;
                                                                        i++) {
                                                                      if (filterStatus[
                                                                              i] ==
                                                                          true) {
                                                                        checkFilterSrarus =
                                                                            true;
                                                                      }
                                                                      if (i ==
                                                                          8) {
                                                                        if (checkFilterSrarus) {
                                                                          onApplyClick();
                                                                        } else {
                                                                          ToastWrap.showToast(
                                                                              'Please select atleast one skill',
                                                                              context);
                                                                        }
                                                                      }
                                                                    }
                                                                  },
                                                                ),
                                                              ),
                                                              flex: 0,
                                                            ),
                                                          ],
                                                        )
                                                      ],
                                                    );
                                                  } else {
                                                    return InkWell(
                                                      child: Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  8.0),
                                                          child: Row(
                                                            children: <Widget>[
                                                              filterStatus[
                                                                      index]
                                                                  ? Expanded(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child: Image.asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0)
                                                                  : Expanded(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child: Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0),
                                                              Expanded(
                                                                  child: Text(
                                                                skillList[index]
                                                                    .title,
                                                                maxLines: 3,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION,
                                                                    fontWeight: skillList[index].title ==
                                                                            MessageConstant
                                                                                .ADD_AACHIEVMENT_SELECT_ALL
                                                                        ? FontWeight
                                                                            .bold
                                                                        : FontWeight
                                                                            .normal,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              )),
                                                            ],
                                                          )),
                                                      onTap: () {
                                                        bool value =
                                                            filterStatus[index];
                                                        if (index == 0) {
                                                          for (int i = 0;
                                                              i <
                                                                  filterStatus
                                                                      .length;
                                                              i++) {
                                                            if (value)
                                                              filterStatus[i] =
                                                                  false;
                                                            else
                                                              filterStatus[i] =
                                                                  true;
                                                          }
                                                        } else {
                                                          filterStatus[0] =
                                                              false;
                                                          if (filterStatus[
                                                              index]) {
                                                            filterStatus[
                                                                index] = false;
                                                          } else {
                                                            filterStatus[
                                                                index] = true;
                                                          }
                                                        }

                                                        // Refresh the All Check
                                                        int count = 0;
                                                        for (int i = 1;
                                                            i <
                                                                filterStatus
                                                                    .length;
                                                            i++) {
                                                          if (!filterStatus[i])
                                                            count++;
                                                        }

                                                        if (count > 0) {
                                                          filterStatus[0] =
                                                              false;
                                                        } else {
                                                          filterStatus[0] =
                                                              true;
                                                        }

                                                        setState(() {
                                                          filterStatus;
                                                        });
                                                        Navigator.pop(context);
                                                        selectSkillDialog();
                                                      },
                                                    );
                                                  }
                                                }))
                                      ],
                                    ))
                              ])))))));
    }

    void typeSelection() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child: Container(
                                  height: 160.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child: Text(
                                                            "Badge",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () async {
                                                        Navigator.pop(context);
                                                        var status =
                                                            await Permission
                                                                .photos.status;
                                                        if (status.isGranted) {
                                                          getImage("badges");
                                                        } else {
                                                          checkPermissionPhoto(
                                                              context);
                                                        }
                                                      },
                                                    ),
                                                    Container(
                                                      color: ColorValues
                                                          .BORDER_COLOR,
                                                      height: 1.0,
                                                    ),
                                                    InkWell(
                                                      child: Container(
                                                          height: 50.0,
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  13.0,
                                                                  0.0,
                                                                  13.0),
                                                          child: Text(
                                                            "Trophy",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: () async {
                                                        Navigator.pop(context);
                                                        var status =
                                                            await Permission
                                                                .photos.status;
                                                        if (status.isGranted) {
                                                          getImage("trophy");
                                                        } else {
                                                          checkPermissionPhoto(
                                                              context);
                                                        }
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    rectangleDecoration() {
      return BoxDecoration(
          border: Border.all(color: Palette.dividerColor), color: Colors.white);
    }

    showMediaFileWidget(double width, File image) {
      return Container(
        height: 54,
        width: width,
        decoration: rectangleDecoration(),
        margin: EdgeInsets.only(left: 0, right: 0),
        child: Image.file(
          image,
          fit: BoxFit.contain,
        ),
      );
    }

    final videoListUi = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaVideosList.map((file) {
        if (file == null) {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 80.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (mediaAndVideoList.length <= 9) {
                  onTapVideoAddButton();
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Container(
              child: Stack(
            children: <Widget>[
              showMediaFileWidget(80, file.file),
              Container(
                height: 54.0,
                width: 80.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              Container(
                  height: 54.0,
                  width: 80.0,
                  child: Center(
                      child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("video", file);
                          })
                    ],
                  ))),
            ],
          ));
        }
      }).toList(),
    ));

    final mediaImageListUI = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaList.map((path) {
        if (path == "") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 80.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () async {
                if (assestList.length <=
                    TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    getImage("media");
                  } else {
                    checkPermissionPhoto(context);
                  }
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Container(
              child: Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 80.0,
              ),
              Container(
                height: 54.0,
                width: 80.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              isPredefinedMediaSelected
                  ? Container(
                      height: 0.0,
                    )
                  : Container(
                      height: 54.0,
                      width: 80.0,
                      child: Center(
                          child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Image.asset(
                                    "assets/newDesignIcon/achievment/remove.png",
                                    width: 35.0,
                                    height: 35.0,
                                  )),
                              onTap: () {
                                conformationDialog("media", path);
                              })
                        ],
                      ))),
            ],
          ));
        }
      }).toList(),
    ));

    final certificateListUI = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: certificateList.map((path) {
        if (path == "") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 80.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () async {
                if (assestList.length <=
                    TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                  var status = await Permission.photos.status;
                  if (status.isGranted) {
                    getImage("certificates");
                  } else {
                    checkPermissionPhoto(context);
                  }
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path,
                height: 54.0,
                width: 80.0,
              ),
              Container(
                height: 54.0,
                width: 80.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              Container(
                  height: 54.0,
                  width: 80.0,
                  child: Center(
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                        InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              conformationDialog("certificate", path);
                            })
                      ]))),
            ],
          );
        }
      }).toList(),
    ));

    final trophyListUi = Container(
        child: GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: badgeAndTrophyList.map((path) {
        if (path.file == "") {
          return Stack(children: <Widget>[
            InkWell(
              child: Container(
                  height: 54.0,
                  width: 54.0,
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child: Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (assestList.length <=
                    TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                  typeSelection();
                  // getImage("trophy");
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + path.file,
                height: 54.0,
                width: 62.0,
              ),
              Container(
                height: 54.0,
                width: 62.0,
                color: Color(0XFFC0C0C0).withOpacity(.4),
              ),
              Container(
                  height: 54.0,
                  width: 80.0,
                  child: Center(
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                        InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                Image.asset(
                                  "assets/newDesignIcon/achievment/remove.png",
                                  width: 35.0,
                                  height: 35.0,
                                )),
                            onTap: () {
                              conformationDialog("badge", path);
                            })
                      ]))),
            ],
          );
        }
      }).toList(),
    ));

    void conformationForBack() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      MessageConstant
                                                          .LEAVEA_PAGE,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant
                                                    .ADD_AACHIEVMENT_CONTINUE,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    // Build a Form widget using the _formKey we created above
    return WillPopScope(
        onWillPop: () {
          if (titleController.text == "" ||
              titleController.text == null ||
              titleController.text == "null") {
            if (descController.text == "" ||
                descController.text == null ||
                descController.text == "null") {
              if (thirdLevelController.text == "" ||
                  thirdLevelController.text == null ||
                  thirdLevelController.text == "null") {
                if (strCompetencyValue == "") {
                  if (appliedFilter == "") {
                    if (strLevelValue == "") {
                      if (strFromDate == "") {
                        if (strToDate == "") {
                          Navigator.pop(context);
                        } else {
                          conformationForBack();
                        }
                      } else {
                        conformationForBack();
                      }
                    } else {
                      conformationForBack();
                    }
                  } else {
                    conformationForBack();
                  }
                } else {
                  conformationForBack();
                }
              } else {
                conformationForBack();
              }
            } else {
              conformationForBack();
            }
          } else {
            conformationForBack();
          }
        },
        child: GestureDetector(
            onTap: () {
              // FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                appBar: AppBar(
                  brightness: Brightness.light,
                  automaticallyImplyLeading: false,
                  titleSpacing: 0.0,
                  elevation: 0.0,
                  title: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        child: InkWell(
                          child: CustomViews.getBackButton(),
                          onTap: () {
                            if (titleController.text == "" ||
                                titleController.text == null ||
                                titleController.text == "null") {
                              if (descController.text == "" ||
                                  descController.text == null ||
                                  descController.text == "null") {
                                if (thirdLevelController.text == "" ||
                                    thirdLevelController.text == null ||
                                    thirdLevelController.text == "null") {
                                  if (strCompetencyValue == "") {
                                    if (appliedFilter == "") {
                                      if (strLevelValue == "") {
                                        if (strFromDate == "") {
                                          if (strToDate == "") {
                                            Navigator.pop(context);
                                          } else {
                                            conformationForBack();
                                          }
                                        } else {
                                          conformationForBack();
                                        }
                                      } else {
                                        conformationForBack();
                                      }
                                    } else {
                                      conformationForBack();
                                    }
                                  } else {
                                    conformationForBack();
                                  }
                                } else {
                                  conformationForBack();
                                }
                              } else {
                                conformationForBack();
                              }
                            } else {
                              conformationForBack();
                            }
                          },
                        ),
                        flex: 0,
                      ),
                      Expanded(
                        child: isOtherCategory
                            ? InkWell(
                                onTap: () {
                                  editCategoryDialog(true, false, true);
                                },
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      strCompetencyValue,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontSize: 18.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                                    Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            5.0, 0, 7, 1),
                                        child: Image.asset(
                                          "assets/newDesignIcon/userprofile/edit_grey.png",
                                          height: 16.0,
                                          width: 17.0,
                                        ))
                                  ],
                                ),
                              )
                            : Text(
                                widget.level1Name == "Sports" ||
                                        widget.level1Name == "Arts"
                                    ? "Accomplishment"
                                    : widget.strcompetencyTypeName,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: ColorValues.HEADING_COLOR_EDUCATION,
                                    fontSize: 18.0,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              ),
                        flex: 1,
                      )
                    ],
                  ),
                  actions: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              20.0,
                              0.0,
                              TextViewWrap.textView(
                                  MessageConstant.ADD_AACHIEVMENT_SAVE,
                                  TextAlign.start,
                                  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  16.0,
                                  FontWeight.normal)),
                          onTap: () {
                            // editCategoryDialog();

                            final form = _formKey.currentState;
                            form.save();

                            FocusScope.of(context).unfocus();
                            /* if (titleController.text == "" ||
                                descController.text == "" ||
                                strCompetencyValue == "" ||
                                appliedFilter == "" ||
                                strLevelValue == "") {
                              scrollTop();
                            } else {
                              if (strCoachFirstName != "" ||
                                  strCoachLastName != "" ||
                                  strCoachEmail != "") {
                                scrollBottom();
                              }
                            }*/
                            if (strCompetencyValue == "Other" &&
                                thirdLevelController.text.length > 0) {
                              setState(() {
                                isThirLevelField = true;
                              });
                            } else {
                              setState(() {
                                isThirLevelField = false;
                              });
                            }

                            if (appliedFilter == "") {
                              setState(() {
                                addSkillsError = true;
                              });
                            } else {
                              setState(() {
                                addSkillsError = false;
                              });
                            }

                            if (strLevelValue == "") {
                              setState(() {
                                selectAchivmentLevel = true;
                              });
                            } else {
                              selectAchivmentLevel = false;
                            }
                            if (form.validate()) {
                              if (validationCheck()) {
                                if (Util.dobCheck(widget.dob) &&
                                    widget.publicUrl != null &&
                                    widget.publicUrl != "null" &&
                                    widget.publicUrl != "") {
                                  conformationDialogForCommunityPost();
                                } else {
                                  /* if (otherCategory!=null&&otherCategory.text!=null&&(strCompetencyValue == "Other" ||
                                          strCompetencyValue == "General") &&
                                      (otherCategory.text.trim() ==
                                              "Other" ||
                                          otherCategory.text.trim() == "General")) {
                                    editCategoryDialog(true,false,true);
                                  } else {*/
                                  apiCalling(false);
                                  // }
                                }
                              }
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .ENTER_VALUE_ACCOMPLISHMENT_FIELD_VAL,
                                  context);
                            }
                          },
                        )
                      ],
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                body: Theme(
                    data: ThemeData(hintColor: Colors.grey[300]),
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                            top: 0.0,
                            left: 0.0,
                            bottom: 0.0,
                            right: 0.0,
                            child: FormKeyboardActions(
                                nextFocus: false,
                                keyboardActionsPlatform:
                                    KeyboardActionsPlatform.IOS,
                                //optional
                                keyboardBarColor: Colors.grey[200],
                                //optional
                                actions: [
                                  KeyboardAction(
                                    focusNode: workinHoursFocusNode,
                                  ),
                                ],
                                child: Column(
                                  children: <Widget>[
                                    CustomViews.getSepratorLine(),
                                    Expanded(
                                        child: ListView(
                                      controller: _controller,
                                      children: <Widget>[
                                        Form(
                                          key: _formKey,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                  22.0,
                                                  19.0,
                                                  22.0,
                                                  0.0,
                                                  Text(
                                                    widget.level1Name ==
                                                                "Sports" ||
                                                            widget.level1Name ==
                                                                "Arts"
                                                        ? "Add a memorable moment, activity, experience,  achievement, or a portfolio"
                                                        : //only for Sport and arts
                                                        "Add a memorable moment, activity, experience, or an achievement"
                                                    // for other
                                                    /*  widget.level1Name ==
                                                        "Life Experiences"
                                                    ? "Please provide details in the sections below to add a  experience"
                                                    : "Please provide details in the sections below to add a  accomplishment"*/
                                                    ,
                                                    style: TextStyle(
                                                        color:
                                                            Color(0XFF151515),
                                                        fontSize: 12.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )),
                                              widget.level1Name == "Sports" ||
                                                      widget.level1Name ==
                                                          "Arts"
                                                  ? PaddingWrap.paddingfromLTRB(
                                                      17.0,
                                                      10.0,
                                                      13.0,
                                                      0.0,
                                                      Text(
                                                        widget.level1Name ==
                                                                "Sports"
                                                            ? "Select Sports"
                                                            : "Select Arts",
                                                        style: TextStyle(
                                                            fontSize: 14.0,
                                                            color: ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR),
                                                      ))
                                                  : Container(height: 0.0),
                                              widget.level1Name == "Sports" ||
                                                      widget.level1Name ==
                                                          "Arts"
                                                  ? secondLevelCompetency
                                                  : Container(height: 0.0),
                                              Container(
                                                  color: ColorValues
                                                      .SCREEN_BG_COLOR,
                                                  child:
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                              12.0,
                                                              12.0,
                                                              12.0,
                                                              10.0,
                                                              Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: <
                                                                    Widget>[
                                                                  Container(
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      borderRadius: BorderRadius.circular(0),
                                                                      color: Colors
                                                                          .white,
                                                                      border:
                                                                          Border
                                                                              .all(
                                                                        color: Color(
                                                                            0xFFFDEDEDE),
                                                                        style: BorderStyle
                                                                            .solid,
                                                                        width:
                                                                            1.0,
                                                                      ),
                                                                    ),
                                                                    child: PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            14.0,
                                                                            0.0,
                                                                            5.0,
                                                                            10.0,
                                                                            Row(
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                Expanded(
                                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                                      0.0,
                                                                                      17.0,
                                                                                      15.0,
                                                                                      0.0,
                                                                                      Image.asset(
                                                                                        "assets/newDesignIcon/achievment/title.png",
                                                                                        width: 25.0,
                                                                                        height: 25.0,
                                                                                      )),
                                                                                  flex: 0,
                                                                                ),
                                                                                Expanded(
                                                                                  child: Column(
                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: <Widget>[
                                                                                      titleUi,
                                                                                      descriptrionUi,
                                                                                      //personalReflectionUi,
                                                                                    ],
                                                                                  ),
                                                                                  flex: 1,
                                                                                )
                                                                              ],
                                                                            )),
                                                                  ),
                                                                  PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  children: <Widget>[
                                                                                    Expanded(
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          10.0,
                                                                                          15.0,
                                                                                          0.0,
                                                                                          Image.asset(
                                                                                            "assets/newDesignIcon/achievment/competency.png",
                                                                                            width: 25.0,
                                                                                            height: 25.0,
                                                                                          )),
                                                                                      flex: 0,
                                                                                    ),
                                                                                    Expanded(
                                                                                      child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: <Widget>[
                                                                                          isOtherCategory
                                                                                              ? getEditCategoryTextField(false, "Focus Area", false)
                                                                                              : Column(
                                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                  children: [
                                                                                                    competencySelected == null
                                                                                                        ? Container(
                                                                                                            height: 10.0,
                                                                                                          )
                                                                                                        : PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel("Focus Area", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                                    secondLevelCompetencyController.text == "" && (widget.level1Name == "Sports" || widget.level1Name == "Arts")
                                                                                                        ? TextFormField(
                                                                                                            keyboardType: TextInputType.text,
                                                                                                            maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
                                                                                                            textCapitalization: TextCapitalization.sentences,
                                                                                                            cursorColor: Constant.CURSOR_COLOR,
                                                                                                            controller: thirdLevelController,
                                                                                                            style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                            validator: (val) => val.trim().isEmpty || val.length == 0 ? MessageConstant.FIELD_REQUIRED : null,
                                                                                                            decoration: BaseCommonWidget.textFormFieldDecorationAchievment("Focus Area", ""), /*InputDecoration(
                                                                                                              contentPadding: const EdgeInsets.fromLTRB(
                                                                                                                0.0,
                                                                                                                5.0,
                                                                                                                5.0,
                                                                                                                5.0,
                                                                                                              ),
                                                                                                              counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                              labelText: "Focus Area",
                                                                                                              errorStyle: Util.errorTextStyle,
                                                                                                              hintText: MessageConstant.FOCUS_AREA_HINT_TEXT,
                                                                                                              counterText: "",
                                                                                                              floatingLabelBehavior: FloatingLabelBehavior.always,
                                                                                                              labelStyle:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                              fillColor: Colors.transparent,
                                                                                                              enabledBorder: UnderlineInputBorder(
                                                                                                                borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                                                                                                              ),
                                                                                                              focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                                                                                                            ),*/
                                                                                                            //  ),
                                                                                                          )
                                                                                                        : competencyDropDownUi,
                                                                                                    strCompetencyValue == "Other"
                                                                                                        ? Padding(
                                                                                                            padding: const EdgeInsets.only(top: 15.0),
                                                                                                            child: Column(
                                                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                                                              children: [
                                                                                                                PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 5.0, getTextLabel("Other, please specify", 14.0, ColorValues.TEXT_LIGHT_GREY, FontWeight.normal)),
                                                                                                                Container(
                                                                                                                    width: double.infinity,
                                                                                                                    height: 30.0,
                                                                                                                    decoration: BoxDecoration(border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER)),
                                                                                                                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                                                                    margin: EdgeInsets.all(0.0),
                                                                                                                    child: TextFormField(
                                                                                                                      keyboardType: TextInputType.text,
                                                                                                                      controller: thirdLevelController,
                                                                                                                      maxLength: 25,
                                                                                                                      cursorColor: Constant.CURSOR_COLOR,
                                                                                                                      style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                                      textCapitalization: TextCapitalization.sentences,
                                                                                                                      decoration: InputDecoration(
                                                                                                                        counterText: "",
                                                                                                                        disabledBorder: InputBorder.none,
                                                                                                                        focusedBorder: InputBorder.none,
                                                                                                                        enabledBorder: InputBorder.none,
                                                                                                                        isDense: true,
                                                                                                                        // Added this
                                                                                                                        contentPadding: EdgeInsets.only(left: 5.0, top: 1.0, bottom: 0.0),
                                                                                                                        floatingLabelBehavior: FloatingLabelBehavior.always,
                                                                                                                      ),
                                                                                                                    )),
                                                                                                                isThirLevelField
                                                                                                                    ? Container(
                                                                                                                        height: 0.0,
                                                                                                                      )
                                                                                                                    : PaddingWrap.paddingfromLTRB(
                                                                                                                        0.0,
                                                                                                                        5.0,
                                                                                                                        0.0,
                                                                                                                        0.0,
                                                                                                                        Text(
                                                                                                                          MessageConstant.THIRD_LEVEL_REQUIRED,
                                                                                                                          style: TextStyle(color: ColorValues.ERROR_COLOR, fontSize: 12.0),
                                                                                                                        ))
                                                                                                              ],
                                                                                                            ),
                                                                                                          )
                                                                                                        : Container(height: 0.0),
                                                                                                  ],
                                                                                                ),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              20.0,
                                                                                              0.0,
                                                                                              5.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
                                                                                                      InkWell(
                                                                                                          child: TextViewWrap.textView(skillsSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skillsSelectedList.length == 0 ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.GREY_TEXT_COLOR, skillsSelectedList.length == 0 ? 16.0 : 13.0, FontWeight.normal),
                                                                                                          onTap: () {
                                                                                                            setState(() {
                                                                                                              addSkillsError = false;
                                                                                                            });
                                                                                                            if (skillsSelectedList.length == 0) selectSkillDialog();
                                                                                                          }),
                                                                                                      addSkillsError
                                                                                                          ? PaddingWrap.paddingfromLTRB(
                                                                                                              0.0,
                                                                                                              5.0,
                                                                                                              0.0,
                                                                                                              0.0,
                                                                                                              Text(
                                                                                                                MessageConstant.SELECT_SKILLS_VAL,
                                                                                                                maxLines: 1,
                                                                                                                style: TextStyle(fontSize: 12.0, color: ColorValues.ERROR_COLOR),
                                                                                                              ))
                                                                                                          : Container(
                                                                                                              height: 0,
                                                                                                            ),
                                                                                                    ]),
                                                                                                    flex: 1,
                                                                                                  )
                                                                                                ],
                                                                                              )),
                                                                                          Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: <Widget>[
                                                                                              Expanded(
                                                                                                child: Wrap(
                                                                                                  children: _buildChoiceList(),
                                                                                                ),
                                                                                                flex: 1,
                                                                                              ),
                                                                                              Expanded(
                                                                                                child: skillsSelectedList.length == 0
                                                                                                    ? Container(
                                                                                                        height: 0.0,
                                                                                                      )
                                                                                                    : InkWell(
                                                                                                        child: Container(
                                                                                                            height: 20.0,
                                                                                                            width: 40.0,
                                                                                                            child: Icon(
                                                                                                              Icons.add,
                                                                                                              color: Colors.black,
                                                                                                              size: 20.0,
                                                                                                            )),
                                                                                                        onTap: () {
                                                                                                          selectSkillDialog();
                                                                                                        },
                                                                                                      ),
                                                                                                flex: 0,
                                                                                              )
                                                                                            ],
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                      flex: 1,
                                                                                    )
                                                                                  ],
                                                                                )),
                                                                          )),
                                                                  PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  children: <Widget>[
                                                                                    Expanded(
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          10.0,
                                                                                          15.0,
                                                                                          0.0,
                                                                                          Image.asset(
                                                                                            "assets/newDesignIcon/achievment/achiewvement_level.png",
                                                                                            width: 25.0,
                                                                                            height: 25.0,
                                                                                          )),
                                                                                      flex: 0,
                                                                                    ),
                                                                                    Expanded(
                                                                                      child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: <Widget>[
                                                                                          /*skillUi,*/
                                                                                          levelSelected == null
                                                                                              ? Container(
                                                                                                  height: 10.0,
                                                                                                )
                                                                                              : PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel(widget.level1Name == "Life Experiences" ? "Experiences Level" : "Achievement Level", 12.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                          competencyDropLevel,
                                                                                          selectAchivmentLevel
                                                                                              ? PaddingWrap.paddingfromLTRB(
                                                                                                  0.0,
                                                                                                  5.0,
                                                                                                  0.0,
                                                                                                  0.0,
                                                                                                  Text(
                                                                                                    MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL,
                                                                                                    maxLines: 1,
                                                                                                    style: TextStyle(fontSize: 12.0, color: ColorValues.ERROR_COLOR),
                                                                                                  ))
                                                                                              : Container(
                                                                                                  height: 0,
                                                                                                ),
                                                                                          widget.strcompetencyTypeName == "Volunteering" ? workingHours : Container(height: 0.0),
                                                                                          widget.level1Name ==
                                                                                              "Sports"
                                                                                              ?
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              10.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[heightUi],
                                                                                                    ),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[weightUi],
                                                                                                    ),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                ],
                                                                                              )):Container(height: 0,),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              10.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[fromDateUi],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Container(),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[toDateUi],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                ],
                                                                                              )),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              8.0,
                                                                                              0.0,
                                                                                              8.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                                                mainAxisAlignment: MainAxisAlignment.end,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Container(),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Row(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[
                                                                                                        Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Image.asset(
                                                                                                              isPresent ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                                              width: 25.0,
                                                                                                              height: 25.0,
                                                                                                            ),
                                                                                                            onTap: () {
                                                                                                              if (isPresent)
                                                                                                                isPresent = false;
                                                                                                              else
                                                                                                                isPresent = true;
                                                                                                              setState(() {
                                                                                                                isPresent;
                                                                                                                toDate = null;
                                                                                                                strToDate = "";
                                                                                                                toDateController = TextEditingController(text: "");
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0,
                                                                                                        ),
                                                                                                        Expanded(
                                                                                                          child: Container(
                                                                                                            padding: EdgeInsets.fromLTRB(5.0, 3.0, 0.0, 0.0),
                                                                                                            child: Container(child: TextViewWrap.textView("Ongoing   ", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                                                          ),
                                                                                                          flex: 0,
                                                                                                        )
                                                                                                      ],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  )
                                                                                                ],
                                                                                              )),
                                                                                        ],
                                                                                      ),
                                                                                      flex: 1,
                                                                                    )
                                                                                  ],
                                                                                )),
                                                                          )),
                                                                  PaddingWrap
                                                                      .paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                InkWell(
                                                                                  child: Row(
                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: <Widget>[
                                                                                      Expanded(
                                                                                        child: PaddingWrap.paddingfromLTRB(
                                                                                            0.0,
                                                                                            10.0,
                                                                                            15.0,
                                                                                            0.0,
                                                                                            Image.asset(
                                                                                              "assets/newDesignIcon/achievment/media.png",
                                                                                              width: 25.0,
                                                                                              height: 25.0,
                                                                                            )),
                                                                                        flex: 0,
                                                                                      ),
                                                                                      Expanded(
                                                                                        child: Column(
                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                          children: <Widget>[
                                                                                            PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 10.0, TextViewWrap.textView("Add media", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                                            PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 0.0, TextViewWrap.textViewMultiLine("Upload Photos, Videos or Images of Certificates, Trophies, and Badges to enrich and embellish your Profile", TextAlign.start, ColorValues.GREY_TEXT_COLOR, 14.0, FontWeight.normal, 4)),
                                                                                            isShowMedia
                                                                                                ? Column(
                                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                                    children: <Widget>[
                                                                                                      PaddingWrap.paddingfromLTRB(
                                                                                                          0.0,
                                                                                                          20.0,
                                                                                                          0.0,
                                                                                                          10.0,
                                                                                                          Text(
                                                                                                            "Photos",
                                                                                                            style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                          )),
                                                                                                      mediaImageListUI,
                                                                                                      Padding(
                                                                                                        padding: const EdgeInsets.fromLTRB(0.0, 0, 20, 10),
                                                                                                        child: isPredefinedMediaSelected && imageList.length > 0
                                                                                                            ? Row(
                                                                                                                children: <Widget>[
                                                                                                                  Expanded(
                                                                                                                    child: Stack(
                                                                                                                      children: <Widget>[
                                                                                                                        InkWell(
                                                                                                                          child: Container(
                                                                                                                              height: 65,
                                                                                                                              width: 65,
                                                                                                                              padding: EdgeInsets.fromLTRB(0, 8, 10, 8),
                                                                                                                              child: FadeInImage.assetNetwork(
                                                                                                                                fit: BoxFit.fill,
                                                                                                                                width: 65,
                                                                                                                                alignment: Alignment.center,
                                                                                                                                placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                                image: Constant.IMAGE_PATH + imageList[0],
                                                                                                                              )),
                                                                                                                          onTap: () {
                                                                                                                            setState(() {
                                                                                                                              selectedIndexCover = 0;
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.add(imageList[0]);
                                                                                                                              mediaList.add("");
                                                                                                                            });
                                                                                                                          },
                                                                                                                        ),
                                                                                                                        selectedIndexCover == 0
                                                                                                                            ? Align(
                                                                                                                                alignment: Alignment.center,
                                                                                                                                child: Padding(
                                                                                                                                  padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                  child: Container(
                                                                                                                                      child: Image.asset(
                                                                                                                                    "assets/profile/student/select_circle.png",
                                                                                                                                    height: 25.0,
                                                                                                                                    width: 25.0,
                                                                                                                                  )),
                                                                                                                                ),
                                                                                                                              )
                                                                                                                            : Container(
                                                                                                                                height: 0.0,
                                                                                                                              )
                                                                                                                      ],
                                                                                                                    ),
                                                                                                                    flex: 1,
                                                                                                                  ),
                                                                                                                  Expanded(
                                                                                                                    child: Stack(
                                                                                                                      children: <Widget>[
                                                                                                                        InkWell(
                                                                                                                          child: Container(
                                                                                                                              height: 65,
                                                                                                                              width: 65,
                                                                                                                              padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                              child: FadeInImage.assetNetwork(
                                                                                                                                fit: BoxFit.fill,
                                                                                                                                width: 65,
                                                                                                                                alignment: Alignment.center,
                                                                                                                                placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                                image: Constant.IMAGE_PATH + imageList[1],
                                                                                                                              )),
                                                                                                                          onTap: () {
                                                                                                                            setState(() {
                                                                                                                              selectedIndexCover = 1;
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.add(imageList[1]);
                                                                                                                              mediaList.add("");
                                                                                                                            });
                                                                                                                          },
                                                                                                                        ),
                                                                                                                        selectedIndexCover == 1
                                                                                                                            ? Align(
                                                                                                                                alignment: Alignment.center,
                                                                                                                                child: Padding(
                                                                                                                                  padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                  child: Container(
                                                                                                                                      child: Image.asset(
                                                                                                                                    "assets/profile/student/select_circle.png",
                                                                                                                                    height: 25.0,
                                                                                                                                    width: 25.0,
                                                                                                                                  )),
                                                                                                                                ),
                                                                                                                              )
                                                                                                                            : Container(
                                                                                                                                height: 0.0,
                                                                                                                              )
                                                                                                                      ],
                                                                                                                    ),
                                                                                                                    flex: 1,
                                                                                                                  ),
                                                                                                                  Expanded(
                                                                                                                    child: Stack(
                                                                                                                      children: <Widget>[
                                                                                                                        InkWell(
                                                                                                                          child: Container(
                                                                                                                              height: 65,
                                                                                                                              width: 65,
                                                                                                                              padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                              child: FadeInImage.assetNetwork(
                                                                                                                                fit: BoxFit.fill,
                                                                                                                                width: 65,
                                                                                                                                alignment: Alignment.center,
                                                                                                                                placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                                image: Constant.IMAGE_PATH + imageList[2],
                                                                                                                              )),
                                                                                                                          onTap: () {
                                                                                                                            setState(() {
                                                                                                                              selectedIndexCover = 2;
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.add(imageList[2]);
                                                                                                                              mediaList.add("");
                                                                                                                            });
                                                                                                                          },
                                                                                                                        ),
                                                                                                                        selectedIndexCover == 2
                                                                                                                            ? Align(
                                                                                                                                alignment: Alignment.center,
                                                                                                                                child: Padding(
                                                                                                                                  padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                  child: Container(
                                                                                                                                      child: Image.asset(
                                                                                                                                    "assets/profile/student/select_circle.png",
                                                                                                                                    height: 25.0,
                                                                                                                                    width: 25.0,
                                                                                                                                  )),
                                                                                                                                ),
                                                                                                                              )
                                                                                                                            : Container(
                                                                                                                                height: 0.0,
                                                                                                                              )
                                                                                                                      ],
                                                                                                                    ),
                                                                                                                    flex: 1,
                                                                                                                  ),
                                                                                                                  Expanded(
                                                                                                                    child: Stack(
                                                                                                                      children: <Widget>[
                                                                                                                        InkWell(
                                                                                                                          child: Container(
                                                                                                                              height: 65,
                                                                                                                              width: 65,
                                                                                                                              padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                              child: FadeInImage.assetNetwork(
                                                                                                                                fit: BoxFit.fill,
                                                                                                                                width: 65,
                                                                                                                                alignment: Alignment.center,
                                                                                                                                placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                                image: Constant.IMAGE_PATH + imageList[3],
                                                                                                                              )),
                                                                                                                          onTap: () {
                                                                                                                            setState(() {
                                                                                                                              selectedIndexCover = 3;
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.add(imageList[3]);
                                                                                                                              mediaList.add("");
                                                                                                                            });
                                                                                                                          },
                                                                                                                        ),
                                                                                                                        selectedIndexCover == 3
                                                                                                                            ? Align(
                                                                                                                                alignment: Alignment.center,
                                                                                                                                child: Padding(
                                                                                                                                  padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                  child: Container(
                                                                                                                                      child: Image.asset(
                                                                                                                                    "assets/profile/student/select_circle.png",
                                                                                                                                    height: 25.0,
                                                                                                                                    width: 25.0,
                                                                                                                                  )),
                                                                                                                                ),
                                                                                                                              )
                                                                                                                            : Container(
                                                                                                                                height: 0.0,
                                                                                                                              )
                                                                                                                      ],
                                                                                                                    ),
                                                                                                                    flex: 1,
                                                                                                                  ),
                                                                                                                  Expanded(
                                                                                                                    child: Stack(
                                                                                                                      children: <Widget>[
                                                                                                                        InkWell(
                                                                                                                          child: Container(
                                                                                                                              height: 65,
                                                                                                                              width: 65,
                                                                                                                              padding: EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                                                                              child: FadeInImage.assetNetwork(
                                                                                                                                fit: BoxFit.fill,
                                                                                                                                width: 65,
                                                                                                                                alignment: Alignment.center,
                                                                                                                                placeholder: 'assets/aerial/feed_default_img.png',
                                                                                                                                image: Constant.IMAGE_PATH + imageList[4],
                                                                                                                              )),
                                                                                                                          onTap: () {
                                                                                                                            setState(() {
                                                                                                                              selectedIndexCover = 4;
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.removeLast();
                                                                                                                              mediaList.add(imageList[4]);
                                                                                                                              mediaList.add("");
                                                                                                                            });
                                                                                                                          },
                                                                                                                        ),
                                                                                                                        selectedIndexCover == 4
                                                                                                                            ? Align(
                                                                                                                                alignment: Alignment.center,
                                                                                                                                child: Padding(
                                                                                                                                  padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                                                                                  child: Container(
                                                                                                                                      child: Image.asset(
                                                                                                                                    "assets/profile/student/select_circle.png",
                                                                                                                                    height: 25.0,
                                                                                                                                    width: 25.0,
                                                                                                                                  )),
                                                                                                                                ),
                                                                                                                              )
                                                                                                                            : Container(
                                                                                                                                height: 0.0,
                                                                                                                              )
                                                                                                                      ],
                                                                                                                    ),
                                                                                                                    flex: 1,
                                                                                                                  )
                                                                                                                ],
                                                                                                              )
                                                                                                            : Container(
                                                                                                                height: 0.0,
                                                                                                              ),
                                                                                                      ),
                                                                                                      PaddingWrap.paddingfromLTRB(
                                                                                                          0.0,
                                                                                                          10.0,
                                                                                                          0.0,
                                                                                                          10.0,
                                                                                                          Text(
                                                                                                            "Videos",
                                                                                                            style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                          )),
                                                                                                      videoListUi,
                                                                                                      PaddingWrap.paddingfromLTRB(
                                                                                                          0.0,
                                                                                                          20.0,
                                                                                                          0.0,
                                                                                                          10.0,
                                                                                                          Text(
                                                                                                            "Certificates",
                                                                                                            style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                          )),
                                                                                                      certificateListUI,
                                                                                                      PaddingWrap.paddingfromLTRB(
                                                                                                          0.0,
                                                                                                          20.0,
                                                                                                          0.0,
                                                                                                          10.0,
                                                                                                          Text(
                                                                                                            "Trophies & Badges",
                                                                                                            style: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                          )),
                                                                                                      trophyListUi
                                                                                                    ],
                                                                                                  )
                                                                                                : Container(
                                                                                                    height: 0.0,
                                                                                                  ),
                                                                                          ],
                                                                                        ),
                                                                                        flex: 1,
                                                                                      )
                                                                                    ],
                                                                                  ),
                                                                                  onTap: () {
                                                                                    setState(() {
                                                                                      isShowMedia = true;
                                                                                    });
                                                                                  },
                                                                                )),
                                                                          )),
                                                                  UIHelper
                                                                      .verticalGapBetweenBox,
                                                                  externalLinkWidget(),

                                                                  UIHelper
                                                                      .verticalGapBetweenBox,

                                                                  personalReflectionWidget(),
                                                                  //UIHelper.verticalGapBetweenBox,
                                                                ],
                                                              ))),
                                              Container(
                                                  color: ColorValues
                                                      .SCREEN_BG_COLOR,
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                          0.0,
                                                          7.0,
                                                          0.0,
                                                          0.0,
                                                          Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                isPrompt
                                                                    ? PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            10.0,
                                                                            Row(
                                                                              children: <Widget>[
                                                                                PaddingWrap.paddingAll(
                                                                                    0.0,
                                                                                    InkWell(
                                                                                      child: Image.asset(
                                                                                        "assets/newDesignIcon/login/check.png",
                                                                                        width: 25.0,
                                                                                        height: 25.0,
                                                                                      ),
                                                                                      onTap: () {
                                                                                        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                                                                                          if (isPrompt)
                                                                                            isPrompt = false;
                                                                                          else
                                                                                            isPrompt = true;
                                                                                          setState(() {
                                                                                            isPrompt;
                                                                                          });
                                                                                        } else {
                                                                                          ToastWrap.showToast(MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR, context);
                                                                                        }
                                                                                      },
                                                                                    )),
                                                                                Text(
                                                                                  "  Ask for recommendation",
                                                                                  style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                ),
                                                                              ],
                                                                            ))
                                                                    : PaddingWrap
                                                                        .paddingfromLTRB(
                                                                            16.0,
                                                                            0.0,
                                                                            16.0,
                                                                            10.0,
                                                                            Row(
                                                                              children: <Widget>[
                                                                                PaddingWrap.paddingAll(
                                                                                    0.0,
                                                                                    PaddingWrap.paddingAll(
                                                                                        0.0,
                                                                                        InkWell(
                                                                                          child: Image.asset(
                                                                                            isPrompt ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                            width: 25.0,
                                                                                            height: 25.0,
                                                                                          ),
                                                                                          onTap: () {
                                                                                            if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                                                                                              if (isPrompt)
                                                                                                isPrompt = false;
                                                                                              else
                                                                                                isPrompt = true;
                                                                                              setState(() {
                                                                                                isPrompt;
                                                                                              });
                                                                                            } else {
                                                                                              ToastWrap.showToast(MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR, context);
                                                                                            }
                                                                                          },
                                                                                        ))),
                                                                                Text(
                                                                                  "  Ask for recommendation",
                                                                                  style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                ),
                                                                              ],
                                                                            )),
                                                                isPrompt
                                                                    ? Card(
                                                                        elevation:
                                                                            0.0,
                                                                        child: Container(
                                                                            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0), top: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                16.0,
                                                                                0.0,
                                                                                16.0,
                                                                                20.0,
                                                                                Column(
                                                                                  children: <Widget>[
                                                                                    recommendationTitle,
                                                                                    recommendationRequest,
                                                                                    PaddingWrap.paddingfromLTRB(
                                                                                        0.0,
                                                                                        15.0,
                                                                                        0.0,
                                                                                        0.0,
                                                                                        Container(
                                                                                            padding: EdgeInsets.all(5.0),
                                                                                            color: Color(0XFFE9E9E9),
                                                                                            width: double.infinity,
                                                                                            child: Text(
                                                                                              "RECOMMENDER DETAILS",
                                                                                              style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 12.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                            ))),
                                                                                    recommenderTitle,
                                                                                    coachFirstName,
                                                                                    coachLastName,
                                                                                    coachEmail,
                                                                                  ],
                                                                                ))))
                                                                    : Container(
                                                                        height:
                                                                            0.0,
                                                                      )
                                                              ]))),
                                            ],
                                          ),
                                        )
                                      ],
                                    ))
                                  ],
                                ))),
                      ],
                    )))));
  }

  externalLinkWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          14.0,
          10.0,
          5.0,
          10.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/story_new/link_url.png",
                      width: 25.0,
                      height: 25.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        TextViewWrap.textView(
                            "External Links & Mentions",
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            "Upload press coverage, video montages/highlight reels, documents.",
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    UIHelper.verticalGapBetweenBox,

                    //////////////////////////////////
                    Container(
                      child: ListView.builder(
                        itemCount: linkUrlListData.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                            child: Container(
                              //color: ColorValues.BLUE_COLOR,
                              //padding: EdgeInsets.only(top: 10,),

                              margin:
                                  EdgeInsets.only(top: 0, bottom: 0, right: 0),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 5, 0),
                                    child: Container(
                                      color: ColorValues.SELECTION_GRAY,
                                      margin: EdgeInsets.only(top: 0, right: 0),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 5, 13, 5),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Expanded(
                                              child: Column(
                                                children: <Widget>[
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: 0,
                                                      top: 0,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .labelController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'Title'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (val) => linkUrlListData[
                                                                          index]
                                                                      .labelController
                                                                      .text ==
                                                                  "" &&
                                                              linkUrlListData[
                                                                          index]
                                                                      .urlController
                                                                      .text ==
                                                                  ""
                                                          ? null
                                                          : val.trim().isEmpty
                                                              ? MessageConstant
                                                                  .FIELD_REQUIRED
                                                              : null,
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .urlController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'URL'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (value) {
                                                        return linkUrlListData[
                                                                            index]
                                                                        .labelController
                                                                        .text ==
                                                                    "" &&
                                                                linkUrlListData[
                                                                            index]
                                                                        .urlController
                                                                        .text ==
                                                                    ""
                                                            ? null
                                                            : ValidationChecks
                                                                .validateWebUrlPortFolio(
                                                                    value);
                                                      },
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: UIHelper
                                                          .screenPadding,
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .descController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'Description'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      /*validator: (value) {
                                    return ValidationChecks
                                        .validateDescription(value);
                                },*/
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    right: 0.0,
                                    top: 0.0,
                                    child: InkWell(
                                      child: index > 0
                                          ? Container(
                                              padding: EdgeInsets.all(0),
                                              child: Image.asset(
                                                ImagePath.ICON_CLEAR,
                                                height: 24.18,
                                                width: 17,
                                              ),
                                            )
                                          : Container(
                                              height: 24.18,
                                              width: 17,
                                            ),
                                      onTap: () {
                                        if (linkUrlListData.length > 1) {
                                          print(
                                              'link Index is =======>  $index');
                                          linkUrlListData.removeAt(index);
                                        }
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    ////////////////////////////
                    InkWell(
                      child: Padding(
                        padding:
                            EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
                        child: Text(
                          '+ Add More Link'.toUpperCase(),
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.accentColor, 14, FontType.Regular),
                        ),
                      ),
                      onTap: () {
                        if (linkUrlListData[linkUrlListData.length - 1]
                                    .urlController
                                    .text !=
                                "" &&
                            linkUrlListData[linkUrlListData.length - 1]
                                    .labelController
                                    .text !=
                                "") {
                          setState(() {
                            linkUrlListData.add(LinkUrlModel(
                                labelController: TextEditingController(),
                                urlController: TextEditingController(),
                                descController: TextEditingController()));
                          });
                        }

                        /*    setState(() {
                          linkUrlListData.add(LinkUrlModel(
                              labelController:  TextEditingController(),
                              urlController:  TextEditingController(),
                              descController:  TextEditingController()));
                        });*/
                      },
                    ),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  personalReflectionWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          17.0,
          0.0,
          5.0,
          20.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/newDesignIcon/ad_new/personal_rel.png",
                      width: 25.0,
                      height: 25.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        6.0,
                        TextViewWrap.textView(
                            "Personal Reflection",
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            "Add some notes/reminders for yourself that you want to remember.",
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),

                    //UIHelper.verticalGapBetweenBox,
                    personalReflectionUi(),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLineItalic(
                            "Note: Personal reflection is a note to self and will not be shared with anyone.",
                            TextAlign.start,
                            ColorValues.ORANGE_TEXT_COLOR,
                            10.0,
                            FontWeight.normal,
                            4)),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  personalReflectionUi() {
    return Container(
        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: personalReflectionController,
          maxLength: TextLength.PERSONAL_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:
              BaseCommonWidget.textFormFieldDecorationAchievment("", ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            floatingLabelBehavior: FloatingLabelBehavior.never,
            //labelText: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is best.",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            // hintText: "Include things like what makes this experience so unique, what you might want to highlight in a college app. or in a job interview etc.",
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                //fontSize: 16
                fontSize: 13),
            fillColor: Colors.transparent,
          ),*/
          /*validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_Personal_Reflection_VAL : null,*/
          onSaved: (val) => strpersonalReflection = val.trim(),
        ));
  }
}
