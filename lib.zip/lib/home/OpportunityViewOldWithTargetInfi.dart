import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/parentProfile/recommendationRequestRepliedParent.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:spike_view_project/modal/StudentDataModel.dart';
class OpportunityViewWidget extends StatefulWidget {
  OpportunityModelForFeed opportunity;
  String feedId, userIdPref, roleId,pageName;
  int diffrenceInDob;

  OpportunityViewWidget(this.opportunity, this.feedId, this.userIdPref,
      this.roleId, this.diffrenceInDob,this.pageName);

  @override
  State<StatefulWidget> createState() =>
      OpportunityViewWidgetState(opportunity, diffrenceInDob);
}

class OpportunityViewWidgetState extends State<OpportunityViewWidget>
    with BaseCommonWidget {
  bool isActivate = true;
  OpportunityModelForFeed opportunity;
  SharedPreferences prefs;
  List<Assest> mediaDocumentList =  List();
  List<Assest> googleLinkList =  List();
  String userIdPref;
  String location="";

  OpportunityViewWidgetState(this.opportunity, this.diffrenceInDob);

  int diffrenceInDob;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    String dob = prefs.getString(UserPreference.DOB);
  }

  Future apiCallingForIncreaseCount() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_INCREASE_NUMBER_OF_COUNT +
                widget.feedId +
                "&roleId=" +
                widget.roleId,
            "get");

        print("apiCallingForIncreaseCount data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    if(opportunity.qualificationModelParam != null)
    print('APurva Qualification::: ${opportunity.qualificationModelParam.length}');
    mediaDocumentList.addAll(opportunity.docList);

    googleLinkList.addAll(opportunity.googleLinkList);
    for (Address adress in opportunity.locationList) {
      if (location == "") {
        location = location + " " + adress.street1;
      } else {
        location = location + "   /  " + adress.street1;
      }
    }
    getSharedPreferences();
    super.initState();
  }

  void groupInvitationAccepted() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Center(
                                              child:  Container(
                                                  child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: opportunity
                                                          .groupIsPublic
                                                      ? ' Awesome! You have successfully joined this group '
                                                      : ' Awesome! You have successfully sent request for this group ',
                                                  style:  TextStyle(
                                                      color:   ColorValues.HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                            ),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallJoin(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(widget.userIdPref),
          "roleId": int.parse(widget.roleId)
        };
        print("map++++" + map.toString());
        response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForForwardParent(groupId, opportunityModelForFeed) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "parentId": int.parse(widget.userIdPref),
          "userId": int.parse(opportunityModelForFeed.studentJoinId)
        };

        print("joinMap++++" + map.toString());

        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    void feedForwardConformation() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Center(
                                                child:  Container(
                                                    child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text:
                                                        ' Your post has been forwarded to your parent. Please follow up with them ',
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                )),
                                              ),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "OK",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    Future apiCallForForwardFeed(id) async {
      try {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          Map map = {
            "opportunityId": int.parse(id),
            "userId": int.parse(widget.userIdPref)
          };
          print("map+++" + map.toString());
          Response response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_FEED_FORWARD, map);

          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                if (msg.contains("Opportunity already forwarded to parent")) {
                  ToastWrap.showToast(msg, context);
                } else {
                  feedForwardConformation();
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      } catch (e) {
        e.toString();
      }
    }

    Widget _loader(BuildContext context) => Center(
            child: Container(
          child:  Image.asset(
            "assets/aerial/feed_default_img.png",
            fit: BoxFit.cover,
          ),
        ));

    Widget _error() {
      return Center(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.fill,
        ),
      );
    }

    void forwardToParentConformAtionDialog(id) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(20.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to forward this feed to your parent?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "No",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Yes",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallForForwardFeed(id);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void infoDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: 145.0,
                                          padding: const EdgeInsets.all(8.0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: ListView(children: <Widget>[
                                            Image.asset(
                                              'assets/profile/parent/info.png',
                                              height: 25.0,
                                              width: 25.0,
                                            ),
                                             Container(
                                                padding:
                                                    const EdgeInsets.all(3.0),
                                                child: RichText(
                                                  maxLines: 1,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text: 'Forward to Parent',
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMBOLD),
                                                  ),
                                                )),
                                             Container(
                                                child: RichText(
                                              maxLines: 5,
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                text:
                                                    'Great that you are interested on this opportunity. Because you are under 13, please follow up your parent/guardian to help with next steps. They will see the details in their feed.',
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 16.0,
                                                    fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                              ),
                                            ))
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Close",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final docListUiData =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.5,
      mainAxisSpacing: 10.0,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: mediaDocumentList.map((file) {
        return  InkWell(
          child:  Container(
              height: 45.0,
              width: 45.0,
              child:  Image.asset(
                "assets/newDesignIcon/patner/pdf.png",
                height: 45.0,
                width: 45.0,
              )),
          onTap: () {
            launch(Constant.IMAGE_PATH + file.file);
          },
        );
      }).toList(),
    ));

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    // TODO: implement build
    return SafeArea(
      child: Scaffold(
          appBar:  AppBar(
            backgroundColor: Palette.webColor,
            centerTitle: true,
            elevation: 0.0,
            actions: <Widget>[
              InkWell(
                child: Container(
                  width: 40,
                  height: 40,
                  padding: EdgeInsets.all(10),
                ),
                onTap: () {},
              )
            ],
            title: Text(
              'Opportunity Detail ',
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor, 18, FontType.Regular),
            ),
            leading: backIcon(context),
          ),
          body: Column(
            children: <Widget>[
              CustomViews.getSepratorLine(),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 15.0),
                    child: Container(
                      child:  Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              15.0,
                              15.0,
                              13.0,
                              10.0,
                               Row(
                                children: <Widget>[
                                   Expanded(
                                    child:  InkWell(
                                      child:  Center(
                                        child:  Container(
                                            width: 50.0,
                                            height: 50.0,
                                            child: ClipOval(
                                                child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                              placeholder:
                                                  'assets/profile/user_on_user.png',
                                              image: Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getSmallImage(
                                                      opportunity
                                                          .profilePicture),
                                            ))),
                                      ),
                                      onTap: () {
                                        onTapImageTile(opportunity.userId,
                                            opportunity.roleId);
                                      },
                                    ),
                                    flex: 0,
                                  ),
                                   Expanded(
                                    child: PaddingWrap.paddingfromLTRB(
                                        8.0,
                                        0.0,
                                        15.0,
                                        0.0,
                                         Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                             InkWell(
                                              child:  Container(
                                                  child: RichText(
                                                maxLines: 2,
                                                textAlign: TextAlign.start,
                                                text: TextSpan(
                                                  text: opportunity.companyName,
                                                  style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontSize: 15.0,
                                                    fontWeight: FontWeight.bold,
                                                  ),
                                                ),
                                              )),
                                            ),
                                          ],
                                        )),
                                    flex: 4,
                                  ),
                                ],
                              )),
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              //
                              opportunity.assestVideoAndImage.length > 0
                                  ?  SizedBox(
                                      // Pager view
                                      height: 215.50,
                                      child: PageIndicatorContainer(
                                        pageView:  PageView.builder(
                                          itemCount: opportunity
                                              .assestVideoAndImage.length,
                                          controller:  PageController(),
                                          itemBuilder: (context, index2) {
                                            print("image+++");
                                            print("image+++"+opportunity
                                                .assestVideoAndImage[
                                            index2]
                                                .file);
                                            return  InkWell(
                                              child:
                                                   Stack(children: <Widget>[
                                                opportunity
                                                            .assestVideoAndImage[
                                                                index2]
                                                            .type ==
                                                        "image"
                                                    ?  CachedNetworkImage(
                                                        width: double.infinity,
                                                        height: 215.50,
                                                        imageUrl: Constant
                                                                .IMAGE_PATH +
                                                            opportunity
                                                                .assestVideoAndImage[
                                                                    index2]
                                                                .file,
                                                        fit: BoxFit.fill,
                                                        placeholder:(context, url) =>
                                                            _loader(context),
                                                        errorWidget:(context, url, error) => _error(),
                                                      )
                                                    :  Container(
                                                        height: 215.50,
                                                        child:  Center(
                                                          child:new VideoPlayPause(
                                                              opportunity
                                                                  .assestVideoAndImage[
                                                              index2]
                                                                  .file,
                                                              "",true),
                                                        ),
                                                      ),
                                                opportunity.assestVideoAndImage
                                                                .length ==
                                                            1 ||
                                                        opportunity
                                                                .assestVideoAndImage[
                                                                    index2]
                                                                .type ==
                                                            "video"
                                                    ?  Container(
                                                        height: 0.0,
                                                      )
                                                    :  Container(
                                                        height: 215.50,
                                                        width: double.infinity,
                                                        child:  Image.asset(
                                                          "assets/newDesignIcon/navigation/layer_image.png",
                                                          fit: BoxFit.fill,
                                                        ),
                                                      )
                                              ]),
                                              onTap: () {},
                                            );
                                          },
                                          onPageChanged: (index) {},
                                        ),
                                        align: IndicatorAlign.bottom,
                                        length: opportunity
                                            .assestVideoAndImage.length,
                                        indicatorSpace: 10.0,
                                        indicatorColor: opportunity
                                                    .assestVideoAndImage
                                                    .length ==
                                                1
                                            ? Colors.transparent
                                            :  Color(0xffc4c4c4),
                                        indicatorSelectorColor: opportunity
                                                    .assestVideoAndImage
                                                    .length ==
                                                1
                                            ? Colors.transparent
                                            :  ColorValues.WHITE,
                                        shape: IndicatorShape.circle(size: 5.0),
                                      ))
                                  :  Stack(children: <Widget>[
                                       Image.asset(
                                        "assets/profile/default_achievement.png",
                                        fit: BoxFit.cover,
                                        height: 215.50,
                                        width: double.infinity,
                                      ),
                                       Container(
                                        height: 215.50,
                                        color: Colors.black54.withOpacity(.4),
                                      )
                                    ])),
                          // UIHelper.verticalSpaceSmall,
                          Container(
                            width: double.infinity,
                            margin: EdgeInsets.all(10),
                            padding: EdgeInsets.all(13),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(

                                  opportunity.offerId == "4" || opportunity.offerId == "5"
                                          ? opportunity.serviceTitle
                                  :opportunity.jobTitle,
                                          //: "College Counselling",
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.primaryTextColor,
                                      20,
                                      FontType.Regular),
                                ),
                                UIHelper.verticalSpaceSmall,
                                Text(
                                  opportunity.offerId == "1" || opportunity.offerId == "2" || opportunity.offerId == "3"
                                      ? opportunity.project
                                      : opportunity.offerId == "4" || opportunity.offerId == "5"
                                          ? opportunity.serviceDesc
                                          : "${opportunity.description}",//"College Counselling",
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.primaryTextColor,
                                      16,
                                      FontType.Regular),
                                ),

                                opportunity.offerId == "6" || opportunity.offerId == "7" || opportunity.offerId == "8" ?
                                getMentorAdvisorTutor()
                                :Container(),

                                UIHelper.verticalSpaceSmall,
                                opportunity.jobLocation==null  || opportunity.jobLocation=="null"  || opportunity.jobLocation==""?new Container(height: 0.0,):  Text(
                                  'Job Location: ' +

                                          opportunity.jobLocation,
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.primaryTextColor,
                                      14,
                                      FontType.Regular),
                                ),
                                UIHelper.verticalSpaceSmall,
                                opportunity.offerId == "6" || opportunity.offerId == "7" || opportunity.offerId == "8" ?
                                getScheduleWidget(opportunity)
                                : Text(
                                  'Schedule: ' +
                                      getConvertedDateStamp2(
                                          opportunity.fromDate) +
                                      " - " +
                                      getConvertedDateStamp2(
                                          opportunity.toDate),
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.primaryTextColor,
                                      14,
                                      FontType.Regular),
                                ),
                                UIHelper.verticalSpaceSmall,
                                Text(
                                  'Expiration Date: ' +
                                      getConvertedDateStamp2(
                                          opportunity.expiresOn),
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.primaryTextColor,
                                      14,
                                      FontType.Regular),
                                ),
                              ],
                            ),
                          ),
                          UIHelper.verticalSpaceSmall,
                          mediaDocumentList.length == 0
                              ?  Container(
                                  height: 0.0,
                                )
                              : Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    23.0,
                                    0.0,
                                    23.0,
                                    10.0,
                                  ),
                                  child: Text(
                                    "Attach Documents (PDF only)",
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.primaryTextColor,
                                        14,
                                        FontType.Regular),
                                  ),
                                ),
                          mediaDocumentList.length == 0
                              ?  Container(
                            height: 0.0,
                          )
                              :   docListUiData,
                          googleLinkList.length == 0
                              ?  Container(
                                  height: 0.0,
                                )
                              : Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    23.0,
                                    20.0,
                                    23.0,
                                    5.0,
                                  ),
                                  child: Text(
                                    "Other Link",
                                    style: AppTextStyle.getDynamicFontStyle(
                                        Palette.primaryTextColor,
                                        14,
                                        FontType.Regular),
                                  ),
                                ),
                           Column(
                              children:  List.generate(googleLinkList.length,
                                  (index) {
                            return Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  23.0, 5.0, 23.0, 5.0),
                              child:  InkWell(
                                child: Text(
                                  googleLinkList[index].file,
                                  style: AppTextStyle.getDynamicFontStyle(
                                      Palette.accentColor,
                                      14,
                                      FontType.Regular),
                                ),
                                onTap: () {
                                  Navigator.push(
                                      Constant.applicationContext,
                                       MaterialPageRoute(
                                          //   builder: (context) =>  DashBoardWidget()));
                                          builder: (context) =>
                                               WebViewWidget(
                                                  googleLinkList[index].file,
                                                  "Document Link")));
                                },
                              ),
                            );
                          })),

                          UIHelper.verticalSpaceSmall,
                          opportunity.targetAudience == "true"
                              ? Container(
                            width: double.infinity,
                            color: Palette.titleBg,
                            padding: EdgeInsets.only(
                                left: 13, top: 5, bottom: 5),
                            child: Text(
                              'OTHER INFORMATION',
                              style: AppTextStyle.getDynamicFontStyle(
                                  Palette.primaryTextColor,
                                  12,
                                  FontType.Regular),
                            ),
                          )
                              :  Container(
                            height: 0.0,
                          ),
                          opportunity.targetAudience == "true"
                              ? Container(
                            padding: EdgeInsets.all(13),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                UIHelper.verticalSpaceSmall,

                                location!=""?    Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    otherInformationHeader(
                                        'Location You Like To Cover'),
                                    otherInformationValue(location),
                                  ],):new Container(height: 0.0,),




                                opportunity.gender == ""
                                    ?  Container(
                                  height: 0.0,
                                )
                                    :  Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    UIHelper.verticalSpaceMedium,
                                    otherInformationHeader('Gender'),
                                    otherInformationValue(
                                        opportunity.gender),
                                  ],
                                ),

                                // UIHelper.verticalSpaceMedium,
                                opportunity.ageList.length == 0
                                    ?  Container(
                                  height: 0.0,
                                )
                                    :  Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    UIHelper.verticalSpaceMedium,
                                    otherInformationHeader(
                                        'Age Group'),
                                    getAgeList(),
                                  ],
                                ),

                                opportunity.interestTypeList.length == 0
                                    ?  Container(
                                  height: 0.0,
                                )
                                    :  Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.start,
                                  children: <Widget>[
                                    UIHelper.verticalSpaceMedium,
                                    otherInformationHeader(
                                        'Interest(s)'),
                                     Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children:  List.generate(
                                          opportunity.interestTypeList
                                              .length, (index) {
                                        return otherInformationValue(
                                            opportunity
                                                .interestTypeList[index]
                                                .name);
                                      }),
                                    ),
                                    UIHelper.verticalSpaceMedium,
                                  ],
                                )
                              ],
                            ),
                          )
                              :  Container(
                            height: 0.0,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                flex: 1,
              ),
         widget.pageName=="preview"?new Container(height: 0.0,):
          Expanded(
                child: diffrenceInDob < 13
                    ?  Container(
                        width: double.infinity,
                        decoration:  BoxDecoration(
                          color: Palette.webColor,
                          border:
                              Border.all(color: ColorValues.DARK_GREY),
                        ),
                        padding:
                            const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                        child: Padding(
                            padding: const EdgeInsets.fromLTRB(
                                15.0, 10.0, 20.0, 10.0),
                            child:  Row(
                              children: <Widget>[
                                 Expanded(
                                  child:  InkWell(
                                    child:  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 0.0),
                                      child:  Text(
                                        "FORWARD TO PARENT",
                                        style: TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontSize: 12.0,
                                            color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                      ),
                                    ),
                                    onTap: () {
                                      forwardToParentConformAtionDialog(
                                          opportunity.opportunityId);
                                    },
                                  ),
                                  flex: 1,
                                ),
                                Expanded(
                                    child:  InkWell(
                                      child: Image.asset(
                                        'assets/profile/parent/info.png',
                                        height: 25.0,
                                        width: 25.0,
                                      ),
                                      onTap: () {
                                        infoDialog();
                                      },
                                    ),
                                    flex: 0),
                              ],
                            )),
                      )
                    :  Container(
                        width: double.infinity,
                        decoration:  BoxDecoration(
                          // color: Palette.webColor,
                          border:
                              Border.all(color: ColorValues.DARK_GREY),
                        ),
                        padding:
                            const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                        height: 45.0,
                        child:  Row(
                          children: <Widget>[
                             Expanded(
                              flex: 1,
                              child:  Container(),
                            ),
                             InkWell(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    15.0, 0.0, 15.0, 0.0),
                                child:  Container(
                                    height: 25.0,
                                    alignment: FractionalOffset.center,
                                    decoration:  BoxDecoration(
                                      //  color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                      border: Border.all(
                                          color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          6.0, 0.0, 6.0, 0.0),
                                      child:  Text(
                                        opportunity.actionType ==
                                                Constant.LINK_URL
                                            ? opportunity.linkUrlPosition ==
                                                    Constant.LEARN_MORE
                                                ? "LEARN MORE"
                                                : opportunity.linkUrlPosition ==
                                                        Constant.GET_OFFER
                                                    ? "GET OFFER"
                                                    : "APPLY NOW"
                                            : opportunity.actionType ==
                                                    Constant.JOIN_GROUP
                                                ? "JOIN GROUP"
                                                : opportunity.actionType ==
                                                        Constant.CALL_NOW
                                                    ? "CALL NOW"
                                                    : "Inquire Now",
                                        style:  TextStyle(
                                            color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                            fontSize: 12.0,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                      ),
                                    )),
                              ),
                              onTap: () {
                                apiCallingForIncreaseCount();
                                if (opportunity.actionType ==
                                    Constant.LINK_URL) {
                                  Navigator.push(
                                      Constant.applicationContext,
                                       MaterialPageRoute(
                                          //   builder: (context) =>  DashBoardWidget()));
                                          builder: (context) =>
                                               WebViewWidget(opportunity.url,
                                                  "Learn More")));
                                } else if (opportunity.actionType ==
                                    Constant.JOIN_GROUP) {


                                  if (opportunity.studentJoinId == "" ||
                                      opportunity.studentJoinId == "null") {
                                    apiCallJoin(opportunity.groupIdAction);
                                    ;
                                  } else {
                                    apiCallForForwardParent(
                                        opportunity.groupIdAction, opportunity);
                                  }
                                } else if (opportunity.actionType ==
                                    Constant.CALL_NOW) {
                                  String callingNumber =
                                      opportunity.callingNumber;
                                  launch("tel:" + callingNumber);
                                } else {
                                  Navigator.of(context).push(
                                       MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                               InquireNowScreen(
                                                  opportunity.opportunityId,
                                                  widget.feedId,
                                                  opportunity.formId,
                                                  opportunity.offerId
                                                      .toString(),
                                                  "")));
                                }
                              },
                            ),
                             Expanded(flex: 1, child:  Container()),
                          ],
                        )),
                flex: 0,
              )
            ],
          )),
    );
  }

  Widget getAgeList() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(opportunity.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            opportunity.ageList[index].from +
                "-" +
                opportunity.ageList[index].to +
                " years ",
            style: AppTextStyle.getDynamicFontStyle(
                Palette.primaryTextColor, 16, FontType.Regular),
          ),
        );
      }),
    );
  }

  otherInformationHeader(String title) {
    return Text(
      title,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
    );
  }

  otherInformationValue(String value) {
    return Text(
      value,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
    );
  }

  bottomWidgetDataTitleWidget(String text, Color color) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(color, 12, FontType.Regular),
    );
  }

  bottomWidgetDataValueWidget(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 24, FontType.Regular),
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now =  DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter =  DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter =  DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  Widget getScheduleWidget(OpportunityModelForFeed opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Schedule: ',
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.primaryTextColor,
                  14,
                  FontType.Regular),
            ),

             Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children:  List
                  .generate(
                  opportunity
                      .scheduleModelParam
                      .length,
                      (index) {
                    return Padding(
                      padding:
                      const EdgeInsets
                          .fromLTRB(
                          0,
                          10,
                          0,
                          0),
                      child: Text(
                          opportunity
                              .scheduleModelParam[
                          index]
                              .day +
                              " : " +
                              getHours(
                                  index),
                          maxLines: null,
                          style: AppTextStyle.getDynamicFont(
                               ColorValues.HEADING_COLOR_EDUCATION,
                              14,
                              FontType
                                  .Regular)),
                    );
                  }),
            )
          ],
        ));
  }

  String getConvertedTime(int time) {
    String timeReturn = "";
    print('getConvertedTime time:: $time');
    if (time != null) {
      int startTimeHour = DateTime.fromMillisecondsSinceEpoch(time).hour;
      int startTimeMinute = DateTime.fromMillisecondsSinceEpoch(time).minute;

      if (startTimeHour > 12) {
        return timeReturn = (startTimeHour - 12).toString() +
            ":" +
            startTimeMinute.toString() +
            "PM";
      } else {
        return timeReturn =
            startTimeHour.toString() + ":" + startTimeMinute.toString() + "AM";
      }
    }
    return timeReturn;
  }

  Widget getMentorAdvisorTutor() {
    return  Column(
      crossAxisAlignment:
      CrossAxisAlignment
          .start,
      mainAxisAlignment:
      MainAxisAlignment
          .start,
      children: [
        UIHelper.verticalSpaceSmall,
        Text(
          "Bio: " +opportunity.bio,
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ),
        UIHelper
            .verticalSpaceSmall,
        Text(
          "Category: " +
              opportunity
                  .toMapStringForDesignation(),
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ),
        opportunity.offerId == "7" ? Container(): UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7" ? Container(): Text(
          "Subject: " +
              opportunity
                  .toMapStringSubject(),
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ),
        opportunity.offerId == "7" ? Container(): UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7" ? Container(): Text(
          "Qualification: " + opportunity.toMapStringQualification(),
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ),




        UIHelper
            .verticalSpaceSmall1,
        Text(
          opportunity.fees ==
              "null"
              ? "Fees: "
              : opportunity.fees == "0" ? "Fees: " + MessageConstant.FEE_EMPTY_VAL : "Fees: " + opportunity.fees,
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ),

        opportunity.offerId == "7" || opportunity.offerId == "8" ?
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            opportunity != null && opportunity.userImageModelParam.length > 0
                ? PaddingWrap.paddingfromLTRB(
                0.0,
                20.0,
                15.0,
                0.0,
                Text(
                  "${opportunity.offerId == "8" ? "Advisors Photo" : "Mentor Photo"}",
                  style: AppTextStyle.getDynamicFont(
                       ColorValues.HEADING_COLOR_EDUCATION,
                      14,
                      FontType.Regular),
                ))
                :  Container(
              height: 0.0,
            ),
            userImageListUI(),
          ],
        )
            : Container(),

      ],
    );
  }

  String getHours(index) {
    String timeReturn = "";

    for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
      timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
          " - " +
          Util.getConvertedTimeForScheduleDate(
              hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
          " | " +
          timeReturn;
    }

    return timeReturn;
  }

  userImageListUI() {
    return Container(
      child: opportunity != null &&
          opportunity.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          15.0,
          10.0,
           Container(
              child:  GridView.count(
                primary: false,
                shrinkWrap: true,
                padding: const EdgeInsets.all(0.0),
                crossAxisSpacing: 10.0,
                childAspectRatio: 1.5,
                scrollDirection: Axis.vertical,
                crossAxisCount: 3,
                children: opportunity.userImageModelParam.map((path) {
                  return  Container(
                      child:  Stack(
                        children: <Widget>[
                           InkWell(
                              child: FadeInImage.assetNetwork(
                                fit: BoxFit.cover,
                                placeholder: 'assets/aerial/default_img.png',
                                image: Constant.IMAGE_PATH + path.file,
                                height: 80.0,
                                width: 120.0,
                              ),
                              onTap: () {
                                Navigator.push(
                                  context,
                                   HeroDialogRoute(
                                    builder: (BuildContext context) {
                                      return  Center(
                                        child:  AlertDialog(
                                          content:  Container(
                                            child:  Hero(
                                              tag: 'developer-hero',
                                              child:  Container(
                                                height: 200.0,
                                                width: 200.0,
                                                child: Image.network(
                                                  Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          path.file),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            ),
                                          ),
                                          actions: <Widget>[
                                             FlatButton(
                                              child:  Text('Close'),
                                              onPressed: Navigator.of(context).pop,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                );
                              }),
                        ],
                      ));
                }).toList(),
              )))
          :  Container(
        height: 0.0,
      ),
    );
  }
}
