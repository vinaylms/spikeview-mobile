// Updated COde
import 'dart:async';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/AboutSpikeView.dart';
import 'package:spike_view_project/gateway/more_data.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/SampleProfile.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/studentWizard/AddEducationInitial.dart';
import 'package:spike_view_project/profile/studentWizard/AddGoalsInterestWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddInterestWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddOtherInterestWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddStudentSummary.dart';
import 'package:spike_view_project/profile/studentWizard/CompetenciesStudent.dart';
import 'package:spike_view_project/profile/studentWizard/CongratulationMobile.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

import 'Login_Widget.dart';
class ChangePasswordNew extends StatefulWidget {
  static String tag = 'login-page';
  String activity;
  String rollId;
  String userId;

  ChangePasswordNew(this.activity, this.rollId, {this.userId});

  @override
  ChangePasswordState createState() =>  ChangePasswordState(activity);
}

final formKey = GlobalKey<FormState>();
String strNewPassword = "", strConformPassword = "", strOldPassword = "";
bool _isLoading = false;

class ChangePasswordState extends State<ChangePasswordNew> {
  Color borderColor = Colors.amber;
  String activity, userPassWord,userIdPref;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  TextEditingController txtOldPasswordController;
  bool _oldPassObscureText = true;
  bool _newPassObscureText = true;
  bool _confirmPassPassObscureText = true;

  String sasToken = '';

  ProfileInfoModal profileInfoModal;

  ChangePasswordState(this.activity);

  SharedPreferences prefs;

  String minimu_chara_icon = /*Icons.radio_button_off_outlined*/"assets/newDesignIcon/profile_radio_deselected.png";
  Color minimu_chara_color =   ColorValues.light_grey;

  String special_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png"/*Icons.radio_button_off_outlined*/;
  String number_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png"/*Icons.radio_button_off_outlined*/;
  String Lower_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png"/*Icons.radio_button_off_outlined*/;

  Color special_chara_color =   ColorValues.light_grey;
  Color number_chara_color =   ColorValues.light_grey;
  Color Lower_chara_color =   ColorValues.light_grey;

  bool minimu_value = false;
  bool number_value = false;
  bool special_value = false;
  bool lower_value = false;
  bool upper_value = false;

  bool button_click = false;

  void _checkValidation() async {
    final form = formKey.currentState;
    setState(() => _isLoading = true);
    form.save();
    if (form.validate()) {
      print("SUCCESS 00");
   //   if (userPassWord == strOldPassword) {
        if (strNewPassword == strConformPassword) {
          changePasswordApiCall();
        } else {
          ToastWrap.showToast("Password does not match.", context);
        }

    } else {
      setState(() => _isLoading = false);
      print("Failure 00");
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    userPassWord = prefs.getString(UserPreference.PASSWORD);
    userIdPref = prefs.getString(UserPreference.USER_ID);
    print("activtiy name" + activity);
    print("activtiy name" + userPassWord);
    txtOldPasswordController =  TextEditingController(text: userPassWord);
    strOldPassword = userPassWord;
    setState(() {
      txtOldPasswordController;
      strOldPassword;
    });
  }

  @override
  void initState() {


    super.initState();

    getSharedPreferences();
  }


  onTapSignOut() async {
    try {
      Constant.isAlreadyLoggedIn = false;

      Map map = {
        "userId": int.parse( prefs.getString(UserPreference.USER_ID)),
        "deviceId": prefs.getString("deviceId")
      };
      GlobalSocketConnection.socket.emitWithAck("disconnect1", [map]).then((data) {

        print("chat-login++++" + data.toString());
      });

      GlobalSocketConnection.socket.emit("disconnect2", []);
      /*   await GlobalSocketConnection.manager
          .clearInstance(GlobalSocketConnection.socket);*/
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
      prefs.setBool(UserPreference.IS_USER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      prefs.setString(UserPreference.NAME,"");
      prefs.setString(UserPreference.COMPANY_NAME_PATH,"");
      bloc.resetData(prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) =>  LoginPage(null)),
      );
    } catch (e) {
      print("Error++++" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e,"ParentDashboard",context);
    }
  }

  Future apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
        };

        Response response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {

              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"ParentDashboard",context);
    }
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      Navigator.pop(context);
      if (activity == "login" || activity == "reset") {
        Navigator.of(context).popUntil((route) => route.isFirst);

        if (widget.rollId == "2") {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              context,
               MaterialPageRoute(
                  builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE))));
        } else if (widget.rollId == "4") {
          Navigator.of(context).popUntil((route) => route.isFirst);
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) =>  DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE))));
        } else {

          StudentOnBoarding().getStudentOnBoardingInit(
              context, profileInfoModal, sasToken, userIdPref);


         /* if (activity == "login" || activity == "reset") {
            if(!prefs.getBool(UserPreference.IS_ADDED_DOB)){
              Navigator.of(context).pushReplacement(
                   MaterialPageRoute(
                      builder: (BuildContext context) =>  MoreData()));
            }else {
              StudentOnBoarding().getStudentOnBoardingInit(
                  context, profileInfoModal, sasToken, widget.userId);
            }
          } else {
            Navigator.of(context).popUntil((route) => route.isFirst);
            Navigator.pushReplacement(
                context,
                 MaterialPageRoute(
                    builder: (context) =>  DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE))));
          }*/
        }
      } else {
//        Navigator.pop(context);
        apiCallForLogout();
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  changePasswordApiCall() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        final String encryptedstrOldPassword =
        await platform.invokeMethod('encryption', {
          "password": strOldPassword,
        });

        final String encryptedstrNewPassword =
        await platform.invokeMethod('encryption', {
          "password": strNewPassword,
        });
        SharedPreferences prefs = await SharedPreferences.getInstance();
        String token = prefs.getString(UserPreference.USER_TOKEN);
        CustomProgressLoader.showLoader(context);
        var dio =  Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        dio.options.headers = {'Authorization': token};
        // Prepare Data
        Map map = {
          "oldPassword": encryptedstrOldPassword,
          "newPassword": encryptedstrNewPassword,
          'requestType':activity == ""?"" :"onboarding"
        };
         print("mapmap......"+map.toString());
        // Make API call
        Response response = await dio.post(Constant.ENDPOINT_CHANGE_PASSWORD, data: json.encode(map));
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            prefs.setString(UserPreference.PATHURL,'');
            prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
            prefs.setBool(UserPreference.IS_PROFILECRETED_BY_PARENT, false);
            prefs.setString(UserPreference.PASSWORD, strNewPassword);
            showSucessMsg(message, context);

            //  ToastWrap.showToast(message);
          } else {
            ToastWrap.showToastLong(message, context);
          }
        } else {
          //CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e,"ChangePasswordNew",context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      // CustomProgressLoader.cancelLoader(context);
      setState(() => _isLoading = false);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final oldPassUi =  Padding(
      padding:
       EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 10.0),
      child:  Theme(
        data:  ThemeData(
            backgroundColor:  ColorValues.WHITE,
            indicatorColor:  ColorValues.WHITE,
            cursorColor:  ColorValues.WHITE,
            textSelectionColor: Colors.black54,
            accentColor:  ColorValues.WHITE,
            hintColor:  ColorValues.WHITE),
        child:  TextFormField(
          controller: txtOldPasswordController,
         validator: (val) => val.trim().length == 0
              ? MessageConstant.ENTER_TEMPORARY_PASSWORD_VAL
            /*  : !ValidationWidget.isPass(val)
              ? MessageConstant.ENTER_TEMPORARY_PASSWORD_VAL*/
              : null,
          onSaved: (val) => strOldPassword = val,
          obscureText: _oldPassObscureText,
          style:  TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          autofocus: false,
          cursorColor: Constant.CURSOR_COLOR,
          decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              enabledBorder: UnderlineInputBorder(
                borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
              ),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0)),
              suffixIcon:  GestureDetector(
                child:  Padding(
                  padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                  child: _oldPassObscureText
                      ?  Image.asset(
                    "assets/newDesignIcon/login/hide.png",
                    width: 30.0,
                    height: 30.0,
                  )
                      :  Image.asset(
                    "assets/newDesignIcon/login/unhide.png",
                    width: 30.0,
                    height: 30.0,color: AppConstants.colorStyle.lightPurple,
                  ),
                ),
                onTap: () {
                  if (_oldPassObscureText)
                    _oldPassObscureText = false;
                  else
                    _oldPassObscureText = true;

                  setState(() {
                    _oldPassObscureText;
                  });
                },
              ),
              labelText: "Temporary Password",
              errorStyle: Util.errorTextStyle,
              errorMaxLines: 3,
              labelStyle:  TextStyle(
                  color: Colors.grey, fontFamily: Constant.TYPE_CUSTOMREGULAR),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color: Colors.grey, style: BorderStyle.none))),
        ),
      ),
    );

    final newPassUi =  Padding(
      padding:
       EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 10.0),
      child:  Theme(
        data:  ThemeData(
            backgroundColor:  ColorValues.WHITE,
            indicatorColor:  ColorValues.WHITE,
            cursorColor:  ColorValues.WHITE,
            textSelectionColor: Colors.black54,
            accentColor:  ColorValues.WHITE,
            hintColor:  ColorValues.WHITE),
        child:  TextFormField(

          onSaved: (val) => strNewPassword = val,
          cursorColor: Constant.CURSOR_COLOR,
          obscureText: _newPassObscureText,
          onChanged: (s) {
            if (s.length >= 8) {
              setState(() {
                minimu_value = true;
                minimu_chara_icon = "assets/newIcon/right.png";
                minimu_chara_color =   ColorValues.light_green;
              });
            } else if (s.length < 8) {
              setState(() {
                if (button_click) {
                  minimu_value = false;
                  minimu_chara_icon = "assets/generateScript/cross_close.png";
                  minimu_chara_color =   ColorValues.light_red;
                } else {
                  minimu_value = false;
                  minimu_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png";
                  minimu_chara_color =   ColorValues.light_grey;
                }
              });
            }

            if (ValidationWidget.NumberChara(s)) {
              setState(() {
                number_value = true;
                number_chara_icon = "assets/newIcon/right.png";
                number_chara_color =   ColorValues.light_green;
              });
            } else if (!ValidationWidget.NumberChara(s)) {
              setState(() {
                if (button_click) {
                  number_value = false;
                  number_chara_icon = "assets/generateScript/cross_close.png";
                  number_chara_color =   ColorValues.light_red;
                } else {
                  number_value = false;
                  number_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png";
                  number_chara_color =   ColorValues.light_grey;
                }
              });
            }

            if (ValidationWidget.upper_case(s)) {
              if (ValidationWidget.lower_case(s)) {
                setState(() {
                  lower_value = true;
                  upper_value = true;
                  Lower_chara_icon = "assets/newIcon/right.png";
                  Lower_chara_color =   ColorValues.light_green;
                });
              }
            } else if (!ValidationWidget.upper_case(s)) {
              setState(() {
                if (button_click) {
                  upper_value = false;
                  lower_value = false;
                  Lower_chara_icon = "assets/generateScript/cross_close.png";
                  Lower_chara_color =   ColorValues.light_red;
                } else {
                  upper_value = false;
                  lower_value = false;
                  Lower_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png";
                  Lower_chara_color =   ColorValues.light_grey;
                }
              });
            }

            if (ValidationWidget.lower_case(s)) {
              if (ValidationWidget.upper_case(s)) {
                setState(() {
                  lower_value = true;
                  upper_value = true;
                  Lower_chara_icon ="assets/newIcon/right.png";
                  Lower_chara_color =   ColorValues.light_green;
                });
              }

            } else if (!ValidationWidget.lower_case(s)) {
              setState(() {
                if (button_click) {
                  upper_value = false;
                  lower_value = false;
                  Lower_chara_icon = 'assets/generateScript/cross_close.png';
                  Lower_chara_color =   ColorValues.light_red;
                } else {
                  upper_value = false;
                  lower_value = false;
                  Lower_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png";
                  Lower_chara_color =   ColorValues.light_grey;
                }
              });
            }

            if (ValidationWidget.specialCha(s)) {
              setState(() {
                special_value = true;
                special_chara_icon = "assets/newIcon/right.png";
                special_chara_color =   ColorValues.light_green;
              });
            } else if (!ValidationWidget.specialCha(s)) {
              setState(() {
                if (button_click) {
                  special_value = false;
                  special_chara_icon = "assets/generateScript/cross_close.png";
                  special_chara_color =   ColorValues.light_red;
                } else {
                  special_value = false;
                  special_chara_icon = "assets/newDesignIcon/profile_radio_deselected.png";
                  special_chara_color =   ColorValues.light_grey;
                }
              });
            }
          },
          style:  TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          autofocus: false,
          decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              enabledBorder: UnderlineInputBorder(
                borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
              ),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0)),
              suffixIcon:  GestureDetector(
                child:  Padding(
                  padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                  child: _newPassObscureText
                      ?  Image.asset(
                    "assets/newDesignIcon/login/hide.png",
                    width: 30.0,
                    height: 30.0,
                  )
                      :  Image.asset(
                    "assets/newDesignIcon/login/unhide.png",
                    width: 30.0,
                    height: 30.0,color: AppConstants.colorStyle.lightPurple,
                  ),
                ),
                onTap: () {
                  if (_newPassObscureText)
                    _newPassObscureText = false;
                  else
                    _newPassObscureText = true;

                  setState(() {
                    _newPassObscureText;
                  });
                },
              ),
              labelText: "New Password",
              errorStyle: Util.errorTextStyle,
              errorMaxLines: 3,
              labelStyle:  TextStyle(
                  color: Colors.grey, fontFamily: Constant.TYPE_CUSTOMREGULAR),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color: Colors.grey, style: BorderStyle.none))),
        ),
      ),
    );

    final conformPasUi =  Padding(
      padding:
       EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 0.0),
      child:  Theme(
        data:  ThemeData(
            backgroundColor:  ColorValues.WHITE,
            indicatorColor:  ColorValues.WHITE,
            cursorColor:  ColorValues.WHITE,
            textSelectionColor: Colors.black54,
            accentColor:  ColorValues.WHITE,
            hintColor:  ColorValues.WHITE),
        child:  TextFormField(
          validator: (val) => val.trim().length == 0
              ? MessageConstant.ENTER_CONFIRM_PASSWORD_VAL
              : (strNewPassword != strConformPassword)
              ? MessageConstant.ENTER_CONFIRM_PASSWORD
              : null,
          onSaved: (val) => strConformPassword = val,
          obscureText: _confirmPassPassObscureText,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          autofocus: false,
          decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              enabledBorder: UnderlineInputBorder(
                borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
              ),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0)),
              suffixIcon:  GestureDetector(
                child:  Padding(
                  padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                  child: _confirmPassPassObscureText
                      ?  Image.asset(
                    "assets/newDesignIcon/login/hide.png",
                    width: 30.0,
                    height: 30.0,
                  )
                      :  Image.asset(
                    "assets/newDesignIcon/login/unhide.png",
                    width: 30.0,
                    height: 30.0,color: AppConstants.colorStyle.lightPurple,
                  ),
                ),
                onTap: () {
                  if (_confirmPassPassObscureText)
                    _confirmPassPassObscureText = false;
                  else
                    _confirmPassPassObscureText = true;

                  setState(() {
                    _confirmPassPassObscureText;
                  });
                },
              )


              ,
              labelText: "Confirm Password",
              errorStyle: Util.errorTextStyle,
              errorMaxLines: 3,
              labelStyle:  TextStyle(
                  color: Colors.grey, fontFamily: Constant.TYPE_CUSTOMREGULAR),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color: Colors.grey, style: BorderStyle.none))),
        ),
      ),
    );

    return  WillPopScope(
        onWillPop: () {},
        child:  GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child:  Scaffold(
                body:  Container(
                  child:  Column(
                    children: <Widget>[
                      CustomViews.getSepratorLine(),
                       Expanded(
                        child:  Container(
                            color: ColorValues.GRAY_BG,
                            height: double.infinity,
                            child:  Container(
                                color: ColorValues.GRAY_BG,
                                child:  Container(
                                  padding:  EdgeInsets.all(0.0),
                                  child: Form(
                                      key: formKey,
                                      child:  ListView(
                                        children: <Widget>[
                                          Column(
                                            children: <Widget>[
                                              Padding(
                                                padding: EdgeInsets.fromLTRB(
                                                    10.0, 40.0, 10.0, 0.0),
                                                child:  Image.asset(
                                                  "assets/newDesignIcon/sucess.png",
                                                  height: 85.0,
                                                  width: 85,
                                                ),
                                              ),
                                               Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                  TextViewWrap.textViewMultiLine(
                                                      "You have successfully",
                                                      TextAlign.center,
                                                        ColorValues.HEADING_COLOR_EDUCATION,
                                                      28.0,
                                                      FontWeight.bold,
                                                      2),
                                                  TextViewWrap.textViewMultiLine(
                                                      "signed in to your account",
                                                      TextAlign.center,
                                                        ColorValues.HEADING_COLOR_EDUCATION,
                                                      28.0,
                                                      FontWeight.bold,
                                                      2),
                                                  Padding(
                                                    padding:
                                                    const EdgeInsets.fromLTRB(
                                                        13, 14, 13, 0),
                                                    child: TextViewWrap.textViewMultiLine(
                                                        "Your parents have started your spikeview journey. Take a look and add additional information to showcase the unique you! ",
                                                        TextAlign.center,
                                                         ColorValues.HEADING_COLOR_EDUCATION,
                                                        14.0,
                                                        FontWeight.normal,
                                                        5),
                                                  ),
                                                  Padding(
                                                    padding:
                                                    const EdgeInsets.fromLTRB(
                                                        13, 20, 13, 0),
                                                    child:  InkWell(
                                                      child: TextViewWrap
                                                          .textViewMultiLine(
                                                          "Preview sample profile",
                                                          TextAlign.center,
                                                           ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          16.0,
                                                          FontWeight.normal,
                                                          1),
                                                      onTap: () {
                                                        Navigator.of(context).push(
                                                             MaterialPageRoute(
                                                                builder: (BuildContext
                                                                context) =>
                                                                 SampleProfile()));
                                                      },
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                    const EdgeInsets.fromLTRB(
                                                        13, 15, 13, 0),
                                                    child:  InkWell(
                                                      child: TextViewWrap
                                                          .textViewMultiLine(
                                                          "Learn more",
                                                          TextAlign.center,
                                                           ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          16.0,
                                                          FontWeight.normal,
                                                          1),
                                                      onTap: () {
                                                        Navigator.of(context).push(
                                                             MaterialPageRoute(
                                                                builder: (BuildContext
                                                                context) =>
                                                                 AboutSpikeView()));
                                                      },
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                    const EdgeInsets.fromLTRB(
                                                        13, 40, 13, 0),
                                                    child: TextViewWrap.textViewMultiLine(
                                                        "Please change your temporary password.",
                                                        TextAlign.center,
                                                         ColorValues.HEADING_COLOR_EDUCATION,
                                                        14.0,
                                                        FontWeight.normal,
                                                        5),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                         /* activity == "login" || activity == "reset"?SizedBox():  */ oldPassUi,
                                          newPassUi,
                                          conformPasUi,
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              15.0,
                                              0.0,
                                              0.0,
                                               Row(
                                                mainAxisSize:
                                                MainAxisSize.min,
                                                children: [
                                                  Image.asset(
                                                    "assets/newDesignIcon/changepassword_new.png",
                                                    width: 17.0,
                                                    height: 17.0,
                                                  ),
                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  TextViewWrap
                                                      .textViewMultiLine(
                                                      "Your password must have:",
                                                      TextAlign
                                                          .start,
                                                        ColorValues.black,
                                                      16.0,
                                                      FontWeight.w600,
                                                      4)
                                                ],
                                              )),
                                          PaddingWrap.paddingfromLTRB(
                                              15.0,
                                              5.0,
                                              0.0,
                                              0.0,
                                               Row(
                                                mainAxisSize:
                                                MainAxisSize.min,
                                                children: [

                                                  Image.asset(
                                                    minimu_chara_icon,
                                                    width: 12.0,
                                                    height: 12.0,
                                                  ),

                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  TextViewWrap.textViewMultiLine(
                                                      "Minimum of 8 characters",
                                                      TextAlign.start,
                                                      minimu_chara_color,
                                                      15.0,
                                                      FontWeight.normal,
                                                      4)
                                                ],
                                              )),
                                          PaddingWrap.paddingfromLTRB(
                                              15.0,
                                              5.0,
                                              0.0,
                                              0.0,
                                               Row(
                                                mainAxisSize:
                                                MainAxisSize.min,
                                                children: [

                                                  Image.asset(
                                                    special_chara_icon,
                                                    width: 12.0,
                                                    height: 12.0,
                                                  ),

                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  TextViewWrap.textViewMultiLine(
                                                      "One special character",
                                                      TextAlign.start,
                                                      special_chara_color,
                                                      15.0,
                                                      FontWeight.normal,
                                                      4)
                                                ],
                                              )),
                                          PaddingWrap.paddingfromLTRB(
                                              15.0,
                                              5.0,
                                              0.0,
                                              0.0,
                                               Row(
                                                mainAxisSize:
                                                MainAxisSize.min,
                                                children: [

                                                  Image.asset(
                                                    number_chara_icon,
                                                    width: 12.0,
                                                    height: 12.0,
                                                  ),
                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  TextViewWrap
                                                      .textViewMultiLine(
                                                      "One number",
                                                      TextAlign
                                                          .start,
                                                      number_chara_color,
                                                      15.0,
                                                      FontWeight
                                                          .normal,
                                                      4)
                                                ],
                                              )),
                                          PaddingWrap.paddingfromLTRB(
                                              15.0,
                                              5.0,
                                              0.0,
                                              0.0,
                                               Row(
                                                mainAxisSize:
                                                MainAxisSize.min,
                                                children: [

                                                  Image.asset(
                                                    Lower_chara_icon,
                                                    width: 12.0,
                                                    height: 12.0,
                                                  ),
                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  TextViewWrap.textViewMultiLine(
                                                      "Lower case and upper case letter",
                                                      TextAlign.start,
                                                      Lower_chara_color,
                                                      15.0,
                                                      FontWeight.normal,
                                                      4)
                                                ],
                                              )),
                                          PaddingWrap.paddingfromLTRB(
                                              13.0,
                                              30.0,
                                              13.0,
                                              20.0,
                                               Center(
                                                  child:  InkWell(
                                                    child:  Container(
                                                        height: 44.0,
                                                        width: double.infinity,
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        child: PaddingWrap.paddingAll(
                                                          10.0,
                                                           Row(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                            children: <Widget>[
                                                              TextViewWrap.textView(
                                                                  "Reset password",
                                                                  TextAlign.center,
                                                                  Colors.white,
                                                                  14.0,
                                                                  FontWeight.normal),
                                                            ],
                                                          ),
                                                        )),
                                                    onTap: () {
                                                      if (minimu_value) {
                                                      } else {
                                                        setState(() {
                                                          minimu_value = false;
                                                          minimu_chara_icon =
                                                          "assets/generateScript/cross_close.png";
                                                          minimu_chara_color =
                                                            ColorValues.light_red;
                                                        });
                                                      }

                                                      if (number_value) {
                                                      } else {
                                                        setState(() {
                                                          number_value = false;
                                                          number_chara_icon =
                                                          "assets/generateScript/cross_close.png";
                                                          number_chara_color =
                                                            ColorValues.light_red;
                                                        });
                                                      }

                                                      if (special_value) {
                                                      } else {
                                                        setState(() {
                                                          special_value = false;
                                                          special_chara_icon =
                                                          "assets/generateScript/cross_close.png";
                                                          special_chara_color =   ColorValues.light_red;
                                                        });

                                                      }

                                                      if (lower_value&&upper_value) {
                                                      } else {
                                                        setState(() {
                                                          lower_value = false;
                                                          Lower_chara_icon =
                                                          "assets/generateScript/cross_close.png";
                                                          Lower_chara_color =   ColorValues.light_red;
                                                        });

                                                      }
                                                      if (minimu_value) {
                                                        if (number_value) {
                                                          if (special_value) {
                                                            if (lower_value) {
                                                              if (upper_value) {
                                                                FocusScope.of(context).unfocus();
                                                                _checkValidation();
                                                              }
                                                            } else {
                                                              button_click = true;
                                                            }
                                                          } else {
                                                            button_click = true;
                                                          }
                                                        } else {
                                                          button_click = true;
                                                        }
                                                      } else {
                                                        button_click = true;
                                                      }
                                                    },
                                                  )))
                                        ],
                                      )),
                                ))),
                        flex: 1,
                      )
                    ],
                  ),
                  color: ColorValues.LIGHT_GRAY_BG,
                ))));
  }
}
