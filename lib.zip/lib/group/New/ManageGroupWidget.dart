import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/report/ReportWidget.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import '../AboutGroupWidget.dart';
import '../EditGroupWidget.dart';
import '../GroupInvitedMembersWidget.dart';
import '../GroupMembersListWidget.dart';
import '../GroupRequestListWidget.dart';
import '../InviteMember.dart';

// Create a Form Widget
class ManageGroupWidget extends StatefulWidget {
  GroupDetailModel model;
  String sasToken, containerName;

  ManageGroupWidget(this.model, this.sasToken, this.containerName);

  @override
  ManageGroupWidgetState createState() {
    return ManageGroupWidgetState();
  }
}

class ManageGroupWidgetState extends State<ManageGroupWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, token, userProfilePath, isNaviagte = '';
  static StreamController syncDoneController = StreamController.broadcast();

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
  }

  @override
  void initState() {
    getSharedPreferences();

    super.initState();
  }

  Future apiCallForGet() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'Apurva API URL:: ${Constant.ENDPOINT_GROUPS_MEMBERS +
                widget.model.groupId + "/" + userIdPref}');
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GROUPS_MEMBERS +
                widget.model.groupId +
                "/" +
                userIdPref,
            "get");
        print("shubh image response1" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {

              List<GroupDetailModel> groupList = ParseJson.parseGroupDetailMap(
                  response.data['result'], userIdPref, roleId);

              if (groupList.length > 0) {
                setState(() {
                  widget.model=groupList[0];
                  //print("Apurva 222 badgeImage" + groupList[0].memberList[0].badgeImage);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }


  onTapViewAllGroupInvitation() async {
    if(widget.model.invitedList.length>0) {
      String result = await Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  GroupInvitedMembersWidget(
                      widget.model.groupId, widget.model)));

      if (result == "push") {
        syncDoneController.add('');
        isNaviagte = "push";
      }
    }else{
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              InviteMember( widget.model.groupId, "", widget.model.allMembersList)));
      if (result == "push") {
        apiCallForGet();
        isNaviagte = "push";
      }

    }
  }

  Future apiCallingDeleteGroup() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {"groupId": int.parse(widget.model.groupId)};
        print("test++++" + map.toString());
        response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_ADD_GROUP, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              syncDoneController.add('');
              Navigator.pop(context, "delete");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  onTapGroupRequestList() async {
    //print('groupList::: ${groupList.memberList[1].firstName}');
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => GroupRequestListWidget(
            widget.model.groupId,
            userIdPref,
            roleId,
            widget.model.requestedList,
            widget.model)));
    if (result == "push") {
      syncDoneController.add('');
      isNaviagte = "push";
    }
  }

  Future apiCallingForLeave() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "userId": int.parse(userIdPref),
          "groupId": int.parse(widget.model.groupId),
          "roleId": int.parse(roleId)
        };
        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_LEAVE_GROUP, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context, "leave");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  void deleteDialog() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
           // headingText: 'Delete group',
            headingText: 'Are you sure you want delete this “${widget.model.groupName}” group?',
            negativeText: 'Cancel',
            positiveText: 'Delete',
            isThreeStepPopup:true,
            positiveTextColor:AppConstants
                .colorStyle.btn_text_red,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              apiCallingDeleteGroup();
            },
          );
        });



  }

  void leaveDialog() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
          //  headingText: 'Leave group',
            headingText: 'Are you sure you want leave this “${widget.model.groupName}” group?',
            negativeText: 'Cancel',
            positiveText: 'Leave',
            isThreeStepPopup:true,
            positiveTextColor:AppConstants
                .colorStyle.btn_text_red,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              apiCallingForLeave();
            },
          );
        });




  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    rowItemView(title, showBorder) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          BaseText(
            text: title,
            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
            fontFamily: AppConstants.stringConstant.latoRegular,
            fontWeight: FontWeight.w500,
            fontSize: 16,
            textAlign: TextAlign.start,
            maxLines: 1,
          ),
          showBorder
              ? Padding(
                  padding: const EdgeInsets.only(top: 14.0, bottom: 14),
                  child: Container(
                    height: 1,
                    color: AppConstants.colorStyle.btnBg,
                  ),
                )
              : SizedBox(),
        ],
      );
    }

    onTapEditGroup() async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => EditGroupWidget(
              widget.model, widget.sasToken, widget.containerName)));

      if (result == "push") {
        syncDoneController.add('');
        isNaviagte = "push";
      }
    }

    onTapMemberDetail() async {
      //print('groupList::: ${groupList.memberList[1].firstName}');
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => GroupMembersListWidget(
              widget.model.groupId, widget.model, userIdPref, roleId)));
      if (result == "push") {
        isNaviagte = "push";
      }
    }

    onTapReport() async {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) =>
              Report("group", widget.model.groupId, "", "")));
      print('refresh++++++manage++' + result.trim().toString());
      if (result == "push" || result == "hide") {
        isNaviagte = "push";
        syncDoneController.add('');
        Navigator.pop(context, 'report');
      }
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isNaviagte);
        },
        child: customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 24, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          BaseText(
                            text: widget.model.isAdmin
                                ? 'Manage group'
                                : 'See group activity',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w700,
                            fontSize: 28,
                            textAlign: TextAlign.start,
                            maxLines: 3,
                          ),
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20.0, right: 20,top: 20),
                      child: widget.model.isAdmin
                          ? ListView(
                        padding: EdgeInsets.zero,
                              children: <Widget>[
                                InkWell(
                                  child: rowItemView('About group', true),
                                  onTap: () {
                                    Navigator.of(context).push(
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                AboutGroupWidget(
                                                    widget.model)));
                                  },
                                ),
                                InkWell(
                                  child: rowItemView('Requests', true),
                                  onTap: () {
                                    onTapGroupRequestList();
                                  },
                                ),
                                InkWell(
                                  child: rowItemView('Invited members', true),
                                  onTap: () {
                                    onTapViewAllGroupInvitation();
                                  },
                                ),
                                InkWell(
                                  child: rowItemView('Edit group', true),
                                  onTap: () {
                                    onTapEditGroup();
                                  },
                                ),
                                InkWell(
                                  child: rowItemView('Delete group', false),
                                  onTap: () {
                                    deleteDialog();
                                  },
                                ),
                              ],
                            )
                          : ListView(
                        padding: EdgeInsets.zero,
                              children: <Widget>[
                                InkWell(
                                  child: rowItemView('About group', true),
                                  onTap: () {
                                    Navigator.of(context).push(
                                        new MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                AboutGroupWidget(
                                                    widget.model)));
                                  },
                                ),
                                InkWell(
                                  child: rowItemView('Group members', true),
                                  onTap: () {
                                    onTapMemberDetail();
                                  },
                                ),
                                InkWell(
                                  child: rowItemView('Leave group', true),
                                  onTap: () {
                                    leaveDialog();
                                  },
                                ),
                                InkWell(
                                  child: rowItemView(
                                      'Find support or Report group', false),
                                  onTap: () {
                                    onTapReport();
                                  },
                                ),
                              ],
                            ),
                    ),
                    flex: 1,
                  ),
                ],
              )),
          () {
            Navigator.pop(context, isNaviagte);
          },
          isShowIcon: false,
        ));
  }
}
