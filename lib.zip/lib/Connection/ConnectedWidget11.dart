import 'dart:async';
import 'package:adhara_socket_io/options.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/foundation.dart';
import 'package:adhara_socket_io/manager.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/common/GoogleAnalytics.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/ScreenNameConstant.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import '../main.dart';

class ConnectedWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  ConnectedWidgetState();
  }
}

class ConnectedWidgetState extends State<ConnectedWidget>
    with AutomaticKeepAliveClientMixin {
  SharedPreferences prefs;
  String userIdPref, roleId, userProfilePath;
  List<RequestedTagModel> tagList =  List();
  bool isLoading = true;
  bool isApiCalling = true;
  bool newDesign_isEmailNeedToShow = false;
  int skip = 0;
  Map<String, String> dataExist =  Map();
  ScrollController _scrollController =  ScrollController();
  StreamSubscription<dynamic> _streamSubscription;
  //--------------------------api Calling for tag------------------
  Future apiCallingForTag(String type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });

        // revious API call was ENDPOINT_CONNECTION_LIST

        print(
            'Apurva ui/connect/listByStaus?userId= URL:::${Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL + userIdPref + "&status=" + Constant.ACCEPTED + "&roleId=" + roleId + "&skip=" + skip.toString()}');
        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                Constant.ACCEPTED +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString(),
            "get");

        isLoading = false;
        setState(() {
          isLoading;
        });

        if (type == "") {
          tagList.clear();
        }
        if (response != null) {
          if (response.statusCode == 200) {
            print("-------------------->   " + response.toString());
            String status = response.data[LoginResponseConstant.STATUS];


MessageConstant.printWrapped("===========data List====" + response.toString());
            if (status == "Success") {
              List<RequestedTagModel> tagListLocal =  List();

              tagListLocal = ParseJson.parseRequestedTagList(
                  response.data['result']['Accepted']);
              print(
                  "===========data List====" + tagListLocal.length.toString());
              // tagList.addAll(tagListLocal);

              if (tagListLocal.length == 0) {
                setState(() {
                  isApiCalling = false;
                });
              }

              if (tagListLocal != null) {
                tagList.addAll(tagListLocal);

                for (RequestedTagModel model in tagList) {
                  if (model.partnerId == "1") {
                    RequestedTagModel local = model;
                    tagList.remove(model);
                    tagList.insert(0, local);
                  }
                }

                setState(() {
                  tagList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"ConnectionWidget",context);
      isLoading = false;
      setState(() {
        isLoading;
      });
      print("ERROR+++" + e.toString());
    }
  }

  //--------------------------Delete Education Data ------------------
  Future apiCallingForUnfriend(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId),
        "userId": int.parse(userIdPref),
      };
      print("map+++" + map.toString());
      Response response = await  ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            tagList.removeAt(index);
            //ToastWrap.showToast(msg);
            setState(() {
              tagList;
            });
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"ConnectionWidget",context);
    }
  }

  void initSocket() async {
    // modify with your true address/port

    GlobalSocketConnection.socket = await SocketIOManager().createInstance(
        SocketOptions(
            GlobalSocketConnection.ip)); //TODO change the port  accordingly

    GlobalSocketConnection.socket.connect();
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    ProfileBloc.connectedController.stream.listen((map) {
      try {
        if (map != null) {
          print("connected shubh-------------------->   " + map.toString());
          tagList.clear();
          List<RequestedTagModel> tagListLocal =  List();

          tagListLocal = ParseJson.parseRequestedTagList(map['Accepted']);
          print("===========data List====" + tagListLocal.length.toString());
          // tagList.addAll(tagListLocal);

          if (tagListLocal.length == 0) {
            setState(() {
              isApiCalling = false;
            });
          }

          if (tagListLocal != null) {
            tagList.addAll(tagListLocal);

            for (RequestedTagModel model in tagList) {
              if (model.partnerId == "1") {
                RequestedTagModel local = model;
                tagList.remove(model);
                tagList.insert(0, local);
              }

              setState(() {
                tagList;
              });
            }
          }
        }
      } catch (e) {
        print("stream+++" + e.toString());
        crashlytics_bloc.recordCrashlyticsError(e,"ConnectionWidget",context);
      }

    });

    bloc.fetchConnected(userIdPref, context, prefs, false, "0");
    //anaylytics.setCurrentSreen(ScreenNameConstant.connection_request_activity);
    //apiCallingForTag();
  }

  @override
  void initState() {
    //initSocket();


    _streamSubscription = SplashScreenState.syncDoneController.stream.listen((value) {
      print("value//////"+value.toString());
      if (Constant.CONNECTIONS_PROFILE == value) {
        skip = 0;
        apiCallingForTag("");
      }
    });



    getSharedPreferences();
    // TODO: implement initState
    super.initState();

    _scrollController.addListener(() {
      if (!isLoading) {
        if (_scrollController.position.pixels ==
            _scrollController.position.maxScrollExtent) {
          skip = skip + 1;
          if (isApiCalling) apiCallingForTag("load");
          //  bloc.fetchConnected(userIdPref, context, prefs, true,skip);
        }
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget getMoreDropDown() {
    return  PopupMenuButton<String>(
      offset: const Offset(0.0, 60.0),
      child: PaddingWrap.paddingfromLTRB(
          0.0,
          0.0,
          5.0,
          0.0,
           Container(
              child:  Center(
                  child:  Image.asset(
            "assets/profile/parent/info.png",
            color: ColorValues.GREY_TEXT_COLOR,
            height: 29.0,
            width: 29.0,
          )))),
      itemBuilder: (BuildContext context) => <PopupMenuItem<String>>[
        PopupMenuItem(
          child:  Padding(
              padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              child:  Text(
                "Reach out to spikeview with questions or requests.",
                textAlign: TextAlign.center,
                style:  TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: 16.0,
                    color: Colors.black),
              )),
          value: "0",
        ),
      ],
    );
  }

  showInfo() {
    showDialog(
      context: context,
      child:  Dialog(
        child:  Container(
            padding:  EdgeInsets.all(10.0),
            height: 100.0,
            color: Colors.white,
            child:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                 Expanded(
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                       Padding(
                          padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                          child:  Text(
                            "Reach out to spikeview with questions or requests.",
                            textAlign: TextAlign.center,
                            style:  TextStyle(
                                fontWeight: FontWeight.normal,
                                fontSize: 16.0,
                                color: Colors.black),
                          )),
                    ],
                  ),
                  flex: 4,
                ),
              ],
            )),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);

    Container getListview(RequestedTagModel requestedTagModel, index) {
      return  Container(
          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 5.0, 0.0),
          child:  Card(
              color: Colors.transparent,
              elevation: 0.0,
              child:  Column(
                children: <Widget>[
                   Row(
                    children: <Widget>[
                       Expanded(
                        child:  InkWell(
                          child:  Container(
                            height: 50.0,
                            width: 50.0,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: requestedTagModel.patner.profilePicture ==
                                          "" ||
                                      requestedTagModel.patner.profilePicture ==
                                          "null"
                                  ?  Image.asset(
                                      requestedTagModel.partnerRoleId == "4"
                                          ? "assets/profile/partner_img.png"
                                          : 'assets/profile/user_on_user.png')
                                  : FadeInImage(
                                      fit: BoxFit.cover,
                                      placeholder: AssetImage(
                                        requestedTagModel.partnerRoleId == "4"
                                            ? "assets/profile/partner_img.png"
                                            : 'assets/profile/user_on_user.png',
                                      ),
                                      image: NetworkImage(
                                          Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  requestedTagModel
                                                      .patner.profilePicture)),
                                    ),
                            ),
                          ),
                          onTap: () {
                            if (requestedTagModel.patner.userId == userIdPref) {
                            } else {
                              Util.onTapImageTile(
                                  tapedUserRole:
                                      requestedTagModel.partnerRoleId,
                                  partnerUserId:
                                      requestedTagModel.patner.userId,
                                  context: context);
                            }
                          },
                        ),
                        flex: 0,
                      ),
                       Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                             Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                 Row(
                                  children: <Widget>[
                                     Expanded(
                                      child:  InkWell(
                                        child: TextViewWrap.textView(
                                            requestedTagModel.patner.lastName ==
                                                        null ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        "null" ||
                                                    requestedTagModel
                                                            .patner.lastName ==
                                                        ""
                                                ? requestedTagModel
                                                    .patner.firstName
                                                : requestedTagModel
                                                        .patner.firstName +
                                                    " " +
                                                    requestedTagModel
                                                        .patner.lastName,
                                            TextAlign.start,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14.0,
                                            FontWeight.bold),
                                        onTap: () {
                                          if (requestedTagModel.patner.userId ==
                                              userIdPref) {
                                          } else {
                                            Util.onTapImageTile(
                                                tapedUserRole: requestedTagModel
                                                    .partnerRoleId,
                                                partnerUserId: requestedTagModel
                                                    .patner.userId,
                                                context: context);
                                          }
                                        },
                                      ),
                                      flex: 0,
                                    ),
                                     Expanded(
                                      child:
                                          //requestedTagModel.patner.roleId == "1" ?
                                          requestedTagModel.partnerRoleId == "1"
                                              ? Util.getStudentBadge12(
                                                  requestedTagModel
                                                      .patner.badge,
                                                  requestedTagModel
                                                      .patner.badgeImage)
                                              : Container(),
                                      flex: 0,
                                    )
                                  ],
                                ),
                                requestedTagModel.patner.tagline == null ||
                                        requestedTagModel.patner.tagline ==
                                            "null" ||
                                        requestedTagModel.patner.tagline == ""
                                    ?  Container(
                                        height: 0.0,
                                      )
                                    :  Row(
                                        children: <Widget>[
                                          Flexible(
                                              child: TextViewWrap.textView(
                                            requestedTagModel.patner.tagline ==
                                                        null ||
                                                    requestedTagModel
                                                            .patner.tagline ==
                                                        "null" ||
                                                    requestedTagModel
                                                            .patner.tagline ==
                                                        ""
                                                ? ""
                                                : requestedTagModel
                                                    .patner.tagline,
                                            TextAlign.start,
                                             ColorValues.GREY_TEXT_COLOR,
                                            12.0,
                                            FontWeight.normal,
                                          )),
                                        ],
                                      ),
                              ],
                            )),
                        flex: 1,
                      ),
                       Expanded(
                        child: Row(
                          children: <Widget>[
                             InkWell(
                              child:  Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 4.0, 10.0, 0.0),
                                  child:  Container(
                                      height: 33.0,
                                      width: 30.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/chat.png',
                                      ))),
                              onTap: () {
                                if (requestedTagModel.patner.isActive ==
                                    "true") {


                                  Friends model =  Friends(
                                    connectId:
                                        int.parse(requestedTagModel.connectId),
                                    userId: int.parse(prefs
                                        .getString(UserPreference.USER_ID)),
                                    firstName:
                                        requestedTagModel.patner.firstName,
                                    lastName: requestedTagModel.patner.lastName,
                                    profilePicture:
                                        requestedTagModel.patner.profilePicture,
                                    partnerId:
                                        int.parse(requestedTagModel.partnerId),
                                    partnerFirstName:
                                        requestedTagModel.patner.firstName,
                                    partnerLastName:
                                        requestedTagModel.patner.lastName,
                                    partnerRoleId: int.parse(
                                        requestedTagModel.partnerRoleId),
                                    partnerProfilePicture:
                                        requestedTagModel.patner.profilePicture,
                                    dateTime:  DateTime.now()
                                        .millisecondsSinceEpoch,
                                    creationTime: int.parse(
                                        requestedTagModel.patner.creationTime),
                                    isActive: true,
                                    online: 1,
                                    lastMessage: "",
                                    unreadMessages: 0,
                                    lastTime: 0,
                                    lastSeen: 0,
                                    textSentBy: int.parse(prefs
                                        .getString(UserPreference.USER_ID)),
                                    badge: requestedTagModel.patner.badge,
                                    badgeImage:
                                        requestedTagModel.patner.badgeImage,
                                    gamificationPoints: requestedTagModel
                                        .patner.gamificationPoints,
                                  );

                                  Navigator.of(context).push(
                                       MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                               ChatRoomWidget(
                                                  model, "", "")));
                                } else {
                                  ToastWrap.showToast(
                                      MessageConstant.CONNECTION_INACTIVE_ERROR,
                                      context);
                                }
                              },
                            ),
                            requestedTagModel.patner.userId == "1"
                                ?  Expanded(
                                    child:  Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            7.0, 0.0, 0.0, 0.0),
                                        child: getMoreDropDown()),
                                    flex: 0,
                                  )
                                : userIdPref == "1"
                                    ?  Container(
                                        height: 0.0,
                                      )
                                    :  InkWell(
                                        child:  Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                10.0, 0.0, 0.0, 0.0),
                                            child:  Container(
                                                height: 30.0,
                                                width: 30.0,
                                                child: Image.asset(
                                                  'assets/newDesignIcon/connections/cancel.png',
                                                ))),
                                        onTap: () {
                                          String name = requestedTagModel
                                                          .patner.lastName ==
                                                      null ||
                                                  requestedTagModel
                                                          .patner.lastName ==
                                                      "null" ||
                                                  requestedTagModel
                                                          .patner.lastName ==
                                                      ""
                                              ? requestedTagModel
                                                  .patner.firstName
                                              : requestedTagModel
                                                      .patner.firstName +
                                                  " " +
                                                  requestedTagModel
                                                      .patner.lastName;

                                          educationRemoveConfromationDialog(
                                              requestedTagModel.connectId,
                                              name,
                                              index);
                                        },
                                      )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                   Padding(
                      padding: EdgeInsets.fromLTRB(75.0, 5.0, 0.0, 0.0),
                      child: Divider(
                        color: Colors.transparent,
                        height: 0.0,
                      )),
                ],
              )));
    }

    Future<Null> _refreshPageHere() async {
      skip = 0;
      apiCallingForTag("");
    }

    return tagList.length > 0
        ?  Column(
            children: <Widget>[
               Expanded(
                  child:  RefreshIndicator(
                      onRefresh: _refreshPageHere,
                      displacement: 0.0,
                      child:  ListView.builder(
                          controller: _scrollController,
                          itemCount: tagList.length,
                          itemBuilder: (BuildContext context, int position) {
                            return getListview(tagList[position], position);
                          })),
                  flex: 1),
            ],
          )
        :  Center(
            child: isLoading
                ? Container(
                  child: Center(
                    child: Container(
                      // A simplified version of dialog.
                        width: 30.0,
                        height: 30.0,
                        child:  CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(Colors.black54),
                          strokeWidth: 2.0,
                        )),
                  ),
                )
                :  Padding(
                    padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                    child:  Container(
                      child:  Column(
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              80.0,
                              0.0,
                              0.0,
                               Image.asset(
                                "assets/newDesignIcon/connection_blank.png",
                                width: 77.0,
                                height: 77.0,
                              )),
                          PaddingWrap.paddingfromLTRB(
                              40.0,
                              25.0,
                              40.0,
                              5.0,
                              TextViewWrap.textView(
                                  "No connection request yet",
                                  TextAlign.center,
                                   ColorValues.GREY_TEXT_COLOR,
                                  16.0,
                                  FontWeight.normal)),
                          PaddingWrap.paddingfromLTRB(
                              40.0,
                              10.0,
                              40.0,
                              5.0,
                              TextViewWrap.textViewMultiLine(
                                  "Connect with friends to motivate and inspire each other . Get social and get better",
                                  TextAlign.center,
                                   ColorValues.GREY_TEXT_COLOR,
                                  14.0,
                                  FontWeight.normal,
                                  3)),
                        ],
                      ),
                    ),
                  ));
  }

  void educationRemoveConfromationDialog(id, name, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//
                                                  PaddingWrap.paddingfromLTRB(
                                                      20.0,
                                                      0.0,
                                                      20.0,
                                                      0.0,
                                                      RichText(
                                                        textAlign:
                                                            TextAlign.center,
                                                        text: TextSpan(
                                                          text:
                                                              'Are you sure you want to delete ',
                                                          style:  TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .normal,
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                          children: <TextSpan>[
                                                            TextSpan(
                                                              text: "\n" +
                                                                  name +
                                                                  "?",
                                                              style:  TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  fontFamily:
                                                                      Constant
                                                                          .customBold),
                                                            )
                                                          ],
                                                        ),
                                                      )),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);

                                              apiCallingForUnfriend(id, index);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
