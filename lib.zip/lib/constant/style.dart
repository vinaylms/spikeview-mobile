import 'package:flutter/material.dart';

class TxtStyle {

/*  static String nunitoBold = 'NunitoBold';
  static String nunitoLight = 'NunitoLight';
  static String nunitoRegular = 'NunitoRegular';
  static String nunitoBlack = 'NunitoBlack';
  static String nunitoItalic = 'NunitoItalic';*/


  static String nunitoBold = 'customBold';
  static String nunitoLight = 'customRegular';
  static String nunitoRegular = 'customRegular';
  static String nunitoBlack = 'customRegular';
  static String nunitoItalic = 'customItalic';


  static String latoRegular = 'LatoRegular';
  static String latoMedium = 'LatoMedium';
  static String latoBold = 'LatoBold';
  static String latoSemiBold = 'LatoSemibold';


  static final nunito_20_600nunitoBold = TextStyle(
      fontFamily: nunitoBold,
      fontSize: 14,
      color: const Color(0xff151515),
      fontWeight: FontWeight.w400
  );
  static final nunito_20_600Black = TextStyle(
    fontFamily: nunitoRegular,
    fontSize: 20,
    color: const Color(0xff151515),
    fontWeight: FontWeight.w600
  );

  static final nunito_20_700Green = TextStyle(
    fontFamily: nunitoRegular,
    fontSize: 20,
    color: const Color(0xff219653),
    fontWeight: FontWeight.w700
  );
  static final nunito_14_400Blue = TextStyle(
      fontFamily: latoRegular,
      fontSize:14,
      color: const Color(0xff27275A),
      fontWeight: FontWeight.w400
  );


  static final nunito_16_400Black = TextStyle(
    fontFamily: nunitoRegular,
    fontSize:16,
    color: const Color(0xff151515),
    fontWeight: FontWeight.w400
  );

  static final nunito_italic_16_400Black = TextStyle(
    fontFamily: nunitoItalic,
    fontSize: 14,
    color: const Color(0xff151515),
    fontWeight: FontWeight.w400
  );


  static final nunito_italic_12_400grey = TextStyle(
      fontFamily: latoRegular,
      fontSize: 12,
      fontStyle: FontStyle.italic,
      color: const Color(0xff828282),
      fontWeight: FontWeight.w400
  );


  static final nunito_16_600Black = TextStyle(
    fontFamily: nunitoRegular,
    fontSize: 16,
    color: const Color(0xff151515),
    fontWeight: FontWeight.w600
  );
  static final nunito_14_500Black = TextStyle(
    fontFamily: nunitoRegular,
    fontSize: 14,
    color: const Color(0xff151515),
    fontWeight: FontWeight.w500
  );
  static final nunito_14_700Black = TextStyle(
    fontFamily: nunitoRegular,
    fontSize:14,
    color: const Color(0xff151515),
    fontWeight: FontWeight.w700
  );


  static final nunito_16_400Blue = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 16,
      color: const Color(0xff4684EB),
      fontWeight: FontWeight.w400
  );
  static final nunito_14_700Blue = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff4684EB),
      fontWeight: FontWeight.w700
  );
  static final nunito_14_400Black = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff000000),
      fontWeight: FontWeight.w400
  );
  static final nunito_14_600Black = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff000000),
      fontWeight: FontWeight.w600
  );
  static final nunito_14_400White = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xffFFFFFF),
      fontWeight: FontWeight.w400
  );

  static final nunito_12_red = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 12,
      color: const Color(0xffEB5757),
      fontWeight: FontWeight.w500
  );
  static final nunito_14_400Grey = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff888888),
      fontWeight: FontWeight.w400
  );
  static final nunito_12_400lightpurple = TextStyle(
      fontFamily: latoRegular,
      fontSize: 12,
      color: const Color(0xff666B9A),
      fontWeight: FontWeight.w400
  );

  static final nunito_16_600Grey = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 16,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w600
  );
  static final nunito_16_400Grey = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 16,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w400
  );
  static final nunito_12_400Grey = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 12,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w400
  );
  static final nunito_12_400White = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 12,
      color: const Color(0xffFFFFFF),
      fontWeight: FontWeight.w400
  );
  static final nunito_14_500Grey = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w500
  );
  static final nunito_14_600Grey = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w600
  );
  static final nunito_italic_14_600Grey = TextStyle(
      fontFamily: nunitoItalic,
      fontSize: 14,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w600
  );
  static final nunito_italic_14_400Grey = TextStyle(
      fontFamily: nunitoItalic,
      fontSize: 14,
      color: const Color(0xff9A9C9C),
      fontWeight: FontWeight.w400
  );
  static final nunito_12_500Blue = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff4684EB),
      fontWeight: FontWeight.w500
  );

/*  static final nunito_14_400Blue = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 14,
      color: const Color(0xff4684EB),
      fontWeight: FontWeight.w400
  );*/
  static final nunito_italic_14_400Blue = TextStyle(
      fontFamily: nunitoItalic,
      fontSize: 12,
      fontStyle: FontStyle.italic,
      color: const Color(0xff4684EB),
      fontWeight: FontWeight.w400
  );
  static final nunito_12_500Red = TextStyle(
      fontFamily: nunitoRegular,
      fontSize: 12,
      color: const Color(0xffEB5757),
      fontWeight: FontWeight.w500
  );

}
