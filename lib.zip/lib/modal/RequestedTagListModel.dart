import 'dart:io';

class RequestedTagModel {
  String _id,connectId,userId,userRoleId,partnerId,partnerRoleId,dateTime,status,userIsActive;
  Patner patner;
  UserData userData;

  RequestedTagModel(this._id, this.connectId, this.userId, this.userRoleId,this.partnerId,this.partnerRoleId, this.dateTime,
      this.status,this.userIsActive, this.patner,this.userData);
}


class UserData{
  String userId,firstName,lastName,email,profilePicture,isActive,dob,roleId,tagline;
  String badge;
  String badgeImage;
  int gamificationPoints;
  UserData(this.userId, this.firstName, this.lastName, this.email,
      this.profilePicture, this.isActive, this.dob,this.roleId,this.tagline,this.badge,this.gamificationPoints,this.badgeImage);
}

class Patner{
  String _id,userId,firstName,lastName,email,password,salt,mobileNo,roleId,
      isActive,isPasswordChanged,organizationId,dob,isArchived,profilePicture,requireParentApproval,ccToParents,lastAccess,gender
  ,genderAtBirth,usCitizenOrPR,address,summary,coverImage,tagline,title,tempPassword,education,creationTime;

  String badge;
  String badgeImage;
  int gamificationPoints;

  Patner(this._id, this.userId, this.firstName, this.lastName, this.email,
      this.password, this.salt, this.mobileNo, this.roleId, this.isActive,
      this.isPasswordChanged, this.organizationId, this.dob, this.isArchived,
      this.profilePicture, this.requireParentApproval, this.ccToParents,
      this.lastAccess, this.gender, this.genderAtBirth, this.usCitizenOrPR,
      this.address, this.summary, this.coverImage, this.tagline, this.title,
      this.tempPassword,this.education,this.creationTime,this.badge,this.gamificationPoints,this.badgeImage);


}

class PeopleYouMayKnow{

  String userId,firstName,lastName,email,tagline,mobileNo,profilePicture,roleId;
  bool isActive;
bool isRequested=false;
  String badge;
  String badgeImage;
  int gamificationPoints;
  PeopleYouMayKnow(this.userId,this.firstName,this.lastName,this.email,this.tagline,this.mobileNo,this.profilePicture,this.isActive,this.roleId,this.badge,this.gamificationPoints,this.badgeImage);
}