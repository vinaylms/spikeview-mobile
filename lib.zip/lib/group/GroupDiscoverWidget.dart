import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';

import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';

import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';


class GroupDiscoverWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  GroupDiscoverWidgetState();
  }
}

class GroupDiscoverWidgetState extends State<GroupDiscoverWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, zipCode;
  bool isLoading = true;
  String isPerformChanges = "false";
  List<GroupModel> groupList =  List();

  int offset = 0;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    zipCode = prefs.getString(UserPreference.ZIPCODE);
    await apiCallForGet();
  }

  ScrollController _scrollController =  ScrollController();
  int skip = 0;
  bool isLoadMore = true;
  bool isLoadingData = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _scrollController = ScrollController();
    _scrollController.addListener(_scrollListener);
    getSharedPreferences();
    print("==================== INIT STATE");
  }

  _scrollListener() {
    if (_scrollController.offset >= _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      offset++;
      if (isLoadMore) {
        apiCallForLoadMore();
      }
    }
  }

  Future apiCallJoin(GroupModel groupModel) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupModel.groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId)
        };
        print("joinMap++++" + map.toString());

        response = await  ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //for handling status of group joined or pending
              isPerformChanges = "push";
              setState(() {
                groupModel.isActive = "true";
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

//==========================================================

  Future apiCallForGet() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        Response response;
        response = await  ApiCalling().
        apiCall(context, Constant.ENDPOINT_DISCOVER_GROUP+ userIdPref+"&roleId="+roleId+"&skip=0", "get");

        isLoading = false;
        setState(() {
          isLoading;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupList = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }
  Future apiCallForLoadMore() async {
    try {
      print("load mo0re call");
      isLoadingData = true;
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {

        Response response;
        print("load mo0re call++"+
            Constant.ENDPOINT_DISCOVER_GROUP+ userIdPref+"&roleId="+roleId+"&skip="+offset.toString());
        response = await  ApiCalling().
        apiCall(context, Constant.ENDPOINT_DISCOVER_GROUP+ userIdPref+
            "&roleId="+roleId+"&skip="+offset.toString(), "get");


        isLoadingData = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var groupList1 = ParseJson.parseGroupDiscover(
                  response.data['result'], userIdPref, roleId);
              setState(() {
                groupList.addAll(groupList1);
              });

              if (groupList1.length > 0) {
                setState(() {
                  groupList.addAll(groupList1);
                });
              } else {
                isLoadMore = false;
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadingData = false;

      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Widget getListview(groupModel, index) {
      print("url" + groupModel.groupImage);

      return PaddingWrap.paddingfromLTRB(
        13.0,
        10.0,
        13.0,
        10.0,
        InkWell(
          child:  Container(
              decoration:  BoxDecoration(
                  color: Colors.white,
                  border:  Border.all(
                      color:   ColorValues.DEVIDER_COLOR, width: 0.5)),
              padding:  EdgeInsets.fromLTRB(10.0, 15.0, 10.0, 15.0),
              child:  Card(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child:  Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Expanded(
                            child:  InkWell(
                              child:  Container(
                                height: 60.0,
                                width: 60.0,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(100),
                                  child: groupModel.groupImage == "" ||
                                      groupModel.groupImage == "null"
                                      ?  Image.asset(
                                      'assets/newDesignIcon/group/default_circle_bg.png')
                                      : FadeInImage(
                                    fit: BoxFit.cover,
                                    placeholder: AssetImage(
                                      'assets/newDesignIcon/group/default_circle_bg.png',
                                    ),
                                    image: NetworkImage(
                                        Constant.IMAGE_PATH_SMALL +
                                            ParseJson.getSmallImage(
                                                groupModel.groupImage)),
                                  ),
                                ),
                              ),
                              onTap: () {
                                Navigator.of(context).push(
                                    MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            GroupDetailWidget(
                                                groupModel.groupId,
                                                "",
                                                "",
                                                "",
                                                "")));
                              },
                            ),
                            flex: 0,
                          ),
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        7.0,
                                        2.0,
                                        2.0,
                                        5.0,
                                        RichText(
                                          maxLines: 2,
                                          textAlign: TextAlign.start,
                                          text: TextSpan(
                                            text: groupModel.groupName + " ",
                                            style:  AppTextStyle.getDynamicStyleGroup(
                                                ColorValues.HEADING_COLOR_EDUCATION,14.0,FontType.Bold ),/*TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.bold,
                                            ),*/
                                            children: (!groupModel.isAdmin)
                                                ? null
                                                : <TextSpan>[
                                              TextSpan(
                                                  text: '(Owner)',
                                                  style: TextStyle(
                                                      fontWeight:
                                                      FontWeight
                                                          .normal,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR,
                                                      fontSize: 12.0,
                                                      color:  Color(
                                                          0xFF404040)))
                                            ],
                                          ),
                                        )),
                                    Row(
                                      children: <Widget>[
                                        Expanded(
                                          child:  Row(
                                            children: <Widget>[
                                              PaddingWrap.paddingfromLTRB(
                                                7.0,
                                                3.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  groupModel.type == "private"
                                                      ? "assets/newDesignIcon/group/private_grey.png"
                                                      : "assets/newDesignIcon/group/public_grey.png",
                                                  height: 15.0,
                                                  width: 15.0,
                                                ),
                                              ),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  3.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap
                                                      .textViewMultiLine(
                                                      groupModel.type ==
                                                          MessageConstant.ABOUT_GROUP_PRIVATE
                                                          ? MessageConstant.ABOUT_GROUP_PRIVATE_GROUP
                                                          :  MessageConstant.ABOUT_GROUP_PUBLIC_GROUP,
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal,
                                                      1))
                                            ],
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    )
                                  ],
                                )),
                            flex: 1,
                          ),
                          Expanded(
                            child:  InkWell(
                              child:  Stack(
                                children: <Widget>[
                                  Container(
                                      height: 32.0,
                                      width: 85.0,
                                      color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                      child:  Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: <Widget>[
                                          Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0, 0.0, 0.0, 0.0),
                                            child: TextViewWrap.textView(
                                                groupModel.isActive == "true"
                                                    ? groupModel.isActive ==
                                                    "true" &&
                                                    groupModel.type ==
                                                        "private"
                                                    ? "REQUESTED"
                                                    : "JOINED"
                                                    : "JOIN",
                                                TextAlign.center,
                                                ColorValues.WHITE,
                                                12.0,
                                                FontWeight.normal),
                                          ),
                                        ],
                                      )),
                                  groupModel.isActive == "true"
                                      ? groupModel.isActive == "true" &&
                                      groupModel.type == "private"
                                      ? Container(
                                    height: 32.0,
                                    width: 85.0,
                                    color:
                                    Colors.white.withOpacity(.5),
                                  )
                                      :  Container(
                                    height: 0.0,
                                  )
                                      :  Container(
                                    height: 0.0,
                                  )
                                ],
                              ),
                              onTap: () {
                                if (groupModel.isActive == "true") {
                                } else {
                                  apiCallJoin(groupModel);
                                }
                              },
                            ),
                            flex: 0,
                          )
                        ],
                      ),
                    ],
                  ))),
          onTap: () {
            Navigator.of(context).push(
                MaterialPageRoute(
                    builder: (BuildContext context) =>
                        GroupDetailWidget(
                            groupModel.groupId,
                            "",
                            "",
                            "",
                            "")));
          },
        ),
      );
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                          Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context, isPerformChanges);
                    },
                  )
                ],
              ),
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    MessageConstant.ABOUT_GROUP_DISCOVER_,
                    style:  AppTextStyle.getDynamicStyleGroup(ColorValues.HEADING_COLOR_EDUCATION,18.0,FontType.Regular ),
                    /*TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),*/
                  )
                ],
              ),
              actions: <Widget>[
                Container(
                  width: 35.0,
                ),
              ],
              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body:isLoading?SizedBox(): groupList.length > 0
                ?  ListView(
              controller: _scrollController,
              children: <Widget>[
                Column(
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children:  List.generate(groupList.length,
                                (int index) {

                              return getListview(groupList[index], index);
                            }))
                  ],
                )
              ],
            )
                : Column(
              crossAxisAlignment:
              CrossAxisAlignment.center,
              mainAxisAlignment:
              MainAxisAlignment.start,
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    100.0,
                    0.0,
                    0.0,
                    Image.asset(
                      "assets/no_search.png",
                      width: double.infinity,
                      height: 151.0,
                    )),
                PaddingWrap.paddingfromLTRB(
                    40.0,
                    20.0,
                    40.0,
                    5.0,
                    TextViewWrap.textViewMultiLine(
                        "Hmm, No results found!",
                        TextAlign.center,
                        ColorValues.GREY_TEXT_COLOR,
                        16.0,
                        FontWeight.bold,
                        2)),

              ],
            )));
  }
}
