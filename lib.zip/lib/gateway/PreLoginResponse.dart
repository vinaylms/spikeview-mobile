class PreLoginResponse {
  String status;
  Result result;
  HighLightsImages highLightsImages;
  List<ExploreImg> exploreImg;
  List<UserDetails> userDetails;

  PreLoginResponse(
      {this.status,
        this.result,
        this.highLightsImages,
        this.exploreImg,
        this.userDetails});

  PreLoginResponse.fromJson(Map<String, dynamic> json) {
    try{
    status = json['status'];
    result =
    json['result'] != null ?  Result.fromJson(json['result']) : null;
    highLightsImages = json['highLightsImages'] != null
        ?  HighLightsImages.fromJson(json['highLightsImages'])
        : null;
    if (json['exploreImg'] != null) {
      exploreImg =  List<ExploreImg>();
      json['exploreImg'].forEach((v) {
        exploreImg.add(new ExploreImg.fromJson(v));
      });
    }
    if (json['userDetails'] != null) {
      userDetails =  List<UserDetails>();
      json['userDetails'].forEach((v) {
        userDetails.add(new UserDetails.fromJson(v));
      });
    }
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    if (this.highLightsImages != null) {
      data['highLightsImages'] = this.highLightsImages.toJson();
    }
    if (this.exploreImg != null) {
      data['exploreImg'] = this.exploreImg.map((v) => v.toJson()).toList();
    }
    if (this.userDetails != null) {
      data['userDetails'] = this.userDetails.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Result {
  int themeId;
  String themeName;
  int creationTime;
  int updateTime;
  String leaderboardTitle;
  String leaderboardDescription;
  LeaderboardBackgroundImg leaderboardBackgroundImg;
  String leaderboardView;
  String highlightsView;
  String highlightsTitle;
  String highlightsDescription;
  int userLimit;
  LeaderboardBackgroundImg highlightsBackgroundImg;
  bool publish;
  bool approved;
  String status;
  int createdBy;
  int createdByRole;

  Result(
      {this.themeId,
        this.themeName,
        this.creationTime,
        this.updateTime,
        this.leaderboardTitle,
        this.leaderboardDescription,
        this.leaderboardBackgroundImg,
        this.leaderboardView,
        this.highlightsView,
        this.highlightsTitle,
        this.highlightsDescription,
        this.userLimit,
        this.highlightsBackgroundImg,
        this.publish,
        this.approved,
        this.status,
        this.createdBy,
        this.createdByRole});

  Result.fromJson(Map<String, dynamic> json) {
    try{
    themeId = json['themeId'];
    themeName = json['themeName'];
    creationTime = json['creationTime'];
    updateTime = json['updateTime'];
    leaderboardTitle = json['leaderboardTitle'];
    leaderboardDescription = json['leaderboardDescription'];
    leaderboardBackgroundImg = json['leaderboardBackgroundImg'] != null
        ?  LeaderboardBackgroundImg.fromJson(
        json['leaderboardBackgroundImg'])
        : null;
    leaderboardView = json['leaderboardView'];
    highlightsView = json['highlightsView'];
    highlightsTitle = json['highlightsTitle'];
    highlightsDescription = json['highlightsDescription'];
    userLimit = json['userLimit'];
    highlightsBackgroundImg = json['highlightsBackgroundImg'] != null
        ?  LeaderboardBackgroundImg.fromJson(json['highlightsBackgroundImg'])
        : null;
    publish = json['publish'];
    approved = json['approved'];
    status = json['status'];
    createdBy = json['createdBy'];
    createdByRole = json['createdByRole'];
  }catch(e){

  print("prelogin fromJson ErrorUser++"+e.toString());
  }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['themeId'] = this.themeId;
    data['themeName'] = this.themeName;
    data['creationTime'] = this.creationTime;
    data['updateTime'] = this.updateTime;
    data['leaderboardTitle'] = this.leaderboardTitle;
    data['leaderboardDescription'] = this.leaderboardDescription;
    if (this.leaderboardBackgroundImg != null) {
      data['leaderboardBackgroundImg'] = this.leaderboardBackgroundImg.toJson();
    }
    data['leaderboardView'] = this.leaderboardView;
    data['highlightsView'] = this.highlightsView;
    data['highlightsTitle'] = this.highlightsTitle;
    data['highlightsDescription'] = this.highlightsDescription;
    data['userLimit'] = this.userLimit;
    if (this.highlightsBackgroundImg != null) {
      data['highlightsBackgroundImg'] = this.highlightsBackgroundImg.toJson();
    }
    data['publish'] = this.publish;
    data['approved'] = this.approved;
    data['status'] = this.status;
    data['createdBy'] = this.createdBy;
    data['createdByRole'] = this.createdByRole;
    return data;
  }
}

class LeaderboardBackgroundImg {
  String width;
  String heigth;
  String file;

  LeaderboardBackgroundImg({this.width, this.heigth, this.file});

  LeaderboardBackgroundImg.fromJson(Map<String, dynamic> json) {
    try{
    width = json['width'];
    heigth = json['heigth'];
    file = json['file'];
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['width'] = this.width;
    data['heigth'] = this.heigth;
    data['file'] = this.file;
    return data;
  }
}

class HighLightsImages {
  List<Blocks> landscape;
  List<Blocks> portrait;

  HighLightsImages({this.landscape, this.portrait});

  HighLightsImages.fromJson(Map<String, dynamic> json) {
    try{
    if (json['landscape'] != null) {
      landscape =  List<Blocks>();
      json['landscape'].forEach((v) {
        landscape.add(new Blocks.fromJson(v));
      });
    }
    if (json['portrait'] != null) {
      portrait =  List<Blocks>();
      json['portrait'].forEach((v) {
        portrait.add(new Blocks.fromJson(v));
      });
    }
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    if (this.landscape != null) {
      data['landscape'] = this.landscape.map((v) => v.toJson()).toList();
    }
    if (this.portrait != null) {
      data['portrait'] = this.portrait.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Blocks {
  String type;
  String largeImgHeight;
  String largeImgWidth;
  String largeImg;
  String smallImgHeight;
  String smallImgWidth;
  String smallImg;
  String file;
  String thubnail;

  Blocks(
      {this.type,
        this.largeImgHeight,
        this.largeImgWidth,
        this.largeImg,
        this.smallImgHeight,
        this.smallImgWidth,
        this.smallImg,
        this.file,
        this.thubnail
      });

  Blocks.fromJson(Map<String, dynamic> json) {
    try{
    type = json['type'];
    largeImgHeight = json['largeImgHeight'];
    largeImgWidth = json['largeImgWidth'];
    largeImg = json['largeImg'];
    smallImgHeight = json['smallImgHeight'];
    smallImgWidth = json['smallImgWidth'];
    smallImg = json['smallImg'];
    file = json['file'];
    thubnail = json['thubnail'];
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['type'] = this.type;
    data['largeImgHeight'] = this.largeImgHeight;
    data['largeImgWidth'] = this.largeImgWidth;
    data['largeImg'] = this.largeImg;
    data['smallImgHeight'] = this.smallImgHeight;
    data['smallImgWidth'] = this.smallImgWidth;
    data['smallImg'] = this.smallImg;
    data['file'] = this.file;
    data['thubnail'] = this.thubnail;
    return data;
  }
}

class ExploreImg {
  List<Blocks> blocks;

  ExploreImg({this.blocks});

  ExploreImg.fromJson(Map<String, dynamic> json) {
    try{
    if (json['blocks'] != null) {
      blocks =  List<Blocks>();
      json['blocks'].forEach((v) {
        blocks.add(new Blocks.fromJson(v));
      });
    }
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    if (this.blocks != null) {
      data['blocks'] = this.blocks.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class UserDetails {
  String sId;
  int userId;
  String email;
  String password;
  String salt;
  int mobileNo;
  String profilePicture;
  int roleId;
  bool isActive;
  bool isPasswordChanged;
  int organizationId;
  String gender;
  int dob;
  bool isArchived;
  int creationTime;
  String zipCode;
  String country;
  String state;
  String city;
  bool userLoginFirstTime;
  bool isHide;
  int referralPopupShowDate;
  int stage;
  int gamificationPoints;
  String referCode;
  int iV;
  String coverImage;
  String tagline;
  String badge;
  List<IntroducingFeatures> introducingFeatures;
  bool isLeaderboardDisplay;
  String userType;
  List<CommunityPostSubscription> communityPostSubscription;
  List<NotificationSettings> notificationSettings;
  bool isEmailSubscribed;
  List<String> userInterest;
  List<Role> role;
  List<Parents> parents;
  String lastName;
  String firstName;
  String badgeImage;
  int rank;
  String tempPassword;
  bool isPartnerMailSent;
  String countryCode;
  bool isWizard;
  String summary;
  bool isEducation;
  bool isAchievement;
  int lastSeen;
  Address address;

  UserDetails(
      {this.sId,
        this.userId,
        this.email,
        this.password,
        this.salt,
        this.mobileNo,
        this.profilePicture,
        this.roleId,
        this.isActive,
        this.isPasswordChanged,
        this.organizationId,
        this.gender,
        this.dob,
        this.isArchived,
        this.creationTime,
        this.zipCode,
        this.country,
        this.state,
        this.city,
        this.userLoginFirstTime,
        this.isHide,
        this.referralPopupShowDate,
        this.stage,
        this.gamificationPoints,
        this.referCode,
        this.iV,
        this.coverImage,
        this.tagline,
        this.badge,
        this.introducingFeatures,
        this.isLeaderboardDisplay,
        this.userType,
        this.communityPostSubscription,
        this.notificationSettings,
        this.isEmailSubscribed,
        this.userInterest,
        this.role,
        this.parents,
        this.lastName,
        this.firstName,
        this.badgeImage,
        this.rank,
        this.tempPassword,
        this.isPartnerMailSent,
        this.countryCode,
        this.isWizard,
        this.summary,
        this.isEducation,
        this.isAchievement,
        this.lastSeen,
        this.address});

  UserDetails.fromJson(Map<String, dynamic> json) {
    try{
    sId = json['_id'];
    userId = json['userId'];
    email = json['email'];
    password = json['password'];
    salt = json['salt'];
    mobileNo = json['mobileNo'];
    profilePicture = json['profilePicture'];
    roleId = json['roleId'];
    isActive = json['isActive'];
    isPasswordChanged = json['isPasswordChanged'];
    organizationId = json['organizationId'];
    gender = json['gender'];
    if(gender=="Non-binary"||gender=="NonBinary"){
      gender="Non-Binary";
    }
    dob = json['dob'];
    isArchived = json['isArchived'];
    creationTime = json['creationTime'];
    zipCode = json['zipCode'];
    country = json['country'];
    state = json['state'];
    city = json['city'];
    userLoginFirstTime = json['userLoginFirstTime'];
    isHide = json['isHide'];
    referralPopupShowDate = json['referralPopupShowDate'];
    stage = json['stage'];
    gamificationPoints = json['gamificationPoints'];
    referCode = json['referCode'];
    iV = json['__v'];
    coverImage = json['coverImage'];
    tagline = json['tagline'];
    badge = json['badge'];
    if (json['introducingFeatures'] != null) {
      introducingFeatures =  List<IntroducingFeatures>();
      json['introducingFeatures'].forEach((v) {
        introducingFeatures.add(new IntroducingFeatures.fromJson(v));
      });
    }
    isLeaderboardDisplay = json['isLeaderboardDisplay'];
    userType = json['userType'];
    if (json['communityPostSubscription'] != null) {
      communityPostSubscription =  List<CommunityPostSubscription>();
      json['communityPostSubscription'].forEach((v) {
        communityPostSubscription
            .add(new CommunityPostSubscription.fromJson(v));
      });
    }
    if (json['notificationSettings'] != null) {
      notificationSettings =  List<NotificationSettings>();
      json['notificationSettings'].forEach((v) {
        notificationSettings.add(new NotificationSettings.fromJson(v));
      });
    }
    isEmailSubscribed = json['isEmailSubscribed'];
    userInterest = json['userInterest'].cast<String>();
    if (json['role'] != null) {
      role =  List<Role>();
      json['role'].forEach((v) {
        role.add(new Role.fromJson(v));
      });
    }
    if (json['parents'] != null) {
      parents =  List<Parents>();
      json['parents'].forEach((v) {
        parents.add(new Parents.fromJson(v));
      });
    }
    lastName = json['lastName'];
    firstName = json['firstName'];
    badgeImage = json['badgeImage'];
    rank = json['rank'];
    tempPassword = json['tempPassword'];
    isPartnerMailSent = json['isPartnerMailSent'];
    countryCode = json['countryCode'];
    isWizard = json['isWizard'];
    summary = json['summary'];
    isEducation = json['isEducation'];
    isAchievement = json['isAchievement'];
    lastSeen = json['lastSeen'];
    address =
    json['address'] != null ?  Address.fromJson(json['address']) : null;
  }catch(e){

  print("prelogin fromJson ErrorUser++"+e.toString());
  }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userId'] = this.userId;
    data['email'] = this.email;
    data['password'] = this.password;
    data['salt'] = this.salt;
    data['mobileNo'] = this.mobileNo;
    data['profilePicture'] = this.profilePicture;
    data['roleId'] = this.roleId;
    data['isActive'] = this.isActive;
    data['isPasswordChanged'] = this.isPasswordChanged;
    data['organizationId'] = this.organizationId;
    data['gender'] = this.gender;
    data['dob'] = this.dob;
    data['isArchived'] = this.isArchived;
    data['creationTime'] = this.creationTime;
    data['zipCode'] = this.zipCode;
    data['country'] = this.country;
    data['state'] = this.state;
    data['city'] = this.city;
    data['userLoginFirstTime'] = this.userLoginFirstTime;
    data['isHide'] = this.isHide;
    data['referralPopupShowDate'] = this.referralPopupShowDate;
    data['stage'] = this.stage;
    data['gamificationPoints'] = this.gamificationPoints;
    data['referCode'] = this.referCode;
    data['__v'] = this.iV;
    data['coverImage'] = this.coverImage;
    data['tagline'] = this.tagline;
    data['badge'] = this.badge;
    if (this.introducingFeatures != null) {
      data['introducingFeatures'] =
          this.introducingFeatures.map((v) => v.toJson()).toList();
    }
    data['isLeaderboardDisplay'] = this.isLeaderboardDisplay;
    data['userType'] = this.userType;
    if (this.communityPostSubscription != null) {
      data['communityPostSubscription'] =
          this.communityPostSubscription.map((v) => v.toJson()).toList();
    }
    if (this.notificationSettings != null) {
      data['notificationSettings'] =
          this.notificationSettings.map((v) => v.toJson()).toList();
    }
    data['isEmailSubscribed'] = this.isEmailSubscribed;
    data['userInterest'] = this.userInterest;
    if (this.role != null) {
      data['role'] = this.role.map((v) => v.toJson()).toList();
    }
    if (this.parents != null) {
      data['parents'] = this.parents.map((v) => v.toJson()).toList();
    }
    data['lastName'] = this.lastName;
    data['firstName'] = this.firstName;
    data['badgeImage'] = this.badgeImage;
    data['rank'] = this.rank;
    data['tempPassword'] = this.tempPassword;
    data['isPartnerMailSent'] = this.isPartnerMailSent;
    data['countryCode'] = this.countryCode;
    data['isWizard'] = this.isWizard;
    data['summary'] = this.summary;
    data['isEducation'] = this.isEducation;
    data['isAchievement'] = this.isAchievement;
    data['lastSeen'] = this.lastSeen;
    if (this.address != null) {
      data['address'] = this.address.toJson();
    }
    return data;
  }
}

class IntroducingFeatures {
  bool display;
  bool exploreOpportunity;
  bool gamification;
  bool communityPost;
  int roleId;

  IntroducingFeatures(
      {this.display,
        this.exploreOpportunity,
        this.gamification,
        this.communityPost,
        this.roleId});

  IntroducingFeatures.fromJson(Map<String, dynamic> json) {
    try{
    display = json['display'];
    exploreOpportunity = json['exploreOpportunity'];
    gamification = json['gamification'];
    communityPost = json['communityPost'];
    roleId = json['roleId'];
  }catch(e){

  print("prelogin fromJson ErrorUser++"+e.toString());
  }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['display'] = this.display;
    data['exploreOpportunity'] = this.exploreOpportunity;
    data['gamification'] = this.gamification;
    data['communityPost'] = this.communityPost;
    data['roleId'] = this.roleId;
    return data;
  }
}

class CommunityPostSubscription {
  bool isSubscribed;
  int roleId;

  CommunityPostSubscription({this.isSubscribed, this.roleId});

  CommunityPostSubscription.fromJson(Map<String, dynamic> json) {
    try{
    isSubscribed = json['isSubscribed'];
    roleId = json['roleId'];
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['isSubscribed'] = this.isSubscribed;
    data['roleId'] = this.roleId;
    return data;
  }
}

class NotificationSettings {
  bool feedNotification;
  bool profileNotification;
  bool allNotification;
  int roleId;

  NotificationSettings(
      {this.feedNotification,
        this.profileNotification,
        this.allNotification,
        this.roleId});

  NotificationSettings.fromJson(Map<String, dynamic> json) {
    try{
    feedNotification = json['feedNotification'];
    profileNotification = json['profileNotification'];
    allNotification = json['allNotification'];
    roleId = json['roleId'];
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['feedNotification'] = this.feedNotification;
    data['profileNotification'] = this.profileNotification;
    data['allNotification'] = this.allNotification;
    data['roleId'] = this.roleId;
    return data;
  }
}

class Role {
  int id;

  Role({this.id});

  Role.fromJson(Map<String, dynamic> json) {
    try{
    id = json['id'];
    }catch(e){

      print("prelogin fromJson ErrorUser++"+e.toString());
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['id'] = this.id;
    return data;
  }
}

class Parents {
  String email;
  int userId;

  Parents({this.email, this.userId});

  Parents.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    userId = json['userId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['email'] = this.email;
    data['userId'] = this.userId;
    return data;
  }
}

class Address {
  //int zip;
  String zip;
  String country;
  String state;
  String city;
  String street2;
  String street1;

  Address(
      {this.zip,
        this.country,
        this.state,
        this.city,
        this.street2,
        this.street1});

  Address.fromJson(Map<String, dynamic> json) {
    zip = json['zip'].toString();
    country = json['country'];
    state = json['state'];
    city = json['city'];
    street2 = json['street2'];
    street1 = json['street1'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['zip'] = this.zip;
    data['country'] = this.country;
    data['state'] = this.state;
    data['city'] = this.city;
    data['street2'] = this.street2;
    data['street1'] = this.street1;
    return data;
  }
}
