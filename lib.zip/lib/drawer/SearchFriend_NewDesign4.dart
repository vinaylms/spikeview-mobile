import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

import 'OpportunitySearch.dart';

class SearchFriendNewDesign extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => SearchFriendState();
}

class SearchFriendState extends State<SearchFriendNewDesign>
    with BaseCommonWidget {
  bool isHome = true;
  bool isConnection = false;
  bool isMessage = false;
  bool isMore = false;
  TextEditingController _searchQuery = TextEditingController(text: "");
  bool _isSearching = false;
  String previousText = "";
  SharedPreferences prefs;
  String userIdPref, token, roleId;
  bool isParent = false;
  int previousLength = 0;
  List<ProfileInfoModal> friendList = List();
  List<GroupInfoModel> groupList = List();
  List<ProfileInfoModal> parentList = List();
  List<ProfileInfoModal> partnerList = List();
  List<OpportunityModelForFeed> _mOpportunityModelList = List();
  int offset = 0;
  int groupCount = 0;
  int parentCount = 0;
  int studentCount = 0;
  int partnerCount = 0;
  int opportunityCount = 0;
  bool isApiCalling = false;
  bool isTyping = false;
  bool isApiCallingLoader = false;
  String doubleCodeForSearchHint = "\"";
  List<String> searchFilterNameList = List();
  bool isStudentFilterSelected = false;
  bool isPartnerFilterSelected = false;
  bool isParentFilterSelected = false;
  bool isGroupFilterSelected = false;

  void deSelectAllFilters() {
    isStudentFilterSelected = false;
    isPartnerFilterSelected = false;
    isParentFilterSelected = false;
    isGroupFilterSelected = false;
  }

  //--------------------------My Narratives Info api ------------------
  Future apiCallingForFrindList() async {
    try {
      Response response = await ApiCalling()
          .apiCall(context, Constant.ENDPOINT_FRIEND_LIST + userIdPref, "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            friendList.clear();
            groupList.clear();
            parentList.clear();
            partnerList.clear();
            var result = response.data['result'];
            friendList = ParseJson.parseUserFriendList(
                result.data['userList'], userIdPref);
            groupList =
                ParseJson.parseGroupList(result.data['groupList'], userIdPref);
            if (friendList.length > 0) {
              setState(() {});
            }
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------My Narratives Info api ------------------
  Future apiCallingForFrindList2() async {
    try {
      if (_searchQuery.text.toString().length >= 1) {
        previousText = _searchQuery.text;

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_RESKIN +
                _searchQuery.text.toString() +
                "&like=true" +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        isApiCalling = false;
        setState(() {});
        print('vkk2');
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              friendList.clear();
              groupList.clear();
              parentList.clear();
              partnerList.clear();
              _mOpportunityModelList.clear();
              groupCount = 0;
              studentCount = 0;
              parentCount = 0;
              partnerCount = 0;
              opportunityCount = 0;

              var result = response.data['result'];
              groupCount = result['groupCount'];
              studentCount = result['studentCount'];
              parentCount = result['parentCount'];
              partnerCount = result['partnerCount'];
              opportunityCount = result['opportunityCount'];

              var userListMap = result['studentList'] as List;
              if (userListMap.length > 0) {
                friendList =
                    ParseJson.parseUserFriendList(userListMap, userIdPref);
              }
              // if(!isParent){
              var groupListMap = result['groupList'] as List;
              if (groupListMap.length > 0) {
                groupList = ParseJson.parseGroupList(groupListMap, userIdPref);
              }
              //   }

              var parentListMap = result['parentList'] as List;
              if (parentListMap.length > 0) {
                parentList =
                    ParseJson.parseUserFriendList(parentListMap, userIdPref);
              }

              var partnerListMap = result['partnerList'] as List;
              if (partnerListMap.length > 0) {
                partnerList =
                    ParseJson.parseUserFriendList(partnerListMap, userIdPref);
              }

              var opportunityListMap = result['opportunityList'] as List;
              if (opportunityListMap.length > 0) {
                _mOpportunityModelList =
                    ParseJson.parseOpportunity(opportunityListMap, userIdPref);
              }

              if (friendList.length > 0 ||
                  groupList.length > 0 ||
                  partnerList.length > 0 ||
                  parentList.length > 0) {
                setState(() {});
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {});
    } catch (e) {
      isApiCalling = false;
      setState(() {});
      e.toString();
    }
  }

  Future apiCallingForFrindFullList3(s, status1) async {
    friendList.clear();
    groupList.clear();
    parentList.clear();
    partnerList.clear();
    try {
      if (s.length >= 1) {
        previousText = _searchQuery.text;
        isApiCalling = true;
        setState(() {});
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_RESKIN_BY_STATUS +
                s +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&status=" +
                status1 +
                "&like=true",
            "get");
        isApiCalling = false;
        setState(() {});
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var result = response.data['result'];
              print(result);
              if (status1 == "1") {
                var userListMap = result['dataList'] as List;
                friendList.clear();
                if (userListMap.length > 0) {
                  friendList =
                      ParseJson.parseUserFriendList(userListMap, userIdPref);
                }
              } else if (status1 == "2") {
                var parentListMap = result['dataList'] as List;
                if (parentListMap.length > 0) {
                  parentList =
                      ParseJson.parseUserFriendList(parentListMap, userIdPref);
                  print("---- parentList ${parentList.length}");
                }
              } else if ((status1 == "10")) {
                var groupListMap = result['groupList'] as List;
                if (groupListMap.length > 0) {
                  groupList =
                      ParseJson.parseGroupList(groupListMap, userIdPref);
                }
              } else if (status1 == "4") {
                var partnerListMap = result['dataList'] as List;
                if (partnerListMap.length > 0) {
                  partnerList =
                      ParseJson.parseUserFriendList(partnerListMap, userIdPref);
                }
              }
              if (friendList.length > 0 ||
                  groupList.length > 0 ||
                  partnerList.length > 0 ||
                  parentList.length > 0) {
                setState(() {});
              }
            }
          }
        }
      }
      isApiCalling = false;
      setState(() {});
    } catch (e) {
      isApiCalling = false;
      setState(() {});
    }
  }

  Future apiLoadMore(s, status1) async {
    try {
      if (s.length >= 1) {
        previousText = _searchQuery.text;
        isApiCallingLoader = true;
        setState(() {});
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_SEARCH_RESKIN_BY_STATUS +
                s +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId +
                "&status=" +
                status1 +
                "&like=true" +
                "&skip=" +
                offset.toString(),
            "get");
        isApiCalling = false;
        isApiCallingLoader = false;
        setState(() {});
        if (response != null && response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            var result = response.data['result'];
            if (status1 == "1") {
              var userListMap = result['dataList'] as List;
              if (userListMap.length > 0) {
                var _friendList =
                    ParseJson.parseUserFriendList(userListMap, userIdPref);
                friendList.addAll(_friendList);
              }
            } else if (status1 == "2") {
              var parentListMap = result['dataList'] as List;
              if (parentListMap.length > 0) {
                var _parentList =
                    ParseJson.parseUserFriendList(parentListMap, userIdPref);
                parentList.addAll(_parentList);
              }
            } else if ((status1 == "")) {
              var groupListMap = result['groupList'] as List;
              if (groupListMap.length > 0) {
                var _groupList =
                    ParseJson.parseGroupList(groupListMap, userIdPref);
                groupList.addAll(_groupList);
              }
            } else if (status1 == "4") {
              var partnerListMap = result['dataList'] as List;
              if (partnerListMap.length > 0) {
                var _partnerList =
                    ParseJson.parseUserFriendList(partnerListMap, userIdPref);
                partnerList.addAll(_partnerList);
              }
            }
            setState(() {});
          }
        }
      }
    } catch (e) {
      isApiCallingLoader = false;
      setState(() {});
    }
  }

  Timer _timer;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    isParent = prefs.getBool("isParent");
    if (isParent == null) {
      isParent = false;
    }
    onFilterClick(0);
  }

  ScrollController _controller = ScrollController();

  _scrollListener() {
    if (isStudentFilterSelected ||
        isPartnerFilterSelected ||
        isParentFilterSelected ||
        isGroupFilterSelected) {
      if (_controller.offset >= _controller.position.maxScrollExtent &&
          !_controller.position.outOfRange) {
        offset++;
        if (isStudentFilterSelected)
          apiLoadMore(_searchQuery.text, "1");
        else if (isParentFilterSelected)
          apiLoadMore(_searchQuery.text, "2");
        else if (isGroupFilterSelected)
          apiLoadMore(_searchQuery.text, "");
        else if (isPartnerFilterSelected) apiLoadMore(_searchQuery.text, "4");
      }
    }
  }

  @override
  void initState() {
    _controller = ScrollController();
    _controller.addListener(_scrollListener);
    searchFilterNameList.add("STUDENTS");
    searchFilterNameList.add("PARENTS");
    searchFilterNameList.add("GROUPS");
    searchFilterNameList.add("PARTNERS");
    getSharedPreferences();
    _searchQuery.addListener(() {
      isTyping = true;
      isApiCalling = false;
      setState(() {});
      if (_searchQuery.text.trim().length >= 1) {
        if (previousText != _searchQuery.text) {
          if (_timer != null) {
            _timer.cancel();
          }
          _timer = Timer(Duration(milliseconds: 700), () {
            previousText = _searchQuery.text;
            isTyping = false;
            isApiCalling = true;
            friendList.clear();
            groupList.clear();
            parentList.clear();
            partnerList.clear();
            _mOpportunityModelList.clear();
            setState(() {});
            if (!isStudentFilterSelected &&
                !isParentFilterSelected &&
                !isGroupFilterSelected &&
                !isPartnerFilterSelected) {
              _timer.cancel();
              apiCallingForFrindList2();
            } else {
              _timer.cancel();
              if (isStudentFilterSelected)
                apiCallingForFrindFullList3(_searchQuery.text, "1");
              else if (isParentFilterSelected)
                apiCallingForFrindFullList3(_searchQuery.text, "2");
              else if (isGroupFilterSelected)
                apiCallingForFrindFullList3(_searchQuery.text, "10");
              else if (isPartnerFilterSelected)
                apiCallingForFrindFullList3(_searchQuery.text, "4");
            }
            setState(() {
              _isSearching = true;
            });
          });
        }
      } else {
        setState(() {
          isApiCalling = false;
          isTyping = false;
          friendList.clear();
          groupList.clear();
          parentList.clear();
          partnerList.clear();
          _isSearching = false;
        });
      }
    });
    super.initState();
  }

  Future apiCallForConnect(userID, index, partnerRoleId) async {
    try {
      if (roleId == "4") {
        ToastWrap.showToast(
            MessageConstant
                .PARTNER_NOT_ALLOWED_CONNECTON_REQUEST_SPIKEVIEW_USERS_ERROR,
            context);
      } else {
        var isConnect = await ConectionDetecter.isConnected();
        if (isConnect) {
          bool ageStatus = false;
          if (prefs.getString(UserPreference.DOB) != null &&
              prefs.getString(UserPreference.DOB) != 'null') {
            ageStatus = Util.currentAge(
                    DateTime.fromMillisecondsSinceEpoch(
                        int.tryParse(prefs.getString(UserPreference.DOB))),
                    13) <
                13;
          }
          Map map = {
            "userId": userIdPref,
            "partnerId": userID,
            "dateTime": DateTime.now().millisecondsSinceEpoch,
            "status": ageStatus ? "Pending" : "Requested",
            "userRoleId": int.parse(roleId),
            "partnerRoleId": int.parse(partnerRoleId),
            "isActive": true
          };
          Response response = await ApiCalling().apiCallPostWithMapData(
              context, Constant.ENDPOINT_CONNECTION_UPDATE, map);
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                if (partnerRoleId == "1") {
                  friendList[index].status = "2";
                  friendList[index].statusVal = "Requested";
                  setState(() {});
                } else if (partnerRoleId == "2") {
                  parentList[index].status = "2";
                  parentList[index].statusVal = "Requested";
                  setState(() {});
                } else if (partnerRoleId == "4") {
                  partnerList[index].status = "2";
                  partnerList[index].statusVal = "Requested";
                  setState(() {});
                }
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Widget _buildGroupSearchList() {
    return groupList.isNotEmpty
        ? ListView.separated(
            itemBuilder: (_, index) {
              return InkWell(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    child: Row(
                      children: [
                        Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: Colors.white, width: 1)),
                          margin: EdgeInsets.zero,
                          elevation: 0,
                          clipBehavior: Clip.antiAlias,
                          child: CachedNetworkImage(
                            height: 48,
                            width: 48,
                            fit: BoxFit.cover,
                            imageUrl: Constant.IMAGE_PATH_SMALL +
                                ParseJson.getSmallImage(
                                    groupList[index].groupImage),
                            placeholder: (_, str) {
                              return Container(
                                height: 48,
                                width: 48,
                                alignment: Alignment.center,
                                child: SizedBox(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(
                                      Colors.black54,
                                    ),
                                    strokeWidth: 2.0,
                                  ),
                                ),
                              );
                            },
                            errorWidget: (_, str, e) {
                              return Image.asset(
                                "assets/newDesignIcon/group/default_circle_bg.png",
                                height: 48,
                                width: 48,
                                fit: BoxFit.fill,
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              BaseText(
                                text: groupList[index].groupId != "null" &&
                                        groupList[index].groupId != ""
                                    ? groupList[index].groupName
                                    : groupList[index].groupName,
                                textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                              const SizedBox(height: 3),
                              Row(
                                children: <Widget>[
                                  Image.asset(
                                    groupList[index].type == "private"
                                        ? "assets/png/private_group.png"
                                        : "assets/png/public_group.png",
                                    height: 15.0,
                                    width: 15.0,
                                  ),
                                  BaseText(
                                    text: groupList[index].type ==
                                            MessageConstant.ABOUT_GROUP_PRIVATE
                                        ? MessageConstant
                                            .ABOUT_GROUP_PRIVATE_GROUP
                                        : MessageConstant
                                            .ABOUT_GROUP_PUBLIC_GROUP,
                                    textColor: ColorValues.labelColor,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14,
                                    textAlign: TextAlign.start,
                                    maxLines: 3,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  onTap: () {
                    Navigator.of(context).pop();
                    if (groupList[index].groupId != "null" &&
                        groupList[index].groupId != "") {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => GroupDetailWidget(
                              groupList[index].groupId, "search", "", "", ""),
                        ),
                      );
                    }
                  });
            },
            separatorBuilder: (_, index) => Divider(
              color: const Color(0xffD4E4FF),
              thickness: 1,
              height: 0,
            ),
            itemCount: groupList.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
          )
        : const SizedBox.shrink();
  }

  Widget _buildFriendSearchList() {
    return friendList.isNotEmpty
        ? ListView.separated(
            itemBuilder: (_, index) {
              return InkWell(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    child: Row(
                      children: [
                        Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: Colors.white, width: 1)),
                          margin: EdgeInsets.zero,
                          elevation: 0,
                          clipBehavior: Clip.antiAlias,
                          child: CachedNetworkImage(
                            height: 48,
                            width: 48,
                            fit: BoxFit.cover,
                            imageUrl: Constant.IMAGE_PATH_SMALL +
                                ParseJson.getSmallImage(
                                    friendList[index].profilePicture),
                            placeholder: (_, str) {
                              return Container(
                                height: 48,
                                width: 48,
                                alignment: Alignment.center,
                                child: SizedBox(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(
                                      Colors.black54,
                                    ),
                                    strokeWidth: 2.0,
                                  ),
                                ),
                              );
                            },
                            errorWidget: (_, str, e) {
                              return Image.asset(
                                "assets/default_profile.png",
                                height: 48,
                                width: 48,
                                fit: BoxFit.fill,
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              BaseText(
                                text: friendList[index].groupId != "null" &&
                                        friendList[index].groupId != ""
                                    ? friendList[index].groupName
                                    : friendList[index].lastName == "null"
                                        ? friendList[index].firstName
                                        : friendList[index].firstName +
                                            " " +
                                            friendList[index].lastName,
                                textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                              BaseText(
                                text: friendList[index].tagline == null ||
                                        friendList[index].tagline == "null" ||
                                        friendList[index].tagline == ""
                                    ? ""
                                    : friendList[index].tagline,
                                textColor: AppConstants.colorStyle.lightPurple,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w400,
                                fontSize: 14,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),

                        ButtonView(
                          btnName:   friendList[index].status ==
                              Constant.ACCEPTED
                              ? 'Connected'
                              : friendList[index].status ==
                              Constant.REQUESTED ||
                              friendList[index].status ==
                                  Constant.PENDING
                              ? 'Requested'
                              : 'Connect',
                          borderColor: AppConstants.colorStyle.lightBlue,
                          bgColor: AppConstants.colorStyle.box_bg_color,
                          txtColor: AppConstants.colorStyle.lightBlue,
                          onButtonTap: () {
                            if (friendList[index].status ==
                                Constant.NON_CONNECTION) {
                              apiCallForConnect(friendList[index].userId, index,
                                  friendList[index].roleId);
                            }
                          },
                        )


                      ],
                    ),
                  ),
                  onTap: () {
                    if (friendList[index].userId != userIdPref) {
                      Util.onTapImageTile(
                          tapedUserRole: "1",
                          partnerUserId: friendList[index].userId,
                          pageName: "search",
                          context: context);
                    }
                  });
            },
            separatorBuilder: (_, index) => Divider(
              color: const Color(0xffD4E4FF),
              thickness: 1,
              height: 0,
            ),
            itemCount: friendList.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
          )
        : const SizedBox.shrink();
  }

  Widget _buildParentsList() {
    return parentList.isNotEmpty
        ? ListView.separated(
            itemBuilder: (_, index) {
              return InkWell(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    child: Row(
                      children: [
                        Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: Colors.white, width: 1)),
                          margin: EdgeInsets.zero,
                          elevation: 0,
                          clipBehavior: Clip.antiAlias,
                          child: CachedNetworkImage(
                            height: 48,
                            width: 48,
                            fit: BoxFit.cover,
                            imageUrl: Constant.IMAGE_PATH_SMALL +
                                ParseJson.getSmallImage(
                                    parentList[index].profilePicture),
                            placeholder: (_, str) {
                              return Container(
                                height: 48,
                                width: 48,
                                alignment: Alignment.center,
                                child: SizedBox(
                                  width: 30,
                                  height: 30,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(
                                      Colors.black54,
                                    ),
                                    strokeWidth: 2.0,
                                  ),
                                ),
                              );
                            },
                            errorWidget: (_, str, e) {
                              return Image.asset(
                                "assets/default_profile.png",
                                height: 48,
                                width: 48,
                                fit: BoxFit.fill,
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              BaseText(
                                text: parentList[index].lastName == "null"
                                    ? parentList[index].firstName
                                    : parentList[index].firstName +
                                        " " +
                                        parentList[index].lastName,
                                textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                              BaseText(
                                text: parentList[index].tagline == null ||
                                        parentList[index].tagline == "null" ||
                                        parentList[index].tagline == ""
                                    ? ""
                                    : parentList[index].tagline,
                                textColor: AppConstants.colorStyle.lightPurple,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w400,
                                fontSize: 14,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),

                        ButtonView(
                          btnName:    parentList[index].status ==
                              Constant.ACCEPTED
                              ? 'Connected'
                              : parentList[index].status ==
                              Constant.REQUESTED ||
                              parentList[index].status ==
                                  Constant.PENDING
                              ? 'Requested'
                              : 'Connect',
                          borderColor: AppConstants.colorStyle.lightBlue,
                          bgColor: AppConstants.colorStyle.box_bg_color,
                          txtColor: AppConstants.colorStyle.lightBlue,
                          onButtonTap: () {
                            if (parentList[index].status ==
                                Constant.NON_CONNECTION) {
                              apiCallForConnect(parentList[index].userId, index,
                                  parentList[index].roleId);
                            }
                          },
                        )

                      ],
                    ),
                  ),
                  onTap: () {
                    if (parentList[index].userId != userIdPref) {
                      Util.onTapImageTile(
                          tapedUserRole: "2",
                          partnerUserId: parentList[index].userId,
                          pageName: "search",
                          context: context);
                    }
                  });
            },
            separatorBuilder: (_, index) => Divider(
              color: const Color(0xffD4E4FF),
              thickness: 1,
              height: 0,
            ),
            itemCount: parentList.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
          )
        : const SizedBox.shrink();
  }

  Widget _buildPartnerList() {
    return partnerList.isNotEmpty
        ? ListView.separated(
            itemBuilder: (_, index) {
              return InkWell(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    child: Row(
                      children: [
                        Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: Colors.white, width: 1)),
                          margin: EdgeInsets.zero,
                          elevation: 0,
                          clipBehavior: Clip.antiAlias,
                          child: (partnerList[index]
                                          ?.profilePicture
                                          ?.isNotEmpty ??
                                      false) &&
                                  partnerList[index]?.profilePicture != 'null'
                              ? CachedNetworkImage(
                                  height: 48,
                                  width: 48,
                                  fit: BoxFit.cover,
                                  imageUrl: Constant.IMAGE_PATH_SMALL +
                                      ParseJson.getSmallImage(
                                          partnerList[index].profilePicture),
                                  placeholder: (_, str) {
                                    return Container(
                                      height: 48,
                                      width: 48,
                                      alignment: Alignment.center,
                                      child: SizedBox(
                                        width: 30,
                                        height: 30,
                                        child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation(
                                            Colors.black54,
                                          ),
                                          strokeWidth: 2.0,
                                        ),
                                      ),
                                    );
                                  },
                                  errorWidget: (_, str, e) {
                                    return Image.asset(
                                      "assets/default_profile.png",
                                      height: 48,
                                      width: 48,
                                      fit: BoxFit.fill,
                                    );
                                  },
                                )
                              : Container(
                                  color: Color(0xff666B9A),
                                  child: Image.asset(
                                    "assets/default_profile.png",
                                    height: 48,
                                    width: 48,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              BaseText(
                                text: partnerList[index].lastName == "null"
                                    ? partnerList[index].firstName
                                    : partnerList[index].firstName +
                                        " " +
                                        partnerList[index].lastName,
                                textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoRegular,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                textAlign: TextAlign.start,
                                maxLines: 3,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        ButtonView(
                          btnName:   partnerList[index].status ==
                              Constant.ACCEPTED
                              ? 'Connected'
                              : partnerList[index].status ==
                              Constant.REQUESTED ||
                              partnerList[index].status ==
                                  Constant.PENDING
                              ? 'Requested'
                              : 'Connect',
                          borderColor: AppConstants.colorStyle.lightBlue,
                          bgColor: AppConstants.colorStyle.box_bg_color,
                          txtColor: AppConstants.colorStyle.lightBlue,
                          onButtonTap: () {
                            if (partnerList[index].status ==
                                Constant.NON_CONNECTION) {
                              apiCallForConnect(partnerList[index].userId,
                                  index, partnerList[index].roleId);
                            }
                          },
                        )


                      ],
                    ),
                  ),
                  onTap: () {
                    if (partnerList[index].userId != userIdPref) {
                      Util.onTapImageTile(
                          tapedUserRole: "4",
                          partnerUserId: partnerList[index].userId,
                          pageName: "search",
                          context: context);
                    }
                  });
            },
            separatorBuilder: (_, index) => Divider(
              color: const Color(0xffD4E4FF),
              thickness: 1,
              height: 0,
            ),
            itemCount: partnerList.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 20),
          )
        : const SizedBox.shrink();
  }

  Widget _noResultFound() {
    return ListView(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      children: <Widget>[
        const SizedBox(height: 30),
        Image.asset(
          "assets/no_search.png",
          width: double.infinity,
          height: 151.0,
        ),
        const SizedBox(height: 20),
        TextViewWrap.textViewMultiLine(
            "Hmm, No results found!",
            TextAlign.center,
            ColorValues.GREY_TEXT_COLOR,
            16.0,
            FontWeight.bold,
            2),
        const SizedBox(height: 8),
        TextViewWrap.textViewMultiLine(
            "We did not find what you were looking for. Try again.",
            TextAlign.center,
            ColorValues.GREY_TEXT_COLOR,
            14.0,
            FontWeight.normal,
            4)
      ],
    );
  }

  Widget getButtonOpportunity() {
    return InkWell(
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xff4684EB),
          borderRadius: BorderRadius.circular(10),
        ),
        clipBehavior: Clip.antiAlias,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            BaseText(
              text: 'Explore opportunities',
              textColor: Colors.white,
              fontWeight: FontWeight.w600,
              fontFamily: Constant.latoRegular,
              fontSize: 14,
            ),
            const SizedBox(width: 7),
            Image.asset(
              "assets/newDesignIcon/ic_explore_opportunity.png",
              width: 18,
              height: 18,
            ),
          ],
        ),
      ),
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => OpportunitySearch(_searchQuery.text)));
      },
    );
  }

  Widget _listView() {
    return Column(
      children: [
        Expanded(
          child: ListView(
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            controller: _controller,
            children: [
              isStudentFilterSelected
                  ? _buildFriendSearchList()
                  : isParentFilterSelected
                      ? _buildParentsList()
                      : isGroupFilterSelected
                          ? _buildGroupSearchList()
                          : isPartnerFilterSelected
                              ? _buildPartnerList()
                              : const SizedBox.shrink(),
            ],
          ),
        ),
        isApiCallingLoader
            ? Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Center(
                    child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(Colors.black54),
                  strokeWidth: 2.0,
                )),
              )
            : const SizedBox.shrink()
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return Scaffold(
      backgroundColor: Colors.white,
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/new_onboarding/background_screen.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 54, 20, 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      child: Image.asset(
                        "assets/new_onboarding/back_blue_icon.png",
                        height: 32.0,
                        width: 32.0,
                        fit: BoxFit.fill,
                      ),
                      onTap: () => Navigator.pop(context),
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(35),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 50, 20, 6),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomFormField(
                              controller: _searchQuery,
                              label: "Search here",
                              alignLabelWithHint: true,
                              contentPadding:
                                  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                              suffixWidget: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/connections/new_search.png",
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: <Widget>[
                                Flexible(
                                  child: InkWell(
                                    onTap: () => onFilterClick(0),
                                    child: Container(
                                      height: 35,
                                      decoration: BoxDecoration(
                                        color: isStudentFilterSelected
                                            ? AppConstants
                                                .colorStyle.orangeShade
                                            : AppConstants.colorStyle.fillShade,
                                        border: Border.all(
                                            color: isStudentFilterSelected
                                                ? AppConstants
                                                    .colorStyle.orangeShade
                                                : AppConstants.colorStyle.btnBg,
                                            width: 1),
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(10.0),
                                            bottomLeft: Radius.circular(10.0)),
                                      ),
                                      child: Center(
                                        child: BaseText(
                                          textAlign: TextAlign.center,
                                          text: 'Students',
                                          textColor: isStudentFilterSelected
                                              ? Colors.white
                                              : AppConstants
                                                  .colorStyle.darkBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: InkWell(
                                    onTap: () => onFilterClick(1),
                                    child: Container(
                                      height: 35,
                                      decoration: BoxDecoration(
                                        color: isParentFilterSelected
                                            ? AppConstants
                                                .colorStyle.orangeShade
                                            : AppConstants.colorStyle.fillShade,
                                        border: Border.all(
                                            color: isParentFilterSelected
                                                ? AppConstants
                                                    .colorStyle.orangeShade
                                                : AppConstants.colorStyle.btnBg,
                                            width: 1),
                                        borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(0.0),
                                            bottomRight: Radius.circular(0.0),
                                            topLeft: Radius.circular(0.0),
                                            bottomLeft: Radius.circular(0.0)),
                                      ),
                                      child: Center(
                                        child: BaseText(
                                          textAlign: TextAlign.center,
                                          text: 'Parents',
                                          textColor: isParentFilterSelected
                                              ? Colors.white
                                              : AppConstants
                                                  .colorStyle.darkBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: InkWell(
                                    onTap: () => onFilterClick(2),
                                    child: Container(
                                      height: 35,
                                      decoration: BoxDecoration(
                                        color: isGroupFilterSelected
                                            ? AppConstants
                                                .colorStyle.orangeShade
                                            : AppConstants.colorStyle.fillShade,
                                        border: Border.all(
                                            color: isGroupFilterSelected
                                                ? AppConstants
                                                    .colorStyle.orangeShade
                                                : AppConstants.colorStyle.btnBg,
                                            width: 1),
                                        borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(0.0),
                                            bottomRight: Radius.circular(0.0),
                                            topLeft: Radius.circular(0.0),
                                            bottomLeft: Radius.circular(0.0)),
                                      ),
                                      child: Center(
                                        child: BaseText(
                                          textAlign: TextAlign.center,
                                          text: 'Groups',
                                          textColor: isGroupFilterSelected
                                              ? Colors.white
                                              : AppConstants
                                                  .colorStyle.darkBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                                Flexible(
                                  child: InkWell(
                                    onTap: () => onFilterClick(3),
                                    child: Container(
                                      height: 35,
                                      decoration: BoxDecoration(
                                        color: isPartnerFilterSelected
                                            ? AppConstants
                                                .colorStyle.orangeShade
                                            : AppConstants.colorStyle.fillShade,
                                        border: Border.all(
                                            color: isPartnerFilterSelected
                                                ? AppConstants
                                                    .colorStyle.orangeShade
                                                : AppConstants.colorStyle.btnBg,
                                            width: 1),
                                        borderRadius: BorderRadius.only(
                                          bottomRight: Radius.circular(10.0),
                                          topRight: Radius.circular(10.0),
                                        ),
                                      ),
                                      child: Center(
                                        child: BaseText(
                                          textAlign: TextAlign.center,
                                          text: 'Partners',
                                          textColor: isPartnerFilterSelected
                                              ? Colors.white
                                              : AppConstants
                                                  .colorStyle.darkBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            const SizedBox(height: 24),
                            getButtonOpportunity(),
                          ],
                        ),
                      ),
                      Expanded(
                        child: isApiCalling
                            ? Center(
                                child: CircularProgressIndicator(
                                  valueColor:
                                      AlwaysStoppedAnimation(Colors.black54),
                                  strokeWidth: 2.0,
                                ),
                              )
                            : friendList.length > 0 ||
                                    groupList.length > 0 ||
                                    parentList.length > 0 ||
                                    partnerList.length > 0 ||
                                    _mOpportunityModelList.length > 0
                                ? _listView()
                                : _searchQuery.text.trim().length > 0 &&
                                        !isTyping
                                    ? _noResultFound()
                                    : Center(
                                        child: TextViewWrap.textViewMultiLine(
                                            "Enter a few words to search in spikeview",
                                            TextAlign.center,
                                            ColorValues.GREY_TEXT_COLOR,
                                            16.0,
                                            FontWeight.normal,
                                            2),
                                      ),
                        flex: 1,
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onFilterClick(int index) {
    switch (index) {
      case 0:
        offset = 0;
        isStudentFilterSelected = true;
        isGroupFilterSelected = false;
        isParentFilterSelected = false;
        isPartnerFilterSelected = false;
        apiCallingForFrindFullList3(_searchQuery.text, "1");
        break;
      case 1:
        offset = 0;
        isParentFilterSelected = true;
        isStudentFilterSelected = false;
        isGroupFilterSelected = false;
        isPartnerFilterSelected = false;
        apiCallingForFrindFullList3(_searchQuery.text, "2");
        break;
      case 2:
        offset = 0;
        isGroupFilterSelected = true;
        isStudentFilterSelected = false;
        isParentFilterSelected = false;
        isPartnerFilterSelected = false;
        apiCallingForFrindFullList3(_searchQuery.text, "10");

        break;
      case 3:
        offset = 0;
        isPartnerFilterSelected = true;
        isStudentFilterSelected = false;
        isGroupFilterSelected = false;
        isParentFilterSelected = false;
        apiCallingForFrindFullList3(_searchQuery.text, "4");
        break;
    }
    setState(() {});
  }

  Color getBgColor(int index) {
    Color color;
    switch (index) {
      case 0:
        color = isStudentFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;

        break;
      case 1:
        color = isParentFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;

        break;
      case 2:
        color = isGroupFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;

        break;
      case 3:
        color = isPartnerFilterSelected
            ? ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED
            : ColorValues.SEARCH_CATEGORY_BOX_BG;
        break;
    }

    return color;
  }

  Color getSelectedTextColor(int index) {
    Color color;
    switch (index) {
      case 0:
        color = isStudentFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;

        break;
      case 1:
        color = isParentFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;

        break;
      case 2:
        color = isGroupFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;

        break;
      case 3:
        color = isPartnerFilterSelected
            ? ColorValues.WHITE
            : ColorValues.BLUE_COLOR_BOTTOMBAR;
        break;
    }

    return color;
  }
}
