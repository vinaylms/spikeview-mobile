import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';

enum FullImageType { network, file, asset, urlList }

class FullImageWidget extends StatefulWidget {
  final FullImageType type;

  /// Here you can any path url, assets, or file path
  final String imagePath;
  final String toolbarTitle;
  final List<String> imagesUrlList;
  final int listInitialIndex;

  const FullImageWidget({
    @required this.type,
    @required this.imagePath,
    this.toolbarTitle,
    this.imagesUrlList,
    this.listInitialIndex,
  });

  @override
  State<FullImageWidget> createState() => _FullImageWidgetState();
}

class _FullImageWidgetState extends State<FullImageWidget> {
  int selectedIndex = 0;

  @override
  void initState() {
    selectedIndex = widget.listInitialIndex ?? 0;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        titleSpacing: 0.0,
        brightness: Brightness.light,
        leading: IconButton(
            icon: Image.asset(
              "assets/newDesignIcon/icon/back_icon.png",
              height: 32.0,
              width: 32.0,
              fit: BoxFit.fill,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      backgroundColor: Colors.white,
      body: Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              Container(
                alignment: Alignment.topLeft,
                padding: EdgeInsets.only(bottom: 10),
                color: AppConstants.colorStyle.white,
                child: PaddingWrap.paddingfromLTRB(
                    17.0,
                    5.0,
                    17.0,
                    5.0,
                    BaseText(
                      text: widget.toolbarTitle ?? "",
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 2,
                    )),
              ),
              Expanded(
                child: Container(
                  color: Colors.black,
                  alignment: Alignment.center,
                  child: widget.type == FullImageType.urlList
                      ? Stack(
                          children: [
                            CarouselSlider.builder(
                              itemCount: widget.imagesUrlList.length,
                              options: CarouselOptions(
                                  height: MediaQuery.of(context).size.height,
                                  initialPage: widget.listInitialIndex ?? 0,
                                  viewportFraction: 1.0,
                                  autoPlay: false,
                                  enableInfiniteScroll: false,
                                  scrollDirection: Axis.horizontal,
                                  onPageChanged: (index, reason) =>
                                      setState(() {
                                        selectedIndex = index;
                                      })),
                              itemBuilder: (context, index) {
                                return Center(
                                    child: CachedNetworkImage(
                                  imageUrl:
                                      '${Constant.IMAGE_PATH}${widget.imagesUrlList[index]}',
                                  fit: BoxFit.contain,
                                  placeholder: (context, url) => _loader(
                                      context,
                                      "assets/aerial/default_img.png"),
                                  errorWidget: (context, url, error) =>
                                      _error("assets/aerial/default_img.png"),
                                ));
                              },
                            ),
                            Positioned(
                              left: 0,
                              right: 0,
                              bottom: 15,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: List.generate(
                                    widget.imagesUrlList.length, (index) {
                                  return Container(
                                    width: 12,
                                    height: 4,
                                    margin: const EdgeInsets.only(right: 5),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: selectedIndex == index
                                          ? const Color(0xff4684EB)
                                          : const Color(0xffF3F5FF),
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ],
                        )
                      : widget.type == FullImageType.network
                          ? CachedNetworkImage(
                              imageUrl:
                                  Constant.IMAGE_PATH + widget.imagePath,
                              fit: BoxFit.contain,
                              placeholder: (context, url) => _loader(context,
                                  "assets/portfolio/certificate.png"),
                              errorWidget: (context, url, error) =>
                                  _error("assets/portfolio/certificate.png"),
                            )
                          : widget.type == FullImageType.file
                              ? Image.file(
                                  File(widget.imagePath),
                                  fit: BoxFit.contain,
                                )
                              : widget.type == FullImageType.asset
                                  ? Image.asset(
                                      widget.imagePath,
                                      fit: BoxFit.contain,
                                    )
                                  : Icon(
                                      Icons.error,
                                      color: Colors.white,
                                    ),
                ),
                flex: 1,
              ),
            ],
          )),
    );

    /*return Scaffold(
      appBar: AppBar(
        brightness: Brightness.light,
        automaticallyImplyLeading: false,
        titleSpacing: 0.0,
        elevation: 0.0,
        leading: InkWell(
          child: CustomViews.getBackButton(),
          onTap: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          widget.toolbarTitle ?? "",
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: ColorValues.HEADING_COLOR_EDUCATION,
            fontSize: 16,
            fontFamily: Constant.latoRegular,
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: Container(
        color: Colors.black,
        alignment: Alignment.center,
        child: widget.type == FullImageType.urlList
            ? Stack(
                children: [
                  CarouselSlider.builder(
                    itemCount: widget.imagesUrlList.length,
                    options: CarouselOptions(
                        height: MediaQuery.of(context).size.height,
                        initialPage: widget.listInitialIndex ?? 0,
                        viewportFraction: 1.0,
                        autoPlay: false,
                        scrollDirection: Axis.horizontal,
                        onPageChanged: (index, reason) => setState(() {
                              selectedIndex = index;
                            })),
                    itemBuilder: (context, index) {
                      return Center(
                          child: CachedNetworkImage(
                        imageUrl:
                            '${Constant.IMAGE_PATH}${widget.imagesUrlList[index]}',
                        fit: BoxFit.contain,
                        placeholder: (context, url) =>
                            _loader(context, "assets/aerial/default_img.png"),
                        errorWidget: (context, url, error) =>
                            _error("assets/aerial/default_img.png"),
                      ));
                    },
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 15,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:
                          List.generate(widget.imagesUrlList.length, (index) {
                        return Container(
                          width: 12,
                          height: 4,
                          margin: const EdgeInsets.only(right: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: selectedIndex == index
                                ? const Color(0xff4684EB)
                                : const Color(0xffF3F5FF),
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              )
            : widget.type == FullImageType.network
                ? CachedNetworkImage(
                    imageUrl: Constant.IMAGE_PATH + widget.imagePath,
                    fit: BoxFit.contain,
                    placeholder: (context, url) =>
                        _loader(context, "assets/portfolio/certificate.png"),
                    errorWidget: (context, url, error) =>
                        _error("assets/portfolio/certificate.png"),
                  )
                : widget.type == FullImageType.file
                    ? Image.file(
                        File(widget.imagePath),
                        fit: BoxFit.contain,
                      )
                    : widget.type == FullImageType.asset
                        ? Image.asset(
                            widget.imagePath,
                            fit: BoxFit.contain,
                          )
                        : Icon(
                            Icons.error,
                            color: Colors.white,
                          ),
      ),
    );*/
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }
}
