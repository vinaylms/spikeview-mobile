import 'dart:async';
import 'dart:io';
import 'package:firebase_core/firebase_core.dart';

import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart' as path;

//import 'package:simple_permissions/simple_permissions.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/BusinessCategoryResponse.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/Signup_As_Parent_Widget_New.dart';
import 'package:spike_view_project/gateway/company/ThnaksPage.dart';
import 'package:spike_view_project/gateway/company/staticpage.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/modal/patner/VideoModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';
import 'package:spike_view_project/modal/patner/opportunity_category_model.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/CongratulationWidget.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/CompanyPreviewProfileWidget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/add_google_doc_link_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';
import 'package:spike_view_project/presoView/simple_animations/controlled_animation.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:spike_view_project/gateway/ReferalCodeResponse.dart';

class CompanyInfoNew extends StatefulWidget {
  final UserModel personalInfoObject;
  String userId,
      pageName,
      signupType,
      firstName = "",
      lastName = "",
      email = "",
      image = "";
  bool isRedirectToRecommendation, isValid;

  CompanyInfoNew(
      {this.personalInfoObject,
      this.userId,
      this.pageName,
      this.isRedirectToRecommendation,
      this.signupType,
      this.firstName,
      this.lastName,
      this.email,
      this.isValid,
      this.image});

  @override
  State<StatefulWidget> createState() =>
      CompanyInfoState(personalInfoObject: personalInfoObject);
}

class CompanyInfoState extends State<CompanyInfoNew> with BaseCommonWidget {
  UserModel personalInfoObject;
  String selectedCountryCode = '1';

  final FocusNode _otherCategoryFocus = FocusNode();

  bool showList = false;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();
  final GlobalKey<AnimatedListState> _listBusinessKey = GlobalKey();

  bool isBusinessCategoryError = false;

  Color bottomViewColor = Palette.dividerColor;

  bool isShowMore = true;
  bool isShowOtherMore = true;

  List<OpportunityCategoriesResult> opportunityCategoryList =  List();

  bool isValidateReferal = false;

  ReferalCodeResponse referalCodeResponse;

  CompanyInfoState({this.personalInfoObject});

  bool _newPassObscureText = true;
  String strNewPassword = "",
      linkUrl,
      referalUserId = "",
      referalUserRoleId = "";

  bool isMediaExpanded = false;
  bool internship = false;
  bool advertise = false;
  bool collageAdmission = false;
  final formKeyReferal = GlobalKey<FormState>();
  final _formKey = GlobalKey<FormState>();
  final FocusNode _companyNameFocus = FocusNode();
  final FocusNode _nameFocus = FocusNode();
  final FocusNode _companyAddressFocus = FocusNode();
  final FocusNode _emailFocus = FocusNode();
  final FocusNode _websiteURLFocus = FocusNode();
  final FocusNode _aboutCompanyFocus = FocusNode();
  final FocusNode _phoneNumberNameFocus = FocusNode();
  bool isMediaSelected = false;
  final companyNameController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController referalController = TextEditingController();
  final companyAddressController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  final websiteController = TextEditingController();
  final phoneNumberController = TextEditingController();
  final aboutCompanyController = TextEditingController();
  static const platform = const MethodChannel('samples.flutter.io/battery');
  File mediaImage, mediaVideo, mediaDoc;
  List<String> mediaAndVideoList =  List();
  File imagePath;
  String sasToken, containerName;
  String googleDocLink, googleDocTitle, selectedGroup;
  ShareProfileModal shareProfileModal;
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "",
      userid;
  SharedPreferences prefs;
  UploadMedia uploadMedia;
  List<String> mediaImagesList =  List();
  List<AssetModel> assetModelMap =  List();
  List<FileModel> mediaVideosList =  List();
  List<String> mediaDocumentList =  List();
  List<String> googleDoclinkList =  List();
  String previouspath = "";
  bool isAgree = false;

  bool isOtherSelected = false;
  List<String> selectedOtherOption = [];
  List<String> selectedCategoryOption = [];
  final categoryController = TextEditingController();
  List<CategoryResult> businessCategoryList =  List<CategoryResult>();
  List<CategoryResult> removedBusinessCategoryList =  List<CategoryResult>();
  List<CategoryResult> orignalBusinessCategoryList =  List<CategoryResult>();
  List<CategoryModel> selectedCategoryList =  List<CategoryModel>();
  FocusNode referalFocusNode = FocusNode();

  bool password_error_lenght = false;
  bool password_error_number = false;
  bool password_error_lower = false;
  bool password_error_upper = false;
  bool password_error_specile = false;
  UserModel personalInfo = UserModel();

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_APP_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
      return "";
    }
  }

  onSucess() async {


    Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
             CongratulationWidget(widget.userId)));
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(context);
      if (widget.pageName == "Login") {
        print("company  off");
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>  LoginPage(null)));
      } else {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>  LoginPage(null)));
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  goto() {
    prefs.setString(UserPreference.PATHURL, "");

    Navigator.pushReplacement(
        context,
         MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) =>  DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
  }

  onTapPresoView() async {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    await Navigator.pushReplacement(
        Constant.applicationContext,
         MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) =>  SharePresoView23(
                shareProfileModal.profileOwner, shareProfileModal, "main")));
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  Future shareIDData(shareId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2()
            .apiCall4(context, Constant.ENDPOINT_SHARE_ID + shareId, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data['message'];
            print(response.toString());
            if (status == "Success") {
              shareProfileModal =
                  ParseJson.parseShareProfile(response.data['result']);
              if (shareProfileModal.profileOwner != "") {
                print("profile status" + shareProfileModal.isActive);
                print("profile status" + shareProfileModal.isViewed);

                if (shareProfileModal.sharedView == "linear") {
                  Navigator.pushReplacement(
                      Constant.applicationContext,
                       MaterialPageRoute(
                          //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) =>  ShareProfilePage(
                              shareProfileModal.profileOwner,
                              false,
                              "shareProfile",
                              shareProfileModal,
                              "")));
                } else {
                  onTapPresoView();
                }
              }

              return;
            } else {
              goto();

              ToastWrap.showToast(message, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        goto();
      }
    } catch (e) {
      goto();
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);

      return;
    }
  }

  processForUri(result, email) async {
    print("resultData+++" + result);
    if (result.toString().toLowerCase().contains(email)) {
      if (result.contains("previewprofile")) {

        Navigator.of(context).popUntil((route) => route.isFirst);
        goto();
      } else if (result.contains("joingroup")) {
        List<String> mesagelist = result.split("=");

        String groupId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");
        String pass = mesagelist[4];
        prefs.setString(UserPreference.ROLE_ID, "4");
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(
          context,
        ).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>
                 GroupDetailWidget(groupId, "login", "", "", "")));
      } else if (result.contains("recommendation")||result.contains("badges")) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            context,
             MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) =>  DashBoardWidgetPartner(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.of(context).popUntil((route) => route.isFirst);
      goto();
    }
    prefs.setString(UserPreference.PATHURL, "");
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        personalInfoObject.assets.addAll(assetModelMap);
        //  FormData formData = FormData.from(UserModel.toArrayMap(personalInfoObject));
        //  Map map = UserModel.toArrayMap(personalInfoObject);
        //widget.signupType = "apple";
        Map map = UserModel.toArrayMapForSideNavigation(
            personalInfoObject,
            widget.userId,
            widget.isRedirectToRecommendation,
            selectedCountryCode,
            widget.signupType);

        print("request======" + map.toString());

        response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_COMPANY_DATA, map);
        // CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            // Api call for get setting data
            bloc.fetchSetting('', context, prefs);
            String path = prefs.getString(UserPreference.PATHURL);
            print("user Login id" + widget.signupType);
            if (widget.signupType == "apple" || widget.signupType == "google") {
              // setState(() {
              Constant.isAlreadyLoggedIn = true;
              prefs.setString(UserPreference.chat_skip_count, "0");
              prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
              prefs.setBool(UserPreference.isEducationAdded, false);
              // });
//role
              //"id" -> 1
              prefs.setString(UserPreference.IS_USER_ROLE, "false");
              prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");

              var companyMap = response.data['result']['company'];
              Company company =  Company('', '', false);
              if (companyMap != null) {
                print('Apurva companyMap:: $companyMap not null');
                company =  Company(
                    companyMap['name'].toString(),
                    companyMap['partnerStatus'].toString(),
                    companyMap['isActive']);

                if (company.partnerStatus.toString() == 'Decline')
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, true);
                else
                  prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP, false);
              }

              print(
                  'Apurva UserPreference.IS_SHOW_REJECTION_POPUP:: ${prefs.getBool(UserPreference.IS_SHOW_REJECTION_POPUP)}');

              String userId = response.data['result']['userId'].toString();
              String firstName =
                  response.data['result']['firstName'].toString();
              String lastName = response.data['result']['lastName'].toString();
              String email = response.data['result']['email'].toString();
              String salt = response.data['result']['salt'].toString();
              String mobileNo = response.data['result']['mobileNo'].toString();
              String profilePicture =
                  response.data['result']['profilePicture'].toString();
              String roleId = response.data['result']['roleId'].toString();
              String dob = response.data['result']['dob'].toString();
              if (dob == null || dob == "null" || dob == "") {
                dob = "0";
              }
              String companyName =
                  response.data['result']['companyName'].toString();
              String companyProfilePicture =
                  response.data['result']['companyProfilePicture'].toString();
              bool ProfileCreatedByParent =
                  response.data['result']['profileCreatedByParent'];
              if (ProfileCreatedByParent == null) {
                ProfileCreatedByParent = false;
              }
              String schoolCode = response.data['result']['schoolCode'].toString();
              if (schoolCode == "null" || schoolCode == "") {
                schoolCode = "";
              }
              bool userLoginFirstTime =
                  response.data['result']['userLoginFirstTime'];
              if (userLoginFirstTime == null) {
                userLoginFirstTime = false;
              }

              prefs.setBool(
                  UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);

              print(
                  "userLoginFirstTime+++++++" + userLoginFirstTime.toString());
              prefs.setBool(
                  UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);

              prefs.setString(UserPreference.DOB, dob);

              roleId = "4";
              String token = response.data['result']['token'].toString();
              bool isPasswordChanged =
                  response.data['result']['isPasswordChanged'];
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                isPasswordChanged = true;
              }
              userList.add(new UserData(userId, firstName, lastName, email,
                  salt, mobileNo, profilePicture, roleId));
              print("user Login id" + userId);

              prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
              String isActive = response.data['result']['isActive'].toString();
              String isHide = response.data['result']['isHide'].toString();
              prefs.setString(UserPreference.ISHide, isHide);
              prefs.setString(UserPreference.ISACTIVE, isActive);

              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setString(UserPreference.ROLE_ID, roleId);
              print("user RoleId test+++" + roleId);
              Constant.ROLE_ID = roleId;

              prefs.setBool(
                  UserPreference.IS_PASSWORD_CHANGED, isPasswordChanged);
              prefs.setBool(UserPreference.IS_PROFILECRETED_BY_PARENT,
                  ProfileCreatedByParent);

              prefs.setString(UserPreference.USER_ID, userId);
              prefs.setBool(
                  UserPreference.IS_PARENT, roleId == "2" ? true : false);
              prefs.setString(UserPreference.PARENT_ID, userId);
              prefs.setString(UserPreference.NAME, firstName + " " + lastName);
              prefs.setString(UserPreference.EMAIL, email);
              prefs.setString(UserPreference.MOBILE, mobileNo);
              prefs.setString(UserPreference.PASSWORD, "");
              prefs.setString(UserPreference.chat_skip_count, "0");
              prefs.setString(
                  UserPreference.PROFILE_IMAGE_PATH, profilePicture);
              prefs.setString(
                  UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);

              prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);

              prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);
              String path = "";
              try {
                path = prefs.getString(UserPreference.PATHURL);
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
              }

              String requireParentApproval =
                  response.data['result']['requireParentApproval'].toString();
              String isPasswordChanged1 =
                  response.data['result']['isPasswordChanged'].toString();
              if (widget.signupType == "apple" ||
                  widget.signupType == "google") {
                isPasswordChanged1 = "true";
              }
              String ccToParents =
                  response.data['result']['ccToParents'].toString();
              String lastAccess =
                  response.data['result']['lastAccess'].toString();
              String organizationId =
                  response.data['result']['organizationId'].toString();
              String gender = response.data['result']['gender'].toString();
              if (gender == "Non-binary" || gender == "NonBinary") {
                gender = "Non-Binary";
              }
              String genderAtBirth =
                  response.data['result']['genderAtBirth'].toString();
              String usCitizenOrPR =
                  response.data['result']['usCitizenOrPR'].toString();
              String summary = response.data['result']['summary'].toString();
              String coverImage =
                  response.data['result']['coverImage'].toString();
              String tagline = response.data['result']['tagline'].toString();
              String title = response.data['result']['title'].toString();
              String tempPassword =
                  response.data['result']['tempPassword'].toString();
              String isArchived =
                  response.data['result']['isArchived'].toString();
              String groupId = response.data['result']['groupId'].toString();
              String groupName =
                  response.data['result']['groupName'].toString();
              String groupImage =
                  response.data['result']['groupImage'].toString();
              String zipCode = response.data['result']['zipCode'].toString();
              bool referralPopup = response.data['result']['referralPopup'];
              String stage = response.data['result']['stage'].toString();
              String creationTime = "0";
              creationTime = response.data['result']['creationTime'].toString();
              if (creationTime == "null") {
                creationTime = "0";
              }

              bool isPublicUrlActive =
                  response.data['result']['isPublicUrlActive'];
              if (isPublicUrlActive == "null") {
                isPublicUrlActive = false;
              }

              bool isPublicProfileGlobalyActive =
                  response.data['result']['isPublicProfileGlobalyActive'];
              if (isPublicProfileGlobalyActive == null ||
                  isPublicProfileGlobalyActive == "null") {
                isPublicProfileGlobalyActive = false;
              }

              String publicUrl =
                  response.data['result']['publicUrl'].toString().trim();
              if (publicUrl == "null") {
                publicUrl = "";
              }

              String referCode =
                  response.data['result']['referCode'].toString();

              bool isPreLoginSetting =
                  response.data["result"]["isLeaderboardDisplay"];
              if (isPreLoginSetting == null) {
                isPreLoginSetting = false;
              }
              prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);

              String badgeImage =
                  response.data['result']['badgeImage'].toString();
              if (badgeImage == null ||
                  badgeImage == "null" ||
                  badgeImage == "") {
                badgeImage = "";
              }
              String badge = response.data['result']['badge'].toString();
              if (badge == null || badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  response.data['result']['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == null ||
                  gamification == "" ||
                  gamification == "null") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }

              prefs.setString(UserPreference.referCode, referCode);
              prefs.setString(UserPreference.badgeType, badge);
              prefs.setInt(
                  UserPreference.gamificationPoints, gamificationPoints);
              prefs.setString(UserPreference.badgeImage, badgeImage);

              if (referralPopup == null || referralPopup == "null") {
                referralPopup = false;
              }

              List<SocialLinkData> socialLinkList =  List();
              var socalLinkMap = response.data['result']['socialLinks'];
              if (socalLinkMap != null && socalLinkMap.length > 0) {
                for (int i = 0; i < socalLinkMap.length; i++) {
                  String image = socalLinkMap[i]['image'].toString();
                  String socialName = socalLinkMap[i]['socialName'].toString();
                  String socialUrl = socalLinkMap[i]['socialUrl'].toString();
                  int socialId = socalLinkMap[i]['socialId'];

                  socialLinkList.add(new SocialLinkData(
                      image: image,
                      socialName: socialName,
                      socialUrl: socialUrl,
                      socialId: socialId));
                }
              }

              ProfileInfoModal profileInfoModal =  ProfileInfoModal(
                  userId,
                  firstName,
                  lastName,
                  email,
                  mobileNo,
                  profilePicture,
                  roleId,
                  isActive,
                  requireParentApproval,
                  ccToParents,
                  lastAccess,
                  isPasswordChanged1,
                  organizationId,
                  gender,
                  dob,
                  genderAtBirth,
                  usCitizenOrPR,
                  null,
                  summary,
                  coverImage,
                  tagline,
                  title,
                  tempPassword,
                  isArchived,
                  null,
                  false,
                  groupId,
                  groupName,
                  groupImage,
                  "",
                  "",
                  zipCode,
                  isHide,
                  referralPopup,
                  userLoginFirstTime,
                  stage,
                  creationTime,
                  badge,
                  gamificationPoints,
                  badgeImage,
                  referCode,
                  socialLinkList,
                  publicUrl,
                  isPublicUrlActive,
                  isPublicProfileGlobalyActive,
                  null,
                  company,
                  false,
                  false,
                  null,schoolCode,'',"",false,false);

              prefs.setString(
                  UserPreference.CREATION_TIME, profileInfoModal.creationTime);
              prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
              prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
              prefs.setString(UserPreference.NAME,
                  profileInfoModal.firstName + " " + profileInfoModal.lastName);
              prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                  profileInfoModal.profilePicture);

              prefs.setString(UserPreference.TAGLINE, profileInfoModal.tagline);
              prefs.setString(
                  UserPreference.ISACTIVE, profileInfoModal.isActive);

              Navigator.of(context).popUntil((route) => route.isFirst);
              goto();
            } else if (widget.isRedirectToRecommendation) {
              prefs.setBool(UserPreference.LOGIN_STATUS, true);
              prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
              prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
              prefs.setString(UserPreference.IS_PARENT_ROLE, "false");
              prefs.setString(UserPreference.IS_USER_ROLE, "false");
              prefs.setString(UserPreference.ROLE_ID, "4");
              Constant.ROLE_ID = "4";
              prefs.setString(UserPreference.NAME, "");
              prefs.setString(UserPreference.EMAIL, personalInfoObject.email);
              prefs.setString(
                  UserPreference.PASSWORD, personalInfoObject.password);
              prefs.setString(UserPreference.PROFILE_IMAGE_PATH, "");
              prefs.setString(UserPreference.COMPANY_IMAGE_PATH, "");
              prefs.setString(UserPreference.COMPANY_NAME_PATH,
                  personalInfoObject.companyName);
              Navigator.of(context).popUntil((route) => route.isFirst);
              processForUri(path, personalInfoObject.email);
            } else {
              prefs.setString(UserPreference.PATHURL, "");
              print("dashBoard++++" + widget.pageName);
              if (widget.pageName == "dashBoard") {
                onSucess();
              } else {
                print("route.isFirst++++" + widget.pageName);
                Navigator.of(context).push(new MaterialPageRoute(
                    builder: (BuildContext context) =>  ThanksPage()));
                //showSucessMsgLong(msg, context);
              }
            }
          } else {
            mediaImagesList.insert(0, null);
            mediaDocumentList.insert(0, null);
            mediaVideosList.insert(0, null);
            ToastWrap.showToastLongNew(msg, context);
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
    }
  }

  Future apiCallingPersonal() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Address address2;

        String encryptedstrNewPassword = "";
        if (widget.isRedirectToRecommendation) {
          encryptedstrNewPassword = await platform.invokeMethod('encryption', {
            "password": strNewPassword,
          });
        }
        personalInfoObject.password = strNewPassword;
        personalInfoObject.firstName = nameController.text;
        personalInfoObject.email = emailController.text.toString();

        Response response;

        //  FormData formData = FormData.from(UserModel.toArrayMap(personalInfoObject));
        Map map = UserModel.toArrayMap(
            personalInfoObject,
            widget.isRedirectToRecommendation,
            encryptedstrNewPassword,
            address2,
            "",
            "",
            referalUserId,
            referalUserRoleId,
            selectedCountryCode,
            widget.signupType,
            prefs.getString("deviceId"));

        MessageConstant.printWrapped("request======" +Constant.ENDPOINT_PARTNER_SIGNUP+ map.toString());

        response = await  ApiCalling2().apiCallPostWithMapData(
            context, Constant.ENDPOINT_PARTNER_SIGNUP, map);
        print("response:-" + response.toString());
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // prefs.setString(UserPreference.PATHURL, "");
              widget.userId = response.data["userId"].toString();
              if (!widget.isRedirectToRecommendation) {
                String token = response.data["token"].toString();

                prefs.setString(UserPreference.USER_TOKEN, "Spike " + token);
              }
              if (widget.isValid) {
                apiCalling();
              } else {
                mediaImagesList.insert(0, null);
                mediaDocumentList.insert(0, null);
                mediaVideosList.insert(0, null);
                ToastWrap.showToastLong(
                    MessageConstant.PRIVATE_EMAIL_MSG, context);
              }
            } else {
              mediaImagesList.insert(0, null);
              mediaDocumentList.insert(0, null);
              mediaVideosList.insert(0, null);
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    // TODO: implement build
    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    //---------------------Add media View and core logics  ---------------------
    void conformationDialog(type, path) {
      String tName =
          type == "image" ? "Image" : type == "video" ? "Video" : "Pdf";

      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      MessageConstant.REMOVE_NAME_ +tName+ " ?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                               MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                MessageConstant.REMOVE,
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "image") {
                                                  mediaAndVideoList
                                                      .removeLast();
                                                  mediaImagesList.remove(path);
                                                  setState(() {
                                                    mediaAndVideoList;
                                                    mediaImagesList;
                                                  });
                                                } else if (type == "video") {
                                                  mediaAndVideoList
                                                      .removeLast();
                                                  mediaVideosList.remove(path);
                                                  setState(() {
                                                    mediaAndVideoList;
                                                    mediaVideosList;
                                                  });
                                                } else if (type == "doc") {
                                                  mediaDocumentList
                                                      .remove(path);
                                                  setState(() {
                                                    mediaDocumentList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});
      if (type == "video") {
        File file =
            await uploadMedia.compresssData(new File(imagePath), true, type);
        imagePath = file.path;
      } else if (type == "image") {
        File file = await uploadMedia.compressImage(new File(imagePath));
        imagePath = file.path;
      }
      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        if (type == "video") {
          mediaAndVideoList.add("");
          String path = Constant.IMAGE_PATH +
              strPrefixPathforPhoto +
              strAzureImageUploadPath;
          print("path+++++" + path);
          final thumbnailFile =
              await uploadMedia.getVideoThumbnailFromUrl(imagePath);

          mediaVideosList.add(new FileModel(
              thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
          setState(() {
            mediaVideosList;
          });
          if (mediaImagesList.length > 0 && mediaVideosList.length > 0) {
            isMediaSelected = true;
          } else {
            isMediaSelected = false;
          }
        } else if (type == "image") {
          mediaAndVideoList.add("");
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
          setState(() {
            mediaImagesList.add(path);
          });
          if (mediaImagesList.length > 0 && mediaVideosList.length > 0) {
            isMediaSelected = true;
          } else {
            isMediaSelected = false;
          }
        } else {
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
          mediaDocumentList.add(path);
          setState(() {
            mediaDocumentList;
          });
        }

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    //---------------------Add media View and core logics  ---------------------
    onTapImageAddButton() async {
      mediaImage = await uploadMedia.pickImageFromGallery();
      if (mediaImage != null) {
        imagePath = mediaImage;
        //  await _cropImage(mediaImage);
        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    String getFileExtension2(File file) {
      return path.extension(file.path);
    }

    onTapVideoAddButton() async {
      mediaVideo = await uploadMedia.pickVideoFromGallery();
      if (mediaVideo != null) {

        if (mediaVideo != null &&
            getFileExtension2(mediaVideo) != null &&
            getFileExtension2(mediaVideo).length > 0) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: mediaVideo
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "video");
          });
        }
      }
    }

    String getFileExtension(String file) {
      return path.extension(file);
    }

    getDocuments() async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if ((Util.getFileExtension(path) == ".pdf") && path != null) {
            print("path+++++" + path.toString());

            CustomProgressLoader.showLoader(context);
            Timer _timer =  Timer(const Duration(milliseconds: 400), () {
              checkMediaAndUpload(
                  imagePath: path
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  type: "doc");
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.INVALID_FILE_FORMAT_VAL, context);
          }
        } catch (e) {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
          crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
      }
    }

    final docListUiData =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 0.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaDocumentList.map((file) {
        if (file == null) {
          return  Stack(children: <Widget>[
             InkWell(
              child: Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 5, 20, 0),
                  child:  Container(
                      height: 54.0,
                      width: 80.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      ))),
              onTap: () {
                if (mediaDocumentList.length <= 5) {
                  getDocuments();
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              Padding(
                  padding: const EdgeInsets.fromLTRB(5.0, 5, 20, 15),
                  child:  Container(
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  InkWell(
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child:  Container(
                              height: 54.0,
                              width: 80.0,
                              child:  Image.asset(
                                "assets/newDesignIcon/patner/pdf.png",
                                height: 50.0,
                                width: 80.0,
                              )),
                        ),
                        onTap: () {
                          launch(Constant.IMAGE_PATH + file);
                        },
                      ))),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              10.0,
                              0.0,
                              0.0,
                               Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("doc", file);
                          })
                    ],
                  )))


            ],
          ));
        }
      }).toList(),
    ));

    final mediaImageListUIData =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaImagesList.map((file) {
        if (file == null) {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (mediaAndVideoList.length <= 10) {
                  onTapImageAddButton();
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + file,
                height: 54.0,
                width: 80.0,
              ),
               Container(
                height: 54.0,
                width: 84.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                               Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("image", file);
                          })
                    ],
                  ))),
            ],
          ));
        }
      }).toList(),
    ));

    final videoListUi =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaVideosList.map((file) {
        if (file == null) {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                if (mediaAndVideoList.length <= 10) {
                  onTapVideoAddButton();
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              showMediaFileWidget(80, file.file),
               Container(
                height: 54.0,
                width: 80.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                               Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("video", file);
                          })
                    ],
                  ))),
            ],
          ));
        }
      }).toList(),
    ));

    uploadGoogleDocLink() {
      return Column(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              InkWell(
                  onTap: () async {
                    if (googleDoclinkList.length < 5) {
                      googleDocLink = "";
                      googleDocTitle = "";
                      final String result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AddGoogleDocLink(
                                  googleDocLink: googleDocLink,
                                  googleDocTitle: googleDocTitle,
                                )),
                      );
                      if (result != null) {
                        setState(() {
                          googleDocLink = result.split('#####')[0];
                          googleDocTitle = result.split('#####')[1];

                          googleDoclinkList.add(googleDocLink);
                        });
                      }
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_5_LINK_UPLOADED_VAL, context);
                    }
                  },
                  child: Text(
                    googleDoclinkList.length == 0
                        ? MessageConstant.PARTNER_UPLOAD_DOCUMENT
                        : MessageConstant.PARTNER_ADD_MORE,
                    style: TextStyle(
                        color: Palette.accentColor,
                        fontSize: 14,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  )),
               Column(
                children: List.generate(googleDoclinkList.length, (index) {
                  return Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          googleDoclinkList[index],
                          style: TextStyle(
                              color: Palette.primaryTextColor,
                              fontSize: 16,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            googleDoclinkList.removeAt(index);
                          });
                        },
                      ),
                    ],
                  );
                }),
              )
            ],
          ),
        ],
      );
    }

    mediaPickerWidgets() {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          UIHelper.verticalSpaceMedium,
          mediaLabelText(MessageConstant.PARTNER_PHOTO),
          SizedBox(
            height: 3,
          ),
          Text(
           MessageConstant.PARTNER_ADD_COMPELLING_PHOTO,
            style: AppTextStyle.getDynamicFontStyle(
                ColorValues.GREY__COLOR, 12, FontType.Regular),
          ),
          UIHelper.verticalSpaceSmall,
          mediaImageListUIData,
          UIHelper.verticalSpaceSmall,
          mediaLabelText(MessageConstant.PARTNER_VIDEOS),
          SizedBox(
            height: 3,
          ),
          Text(
           MessageConstant.PARTNER_ABOUT_YOUR_COMPANY,
            style: AppTextStyle.getDynamicFontStyle(
                ColorValues.GREY__COLOR, 12, FontType.Regular),
          ),
          UIHelper.verticalSpaceSmall,
          videoListUi,
          UIHelper.verticalSpaceSmall,
          mediaLabelText('Documents (PDF only)'),
          SizedBox(
            height: 3,
          ),
          Text(
           MessageConstant.PARTNER_UPLOAD_DOC_ADDITIONAL_DET,
            style: AppTextStyle.getDynamicFontStyle(
                ColorValues.GREY__COLOR, 12, FontType.Regular),
          ),
          UIHelper.verticalSpaceSmall,
          docListUiData,
          UIHelper.verticalSpaceMedium,
          uploadGoogleDocLink(),
          UIHelper.verticalSpaceMedium
        ],
      );
    }

    mediaHeaderWidget() {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(UIHelper.screenPadding),
            child: colorIcon(ImagePath.ICON_MEDIA, 25, 25),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                  right: 0, bottom: UIHelper.screenPadding, top: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  UIHelper.verticalSpaceExtraSmall,
                  Text(
                   MessageConstant.PARTNER_ADD_MEDIA,
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.primaryTextColor, 14, FontType.Regular),
                  ),
                  SizedBox(
                    height: 3,
                  ),
                  Text(
                   MessageConstant.PARTNER_ADD_COMPANY_LOGOS_PRODUCT_IMAGE,
                    style: AppTextStyle.getDynamicFontStyle(
                        ColorValues.GREY__COLOR, 12, FontType.Regular),
                  ),
                  isMediaExpanded ? mediaPickerWidgets() : Container(height: 0.0,),
                ],
              ),
            ),
          ),
        ],
      );
    }

    mediaWidget() {
      return Container(
          decoration: rectangleDecoration(), child: mediaHeaderWidget());


    }

    getHeaderWidget() {
      return Padding(
        padding: const EdgeInsets.fromLTRB(40.0, 0, 13, 0),
        child: Container(
          width: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
               MessageConstant.PARTNER_PROVIDE_DETAILS_ABOUT_BUSINESS,
                style: TextStyle(
                    fontSize: 13, color:  ColorValues.light_grey),
              ),
            ],
          ),
        ),
      );
    }

    void goToNextScreen() async {
      FocusScope.of(context).unfocus();
      generateChipsForOther();
      getSelectedCategoryDetail();
      _formKey.currentState.save();
      if (_formKey.currentState.validate()) {
        if (selectedCategoryOption.length > 0) {
          if (personalInfoObject.offers.length > 0) {
            personalInfoObject.companyName = companyNameController.text;
            personalInfoObject.companyAddress = companyAddressController.text;
            personalInfoObject.companyPhoneNumber = phoneNumberController.text;
            personalInfoObject.phoneNumber = phoneNumberController.text;
            personalInfoObject.webUrl = websiteController.text;
            personalInfoObject.aboutCompany =
                aboutCompanyController.text.trim();
            personalInfoObject.referCode = referalController.text.trim();
            personalInfoObject.categoryResult = null;
            personalInfoObject.categoryResult =
                CategoryModel.mapList(selectedCategoryList);
            print("categoryResult size+++++" +
                personalInfoObject.categoryResult.length.toString());

            if (widget.isRedirectToRecommendation) {
              if (strNewPassword.length >= 8) {
                if (ValidationWidget.NumberChara(strNewPassword)) {
                  if (ValidationWidget.upper_case(strNewPassword)) {
                    if (ValidationWidget.lower_case(strNewPassword)) {
                      if (ValidationWidget.specialCha(strNewPassword)) {
                        CustomProgressLoader.showLoader(context);
                      }
                    }
                  }
                }
              }
            } else {
              CustomProgressLoader.showLoader(context);
            }

            Timer _timer =  Timer(const Duration(milliseconds: 400), () {
              if (widget.isRedirectToRecommendation) {
                if (ValidationWidget.NumberChara(strNewPassword)) {
                  if (ValidationWidget.upper_case(strNewPassword)) {
                    if (ValidationWidget.lower_case(strNewPassword)) {
                      if (ValidationWidget.specialCha(strNewPassword)) {
                        registerUser(personalInfoObject);
                      }
                    }
                  }
                }
              } else {
                registerUser(personalInfoObject);
              }
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.MIN_1_OFFERING_SELECTED_VAL, context);
          }
//    if (personalInfoObject != null) setData(personalInfoObject);
        } else {
          setState(() {
            isBusinessCategoryError = true;
            //bottomViewColor = Palette.redColor;
            bottomViewColor = Colors.red[700];
          });
        }
      }
    }

    onTapPreviewProfile() {
      _formKey.currentState.save();
      if (_formKey.currentState.validate()) {
        personalInfoObject.companyName = companyNameController.text;
        personalInfoObject.companyAddress = companyAddressController.text;
        personalInfoObject.companyPhoneNumber = phoneNumberController.text;
        personalInfoObject.webUrl = websiteController.text;
        personalInfoObject.aboutCompany = aboutCompanyController.text.trim();
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>  CompanyPreviewProfileWidget(
                  personalInfoObject,
                  this.mediaImagesList,
                  this.mediaVideosList,
                  this.mediaDocumentList,
                  this.googleDoclinkList,
                )));
      } else {
        ToastWrap.showToast(
            MessageConstant.REQUIRED_FILL_ALL_FIELD_VAL, context);
      }
    }

    final newPasswordUI =  Padding(
      padding:
           EdgeInsets.only(left: 0.0, top: 15.0, right: 0.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            validator: (val) => val.trim().length == 0
                ? MessageConstant.ENTER_PASSWORD_VAL
                :
                null,
            onSaved: (val) => strNewPassword = val,
            cursorColor: Constant.CURSOR_COLOR,
            obscureText: _newPassObscureText,
            style:  TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 16.0,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            autofocus: false,
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              suffixIcon:  GestureDetector(
                child:  Padding(
                  padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                  child: _newPassObscureText
                      ?  Image.asset(
                          "assets/newDesignIcon/login/hide.png",
                          width: 30.0,
                          height: 30.0,
                        )
                      :  Image.asset(
                    "assets/newDesignIcon/login/unhide.png",
                    width: 30.0,
                    height: 30.0,color: AppConstants.colorStyle.lightPurple,
                  ),
                ),
                onTap: () {
                  if (_newPassObscureText)
                    _newPassObscureText = false;
                  else
                    _newPassObscureText = true;

                  setState(() {
                    _newPassObscureText;
                  });
                },
              ),
              labelText: MessageConstant.PARTNER_PASSWORD,
              errorStyle: Util.errorTextStyle,
              errorMaxLines: 3,
              labelStyle:  TextStyle(
                  color: Colors.grey, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );
    final referalCodeField =  Padding(
      padding:
           EdgeInsets.only(left: 25.0, top: 0.0, right: 25.0, bottom: 0.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            keyboardType: TextInputType.text,
            controller: referalController,
            focusNode: referalFocusNode,
            textInputAction: TextInputAction.done,
            cursorColor: Constant.CURSOR_COLOR,

            style:  TextStyle(
                color:  ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 22.0,
                fontFamily: Constant.TYPE_CUSTOMBOLD),
            decoration:  InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              counterText: "",
              focusedBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              enabledBorder:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),
              border:  UnderlineInputBorder(
                  borderSide:  BorderSide(
                      color:  ColorValues.DARK_GREY, width: 1.0)),

              labelText: "",
              errorStyle: Util.errorTextStyle,
              labelStyle:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            ),
          )),
    );

    Widget showReferelPopUp(context) {
      showModalBottomSheet(
          context: context,
          backgroundColor: Colors.white,

          isScrollControlled: true,
          builder: (BuildContext context) {
            return StatefulBuilder(
                builder: (BuildContext context, StateSetter myState
                 ) {
              return Form(
                  key: formKeyReferal,
                  child: Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom,
                      left: 0, //11.0,
                      right: 0, // 11.0,
                    ),
                    child: Container(
                      height: 275.0,
                      //color: Colors.black.withOpacity(0.8),
                      color: Colors.white,
                      child:  Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
                            child:  Container(
                                height: 4.0,
                                width: 58.0,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color:  ColorValues.GREY__COLOR,
                                )),
                          ),
                          Padding(
                            padding: const EdgeInsets.fromLTRB(15.0, 40, 35, 0),
                            child: TextViewWrap.textView(
                               MessageConstant.PARTNER_REFERRAL_CODE,
                                TextAlign.start,
                                 ColorValues.HEADING_COLOR_EDUCATION,
                                20.0,
                                FontWeight.normal),
                          ),
                          referalCodeField,
                          Padding(
                              padding:  EdgeInsets.only(
                                  left: 20.0,
                                  top: 40.0,
                                  right: 20.0,
                                  bottom: 15.0),
                              child:  InkWell(
                                child:  Container(
                                    height: 44.0,
                                    //width: 226.0,
                                    color:  ColorValues.BLUE_COLOR,
                                    child:  Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                         Text(
                                          MessageConstant.PARTNER_CONFIRM,
                                          style:  TextStyle(
                                            color: Colors.white,
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 20.0,
                                          ),
                                        )
                                      ],
                                    )),
                                onTap: () {

                                  callApiToValidateTheaReferalCode('');

                                },
                              ))
                        ],
                      ),
                    ),
                  ));
            });
          }).then((value) => (value) {});
    }

    bool isShowConformationDialog() {
      if (companyNameController.text.length > 0 ||
          nameController.text.length > 0 ||
          companyAddressController.text.length > 0 ||
          phoneNumberController.text.length > 0 ||
          websiteController.text.length > 0 ||
          aboutCompanyController.text.length > 0) {
        return true;
      }
      return false;
    }

    void conformationDialogForBackNavigation(back) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.fromLTRB(
                                                  15.0, 10.0, 15.0, 10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                     MessageConstant.PARTNER_DISCARD_ALL_CHANGES,
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                       style:  TextStyle(
                                                           color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                           height: 1.2,
                                                           fontSize: 16.0,
                                                           fontWeight: FontWeight.w400,
                                                           fontFamily:
                                                           Constant.latoRegular),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                              MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                        fontSize: 16.0,
                                                        fontWeight: FontWeight.w500,
                                                        fontFamily:Constant.latoRegular),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                               MessageConstant.PARTNER_OK,
                                                textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION_1,
                                                        fontSize: 16.0,
                                                        fontWeight: FontWeight.w500,
                                                        fontFamily:Constant.latoRegular),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (back == "back") {
                                                  Navigator.pop(context);
                                                } else {
                                                  if (widget.pageName ==
                                                      "Login") {
                                                    Navigator.of(context)
                                                        .popUntil((route) =>
                                                            route.isFirst);
                                                  } else {
                                                    Navigator.of(context)
                                                        .popUntil((route) =>
                                                            route.isFirst);
                                                    Navigator.of(context).pushReplacement(
                                                         MaterialPageRoute(
                                                            builder: (BuildContext
                                                                    context) =>
                                                                 LoginPage(
                                                                    null)));
                                                  }
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    getFormWidget() {
      return Padding(
        padding: EdgeInsets.only(
            left: 0,
            right: 0,
            bottom: 15,
            top: 13.0),
        child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 13.0, right: 13.0),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[


                        Padding(
                            padding: const EdgeInsets.only(top: 0),
                            child:  TextFormField(
                              onFieldSubmitted: (term) {
                                _companyNameFocus.unfocus();
                                FocusScope.of(context).requestFocus(_nameFocus);
                              },
                              validator: (value) {
                                return ValidationChecks.validateCompanyName(
                                    value);
                              },
                              cursorColor: Constant.CURSOR_COLOR,
                              controller: companyNameController,

                              focusNode: _companyNameFocus,
                              textInputAction: TextInputAction.next,
                              maxLength: TextLength.COMAPNY_NAME_MAX_LENGTH,
                              textCapitalization: TextCapitalization.sentences,
                              keyboardType: TextInputType.text,
                              style:  TextStyle(
                                  color: ColorValues.HEADING_COLOR_EDUCATION,
                                  fontSize: 16.0,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              autofocus: false,
                              decoration: textInputDecorationCommon(
                                 MessageConstant.PARTNER_DISPLAY_NAME,
                                  ImagePath.ICON_DOC,
                                  23,
                                  23,
                                  MessageConstant.PARTNER_DISPLAYED_HOMEPAGE),
                            ),),


                        SizedBox(
                          height: 15,
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 0.0, bottom: 0),
                          child: widget.pageName == "dashBoard"
                              ?  Container(
                                  height: 0.0,
                                )
                              : widget.firstName == "" ||
                                      widget.firstName == "null"
                                  ?  Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                         TextFormField(
                                          onFieldSubmitted: (term) {
                                            _nameFocus.unfocus();
                                            FocusScope.of(context).requestFocus(
                                                _companyAddressFocus);
                                          },
                                           validator: (val) =>val.trim().length == 0
                                               ? null
                                               : !ValidationWidget.isName(val)
                                               ? MessageConstant.NAME_CONTAIN_ALPHABT_VAL
                                               : null,
                                          cursorColor: Constant.CURSOR_COLOR,
                                          textInputAction: TextInputAction.next,
                                          focusNode: _nameFocus,
                                          maxLines: null,
                                          maxLength:
                                              TextLength.YOUR_NAME_MAX_LENGTH,
                                          textCapitalization:
                                              TextCapitalization.sentences,
                                          keyboardType: TextInputType.text,
                                          controller: nameController,
                                          style:  TextStyle(
                                              color: ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 16.0,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                          autofocus: false,
                                          decoration: textInputDecorationCommon(
                                              MessageConstant.PARTNER_YOUR_NAME,
                                              ImagePath.ICON_DOC,
                                              23,
                                              23,
                                             MessageConstant.PARTNER_FIRST_LAST_NAME),
                                        ),
                                      ],
                                    )
                                  :  Container(
                                      height: 0.0,
                                    ),
                        ),

                        SizedBox(
                          height: 18,
                        ),

                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                           MessageConstant.PARTNER_BUSINESS_CATEGORY,
                            style:  TextStyle(
                                color: ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR,fontSize: 13.0),
                          ),
                        ),
                        Container(
                          decoration: bottomBorderDynamic(bottomViewColor),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: <Widget>[
                                  selectedCategoryOption.length > 0
                                      ? Expanded(
                                          flex: 1,
                                          child: InkWell(
                                            onTap: () {
                                              setState(() {
                                                showList = !showList;
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());
                                              });
                                            },
                                            child: Wrap(
                                              children: isShowMore
                                                  ? getSelectedWidgets(
                                                      selectedCategoryOption
                                                          .sublist(0, 1),
                                                      "mainCategory")
                                                  : getSelectedWidgets(
                                                      selectedCategoryOption,
                                                      "mainCategory"),
                                            ),
                                          ),
                                        )
                                      : Expanded(
                                          flex: 1,
                                          child: InkWell(
                                            onTap: () {
                                              setState(() {
                                                showList = !showList;
                                                FocusScope.of(context)
                                                    .requestFocus(FocusNode());
                                              });
                                            },
                                            child: Container(
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    bottom: 7.0),
                                                child: Text(
                                                 MessageConstant.PARTNER_SELECT_CATEGORY,
                                                  style: AppTextStyle
                                                      .getDynamicFontStyle(
                                                          Palette
                                                              .primaryTextColor,
                                                          16,
                                                          FontType.Regular),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                  selectedCategoryOption.length > 1
                                      ? InkWell(
                                          onTap: () {
                                            setState(() {
                                              isShowMore = !isShowMore;
                                            });
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 16.0, left: 8.0),
                                            child: Text(
                                              isShowMore
                                                  ? '+${selectedCategoryOption.length - 1} More'
                                                  : 'Less',
                                              style: AppTextStyle
                                                  .getDynamicFontStyle(
                                                      Palette.accentColor,
                                                      14,
                                                      FontType.Regular),
                                            ),
                                          ),
                                        )
                                      : Container(height: 0.0,),
                                ],
                              ),

                            ],
                          ),
                        ),
                        //isOtherSelected ?
                        businessCategoryList != null &&
                                businessCategoryList.length > 0
                            ? businessCategoryListWidget()
                            : Container(height: 0.0,),

                        isBusinessCategoryError
                            ? Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(top: 6.0),
                                    child: Text(
                                      '${MessageConstant.ENTER_BUSINESS_CATE_VAL}',
                                      textAlign: TextAlign.left,
                                      style: AppTextStyle.getDynamicFontStyle(
                                          //Palette.redColor,
                                          Colors.red[700],
                                          12,
                                          FontType.Regular),
                                    ),
                                  ),
                                ],
                              )
                            : Container(height: 0.0,),

                        isOtherSelected
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  UIHelper.verticalSpaceSmall1,
                                  Container(
                                    //decoration: bottomBorder(),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        selectedOtherOption.length > 0
                                            ? Text(
                                               MessageConstant.PARTNER_OTHER_BUSINESS_CATEGORY,
                                                style: AppTextStyle
                                                    .getDynamicFontStyle(
                                                        Palette
                                                            .secondaryTextColor,
                                                        12,
                                                        FontType.Regular),
                                              )
                                            : Container(height: 0.0,),
                                        Row(
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: <Widget>[
                                            selectedOtherOption.length > 0
                                                ? Expanded(
                                                    flex: 1,
                                                    child: Wrap(
                                                      //children: getSelectedWidgets(selectedOtherOption,"otherCategory"),
                                                      children: isShowOtherMore
                                                          ? getSelectedWidgets(
                                                              selectedOtherOption
                                                                  .sublist(
                                                                      0, 1),
                                                              "otherCategory")
                                                          : getSelectedWidgets(
                                                              selectedOtherOption,
                                                              "otherCategory"),
                                                    ),
                                                  )
                                                : Expanded(
                                                    flex: 1,
                                                    child: isOtherSelected
                                                        ? selectOtherCategoryTextField()
                                                        : Container(height: 0.0,),
                                                  ),
                                            selectedOtherOption.length > 1
                                                ? InkWell(
                                                    onTap: () {
                                                      setState(() {
                                                        isShowOtherMore =
                                                            !isShowOtherMore;
                                                      });
                                                    },
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              bottom: 16.0,
                                                              left: 8.0,
                                                              right: 16.0),
                                                      child: Text(
                                                        isShowOtherMore
                                                            ? '+${selectedOtherOption.length - 1} More'
                                                            : 'Less',
                                                        style: AppTextStyle
                                                            .getDynamicFontStyle(
                                                                Palette
                                                                    .accentColor,
                                                                14,
                                                                FontType
                                                                    .Regular),
                                                      ),
                                                    ),
                                                  )
                                                : Container(height: 0.0,),
                                          ],
                                        ),
                                        selectedOtherOption.length > 0
                                            ? selectOtherCategoryTextField()
                                            : Container(height: 0.0,),
                                      ],
                                    ),
                                  ),
                                ],
                              )
                            : Container(height: 0.0,),

                        SizedBox(
                          height: 15,
                        ),

                         TextFormField(
                          onFieldSubmitted: (term) {
                            _companyAddressFocus.unfocus();
                            FocusScope.of(context)
                                .requestFocus(_phoneNumberNameFocus);
                          },
                          validator: (value) {
                            return ValidationChecks.validateCompanyAddress(
                                value);
                          },
                          cursorColor: Constant.CURSOR_COLOR,
                          focusNode: _companyAddressFocus,
                          maxLines: null,
                          textCapitalization: TextCapitalization.sentences,
                          keyboardType: TextInputType.multiline,
                          maxLength: TextLength.COMAPNY_ADDRESS_MAX_LENGTH,
                          controller: companyAddressController,
                          style:  TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 16.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          autofocus: false,
                          decoration: textInputDecorationCommon(
                            MessageConstant.PARTNER_YOUR_ADDRESS,
                              ImagePath.ICON_DOC,
                              23,
                              23,
                              ""),
                        ),

                        SizedBox(
                          height: 15,
                        ),




                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                             CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: false,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    selectedCountryCode =
                                        country.dialingCode;
                                  });
                                },
                                selectedCountryCode: selectedCountryCode,
                              ),

                            SizedBox(
                              width: 12,
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 1.0),
                                child: Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    TextFormField(
                                      controller: phoneNumberController,
                                      cursorColor: Constant.CURSOR_COLOR,
                                      focusNode: _phoneNumberNameFocus,
                                      textInputAction: TextInputAction.next,
                                      keyboardType: TextInputType.number,
                                      decoration:
                                      textFormFieldDecorationWithLabel(
                                          'Phone Number'),
                                      style: textFormFieldValueStyle(),
                                      onFieldSubmitted: (term) {
                                        _phoneNumberNameFocus.unfocus();
                                        FocusScope.of(context)
                                            .requestFocus(_emailFocus);
                                      },
                                      validator: (value) {
                                        return ValidationChecks.validatePhone(
                                            value);
                                      },
                                      maxLength: 20,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),



                        SizedBox(
                          height: 15,
                        ),

                        Padding(
                          padding: const EdgeInsets.only(top: 0.0),
                          child: widget.email == "" || widget.email == "null"
                              ?  TextFormField(
                                  onFieldSubmitted: (term) {
                                    _emailFocus.unfocus();
                                    FocusScope.of(context)
                                        .requestFocus(_websiteURLFocus);
                                  },
                                  validator: (value) {
                                    return ValidationChecks.validateEmail(
                                        value);
                                  },
                                  cursorColor: Constant.CURSOR_COLOR,
                                  focusNode: _emailFocus,
                                  textInputAction: TextInputAction.next,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  controller: emailController,
                                  style:  TextStyle(
                                      color: ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 16.0,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                  autofocus: false,
                                  decoration: textInputDecorationCommon(
                                      'Email',
                                      ImagePath.ICON_DOC,
                                      23,
                                      23,
                                      ""),
                                  enabled: widget.pageName == "dashBoard"
                                      ? false
                                      : widget.signupType == "apple" ||
                                              widget.signupType == "google"
                                          ? false
                                          : widget.isRedirectToRecommendation
                                              ? false
                                              : referalUserId != ""
                                                  ? false
                                                  : true,
                                )
                              :  Container(height: 0.0),
                        ),

                        widget.isRedirectToRecommendation
                            ?  Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  newPasswordUI,
                                  password_error_lenght
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          1.0,
                                          0.0,
                                          0.0,
                                           Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Image.asset(
                                                "assets/profile/red_cross.png",
                                                width: 14.0,
                                                height: 14.0,
                                                color: Colors.red[600],
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              TextViewWrap.textViewMultiLine(
                                                 MessageConstant.PARTNER_MINIMUM_8_CHARACTERS,
                                                  TextAlign.start,
                                                  Colors.red[600],
                                                  12.0,
                                                  FontWeight.normal,
                                                  1)
                                            ],
                                          ))
                                      :  Container(
                                          height: 0.0,
                                        ),
                                  password_error_specile
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          1.0,
                                          0.0,
                                          0.0,
                                           Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Image.asset(
                                                "assets/profile/red_cross.png",
                                                width: 14.0,
                                                height: 14.0,
                                                color: Colors.red[600],
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              TextViewWrap.textViewMultiLine(
                                                MessageConstant.PARTNER_SPECIAL_CHARACTER,
                                                  TextAlign.start,
                                                  Colors.red[600],
                                                  12.0,
                                                  FontWeight.normal,
                                                  1)
                                            ],
                                          ))
                                      :  Container(
                                          height: 0.0,
                                        ),
                                  password_error_upper || password_error_lower
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          1.0,
                                          0.0,
                                          0.0,
                                           Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Image.asset(
                                                "assets/profile/red_cross.png",
                                                width: 14.0,
                                                height: 14.0,
                                                color: Colors.red[600],
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              TextViewWrap.textViewMultiLine(
                                                 MessageConstant.PARTNER_LOWER_UPPER_LETTER,
                                                  TextAlign.start,
                                                  Colors.red[600],
                                                  12.0,
                                                  FontWeight.normal,
                                                  1)
                                            ],
                                          ))
                                      :  Container(
                                          height: 0.0,
                                        ),
                                  password_error_number
                                      ? PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          1.0,
                                          0.0,
                                          0.0,
                                           Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Image.asset(
                                                "assets/profile/red_cross.png",
                                                width: 14.0,
                                                height: 14.0,
                                                color: Colors.red[600],
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              TextViewWrap.textViewMultiLine(
                                                  "One number",
                                                  TextAlign.start,
                                                  Colors.red[600],
                                                  12.0,
                                                  FontWeight.normal,
                                                  1)
                                            ],
                                          ))
                                      :  Container(
                                          height: 0.0,
                                        )
                                ],
                              )
                            :  Container(
                                height: 0.0,
                              ),

                        SizedBox(
                          height: 15,
                        ),

                         TextFormField(
                          onFieldSubmitted: (term) {
                            _websiteURLFocus.unfocus();
                            FocusScope.of(context)
                                .requestFocus(_aboutCompanyFocus);
                          },
                          validator: (value) {
                            return value.trim().length == 0
                                ? null
                                : ValidationChecks.validateWebUrl(value);
                          },
                          cursorColor: Constant.CURSOR_COLOR,
                          textInputAction: TextInputAction.next,
                          keyboardType: TextInputType.text,
                          focusNode: _websiteURLFocus,
                          controller: websiteController,
                          style:  TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 16.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          autofocus: false,
                          decoration:  InputDecoration(
                            contentPadding:
                                const EdgeInsets.fromLTRB(0.0, 7.0, 5.0, 10.0),
                            focusedBorder:  UnderlineInputBorder(
                                borderSide:  BorderSide(
                                    color:  ColorValues.DARK_GREY,
                                    width: 1.0)),
                            enabledBorder:  UnderlineInputBorder(
                                borderSide:  BorderSide(
                                    color:  ColorValues.DARK_GREY,
                                    width: 1.0)),
                            border:  UnderlineInputBorder(
                                borderSide:  BorderSide(
                                    color:  ColorValues.DARK_GREY,
                                    width: 1.0)),
                            labelText: MessageConstant.PARTNER_WEBSITE_URL,
                            hintText: "",
                            errorStyle: Util.errorTextStyle,
                            errorMaxLines: 3,
                            labelStyle:  TextStyle(
                                color: Colors.grey,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          ),
                        ),

                        SizedBox(
                          height: 15,
                        ),

                         TextFormField(
                          validator: (value) {
                            return ValidationChecks.validateAboutCompany(
                                value.trim());
                          },
                          cursorColor: Constant.CURSOR_COLOR,
                          textInputAction: TextInputAction.done,
                          keyboardType: TextInputType.multiline,
                          textCapitalization: TextCapitalization.sentences,
                          controller: aboutCompanyController,
                          focusNode: _aboutCompanyFocus,
                          style:  TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 16.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          autofocus: false,
                          decoration: textInputDecorationCommon(
                             MessageConstant.PARTNER_ABOUT_COMPANY_SERVICE,
                              ImagePath.ICON_DOC,
                              23,
                              23,
                           MessageConstant.PARTNER_PREMIER_TUTORING_SERVICE_SPECIALIZING),
                        ),
                        Text(
                          MessageConstant.PARTNER_MESSAGE_COMPELLING,
                          style: AppTextStyle.getDynamicFontStyle(
                              ColorValues.GREY__COLOR, 11, FontType.Regular),
                        ),

                        SizedBox(
                          height: 15,
                        ),
                        InkWell(
                          child: mediaWidget(),
                          onTap: () {
                            setState(() {
                              isMediaExpanded = !isMediaExpanded;
                              FocusScope.of(context).requestFocus(FocusNode());
                            });
                          },
                        ),
                        SizedBox(
                          height: 23,
                        ),


                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(15.0, 0, 13, 10),
                  child:  Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                         InkWell(
                          child: TextViewWrap.textView(
                              MessageConstant.PARTNER_HAVE_REFERRAL_CODE,
                              TextAlign.start,
                               ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal),
                          onTap: () {
                            showReferelPopUp(context);
                          },
                        )
                      ]),
                ),
                 Padding(
                    padding:  EdgeInsets.only(
                        left: 15.0, top: 10.0, right: 0.0, bottom: 0.0),
                    child:  Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                         Expanded(
                          child:  InkWell(
                            child:  Image.asset(
                              isAgree
                                  ? "assets/newDesignIcon/login/check.png"
                                  : "assets/newDesignIcon/login/uncheck.png",
                              width: 25.0,
                              height: 25.0,
                            ),
                            onTap: () {
                              if (isAgree)
                                isAgree = false;
                              else
                                isAgree = true;
                              setState(() {
                                isAgree;
                              });
                            },
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child: Container(
                            padding: EdgeInsets.only(left: 4.0, right: 4.0),
                            height: 45,
                            child:  Container(
                                child: RichText(
                              maxLines: 2,
                              textAlign: TextAlign.start,
                              text: TextSpan(
                                text: MessageConstant.PARTNER_SIGINGUP_AGREE_TO_OUR,
                                style:  TextStyle(
                                    color:
                                         ColorValues.GREY_TEXT_COLOR,
                                    fontSize: 13.0,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                children: <TextSpan>[
                                  TextSpan(
                                      text: 'Terms, Data',
                                      recognizer:  TapGestureRecognizer()
                                        ..onTap = () {
                                          Navigator.push(
                                              Constant.applicationContext,
                                               MaterialPageRoute(
                                                  //   builder: (context) =>  DashBoardWidget()));
                                                  builder: (context) =>
                                                       WebViewWidget(
                                                          Constant.TERMS,
                                                          MessageConstant.PARTNER_TERMS_DATA)));
                                        },
                                      style:  TextStyle(
                                          color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          fontSize: 13.0,
                                          fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                  TextSpan(
                                    text: " & ",
                                    style:  TextStyle(
                                        color:  ColorValues.GREY_TEXT_COLOR,
                                        fontSize: 13.0,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                  ),
                                  TextSpan(
                                    text: MessageConstant.PARTNER_PRIVACY_POLICY,
                                    recognizer:  TapGestureRecognizer()
                                      ..onTap = () {
                                        Navigator.push(
                                            Constant.applicationContext,
                                             MaterialPageRoute(
                                                //   builder: (context) =>  DashBoardWidget()));
                                                builder: (context) =>
                                                     WebViewWidget(
                                                        Constant.PRIVACY_POLICY,
                                                         MessageConstant.PARTNER_PRIVACY_POLICY)));
                                      },
                                    style:  TextStyle(
                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                        fontSize: 13.0,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                  ),
                                  TextSpan(
                                    text:
                                       MessageConstant.PARTNER_CERTIFY_THAT_OVER_15,
                                    style:  TextStyle(
                                        color:  ColorValues.GREY_TEXT_COLOR,
                                        fontSize: 13.0,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                  ),
                                ],
                              ),
                            )),
                          ),
                          flex: 1,
                        )
                      ],
                    )),
                 Padding(
                  padding:  EdgeInsets.only(
                      left: 15.0, top: 0.0, right: 15.0, bottom: 13.0),
                  child: Stack(
                    children: <Widget>[
                       Container(
                          height: 48.0,
                          //width: 165.0,
                          child: FlatButton(
                            onPressed: () {
                              _formKey.currentState.save();
                              if (widget.isRedirectToRecommendation) {
                                if (strNewPassword != null &&
                                    strNewPassword.length > 0) {
                                  if (strNewPassword.length < 8) {
                                    setState(() {
                                      password_error_lenght = true;
                                    });
                                  } else {
                                    setState(() {
                                      password_error_lenght = false;
                                    });
                                  }

                                  if (!ValidationWidget.NumberChara(
                                      strNewPassword)) {
                                    setState(() {
                                      password_error_number = true;
                                    });
                                  } else {
                                    setState(() {
                                      password_error_number = false;
                                    });
                                  }

                                  if (!ValidationWidget.upper_case(
                                      strNewPassword)) {
                                    setState(() {
                                      password_error_upper = true;
                                    });
                                  } else {
                                    setState(() {
                                      password_error_upper = false;
                                    });
                                  }

                                  if (!ValidationWidget.lower_case(
                                      strNewPassword)) {
                                    setState(() {
                                      password_error_lower = true;
                                    });
                                  } else {
                                    setState(() {
                                      password_error_lower = false;
                                    });
                                  }

                                  if (!ValidationWidget.specialCha(
                                      strNewPassword)) {
                                    setState(() {
                                      password_error_specile = true;
                                    });
                                  } else {
                                    setState(() {
                                      password_error_specile = false;
                                    });
                                  }
                                } else {
                                  setState(() {
                                    password_error_specile = false;
                                    password_error_lower = false;
                                    password_error_upper = false;
                                    password_error_number = false;
                                    password_error_lenght = false;
                                  });
                                }
                                if (isAgree) goToNextScreen();
                              } else {
                                if (isAgree) goToNextScreen();
                              }
                            },
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(0)),
                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                            child: Row(
                              // Replace with a Row for horizontal icon + text
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Text(MessageConstant.PARTNER_CONTINUE,
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.white)),
                              ],
                            ),
                          )),
                      isAgree?new Container(height:0.0):  Container(height:48.0,color: Colors.white.withOpacity(.5),)
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                     Expanded(
                      child: Row(
                        children: <Widget>[
                           Text(MessageConstant.PARTNER_ALREADY_HAVE_ACCOUNT,
                              style:  TextStyle(
                                  color:  ColorValues.GREY_TEXT_COLOR,
                                  fontSize: 14.0,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                          SizedBox(
                            width: 6,
                          ),
                           InkWell(
                            child:  Text(MessageConstant.PARTNER_SIGNIN,
                                style:  TextStyle(
                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: Constant.TYPE_CUSTOMBOLD)),
                            onTap: () {
                              if (isShowConformationDialog()) {
                                conformationDialogForBackNavigation("SignIn");
                              } else {
                                if (widget.pageName == "Login") {
                                  //Navigator.of(context).popUntil((route) => route.isFirst);
                                  Navigator.of(context).pop('SignIn');
                                } else {
                                  Navigator.of(context)
                                      .popUntil((route) => route.isFirst);
                                  Navigator.of(context).pushReplacement(
                                       MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                               LoginPage(
                                                null,
                                                showLogin: true,
                                              )));
                                  //Navigator.of(context).pop('SignIn');
                                }
                              }
//                            Navigator.pushReplacement(
//                                context,
//                                 MaterialPageRoute(
//                                  //   builder: (context) =>  DashBoardWidget()));
//                                    builder: (context) =>  LoginPage(null)));
                            },
                          )
                        ],
                      ),
                      flex: 0,
                    ),
                  ],
                ),
                Padding(
                    padding: EdgeInsets.only(
                        left: 0.0, right: 0.0, top: 15, bottom: 0),
                    child: Container(
                      child: Column(
                        children: <Widget>[

                          Padding(
                              padding: EdgeInsets.only(
                                  left: 13.0, right: 13.0, top: 15, bottom: 0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15.0,
                                            right: 0.0,
                                            top: 0.0,
                                            bottom: 0),
                                        child: InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  Constant.applicationContext,
                                                   MaterialPageRoute(
                                                      builder: (context) =>
                                                           WebViewWidget(
                                                              Constant.CARRER,
                                                              MessageConstant.PARTNER_CAREER)));
                                            },
                                            child:  Text(
                                             MessageConstant.PARTNER_CAREERS,
                                              textAlign: TextAlign.start,
                                              style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize: 12.0,
                                                  fontWeight: FontWeight.w400),
                                            )),
                                      ),
                                      flex: 0),
                                  Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15.0,
                                            right: 0.0,
                                            top: 0.0,
                                            bottom: 0),
                                        child: InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  Constant.applicationContext,
                                                   MaterialPageRoute(
                                                      builder: (context) =>
                                                           WebViewWidget(
                                                              Constant
                                                                  .PRIVACY_POLICY,
                                                             MessageConstant.PARTNER_PRIVACY_POLICY)));
                                            },
                                            child:  Text(
                                              MessageConstant.PARTNER_PRIVACY_POLICY,
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize: 12.0,
                                                  fontWeight: FontWeight.w400),
                                            )),
                                      ),
                                      flex: 0),
                                  Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15.0,
                                            right: 0.0,
                                            top: 0.0,
                                            bottom: 0),
                                        child: InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  Constant
                                                      .applicationContext,
                                                   MaterialPageRoute(
                                                      builder: (context) =>  WebViewWidget(
                                                          Constant
                                                              .FAQ,
                                                         MessageConstant.PARTNER_FAQS)));
                                            },
                                            child:  Text(
                                              MessageConstant.PARTNER_FAQS,
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize: 12.0,
                                                  fontWeight: FontWeight.w400),
                                            )),
                                      ),
                                      flex: 0),
                                  Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15.0,
                                            right: 15.0,
                                            top: 0.0,
                                            bottom: 0),
                                        child: InkWell(
                                            onTap: () {
                                              Navigator.push(
                                                  Constant.applicationContext,
                                                   MaterialPageRoute(
                                                      builder: (context) =>
                                                           WebViewWidget(
                                                              Constant.TERMS,
                                                              MessageConstant.PARTNER_TERMS_DATA)));
                                            },
                                            child:  Text(
                                           MessageConstant.PARTNER_TERMS_SERVICES,
                                              textAlign: TextAlign.end,
                                              style:  TextStyle(
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                  fontSize: 12.0,
                                                  fontWeight: FontWeight.w400),
                                            )),
                                      ),
                                      flex: 0),
                                ],
                              )),
                        ],
                      ),
                    )),
              ],
            )),
      );
    }

    return  GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: SafeArea(
          child:  WillPopScope(
            onWillPop: () async {
              if (isShowConformationDialog()) {
                conformationDialogForBackNavigation("back");
              } else {
                Navigator.pop(context);
              }
              return false;
            },
            child: Scaffold(

                backgroundColor: Colors.white,
                body: GestureDetector(
                  onTap: () {
                    generateChipsForOther();
                    FocusScope.of(context).requestFocus(FocusNode());
                  },
                  child: FormKeyboardActions(
                      nextFocus: false,
                      keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                      keyboardBarColor: Colors.grey[200],
                      actions: [
                        KeyboardAction(
                          focusNode: _phoneNumberNameFocus,
                        ),
                      ],
                      child:  Column(
                        children: <Widget>[

                      Padding(
                      padding:
                      EdgeInsets
                          .only(
                          left:
                          0.0,
                          right:
                          0.0,
                          top: 10,
                          bottom:
                          15),
                    child:  Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                               Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 0.0),
                                  child:  InkWell(
                                    child:  SizedBox(
                                      height: 40.0,
                                      width: 30.0,
                                      child: PaddingWrap.paddingfromLTRB(
                                          4.0,
                                          0.0,
                                          0.0,
                                          3.0,
                                           Center(
                                              child:  Image.asset(
                                                "assets/newDesignIcon/navigation/back.png",
                                                height: 20.0,
                                                width: 10.0,
                                                fit: BoxFit.fitHeight,
                                                color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              ))),
                                    ),
                                    onTap: () {
                                      if (isShowConformationDialog()) {
                                        conformationDialogForBackNavigation(
                                            "back");
                                      } else {
                                        Navigator.pop(context);
                                      }
                                    },
                                  ),
                                ),
                                flex: 0,
                              ),
                               Expanded(
                                child:Padding(
                                  padding: const EdgeInsets.only(top:5.0),
                                  child:  Image
                                    .asset(
                                  "assets/newDesignIcon/navigation/spike_logo_login.png",
                                  height:
                                  32.0,
                                  width:
                                  116.0,
                                )),
                                flex: 1,
                              ),

                               Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 0.0),
                                  child:  InkWell(
                                    child:  SizedBox(
                                      height: 40.0,
                                      width: 30.0,
                                      child:  Container(),
                                    ),

                                  ),
                                ),
                                flex: 0,
                              ),
                            ],
                          )),




                          Expanded(
                            child: SingleChildScrollView(
                              child: Stack(
                                children: <Widget>[
                                   Column(
                                    children: <Widget>[
                                      //getHeaderWidget(),
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: <Widget>[

                                           Expanded(
                                            child:  Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: <Widget>[
                                                Padding(
                                                  padding: const EdgeInsets.only(
                                                      left: 13.0,
                                                      right: 13.0,
                                                      top: 30.0,
                                                      bottom: 0),
                                                  child:  Text(
                                                    MessageConstant.PARTNER_LETTS_STARTED,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                        fontSize: 22.0,
                                                        fontWeight: FontWeight.w700),
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsets.only(
                                                      left: 13.0,
                                                      right: 13.0,
                                                      top: 3.0,
                                                      bottom: 15),
                                                  child:  Text(
                                                   MessageConstant.PARTNER_PROVIDE_BUSINESS_DETAILS,
                                                    style:  TextStyle(
                                                        color:  Color(0xff828282),
                                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                        fontSize: 12.0,
                                                        fontWeight: FontWeight.w400),textAlign: TextAlign.center,
                                                  ),
                                                )
                                              ],
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ),
                                      getFormWidget(),

                                    ],
                                  ),

                                ],
                              ),
                            ),
                          ),
                        ],
                      )),
                )),
          ),
        ));
  }

  void goToPrevious() async {
    if (widget.pageName == "dashBoard") {
      Navigator.pop(context, "pop");
    } else {
      assetModelMap.clear();
      mediaImagesList.removeAt(0);
      mediaDocumentList.removeAt(0);
      mediaVideosList.removeAt(0);
      for (var file in mediaImagesList) {
        assetModelMap.add(AssetModel(
          file: file,
          tag: 'media',
          type: "image",
        ));
      }

      for (var file in mediaDocumentList) {
        assetModelMap.add(AssetModel(
          file: file,
          tag: 'media',
          type: "doc",
        ));
      }

      for (var file in mediaVideosList) {
        assetModelMap.add(AssetModel(
          file: file.path,
          tag: 'media',
          type: "video",
        ));
      }

      for (var file in googleDoclinkList) {
        assetModelMap.add(AssetModel(
          file: file,
          tag: 'media',
          type: "google",
        ));
      }

      personalInfoObject.companyName = companyNameController.text;
      personalInfoObject.companyAddress = companyAddressController.text;
      personalInfoObject.companyPhoneNumber = phoneNumberController.text;
      personalInfoObject.webUrl = websiteController.text;
      personalInfoObject.aboutCompany = aboutCompanyController.text.trim();
      personalInfoObject.assets = assetModelMap;
      Navigator.pop(context, personalInfoObject);
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    String deviceID = prefs.get(UserPreference.DEVICE_ID);
    String name = prefs.getString(UserPreference.NAME);
    String email = prefs.getString(UserPreference.EMAIL);
    userid = prefs.getString(UserPreference.USER_ID);
    if (widget.isRedirectToRecommendation) {
      if (email != null && email != "notdelete@gmail.com") {
        name = "";
        emailController =  TextEditingController(text: email);
      }
    }

    if (widget.pageName == "dashBoard") {
      emailController =  TextEditingController(text: email);
    }
    linkUrl = prefs.getString(UserPreference.PATHURL);
    if (linkUrl == null) {
      linkUrl = "";
      linkUrl = "";
    }
    print("data++++" + linkUrl);
    print("data++++" + widget.pageName);
    if ((linkUrl != "" || linkUrl != " ") &&
        (widget.pageName == "main" || widget.pageName == "recomendation")) {

      if (linkUrl.contains("referNow")) {
        // https://spikeview.com/referNow?userId=1830&roleId=1&email=sk1213@yopmail.com&pass=null
        List<String> mesagelist = linkUrl.split("=");

        referalUserId = mesagelist[1].replaceAll("&roleId", "");
        referalUserRoleId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");

        print(
            "userId{$referalUserId} roleId {$referalUserRoleId}  emaail {$email}");

        emailController =  TextEditingController(text: email);
        setState(() {
          //   prefs.setString(UserPreference.PATHURL, "");
          emailController;
        });
      }
      if (linkUrl.contains("referNow")) {
        // https://spikeview.com/referNow?userId=1830&roleId=1&email=sk1213@yopmail.com&pass=null
        List<String> mesagelist = linkUrl.split("=");

        referalUserId = mesagelist[1].replaceAll("&roleId", "");
        referalUserRoleId = mesagelist[2].replaceAll("&email", "");
        String email = mesagelist[3].replaceAll("&pass", "");

        print(
            "userId{$referalUserId} roleId {$referalUserRoleId}  emaail {$email}");

        emailController =  TextEditingController(text: email);
        setState(() {
          //   prefs.setString(UserPreference.PATHURL, "");
          emailController;
        });
      } else {
        if (email != null && email != "notdelete@gmail.com") {
          emailController =  TextEditingController(text: email);
          nameController =
               TextEditingController(text: name == null ? "" : name);

          setState(() {
            emailController;
            nameController;
          });
        }
      }
    }
    showJoinNowPopup(context);
    // personalInfo.deviceId = deviceID;
  }

  void _closeModal(void value) {
    print('modal closed');
  }

  Widget showJoinNowPopup(context) {
    setState(() {
      //   showSignupButton = false;
    });
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext bc) {
          return Container(
            color: Colors.white,
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
              left: 0, //11.0,
              right: 0, // 11.0,
            ),
            child: Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.only(left: 5.0, right: 5.0),
                child:  SingleChildScrollView(
                    child:  Column(
                  mainAxisSize: MainAxisSize.min,
                  //crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(top: 15.0, bottom: 15.0),
                      child:  Image.asset(
                        "assets/pre_login/grey_bar.png",
                        width: 58.0,
                        height: 4.0,
                      ),
                    ),
                     Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 10, bottom: 0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                             Expanded(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 0.0),
                                child:  InkWell(
                                  child:  SizedBox(
                                    height: 25.0,
                                    width: 25.0,
                                    child: PaddingWrap.paddingfromLTRB(
                                        4.0,
                                        0.0,
                                        0.0,
                                        3.0,Container(height: 20.0,
                                      width: 10.0,)
                                     ),
                                  ),
                                  onTap: () {
                                  //  Navigator.pop(context);
                                  //  Navigator.pop(context);
                                  },
                                ),
                              ),
                              flex: 0,
                            ),
                             Expanded(
                              child:  Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 5.0,
                                        right: 5.0,
                                        top: 2.0,
                                        bottom: 0),
                                    child:  Text(
                                      MessageConstant.PARTNER_CONNECTED_OUR_COMMUNITY,
                                      textAlign: TextAlign.center,
                                      style:  TextStyle(
                                          color:  Color(0xff000000),
                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 18.0,
                                          fontWeight: FontWeight.w700),
                                    ),
                                  ),
                                ],
                              ),
                              flex: 1,
                            ),
                             Expanded(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 5.0, 2.0, 0.0),
                                child:  InkWell(
                                  child:  SizedBox(
                                    height: 25.0,
                                    width: 25.0,
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         Center(
                                            child: Icon(
                                          Icons.clear,
                                          size: 25.0,
                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                        ))),
                                  ),
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                ),
                              ),
                              flex: 0,
                            ),
                          ],
                        ),
                      ),
                      flex: 0,
                    ),


                    Container(

                      child: Column(
                        children: <Widget>[
                          Points(
                            textString: MessageConstant.BRIEF_ABOUT_YOU,
                          ),
                          Points(
                            textString: MessageConstant.HOME_PAGE,
                          ),
                          Points(
                            textString: MessageConstant.CREATE_OPPORTUNITY,
                          ),
                          Points(
                            textString: MessageConstant.BUSINESS_OBJECTIVES,
                          ),

                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15.38,
                    ),
                     Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 10, bottom: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                             Expanded(
                              child: Row(
                                children: <Widget>[
                                   Text(MessageConstant.PARTNER_ALREADY_HAVE_ACCOUNT,
                                      style:  TextStyle(
                                          color:  Color(0xFF000000),
                                          fontSize: 14.0,
                                          fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                  SizedBox(
                                    width: 6,
                                  ),
                                   InkWell(
                                    child:  Text(MessageConstant.PARTNER_SIGNIN,
                                        style:  TextStyle(
                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: Constant.TYPE_CUSTOMBOLD)),
                                    onTap: () {

                                      if (widget.pageName == "Login") {
                                        Navigator.pop(context);
                                        Navigator.of(context).pop('SignIn');
                                      } else {
                                        Navigator.of(context).pop('SignIn');
                                      }
                                    },
                                  )
                                ],
                              ),
                              flex: 0,
                            ),
                          ],
                        ),
                      ),
                      flex: 0,
                    )
                  ],
                )),
              ),
            ),
          );
        }).then((value) => _closeModal(value));
  }

  @override
  void initState() {

    
    


    mediaImagesList.add(null);
    mediaVideosList.add(null);
    mediaDocumentList.add(null);
    uploadMedia = UploadMedia(context);
    if (widget.signupType == "apple" || widget.signupType == "google") {
      emailController.text = widget.email;
      if (widget.lastName != null && widget.lastName != "") {
        nameController.text = widget.firstName + " " + widget.lastName;
      }
    }
    setData(personalInfoObject);
    getSharedPreferences();
    callApiGetCategory();
    callApiForSaas();
    callApiOpporunityCategory();

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        Constant.CONTAINER_PARTNER +
        Constant.CONTAINER_MEDIA +
        "/";

    super.initState();
  }

  void setData(UserModel personalInfo) async {
    if (personalInfo != null) {
      setState(() {
        if (personalInfo.companyName != null)
          companyNameController.text = personalInfo.companyName;
        if (personalInfo.companyAddress != null)
          companyAddressController.text = personalInfo.companyAddress;
        if (personalInfo.companyPhoneNumber != null)
          phoneNumberController.text = personalInfo.companyPhoneNumber;
        if (personalInfo.webUrl != null)
          websiteController.text = personalInfo.webUrl;
        if (personalInfo.aboutCompany != null)
          aboutCompanyController.text = personalInfo.aboutCompany;

        internship = isSelected(personalInfo.offers, 1);
        advertise = isSelected(personalInfo.offers, 2);
        collageAdmission = isSelected(personalInfo.offers, 3);
      });

      List<AssetModel> assetsList = personalInfo.assets;
      if (assetsList != null) {
        for (int k = 0; k < assetsList.length; k++) {
          String type = assetsList[k].type;
          String tag = assetsList[k].tag;
          String file = assetsList[k].file;
          //  file= getMediumImage(file);

          if (type == "image") {
            mediaImagesList.add(file);
          } else if (type == "video") {
            final thumbnailFile = await uploadMedia
                .getVideoThumbnailFromUrl(Constant.IMAGE_PATH + file);

            mediaVideosList.add(new FileModel(thumbnailFile,
                strPrefixPathforPhoto + strAzureImageUploadPath));

            mediaVideosList;
          } else if (type == "doc") {
            mediaDocumentList.add(file);
          } else if (type == "google") {
            googleDoclinkList.add(file);
          }
        }
      }

      setState(() {
        if (personalInfo.assets != null && personalInfo.assets.length > 0) {
          isMediaExpanded = true;
          isMediaSelected = true;
          mediaImagesList;
          mediaVideosList;
          mediaDocumentList;
          googleDoclinkList;
        }
      });
    }
  }

  void checkInOfferArray(OfferModel offer, bool isChecked) {
    if (isChecked && !personalInfoObject.offers.contains(offer))
      personalInfoObject.offers.add(offer);
    else {
      //removeOfferFromList(offer);

      for (OfferModel offerModel in personalInfoObject.offers) {
        if (offerModel.offerId == offer.offerId) {
          personalInfoObject.offers.remove(offerModel);
          return;
        }
      }
    }
  }

  bool isSelected(List<OfferModel> offers, int id) {
    for (OfferModel offerModel in offers) {
      if (offerModel.offerId == id) return true;
    }
    return false;
  }

  void removeOfferFromList(OfferModel offer) {
    List<OfferModel> offers = personalInfoObject.offers;
    personalInfoObject.offers.clear();
    for (OfferModel offerModel in offers) {
      if (offer.offerId != offer.offerId) {
        personalInfoObject.offers.add(offerModel);
      }
    }
  }

  Future callApiGetCategory() async {
    print('inside callApiGetCategory() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCallWithouAuth(
            context, Constant.ENDPOINT_GET_BUSINESS_CATEGORY_API, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              BusinessCategoryResponse apiResponse =
                   BusinessCategoryResponse.fromJson(response.data);
              setState(() {
                businessCategoryList = apiResponse.result;

                if (businessCategoryList != null &&
                    businessCategoryList.isNotEmpty) {
                  orignalBusinessCategoryList.addAll(businessCategoryList);
                  businessCategoryList.insert(
                      0,
                      CategoryResult(
                          businessCategoryId: -1,
                          name: 'Select All',
                          description: 'Select All'));
                  //selectedCategory = businessCategoryList[0].name;
                  print(
                      'businessCategoryList[businessCategoryList.length - 1].businessCategoryId:: ${businessCategoryList[businessCategoryList.length - 1].businessCategoryId}');
                  //otherCategoryId = businessCategoryList[businessCategoryList.length - 1].businessCategoryId;

                }
              });

              print(
                  'Apurva businessCategoryList size::::: ${businessCategoryList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
      e.toString();
    }
  }

  List<Widget> getSelectedWidgets(List<String> selectedOption, String from) {
    List<Widget> widgets = [];
    for (String item in selectedOption) {
      print("Name+++++" + item);
      double width = item.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {

            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {

                return Container(
                  margin: EdgeInsets.all(5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (from == "mainCategory") {
                        if (businessCategoryList.length == 0) {
                          businessCategoryList.insert(
                              0,
                              CategoryResult(
                                  businessCategoryId: -1,
                                  name: 'Select All',
                                  description: 'Select All'));
                        }
                        if (item == 'Other') {
                          //setState(() {
                          isOtherSelected = false;
                          selectedOtherOption.clear();
                          isShowOtherMore = true;
                          //});
                        }
                        updateList(item);

                        setState(() {});
                      } else {
                        selectedOtherOption.remove(item);
                        selectedCategoryList.remove(item);
                        setState(() {});
                      }


                      showList = false;
                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,

                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item,
                          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  businessCategoryListWidget() {

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? businessCategoryList.length > 0
                ? Container(
                    height: businessCategoryList.length == 1
                        ? 50
                        : businessCategoryList.length == 2 ? 100 : 150.0,
                    child: Card(
                      child: Container(
                        padding: businessCategoryList.length > 0
                            ? EdgeInsets.all(10)
                            : EdgeInsets.all(0),
                        child: AnimatedList(
                          key: _listKey,
                          initialItemCount: businessCategoryList.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index, animation) {
                            animation = CurvedAnimation(
                                curve: Curves.linear, parent: animation);

                            return _buildAddedItem(
                                businessCategoryList[index], animation, index);
                          },
                        ),
                      ),
                    ))
                : Container(height: 0.0,)
            : Container(height: 0.0,),
      ],
    );
  }

  Widget _buildAddedItem(CategoryResult item, Animation animation, int index) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: animation,
        child: InkWell(
          onTap: () {
            //CustomProgressLoader.showLoader(context);
            print("item++++" + item.name);
            //displayPrediction(item.id, item.name, item.index);
            //_removeSingleItems(businessCategoryList.indexOf(item));

            if (businessCategoryList[index].name == 'Select All') {
              setState(() {
                isOtherSelected = true;
              });
              //getSelectedCategoryDetail(item.name);
              //selectedCategory = 'Select All';
              //selectedCategoryOption.clear();
              //removedBusinessCategoryList.clear();
              for (item in businessCategoryList) {
                if (item.name != 'Select All')
                  selectedCategoryOption.add(item.name);
                removedBusinessCategoryList.add(item);
              }
              businessCategoryList.clear();
            } else {
              if (businessCategoryList[index].name == 'Other') {
                setState(() {
                  isOtherSelected = true;
                });
              }
              //getSelectedCategoryDetail(item.name);
              removedBusinessCategoryList.add(businessCategoryList[index]);
              //selectedCategory = businessCategoryList[index].name;

              selectedCategoryOption.add(businessCategoryList[index].name);
              if (businessCategoryList.length > 0)
                businessCategoryList.removeAt(index);
            }

            showList = !showList;
            FocusScope.of(context).requestFocus(FocusNode());
            //searchCountryController.clear();
            setState(() {});
            setState(() {
              isBusinessCategoryError = false;
              bottomViewColor = Palette.dividerColor;
            });
          },
          child: AnimatedContainer(
            curve: Curves.easeIn,
            duration: Duration(milliseconds: 500),
            width: MediaQuery.of(context).size.width,
            child: Text(item.name,
                style: TextStyle(fontFamily: Constant.customRegular)),
            padding: EdgeInsets.all(8),
          ),
        ),
      ),
    );
  }

  selectOtherCategoryTextField() {
    String name = '';
    String help = '';
    if (selectedOtherOption.length == 0) {
      name = "Other Business Category";
      help = "Other Business Category";
    }
    setState(() {
      name;
      help;
    });
    return TextFormField(

      cursorColor: ColorValues.GREY_TEXT_COLOR,
      decoration: textFormFieldDecorationWithHintWithNewDesign(
          name, ImagePath.ICON_COMPANY, 23, 23, help),
      controller: categoryController,
      onChanged: (value) {},
      textInputAction: TextInputAction.next,
      focusNode: _otherCategoryFocus,
      style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
      autocorrect: false,
      onFieldSubmitted: (term) {
        _otherCategoryFocus.unfocus();
        if (categoryController.text != null && categoryController.text != "") {
          if (!selectedOtherOption.contains(categoryController.text)) {
            selectedOtherOption.add(categoryController.text);
          }
        }
        //getSelectedCategoryDetail('Other');
        //selectedCategoryList.add(new CategoryModel(categoryController.text,otherCategoryId, true));
        categoryController.clear();
      },
      validator: (String arg) {
        if (selectedOtherOption.length > 0) {
          return null;
        } else {
          return MessageConstant.ENTER_OTHER_BUSINESS_CATE_VAL;
        }
      },
    );
  }

  void getSelectedCategoryDetail() {
    print('getSelectedCategoryDetail() ');
    selectedCategoryList.clear();
    for (var selectedItem in selectedCategoryOption) {
      print(
          'getSelectedCategoryDetail() inside loop businessCategoryList size:: ${businessCategoryList.length}');
      //if(selectedCatOption == item.name){
      for (var item in orignalBusinessCategoryList) {
        if (item.name == selectedItem) {
          //CategoryResult categoryResult = ;
          if (selectedItem != 'Other') {
            CategoryModel categoryModel =  CategoryModel(
                name: item.name,
                businessCategoryId: item.businessCategoryId,
                isOther: false);
            selectedCategoryList.add(categoryModel);
          } else {
            for (var option in selectedOtherOption) {
              CategoryModel categoryModel =  CategoryModel(
                  name: option,
                  businessCategoryId: item.businessCategoryId,
                  isOther: true);
              selectedCategoryList.add(categoryModel);
            }
          }
        }
      }

      //}
    }
    print(
        'inside getSelectedCategoryDetail() selectedCategoryList size:: ${selectedCategoryList.length}');
  }

  void updateList(String item) {
    print('inside updateList');
    for (var removeitem in removedBusinessCategoryList) {
      print('inside updateList removeitem name:: ${removeitem.name}');
      if (item == removeitem.name) {

        setState(() {

          businessCategoryList.add(removeitem);
          removedBusinessCategoryList.remove(removeitem);
          selectedCategoryOption.remove(item);
        });
      }
    }
    setState(() {});
  }

  Future callApiOpporunityCategory() async {
    print('inside callApiOpporunityCategory() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling2().apiCallWithouAuth(
            context, Constant.ENDPOINT_OPPORTUNITY_CATEGORY, "get");

        print(
            'Apurva callApiOpporunityCategory() Response:::: ${response.toString()}');

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              OpportunityCategoriesModel apiResponse =
                   OpportunityCategoriesModel.fromJson(response.data);
              setState(() {
                opportunityCategoryList = apiResponse.result;
              });
              setOfferList();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
      e.toString();
    }
  }

  void setOfferList() {
    if (personalInfoObject.offers.length == 0) {
      setState(() {


        for (var item in opportunityCategoryList) {
          //personalInfoObject.offers.add(OfferModel(offerId: item.oppCategoryId, name: item.name, isSelected: true));
          personalInfoObject.offers
              .add(OfferModel(offerId: item.oppCategoryId, name: item.name));
        }


        internship = !internship;
        advertise = !advertise;
        // collageAdmission = !collageAdmission;
      });
    }
  }

  void generateChipsForOther() {
    if (categoryController.text != null && categoryController.text != "") {
      if (!selectedOtherOption.contains(categoryController.text)) {
        selectedOtherOption.add(categoryController.text);
      }
    }
    categoryController.clear();
    setState(() {});
  }

  Future callApiToValidateTheaReferalCode(String from) async {
    print('inside callApiToValidateTheaReferalCode() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'URL Referal:: ${Constant.ENDPOINT_VALIDATE_REFERAL_CODE_API + referalController.text.trim()}');

        Response response = await  ApiCalling().apiCallWithouAuth(
            context,
            Constant.ENDPOINT_VALIDATE_REFERAL_CODE_API +
                referalController.text.trim(),
            "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String message = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              ReferalCodeResponse apiResponse =
                   ReferalCodeResponse.fromJson(response.data);
              referalCodeResponse = apiResponse; //apiResponse.result;
              print(
                  'Apurva ReferalCodeResponse::::: ${referalCodeResponse.message.toString()}');
              Navigator.of(context).pop();
              if (from == 'continue') {
                registerUser(personalInfoObject);
              } else {

                ToastWrap.showToastGreen(message, context);
              }
            } else {
              if (from == 'continue')
                CustomProgressLoader.cancelLoader(context);
              //ToastWrap.showToast(MessageConstant.INVALID_REFERRAL_CODE, context);
              ToastWrap.showToast(message, context);
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"partnerSignup",context);
      e.toString();
    }
  }

  void registerUser(UserModel personalInfoObject) async {
    mediaImagesList.removeAt(0);
    mediaDocumentList.removeAt(0);
    mediaVideosList.removeAt(0);
    for (var file in mediaImagesList) {
      assetModelMap.add(AssetModel(
        file: file,
        tag: 'media',
        type: "image",
      ));
    }

    for (var file in mediaDocumentList) {
      assetModelMap.add(AssetModel(
        file: file,
        tag: 'media',
        type: "doc",
      ));
    }

    for (var file in mediaVideosList) {
      assetModelMap.add(AssetModel(
        file: file.path,
        tag: 'media',
        type: "video",
      ));
    }

    for (var file in googleDoclinkList) {
      assetModelMap.add(AssetModel(
        file: file,
        tag: 'media',
        type: "google",
      ));
    }

    if (widget.pageName == "dashBoard") {
      if (widget.isValid) {
        apiCalling();
      } else {
        mediaImagesList.insert(0, null);
        mediaDocumentList.insert(0, null);
        mediaVideosList.insert(0, null);
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToastLong(MessageConstant.PRIVATE_EMAIL_MSG, context);
      }
    } else {
      if (widget.isValid) {
        apiCallingPersonal();
      } else {
        mediaImagesList.insert(0, null);
        mediaDocumentList.insert(0, null);
        mediaVideosList.insert(0, null);

        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToastLong(MessageConstant.PRIVATE_EMAIL_MSG, context);
      }
    }

    // API.registerUser();
    // Navigator.pushNamed(context, Screen.Service.toString());
  }
}
