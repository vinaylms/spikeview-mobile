import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/home/home.dart';

class MyIntroWidget extends StatelessWidget {
  final bool isVideoPlaying;
  final VoidCallback onAddEditVideoTap;
  final VoidCallback onPlayTap;
  final String videoUrl;
  final String videoThumbnailUrl;

  const MyIntroWidget({
    @required this.onAddEditVideoTap,
    this.isVideoPlaying,
    this.videoThumbnailUrl,
    this.videoUrl,
    this.onPlayTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: BaseText(
                text: "My introduction",
                textColor: const Color(0xff27275A),
                fontFamily: Constant.latoRegular,
                fontWeight: FontWeight.w600,
                fontSize: 18,
              ),
            ),
            const SizedBox(width: 12),
            Visibility(
              visible: videoUrl?.isNotEmpty ?? false,
              child: InkWell(
                onTap: onAddEditVideoTap,
                child: Image.asset(
                  "assets/profile/skills/ic_edit_blue.png",
                  height: 18,
                  width: 18,
                ),
              ),
            )
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          ),
          clipBehavior: Clip.antiAlias,
          width: double.maxFinite,
          height: 200,
          child: videoUrl?.isNotEmpty ?? false
              ? isVideoPlaying ?? false
                  ? VideoPlayPause(
                      videoUrl,
                      "",
                      true,
                      pageName: "profile",
                    )
                  : Container(
                      color: Colors.black,
                      child: Stack(
                        children: [
                          videoThumbnailUrl?.isNotEmpty ?? false
                          ?CachedNetworkImage(
                            height: 200,
                            width: double.infinity,
                            imageUrl: videoThumbnailUrl
                                        .toLowerCase()
                                        .contains("http") ||
                                    videoThumbnailUrl
                                        .toLowerCase()
                                        .contains("www.")
                                ? videoThumbnailUrl
                                : "${Constant.IMAGE_PATH}$videoThumbnailUrl",
                            fit: BoxFit.contain,
                            placeholder: (context, url) =>
                                Util.loader(context, ""),
                            errorWidget: (context, url, error) =>
                                Util.error(""),
                          )
                          :const SizedBox.shrink(),
                          Center(
                            child: InkWell(
                              onTap: onPlayTap,
                              child: Image.asset(
                                'assets/ic_intro_play.png',
                                height: 40,
                                width: 40,
                              ),
                            ),
                          )
                        ],
                      ),
                    )
              : Stack(
                  children: [
                    Image.asset(
                      'assets/intro_default_img.png',
                      width: double.maxFinite,
                      height: 230,
                      fit: BoxFit.fill,
                    ),
                    Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          BaseText(
                            text: AppConstants
                                .stringConstant.addYourIntroductionVideo,
                            textColor: const Color(0xff27275A),
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            fontFamily: Constant.latoRegular,
                          ),
                          const SizedBox(height: 12),
                          InkWell(
                            onTap: onAddEditVideoTap,
                            child: Container(
                              decoration: BoxDecoration(
                                color:
                                    AppConstants.colorStyle.lightBlueAddVideo,
                                borderRadius: BorderRadius.all(
                                  Radius.circular(8),
                                ),
                              ),
                              padding: const EdgeInsets.fromLTRB(10, 5, 10, 5),
                              child: BaseText(
                                text: "Add video",
                                textColor: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'NunitoRegular',
                              ),
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
        )
      ],
    );
  }
}
