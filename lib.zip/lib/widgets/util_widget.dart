import 'dart:io';

import 'package:device_info/device_info.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'package:intl/intl.dart';

enum DateType { start, end }

class UtilWidget {
  /*void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    if (args.value.startDate != null && args.value.endDate != null) {
      tempDateRange = DateTimeRange(
        start: args.value.startDate,
        end: args.value.endDate ?? DateTime.now(),
      );
    }
  }*/

  /*showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) {
          return AlertDialog(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            clipBehavior: Clip.antiAlias,
            titlePadding: EdgeInsets.zero,
            insetPadding: const EdgeInsets.symmetric(horizontal: 20),
            content: SizedBox(
              height: 280,
              width: double.maxFinite,
              child: SfDateRangePicker(
                onSelectionChanged: _onSelectionChanged,
                selectionMode: DateRangePickerSelectionMode.range,
                maxDate: DateTime(DateTime.now().year + 5),
                minDate: DateTime(1970),
                initialDisplayDate: DateTime.now(),
                backgroundColor: Colors.white,
                allowViewNavigation: true,
                selectionShape: DateRangePickerSelectionShape.rectangle,
                selectionRadius: 12,
                startRangeSelectionColor: const Color(0xFF4684EB),
                endRangeSelectionColor: const Color(0xFF4684EB),
                headerStyle: DateRangePickerHeaderStyle(
                  textStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                ),
                viewSpacing: 6,
                //todayHighlightColor: Colors.white,
                monthCellStyle: DateRangePickerMonthCellStyle(
                  textStyle: TextStyle(
                    color: Colors.black.withOpacity(0.7),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                  todayTextStyle: TextStyle(
                    color: const Color(0xFF4684EB),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                  // todayCellDecoration: BoxDecoration(
                  //   color: const Color(0xff007AFF),
                  //   borderRadius: BorderRadius.circular(10)
                  // )
                ),
                monthViewSettings: DateRangePickerMonthViewSettings(
                  viewHeaderStyle: DateRangePickerViewHeaderStyle(
                    textStyle: TextStyle(
                      color: Color.fromRGBO(60, 60, 67, 0.30),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                    ),
                  ),
                ),
                selectionTextStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  fontFamily: AppConstants.stringConstant.latoRegular,
                ),
                rangeTextStyle: TextStyle(
                  color: Colors.black.withOpacity(0.7),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  fontFamily: AppConstants.stringConstant.latoRegular,
                ),
                initialSelectedRange: selectedDateTimeRange != null
                    ? PickerDateRange(
                        selectedDateTimeRange?.start ??
                            DateTime.now().subtract(const Duration(days: 4)),
                        selectedDateTimeRange?.end ?? DateTime.now())
                    : null,
              ),
            ),
            actionsPadding: const EdgeInsets.symmetric(horizontal: 20),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _checkAccomplishmentsValidation();
                },
                style: TextButton.styleFrom(
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  MessageConstant.CANCEL,
                  style: TextStyle(
                    fontFamily: Constant.customRegular,
                    fontSize: 16,
                    color: ColorValues.GREY_TEXT_COLOR,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  dateNode.unfocus();
                  if (tempDateRange != null) {
                    selectedDateTimeRange = tempDateRange;
                    dateCtrl.text =
                        '${Util.getDate(selectedDateTimeRange.start)} - ${Util.getDate(selectedDateTimeRange.end)}';
                  }
                  dateNode.unfocus();
                  _checkAccomplishmentsValidation();
                },
                style: TextButton.styleFrom(
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  'Apply',
                  style: TextStyle(
                    fontFamily: Constant.customRegular,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: const Color(0xFF4684EB),
                  ),
                ),
              ),
            ],
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          );
        });
    */

  /* showDateRangePicker(
      context: context,
      firstDate: DateTime(1970),
      lastDate: DateTime.now(),
      cancelText: 'Cancel',
      confirmText: 'Apply',
      helpText: 'Please select start and end date',
      initialEntryMode: DatePickerEntryMode.input,
      builder: ( context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: const Color(0xFFF48808),
            accentColor: const Color(0xFFF48808),
            colorScheme: ColorScheme.light(primary: const Color(0xFFF48808)),
            buttonTheme: ButtonThemeData(
                textTheme: ButtonTextTheme.primary
            ),
          ),
          child: child,
        );
      },
    );*/

  static void startEndDatePickerDialog({
    @required BuildContext context,
    @required Function(DateTime date) onConfirm,
    DateTime selectedDate,
    DateTime minDate,
    DateTime maxDate,
  }) {
    DateTime tempDate = selectedDate ?? DateTime.now();
    if (minDate != null) {
      if (DateFormat('yyyy-MM-dd').format(minDate) ==
          DateFormat('yyyy-MM-dd').format(DateTime.now())) {
         minDate = DateTime.now();

        // minDate = DateTime.now().subtract(Duration(days: 1));
      }
    }

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) {
          return AlertDialog(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            clipBehavior: Clip.antiAlias,
            titlePadding: EdgeInsets.zero,
            insetPadding: const EdgeInsets.symmetric(horizontal: 20),
            content: SizedBox(
              height: 280,
              width: double.maxFinite,
              child: SfDateRangePicker(
                onSelectionChanged: (DateRangePickerSelectionChangedArgs args) {
                  print('------ args.value ${args.value} ');
                  if (args.value is DateTime) {
                    //_selectedDate = args.value;
                    tempDate = args.value;
                  }
                  /*if (args.value.startDate != null && args.value.endDate != null) {
                    tempDateRange = DateTimeRange(
                      start: args.value.startDate,
                      end: args.value.endDate ?? DateTime.now(),
                    );
                  }*/
                },
                selectionMode: DateRangePickerSelectionMode.single,
                maxDate: maxDate ?? DateTime.now(),
                minDate: minDate ?? DateTime(1970),
                initialDisplayDate: DateTime.now(),
                backgroundColor: Colors.white,
                allowViewNavigation: true,
                selectionShape: DateRangePickerSelectionShape.rectangle,
                selectionRadius: 12,
                startRangeSelectionColor: const Color(0xFF4684EB),
                endRangeSelectionColor: const Color(0xFF4684EB),
                headerStyle: DateRangePickerHeaderStyle(
                  textStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                    fontFamily: Constant.latoRegular,
                  ),
                ),
                viewSpacing: 6,
                //todayHighlightColor: Colors.white,
                monthCellStyle: DateRangePickerMonthCellStyle(
                  textStyle: TextStyle(
                    color: Colors.black.withOpacity(0.7),
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    fontFamily: Constant.latoRegular,
                  ),
                  todayTextStyle: TextStyle(
                    color: const Color(0xFF4684EB),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontFamily: Constant.latoRegular,
                  ),
                  // todayCellDecoration: BoxDecoration(
                  //   color: const Color(0xff007AFF),
                  //   borderRadius: BorderRadius.circular(10)
                  // )
                ),
                monthViewSettings: DateRangePickerMonthViewSettings(
                  viewHeaderStyle: DateRangePickerViewHeaderStyle(
                    textStyle: TextStyle(
                      color: Color.fromRGBO(60, 60, 67, 0.30),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      fontFamily: Constant.latoRegular,
                    ),
                  ),
                ),
                selectionTextStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  fontFamily: Constant.latoRegular,
                ),
                rangeTextStyle: TextStyle(
                  color: Colors.black.withOpacity(0.7),
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  fontFamily: Constant.latoRegular,
                ),
                initialSelectedDate: selectedDate ?? DateTime.now(),
              ),
            ),
            actionsPadding: const EdgeInsets.symmetric(horizontal: 20),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                style: TextButton.styleFrom(
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  MessageConstant.CANCEL,
                  style: TextStyle(
                    fontFamily: Constant.customRegular,
                    fontSize: 16,
                    color: ColorValues.GREY_TEXT_COLOR,
                  ),
                ),
              ),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  onConfirm(tempDate);
                },
                style: TextButton.styleFrom(
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
                child: Text(
                  'Apply',
                  style: TextStyle(
                    fontFamily: Constant.customRegular,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: const Color(0xFF4684EB),
                  ),
                ),
              ),
            ],
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          );
        });
  }

  static void startEndDatePickerDialog2({
    @required BuildContext context,
    @required Function(DateTime date) onConfirm,
    DateTime selectedDate,
    DateTime minDate,
    DateTime maxDate,
  }) {
    if (minDate != null) {
      if (DateFormat('yyyy-MM-dd').format(minDate) ==
          DateFormat('yyyy-MM-dd').format(DateTime.now())) {
        minDate = DateTime.now();
      }
    }

    showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: minDate ?? DateTime(1900),
      lastDate: maxDate ?? DateTime.now(),
      confirmText: 'Apply',
      cancelText: 'Cancel',
    ).then((value) {
      if (value != null) {
        onConfirm(value);
      }
    });
  }

  static String stringCheck({@required String string, String defaultValue}) {
    return string != null && string != 'null' && string != ''
        ? string
        : defaultValue ?? '';
  }

  static Future<bool> checkAndroid13Permission() async {
    if (Platform.isAndroid) {
      /*DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      if (androidInfo.version.sdkInt >= 33) {
        final isPhotosPermission = await Permission.storage.status.isGranted;
        if (!isPhotosPermission) {
          final status = await Permission.storage.request();
          if (status.isGranted || status.isLimited) {
            return true;
          } else {
            return false;
          }
        }else {
          return false;
        }
      } else {
        return true;
      }*/
      return await getStoragePermission();
    } else {
      return true;
    }
  }

  static Future<bool> getStoragePermission() async {
    DeviceInfoPlugin plugin = DeviceInfoPlugin();
    AndroidDeviceInfo android = await plugin.androidInfo;
    if (android.version.sdkInt >= 33) {
      if (await Permission.photos.request().isGranted) {
        return true;
      } else {
        await openAppSettings();
        return false;
      }
    } else {
      if (await Permission.photos.request().isGranted) {
        return true;
      } else {
        await openAppSettings();
        return false;
      }
    }
  }

  static Future<bool> checkPermission(Permission permission) async {
    final status = await permission.status;
    if (status.isLimited || status.isGranted) {
      return true;
    } else {
      final requestResult = await permission.request();
      if (requestResult.isLimited || requestResult.isGranted) {
        return true;
      } else {
        openAppSettings();
        return false;
      }
    }
  }

  static bool isNumeric(String string) {
    final numericRegex = RegExp(r'^-?(([0-9]*)|(([0-9]*)\.([0-9]*)))$');

    return numericRegex.hasMatch(string);
  }

  static String timeAgo(DateTime date) {
    if (date != null) {
      DateTime currentDate = DateTime.now();
      var different = currentDate.difference(date);
      if (different.inDays > 7) {
        if ((different.inDays / 7).floor() > 1) {
          return DateFormat('MMM dd, yyyy').format(date);
        } else {
          return "${((different.inDays / 7).floor()).toString().padLeft(2, "0")} ${(different.inDays / 7).floor() == 1 ? "week" : "weeks"}";
        }
      } else if (different.inDays > 0) {
        return "${(different.inDays).toString().padLeft(2, "0")} ${different.inDays == 1 ? "day" : "days"}";
      } else if (different.inHours > 0) {
        return "${(different.inHours).toString().padLeft(2, "0")} ${different.inHours == 1 ? "hour" : "hours"}";
      } else if (different.inMinutes > 0) {
        return "${(different.inMinutes).toString().padLeft(2, "0")} ${different.inMinutes == 1 ? "min" : "mins"}";
      } else if (different.inMinutes == 0) {
        return 'Just now';
      } else {
        return DateFormat('MMM dd, yyyy').format(date);
      }
    }
    return '';
  }

  static String chatTime(int chatTime) {
    if (chatTime != null && chatTime > 0) {
      final chatDate = DateTime.fromMillisecondsSinceEpoch(chatTime);
      DateTime currentDate = DateTime.now();
      // var different = currentDate.difference(chatDate);
      if (DateFormat('MMM dd, yyyy').format(chatDate) == DateFormat('MMM dd, yyyy').format(currentDate)) {
        return DateFormat('hh:mm a').format(chatDate);
      } else {
        return DateFormat('MMM dd, yyyy').format(chatDate);
      }
    }
    return DateFormat('hh:mm a').format(DateTime.now());
  }
}
