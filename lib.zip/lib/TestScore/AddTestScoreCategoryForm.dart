import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/list_image_view.dart';

// Create a Form Widget
class AddTestScoreCategoryForm extends StatefulWidget {
  ProfileData profileInfoModal;
  List<SebjectDetailModel> subjectModel;
  String testName = '';
  int testId;
  int subjectSelectedPosition;
  TestScoreModel testScoreModel;

  AddTestScoreCategoryForm(
      this.profileInfoModal,
      this.subjectModel,
      this.testName,
      this.testId,
      this.testScoreModel,
      this.subjectSelectedPosition);

  @override
  AddTestScoreCategoryFormState createState() {
    return AddTestScoreCategoryFormState();
  }
}

class AddTestScoreCategoryFormState extends State<AddTestScoreCategoryForm> {
  ScrollController _controller = ScrollController();
  String isPerformChanges = "pop";
  String userIdPref;
  SharedPreferences prefs;
  bool isValid = true;
  bool isTestSelected = false;
  File mediaImage;
  String dob, strDate;
  TextEditingController dobController;
  int strDateOfBirth = 0;
  DateTime pickedDate;
  String previousTestScorePosition = "", previousSubjectPosition = "";
  File imagePath;
  UploadMedia uploadMedia;
  List<String> mediaDocumentList = List();
  List<String> mediaList = List();
  List<String> mediaImagesList = List();
  String sasToken, containerName, strPrefixPathforPhoto;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  final formKey = GlobalKey<FormState>();
  DateTime startDate;
  Map<int, String> dataValue = {};

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    dob = widget.profileInfoModal.dob;

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    callApiForSaas();
  }

  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_APP_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();
    super.initState();
  }

  Future apiCalling(addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        //mediaDocumentList.removeAt(0);
        //      mediaImagesList.removeAt(0);
        //    mediaList.addAll(mediaImagesList);
        //  mediaList.addAll(mediaDocumentList);
        List<ScoreModel> scoreList = List();
        dataValue.forEach((k, v) {
          if (v == null || v == "null") {
            v = "";
          }
          scoreList.add(new ScoreModel(v, k));
        });

        Map map = {
          "testId": widget.testId,
          "userId": userIdPref,
          "dateTaken": strDateOfBirth,
          "docUrl": mediaDocumentList.map((item) => item).toList(),
          "imageUrl": mediaImagesList.map((item) => item).toList(),
          "score": scoreList.map((item) => item.toJson()).toList(),
          "addIntoProfile": addIntoProfile
        };

        print("map+++" + map.toString());
        response = await ApiCalling2().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_TEST_SCORE_DATA, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              isPerformChanges = "push";
              bloc.fetcprofileData(userIdPref, context, prefs, true);

              Navigator.pop(context, true);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        mediaDocumentList.add("");
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      mediaDocumentList.add("");
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result =
          await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  void checkMediaAndUpload({
    @required String imagePath,
    @required String type,
  }) async {
    setState(() {});

    String strAzureImageUploadPath = await uploadImgOnAzure(
        imagePath
            .toString()
            .replaceAll("File: ", "")
            .replaceAll("'", "")
            .trim(),
        strPrefixPathforPhoto);

    CustomProgressLoader.cancelLoader(context);
    if (strAzureImageUploadPath != null ||
        strAzureImageUploadPath != "false") {
      String path = strPrefixPathforPhoto + strAzureImageUploadPath;
      if (type == "doc") {
        mediaDocumentList.add(path);
        setState(() {
          mediaDocumentList;
        });
      } else {
        mediaImagesList.add(path);
        setState(() {
          mediaImagesList;
        });
      }

      //assetModelMap.add(model);
    } else {
      //  showToastMessage('Upload failed. Please try again.');
    }
  }

  getDocuments() async {
    try {
      // Platform messages may fail, so we use a try/catch PlatformException.
      try {
        FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
          allowedFileExtensions: ['pdf'],
          allowedMimeTypes: ['application/pdf'],
          invalidFileNameSymbols: ['/'],
        );

        String path =
        await FlutterDocumentPicker.openDocument(params: params);
        if (path != null && path != "") {
          if ((Util.getFileExtension(path) == ".pdf") && path != null) {
            print("path+++++" + path.toString());

            CustomProgressLoader.showLoader(context);
            Timer _timer = Timer(const Duration(milliseconds: 400), () {
              checkMediaAndUpload(
                  imagePath: path
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  type: "doc");
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.INVALID_FILE_FORMAT_VAL, context);
          }
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    } catch (e) {
      ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
    }
  }

  onTapImageAddButton() async {
    mediaImage = await UploadMedia(context).pickImageFromGallery();
    //   mediaImage = await ImagePicker.pickImage(source: ImageSource.gallery);
    if (mediaImage != null) {
      imagePath = mediaImage;
      //await _cropImage(mediaImage);
      if (imagePath != null) {
        CustomProgressLoader.showLoader(context);
        Timer(const Duration(milliseconds: 400), () {
          checkMediaAndUpload(
              imagePath: imagePath
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim(),
              type: "image");
        });
      }
    }
  }

  void _checkValidation() async {
    final form = formKey.currentState;
    form.save();

    if (form.validate()) {
      if (strDateOfBirth != 0) {
        isValid = true;

        if (Util.dobCheck(widget.profileInfoModal.dob) &&
            widget.profileInfoModal.publicUrl != null &&
            widget.profileInfoModal.publicUrl != "null" &&
            widget.profileInfoModal.publicUrl != "") {
          // conformationDialogForCommunityPost(model);
        } else {
          apiCalling(false);
        }
      } else {
        isValid = false;
      }
    } else {
      if (strDateOfBirth == 0) {
        isValid = false;
      }
    }
    setState(() {});
  }

  void takeNumber(String text, int name) {
    try {
      //  int number = int.parse(text);
      dataValue[name] = text;
      print(dataValue);
    } on FormatException {}
  }

  validateMethod(SebjectDetailModel model, value) {
    if (value == '') {
      return "Please enter value between " +
          model.minScore.toString() +
          "-" +
          model.maxScore.toString();
    } else if (value >= model.minScore && value <= model.maxScore) {
      return null;
    }

    return "Please enter value between " +
        model.minScore.toString() +
        "-" +
        model.maxScore.toString();
  }

  Padding gridSelectedImagesVideos() {
    return mediaImagesList != null && mediaImagesList.length > 0
        ? PaddingWrap.paddingfromLTRB(
        15.0,
        0.0,
        15.0,
        0.0,
        Container(
            height: 80.0,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children:
              List.generate(mediaImagesList.length, (int index) {
                return Padding(
                  padding: EdgeInsets.only(left: index == 0 ? 0 : 13.0),
                  child: Stack(
                    children: [
                      Container(
                        width: 123,
                        height: 67,
                        margin: EdgeInsets.only(right: 0),
                        child: FadeInImage.assetNetwork(
                          fit: BoxFit.cover,
                          placeholder: 'assets/aerial/default_img.png',
                          image: Constant.IMAGE_PATH +
                              mediaImagesList[index],
                        ),
                      ),
                      Positioned(
                        top: 20,
                        right: 50,
                        child: InkWell(
                          onTap: () {
                            mediaImagesList.removeAt(index);
                            setState(() {});
                          },
                          child: Image.asset(
                            "assets/generateScript/cross_close.png",
                            height: 25.0,
                            width: 25.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            )))
        : PaddingWrap.paddingfromLTRB(
        5.0,
        0.0,
        5.0,
        0.0,
        Container(
          height: 0.0,
        ));
  }

  void _showRemoveDialog(int index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Are you sure you want to remove this?',
          onPositiveTap: () {
            mediaImagesList.removeAt(index);
            setState(() {});
          },
        );
      },
    );
  }

  Padding gridSelectedDocument() {
    return mediaDocumentList != null && mediaDocumentList.length > 0
        ? PaddingWrap.paddingfromLTRB(
        15.0,
        0.0,
        15.0,
        0.0,
        Container(
            height: 80.0,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.zero,
              children:
              List.generate(mediaDocumentList.length, (int index) {
                return Container(
                  margin: EdgeInsets.only(left: index == 0 ? 0 : 13.0),
                  decoration: BoxDecoration(
                      color: AppConstants.colorStyle.lightPurple,
                      border: Border.all(
                          color:
                          ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  width: 123,
                  height: 67,
                  padding: const EdgeInsets.all(8.0),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Image.asset(
                        "assets/newDesignIcon/patner/pdf.png",
                        height: 67,
                      ),
                      InkWell(
                        onTap: () {
                          mediaDocumentList.removeAt(index);
                          setState(() {});
                        },
                        child: Image.asset(
                          "assets/generateScript/cross_close.png",
                          height: 25.0,
                          width: 25.0,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            )))
        : PaddingWrap.paddingfromLTRB(
        5.0,
        0.0,
        5.0,
        0.0,
        Container(
          height: 0.0,
        ));
  }

  mediaSection() {
    return Column(
      children: [
        SizedBox(
          width: double.maxFinite,
          height: 120,
          child: InkWell(
            onTap: () =>  onTapImageAddButton(),
            child: Stack(
              alignment: Alignment.center,
              overflow: Overflow.visible,
              children: [
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  bottom: 14,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: mediaImagesList.isNotEmpty
                        ? SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: List.generate(
                          mediaImagesList.length,
                              (index) {
                                final item = mediaImagesList[index];
                                return ListImageView(
                                  imageUrl: Constant.IMAGE_PATH + item.replaceAll(Constant.IMAGE_PATH , ''),
                                  onRemoveTap: () {
                                    _showRemoveDialog(index);
                                  },
                                );
                              },
                        ),
                      ),
                    )
                        : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(height: 18),
                        Image.asset(
                          "assets/recommendation/ic_camera.png",
                          height: 26,
                          width: 25,
                        ),
                        const SizedBox(height: 5),
                        Text(
                          'Your uploaded photos will appear here',
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          style: AppConstants.txtStyle
                              .heading14400LatoItalicLightPurple,
                        ),
                      ],
                    ),
                    decoration: BoxDecoration(
                      color: AppConstants.colorStyle.tabBg,
                      border: Border.all(
                        color: AppConstants.colorStyle.borderGenerateScript,
                      ),
                      borderRadius: const BorderRadius.all(
                        Radius.circular(7),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  child: Image.asset(
                    "assets/generateScript/plus_icon.png",
                    height: 28,
                    width: 28,
                  ),
                ),
              ],
            ),
          ),
        ),
        /*InkWell(
          onTap: () async {

            onTapImageAddButton();

            *//*  var status = await Permission.photos.status;
              if (status.isGranted) {
                onTapImageAddButton();
              } else {
                checkPermissionPhoto(context);
              }*//*
          },
          child: Stack(
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 96,
                    child: Column(
                      children: [
                        const SizedBox(height: 18),
                        mediaImagesList.length == 0
                            ? Image.asset(
                          "assets/generateScript/camera.png",
                          height: 26.0,
                          width: 25.0,
                        )
                            : SizedBox(),
                        const SizedBox(height: 5),
                        Text(
                          mediaImagesList.length == 0
                              ? 'Your uploaded photos will appear here'
                              : "",
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          style: AppConstants
                              .txtStyle.heading14400LatoItalicLightPurple,
                        ),
                      ],
                    ),
                    decoration: BoxDecoration(
                      color: AppConstants.colorStyle.tabBg,
                      border: Border.all(
                          color:
                          AppConstants.colorStyle.borderGenerateScript),
                      borderRadius:
                      const BorderRadius.all(Radius.circular(10)),
                    ),
                  ),
                  SizedBox(
                    height: 12,
                  )
                ],
              ),
              gridSelectedImagesVideos(),
              Positioned(
                bottom: 0,
                child: InkWell(
                  radius: 50,
                  onTap: () async {
                    onTapImageAddButton();

                    *//*  var status = await Permission.photos.status;
                      if (status.isGranted) {
                        onTapImageAddButton();
                      } else {
                        checkPermissionPhoto(context);
                      }*//*
                  },
                  child: Image.asset(
                    "assets/generateScript/plus_icon.png",
                    height: 26.0,
                    width: 25.0,
                  ),
                ),
              ),
            ],
          ),
        ),*/
      ],
    );
  }

  Widget docSection() {
   return SizedBox(
      width: double.maxFinite,
      height: 120,
      child: InkWell(
        onTap: () {
          if (mediaDocumentList.length <= 5) {
            getDocuments();
          } else {
            ToastWrap.showToast(
                MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
          }
        },
        child: Stack(
          alignment: Alignment.center,
          overflow: Overflow.visible,
          children: [
            Positioned(
              left: 0,
              right: 0,
              top: 0,
              bottom: 14,
              child: Container(
                width: MediaQuery
                    .of(context)
                    .size
                    .width,
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 14),
                child: mediaDocumentList.isNotEmpty
                    ? SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: List.generate(
                      mediaDocumentList.length,
                          (index) =>
                              Container(
                                margin: EdgeInsets.only(left: index == 0 ? 0 : 13.0),
                                decoration: BoxDecoration(
                                    color: AppConstants.colorStyle.lightPurple,
                                    border: Border.all(
                                        color:
                                        ColorValues.LIGHT_GREY_TEXT_COLOR)),
                                width: 123,
                                height: 70,
                                padding: const EdgeInsets.all(8.0),
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Image.asset(
                                      "assets/newDesignIcon/patner/pdf.png",
                                      height: 70,
                                    ),
                                    InkWell(
                                      onTap: () {
                                        mediaDocumentList.removeAt(index);
                                        setState(() {});
                                      },
                                      child: Image.asset(
                                        "assets/generateScript/cross_close.png",
                                        height: 25.0,
                                        width: 25.0,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                    ),
                  ),
                )
                    : Center(
                      child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                      Image.asset(
                        "assets/generateScript/pdf.png",
                        height: 26.0,
                        width: 25.0,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Your uploaded documents (PDF only) will appear here',
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        style: AppConstants.txtStyle
                            .heading14400LatoItalicLightPurple,
                      ),
                  ],
                ),
                    ),
                decoration: BoxDecoration(
                  color: AppConstants.colorStyle.tabBg,
                  border: Border.all(
                    color: AppConstants.colorStyle.borderGenerateScript,
                  ),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(7),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: Image.asset(
                "assets/generateScript/plus_icon.png",
                height: 28,
                width: 28,
              ),
            ),
          ],
        ),
      ),
    );
    /*return Column(
      children: [
        InkWell(
          onTap: () async {
            if (mediaDocumentList.length <= 5) {
              getDocuments();
            } else {
              ToastWrap.showToast(
                  MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
            }
          },
          child: Stack(
            alignment: Alignment.center,
            overflow: Overflow.visible,
            children: [
              Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: mediaDocumentList.length == 0 ? 100 : 96,
                    child: Column(
                      children: [
                        const SizedBox(height: 18),
                        mediaDocumentList.length == 0
                            ? Image.asset(
                          "assets/generateScript/pdf.png",
                          height: 26.0,
                          width: 25.0,
                        )
                            : SizedBox(),
                        const SizedBox(height: 5),
                        Padding(
                          padding: const EdgeInsets.only(left: 0.0, right: 0),
                          child: Text(
                            mediaDocumentList.length == 0
                                ? 'Your uploaded documents (PDF only) will appear here  '
                                : "",
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            style: AppConstants
                                .txtStyle.heading14400LatoItalicLightPurple,
                          ),
                        ),
                      ],
                    ),
                    decoration: BoxDecoration(
                      color: AppConstants.colorStyle.tabBg,
                      border: Border.all(
                          color:
                          AppConstants.colorStyle.borderGenerateScript),
                      borderRadius:
                      const BorderRadius.all(Radius.circular(10)),
                    ),
                  ),
                  SizedBox(
                    height: 12,
                  )
                ],
              ),
              gridSelectedDocument(),
              Positioned(
                bottom: 0,
                child: InkWell(
                  radius: 50,
                  onTap: () async {
                    if (mediaDocumentList.length <= 5) {
                      getDocuments();
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                    }
                  },
                  child: Image.asset(
                    "assets/generateScript/plus_icon.png",
                    height: 26.0,
                    width: 25.0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );*/
  }

  Widget getFormViewUi(isMultipleSubject) {
    return PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        0.0,
        5.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Form(
                key: formKey,
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                          padding: const EdgeInsets.only(top: 30.0),
                          child: CustomFormField(
                            // maxLength: 35,
                              onSaved: (val) => strDate = val,
                              readOnly: true,
                              controller: dobController,
                              label: "Date taken",
                              onClick: () async {
                                DateTime pickedDate1 = await showDatePicker(
                                  context: context,
                                  initialDate: pickedDate == null ? DateTime.now() : pickedDate,
                                  //get today's date
                                  firstDate: DateTime(1900),
                                  //DateTime.now() - not to allow to choose before today.
                                  lastDate: DateTime.now(),
                                  confirmText: 'Apply',
                                  cancelText: 'Cancel',
                                );
                                if (pickedDate1 != null) {
                                  pickedDate = pickedDate1;
                                  strDateOfBirth = pickedDate1.millisecondsSinceEpoch;
                                  String date = Util.getDate(pickedDate1);
                                  setState(() {
                                    dobController = TextEditingController(text: date);
                                  });
                                }
                                // selectDob(context);
                              },
                              validation: (value) {
                                return value.length == 0
                                    ? MessageConstant.SELECT_DATE_TAKEN_VAL
                                    : null;
                              })),
                      isMultipleSubject
                          ? Column(
                          children: List.generate(
                            widget.subjectModel.length,
                                (int subjectIndex) {
                              SebjectDetailModel modelData =
                              widget.subjectModel[subjectIndex];
                              return Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding:
                                      const EdgeInsets.only(top: 30.0),
                                      child: CustomFormField(
                                        autovalidateMode:
                                        AutovalidateMode.disabled,
                                        textInputType: TextInputType.number,
                                        onType: (val) {},
                                        onSaved: (text) {
                                          takeNumber(
                                              text, modelData.testSubId);
                                        },
                                        label: modelData.subjectName +
                                            " (" +
                                            modelData.minScore.toString() +
                                            "-" +
                                            modelData.maxScore.toString() +
                                            ")",
                                        validation: (val) => modelData
                                            .isOptional &&
                                            (val == null || val == "")
                                            ? null
                                            : validateMethod(
                                            modelData,
                                            val != null && val != ""
                                                ? int.parse(val)
                                                : ''),
                                      ),
                                    ),
                                  ]);
                            },
                          ))
                          : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                                padding:
                                const EdgeInsets.only(top: 30.0),
                                child: CustomFormField(
                                  autovalidateMode:
                                  AutovalidateMode.disabled,
                                  textInputType: TextInputType.number,
                                  onType: (val) {},
                                  onSaved: (text) {
                                    takeNumber(
                                        text,
                                        widget
                                            .subjectModel[widget
                                            .subjectSelectedPosition]
                                            .testSubId);
                                  },
                                  label: widget
                                      .subjectModel[widget
                                      .subjectSelectedPosition]
                                      .subjectName +
                                      " (" +
                                      widget
                                          .subjectModel[widget
                                          .subjectSelectedPosition]
                                          .minScore
                                          .toString() +
                                      "-" +
                                      widget
                                          .subjectModel[widget
                                          .subjectSelectedPosition]
                                          .maxScore
                                          .toString() +
                                      ")",
                                  validation: (val) => widget
                                      .subjectModel[widget
                                      .subjectSelectedPosition]
                                      .isOptional
                                      ? null
                                      : validateMethod(
                                      widget.subjectModel[widget
                                          .subjectSelectedPosition],
                                      val != null && val != ""
                                          ? int.parse(val)
                                          : ''),
                                )),
                          ]),
                      Padding(
                        padding: const EdgeInsets.only(top: 24.0),
                        child: docSection(),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 24.0),
                        child: mediaSection(),
                      ),
                    ]))
          ],
        ));
  }

  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return GestureDetector(
        child: GestureDetector(
            child: customAppbar(
                context,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text: widget.testName,
                              textColor:
                                  ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            widget.testScoreModel.isSubCategory
                                ? BaseText(
                                    text: widget
                                        .subjectModel[
                                            widget.subjectSelectedPosition]
                                        .subjectName,
                                    textColor:
                                        AppConstants.colorStyle.lightPurple,
                                    fontFamily: AppConstants
                                        .stringConstant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                    textAlign: TextAlign.start,
                                    fontSize: 16,
                                    maxLines: 2,
                                  )
                                : SizedBox(height: 10,)
                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              widget.testScoreModel.isSubCategory
                                  ? PaddingWrap.paddingfromLTRB(20.0, 0.0,
                                      20.0, 5.0, getFormViewUi(false))
                                  : PaddingWrap.paddingfromLTRB(20.0, 0.0,
                                      20.0, 0.0, getFormViewUi(true))
                            ],
                          ),
                        ),
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Stack(
                        children: [
                          InkWell(
                            child: PaddingWrap.paddingfromLTRB(
                                20.0,
                                20.0,
                                20.0,
                                20.0,
                                Container(
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color:
                                          AppConstants.colorStyle.lightBlue,
                                      border: Border.all(
                                          color: AppConstants
                                              .colorStyle.lightBlue),
                                      borderRadius:
                                          BorderRadius.circular(10),
                                    ),
                                    child: Align(
                                        alignment: Alignment.center,
                                        // Align however you like (i.e .centerRight, centerLeft)
                                        child: Text(
                                          "Add",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontWeight: FontWeight.w600,
                                            color: ColorValues.WHITE,
                                            fontFamily: AppConstants
                                                .stringConstant.latoMedium,
                                            fontSize: 18.0,
                                          ),
                                        )))),
                            onTap: () async {
                              _checkValidation();
                            },
                          ),
                        ],
                      ),
                      flex: 0,
                    )
                  ],
                ), () {
          Navigator.pop(context);
        }, isShowIcon: false)));
  }
}
