import 'dart:async';

import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/emoji_picker_widget.dart';
import 'package:spike_view_project/ChatReafctor/viewmodel/chat_room_viewmodel.dart';
import 'package:spike_view_project/ChatReafctor/model/ChatModel.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:stacked/stacked.dart';

import '../model/FrienndListModel.dart';

class ChatRoomWidget extends StatefulWidget {
  String link, pageName, shareId;

  ChatRoomWidget(this._mFriends, this.link, this.shareId, {this.pageName});

  final Friends _mFriends;

  @override
  State<StatefulWidget> createState() {
    return ChatRoomWidgetState();
  }
}

class ChatRoomWidgetState extends State<ChatRoomWidget>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {
  String firstHalf = '';
  String userIdPref = "";
  SharedPreferences prefs;
  int notificationCount = 0;
  StreamSubscription<dynamic> _streamSubscription;

  String previousDateStamp = "";

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    if (widget.pageName == "notification") {
      bloc.fetchChatList(prefs.getString(UserPreference.USER_ID), context,
          prefs, true, 0.toString());
    }
    isUserRepoted = UserPreference.getIsUserReported();
  }

  bool isUserRepoted = true;

  @override
  void initState() {
    super.initState();

    getSharedPreferences();
    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
      if (value == "msg") {
      } else {
        if (mounted) {
          notificationCount = int.parse(value);
          setState(() {});
        }
      }
    });

    _streamSubscription =
        DashBoardStateParent.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        setState(() {});
      }
    });
    DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted) setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return ViewModelBuilder<ChatRoomViewModel>.reactive(
      builder: (context, model, child) => WillPopScope(
        onWillPop: () {
          if (widget.link != null && widget.link != "") {
            if (prefs.getString(UserPreference.ROLE_ID) == "1") {
              // For Studenet
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      //   builder: (context) =>  DashBoardWidget()));
                      builder: (context) => DashBoardWidget(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.CHAT_TYPE)));
            } else if (prefs.getString(UserPreference.ROLE_ID) == "2") {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      //   builder: (context) =>  DashBoardWidget()));
                      builder: (context) => DashBoardWidgetParent(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.CHAT_TYPE)));

              // For Parent
            } else if (prefs.getString(UserPreference.ROLE_ID) == "4") {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      //   builder: (context) =>  DashBoardWidget()));
                      builder: (context) => DashBoardWidgetPartner(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.CHAT_TYPE)));

              // For Partner
            }
          } else {
            model.onBack(context);
          }
          return Future.value(false);
        },
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: Scaffold(
            backgroundColor: const Color(0xffF5F6FA),
            appBar: AppBar(
              shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.vertical(bottom: Radius.circular(20))),
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 5,
              brightness: Brightness.light,
              toolbarHeight: 70,
              leading: Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Center(
                  child: InkWell(
                    child: CustomViews.getBackButton(),
                    onTap: () {
                      if (widget.link != null && widget.link != "") {
                        if (prefs.getString(UserPreference.ROLE_ID) == "1") {
                          // For Studenet
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) => DashBoardWidget(
                                      prefs.getString(
                                          UserPreference.IS_PARENT_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_PARTNER_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_USER_ROLE),
                                      currentPage: Constant.CHAT_TYPE)));
                        } else if (prefs.getString(UserPreference.ROLE_ID) ==
                            "2") {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) => DashBoardWidgetParent(
                                      prefs.getString(
                                          UserPreference.IS_PARENT_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_PARTNER_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_USER_ROLE),
                                      currentPage: Constant.CHAT_TYPE)));

                          // For Parent
                        } else if (prefs.getString(UserPreference.ROLE_ID) ==
                            "4") {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) => DashBoardWidgetPartner(
                                      prefs.getString(
                                          UserPreference.IS_PARENT_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_PARTNER_ROLE),
                                      prefs.getString(
                                          UserPreference.IS_USER_ROLE),
                                      currentPage: Constant.CHAT_TYPE)));

                          // For Partner
                        }
                      } else {
                        model.onBack(context);
                      }
                    },
                  ),
                ),
              ),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    onTap: () {
                      Util.onTapImageTile(
                          tapedUserRole:
                              widget._mFriends.partnerRoleId.toString(),
                          partnerUserId: widget._mFriends.partnerId.toString(),
                          context: context);
                    },
                    child: SizedBox(
                      height: 48,
                      width: 48,
                      child: Stack(
                        children: [

                          ProfileImageView(
                            imagePath:   Constant.IMAGE_PATH_SMALL + model.mFriends.partnerProfilePicture,
                            placeHolderImage: model?.mFriends?.partnerRoleId == 4
                                ? "assets/profile/partner_img.png"
                                : 'assets/profile/user_on_user.png',
                            height: 46,
                            width: 46,
                            onTap: () {},
                          ),
                          Positioned(
                            right: 0,
                            top: 0,
                            child: Image.asset(
                              model.mFriends.online == 1 ||
                                      model.mFriends.partnerId.toString() == "1"
                                  ? "assets/chats/ic_online.png"
                                  : "assets/chats/ic_offline.png",
                              width: 12,
                              height: 12,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Util.onTapImageTile(
                            tapedUserRole:
                                widget._mFriends.partnerRoleId.toString(),
                            partnerUserId: widget._mFriends.partnerId.toString(),
                            context: context);
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Flexible(
                                child: Text(
                                  model.mFriends.partnerFirstName == null ||
                                          model.mFriends.partnerFirstName ==
                                              "null"
                                      ? ""
                                      : model.mFriends.partnerLastName == null ||
                                              model.mFriends.partnerLastName ==
                                                  "" ||
                                              model.mFriends.partnerLastName ==
                                                  "null"
                                          ? model.mFriends.partnerFirstName
                                              .toString()
                                              .trim()
                                          : model.mFriends.partnerFirstName
                                                  .toString()
                                                  .trim() +
                                              " " +
                                              model.mFriends.partnerLastName,
                                  textAlign: TextAlign.start,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 18.0,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: Constant.latoMedium,
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION_1),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 3),
                                child:
                                    model.mFriends.partnerRoleId.toString() == "1"
                                        ? Util.getStudentBadge12(
                                            model.mFriends.badge,
                                            model.mFriends.badgeImage)
                                        : const SizedBox.shrink(),
                              ),
                            ],
                          ),
                          Text(
                            model.isTyping
                                ? "typing..."
                                : model.mFriends.online == 1 ||
                                        model.mFriends.partnerId.toString() == "1"
                                    ? "Active now"
                                    : ParseJson.getTimeValue2(
                                        DateTime.fromMillisecondsSinceEpoch(
                                            model.mFriends.lastSeen),
                                        DateTime.now()),
                            textAlign: TextAlign.start,
                            style: TextStyle(
                                fontSize: 12.0,
                                fontWeight: FontWeight.w400,
                                fontFamily: Constant.latoRegular,
                                color:
                                    ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              ),
              backgroundColor: Colors.white,
              actions: [
                /* InkWell(
                        child: CustomViews.getMoreButton(),
                        onTap: () {},
                      ),*/
                const SizedBox(width: 20),
              ],
            ),
            body: SafeArea(
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/newDesignIcon/icon/chat_bg.png'),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                    Expanded(
                      child: model.isLoading
                          ? Center(
                              child: Container(
                                  // A simplified version of dialog.
                                  width: 30.0,
                                  height: 30.0,
                                  child: CircularProgressIndicator(
                                    valueColor:
                                        AlwaysStoppedAnimation(Colors.black54),
                                    strokeWidth: 2.0,
                                  )),
                            )
                          : model.chatList == null || model.chatList.length == 0
                              ? widget.link == ""
                                  ? Center(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Image.asset(
                                            "assets/newDesignIcon/icon/no_chat_available.png",
                                            height: 114,
                                          ),
                                          Container(
                                            child: Column(
                                              children: [
                                                BaseText(
                                                  text: 'No conversation',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_CHAT_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18,
                                                  textAlign: TextAlign.center,
                                                  maxLines: 1,
                                                ),
                                                BaseText(
                                                  text:
                                                      'You didn’t made any conversation yet.',
                                                  textColor: AppConstants
                                                      .colorStyle.lightGrey,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoRegular,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 14,
                                                  textAlign: TextAlign.center,
                                                  maxLines: 2,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    )
                                  : const SizedBox.shrink()
                              : Column(
                                  children: <Widget>[
                                    model.isLoadMoreWithList
                                        ? Expanded(
                                            child: Container(
                                              // A simplified version of dialog.
                                              width: 30.0,
                                              height: 30.0,
                                              child: CircularProgressIndicator(
                                                valueColor:
                                                    AlwaysStoppedAnimation(
                                                        Colors.black54),
                                                strokeWidth: 2.0,
                                              ),
                                            ),
                                            flex: 0,
                                          )
                                        : const SizedBox.shrink(),
                                    Expanded(
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                          padding: EdgeInsets.zero,

                                          controller: model.mController,
                                          itemCount: model.chatList.length,
                                          itemBuilder: (_,  index) {
                                            return model.mFriends.userId ==
                                                    model.chatList[index].sender
                                                ? model.chatList[index].type ==
                                                        Constant
                                                            .opportunityPredefinedType
                                                    ? getSenderCellItemForSharedOpprtunity(
                                                        model.chatList[index],
                                                        index,
                                                        model)
                                                    : getSenderCellItem(
                                                        model.chatList[index],
                                                        index,
                                                        model)
                                                : model.chatList[index].type ==
                                                        Constant
                                                            .opportunityPredefinedType
                                                    ? getReceiverCellItemForSharedOpprtunity(
                                                        model.chatList[index],
                                                        index,
                                                        model)
                                                    : getReceiverCellItem(
                                                        model.chatList[index],
                                                        index,
                                                        model);
                                          }),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                      flex: 1,
                    ),
                    isUserRepoted
                        ? Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                              20.0,
                              10.0,
                              20.0,
                              20.0,
                              SingleChildScrollView(
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0,
                                      model.mInputHeight > 100 ? 0.0 : 0.0),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                      color: ColorValues.BORDER_COLOR_NEW,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Expanded(
                                        child: model.isEmojiVisible
                                            ? IconButton(
                                                icon: Icon(
                                                  Icons.keyboard,
                                                ),
                                                onPressed: () {
                                                  model.onClickedEmoji(context);
                                                },
                                              )
                                            : InkWell(
                                                child: Padding(
                                                    padding:
                                                        EdgeInsets.fromLTRB(0.0,
                                                            0.0, 10.0, 12.0),
                                                    child: Image.asset(
                                                      "assets/newDesignIcon/icon/attachment.png",
                                                      width: 24.0,
                                                      height: 24.0,
                                                    )),
                                                onTap: () {
                                                  model.onClickedEmoji(context);
                                                },
                                              ),
                                        flex: 0,
                                      ),
                                      Expanded(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 10.0, 2.0),
                                              child: TextField(
                                                maxLines: 6,
                                                minLines: 1,
                                                maxLength: TextLength
                                                    .CHAT_MSG_MAX_LENGTH,
                                                autofocus: true,
                                                cursorColor:
                                                    Constant.CURSOR_COLOR,
                                                keyboardType:
                                                    TextInputType.multiline,
                                                onChanged: (s) {
                                                  setState(() {
                                                    model.isLoadMoreWithList =
                                                        false;
                                                  });
                                                },
                                                style: TextStyle(
                                                    fontFamily:
                                                        Constant.customRegular),
                                                decoration: InputDecoration(
                                                  counterStyle: TextStyle(
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                  hintText: "Type a message...",
                                                  hintStyle: TextStyle(
                                                      fontSize: 14,
                                                      fontFamily: Constant.latoRegular,
                                                      color: ColorValues.hintColor),
                                                  counterText: "",
                                                  border: InputBorder.none,
                                                ),
                                                controller: model
                                                    .chatMessageEditTextController,
                                                focusNode: model.focusNode,
                                              )),
                                          flex: 1),
                                      Expanded(
                                        child: InkWell(
                                          child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  0.0, 0.0, 10.0, 12.0),
                                              child: Image.asset(
                                                "assets/newDesignIcon/icon/send_new.png",
                                                width: 23.0,
                                                height: 23.0,
                                              )),
                                          onTap: () {
                                            print(
                                                "object^^^^^^^^^^^^^^^^^^^^^^^^^^^");

                                            //  int dateAndTimeMil = DateTime.now().millisecondsSinceEpoch;

                                            /*model.chatList.add(new ChatData(
                                                      messageId: 0,
                                                      connectorId: model.mFriends.connectId,
                                                      sender: model.mFriends.userId,
                                                      receiver:model.mFriends.partnerId,
                                                      deletedBy: 0,
                                                      senderRoleId: int.parse(model.roleId),
                                                      receiverRoleId:model.mFriends.partnerRoleId,
                                                      time: dateAndTimeMil,
                                                      text: model.chatMessageEditTextController.text,
                                                      type: 1,
                                                      status: 0,
                                                      opportunityId: "",
                                                      opportunityTitle: "",
                                                      opportunityImage: "",
                                                      opportunityDesc: ""));*/

                                            model.sendChatMessage();

                                            if (widget.link != "") {
                                              model
                                                  .apiCallingForUpdateStudentStatus(
                                                      model.mFriends, context);
                                            }
                                          },
                                        ),
                                        flex: 0,
                                      )
                                    ],
                                  ),
                                  //color: Colors.white,
                                ),
                              ),
                            ),
                            flex: 0,
                          )
                        : const SizedBox.shrink(),
                    Offstage(
                      child: EmojiPickerWidget(onEmojiSelected: (String emoji) {
                        print("selection++++++++++++++++++----------------" +
                            model.chatMessageEditTextController.selection
                                .baseOffset
                                .toString());

                        if (model.chatMessageEditTextController.text == "" ||
                            model.chatMessageEditTextController.selection
                                    .baseOffset <
                                0) {
                          model.chatMessageEditTextController.text =
                              model.chatMessageEditTextController.text + emoji;
                        } else {
                          String text =
                              model.chatMessageEditTextController.text;
                          TextSelection textSelection =
                              model.chatMessageEditTextController.selection;
                          String newText = text.replaceRange(
                              textSelection.start, textSelection.end, emoji);
                          final emojiLength = emoji.length;
                          model.chatMessageEditTextController.text = newText;
                          model.chatMessageEditTextController.selection =
                              textSelection.copyWith(
                            baseOffset: textSelection.start + emojiLength,
                            extentOffset: textSelection.start + emojiLength,
                          );
                        }
                      }),
                      offstage: !model.isEmojiVisible,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      viewModelBuilder: () => ChatRoomViewModel(widget._mFriends, widget.link,
          widget.pageName, widget.shareId, context),
    );
  }

  String getConvertedTime1(String time, index) {
    int millis = int.tryParse(time);
    var now = DateTime.fromMillisecondsSinceEpoch(millis);
    String formatted = "";
    int hour = now.hour;
    int minute = now.minute;
    //  int weight = int.parse(formatted);
    print("time" +
        formatted.toString() +
        " hour " +
        hour.toString() +
        "   minute " +
        minute.toString());
    if (12 <= hour) {
      String minutetTime = minute.toString();
      if (minute.toString().length == 1) {
        minutetTime = "0" + minute.toString();
      }
      hour = hour - 12;
      if (hour == 0) {
        hour = 12;
      }
      formatted = hour.toString() + ":" + minutetTime + " pm";
    } else {
      String minutetTime = minute.toString();
      if (minute.toString().length == 1) {
        minutetTime = "0" + minute.toString();
      }
      if (hour == 0) {
        hour = 12;
      }
      formatted = (hour).toString() + ":" + minutetTime + " am";
    }

    return formatted;
  }

  String getConvertedDateStamp(String time, int index) {
    int millis = int.tryParse(time);
    var now = DateTime.fromMillisecondsSinceEpoch(millis);
    var formatter = DateFormat('MMM dd, yyyy');
    String formatted = formatter.format(now);

    print("apurva date+++++" + formatted);
    print("apurva date trim" + formatted.trim());
    print("apurva date trim previousDateStamp++" + previousDateStamp.trim());
    if (index == 0) {
      previousDateStamp = "";
    }
    if (formatted.trim() != previousDateStamp.trim()) {
      print("date set++" + formatted.trim());
      previousDateStamp = formatted;

      return formatted;
    } else {
      return "";
    }
  }

  Padding getReceiverCellItem(
      ChatData model, index, ChatRoomViewModel mChatRoomViewModel) {
    String timePre = getConvertedDateStamp(model.time.toString(), index);
    // String timePre = model.convertedDateString.toString();
    return Padding(
        padding: EdgeInsets.fromLTRB(12.0, 10.0, 12.0, 0.0),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              timePre == ""
                  ? const SizedBox.shrink()
                  : Center(
                      child: Container(
                          decoration: BoxDecoration(
                            color: ColorValues.Withdraw_Text_Color,
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                          ),
                          padding: EdgeInsets.all(5.0),
                          margin: EdgeInsets.only(top: 5, bottom: 20),
                          child: Text(
                            timePre,
                            style: TextStyle(
                              color: ColorValues.TEXT_COLOR_DATE,
                              fontSize: 12.0,
                              fontWeight: FontWeight.w600,
                              fontFamily: Constant.latoRegular,
                            ),
                          ))),
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Transform.translate(
                    offset: Offset(-3,0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: <Widget>[
                        /* Padding(
                                  padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                                  child: Container(
                                    height: 35.0,
                                    width: 35.0,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(100),
                                      child: FadeInImage(
                                        fit: BoxFit.cover,
                                        placeholder: AssetImage(
                                          'assets/profile/user_on_user.png',
                                        ),
                                        image: NetworkImage(
                                            Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getMediumImage(
                                                    mChatRoomViewModel.mFriends
                                                        .partnerProfilePicture)),
                                      ),
                                    ),
                                  )),*/
                        Transform.translate(
                          offset: Offset(2, -9),
                          child: RotatedBox(
                            quarterTurns: 90,
                            child: Image.asset(
                              'assets/chats/triangle_white.png',
                              width: 12,
                              height: 12,
                            ),
                          ),
                        ),
                        Flexible(
                          child: InkWell(
                            child: Container(
                              margin: const EdgeInsets.only(right: 48),
                              padding: EdgeInsets.fromLTRB(16, 10, 16, 10),
                              decoration: BoxDecoration(
                                  color: ColorValues.FROM_MSG_BG_COLOR,
                                  borderRadius: BorderRadius.circular(14)),
                              child: Linkify(
                                onOpen: (link) async {
                                  mChatRoomViewModel.onTapText(
                                      link.url, context);
                                },
                                text: model.text,
                                style: TextStyle(
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    fontFamily: Constant.latoMedium,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14.0),
                                linkStyle: TextStyle(
                                    color: ColorValues
                                        .HEADING_COLOR_EDUCATION_1,
                                    fontFamily: Constant.latoMedium,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 14.0),
                              ),
                            ),
                            onTap: () {
                              // onTapText(model.text);
                            },
                            onLongPress: () {
                              Util.copyToClipboard(model.text, context);
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
                    child: _msgTimeView(getConvertedTime1(
                        model.time.toString(), index)),
                  ),
                ],
              ),
            ],
        ),
    );
  }

  Widget _msgTimeView(String time) {
    return BaseText(
      text: time,
      textColor: const Color(0xff666B9A),
      fontFamily: Constant.latoRegular,
      fontWeight: FontWeight.w400,
      fontSize: 12,
    );
  }

  Padding getSenderCellItem(
      ChatData model, index, ChatRoomViewModel mChatRoomViewModel) {
    String timePre = getConvertedDateStamp(model.time.toString(), index);
    // String timePre = model.convertedDateString.toString();

    return Padding(
        padding: EdgeInsets.fromLTRB(12.0, 10.0, 12.0, 0.0),
        child: Center(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                timePre == ""
                    ? Container(
                        height: 0.0,
                      )
                    : Center(
                        child: Container(
                          decoration: BoxDecoration(
                            color: ColorValues.Withdraw_Text_Color,
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                          ),
                          padding: EdgeInsets.all(5.0),
                          margin: EdgeInsets.only(top: 5, bottom: 20),
                          child: Text(
                            timePre,
                            style: TextStyle(
                              color: ColorValues.TEXT_COLOR_DATE,
                              fontSize: 12.0,
                              fontWeight: FontWeight.w600,
                              fontFamily: Constant.latoRegular,
                            ),
                          ),
                        ),
                      ),
                model.text.length < 35
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Align(
                              alignment: Alignment.bottomRight,
                              child: InkWell(
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        /*image: DecorationImage(
                                            image: AssetImage(
                                                'assets/chats/bg_one_line_msg.png',
                                            ),
                                            fit: BoxFit.fill,
                                          ),*/
                                        color: const Color(0xff4684EB),
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      padding:
                                          EdgeInsets.fromLTRB(16, 10, 16, 10),
                                      child: Linkify(
                                        onOpen: (link) async {
                                          mChatRoomViewModel.onTapText(
                                              link.url, context);
                                        },
                                        text: model.text,
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontFamily: Constant.latoMedium,
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14.0),
                                        linkStyle: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontFamily: Constant.latoMedium,
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14.0),
                                      ),
                                    ),
                                    Transform.translate(
                                      offset: Offset(-1, 0),
                                      child: Image.asset(
                                        'assets/chats/triangle_blue.png',
                                        height: 12,
                                        width: 12,
                                      ),
                                    ),
                                  ],
                                ),
                                onTap: () {
                                  //onTapText(model.text);
                                },
                                onLongPress: () {
                                  Util.copyToClipboard(model.text, context);
                                },
                              )),
                          const SizedBox(height: 5),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: _msgTimeView(getConvertedTime1(
                                model.time.toString(), index)),
                          ),
                        ],
                      )
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          InkWell(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(40.0, 0.0, 0.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image: AssetImage(
                                            'assets/newDesignIcon/icon/my_chat.png'),
                                        fit: BoxFit.fill,
                                      ),
                                      borderRadius: BorderRadius.only(
                                        topLeft: const Radius.circular(15.0),
                                        bottomLeft: const Radius.circular(15.0),
                                        bottomRight:
                                            const Radius.circular(15.0),
                                        topRight: const Radius.circular(15.0),
                                      )),
                                  child: Container(
                                    padding: EdgeInsets.only(
                                        left: 16,
                                        right: 16,
                                        top: 10,
                                        bottom: 10),
                                    child: Linkify(
                                      onOpen: (link) async {
                                        print("onclick +++" + link.url);
                                        mChatRoomViewModel.onTapText(
                                            link.url, context);
                                        //    onTapText(link.url);
                                      },
                                      text: model.text,
                                      style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontFamily: Constant.latoMedium,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14.0),
                                      linkStyle: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontFamily: Constant.latoMedium,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14.0),
                                    ),
                                  ),
                                )),
                            onTap: () {
                              //onTapText(model.text);
                            },
                            onLongPress: () {
                              Util.copyToClipboard(model.text, context);
                              //copyToClipboard(model.text);
                            },
                          ),
                          const SizedBox(height: 5),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: _msgTimeView(getConvertedTime1(
                                model.time.toString(), index)),
                          ),
                        ],
                      )
              ]),
        ));
  }

  Padding getSenderCellItemForSharedOpprtunity(
      ChatData model, index, ChatRoomViewModel mChatRoomViewModel) {
    String timePre = getConvertedDateStamp(model.time.toString(), index);
    //String timePre = model.convertedDateString.toString();

    return Padding(
        padding: EdgeInsets.fromLTRB(12.0, 10.0, 12.0, 0.0),
        child: Center(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                timePre == ""
                    ? Container(
                        height: 0.0,
                      )
                    : Center(
                        child: Container(
                            decoration: BoxDecoration(
                              color: ColorValues.Withdraw_Text_Color,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5.0)),
                            ),
                            padding: EdgeInsets.all(5.0),
                            margin: EdgeInsets.only(top: 5, bottom: 20),
                            child: Text(
                              timePre,
                              style: TextStyle(
                                color: ColorValues.TEXT_COLOR_DATE,
                                fontSize: 12.0,
                                fontWeight: FontWeight.w600,
                                fontFamily: Constant.latoRegular,
                              ),
                            ))),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    InkWell(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(40.0, 0.0, 0.0, 0.0),
                          child: Container(
                            decoration: BoxDecoration(
                                color: ColorValues.BORDER_COLOR,
                                border: Border.all(
                                    color: ColorValues.BORDER_COLOR,
                                    width: 1.0),
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(15.0),
                                  bottomLeft: const Radius.circular(15.0),
                                  bottomRight: const Radius.circular(15.0),
                                  topRight: const Radius.circular(15.0),
                                )),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 5.0),
                                  child: Container(
                                    color: Colors.white,
                                    child: Column(
                                      children: <Widget>[
                                        Padding(
                                            padding: EdgeInsets.all(0),
                                            child: Container(
                                                child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              width: double.infinity,
                                              height: 150.00,
                                              placeholder:
                                                  'assets/aerial/default_img.png',
                                              image: Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getMediumImage(
                                                      model.opportunityImage),
                                            ))),
                                        Row(
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      10.0, 5.0, 10.0, 5.0),
                                              child: Linkify(
                                                onOpen: (link) async {
                                                  print(
                                                      "onclick +++" + link.url);
                                                  mChatRoomViewModel.onTapText(
                                                      link.url, context);
                                                  //onTapText(link.url);
                                                },
                                                text: model.opportunityTitle,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR,
                                                    fontSize: 12.0,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Row(
                                  children: <Widget>[
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          17.0, 7.0, 10.0, 10.0),
                                      child: Linkify(
                                        onOpen: (link) async {
                                          print("onclick +++" + link.url);
                                          mChatRoomViewModel.onTapText(
                                              link.url, context);
                                          //onTapText(link.url);
                                        },
                                        text: model.opportunityDesc,
                                        style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 14.0,
                                        ),
                                        linkStyle: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 14.0,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          )),
                      onTap: () {
                        //uncomment;
                        mChatRoomViewModel.onTapOpportunity(
                            model.opportunityId, context);
                      },
                      onLongPress: () {},
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 3.0, 5.0, 0.0),
                          child: Text(
                              getConvertedTime1(model.time.toString(), index),
                              style: TextStyle(
                                  color: ColorValues.GREY_TEXT_COLOR,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 8.0))),
                    ),
                  ],
                )
              ]),
        ));
  }

  Padding getReceiverCellItemForSharedOpprtunity(
      ChatData model, index, ChatRoomViewModel mChatRoomViewModel) {
    String timePre = getConvertedDateStamp(model.time.toString(), index);
    //String timePre = model.convertedDateString.toString();

    return Padding(
        padding: EdgeInsets.fromLTRB(12.0, 10.0, 12.0, 0.0),
        child: Center(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                timePre == ""
                    ? Container(
                        height: 0.0,
                      )
                    : Center(
                        child: Container(
                            decoration: BoxDecoration(
                              color: ColorValues.Withdraw_Text_Color,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5.0)),
                            ),
                            padding: EdgeInsets.all(5.0),
                            margin: EdgeInsets.only(top: 5, bottom: 5),
                            child: Text(
                              timePre,
                              style: TextStyle(
                                color: ColorValues.TEXT_COLOR_DATE,
                                fontSize: 12.0,
                                fontWeight: FontWeight.w600,
                                fontFamily: Constant.latoRegular,
                              ),
                            ))),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                          child: Container(
                            height: 35.0,
                            width: 35.0,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: FadeInImage(
                                fit: BoxFit.cover,
                                placeholder: AssetImage(
                                  'assets/profile/user_on_user.png',
                                ),
                                image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getMediumImage(mChatRoomViewModel
                                        .mFriends.partnerProfilePicture)),
                              ),
                            ),
                          )),
                      flex: 0,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          InkWell(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(8.0, 0.0, 40.0, 0.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                      color: ColorValues.DARK_GREY,
                                      border: Border.all(
                                          color: ColorValues.DARK_GREY,
                                          width: 1.0),
                                      borderRadius: BorderRadius.only(
                                        topLeft: const Radius.circular(15.0),
                                        bottomLeft: const Radius.circular(15.0),
                                        bottomRight:
                                            const Radius.circular(15.0),
                                        topRight: const Radius.circular(15.0),
                                      )),
                                  child: Padding(
                                    padding: const EdgeInsets.all(1.0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: ColorValues.WHITE,
                                          border: Border.all(
                                              color: ColorValues.WHITE,
                                              width: 1.0),
                                          borderRadius: BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(15.0),
                                            bottomLeft:
                                                const Radius.circular(15.0),
                                            bottomRight:
                                                const Radius.circular(15.0),
                                            topRight:
                                                const Radius.circular(15.0),
                                          )),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                10.0, 5.0, 10.0, 5.0),
                                            child: Container(
                                              color: Color(0xffF4F4F4),
                                              child: Column(
                                                children: <Widget>[
                                                  Padding(
                                                      padding:
                                                          EdgeInsets.all(0),
                                                      child: Container(
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                        fit: BoxFit.cover,
                                                        width: double.infinity,
                                                        height: 150.00,
                                                        placeholder:
                                                            'assets/aerial/default_img.png',
                                                        image: Constant
                                                                .IMAGE_PATH_SMALL +
                                                            ParseJson
                                                                .getMediumImage(
                                                                    model
                                                                        .opportunityImage),
                                                      ))),
                                                  Row(
                                                    children: <Widget>[
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                10.0,
                                                                5.0,
                                                                10.0,
                                                                5.0),
                                                        child: Linkify(
                                                          onOpen: (link) async {
                                                            print(
                                                                "onclick +++" +
                                                                    link.url);
                                                            mChatRoomViewModel
                                                                .onTapText(
                                                                    link.url,
                                                                    context);
                                                            //   onTapText(link.url);
                                                          },
                                                          text: model
                                                              .opportunityTitle,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR,
                                                              fontSize: 12.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Row(
                                            children: <Widget>[
                                              Padding(
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        17.0, 7.0, 10.0, 10.0),
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    print("onclick +++" +
                                                        link.url);
                                                    mChatRoomViewModel
                                                        .onTapText(
                                                            link.url, context);
                                                  },
                                                  text: model.opportunityDesc,
                                                  style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0,
                                                  ),
                                                  linkStyle: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR,
                                                    fontSize: 14.0,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )),
                            onTap: () {
                              //uncomment
                              mChatRoomViewModel.onTapOpportunity(
                                  model.opportunityId, context);
                            },
                            onLongPress: () {},
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 3.0, 5.0, 0.0),
                                child: Text(
                                    getConvertedTime1(
                                        model.time.toString(), index),
                                    style: TextStyle(
                                        color: ColorValues.GREY_TEXT_COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 8.0))),
                          ),
                        ],
                      ),
                      flex: 1,
                    )
                  ],
                )
              ]),
        ));
  }

  String getTextValue(Friends model) {
    //print('model.lastMessage.length:: ${model.lastMessage.length}');
    if (model.lastMessage.length > 24) {
      firstHalf = model.lastMessage.substring(0, 24) + '...';
    } else {
      firstHalf = model.lastMessage;
    }
    try {
      print("model++++" + model.textSentBy.toString());
      if (model.userId != null) {
        if (model.textSentBy == model.userId) {
          return "You: ";
        }

        if (model.textSentBy == model.partnerId) {
          // return model.partnerFirstName + ": ";
          return " ";
        }
      }
      return " ";
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "chat_friend_list", context);
      return " ";
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
