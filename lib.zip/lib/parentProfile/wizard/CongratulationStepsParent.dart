import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/drawer/ProfileVisibilitySetting.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/OpportunityViewOnNotificationClick.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/notification/OpportunityForBoat.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parentProfile/RecommendationListForParent.dart';
import 'package:spike_view_project/parentProfile/wizard/CongratulationMobileParent.dart';
import 'package:spike_view_project/parentProfile/wizard/ProfilePic_Widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/badges/new_badges/partner_manage_badges.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicViewForUser.dart';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForBoatReview.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForOtherUser.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/profile/studentWizard/AddProfileImage.dart';
import 'package:spike_view_project/profile/studentWizard/CongratulationMobile.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:flutter/services.dart';

import 'package:spike_view_project/presoView/AerialViewMainStart23.dart';

import 'package:spike_view_project/shareprofile/ShareProfileViewPage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/Company_Edit_Widget.dart';

class CongratulationStepsParent extends StatefulWidget {
  String isActive = "false", pageName;
  StudentDataModel studModel;
  String sasToken;
  int stage;
  CongratulationStepsParent(this.studModel);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  CongratulationStepsParentState();
  }
}

class CongratulationStepsParentState extends State<CongratulationStepsParent> {
  List<NotificationModel> dataList =  List();
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String userIdPref, roleId;


  getSharedPreferences() async {

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //getSharedPreferences();
    print("==================== INIT STATE");
  }



  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  WillPopScope(
        onWillPop: () {
          /*if (!isDataLoading) {
            if(widget.pageName == 'main'){
              Navigator.pushReplacement(
                //Constant.applicationContext,
                  context,
                   MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                      builder: (context) =>  DashBoardWidgetPartner(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          currentPage: Constant.PROFILE_TYPE)));
            }else
            Navigator.pop(context);
          } else
            print("not perform");*/
          print("not perform");
        },

        child:  Scaffold(
            backgroundColor: Colors.white,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,

              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 0,
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        //Navigator.pop(context);
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child:  Image.asset(
                        "assets/newDesignIcon/blue_spike_logo.png",
                        width: 114.0,
                        height: 29.0,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 0,
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),),
                  ),
                ],
              ),

              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body: Container(
              //color: Color(0xffDADADA),
              child: Stack(
                children: <Widget>[
                  Positioned(

                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Column(

                      children: <Widget>[
                        //CustomViews.getSepratorLine(),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 44.0, vertical: 0.0),
                          child:  Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [

                              Padding(
                                padding: const EdgeInsets.only(top: 10.0, bottom: 50.0),
                                child:  Center(
                                  child:  Image.asset(
                                    "assets/progress_indecator/congratulations_msg_child.png",
                                    width: 306.0,
                                    height: 62.0,
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onVerticalDragUpdate: (details) {
                                  int sensitivity = 8;
                                  if (details.delta.dy > sensitivity) {
                                    // Down Swipe
                                    print('Apurva GestureDetector Down Swipe');
                                    goToUpperScreen();
                                  } else if(details.delta.dy < -sensitivity){
                                    // Up Swipe
                                    print('Apurva GestureDetector Up Swipe');

                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 0.0, bottom: 0.0),
                                  child:  Center(
                                    child:  Image.asset(
                                      "assets/progress_indecator/all_steps.png",
                                      width: 251,//MediaQuery.of(context).size.width - 88,
                                      height: 400,//MediaQuery.of(context).size.height - statusBarHeight - AppBar().preferredSize.height - 200.0 -10 - 27 -61,
                                       fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    bottom: 40,
                    left: 0,
                    right: 0,
                    child: InkWell(
                      onTap: (){
                        goToNextState();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                          child: /*new Image.asset(
                            "assets/progress_indecator/lets_start.png",
                            width: 150.0,
                            //height: 30.0,
                            fit: BoxFit.fitWidth,
                          ),*/
                          Text(
                            "Let’s get started!",
                            textAlign: TextAlign.start,
                            style:  TextStyle(
                                color:  ColorValues.BLUE_COLOR,
                                fontSize: 20.0,
                                fontWeight: FontWeight.w400,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          )
                        ),
                      ),
                    ),)
                ],
              ),
            )));
  }

  Future<void> goToNextState() async {
    String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         ProfilePic_Widget(widget.studModel)));
  }
  Future<void> goToUpperScreen() async {
    String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         CongratulationMobileParent(widget.studModel)));
    //Navigator.of(context).pop();
  }
}
