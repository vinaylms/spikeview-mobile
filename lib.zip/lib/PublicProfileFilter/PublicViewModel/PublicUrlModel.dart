import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';

class PublicUrlModel {
  String status;
  String message;
  List<String> result;

  PublicUrlModel({this.status, this.message, this.result});

  PublicUrlModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    result = json['result'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    data['result'] = this.result;
    return data;
  }
}