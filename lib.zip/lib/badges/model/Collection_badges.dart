

import 'package:spike_view_project/badges/model/CollectionResult.dart';

class CollectionBadges {
  CollectionBadges({
      this.status, 
      this.result, 
      this.totalCount,});

  CollectionBadges.fromJson(dynamic json) {
    status = json['status'];
    if (json['result'] != null) {
      result = [];
      json['result'].forEach((v) {
        result.add(Result.fromJson(v));
      });
    }
    totalCount = json['totalCount'];
  }
  String status;
  List<Result> result;
  int totalCount;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    if (result != null) {
      map['result'] = result.map((v) => v.toJson()).toList();
    }
    map['totalCount'] = totalCount;
    return map;
  }

}