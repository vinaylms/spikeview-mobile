import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ThanksPage extends StatefulWidget {
  @override
  _ThanksPageState createState() => _ThanksPageState();
}

class _ThanksPageState extends State<ThanksPage> {
  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0.0,
        brightness: Brightness.light,
        backgroundColor: Colors.white,
        title: Align(
          alignment: Alignment.center,
          child: Image.asset(
            "assets/newDesignIcon/navigation/spike_logo_login.png",
            height: 30.0,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 24, right: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              "assets/svgimages/donewithbg.png",
              height: 73.0,
            ),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(top: 8),
              child: Text(
                MessageConstant.THANKS,
                style: TextStyle(fontSize: 26),
                textAlign: TextAlign.center,
              ),
            ),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.only(top: 8),
              child: Text(
                MessageConstant.DIS,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            ),
            FlatButton(
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                Util.onTapSignOut(context, prefs);
              },
              child: Text(
                "SIGN IN",
                style: TextStyle(color: ColorValues.BLUE_COLOR_BOTTOMBAR),
              ),
            )
          ],
        ),
      ),
    );
  }
}
