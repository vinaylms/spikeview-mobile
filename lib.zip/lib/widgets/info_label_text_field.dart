import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// ignore: must_be_immutable
class InfoLabelTextField extends StatefulWidget {
  InfoLabelTextField({
    Key key,
    this.label,
    this.hint,
    this.suffixWidget,
    this.prefixWidget,
    this.textInputType = TextInputType.text,
    this.textInputAction = TextInputAction.done,
    this.maxLength,
    this.validation,
    this.controller,
    this.inputFormatter,
    this.onClick,
    this.onType,
    this.focusNode,
    this.autovalidateMode,
    this.alignLabelWithHint,
    this.textAlign = TextAlign.left,
    this.maxLines,
    this.textStyle,
    this.minLines,
    this.onLabelTap,
  }) : super(key: key);

  final TextAlign textAlign;
  final String label;
  final String hint;
  final Widget suffixWidget;
  final Widget prefixWidget;
  final FocusNode focusNode;
  final TextInputType textInputType;
  final TextInputAction textInputAction;
  final AutovalidateMode autovalidateMode;
  final int maxLength;
  final Function() onClick;
  final Function(String selected) onType;
  final String Function(String) validation;
  final TextEditingController controller;
  final bool alignLabelWithHint;
  final int maxLines;
  final TextStyle textStyle;
  final int minLines;
  List<TextInputFormatter> inputFormatter;
  bool readOnly = false;
  bool autoValidate = false;
  final VoidCallback onLabelTap;

  @override
  _InfoLabelTextFieldState createState() => _InfoLabelTextFieldState();
}

class _InfoLabelTextFieldState extends State<InfoLabelTextField> {
  bool isFocus = false;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          isFocus
              ? InkWell(
                  onTap: widget.onLabelTap,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BaseText(
                        text: widget.label,
                        textColor:  const Color(0xff666B9A),
                        fontSize: 13.5,
                        //fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                      const SizedBox(width: 5),
                       Image.asset(
                        'assets/experience/ic_info.png',
                        height: 18,
                        width: 18,
                        color: const Color(0xFF666B9A),
                      ),
                    ],
                  ),
                )
              : const SizedBox.shrink(),
          Focus(
            onFocusChange: (value) {
              setState(() {
                isFocus = value;
              });
            },
            child: TextFormField(
                autovalidateMode: widget.autovalidateMode == null
                    ? AutovalidateMode.onUserInteraction
                    : widget.autovalidateMode,
                textCapitalization: TextCapitalization.sentences,
                textAlign: widget.textAlign,
                textInputAction: widget.textInputAction,
                cursorColor: AppConstants.colorStyle.lightBlue,
                maxLines: widget.maxLines,
                minLines: widget.minLines ?? 1,
                focusNode: widget.focusNode,
                readOnly: widget.readOnly,
                keyboardType: widget.textInputType,
                onTap: widget.onClick,
                onChanged: (value) {
                  widget.onType(value);
                },
                controller: widget.controller,
                maxLength: widget.maxLength,
                style: widget.textStyle != null
                    ? widget.textStyle
                    /*: isFocus
                        ? AppConstants.txtStyle.labelStyleTextFormlightBlue*/
                        : AppConstants.txtStyle.txtStyleTextForm,
                validator: widget.validation,
                inputFormatters: widget.inputFormatter,
                decoration: InputDecoration(
                  alignLabelWithHint: widget.alignLabelWithHint ?? false,
                  isDense: true,
                  suffixIcon: widget.suffixWidget,
                  filled: true,
                  errorMaxLines: 4,
                  suffixIconConstraints: BoxConstraints(
                    minWidth: 25,
                    minHeight: 25,
                  ),
                  labelText: isFocus ? null : widget.label,
                  labelStyle: AppConstants.txtStyle.labelStyleTextForm,
                  counterText: '',
                  hintText: isFocus ? widget.hint : '',
                  hintMaxLines: 10,
                  hintStyle: TextStyle(
                    color: ColorValues.hintColor,
                    fontFamily: Constant.latoRegular,
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                  ),
                  focusColor: AppConstants.colorStyle.lightBlue,
                  errorStyle: AppConstants.txtStyle.labelStyleTextForm,
                  counterStyle: AppConstants.txtStyle.counterStyleTextForm,
                  fillColor: Colors.transparent,
                  contentPadding: EdgeInsets.fromLTRB(0.0, 0, 5.0, 10),
                  border: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: AppConstants.colorStyle.btnBg,
                    width: 1.0,
                  )),
                  focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: AppConstants.colorStyle.lightBlue,
                    width: 1.0,
                  )),
                  enabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: AppConstants.colorStyle.btnBg,
                    width: 1.0,
                  )),
                  disabledBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                    color: AppConstants.colorStyle.btnBg,
                    width: 1.0,
                  )),
                )),
          ),
        ],
      ),
    );
  }
}
