import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/MainUIView/PatnerProfileWidgetForBoatReview.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';

class OpportunityForBoat extends StatefulWidget {
  String roleId, pageName;

  String opportunityId;

  OpportunityForBoat(this.opportunityId, this.roleId, this.pageName);

  @override
  State<StatefulWidget> createState() => OpportunityForBoatState(opportunityId);
}

class OpportunityForBoatState extends State<OpportunityForBoat>
    with BaseCommonWidget {
  bool isActivate = true;
  OpportunityModelForFeed opportunity = null;
  SharedPreferences prefs;
  List<Assest> mediaDocumentList = List();
  List<Assest> googleLinkList = List();
  String userIdPref;
  String location = "";
  TextEditingController reasonTxtController = TextEditingController();
  final FocusNode _reasonFocus = FocusNode();
  final GlobalKey<FormState> _mpportunityRejectionFormKey =
      GlobalKey<FormState>();
  String rejectionReason = '';
  final formKeyReferal = GlobalKey<FormState>();

  String opportunityId;

  OpportunityForBoatState(this.opportunityId);

  int diffrenceInDob = 14;

  String firstHalf = '';
  String secondHalf = '';
  bool flag = true;

  String firstHalfDesc = '';
  String secondHalfDesc = '';
  bool flagDesc = true;

  String descVal = '';

  String categoryString = '';

  String subjectString = '';

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    String dob = prefs.getString(UserPreference.DOB);
    diffrenceInDob = int.tryParse(dob);
  }

  onBack() async {
    print("inside onBack()");
    print("inside onBack() widget.page++" + widget.pageName);
    if (widget.pageName != null && widget.pageName == "main") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);

        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  onBackold() async {
    print("inside onBack()");
    print("inside onBack() widget.page++" + widget.pageName);
    if (widget.pageName != null && widget.pageName == "main") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  showErrorMsg(msg, context) {
    Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => Scaffold(
          backgroundColor: Colors.transparent,
          body: Stack(
            children: <Widget>[
              Positioned(
                  right: 0.0,
                  top: 55.0,
                  left: 0.0,
                  child: Container(
                    height: 65.0,
                    padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                    color: Color(0xffF1EDC3),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          RichText(
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: 'ERROR: ',
                              style: TextStyle(
                                color: Color(0xffFF0101),
                                height: 1.2,
                                fontSize: 13.0,
                                fontWeight: FontWeight.bold,
                              ),
                              children: <TextSpan>[
                                TextSpan(
                                  text: msg,
                                  style: TextStyle(
                                      color: Color(0xffFF0101),
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.normal,
                                      fontFamily: Constant.customRegular),
                                )
                              ],
                            ),
                          )
                        ]),
                  )),
            ],
          ),
        ));
  }

  Future callGetOpportunityDetailsAPI() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'callGetOpportunityDetailsAPI URL:: ${Constant.ENDPOINT_Opportunity_detail_api}${widget.opportunityId}');
        CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_Opportunity_detail_api + widget.opportunityId,
            "get");
        CustomProgressLoader.cancelLoader(context);
        print("callGetOpportunityDetailsAPI data" + response.toString());
        if (response != null) {
          if (response.data['result'].toString() == "[]") {
            showErrorMsg(MessageConstant.OPPORTUNITY_DELETED_POST, context);
          } else if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            print('Status:: $status');

            opportunity = ParseJson.parseOpportunityDetailData(
                response.data['result'], userIdPref, widget.roleId);
            print('opportunity after parsing::::::' +
                opportunity.status.toString());
            if (opportunity != null) {
              print('inside if::::: ');
              mediaDocumentList.addAll(opportunity.docList);

              googleLinkList.addAll(opportunity.googleLinkList);
              for (Address adress in opportunity.locationList) {
                if (location == "") {
                  location = location + " " + adress.street1;
                } else {
                  location = location + "   /  " + adress.street1;
                }
              }
              getData();
              if (opportunity.status != "Pending" &&
                  opportunity.status != "Created" &&
                  widget.roleId == "1") {
                ToastWrap.showToast("Action already been taken", context);
              }
              setState(() {
                opportunity = opportunity;
              });
              print(
                  'opportunity.expiresOn::: ${opportunity.expiresOn}, value:: ${getConvertedDateStamp2(opportunity.expiresOn)}');
            }
          }
        } else {
          print("error+++++++++++++");
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  Future<void> getInitData() async {
    await getSharedPreferences();
    await callGetOpportunityDetailsAPI();
  }

  @override
  void initState() {
    getInitData();
    super.initState();
  }


  void showSucessMsg(msg, duration, maxLine) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,

      builder: (_) {
        return ConfirmationDialog(
          headingText: msg,
            isSucessPopup:true,
          onPositiveTap: (){
            Navigator.pop(context);

          },
        );
      },
    );
  }


  showSucessMsgold(msg, context, duration, maxLine) {
    Timer _timer;

    print("timer on");
    _timer = Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  Future apiCallingForUpdate(value) async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "opportunityId": widget.opportunityId,
        "status": value,
        "declineReason": reasonTxtController.text,
      };
      print("map:-" + map.toString());

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_OPPORTUNITY_APPROVE, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
              showSucessMsg(msg, 3000, 2);
            setState(() {});
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  void conformationDialogForCommunityPost(msg, value) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: msg,
          onPositiveTap: (){
            apiCallingForUpdate(value);
          },
        );
      },
    );
  }


  void conformationDialogForCommunityPostold(msg, value) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 200.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                msg,
                                                textAlign: TextAlign.center,
                                                maxLines: 5,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    height: 1.2,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                            ]),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "Cancel",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .GREY_TEXT_COLOR,
                                              fontSize: 16.0,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "Ok",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 16.0,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.pop(context);
                                          apiCallingForUpdate(value);
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }


  Widget _loader(BuildContext context) => Center(
      child: Container(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }



  Widget _negativeButton({@required String title}) {
    return InkWell(
      onTap: () {
      //  showRejectionAlert();
        showRejectWithReasonPopUp(context);
      },
      child: Container(
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          border: Border.all(color: Color(0xffB2BDDB)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: AppConstants.colorStyle.lightPurple,
            fontFamily: AppConstants.stringConstant.latoRegular,
            fontSize: 18,
          ),
        ),
      ),
    );
  }

  uploadGoogleDocLink() {
    return Column(
      children: <Widget>[
        Column(
          children: List.generate(opportunity.googleLinkList.length, (index) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                    child: InkWell(
                      child: Text(
                        opportunity.googleLinkList[index].label.trim() ==
                            "null"
                            ? opportunity.googleLinkList[index].file.trim()
                            : opportunity.googleLinkList[index].label.trim(),
                        style: TextStyle(
                            color: Palette.accentColor,
                            fontSize: 14,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      ),
                      onTap: () {
                        String url = "";
                        if (opportunity.googleLinkList[index].file
                            .contains("http")) {
                          url = opportunity.googleLinkList[index].file;
                        } else {
                          url = "http://" +
                              opportunity.googleLinkList[index].file;
                        }
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) =>
                                    WebViewWidget(url, "spikeview")));
                      },
                    ),
                  ),
                ),
              ],
            );
          }),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {

    final docListUiData = Container(
        padding: const EdgeInsets.fromLTRB(0.0, 18.0, 0.0, 0.0),
        child: Wrap(
          runSpacing: 10,
          spacing: 10,
          // primary: false,
          // shrinkWrap: true,
          // padding: const EdgeInsets.all(0.0),
          // crossAxisSpacing: 10.0,
          // childAspectRatio: 0.7,
          // scrollDirection: Axis.vertical,
          // crossAxisCount: 4,
          children: mediaDocumentList.map((file) {
            var fileName;
            String docName = "";
            if (file.file != null) {
              fileName = file.file.split("/");
              if (fileName != null && fileName.length > 0) {
                docName = fileName[fileName.length - 1];
              }
            }
            print('Apurva docListUiData docName:: $docName, file:: $file');

            return InkWell(
              onTap: () {
                print("DOC++++" +
                    Constant.IMAGE_PATH +
                    file.file);
                launch(Constant.IMAGE_PATH +
                    (file.file).replaceAll("pdf'", 'pdf'));
              },
              child: Container(
                  height: 60.0,
                  width: 62.0,
               
                  child: Image.asset(
                    "assets/resume/ic_doc_pdf.png",
                    height: 60.0,
                    width: 62.0,
                  )),
            );
          }).toList() ??
              [],
        ));

    return WillPopScope(
        onWillPop: () {
          onBack();
          return Future.value(false);
        },
        child: customAppbar(
          context,
          GestureDetector(
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());
              },
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0, right: 20, top: 24, bottom: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox()
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Padding(
                        padding: const EdgeInsets.only(left: 20.0, right: 20),
                        child: SingleChildScrollView(
                          child: Container(
                            child: opportunity != null
                                ? opportunity.partnerStatus == "Active"
                                    ? Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 0.0, bottom: 20),
                                            child: Text(
                                              "Opportunity ",
                                              // "${opportunity.status} opportunity",
                                              style: TextStyle(
                                                  fontSize: 28,
                                                  fontFamily:
                                                      Constant.latoSemibold,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1),
                                            ),
                                          ),
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              //
                                              opportunity.assestVideoAndImage
                                                          .length >
                                                      0
                                                  ? SizedBox(
                                                      // Pager view
                                                      height: 215.50,
                                                      child:
                                                          PageIndicatorContainer(
                                                        pageView:
                                                            PageView.builder(
                                                          itemCount: opportunity
                                                              .assestVideoAndImage
                                                              .length,
                                                          controller:
                                                              PageController(),
                                                          itemBuilder: (context,
                                                              index2) {
                                                            return Stack(
                                                                children: <
                                                                    Widget>[
                                                                  opportunity.assestVideoAndImage[index2].type ==
                                                                          "image"
                                                                      ?
                                                                      
                                                                       ClipRRect(
                                                                              borderRadius: BorderRadius.circular(10),     
                                                                                                                                                child: Container(
                                                                            decoration:
                                                                                BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(10)),
                                                                            child: CachedNetworkImage(
                                                                                width: double.infinity,
                                                                                height: 215.50,
                                                                                imageUrl: Constant.IMAGE_PATH + opportunity.assestVideoAndImage[index2].file,
                                                                                fit: BoxFit.contain,
                                                                                placeholder: (context, url) => _loader(context),
                                                                                errorWidget: (context, url, error) => _error(),
                                                                              )),
                                                                       )
                                                                      : InkWell(
                                                                          child: Container(
                                                                          decoration:
                                                                              BoxDecoration(
                                                                            color: Colors.black,
                                                                            borderRadius: BorderRadius.circular(10),
                                                                          ),
                                                                          height:
                                                                              215.50,
                                                                          child:
                                                                              Center(child: VideoPlayPause(opportunity.assestVideoAndImage[index2].file, "", true)),
                                                                        )),
                                                                  opportunity.assestVideoAndImage.length ==
                                                                              1 ||
                                                                          opportunity.assestVideoAndImage[index2].type ==
                                                                              "video"
                                                                      ? Container(
                                                                          height:
                                                                              0.0,
                                                                        )
                                                                      : new InkWell(
                                                                          onTap:
                                                                              () {
                                                                            Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => CommonFullViewWidget(opportunity.assestVideoAndImage, MessageConstant.ACCOMPLISHMENT_HEDING, index2, MessageConstant.VIEWER_END_REWCOMMENDATION_HEDING)));
                                                                          },
                                                                          child:
                                                                              Container(
                                                                            height: 215.50,
                                                                            width: double.infinity,
                                                                            child: Image.asset(
                                                                              "assets/newDesignIcon/navigation/layer_image.png",
                                                                              fit: BoxFit.fill,
                                                                            ),
                                                                          ))
                                                                ]);
                                                          },
                                                          onPageChanged:
                                                              (index) {},
                                                        ),
                                                        align: IndicatorAlign
                                                            .bottom,
                                                        length: opportunity
                                                            .assestVideoAndImage
                                                            .length,
                                                        indicatorSpace: 10.0,
                                                        indicatorColor: opportunity
                                                                    .assestVideoAndImage
                                                                    .length ==
                                                                1
                                                            ? Colors.transparent
                                                            : Color(0xffc4c4c4),
                                                        indicatorSelectorColor:
                                                            opportunity.assestVideoAndImage
                                                                        .length ==
                                                                    1
                                                                ? Colors
                                                                    .transparent
                                                                : ColorValues
                                                                    .WHITE,
                                                        shape: IndicatorShape
                                                            .circle(size: 5.0),
                                                      ))
                                                  : Stack(children: <Widget>[
                                                      Image.asset(
                                                        "assets/profile/default_achievement.png",
                                                        fit: BoxFit.cover,
                                                        height: 215.50,
                                                        width: double.infinity,
                                                      ),
                                                      Container(
                                                        height: 215.50,
                                                        color: Colors.black54
                                                            .withOpacity(.4),
                                                      )
                                                    ])),
                                          UIHelper.verticalSpaceMedium,
                                          Container(
                                            width: double.infinity,
                                            margin: EdgeInsets.all(0),
                                            padding: EdgeInsets.all(0),
                                            // decoration: rectangleDecoration(),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Container(
                                                  width: double.infinity,
                                                  padding: EdgeInsets.all(0),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: <Widget>[
                                                      Text(
                                                        opportunity.offerId ==
                                                                    "4" ||
                                                                opportunity
                                                                        .offerId ==
                                                                    "5"
                                                            ? opportunity
                                                                .serviceTitle
                                                            : opportunity
                                                                .jobTitle,
                                                        //: "College Counselling",
                                                        style: TextStyle(
                                                            fontSize: 20,
                                                            fontFamily: Constant
                                                                .latoSemibold,
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1),
                                                      ),

                                                      UIHelper
                                                          .verticalSpaceSmall,

                                                      RichText(
                                                        text: TextSpan(
                                                            text: secondHalfDesc ==
                                                                        null &&
                                                                    secondHalfDesc ==
                                                                        ""
                                                                ? firstHalfDesc
                                                                : flagDesc
                                                                    ? (firstHalfDesc +
                                                                        "")
                                                                    : (firstHalfDesc +
                                                                        secondHalfDesc),
                                                            style: TextStyle(
                                                                fontSize: 12,
                                                                fontFamily: Constant
                                                                    .latoRegular,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                color: ColorValues
                                                                    .labelColor),
                                                            children: [
                                                              TextSpan(
                                                                text: secondHalfDesc ==
                                                                        ''
                                                                    ? ''
                                                                    : flagDesc
                                                                        ? " More"
                                                                        : " Less",
                                                                style: AppTextStyle
                                                                    .getDynamicFont(
                                                                        ColorValues
                                                                            .BLUE_COLOR,
                                                                        12,
                                                                        FontType
                                                                            .Regular),
                                                                recognizer:
                                                                    TapGestureRecognizer()
                                                                      ..onTap =
                                                                          () {
                                                                        print(
                                                                            'Tap Here onTap');
                                                                        setState(
                                                                            () {
                                                                          flagDesc =
                                                                              !flagDesc;
                                                                        });
                                                                      },
                                                              )
                                                            ]),
                                                      ),
                                                      UIHelper
                                                          .verticalSpaceSmall,
                                                      opportunity.offerId ==
                                                                  "6" ||
                                                              opportunity
                                                                      .offerId ==
                                                                  "7" ||
                                                              opportunity
                                                                      .offerId ==
                                                                  "8"
                                                          ? getMentorAdvisorTutor()
                                                          : opportunity
                                                                          .offerId ==
                                                                      "1" ||
                                                                  opportunity
                                                                          .offerId ==
                                                                      "2" ||
                                                                  opportunity
                                                                          .offerId ==
                                                                      "3"
                                                              ? getJobInternship()
                                                              : Container(
                                                                  height: 0.0,
                                                                ),

                                                      opportunity.offerId ==
                                                                  "6" ||
                                                              opportunity
                                                                      .offerId ==
                                                                  "7" ||
                                                              opportunity
                                                                      .offerId ==
                                                                  "8"
                                                          ? UIHelper
                                                              .verticalSpaceMedium
                                                          : Container(
                                                              height: 0.0),


                                                      opportunity.offerId ==
                                                                  "6" ||
                                                              opportunity
                                                                      .offerId ==
                                                                  "7" ||
                                                              opportunity
                                                                      .offerId ==
                                                                  "8"
                                                          ? getScheduleWidget(
                                                              opportunity)
                                                          : Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: <
                                                                  Widget>[
                                                                UIHelper.verticalSpaceMedium,
                                                                otherInformationHeader(
                                                                    'Scheduled for '),
                                                                UIHelper
                                                                    .verticalSpaceSmall,
                                                                otherInformationValue(
                                                                  getConvertedDateStamp2(
                                                                          opportunity
                                                                              .fromDate) +
                                                                      " - " +
                                                                      getConvertedDateStamp2(
                                                                          opportunity
                                                                              .toDate),
                                                                ),
                                                              ],
                                                            ),

                                                      Padding(
                                                        padding: const EdgeInsets.fromLTRB(
                                                            0.0,
                                                            20,
                                                            0,
                                                            0),
                                                        child:
                                                        otherInformationHeader(
                                                            'Expiration date ')

                                                      ),

                                                      UIHelper
                                                          .verticalSpaceSmall,

                                                    otherInformationValue(getConvertedDateStamp2(opportunity.expiresOn))



                                              ],
                                                  ),
                                                ),




                                            Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: [
                                                    Expanded(
                                                      child:
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets.fromLTRB(
                                                            0.0,
                                                            20,
                                                            0,
                                                            0),
                                                        child:
                                                        otherInformationHeader(
                                                            'Call to action ')

                                                      ),
                                                      flex: 0,
                                                    ),
                                                    UIHelper
                                                        .verticalSpaceSmall,

                                                    Expanded(
                                                      child:
                                                      InkWell(
                                                        child:
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .fromLTRB(
                                                              0.0,
                                                              0.0,
                                                              5.0,
                                                              0.0),
                                                          child:
                                                          Padding(
                                                            padding: EdgeInsets.fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                6.0,
                                                                0.0),
                                                            child:
                                                            Text(
                                                              opportunity.actionType == Constant.LINK_URL
                                                                  ? opportunity.linkUrlPosition == Constant.LEARN_MORE
                                                                  ? "Learn more"
                                                                  : opportunity.linkUrlPosition == Constant.GET_OFFER
                                                                  ? "Get offer"
                                                                  : "Apply now"
                                                                  : opportunity.actionType == Constant.JOIN_GROUP
                                                                  ? "Join group"
                                                                  : opportunity.actionType == Constant.CALL_NOW
                                                                  ? "Call now"
                                                                  : "Inquire now",
                                                                style: TextStyle(
                                                                    fontFamily: Constant.latoMedium,
                                                                    fontSize: 14,
                                                                    color: Palette.accentColor,
                                                                    fontWeight: FontWeight.w600),


                                                            ),
                                                          ),
                                                        ),
                                                        onTap: () {
                                                          //apiCallingForIncreaseCount();
                                                          if (opportunity
                                                              .actionType ==
                                                              Constant
                                                                  .LINK_URL) {
                                                            print(
                                                                "OnClick++++++++++++++++++++++++++");
                                                            print("OnClick++++++++++++++++++++++++++" +
                                                                opportunity.url);
                                                            Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                  //   builder: (context) =>  DashBoardWidget()));
                                                                    builder: (context) =>  WebViewWidget(
                                                                        opportunity.url.contains("http") ? opportunity.url : "https://" + opportunity.url,
                                                                        opportunity.linkUrlPosition == Constant.LEARN_MORE
                                                                            ? "Learn More"
                                                                            : opportunity.linkUrlPosition == Constant.GET_OFFER
                                                                            ? "Get Offer"
                                                                            : "Apply Now")));
                                                          } else if (opportunity
                                                              .actionType ==
                                                              Constant
                                                                  .JOIN_GROUP) {
                                                            Navigator.of(Constant.applicationContext).push(new MaterialPageRoute(
                                                                builder: (BuildContext context) =>  GroupDetailWidget(
                                                                    opportunity.groupIdAction,
                                                                    "",
                                                                    "",
                                                                    "",
                                                                    "")));
                                                          } else if (opportunity
                                                              .actionType ==
                                                              Constant
                                                                  .CALL_NOW) {
                                                            String
                                                            callingNumber =
                                                                opportunity.callingNumber;
                                                            launch("tel:" +
                                                                callingNumber);
                                                          } else {
                                                            Navigator.of(context).push(new MaterialPageRoute(
                                                                builder: (BuildContext context) =>  InquireNowScreen(
                                                                    opportunity.opportunityId,
                                                                    userIdPref,
                                                                    opportunity.formId,
                                                                    opportunity.offerId.toString(),
                                                                    "")));
                                                          }
                                                        },
                                                      ),
                                                      flex: 0,
                                                    )
                                                  ],
                                                ),

                                          widget.pageName ==
                                              'preview'
                                              ? Column(
                                            children: <
                                                Widget>[
                                              UIHelper
                                                  .verticalSpaceSmall,
                                              otherInformationHeader(
                                                  'Expiration date '),
                                              UIHelper
                                                  .verticalSpaceSmall,

                                              otherInformationValue(getConvertedDateStamp2(opportunity.expiresOn))

                                            ],
                                          )
                                              : Container(
                                            height: 0.0,
                                          ),

                                                opportunity.docList.length ==
                                                            0 ||
                                                        opportunity.offerId ==
                                                            "6"
                                                    ? Container(
                                                        height: 0.0,
                                                      )
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0,
                                                                20.0,
                                                                0.0,
                                                                0.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            otherInformationHeader(
                                                                'Documents'),
                                                            opportunity.docList
                                                                    .isNotEmpty
                                                                ? docListUiData
                                                                : Container(),
                                                          ],
                                                        )),
                                                opportunity.offerId == "7" ||
                                                        opportunity.offerId ==
                                                            "8"
                                                    ? Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          opportunity != null &&
                                                                  opportunity
                                                                          .userImageModelParam
                                                                          .length >
                                                                      0
                                                              ? PaddingWrap
                                                                  .paddingfromLTRB(
                                                                      0.0,
                                                                      20.0,
                                                                      15.0,
                                                                      0.0,
                                                                      otherInformationHeader(
                                                                          "${opportunity.offerId == "8" ? "Advisors photo" : "Mentor photo"}"))
                                                              : Container(
                                                                  height: 0.0,
                                                                ),
                                                          userImageListUI(),
                                                        ],
                                                      )
                                                    : Container(),
                                                opportunity.offerId == "6" ||
                                                        opportunity.offerId ==
                                                            "7" ||
                                                        opportunity.offerId ==
                                                            "8"
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .fromLTRB(
                                                          0.0,
                                                          2.0,
                                                          0.0,
                                                          0.0,
                                                        ),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            UIHelper
                                                                .verticalSpaceMedium,
                                                            otherInformationHeader(
                                                                "Bio"),
                                                            UIHelper
                                                                .verticalSpaceExtraSmall,
                                                            RichText(
                                                              text: TextSpan(
                                                                  text: secondHalf ==
                                                                          ""
                                                                      ? firstHalf
                                                                      : flag
                                                                          ? (firstHalf +
                                                                              "")
                                                                          : (firstHalf +
                                                                              secondHalf),
                                                                  //style: underlineStyle.copyWith(decoration: TextDecoration.none),
                                                                  style:
                                                                      TextStyle(
                                                                    color: ColorValues
                                                                        .labelColor,
                                                                    fontFamily:
                                                                        Constant
                                                                            .latoRegular,
                                                                    fontSize:
                                                                        14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600,
                                                                  ),
                                                                  children: [
                                                                    TextSpan(
                                                                      text: secondHalf ==
                                                                              ''
                                                                          ? ''
                                                                          : flag
                                                                              ? " More"
                                                                              : " Less",
                                                                      style: AppTextStyle.getDynamicFont(
                                                                          ColorValues
                                                                              .BLUE_COLOR,
                                                                          14,
                                                                          FontType
                                                                              .Regular),
                                                                      recognizer:
                                                                          TapGestureRecognizer()
                                                                            ..onTap =
                                                                                () {
                                                                              print('Tap Here onTap');
                                                                              setState(() {
                                                                                flag = !flag;
                                                                              });
                                                                            },
                                                                    )
                                                                  ]),
                                                            ),
                                                          ],
                                                        ),
                                                      )
                                                    : Container(),
                                                opportunity.docList.length !=
                                                            0 &&
                                                        opportunity.offerId ==
                                                            "6"
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0,
                                                                20.0,
                                                                0.0,
                                                                0.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            otherInformationHeader(
                                                                'Teaching certifications'),

                                                            // mediaLabelText(
                                                            //     'Teaching Certifications'),

                                                            opportunity.docList
                                                                    .isNotEmpty
                                                                ? docListUiData
                                                                : Container(),
                                                          ],
                                                        ))
                                                    : Container(
                                                        height: 0.0,
                                                      ),
                                                opportunity.googleLinkList
                                                            .length ==
                                                        0
                                                    ? Container(
                                                        height: 0.0,
                                                      )
                                                    : Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0,
                                                                20.0,
                                                                0.0,
                                                                0.0),
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            otherInformationHeader(
                                                                'Additional link(s) '),

                                                            // mediaLabelText('Additional Link(s): '),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 0.0),
                                                              child:
                                                                  uploadGoogleDocLink(),
                                                            ),
                                                          ],
                                                        )),
                                              ],
                                            ),
                                          ),


                                          opportunity.targetAudience ==
                                              "true"
                                              ?
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              24.0,
                                              0.0,
                                              0.0,
                                              Container(
                                                  decoration: BoxDecoration(
                                                    color: ColorValues.SELECTION_BG,
                                                    borderRadius: BorderRadius.circular(10),
                                                  ),
                                                  // Border.all(color: ColorValues.BORDER_COLOR, width: 0.5)),
                                                  child: Column(
                                                      children: <Widget>[

                                                        Container(
                                                          clipBehavior: Clip.antiAlias,
                                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                                                          decoration: BoxDecoration(
                                                            color:const Color(0xffE8ECFF),
                                                            borderRadius: BorderRadius.vertical(
                                                              top: Radius.circular(10),
                                                            ),
                                                          ),
                                                          child: Padding(
                                                            padding: const EdgeInsets.only(top: 4,bottom: 4),
                                                            child: Row(

                                                              children: [
                                                                const SizedBox(width: 10),

                                                                Expanded(
                                                                  child: Text(
                                                                    "Other Information",
                                                                    style: TextStyle(
                                                                      color: const Color(0xff27275A),
                                                                      fontSize: 16,
                                                                      fontWeight: FontWeight.w600,
                                                                      fontFamily: AppConstants.stringConstant.latoMedium,
                                                                    ),
                                                                  ),
                                                                ),
                                                                const SizedBox(width: 10),
                                                                const SizedBox(width: 5)
                                                              ],
                                                            ),
                                                          ),
                                                        ),

                                                        opportunity.targetAudience ==
                                                            "true"
                                                            ?
                                                        Align(
                                                            alignment: Alignment.topLeft,
                                                            child:

                                                            Container(
                                                                padding: EdgeInsets.fromLTRB(20, 0, 0, 8),
                                                                child: Column(
                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    children: <Widget>[
                                                                      // UIHelper.verticalSpaceSmall,

                                                                      location != ""
                                                                          ? Padding(
                                                                        padding: const EdgeInsets.only(
                                                                            top: 15, bottom: 5),
                                                                        child: Column(
                                                                          crossAxisAlignment:
                                                                          CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                          MainAxisAlignment.start,
                                                                          children: <Widget>[
                                                                            otherInformationHeader(
                                                                                'Location you like to cover'),
                                                                            SizedBox(
                                                                              height: 8,
                                                                            ),
                                                                            otherInformationValue(
                                                                                location.trim()),
                                                                          ],
                                                                        ),
                                                                      )
                                                                          : Container(
                                                                        height: 0.0,
                                                                      ),

                                                                      opportunity.gender ==
                                                                          ""
                                                                          ? Container(
                                                                        height: 0.0,
                                                                      )
                                                                          : Container(
                                                                        child: Padding(
                                                                          padding: const EdgeInsets.only(
                                                                              top: 20),
                                                                          child: Column(
                                                                            crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                            mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                            children: <Widget>[
                                                                              // UIHelper.verticalSpaceMedium,
                                                                              otherInformationHeader(
                                                                                  'Gender'),
                                                                              SizedBox(
                                                                                height: 8,
                                                                              ),
                                                                              otherInformationValue(
                                                                                  opportunity
                                                                                      .gender),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),

                                                                      // UIHelper.verticalSpaceMedium,
                                                                      opportunity
                                                                          .ageList.length ==
                                                                          0
                                                                          ? Container(
                                                                        height: 0.0,
                                                                      )
                                                                          : Column(
                                                                        crossAxisAlignment:
                                                                        CrossAxisAlignment.start,
                                                                        mainAxisAlignment:
                                                                        MainAxisAlignment.start,
                                                                        children: <Widget>[
                                                                          SizedBox(
                                                                            height: 20,
                                                                          ),
                                                                          otherInformationHeader(
                                                                              'Age group'),
                                                                          SizedBox(
                                                                            height: 3,
                                                                          ),
                                                                          getAgeList(),
                                                                        ],
                                                                      ),

                                                                      opportunity
                                                                          .interestTypeList.length ==
                                                                          0
                                                                          ? Container(
                                                                        height: 0.0,
                                                                      )
                                                                          : Column(
                                                                          crossAxisAlignment:
                                                                          CrossAxisAlignment.start,
                                                                          mainAxisAlignment:
                                                                          MainAxisAlignment.start,
                                                                          children: <Widget>[
                                                                            SizedBox(
                                                                              height: 20,
                                                                            ),
                                                                            otherInformationHeader(
                                                                                'Interests'),
                                                                            SizedBox(
                                                                              height: 4,
                                                                            ),


                                                                            /*
                                          List.generate(
                                              selectedDataOpportunityPreview
                                                  .interestTypeList
                                                  .length, (index) {
                                            return otherInformationValue(
                                                selectedDataOpportunityPreview
                                                    .interestTypeList[
                                                index]
                                                    .name);
                                          }),


                                               */
                                                                            Container(
                                                                                decoration: BoxDecoration(
                                                                                  //color: Colors.white,
                                                                                  // border:  Border.all(
                                                                                  //     color:   ColorValues.DEVIDER_COLOR,
                                                                                  //     width: 1.0)
                                                                                ),
                                                                                child: Wrap(
                                                                                  spacing: 0.0,
                                                                                  runSpacing: 0.0,
                                                                                  children: opportunity
                                                                                      .interestTypeList.map((level) {
                                                                                    return Padding(
                                                                                        padding: const EdgeInsets.only(left: 0,right: 10,top: 5,bottom: 5),
                                                                                        child: Container(
                                                                                          decoration: BoxDecoration(
                                                                                            color: ColorValues.DARK_YELLOW,
                                                                                            borderRadius: BorderRadius.circular(6),
                                                                                          ),
                                                                                          child: Padding(
                                                                                            padding: const EdgeInsets.only(left: 8,right: 8,top: 5,bottom: 5),
                                                                                            child: Row(
                                                                                              mainAxisSize: MainAxisSize.min,
                                                                                              children: [
                                                                                                InkWell(
                                                                                                  onTap: () {

                                                                                                  },
                                                                                                  child: Text(
                                                                                                    '${level.name}',
                                                                                                    style: TextStyle(
                                                                                                      fontSize: 12.0,
                                                                                                      fontFamily: Constant.latoRegular,
                                                                                                      fontWeight: FontWeight.w400,
                                                                                                      color: Colors.white,
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        )


                                                                                    );
                                                                                  }).toList(),
                                                                                )

                                                                            ),


                                                                            UIHelper.verticalSpaceSmall,

                                                                          ]
                                                                      )


                                                                    ])

                                                            )
                                                        ): const SizedBox()

                                                      ])
                                              )
                                          ) : const SizedBox(),
                                          const SizedBox(height: 20,)

                                        ],
                                      )
                                    : Center(
                                        child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            height: 100,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                30.0, 0, 30, 0),
                                            child: RichText(
                                              maxLines: 8,
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                text:
                                                    "Partner account pending approval. Opportunity cannot be approved until account is approved.",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                    fontSize: 16.0,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontFamily:
                                                        Constant.latoRegular),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 40.0, 15, 50),
                                            child: InkWell(
                                              child: Container(
                                                  decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .BLUE_COLOR_BOTTOMBAR,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5)),
                                                  width: double.infinity,
                                                  height: 40.0,
                                                  child: Center(
                                                    child: Text(
                                                      "Review Partner Account",
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    ),
                                                  )),
                                              onTap: () {
                                                Navigator.of(context).pushReplacement(
                                                    MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            PatnerProfileWidgetForBoatReview(
                                                              opportunity
                                                                  .userId,
                                                              widget.pageName,
                                                              opportunityId:
                                                                  opportunityId,
                                                            )));
                                              },
                                            ),
                                          )
                                        ],
                                      ))
                                : Container(
                                    height: 0.0,
                                  ),
                          ),
                        )),
                    flex: 1,
                  ),
                ],
              )),
          () {
            Navigator.pop(context);
          },
          isShowIcon: false,

          bottomNavigation:  opportunity != null ? opportunity.status == "Pending" ||
              opportunity.status ==
                  "Created"
              ? Container(
            padding:
            const EdgeInsets.fromLTRB(
                20, 0, 20, 0),
            height: 90,
            //currentStep == 0 ? 0 : 90,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Color.fromRGBO(204, 220, 247, 0.46),
                  blurRadius: 13,
                  spreadRadius: 10,
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 30,
                  //currentStep >= 0 ? 30 : 1,
                  child: _negativeButton(
                      title: 'Reject'),
                ),
                Expanded(
                  flex: 66,
                  child: Padding(
                    padding:
                    const EdgeInsets
                        .only(
                        left: 12),
                    child: SizedBox(
                      height: 44,
                      child:
                      PositiveButton(
                        onTap: () {
                          conformationDialogForCommunityPost(
                              "Are you sure you want to approve this post?",
                              "Active");
                        },
                        // isEnable: true,
                        isEnable: true,
                        title: 'Approve',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )
              : Container(
            height: 0.0,
          ) : const SizedBox(),
        )
        );
  }

  otherInformationHeader(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600),
    );
  }

  otherInformationHeaderBold(String title) {
    return Text(
      title,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 12,
          color: ColorValues.HEADING_COLOR_EDUCATION_1,
          fontWeight: FontWeight.w600),
    );
  }

  otherInformationValue(String value) {
    return Text(
      value,
      textAlign: TextAlign.start,
      style: TextStyle(
          fontFamily: Constant.latoRegular,
          fontSize: 14,
          color: ColorValues.labelColor,
          fontWeight: FontWeight.w600),
    );
  }


  Widget showRejectWithReasonPopUp(context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.white,
        isScrollControlled: true,
        builder: (BuildContext context) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter myState
                  /*You can rename this!*/) {
                return customAppbar(
                    context,

                    SingleChildScrollView(
                      child: Form(
                          key: _mpportunityRejectionFormKey,
                          child: Container(
                            padding: EdgeInsets.only(
                              bottom: MediaQuery.of(context).viewInsets.bottom,
                              left: 0, //11.0,
                              right: 0, // 11.0,
                            ),

                            child: Container(
                             // height: 275.0,
                              //color: Colors.black.withOpacity(0.8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                      padding: const EdgeInsets.only(
                                          left: 20.0,
                                          right: 0.0,
                                          top: 25.0,
                                          bottom: 0),
                                      child: RichText(
                                        maxLines: 1,
                                        textAlign: TextAlign.center,
                                        text: TextSpan(
                                          text: 'Opportunity reject',
                                          style: AppConstants.txtStyle
                                              .heading400LatoRegularDarkBlue
                                              .copyWith(
                                              fontSize: 28,
                                              fontWeight: FontWeight.w700),
                                          children: [
                                            TextSpan(
                                                text: '',
                                                recognizer: TapGestureRecognizer()
                                                  ..onTap = () {},
                                                style: AppConstants.txtStyle
                                                    .heading40018LatoRegularDarkBlue
                                                    .copyWith(
                                                    fontSize: 28,
                                                    fontWeight:
                                                    FontWeight.w700)),
                                          ],
                                        ),
                                      )),

                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 20.0,
                                  right: 10.0,
                                  top: 10.0,
                                  bottom: 10),
                              child:Text(
                                "Please enter reason for rejecting the opportunity.",
                                textAlign:
                                TextAlign.left,
                                maxLines: 5,
                                style: TextStyle(
                                    color: ColorValues
                                        .labelColor,
                                    fontSize: 15.0,
                                    fontWeight:
                                    FontWeight.w500,
                                    fontFamily: Constant
                                        .latoRegular),
                              ),
                            ),


                                 Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20.0,
                                        right: 20.0,
                                        top: 15.0,
                                        bottom: 0),
                                    child:

                                    Container(
                                      padding: const EdgeInsets
                                          .symmetric(
                                          horizontal: 0.0,
                                          vertical: 0.0),
                                      child:

                                      CustomFormField(
                                        decoration: InputDecoration(
                                          hintStyle: TextStyle(
                                          color: ColorValues.hintColor,
                                          fontFamily: Constant.latoRegular,

                                          ),

                                            border: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: ColorValues
                                                        .BORDER_GENERATE_SCRIPT,
                                                    width: 1.0),
                                              borderRadius: BorderRadius.circular(10)

                                            ),
                                            focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: AppConstants.colorStyle.lightBlue,
                                                    width: 1.0),
                                                borderRadius: BorderRadius.circular(10)

                                            ),
                                            enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: AppConstants.colorStyle.btnBg, width: 1.0),
                                                borderRadius: BorderRadius.circular(10)

                                            ),
                                            disabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                    color: AppConstants.colorStyle.btnBg, width: 1.0),
                                                borderRadius: BorderRadius.circular(10)
                                            ),


                                        ),
                                        minLines: 12,

                                        textInputType: TextInputType.text,
                                        label: "",
                                        hint: "Write your reason",
                                       // onType: (value) => _checkValidation(),
                                        maxLength: 500,
                                        maxLines: 12 ,
                                        onSaved: (val){
                                          rejectionReason = val;
                                          setState(() {

                                          });
                                        },
                                        alignLabelWithHint: true,
                                        //focusNode: aboutNode,
                                        controller: reasonTxtController,
                                        // helperText:"",
                                        // helperTextStyle: TextStyle(
                                        //   color: const Color(0xff828282),
                                        //   fontFamily: Constant.latoRegular,
                                        //   fontWeight: FontWeight.w400,
                                        //   fontSize: 10,
                                        //   fontStyle: FontStyle.italic,
                                        // ),
                                        validation: (arg) {
                                          if (arg.length > 0) {
                                            /*if (ValidationWidget.isName(arg)) {
                                                          return null;
                                                        } else {
                                                          return MessageConstant.ENTER_CORRECT_INPUT_VAL;
                                                        }*/
                                            return null;
                                          } else {
                                            return MessageConstant
                                                .ENTER_PARTNER_REJECTION;
                                          }
                                        },
                                      ),


                                    ),

                                  ),


                                ],
                              ),
                            ),
                          )),
                    ), () {

                  Navigator.pop(context);
                },
                    bottomNavigation: Container(
                        child: Padding(
                            padding: EdgeInsets.only(
                                left: 20.0, top: 0.0, right: 20.0, bottom: 40.0),
                            child: Stack(
                              children: <Widget>[
                                Container(
                                    height: 44.0,
                                    width: double.infinity,
                                    child: FlatButton(
                                      onPressed: () async {
                                        //callZip();
                                       // callApiToValidateTheaReferalCode('');
                                        if (_mpportunityRejectionFormKey
                                            .currentState
                                            .validate()) {
                                          _mpportunityRejectionFormKey
                                              .currentState
                                              .save();
                                          Navigator.pop(context);
                                          apiCallingForUpdate("Decline");
                                        }
                                      },
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(10)),
                                      color: AppConstants.colorStyle.lightBlue,
                                      child: Row(
                                        // Replace with a Row for horizontal icon + text
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: <Widget>[
                                          Text("Add",
                                              style: AppConstants.txtStyle
                                                  .heading18600LatoRegularWhite),
                                        ],
                                      ),
                                    )),

                              ],
                            ))),
                    isShowExplanation: true,isShowIcon: false
                );
              });
        }).then((value) => (value) {});
  }




  showRejectionAlert() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 285.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 235.0,

                                        ///145
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Form(
                                          key: _mpportunityRejectionFormKey,
                                          child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[

                                                Text(
                                                  "Opportunity not approved",
                                                  textAlign: TextAlign.left,
                                                  //maxLines: 5,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      height: 1.2,
                                                      fontSize: 16.0,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                ),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          top: 10.0,
                                                          bottom: 20.0),
                                                  child: Text(
                                                    " Please enter reason(s) for rejecting the opportunity",
                                                    textAlign:
                                                        TextAlign.left,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 12.0,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color:
                                                        Color(0xffFEFEFE),
                                                    border: Border.all(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        width: 1.0),
                                                  ),
                                                  padding: const EdgeInsets
                                                          .symmetric(
                                                      horizontal: 15.0,
                                                      vertical: 12.0),
                                                  child: TextFormField(
                                                    controller:
                                                        reasonTxtController,
                                                    keyboardType:
                                                        TextInputType.text,
                                                    maxLines: 4,
                                                    textInputAction:
                                                        TextInputAction
                                                            .done,
                                                    focusNode: _reasonFocus,
                                                    onFieldSubmitted:
                                                        (term) {
                                                      //_fieldFocusChange(context, _emailFocus, _passwordFocus);
                                                    },
                                                    validator:
                                                        (String arg) {
                                                      if (arg.length > 0) {
                                                        /*if (ValidationWidget.isName(arg)) {
                                                          return null;
                                                        } else {
                                                          return MessageConstant.ENTER_CORRECT_INPUT_VAL;
                                                        }*/
                                                        return null;
                                                      } else {
                                                        return MessageConstant
                                                            .ENTER_PARTNER_REJECTION;
                                                      }
                                                    },
                                                    onSaved: (val) =>
                                                        rejectionReason =
                                                            val,
                                                    cursorColor: Constant
                                                        .CURSOR_COLOR,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR,
                                                        fontSize: 16,
                                                        fontWeight:
                                                            FontWeight
                                                                .w400),
                                                    decoration:
                                                        InputDecoration(
                                                      contentPadding:
                                                          const EdgeInsets
                                                                  .fromLTRB(
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              0.0),
                                                      border:
                                                          InputBorder.none,
                                                      hintText: "",
                                                      hintStyle: TextStyle(
                                                          color: ColorValues.hintColor,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR,
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight
                                                                  .w400),
                                                    ),
                                                  ),
                                                ),
                                              ]),
                                        ),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "Cancel",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color:
                                                  ColorValues.GREY__COLOR,
                                              fontSize: 16.0,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          //Navigator.of(context, rootNavigator: true).pop('dialog');

                                          Navigator.pop(context);
                                          reasonTxtController.text = '';
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "Submit",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 16.0,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          if (_mpportunityRejectionFormKey
                                              .currentState
                                              .validate()) {
                                            _mpportunityRejectionFormKey
                                                .currentState
                                                .save();
                                            Navigator.pop(context);
                                            apiCallingForUpdate("Decline");
                                          }
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  Widget getScheduleWidget(OpportunityModelForFeed opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        otherInformationHeader('Scheduled for '),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children:
              List.generate(opportunity.scheduleModelParam.length, (index) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: getHoursData(index),
            );
          }),
        ),
             SizedBox(height: 20),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            otherInformationHeader('Expiration date '),
            UIHelper.verticalSpaceSmall,
            otherInformationValue(
                getConvertedDateStamp2(opportunity.expiresOn)),
          ],
        ),
      ],
    ));
  }

  Widget getScheduleWidgetold(OpportunityModelForFeed opportunity) {
    print(
        'opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        UIHelper.verticalSpaceSmall,
        Text(
          'Scheduled For: ',
          style: AppTextStyle.getDynamicFontStyle(
              Palette.secondaryTextNewColor, 14, FontType.Regular),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children:
              List.generate(opportunity.scheduleModelParam.length, (index) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: getHoursData(index),
            );
          }),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 0),
          child: AppTextStyle.getLableTextForDetailNew('Expiration Date '),
        ),
        AppTextStyle.getTextForDetail(
            getConvertedDateStamp2(opportunity.expiresOn))
      ],
    ));
  }

  String getConvertedTime(int time) {
    String timeReturn = "";
    if (time != null) {
      int startTimeHour = DateTime.fromMillisecondsSinceEpoch(time).hour;
      int startTimeMinute = DateTime.fromMillisecondsSinceEpoch(time).minute;

      if (startTimeHour > 12) {
        String startTimeH = (startTimeHour - 12).toString();

        startTimeH = startTimeH.toString().length == 2
            ? startTimeH.toString()
            : "0" + startTimeH.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn = startTimeH.toString() + ":" + startTimeM + " pm";
      } else {
        String startTimeH = startTimeHour.toString().length == 2
            ? startTimeHour.toString()
            : "0" + startTimeHour.toString();
        String startTimeM = startTimeMinute.toString().length == 2
            ? startTimeMinute.toString()
            : "0" + startTimeMinute.toString();

        return timeReturn =
            startTimeH.toString() + ":" + startTimeM.toString() + " am";
      }
    } else {
      return "";
    }
  }


  Widget getAgeList() {
    return

      Container(
          decoration: BoxDecoration(
            //color: Colors.white,
            // border:  Border.all(
            //     color:   ColorValues.DEVIDER_COLOR,
            //     width: 1.0)
          ),
          child: Wrap(
            spacing: 0.0,
            runSpacing: 0.0,
            children: opportunity.ageList.map((level) {
              return Padding(
                  padding: const EdgeInsets.only(left: 0,right: 5,top: 5,bottom: 0),
                  child: Container(

                    child: Padding(
                      padding: const EdgeInsets.all(2.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          InkWell(
                            onTap: () {

                            },
                            child:

                            otherInformationValue(
                                level.from +
                                    "-" +
                                    level.to +
                                    " Years;"
                            ),
                            //   Text(
                            //     level.from +
                            //         "-" +
                            //         level.to +
                            //         " years;",
                            //     style: TextStyle(
                            //         fontFamily: Constant.latoRegular,
                            //         fontSize: 12,
                            //         color: ColorValues.labelColor,
                            //         fontWeight: FontWeight.w600
                            //     ),
                            //
                            //
                            // ),
                          )
                        ],
                      ),
                    ),
                  )


              );
            }).toList(),
          )


      );

    /*
      Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(selectedDataOpportunityPreview.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            selectedDataOpportunityPreview.ageList[index].from +
                "-" +
                selectedDataOpportunityPreview.ageList[index].to +
                " years ",
            style: TextStyle(
                fontFamily: Constant.latoRegular,
                fontSize: 14,
                color: ColorValues.labelColor,
                fontWeight: FontWeight.w600
            ),
          ),
        );
      }),
    );
      */
  }


  bottomWidgetDataTitleWidget(String text, Color color) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(color, 12, FontType.Regular),
    );
  }

  bottomWidgetDataValueWidget(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 24, FontType.Regular),
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  Widget getMentorAdvisorTutor() {
    print('opportunity.fees:: ${opportunity.fees}');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Category '),
            SizedBox(
              height: 9,
            ),
            otherInformationValue(categoryString),
          ],
        ),

        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceMedium,
        opportunity.offerId == "7"
            ? Container()
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  otherInformationHeader('Subject '),
                  SizedBox(
                    height: 8,
                  ),
                  otherInformationValue(subjectString),
                ],
              ),
        //opportunity.toMapStringSubject()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceMedium,
        opportunity.offerId == "7"
            ? Container()
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  otherInformationHeader('Qualification '),
                  SizedBox(
                    height: 8,
                  ),
                  otherInformationValue(opportunity.toMapStringQualification()),
                ],
              ),

        UIHelper.verticalSpaceMedium,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Fees '),
            SizedBox(
              height: 8,
            ),
            otherInformationValue(opportunity.fees == "0"
                ? MessageConstant.FEE_EMPTY_VAL
                : opportunity.fees),
          ],
        ),
      ],
    );
  }

  Widget getMentorAdvisorTutorold() {
    print('opportunity.fees:: ${opportunity.fees}');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetailNew('Category'),
        AppTextStyle.getTextForDetail(categoryString),
        //opportunity.toMapStringForDesignation()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall,
        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getLableTextForDetailNew('Subject '),

        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getTextForDetail(subjectString),
        //opportunity.toMapStringSubject()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall,
        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getLableTextForDetailNew('Qualification: '),

        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getTextForDetail(
                opportunity.toMapStringQualification()),

        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetailNew('Fees'),
        AppTextStyle.getTextForDetail(opportunity.fees == "0"
            ? MessageConstant.FEE_EMPTY_VAL
            : opportunity.fees),
      ],
    );
  }

  getHoursData(index) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text: TextSpan(
        text:
            opportunity.scheduleModelParam[index].day + ": " + getHours(index),
        style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
            fontFamily: Constant.latoRegular,
            color: ColorValues.labelColor),
        children: <TextSpan>[
          TextSpan(
            text: opportunity.timeZone == null ||
                    opportunity.timeZone == "" ||
                    opportunity.timeZone == "null"
                ? ""
                : "(" + opportunity.timeZone + ")",
            style: TextStyle(
                color: ColorValues.GREY__COLOR,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: Constant.customRegular),
          )
        ],
      ),
    );
  }

  String getHours(index) {
    String timeReturn = "";
    try {
      for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      return timeReturn;
    }
  }

  userImageListUIold() {
    return Container(
      child: opportunity != null && opportunity.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              15.0,
              10.0,
              Container(
                  child: GridView.count(
                      primary: false,
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(0.0),
                      crossAxisSpacing: 10.0,
                      childAspectRatio: 1.5,
                      scrollDirection: Axis.vertical,
                      crossAxisCount: 3,
                      children: List.generate(
                          opportunity.userImageModelParam.length, (index2) {
                        return Container(
                            child: Stack(
                          children: <Widget>[
                            InkWell(
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/aerial/default_img.png',
                                  image: Constant.IMAGE_PATH +
                                      opportunity
                                          .userImageModelParam[index2].file,
                                  height: 80.0,
                                  width: 120.0,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          CommonFullViewWidget(
                                              opportunity.userImageModelParam,
                                              MessageConstant.HOME_HEDING,
                                              index2,
                                              MessageConstant
                                                  .VIEWER_END_REWCOMMENDATION_HEDING)));
                                }),
                          ],
                        ));
                      })
                      ),),)
          : Container(
              height: 0.0,
            ),
    );
  }

  userImageListUI() {
    return Container(
      child: opportunity != null && opportunity.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
              0.0,
              10.0,
              15.0,
              0.0,
              Container(
                  child: GridView.count(
                      primary: false,
                      shrinkWrap: true,
                      padding: const EdgeInsets.all(0.0),
                      crossAxisSpacing: 10.0,
                      childAspectRatio: 1.5,
                      scrollDirection: Axis.vertical,
                      crossAxisCount: 3,
                      children: List.generate(
                          opportunity.userImageModelParam.length, (index2) {
                        return Container(
                            child: Stack(
                          children: <Widget>[
                            InkWell(
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/aerial/default_img.png',
                                  image: Constant.IMAGE_PATH +
                                      opportunity
                                          .userImageModelParam[index2].file,
                                  height: 80.0,
                                  width: 120.0,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          CommonFullViewWidget(
                                              opportunity.userImageModelParam,
                                              MessageConstant.HOME_HEDING,
                                              index2,
                                              MessageConstant
                                                  .VIEWER_END_REWCOMMENDATION_HEDING)));

                                  /*  Navigator.push(
                                  context,
                                   HeroDialogRoute(
                                    builder: (BuildContext context) {
                                      return  Center(
                                        child:  AlertDialog(
                                          content:  Container(
                                            child:  Hero(
                                              tag: 'developer-hero',
                                              child:  Container(
                                                height: 200.0,
                                                width: 200.0,
                                                child: Image.network(
                                                  Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          path.file),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            ),
                                          ),
                                          actions: <Widget>[
                                             FlatButton(
                                              child:  Text('Close'),
                                              onPressed: Navigator.of(context).pop,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                );*/
                                }),
                          ],
                        ));
                      }))))
          : Container(
              height: 0.0,
            ),
    );
  }

  getJobInternship() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [

        SizedBox(
          height: 4,
        ),

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Job type '),
            SizedBox(
              height: 8,
            ),
            otherInformationValue(opportunity.jobType),
          ],
        ),
        UIHelper.verticalSpaceMedium,

        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            otherInformationHeader('Job location '),
            SizedBox(
              height: 8,
            ),
            otherInformationValue(opportunity.jobLocation),
          ],
        ),

      ],
    );
  }

  getJobInternshipold() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetailNew('Job Type '),
        AppTextStyle.getTextForDetail(opportunity.jobType),
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetailNew('Job Location '),
        AppTextStyle.getTextForDetail(opportunity.jobLocation),
        //   UIHelper.verticalSpaceSmall,
      ],
    );
  }

  void getData() {
    //category
    if (opportunity.bio != null) {
      if (opportunity.bio.length > 150) {
        firstHalf = opportunity.bio.substring(0, 150);
        secondHalf = opportunity.bio.substring(150, opportunity.bio.length);
      } else {
        firstHalf = opportunity.bio;
        secondHalf = "";
      }
    }

    categoryString = opportunity.toMapStringForDesignation();
    if (opportunity.selectedDesignationCareerOption != null &&
        opportunity.selectedDesignationCareerOption.length > 0) {
      if (categoryString != "")
        categoryString = categoryString +
            " | " +
            opportunity.toMapStringForDesignationCareer();
      else
        categoryString = opportunity.toMapStringForDesignationCareer();
    }
    if (opportunity.selectedDesignationOtherOption != null &&
        opportunity.selectedDesignationOtherOption.length > 0) {
      if (categoryString != "")
        categoryString = categoryString +
            " | " +
            opportunity.toMapStringForDesignationOther();
      else
        categoryString = opportunity.toMapStringForDesignationOther();
    }

    //Subject
    subjectString = opportunity.toMapStringSubject();
    if (opportunity.selectedSubjectOtherOption != null &&
        opportunity.selectedSubjectOtherOption.length > 0) {
      if (subjectString != "")
        subjectString =
            subjectString + " | " + opportunity.toMapStringSubjectOther();
      else
        subjectString = opportunity.toMapStringSubjectOther();
    }

    descVal = '';
    if (opportunity.offerId == "1" ||
        opportunity.offerId == "2" ||
        opportunity.offerId == "3") {
      descVal = opportunity.project;
    } else if (opportunity.offerId == "4" || opportunity.offerId == "5") {
      descVal = opportunity.serviceDesc;
    } else {
      descVal = opportunity.description;
    }

    if (descVal != null) {
      if (descVal.length > 150) {
        firstHalfDesc = descVal.substring(0, 150);
        secondHalfDesc = descVal.substring(150, descVal.length);
      } else {
        firstHalfDesc = descVal;
        secondHalfDesc = "";
      }
    }

    setState(() {
      categoryString;
      subjectString;
      secondHalfDesc;
      firstHalfDesc;
    });
  }
}
