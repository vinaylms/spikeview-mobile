import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String icon;
  final Function() click;

  CustomAppBar({
    this.title,
    this.icon,
    this.click,
  });

  @override
  Size get preferredSize => const Size.fromHeight(100); //kToolbarHeight

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        padding: EdgeInsets.only(left:20,right: 20 ,top: 50),
        height: preferredSize.height,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                title,
                maxLines: 1,
                textAlign: TextAlign.start,
                style: AppConstants.txtStyle.heading28_700LatoRegularDarkBlue,
              ),
            ),
            GestureDetector(
              onTap: click,
              child: Image.asset(
                icon,
                height: 32,
                width: 32,
              ),
            ),
        ],),
      ),
    );
  }
}
