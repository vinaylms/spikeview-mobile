import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gallery/Accomplishment_Add_Screen.dart';
import 'package:spike_view_project/gallery/SelectCompetencyWidget.dart';
import 'package:spike_view_project/gallery/StudentSelectionIfUserIsParent.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';

class FullIMageViewGallery extends StatefulWidget {
  List<SharedMediaFile> images;

  FullIMageViewGallery(this.images);

  @override
  FullIMageViewGalleryState createState() =>
       FullIMageViewGalleryState(images);
}

class FullIMageViewGalleryState extends State<FullIMageViewGallery> {
  FullIMageViewGalleryState(this.images);

  //String selectedImageType = "media";
  List<SharedMediaFile> images =  List();
  final PageController controller =  PageController(viewportFraction: .2);
  List<StudentDataModel> listStudent =  List();
  int currentindex = 0;
  List<Assest> assestList =  List();
  SharedPreferences prefs;

  String userIdPref, roleId;
  int tapCount = 0;
  BuildContext context;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    if (roleId == "2") {
      prefs.setString(
          UserPreference.USER_ID, prefs.getString(UserPreference.PARENT_ID));
    }

    if (assestList.length == 0 || assestList.length < images.length) {
      showSucessMsg(MessageConstant.VIDEO_UPLOAD_NOT_SUPPORT_VAL, context);
    }
  }

  Future studentByParentApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await  ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_PARENT_STUDENTSBYPARENT +
              prefs.getString(UserPreference.PARENT_ID),
          "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            listStudent.clear();
            listStudent =
                ParseJson.parseMapStudentByParent(response.data['result']);

            if (listStudent != null) {
              setState(() {
                listStudent;
              });
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    _timer =  Timer(const Duration(milliseconds: 5000), () async {

      Navigator.pop(context);
      if (assestList.length == 0) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        onBack();
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xffFF0101),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  @override
  void initState() {
    super.initState();
    // TODO: implement initState
    for (int i = 0; i < images.length; i++) {
      if (images[i].path.toString().contains(".mp4") ||
          images[i].path.toString().contains(".mov") ||
          images[i].path.toString().contains(".MOV") ||
          images[i].path.toString().contains(".MP4")) {
      } else {
        assestList.add(new Assest("NC", "media", images[i].path,"", false));
      }
    }
    setState(() {
      assestList;
    });
    getSharedPreferences();
  }

  onBack() async {
    roleId = prefs.getString(UserPreference.ROLE_ID);
    if (roleId == "2") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => DashBoardWidgetParent(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    } else if (roleId == "4") {
      Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => DashBoardWidgetPartner(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    } else {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>  DashBoardWidget(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    }
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    isParentLogin() async {
      var isConnect = await ConectionDetecter.isConnected();

      if (isConnect) {
        await studentByParentApi(true);
        if (listStudent.length <= 1) {
          if (listStudent.length == 0) {
            ToastWrap.showToast(
                MessageConstant.REQUIRED_MIN_1_STUDENT_VAL, context);
          } else {
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>
                     Accomplishment_Add_Screen(
                        listStudent[0].userId, assestList)));

          }
        } else {
          Navigator.of(context).push(new MaterialPageRoute(
              builder: (BuildContext context) =>
                   StudentSelectionIfUserIsParent(assestList, listStudent)));
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    }

    ontapImageCropIcon(file, index) async {
      File imagePath = await ImageCropper.cropImage(
        sourcePath: file.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
      if (imagePath != null) {
        tapCount = 0;
        assestList[index].file = imagePath.path;
        assestList[index].type = "image";
        setState(() {
          tapCount;
          assestList;
        });
      } else {
      }
    }

    onCrop() async {
      for (int i = 0; i < assestList.length; i++) {
        if (assestList[i].type == "NC") {
          await ontapImageCropIcon(new File(assestList[i].file), i);
        }
      }
    }

    onTapNext() async {
      if (roleId != "4") {
        await onCrop();
        bool isCompleted = true;
        for (int i = 0; i < assestList.length; i++) {
          if (assestList[i].type == "NC") {
            isCompleted = false;
          }
        }

        if (isCompleted) {
          //ToastWrap.showToast("Completed", context);

          if (roleId == "2") {
            isParentLogin();
          } else {
            Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>
                     Accomplishment_Add_Screen(userIdPref, assestList)));

          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.NOT_AUTHORIZED_ACCESS_OUTSIDE_ACCOMPLISHMENT,
            context);
      }
    }

    return  Scaffold(
        backgroundColor: Colors.white,
        appBar:  AppBar(
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          elevation: 0.0,
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
               Expanded(
                child:  InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    onBack();
                  },
                ),
                flex: 0,
              ),
               Expanded(
                child:  Text(
                  "Add media",
                  textAlign: TextAlign.center,
                  style:  TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              )
            ],
          ),
          actions: <Widget>[
             Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                 InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      13.0,
                      0.0,
                      TextViewWrap.textView(
                          "Next",
                          TextAlign.start,
                           ColorValues.BLUE_COLOR_BOTTOMBAR,
                          16.0,
                          FontWeight.normal)),
                  onTap: () {
                    onTapNext();
                  },
                )
              ],
            )
          ],
          backgroundColor: Colors.white,
        ),
        body: assestList.length == 0
            ?  Column(children: <Widget>[CustomViews.getSepratorLine()])
            :  Column(
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                   Expanded(
                    child:  ListView(
                      children: <Widget>[
                         Container(
                            child:  Column(
                          mainAxisSize: MainAxisSize.max,
                          children: <Widget>[
                             Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                 Container(
                                    height: 250.0,
                                    child:  Stack(
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            13.0,
                                            20.0,
                                            13.0,
                                            20.0,
                                             Container(
                                              height: 250.0,
                                              width: double.infinity,
                                              child: Image.file(
                                                 File(
                                                    assestList[currentindex]
                                                        .file),
                                                fit: BoxFit.fitWidth,
                                              ),
                                            )),
                                         Align(
                                            alignment: Alignment.topRight,
                                            child: PaddingWrap.paddingfromLTRB(
                                                13.0,
                                                30.0,
                                                13.0,
                                                20.0,
                                                 Container(
                                                  height: 40.0,
                                                  width: 40,
                                                  color: Colors.black54
                                                      .withOpacity(.4),
                                                ))),
                                         Align(
                                            alignment: Alignment.topRight,
                                            child:  InkWell(
                                                child:
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        35.0,
                                                        15.0,
                                                        0.0,
                                                         Image.asset(
                                                          "assets/newIcon/cropper.png",
                                                          width: 25.0,
                                                          height: 25.0,
                                                        )),
                                                onTap: () {
                                                  ontapImageCropIcon(
                                                       File(assestList[
                                                              currentindex]
                                                          .file),
                                                      currentindex);
                                                }))
                                      ],
                                    )),
                                 Container(
                                  height: 100.0,
                                  child:  PageView.builder(
                                    physics:
                                         AlwaysScrollableScrollPhysics(),
                                    itemCount: assestList.length,
                                    controller: controller,
                                    itemBuilder: (context, index) {
                                      return  InkWell(
                                        child:  SizedBox(
                                            child: PaddingWrap.paddingAll(
                                                10.0,
                                                 Container(
                                                    decoration: currentindex ==
                                                            index
                                                        ?  BoxDecoration(
                                                            border:  Border
                                                                    .all(
                                                                color:
                                                                    Colors.blue,
                                                                width: 2.0))
                                                        : null,
                                                    child: Image.file(
                                                       File(assestList[index]
                                                          .file),
                                                      fit: BoxFit.cover,
                                                    )))),
                                        onTap: () {
                                          setState(() {
                                            currentindex = index;
                                          });
                                        },
                                      );
                                    },
                                    onPageChanged: (index) {
                                      setState(() {
                                        currentindex = index;
                                      });
                                    },
                                  ),

                                ),
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    5.0,
                                    PaddingWrap.paddingAll(
                                        5.0,
                                        TextViewWrap.textView(
                                            "Select tag for the image",
                                            TextAlign.center,
                                             Color(0xFF798EA1),
                                            16.0,
                                            FontWeight.bold))),
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                     Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                         Expanded(
                                            child: assestList[currentindex]
                                                        .tag ==
                                                    "media"
                                                ? PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                     InkWell(
                                                      child:  Container(
                                                          child:  Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0,
                                                                   Image
                                                                      .asset(
                                                                    "assets/newIcon/general_blue.png",
                                                                    height:
                                                                        25.0,
                                                                    width: 25.0,
                                                                  )),
                                                          PaddingWrap.paddingfromLTRB(
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                              5.0,
                                                              TextViewWrap.textView(
                                                                  " General",
                                                                  TextAlign
                                                                      .center,
                                                                    ColorValues.BLUE_COLOR,
                                                                  13.0,
                                                                  FontWeight
                                                                      .bold)),
                                                        ],
                                                      )),
                                                      onTap: () {
                                                        assestList[currentindex]
                                                            .tag = "media";
                                                        setState(() {
                                                          assestList;
                                                        });
                                                      },
                                                    ),
                                                  )
                                                : PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                     InkWell(
                                                      child:  Container(
                                                          child:  Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0,
                                                                   Image
                                                                      .asset(
                                                                    "assets/newIcon/general.png",
                                                                    height:
                                                                        25.0,
                                                                    width: 25.0,
                                                                  )),
                                                          PaddingWrap.paddingfromLTRB(
                                                              0.0,
                                                              5.0,
                                                              0.0,
                                                              5.0,
                                                              TextViewWrap.textView(
                                                                  " General",
                                                                  TextAlign
                                                                      .center,
                                                                  Colors.black,
                                                                  13.0,
                                                                  FontWeight
                                                                      .bold)),
                                                        ],
                                                      )),
                                                      onTap: () {
                                                        assestList[currentindex]
                                                            .tag = "media";
                                                        setState(() {
                                                          assestList;
                                                        });
                                                      },
                                                    )),
                                            flex: 1),
                                         Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                assestList[currentindex].tag ==
                                                        "certificates"
                                                    ?  InkWell(
                                                        child:  Container(
                                                            decoration:
                                                                 BoxDecoration(
                                                                    border:
                                                                        const Border(
                                                              right: const BorderSide(
                                                                  width: 0.8,
                                                                  color: Colors
                                                                      .grey),
                                                              left: const BorderSide(
                                                                  width: 0.8,
                                                                  color: Colors
                                                                      .grey),
                                                            )),
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: <
                                                                  Widget>[
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        5.0,
                                                                        0.0,
                                                                        0.0,
                                                                         Image
                                                                            .asset(
                                                                          "assets/newIcon/Certificate_blue.png",
                                                                          height:
                                                                              25.0,
                                                                          width:
                                                                              25.0,
                                                                        )),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    5.0,
                                                                    TextViewWrap.textView(
                                                                        " Certificates",
                                                                        TextAlign
                                                                            .center,
                                                                          ColorValues.BLUE_COLOR,
                                                                        13.0,
                                                                        FontWeight
                                                                            .bold)),
                                                              ],
                                                            )),
                                                        onTap: () {
                                                          assestList[currentindex]
                                                                  .tag =
                                                              "certificates";
                                                          setState(() {
                                                            assestList;
                                                          });
                                                        },
                                                      )
                                                    :  InkWell(
                                                        child:  Container(
                                                            decoration:
                                                                 BoxDecoration(
                                                                    border:
                                                                        const Border(
                                                              right: const BorderSide(
                                                                  width: 0.8,
                                                                  color: Colors
                                                                      .grey),
                                                              left: const BorderSide(
                                                                  width: 0.8,
                                                                  color: Colors
                                                                      .grey),
                                                            )),
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: <
                                                                  Widget>[
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        5.0,
                                                                        0.0,
                                                                        0.0,
                                                                         Image
                                                                            .asset(
                                                                          "assets/newIcon/Certificate_black.png",
                                                                          height:
                                                                              25.0,
                                                                          width:
                                                                              25.0,
                                                                        )),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    5.0,
                                                                    TextViewWrap.textView(
                                                                        " Certificates",
                                                                        TextAlign
                                                                            .center,
                                                                        Colors
                                                                            .black,
                                                                        13.0,
                                                                        FontWeight
                                                                            .bold)),
                                                              ],
                                                            )),
                                                        onTap: () {
                                                          assestList[currentindex]
                                                                  .tag =
                                                              "certificates";
                                                          setState(() {
                                                            assestList;
                                                          });
                                                        },
                                                      )),
                                            flex: 1),
                                         Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                assestList[currentindex].tag ==
                                                        "badges"
                                                    ?  InkWell(
                                                        child:  Container(
                                                            decoration:
                                                                 BoxDecoration(
                                                                    border:
                                                                        const Border(
                                                              right: const BorderSide(
                                                                  width: 0.8,
                                                                  color: Colors
                                                                      .grey),
                                                            )),
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: <
                                                                  Widget>[
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        5.0,
                                                                        0.0,
                                                                        0.0,
                                                                         Image
                                                                            .asset(
                                                                          "assets/newIcon/badge_blue.png",
                                                                          height:
                                                                              25.0,
                                                                          width:
                                                                              25.0,
                                                                        )),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    5.0,
                                                                    TextViewWrap.textView(
                                                                        " Badges",
                                                                        TextAlign
                                                                            .center,
                                                                          ColorValues.BLUE_COLOR,
                                                                        13.0,
                                                                        FontWeight
                                                                            .bold)),
                                                              ],
                                                            )),
                                                        onTap: () {
                                                          assestList[
                                                                  currentindex]
                                                              .tag = "badges";
                                                          setState(() {
                                                            assestList;
                                                          });
                                                        },
                                                      )
                                                    :  InkWell(
                                                        child:  Container(
                                                            decoration:
                                                                 BoxDecoration(
                                                                    border:
                                                                        const Border(
                                                              right: const BorderSide(
                                                                  width: 0.8,
                                                                  color: Colors
                                                                      .grey),
                                                            )),
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: <
                                                                  Widget>[
                                                                PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        0.0,
                                                                        5.0,
                                                                        0.0,
                                                                        0.0,
                                                                         Image
                                                                            .asset(
                                                                          "assets/newIcon/badge_black.png",
                                                                          height:
                                                                              25.0,
                                                                          width:
                                                                              25.0,
                                                                        )),
                                                                PaddingWrap.paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    5.0,
                                                                    TextViewWrap.textView(
                                                                        " Badges",
                                                                        TextAlign
                                                                            .center,
                                                                        Colors
                                                                            .black,
                                                                        13.0,
                                                                        FontWeight
                                                                            .bold)),
                                                              ],
                                                            )),
                                                        onTap: () {
                                                          assestList[
                                                                  currentindex]
                                                              .tag = "badges";
                                                          setState(() {
                                                            assestList;
                                                          });
                                                        },
                                                      )),
                                            flex: 1),
                                         Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                assestList[currentindex].tag ==
                                                        "trophy"
                                                    ?  InkWell(
                                                        child:  Container(
                                                            child:  Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    0.0,
                                                                     Image
                                                                        .asset(
                                                                      "assets/newIcon/trophy_blue.png",
                                                                      height:
                                                                          25.0,
                                                                      width:
                                                                          25.0,
                                                                    )),
                                                            PaddingWrap.paddingfromLTRB(
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                5.0,
                                                                TextViewWrap.textView(
                                                                    " Trophies",
                                                                    TextAlign
                                                                        .center,
                                                                      ColorValues.BLUE_COLOR,
                                                                    13.0,
                                                                    FontWeight
                                                                        .bold)),
                                                          ],
                                                        )),
                                                        onTap: () {
                                                          assestList[
                                                                  currentindex]
                                                              .tag = "trophy";
                                                          setState(() {
                                                            assestList;
                                                          });
                                                        },
                                                      )
                                                    :  InkWell(
                                                        child:  Container(
                                                            child:  Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                          children: <Widget>[
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    5.0,
                                                                    0.0,
                                                                    0.0,
                                                                     Image
                                                                        .asset(
                                                                      "assets/newIcon/trophy.png",
                                                                      height:
                                                                          25.0,
                                                                      width:
                                                                          25.0,
                                                                    )),
                                                            PaddingWrap.paddingfromLTRB(
                                                                0.0,
                                                                5.0,
                                                                0.0,
                                                                5.0,
                                                                TextViewWrap.textView(
                                                                    " Trophies",
                                                                    TextAlign
                                                                        .center,
                                                                    Colors
                                                                        .black,
                                                                    13.0,
                                                                    FontWeight
                                                                        .bold)),
                                                          ],
                                                        )),
                                                        onTap: () {
                                                          assestList[
                                                                  currentindex]
                                                              .tag = "trophy";
                                                          setState(() {
                                                            assestList;
                                                          });
                                                        },
                                                      )),
                                            flex: 1),
                                      ],
                                    )),
                              ],
                            )
                          ],
                        ))
                      ],
                    ),
                    flex: 1,
                  )
                ],
              ));
  }
}
