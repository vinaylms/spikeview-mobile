import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:confetti/confetti.dart';
import 'package:dio/dio.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/ClubTeamModel.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/LinkUrlDataModel.dart';

import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/StateModel.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/theme/palette.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/modal/FileModel.dart';

import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:path/path.dart' as path;
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';

import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfile.dart';
import 'package:spike_view_project/parentProfile/wizard/AddChildInterestWidget.dart';
import 'package:spike_view_project/parentProfile/wizard/AllAccomplishmentListWidget.dart';

import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';


import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class CompetenciesParentStudent extends StatefulWidget {
  String userEmail, userName;
  String sasToken;

  CompetenciesParentStudent(this.sasToken, this.userEmail, this.userName,
      this.studModel, this.pageName);

  StudentDataModel studModel;
  String pageName;

  @override
  CompetenciesStudentState createState() {
    return  CompetenciesStudentState();
  }
}

class CompetenciesStudentState extends State<CompetenciesParentStudent>
    with BaseCommonWidget {
  final _formKey = GlobalKey<FormState>();
  String userIdPref, userEmail, token;

  // List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  String isPerformChanges = "pop";
  List<CompetencyModel> listCompetency =  List();
  SharedPreferences prefs;
  bool isSelectedList = false;
  bool isSelectedLevel2 = false;
  int level2Position = 0;
  int level1Position = 0;

  //----------------------------
  String strAchievement = "",
      strFromDate = "",
      strToDate = "",
      strName = "",
      strEmail = "",
      strTitle = "",
      strWorkingHours = "",
      strCoachLastName = "",
      strCoachFirstName = "",
      strRecommendationTitle = "",
      strRecommendationRequest = "",
      strRecommenderTitle = "",
      strCoachEmail = "",
      strDeascription = "",
      strBio = "",
      strWeight = "",
      strHeight = "";

  TextEditingController fromDateController, toDateController;
  TextEditingController descController =  TextEditingController(text: "");
  TextEditingController bioController =  TextEditingController(text: "");
  TextEditingController titleController =  TextEditingController(text: "");

  List<AchievementImportanceModal> levelList =  List();
  List<AcvhievmentSkillModel> skillList =  List();
  List<Skill> skillsSelectedList =  List();
  List<Level3Competencies> level3Competencylist =  List();

  List<Assest> assestList =  List();
  List<String> mediaList =  List();
  List<String> certificateList =  List();
  List<Assest> badgeAndTrophyList =  List();
  Map<String, List<Level3Competencies>> competencyList =  Map();

  Level3Competencies competencySelected;
  String strCompetencyValue = "",
      strLevelValue = "",
      filterData = "",
      appliedFilter = "";
  Map<int, bool> filterStatus =  Map();
  File imagePath;
  AchievementImportanceModal levelSelected;
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "";
  String sasToken, containerName;

  static const platform = const MethodChannel('samples.flutter.io/battery');

  DateTime fromDate, toDate;
  bool isMedaiDialog = false;
  bool isShowMedia = true;
  bool isPrompt = false;
  FocusNode _focus =  FocusNode();
  DateTime startDate;
  bool isPresent = false;
  static StreamController syncDoneController = StreamController.broadcast();
  bool isPredefinedMediaSelected = true;
  List<String> imageList =  List();
  int selectedIndexCover = 0;

  ConfettiController _controllerConfetti;

  List<FileModel> mediaVideosList =  List();
  List<String> mediaAndVideoList =  List();

  UploadMedia uploadMedia;

  File mediaVideo;

  bool isPortFolioSelected = false;
  bool isAccSelected = false;

  String strAgeValue = "1", strFootValue = "1\'", strInchValue = "0\"";
  bool isValidHeight = true;
  bool isValidAge = true;
  List<LinkUrlDataModel> linkUrlListData =  List();
  List<MediaDataModelNew> mediaListData =  List();
  List<StateModel> stateListData =  List();
  List<ClubTeamModel> clubTeamList =  List();
  List<ClubTeamModel> highSchoolTeamList =  List();
  List<ClubTeamModel> collegeTeamList =  List();
  List<ClubTeamModel> otherTeamList =  List();
  bool isClubTeam = false;
  bool isHighSchoolTeam = false;
  bool isCollegeTeam = false;
  bool isOtherTeam = false;
  final _formKey2 = GlobalKey<FormState>();
  ScrollController _scrollController = ScrollController();

  String strCompetencyTypeId = "", strcompetencyTypeName = "";
  List<Level2Competencies> level2Competencylist =  List();
  List<int> yearList =  List();
  static  TextStyle styleForHeight = TextStyle(
      color: ColorValues.HEADING_COLOR_EDUCATION,
      fontSize: 18.0,
      fontFamily:Constant.TYPE_CUSTOMREGULAR);
  final List<String> footList = [
    "1\'",
    "2\'",
    "3\'",
    "4\'",
    "5\'",
    "6\'",
    "7\'",
    "8\'",
    "9\'",
    "10\'",
  ].toList();

  final List<String> inchList = [
    "0\"",
    "1\"",
    "2\"",
    "3\"",
    "4\"",
    "5\"",
    "6\"",
    "7\"",
    "8\"",
    "9\"",
    "10\"",
    "11\"",
    "12\"",
  ].toList();
  FocusNode workinHoursFocusNode = FocusNode();
  FocusNode weightFocusNode = FocusNode();
  TextEditingController cityController =  TextEditingController(text: "");
  TextEditingController stateController =  TextEditingController(text: "");
  TextEditingController heightController =  TextEditingController(text: "");
  TextEditingController ageController =  TextEditingController(text: "");
  TextEditingController weightController =  TextEditingController(text: "");
  String portfolioImagePath = "";
  TextEditingController secondLevelCompetencyController =
   TextEditingController();
  TextEditingController otherCategory =  TextEditingController();
  TextEditingController thirdLevelController =
   TextEditingController(text: "");
  bool isThirLevelField = true;

  bool isOtherCategory = false;
  int uploadMediaCount = 0;
  TextEditingController personalReflectionController =
   TextEditingController(text: "");
  String strpersonalReflection = '';

  // bool isOtherOption = false;

  //------------------------------------------

  //--------------------------Recommendation Info api ------------------

  Future apiCallMaster() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_MASTER_DATA, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              skillList.clear();
              competencyList.clear();
              prefs.setString(
                  "skill", json.encode(response.data['result']['skills']));
              prefs.setString(
                  "level", json.encode(response.data['result']['importance']));

              prefs.setString("competencies",
                  json.encode(response.data['result']['competencies']));

              levelList = ParseJson.parseMapLevelList(
                  response.data['result']['importance']);
              skillList = ParseJson.parseMapSkillList(
                  response.data['result']['skills']);

              competencyList = ParseJson.parseMapMasterCompetency(
                  response.data['result']['competencies']);

              if (competencyList.length > 0) {
                level3Competencylist.clear();
                setState(() {
                  competencyList;
                });
              }

              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }

              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallLevelList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_LEVEL_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              prefs.setString("level", json.encode(response.data['result']));
              levelList = ParseJson.parseMapLevelList(response.data['result']);
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": widget.sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  //--------------------------Api Call for skills ------------------
  Future apiCallSkill() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_SKILLS, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              skillList.clear();
              prefs.setString("skill", json.encode(response.data['result']));
              skillList = ParseJson.parseMapSkillList(response.data['result']);
              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Upload Acchievment Data ------------------

  bool validationCheck() {
   if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    } else if (appliedFilter == "") {

      
      return false;
    } else if (strLevelValue == "") {
     // ToastWrap.showToast(MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL, context);

      return false;
    } else if (strFromDate == "") {
      ToastWrap.showToast(MessageConstant.SELECT_FROM_DATE_VAL, context);
      return false;
    } else if (strToDate == "" && (!isPresent)) {
      ToastWrap.showToast(MessageConstant.SELECT_TO_DATE_VAL, context);
      return false;
    } else if (mediaList.length + mediaVideosList.length == 1) {
      ToastWrap.showToast("Please select photo.", context);
      return false;
    }

    return true;
  }

  bool validationForPortFolio() {
   /* if(!isValidAge){
      return false;
    }
    else */ if (portfolioImagePath == "") {
      ToastWrap.showToast(MessageConstant.REQUIRED_IMAGE, context);
      return false;
    } else if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    } else if (appliedFilter == "") {
      ToastWrap.showToast(MessageConstant.SELECT_SKILLS_VAL, context);
      return false;
    } else if (strLevelValue == "") {
      ToastWrap.showToast(
          MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL, context);
      return false;
    } else if (strFromDate == "") {
      ToastWrap.showToast(MessageConstant.SELECT_FROM_DATE_VAL, context);
      return false;
    } else if (strToDate == "" && (!isPresent)) {
      ToastWrap.showToast(MessageConstant.SELECT_TO_DATE_VAL, context);
      return false;
    }
    return true;
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    _timer =  Timer(const Duration(milliseconds: 3000), () async {
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCallingPortFolio() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        if (linkUrlListData.length == 1 &&
            linkUrlListData[0].urlController.text.trim() == '') {
          //linkUrlListData[0].urlController.text.trim() == '';
          linkUrlListData.clear();
          print('linkUrlListData len::: ${linkUrlListData.length}');
        }
        //assestList.removeAt(0);
        Map map = {
          "achievementId": "",
          "userId": userIdPref,
          "userImage": portfolioImagePath,
          "competencyTypeId": strCompetencyTypeId,
          "level2Competency": strcompetencyTypeName,
          "level3Competency": secondLevelCompetencyController.text == "Other" ||
              secondLevelCompetencyController.text == "General"
              ? otherCategory.text.toString()
              : strCompetencyValue,
          "focusArea": thirdLevelController.text,
          "importance": strLevelValue,
          "skills": skillsSelectedList.map((item) => item.toJson()).toList(),
          "title": strTitle,
          "fromDate": strFromDate,
          "toDate": strToDate,
          "type": "portfolio",
          "personalStatement": strDeascription,
          "description": strBio,
          "personalReflection": personalReflectionController.text.trim(),
          "city": cityController.text,
          "state": stateController.text,
          "height": heightController.text,
          "weight": weightController.text,

          "age": ageController.text,
          "asset": mediaListData.map((item) => item.toJson()).toList(),
          "team": [
            {
              "teamType": clubTeamList.length > 0 ? "Club Team" : "",
              "teams": clubTeamList.map((item) => item.toJson()).toList()
            },
            {
              "teamType":
              highSchoolTeamList.length > 0 ? "High School Team" : "",
              "teams": highSchoolTeamList.map((item) => item.toJson()).toList()
            },
            {
              "teamType": collegeTeamList.length > 0 ? "College Team" : "",
              "teams": collegeTeamList.map((item) => item.toJson()).toList()
            },
            {
              "teamType": otherTeamList.length > 0 ? "Others" : "",
              "teams": otherTeamList.map((item) => item.toJson()).toList()
            }
          ],
          "external_links":
          linkUrlListData.map((item) => item.toJson()).toList(),
          "stats": stateListData.map((item) => item.toJson()).toList(),
          "guide": {
            "promptRecommendation": isPrompt,
            "firstName": strCoachFirstName,
            "lastName": strCoachLastName,
            "email": strCoachEmail,
            "title": strRecommenderTitle,
            "recommenderTitle": strRecommendationTitle,
           // "title": strRecommendationTitle,
           // "recommenderTitle": strRecommenderTitle,
            "request": strRecommendationRequest,
          },
          "isActive": "true"
        };

        CustomProgressLoader.cancelLoader(context);
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              RewardStatus rewardStatus;
              if (!isPrompt)
                rewardStatus =  RewardStatus.fromJson(
                    response.data['result']['rewardStatus']);
              else
                rewardStatus =
                 RewardStatus.fromJson(response.data['rewardStatus']);
              if (rewardStatus != null) {
                print('rewardStatus msg:: ${rewardStatus.msg}');
              } else
                print('rewardStatus obj:: ${rewardStatus}');

              if (widget.pageName == "all") {
                //Navigator.pop(context, "push");
                Util.showRewardPointPush(rewardStatus, context);
              } else {
                ParentProfilePageState.isAchivmentAdded = "true";
                widget.studModel.isAchievement = "true";
                setState(() {
                  widget.studModel.isAchievement;
                });
                await Util.showRewardPointOnBoarding(
                    rewardStatus, context, widget.studModel);
                // apiCallWizardCompleted(false);
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        mediaList.removeLast();
        //  badgeList.removeLast();
        certificateList.removeLast();
        badgeAndTrophyList.removeLast();
        mediaVideosList.removeLast();
        assestList.clear();
        for (var file in mediaList) {
          assestList.add(new Assest("image", "media", file, "", false));
        }

        for (FileModel item in mediaVideosList) {
          assestList.add(new Assest("video", "media", item.path, "", false));
        }

        for (var file in certificateList) {
          assestList.add(new Assest("image", "certificates", file, "", false));
        }

        for (var file in badgeAndTrophyList) {
          assestList.add(new Assest("image", file.tag, file.file, "", false));
        }

        if (linkUrlListData.length == 1 &&
            linkUrlListData[0].urlController.text.trim() == '') {
          //linkUrlListData[0].urlController.text.trim() == '';
          linkUrlListData.clear();
          print('linkUrlListData len::: ${linkUrlListData.length}');
        }

        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {
          "external_links":
          linkUrlListData.map((item) => item.toJson()).toList(),
          "achievementId": "",
          "competencyTypeId": listCompetency[level1Position]
              .level2Competencylist[level2Position]
              .competencyTypeId,
          "level2Competency": listCompetency[level1Position]
              .level2Competencylist[level2Position]
              .name,
          "level3Competency": secondLevelCompetencyController.text == "Other" ||
              secondLevelCompetencyController.text == "General"
              ? otherCategory.text.toString()
              : strCompetencyValue,
          "focusArea": thirdLevelController.text,
          "userId": userIdPref,
          "badge": [],
          "certificate": [],
          "asset": assestList.map((item) => item.toJson()).toList(),
          "skills": skillsSelectedList.map((item) => item.toJson()).toList(),
          "title": strTitle,
          "description": strDeascription,
          "personalReflection": personalReflectionController.text.trim(),
          "hoursWorkedPerWeek": strWorkingHours,
          "fromDate": strFromDate,
          "toDate": strToDate,
          "importance": strLevelValue,
          "guide": {
            "promptRecommendation": isPrompt,
            "firstName": strCoachFirstName,
            "lastName": strCoachLastName,
            "email": strCoachEmail,
            "title": strRecommenderTitle,
            "recommenderTitle": strRecommendationTitle,
          //  "title": strRecommendationTitle,
           // "recommenderTitle": "",
            "request": strRecommendationRequest,
          },
          "stories": "",
          "isActive": "true",
          "sheight": strHeight,
          "sweight": strWeight,
          "height": heightController.text,
          "weight": weightController.text,
        };

        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              // showSucessMsg("Nice Work! You’ve successfully done something that makes you great.", context);

              RewardStatus rewardStatus;
              if (!isPrompt)
                rewardStatus =  RewardStatus.fromJson(
                    response.data['result']['rewardStatus']);
              else
                rewardStatus =
                 RewardStatus.fromJson(response.data['rewardStatus']);
              if (rewardStatus != null) {
                print('rewardStatus msg:: ${rewardStatus.msg}');
              } else
                print('rewardStatus obj:: ${rewardStatus}');

              if (widget.pageName == "all") {
                //Navigator.pop(context, "push");
                Util.showRewardPointPush(rewardStatus, context);
              } else {
                ParentProfilePageState.isAchivmentAdded = "true";
                widget.studModel.isAchievement = "true";
                setState(() {
                  widget.studModel.isAchievement;
                });
                await Util.showRewardPointOnBoarding(
                    rewardStatus, context, widget.studModel);
                //apiCallWizardCompleted(false);
              }

              // Navigate to List
              /*    if(widget.pageName=="all"){
                Navigator.pop(context,"push");
                syncDoneController.add("secess");
              }else {
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>
                     AllAccomplishmentListWidget(widget.studModel)));
              }*/
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future mediaApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await  ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_MEDIA_ACCOM, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              imageList = ParseJson.parseMedia(response.data['result']);
              if (imageList != null) {
                setState(() {
                  imageList;
                  if (imageList.length > 0) {
                    mediaList.removeLast();
                    mediaList.add(imageList[0]);
                    mediaList.add("");
                  }
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_WIZARD_USERID);
    userEmail = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);
    portfolioImagePath = widget.studModel.profilePicture;
    mediaList.add("");
    mediaVideosList.add(null);
    competencyApiCall();
    mediaApi(true);
    try {
      if (prefs.getString("competencies") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("competencies"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          competencyList.clear();
          competencyList = ParseJson.parseMapMasterCompetency(data);
          if (competencyList.length > 0) {
            level3Competencylist.clear();
            setState(() {
              competencyList;
            });
          }
        }
      }

      if (prefs.getString("level") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("level"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          levelList.clear();
          levelList = ParseJson.parseMapLevelList(data);
          if (levelList.length > 0) {
            setState(() {
              levelList;
            });
          }
        }
      }

      if (prefs.getString("skill") == null) {
        await apiCallMaster();
      } else {
        final skill = json.decode(prefs.getString("skill"));
        if (skill == null || skill.length == 0) {
          await apiCallMaster();
        } else {
          skillList.clear();
          skillList = ParseJson.parseMapSkillList(skill);
          if (skillList.length > 0) {
            for (int i = 0; i < skillList.length; i++) {
              filterStatus[i] = false;
            }
            setState(() {
              filterStatus;
              skillList;
            });
          }
        }
      }

      if (level3Competencylist.length == 1) {
        competencySelected = level3Competencylist[0];
        strCompetencyValue = level3Competencylist[0].name;
        setState(() {
          competencySelected;
          strCompetencyValue;
        });
      }
    } catch (e) {
      e.toString();
    }
    //await apiCallSkill();
    // await callApiForSaas();

    certificateList.add("");

    // badgeList.addAll(achivmentModel.badgeList);
    // badgeList.add("");

    badgeAndTrophyList.add(new Assest("image", "badges", "", "", false));

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    // narrativeApi();
  }

//------------------------------------Api Calling for get Commpetency -------------------------
  Future competencyApiCall() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling()
            .apiCall(context, Constant.ENDPOINT_COMPENTENCY, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              listCompetency.clear();
              listCompetency =
                  ParseJson.parseMapCompetency(response.data['result']);
              if (listCompetency.length > 0) {
                setState(() {
                  listCompetency;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  bool isShiftBelow = true;
  FocusNode _focusDescription =  FocusNode();

  void _onFocusChangeDesc() {
    setState(() {
      if (!_focusDescription.hasFocus && descController.text == '')
        isShiftBelow = true;
      else
        isShiftBelow = false;
    });
  }
bool addSkillsError = false;

  bool selectAchivmentLevel = false;

  @override
  void initState() {
    // TODO: implement initState
    String date = widget.studModel.dob;
    for (int i = 1; i < 100; i++) {
      yearList.add(i);
    }
    if (date != "" || date != null) {
      startDate =  DateTime.fromMillisecondsSinceEpoch(
          int.parse(widget.studModel.dob));
    } else {
      startDate =  DateTime.now();
    }
    descController.addListener(() {
      setState(() {
        descController.text.length;
      });
    });

    getSharedPreferences();
    uploadMedia = UploadMedia(context);
    _controllerConfetti =  ConfettiController(
      duration:  Duration(seconds: 3),
    );

    linkUrlListData.add(LinkUrlDataModel(
       TextEditingController(text: ""),
       TextEditingController(text: ""),
       TextEditingController(text: ""),
    ));
    MediaDataModelNew _mMediaDataModelNew = MediaDataModelNew(
         TextEditingController(text: ""),
         TextEditingController(text: ""),
         TextEditingController(text: ""),
        isSelectMedia: true,
        fileDataModelList:  List<FileDataModel>());
    _mMediaDataModelNew.fileDataModelList.add(new FileDataModel(
        filePath: "",
        type: "",
        thumbnailFile: null,
        imagePath: null,
        linkController:  TextEditingController()));

    mediaListData.add(_mMediaDataModelNew);
    _focusDescription.addListener(_onFocusChangeDesc);

    stateListData.add(StateModel(
        position: "",
        lable: "",
        value: "",
        positionController:  TextEditingController(),
        lableController:  TextEditingController(),
        valueController:  TextEditingController()));
    super.initState();
  }

  getEditCategoryTextField(isEnabled, label, isEdit) {
    return  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 5.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          autofocus: isEnabled,
          //autofocus: true,
          //enabled: isEnabled,
          //enabled: isEnabled,f
          maxLength: isEnabled
              ? TextLength.OTHER_MAX_LENGTH
              : TextLength.OTHER_COMPETENCY_MAX_LENGTH,

          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
          controller: isEnabled ? otherCategory : thirdLevelController,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              0.0,
            ),
            labelText: label,
            errorStyle: Util.errorTextStyle,
            //hintText: isEnabled ? "" : strCompetencyValue,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            counterText: "",
            hintText: isEnabled
                ? ""
                : MessageConstant.FOCUS_AREA_HINT_TEXT,
            hintMaxLines: 1,
            hintStyle:  TextStyle(
                color: ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),

            fillColor: Colors.transparent,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
          ),
          validator: (val) =>
          /*isEdit?
          val.trim().isEmpty|| val.trim()=="Other"||val.trim()=="General"?MessageConstant.ENTER_TITLE_VAL_CHANGE:null
              :*/
          val.trim().isEmpty
              ?  listCompetency[level1Position]
              .level2Competencylist[level2Position]
              .name==
              "General"
              ? MessageConstant.ENTER_TITLE_VAL_GENERAL_CHANGE
              : MessageConstant.ENTER_TITLE_VAL_OTHER_CHANGE
              : null,
        ));
  }

  competencySelectionDialog() {
    double heightItem = ((level2Competencylist.length * 30.0) + 70.0);
    double systemHeight = MediaQuery.of(context).size.height - 150;
    if (heightItem > systemHeight) {
      heightItem = systemHeight;
    }
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 38.0,
                            child:  Container(
                                height: heightItem,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                     Container(
                                      height: heightItem - 30.0,
                                      color: Colors.transparent,
                                      child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              13.0, 0, 13, 0),
                                          child: Container(
                                            color: Colors.white,
                                            child:  ListView(

                                              children: [
                                                Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .center,
                                                    children:  List.generate(
                                                        level2Competencylist
                                                            .length,
                                                            (int index) {
                                                          return  InkWell(
                                                            onTap: () {
                                                              level3Competencylist
                                                                  .clear();
                                                              strCompetencyTypeId =
                                                                  level2Competencylist[
                                                                  index]
                                                                      .competencyTypeId;
                                                              level2Position =
                                                                  index;
                                                              strcompetencyTypeName =
                                                                  level2Competencylist[
                                                                  index]
                                                                      .name;

                                                              secondLevelCompetencyController
                                                                  .text =
                                                                  level2Competencylist[
                                                                  index]
                                                                      .name;
                                                              level3Competencylist.addAll(
                                                                  level2Competencylist[
                                                                  index]
                                                                      .level3Competencylist);
                                                              competencySelected =
                                                              level3Competencylist[
                                                              0];
                                                              strCompetencyValue =
                                                                  level3Competencylist[
                                                                  0]
                                                                      .name;
                                                              setState(() {
                                                                competencySelected;
                                                                strCompetencyValue;
                                                                if (level2Competencylist[
                                                                index]
                                                                    .name ==
                                                                    "Other" ||
                                                                    level2Competencylist[
                                                                    index]
                                                                        .name ==
                                                                        "General") {
                                                                  otherCategory
                                                                      .text = "";
                                                                  isOtherCategory =
                                                                  true;
                                                                  /*  if (level2Competencylist[
                                                                            index]
                                                                        .name ==
                                                                    "Other")
                                                                  isOtherOption =
                                                                      true;
                                                                else
                                                                  isOtherOption =
                                                                      false;*/
                                                                } else {
                                                                  isOtherCategory =
                                                                  false;
                                                                  otherCategory
                                                                      .text = "";
                                                                }
                                                              });
                                                              setState(() {});
                                                              Navigator.pop(
                                                                  context);
                                                              if (isOtherCategory) {
                                                                editCategoryDialog(
                                                                    true,
                                                                    false,
                                                                    false);
                                                              }

                                                            },
                                                            child:  Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .center,
                                                              children: [
                                                                PaddingWrap.paddingfromLTRB(
                                                                    15.0,
                                                                    10.0,
                                                                    13.0,
                                                                    10.0,
                                                                    TextViewWrap.textView(
                                                                        level2Competencylist[
                                                                        index]
                                                                            .name,
                                                                        TextAlign
                                                                            .center,
                                                                         ColorValues.HEADING_COLOR_EDUCATION,
                                                                        16.0,
                                                                        FontWeight
                                                                            .normal)),
                                                                level2Competencylist
                                                                    .length -
                                                                    1 ==
                                                                    index
                                                                    ?  Container(
                                                                  height: 0.0,
                                                                )
                                                                    : CustomViews
                                                                    .getSepratorLine(),
                                                              ],
                                                            ),
                                                          );
                                                        }))
                                              ],
                                            ),
                                          )),
                                    )
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:
                                                      Constant.customRegular),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  editCategoryDialog(isPortFolio, isEdit, isCompulsary) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 20.0,
                            child:  Container(
                                height: isCompulsary ? 140.0 : 170.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        10.0,
                                        13.0,
                                        0.0,
                                         Container(
                                            height:
                                            isCompulsary ? 140.0 : 170.0,
                                            padding:  EdgeInsets.fromLTRB(
                                                13.0, 0, 13, 0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Form(
                                                key: _formKey2,
                                                child:  Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                    children: <Widget>[
                                                      isCompulsary
                                                          ?  Container(
                                                        height: 5,
                                                      )
                                                          :  InkWell(
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);

                                                            if (isPortFolio) {
                                                              competencySelectionDialog();
                                                            } else {
                                                              if (!isEdit)
                                                                isSelectedLevel2 = false;

                                                              try {
                                                                listCompetency[level1Position]
                                                                    .level2Competencylist[level2Position]
                                                                    .isSelected =
                                                                false;
                                                                setState(() {});
                                                              }catch(e){

                                                              }
                                                            }
                                                            setState(() {});

                                                          },
                                                          child:
                                                           Padding(
                                                              padding:  EdgeInsets
                                                                  .fromLTRB(
                                                                  0.0,
                                                                  12.0,
                                                                  0.0,
                                                                  0.0),
                                                              child:
                                                               Icon(
                                                                Icons
                                                                    .close,
                                                                color:  Color(
                                                                    0xff888888),
                                                                size:
                                                                20.0,
                                                              ))),
                                    Container(
                                        height: 84,
                                        child:   getEditCategoryTextField(
                                                          true,
                                                          listCompetency[level1Position]
                                                              .level2Competencylist[level2Position]
                                                              .name==
                                                              "General"
                                                              ?MessageConstant.ENTER_GENERAL_DISPLAY_TITLE:  MessageConstant.ENTER_OTHER_DISPLAY_TITLE,
                                                          isCompulsary
                                                        /*widget.strcompetencyTypeName ==
                                                              "General"
                                                              ? "Change General To:"
                                                              : "Change Other To:"*/
                                                      )),
                                                       InkWell(
                                                        child: Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              top: 0.0,
                                                              bottom: 6.0),
                                                          child:  Container(
                                                              width: 80.0,
                                                              height: 30.0,
                                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                              child: Center(
                                                                child:  Text(
                                                                  isCompulsary
                                                                      ?"UPDATE":  "ADD",
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:  TextStyle(
                                                                      color: Colors
                                                                          .white,
                                                                      fontSize:
                                                                      12.0,
                                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                                ),
                                                              )),
                                                        ),
                                                        onTap: () {
                                                          final form1 =
                                                              _formKey2
                                                                  .currentState;

                                                          form1.save();
                                                          if (form1
                                                              .validate()) {
                                                            Navigator.pop(
                                                                context);
                                                            setState(() {
                                                              strCompetencyValue =
                                                                  otherCategory
                                                                      .text;
                                                            });
                                                            if(!isCompulsary)
                                                            _scrollController.jumpTo(_scrollController.position.minScrollExtent);
                                                          }
                                                        },
                                                      )
                                                    ])))),
                                  ],
                                ))),
                      ],
                    )))));
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
//============================================ grid view achevements nd core logic =====================================

    //==============================add=============

    void infoDialogPer() {
      FocusScope.of(context).requestFocus(new FocusNode());
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: 145.0,
                                          padding: const EdgeInsets.all(8.0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: ListView(children: <Widget>[
                                             Container(
                                                child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text:
                                                    "This tells your story so share things like why you are passionate about the sport, how long you have been playing, who inspires you, any personality traits that makes you an awesome athlete and a great fit for any team. Goal is to WOW the reader to continue to review your portfolio.",
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ))
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Close",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 20.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final dropdownMenuLevel = levelList
        .map((AchievementImportanceModal item) =>
     DropdownMenuItem<AchievementImportanceModal>(
        value: item,
        child:  Text(item.title,
            style:  TextStyle(
              fontFamily:Constant.TYPE_CUSTOMREGULAR,
              color:  ColorValues.HEADING_COLOR_EDUCATION,
            ))))
        .toList();
    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    //---------------------------------Skill Core Logic nd ui -----------------------
    void iterateFilters(key, value) {
      print('-------------$key:$value'); //string interpolation in action
      if (value) {
        if (key != 0) {
          if (filterData == "") {
            filterData = (key).toString();
            appliedFilter = skillList[key].title;

            skillsSelectedList.add(
                 Skill(skillList[key].title, skillList[key].skillId, key));
          } else {
            filterData = filterData + ", " + (key).toString();
            appliedFilter = appliedFilter + ",\n" + skillList[key].title;
            skillsSelectedList.add(
                 Skill(skillList[key].title, skillList[key].skillId, key));
          }
        }
      }
    }

    void onApplyClick() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      filterStatus.forEach(iterateFilters);
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());

        appliedFilter;
      });
      Navigator.pop(context);
    }

    void onCancelTap() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      for (int i = 0; i < filterStatus.length; i++) {
        filterStatus[i] = false;
      }
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());

        appliedFilter;
      });
      Navigator.pop(context);
    }

    void conformationDialog(type, path) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to remove?",
                                                      textAlign:
                                                      TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Remove",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "media") {
                                                  mediaList.remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    mediaList;
                                                    assestList;
                                                  });

                                                  if (mediaList.length == 1 &&
                                                      mediaVideosList.length ==
                                                          1) {
                                                    selectedIndexCover = 0;
                                                    mediaList.removeLast();
                                                    mediaList.add(imageList[0]);
                                                    mediaList.add("");
                                                    isPredefinedMediaSelected =
                                                    true;
                                                  }
                                                } else if (type == "video") {
                                                  mediaVideosList.remove(path);
                                                  //assestList.removeLast();
                                                  setState(() {
                                                    mediaVideosList;
                                                    //assestList;
                                                  });
                                                  //Ad added
                                                  if (mediaList.length == 1 &&
                                                      mediaVideosList.length ==
                                                          1) {
                                                    selectedIndexCover = 0;
                                                    mediaList.removeLast();
                                                    mediaList.add(imageList[0]);
                                                    mediaList.add("");
                                                    isPredefinedMediaSelected =
                                                    true;
                                                  }
                                                  //ad added end
                                                } else if (type ==
                                                    "certificate") {
                                                  certificateList.remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    certificateList;
                                                    assestList;
                                                  });
                                                } else {
                                                  badgeAndTrophyList
                                                      .remove(path);
                                                  assestList.removeLast();
                                                  setState(() {
                                                    badgeAndTrophyList;
                                                    assestList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

//======================================================================================

    //---------------------Add media View and core logics  ---------------------
    ontapApply(type) async {
      if (imagePath != null) {
        strAzureImageUploadPath = await uploadImgOnAzure(
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforPhoto);
        setState(() {
          strAzureImageUploadPath;
        });
        CustomProgressLoader.cancelLoader(context);
        if ((strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") &&
            type == "portfolio") {
          portfolioImagePath = strPrefixPathforPhoto + strAzureImageUploadPath;
          setState(() {
            portfolioImagePath;

          });
        } else if (strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") {
          assestList.add(new Assest("image", type,
              strPrefixPathforPhoto + strAzureImageUploadPath, "", false));

          if (type == "media") {
            if (isPredefinedMediaSelected) {
              isPredefinedMediaSelected = false;
              mediaList.removeLast();
            }
            mediaList.removeLast();
            mediaList.add(strPrefixPathforPhoto + strAzureImageUploadPath);
            mediaList.add("");
          } else if (type == "certificates") {
            certificateList.removeLast();

            certificateList
                .add(strPrefixPathforPhoto + strAzureImageUploadPath);
            certificateList.add("");
          } else if (type == "badges") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "", false));
          } else if (type == "trophy") {
            badgeAndTrophyList.removeLast();

            badgeAndTrophyList.add(new Assest("image", type,
                strPrefixPathforPhoto + strAzureImageUploadPath, "", false));
            badgeAndTrophyList.add(new Assest("image", type, "", "", false));
          }

          selectedImageType = "media";
          strAzureImageUploadPath = "";
          imagePath = null;
          setState(() {
            mediaList;
            isMedaiDialog = false;
            assestList;
            selectedImageType;
            strAzureImageUploadPath;
            imagePath;
          });
        }
      }
    }

    //------------------------Image Sewlection ---------------------------

    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();
      //imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          // await _cropImage(imagePath);
          if (imagePath != null) {
            /*setState(() {
            isMedaiDialog = true;
          });
          addMediaDialog();*/
            setState(() {
              imagePath;
            });

            CustomProgressLoader.showLoader(context);
            Timer _timer =  Timer(const Duration(milliseconds: 400), () {
              ontapApply(type);
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    InkWell isImageSelectedView() {
      return  InkWell(
        child:  Container(
          width: 90.0,
          height: 90.0,
          child:  Stack(
            children: <Widget>[
               Center(
                  child:  Container(
                    child: portfolioImagePath == ""
                        ?  Image.asset(
                      "assets/profile/user_on_user.png",
                    )
                        :  ClipOval(
                        child:  CachedNetworkImage(
                          imageUrl: Constant.IMAGE_PATH + portfolioImagePath,
                          fit: BoxFit.cover,
                          placeholder: (context, url) =>
                              _loader(context, "assets/profile/user_on_user.png"),
                          errorWidget: (context, url, error) =>
                              _error("assets/profile/user_on_user.png"),
                        )),
                    width: 85.0,
                    height: 85.0,
                    padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                  )),
               Align(
                  alignment: Alignment.bottomRight,
                  child:  Container(
                    padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                    child:  Image.asset("assets/newDesignIcon/edit_img.png"),
                    height: 32.0,
                    width: 32.0,
                  ))
            ],
          ),
        ),
        onTap: () async{
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getImage("portfolio");
          }  else {
            checkPermissionPhoto(context);
          }

        },
      );
    }

    String getFileExtension2(File file) {
      return path.extension(file.path);
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});
      if (type == "video") {
        File file =
        await uploadMedia.compresssData(new File(imagePath), true, type);
        imagePath = file.path;
      } else if (type == "image") {
        File file = await uploadMedia.compressImage(new File(imagePath));
        imagePath = file.path;
      }
      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        if (type == "video") {
          mediaAndVideoList.add("");
          String path = Constant.IMAGE_PATH +
              strPrefixPathforPhoto +
              strAzureImageUploadPath;

          //final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(path);
          final thumbnailFile =
          await uploadMedia.getVideoThumbnailFromUrl(imagePath);
          //final thumbnailFile = await uploadMedia.getVideoThumbnailFromFile(path);

          print('view thumbnailFile:: ${thumbnailFile}');

          if (isPredefinedMediaSelected) {
            isPredefinedMediaSelected = false;
            /*mediaList.removeLast();
            mediaList.add("");*/
            mediaList.removeAt(0);
          }
          mediaVideosList.removeLast();
          mediaVideosList.add(new FileModel(
              thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
          mediaVideosList.add(null);
          setState(() {
            mediaVideosList;
          });

        } else if (type == "image") {
          mediaAndVideoList.add("");
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        } else {
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
        }

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    onTapVideoAddButton() async {
      mediaVideo = await uploadMedia.pickVideoFromGallery();
      print('Apurva inside onTapVideoAddButton() mediaVideo:: $mediaVideo');
      if (mediaVideo != null) {
        if (mediaVideo != null &&
            getFileExtension2(mediaVideo) != null &&
            getFileExtension2(mediaVideo).length > 0) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: mediaVideo
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "video");
          });
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }


    final dropdownMenuCompetency = level3Competencylist
        .map((Level3Competencies item) =>
     DropdownMenuItem<Level3Competencies>(
        value: item,
        child:  Text(item.name,
            style:  TextStyle(
              fontFamily:Constant.TYPE_CUSTOMREGULAR,
              color:  ColorValues.HEADING_COLOR_EDUCATION,
            ))))
        .toList();

    final competencyDropDownUi =  Container(
        height: 28.0,
        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration:  BoxDecoration(
            border:  Border(
                bottom: BorderSide(
                    color:  ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child:  DropdownButtonHideUnderline(
            child:  DropdownButton<Level3Competencies>(
                hint:  Text(
                  "Focus Area",
                  style:  TextStyle(
                      fontSize: 16.0,
                      color:  ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: competencySelected,
                items: dropdownMenuCompetency,
                onChanged: (Level3Competencies item) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    competencySelected = item;
                    strCompetencyValue = item.name;
                  });
                })));

    final workingHours =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.number,
          focusNode: workinHoursFocusNode,
          maxLength: TextLength.WORKING_HOURS_MAX_LENGTH,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          style: Util.errorTextStyle,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            labelText: "Hours Worked Per Week",
            counterText: "",
            errorStyle: Util.errorTextStyle,
            labelStyle:
             TextStyle(color:  ColorValues.GREY_TEXT_COLOR),
            fillColor: Colors.transparent,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),

          ),
          onSaved: (val) => strWorkingHours = val.trim(),
        ));

    final competencyDropLevel =  Container(
        height: 28.0,
        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration:  BoxDecoration(
            border:  Border(
                bottom: BorderSide(
                    color:  ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child:  DropdownButtonHideUnderline(
            child:  DropdownButton<AchievementImportanceModal>(
                hint:  Text(
                  "Achievement Level",
                  style:  TextStyle(
                      fontSize: 16.0,
                      color:  ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: levelSelected,
                items: dropdownMenuLevel,
                onChanged: (AchievementImportanceModal level) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    levelSelected = level;
                    strLevelValue = level.importanceId;
                  });
                })));

    final titleUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          maxLength: 200,
          focusNode: _focus,
          style: Util.errorTextStyle,
          controller: titleController,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            labelText: "Title",
            counterText: "",
            errorStyle: Util.errorTextStyle,
            hintText: listCompetency.length == 0
                ? ""
                : listCompetency[level1Position].level1 == "Arts"
                ? 'My Arts Portfolio'
                : listCompetency[level1Position].level1 == "Sports"
                ? "My Baseball Portfolio"
                : "",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),

          ),
          validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
          onSaved: (val) => strTitle = val.trim(),
        ));

    final recommenderTitle =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            labelText: "Title",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            fillColor: Colors.transparent,
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
              ? MessageConstant.ENTER_TITLE_VAL
              : null
              : null,
          onSaved: (val) => strRecommenderTitle = val.trim(),
        ));

    final recommendationTitle =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          autofocus: true,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            labelText: "Recommendation Title",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
              ? MessageConstant.ENTER_RECOMMENDATION_TITLE_VAL
              : null
              : null,
          onSaved: (val) => strRecommendationTitle = val.trim(),
        ));

    final recommendationRequest = Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 15, 0, 0),
        child:  Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(0),
              border: Border.all(
                color: Color(0xFFFDEDEDE),
                style: BorderStyle.solid,
                width: 1.0,
              ),
            ),
            padding:  EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child:  TextFormField(
              keyboardType: TextInputType.multiline,
              cursorColor: Constant.CURSOR_COLOR,
              maxLength: TextLength.RECOMMENDATION_REQUEST_MSG_LENGTH,
              textCapitalization: TextCapitalization.sentences,
              maxLines: 3,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                hintText:
                "Hi Coach, What a great soccer season. Can you please take a few min to recommend me on my soccer, leadership, and team building skills.",
                counterText: "",
                errorStyle: Util.errorTextStyle,
                floatingLabelBehavior: FloatingLabelBehavior.always,
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color:  ColorValues.hintColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 10.0),
                labelText: "Recommendation request",
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                fillColor: Colors.transparent,
                /* border: OutlineInputBorder(
              borderRadius: const BorderRadius.all(Radius.circular(0.0)),
              gapPadding: 0.0,
              borderSide: BorderSide(color: Colors.grey[300]))*/
              ),
              validator: (val) => val.trim().isEmpty
                  ? isPrompt
                  ? MessageConstant.ENTER_REQUEST_VAL
                  : null
                  : null,
              onSaved: (val) => strRecommendationRequest = val.trim(),
            )));

    final coachFirstName =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            labelText: "First Name",
            hintText: "First Name",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
              ? val.trim().length == 0
              ? MessageConstant.ENTER_FIRST_NAME_VAL
              : !ValidationWidget.isName(val)
              ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
              : null
              : null
              : val.trim().length == 0
              ? MessageConstant.ENTER_FIRST_NAME_VAL
              : !ValidationWidget.isName(val)
              ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
              : null,
          onSaved: (val) => strCoachFirstName = val.trim(),
        ));
    final coachLastName =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            labelText: "Last Name",
            hintText: "Last Name",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
            /*  border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(0.0)),
            gapPadding: 0.0,
            borderSide: BorderSide(
              color:new ColorValues.DARK_GREY,
            )),*/
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
              ? val.trim().length == 0
              ? MessageConstant.ENTER_LAST_NAME_VAL
              : !ValidationWidget.isName(val)
              ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
              : null
              : null
              : val.trim().length == 0
              ? MessageConstant.ENTER_LAST_NAME_VAL
              : !ValidationWidget.isName(val)
              ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
              : null,
          onSaved: (val) => strCoachLastName = val.trim(),
        ));

    final coachEmail =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.emailAddress,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            labelText: "Email",
            hintText: "abc@xyz.com",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            errorStyle: Util.errorTextStyle,
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
            /*  border: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(0.0)),
            gapPadding: 0.0,
            borderSide: BorderSide(
              color:new ColorValues.DARK_GREY,
            )),*/
          ),
          validator: (val) => val.trim().isEmpty
              ? isPrompt
              ? val.trim().length == 0
              ? MessageConstant.ENTER_EMAIL_VAL
              : val.toString().toLowerCase() == userEmail.toLowerCase()
              ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
              : !ValidationWidget.isEmail(val)
              ? MessageConstant.VALID_EMAIL_VAL
              : null
              : null
              : val.trim().length == 0
              ? MessageConstant.ENTER_EMAIL_VAL
              : val.toString().toLowerCase() == userEmail.toLowerCase()
              ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
              : !ValidationWidget.isEmail(val)
              ? MessageConstant.VALID_EMAIL_VAL
              : null,
          onSaved: (val) => strCoachEmail = val.trim(),
        ));
    final bioUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: bioController,
          maxLength: 1000,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "Bio",
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            counterStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintStyle:  TextStyle(
                color:  ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
          validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
          onSaved: (val) => strBio = val.trim(),
        ));
    void infoDialogdesc() {
      FocusScope.of(context).requestFocus(new FocusNode());
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height:
                                  listCompetency[level1Position].level1 ==
                                      "Arts"
                                      ? 260
                                      : 270,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: listCompetency[level1Position]
                                              .level1 ==
                                              "Arts"
                                              ? 210
                                              : 220,
                                          padding: const EdgeInsets.fromLTRB(
                                              8.0, 15, 8, 0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: ListView(children: <Widget>[
                                            Padding(
                                              padding:
                                              const EdgeInsets.fromLTRB(
                                                  0.0, 0, 0, 13),
                                              child: Image.asset(
                                                'assets/profile/parent/info.png',
                                                height: 22.0,
                                                width: 22.0,
                                              ),
                                            ),
                                             Container(
                                                child: RichText(
                                                  maxLines: 15,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text: listCompetency[
                                                    level1Position]
                                                        .level1 ==
                                                        "Arts"
                                                        ? "Write a general introduction to your work. It should open with the work's basic ideas in an overview of two or three sentences or a short paragraph. The second paragraph should go into detail about how these issues or ideas are presented in the work."
                                                        : "This tells your story so share things like why you are passionate about the sport, how long you have been playing, who inspires you, any personality traits that makes you an awesome athlete and a great fit for any team. Goal is to WOW the reader to continue to review your portfolio.",
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ))
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Close",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final descriptrionUi = listCompetency.length == 0
        ?  Container(
      height: 0.0,
    )
        :  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: Stack(
          children: <Widget>[
             TextFormField(
              keyboardType: TextInputType.text,
              controller: descController,
              maxLength: 1000,
              cursorColor: Constant.CURSOR_COLOR,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  0.0,
                  5.0,
                ),
                counterText: "",
                errorStyle: Util.errorTextStyle,
                counterStyle: Util.errorTextStyle,
                labelText: listCompetency.length == 0
                    ? "Description"
                    : isAccSelected
                    ? "Description"
                    : listCompetency[level1Position].level1 == "Arts"
                    ? "Artist Statement"
                    : listCompetency[level1Position].level1 ==
                    "Sports"
                    ? "Personal Statement"
                    : "Description",
                hintMaxLines: isAccSelected
                    ? 1
                    : listCompetency[level1Position].level1 == "Sports" ||
                    listCompetency[level1Position].level1 == "Arts"
                    ? isShiftBelow
                    ? 1
                    : 4
                    : 1,
                hintText: isAccSelected
                    ? ""
                    : listCompetency[level1Position].level1 == "Sports"
                    ? "As a versatile student-athlete, I bring unique skills to any competitive baseball team. I strive to be an impact player, always looking at how to help my team win."
                    : listCompetency[level1Position].level1 == "Arts"
                    ? "I am a passionate artist focused on pottery. I have 5 years of experience, but pottery is where I stand out. Statement: In my art, I like to capture the beauty in mundane objects and places. Different mediums allow me to..."
                    : "",
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color:  ColorValues.hintColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 10),
                fillColor: Colors.transparent,
              ),
              validator: (val) =>
              listCompetency[level1Position].level1 == "Arts"
                  ? null
                  : val.trim().isEmpty
                  ? MessageConstant.FIELD_REQUIRED
                  : null,
              onSaved: (val) => strDeascription = val.trim(),
              focusNode: _focusDescription,
            ),
            Positioned(
              /*top: isShiftBelow ? 16.0 : 4.0,
                  right: 4.0,*/
              top: isShiftBelow ? 16.0 : 4.0,
              //  left: listCompetency[level1Position].level1 == "Arts" ? isShiftBelow ? 125 : 115 : isShiftBelow ? 145 : 135,
              left: listCompetency[level1Position].level1 == "Arts"
                  ? isShiftBelow
                  ? 135
                  : 105
                  : isShiftBelow
                  ? 160
                  : 125,
              child: (listCompetency[level1Position].level1 != "Sports" &&
                  listCompetency[level1Position].level1 !=
                      "Arts") ||
                  isAccSelected
                  ? Container(
                height: 0.0,
                width: 0.0,
              )
                  :  InkWell(
                child: Image.asset(
                  'assets/profile/parent/info.png',
                  height: 12.0,
                  width: 12.0,
                ),
                onTap: () {
                  FocusScope.of(context)
                      .requestFocus(new FocusNode());
                  infoDialogdesc();
                },
              ),
            ),
          ],
        ));

    /*
    final descriptrionUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: Stack(
          children: <Widget>[
             TextFormField(
              keyboardType: TextInputType.text,
              controller: descController,
              maxLength: 1000,
              cursorColor: Constant.CURSOR_COLOR,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                counterText: "",
                labelText: listCompetency.length == 0
                    ? "Description"
                    : listCompetency[level1Position].level1 == "Arts"
                        ? "Artist Statement"
                        : listCompetency[level1Position].level1 == "Sports"
                            ? "Personal Statement"
                            : "Description",
                hintText: "Highlight key learnings and contributions",
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 13),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                fillColor: Colors.transparent,
              ),
              validator: (val) =>
                  val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
              onSaved: (val) => strDeascription = val.trim(),
            ),
            Positioned(
              top: 0.0,
              right: 4.0,
              child: listCompetency[level1Position].level1 == "Sports"
                  ? Container(
                      height: 0.0,
                      width: 0.0,
                    )
                  :  InkWell(
                      child: Image.asset(
                        'assets/profile/parent/info.png',
                        height: 20.0,
                        width: 20.0,
                      ),
                      onTap: () {
                        FocusScope.of(context).requestFocus(new FocusNode());
                        infoDialogPer();
                      },
                    ),
            ),
          ],
        ));*/

    final cityUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: cityController,
          maxLength: 50,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "City",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintStyle:  TextStyle(
                color: ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
          validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
        ));

    final stateUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: stateController,
          maxLength: 50,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "State",
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintStyle:  TextStyle(
                color: ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
          validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
        ));

    Text getTextLabel(txt, size, color, fontWeight) {
      return  Text(
        txt,
        style:
         TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Future<Null> selectFromDate(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime:  DateTime.now(),
        initialDateTime: fromDate == null ?  DateTime.now() : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime != null) {
            fromDate = dateTime;
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime);
            String date2 =  DateFormat("yyyy-MM-dd").format(dateTime);
            print(date);
            setState(() {
              strFromDate = (dateTime.millisecondsSinceEpoch).toString();
              fromDateController =  TextEditingController(text: date);
              toDateController =  TextEditingController(text: "");
            });
          }
        },
      );
    }

    final fromDateUi =  InkWell(
        child:  Container(
            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration:  BoxDecoration(
                border:  Border(
                    bottom: BorderSide(
                        color:  ColorValues.DARK_GREY, width: 1.0))),
            child:  TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              controller: fromDateController,
              decoration:  InputDecoration(
                border: InputBorder.none,
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                labelText: "Date From",
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color:  ColorValues.hintColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());

            selectFromDate(context);
          });
        });

    showHeight() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 38.0,
                              child:  Container(
                                  height: 190.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 0, 13, 0),
                                        child: Container(
                                          color: Colors.white,
                                          height: 155.0,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  color: Colors.white,
                                                  height: 40.0,
                                                  child: Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          13.0, 8, 0, 0),
                                                      child: Text(
                                                        "Height",
                                                        style: TextStyle(
                                                            color: ColorValues.GREY_TEXT_COLOR,
                                                            fontSize: 18.0,
                                                            fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                      ))),
                                               Container(
                                                color: ColorValues.GREY__COLOR,
                                                height: 0.3,
                                              ),
                                              Container(
                                                  height: 113.0,
                                                  child:  Row(
                                                    children: [
                                                       Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                            Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strFootValue =
                                                                footList[
                                                                value];

                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:  List
                                                                .generate(
                                                                footList.length,
                                                                    (int index) {
                                                                  return Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                    child: Text(
                                                                      footList[
                                                                      index],
                                                                      style:
                                                                      styleForHeight,
                                                                    ),
                                                                  );
                                                                })),
                                                        flex: 1,
                                                      ),
                                                       Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                            Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strInchValue =
                                                                inchList[
                                                                value];

                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:  List
                                                                .generate(
                                                                inchList.length,
                                                                    (int index) {
                                                                  return Padding(
                                                                    padding:
                                                                    const EdgeInsets
                                                                        .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                    child: Text(
                                                                      inchList[
                                                                      index],
                                                                      style:
                                                                      styleForHeight,
                                                                    ),
                                                                  );
                                                                })),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  )),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.of(context,
                                                    rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Save",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                isValidHeight = true;

                                                heightController.text =
                                                    strFootValue + strInchValue;
                                                Navigator.pop(context);
                                                setState(() {});
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    ageSelection() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 38.0,
                              child:  Container(
                                  height: 190.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 0, 13, 0),
                                        child: Container(
                                          color: Colors.white,
                                          height: 155.0,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  color: Colors.white,
                                                  height: 40.0,
                                                  child: Padding(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          13.0, 8, 0, 0),
                                                      child: Text(
                                                        "Age",
                                                        style: TextStyle(
                                                            color: ColorValues.GREY_TEXT_COLOR,
                                                            fontSize: 18.0,
                                                            fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                      ))),
                                               Container(
                                                color: ColorValues.GREY__COLOR,
                                                height: 0.3,
                                              ),
                                              Container(
                                                  height: 113.0,
                                                  child: CupertinoPicker(
                                                      backgroundColor:
                                                      Colors.white,
                                                      onSelectedItemChanged:
                                                          (value) {
                                                        setState(() {
                                                          //selectedValue = value;
                                                          strAgeValue =
                                                              yearList[value]
                                                                  .toString();
                                                          print(
                                                              "CupertinoPicker Value+++++" +
                                                                  footList[
                                                                  value]);
                                                        });
                                                      },
                                                      itemExtent: 40.0,
                                                      children:
                                                       List.generate(
                                                          yearList.length,
                                                              (int index) {
                                                            return Padding(
                                                              padding:
                                                              const EdgeInsets
                                                                  .fromLTRB(
                                                                  0.0, 4, 0, 0),
                                                              child: Text(
                                                                yearList[index]
                                                                    .toString(),
                                                                style:
                                                                styleForHeight,
                                                              ),
                                                            );
                                                          }))),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.of(context,
                                                    rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Save",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                isValidAge = true;
                                                ageController.text =
                                                    strAgeValue;
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final secondLevelCompetency =  InkWell(
        onTap: () {
          competencySelectionDialog();
        },
        child: PaddingWrap.paddingfromLTRB(
            12.0,
            5.0,
            12.0,
            10.0,
             Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                  color: Colors.white,
                  border: Border.all(
                    color: Color(0xFFFDEDEDE),
                    style: BorderStyle.solid,
                    width: 1.0,
                  ),
                ),
                child:  InkWell(
                  child: ListTile(
                      trailing:  Container(
                        padding:  EdgeInsets.all(7.0),
                        height: 40.0,
                        width: 30.0,
                        child:  Icon(Icons.arrow_drop_down),
                      ),
                      title:  InkWell(
                        onTap: () {
                          if (isOtherCategory)
                            editCategoryDialog(false, true, true);
                          else
                            competencySelectionDialog();
                        },
                        child:  Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            isOtherCategory
                                ? Padding(
                                padding:
                                const EdgeInsets.fromLTRB(0.0, 0, 5, 1),
                                child:  Image.asset(
                                  "assets/newDesignIcon/userprofile/edit_grey.png",
                                  height: 16.0,
                                  width: 17.0,
                                ))
                                :  Container(
                              height: 0.0,
                            ),
                             Text(
                              secondLevelCompetencyController.text == ""
                                  ? listCompetency.length == 0
                                  ? "Select Sports"
                                  : listCompetency[level1Position].level1 ==
                                  "Arts"
                                  ? "Select Arts"
                                  : "Select Sports"
                                  : isOtherCategory
                                  ? otherCategory.text
                                  : secondLevelCompetencyController.text,
                              textAlign: TextAlign.center,
                              style:  TextStyle(
                                  color:  ColorValues.GREY_TEXT_COLOR,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 16),
                            ),
                          ],
                        ),
                      )),
                ))));

    final heightUi =  InkWell(
        onTap: () {
          FocusScope.of(context).unfocus();
          showHeight();
        },
        child:  Container(
            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
            margin: EdgeInsets.all(0.0),
            child:  TextFormField(
              keyboardType: TextInputType.text,
              controller: heightController,
              maxLength: 10,
              cursorColor: Constant.CURSOR_COLOR,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              enabled: (!isValidHeight),
              onTap: () {
                showHeight();
              },
              decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                counterText: "",
                labelText: "Height",
                errorStyle: Util.errorTextStyle,
               /* errorText:
                (!isValidHeight) ? MessageConstant.FIELD_REQUIRED : null,
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),*/
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 14.0),
                hintText: "Height",
                suffixIcon:  Icon(Icons.arrow_drop_down),
                hintStyle:  TextStyle(
                    color:  ColorValues.hintColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 13),
                fillColor: Colors.transparent,
              ),
            )));
    final weightUi =  Container(
        padding:  EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.number,
          controller: weightController,
          maxLength: 10,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          focusNode: weightFocusNode,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "Weight (in pounds)",
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 14.0),
            hintText: "",
            hintStyle:  TextStyle(
                color:  ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
      /*    validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,*/
          onSaved: (val) => strWeight = val.trim(),
        ));

    final ageSelectionUi =  InkWell(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());

          ageSelection();
        },
        child:  Container(
            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            margin: EdgeInsets.all(0.0),
            child:  TextFormField(
              keyboardType: TextInputType.text,
              controller: ageController,
              maxLength: 10,
              cursorColor: Constant.CURSOR_COLOR,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              enabled: (!isValidAge),
              onTap: () {
                FocusScope.of(context).requestFocus(new FocusNode());

                ageSelection();
              },
              decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  0.0,
                  5.0,
                ),
                counterText: "",
                labelText: "Age",
                errorStyle: Util.errorTextStyle,
                errorText:
                (!isValidAge) ? MessageConstant.FIELD_REQUIRED : null,
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 14.0),
                hintText: "",
                suffixIcon:  Icon(Icons.arrow_drop_down),
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 13),
                fillColor: Colors.transparent,
              ),
            )));

    Future<Null> selectToDate(BuildContext context) async {
      DateTime dateTime2;
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime:  DateTime.now(),
        initialDateTime: toDateController == null || toDateController.text == ""
            ? fromDate
            : toDate != null
            ? toDate
            : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime2 != null) {
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime2);
            String date2 =  DateFormat("yyyy-MM-dd").format(dateTime2);
            print(date);
            var differenceStartDate = dateTime2.difference(fromDate);

            if (differenceStartDate.inDays >= 0) {
              toDate = dateTime2;

              setState(() {
                isPresent = false;
                strToDate = (dateTime2.millisecondsSinceEpoch).toString();
                toDateController =  TextEditingController(text: date);
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.ENTER_CORRECT_DATE_RANGE_VAL, context);
            }
          }
        },
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
        },
        onConfirm: (dateTime, List<int> index) {
          dateTime2 = dateTime;
        },
      );
    }

    final toDateUi =  InkWell(
        child:  Container(
            padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration:  BoxDecoration(
                border:  Border(
                    bottom: BorderSide(
                        color:  ColorValues.DARK_GREY, width: 1.0))),
            child:  TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style:  TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              controller: toDateController,
              decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                border: InputBorder.none,
                labelText: "Date To",
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
            if (fromDate != null) {
              selectToDate(context);
            } else {
              ToastWrap.showToast(
                  MessageConstant.SELECT_FROM_DATE_VAL, context);
            }
          });
        });

    _buildChoiceList() {
      List<Widget> choices = List();
      skillsSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.all(3.0),
            child:  Row(
              children: <Widget>[
                 Flexible(
                  child:  Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),
                  flex: 1,
                ),
                 Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                         Icon(
                          Icons.cancel,
                          color:  ColorValues.BG_CIRCLE_COLOR,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        skillsSelectedList.remove(item);
                        filterStatus[item.index] = false;
                        filterStatus[0] = false;
                      });
                      filterData = "";
                      appliedFilter = "";
                      skillsSelectedList.clear();
                      filterStatus.forEach(iterateFilters);
                    },
                  ),
                  flex: 0,
                ),
              ],
            )));
      });
      return choices;
    }

    void selectSkillDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Center(
                          child: PaddingWrap.paddingAll(
                              10.0,
                              ListView(children: <Widget>[
                                 Container(
                                    padding:  EdgeInsets.all(0.0),
                                    color: Colors.white,
                                    child:  Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: <Widget>[
                                         Container(
                                          color:  Color(0XFFEDEDED),
                                          child: PaddingWrap.paddingfromLTRB(
                                              19.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                               Text(
                                                "Each experience leads to skill building. So, select every skill you feel you built or exercised "
                                                    "with this experience. Demonstrate why this experience was so enriching for you.",
                                                textAlign: TextAlign.start,
                                                style:  TextStyle(
                                                    fontSize: 14.0,
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                        ),
                                        PaddingWrap.paddingfromLTRB(
                                            19.0,
                                            20.0,
                                            10.0,
                                            10.0,
                                             Text(
                                              "Select all your skills from the list below:",
                                              textAlign: TextAlign.start,
                                              style:  TextStyle(
                                                  fontSize: 14.0,
                                                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                        PaddingWrap.paddingfromLTRB(
                                            19.0,
                                            0.0,
                                            10.0,
                                            10.0,
                                             ListView.builder(
                                              // itemCount: myData.lenght(),
                                                shrinkWrap: true,
                                                itemCount: skillList.length,
                                                itemBuilder:
                                                    (BuildContext context,
                                                    int index) {
                                                  if ((skillList.length - 1) ==
                                                      index) {
                                                    return  Column(
                                                      children: <Widget>[
                                                         InkWell(
                                                          child:  Padding(
                                                              padding:
                                                               EdgeInsets
                                                                  .fromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  8.0),
                                                              child:  Row(
                                                                children: <
                                                                    Widget>[
                                                                  filterStatus[
                                                                  index]
                                                                      ?  Expanded(
                                                                      child:  Padding(
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child:  Image.asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height: 20.0,
                                                                            width: 20.0,
                                                                          )),
                                                                      flex: 0)
                                                                      :  Expanded(
                                                                      child:  Padding(
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child:  Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height: 20.0,
                                                                            width: 20.0,
                                                                          )),
                                                                      flex: 0),
                                                                   Expanded(
                                                                      child:
                                                                       Text(
                                                                        skillList[
                                                                        index]
                                                                            .title,
                                                                        maxLines: 3,
                                                                        style:  TextStyle(
                                                                            fontSize:
                                                                            14.0,
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                            fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                      )),
                                                                ],
                                                              )),
                                                          onTap: () {
                                                            bool value =
                                                            filterStatus[
                                                            index];

                                                            if (index == 0) {
                                                              for (int i = 0;
                                                              i <
                                                                  filterStatus
                                                                      .length;
                                                              i++) {
                                                                if (value)
                                                                  filterStatus[
                                                                  i] =
                                                                  false;
                                                                else
                                                                  filterStatus[
                                                                  i] = true;
                                                              }
                                                            } else {
                                                              // filterStatus[0] = false; // Set All false
                                                              if (filterStatus[
                                                              index]) {
                                                                filterStatus[
                                                                index] =
                                                                false;
                                                              } else {
                                                                filterStatus[
                                                                index] =
                                                                true;
                                                              }
                                                            }

                                                            // Refresh the All Check
                                                            int count = 0;
                                                            for (int i = 1;
                                                            i <
                                                                filterStatus
                                                                    .length;
                                                            i++) {
                                                              if (!filterStatus[
                                                              i]) count++;
                                                            }

                                                            if (count > 0) {
                                                              filterStatus[0] =
                                                              false;
                                                            } else {
                                                              filterStatus[0] =
                                                              true;
                                                            }

                                                            setState(() {
                                                              filterStatus;
                                                            });
                                                            Navigator.pop(
                                                                context);
                                                            selectSkillDialog();
                                                          },
                                                        ),
                                                         Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .end,
                                                          children: <Widget>[
                                                             Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                15.0,
                                                                20.0,
                                                                0.0,
                                                                20.0,
                                                                 InkWell(
                                                                  child:
                                                                   Text(
                                                                    'Cancel',
                                                                    style:  TextStyle(
                                                                        fontSize:
                                                                        16.0,
                                                                        color:  ColorValues.GREY_TEXT_COLOR),
                                                                  ),
                                                                  onTap: () {
                                                                    onCancelTap();
                                                                  },
                                                                ),
                                                              ),
                                                              flex: 0,
                                                            ),
                                                             Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                0.0,
                                                                20.0,
                                                                20.0,
                                                                20.0,
                                                                 InkWell(
                                                                  child:
                                                                   Text(
                                                                    '',
                                                                    style:  TextStyle(
                                                                        fontSize:
                                                                        16.0,
                                                                        color:  ColorValues.GREY_TEXT_COLOR),
                                                                  ),
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            ),
                                                             Expanded(
                                                              child: PaddingWrap
                                                                  .paddingfromLTRB(
                                                                10.0,
                                                                20.0,
                                                                30.0,
                                                                20.0,
                                                                 InkWell(
                                                                  child:
                                                                   Text(
                                                                    'Done',
                                                                    style:  TextStyle(
                                                                        fontSize:
                                                                        16.0,
                                                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                                  ),
                                                                  onTap: () {
                                                                    onApplyClick();
                                                                  },
                                                                ),
                                                              ),
                                                              flex: 0,
                                                            ),
                                                          ],
                                                        )
                                                      ],
                                                    );
                                                  } else {
                                                    return  InkWell(
                                                      child:  Padding(
                                                          padding:
                                                           EdgeInsets
                                                              .fromLTRB(
                                                              0.0,
                                                              8.0,
                                                              0.0,
                                                              8.0),
                                                          child:  Row(
                                                            children: <Widget>[
                                                              filterStatus[
                                                              index]
                                                                  ?  Expanded(
                                                                  child:  Padding(
                                                                      padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                      child:  Image.asset(
                                                                        "assets/newDesignIcon/navigation/check.png",
                                                                        height:
                                                                        20.0,
                                                                        width:
                                                                        20.0,
                                                                      )),
                                                                  flex: 0)
                                                                  :  Expanded(
                                                                  child:  Padding(
                                                                      padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                      child:  Image.asset(
                                                                        "assets/newDesignIcon/navigation/uncheck.png",
                                                                        height:
                                                                        20.0,
                                                                        width:
                                                                        20.0,
                                                                      )),
                                                                  flex: 0),
                                                               Expanded(
                                                                  child:
                                                                   Text(
                                                                    skillList[index]
                                                                        .title,
                                                                    maxLines: 3,
                                                                    style:  TextStyle(
                                                                        fontSize:
                                                                        14.0,
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontWeight: skillList[index].title ==
                                                                            "Select All"
                                                                            ? FontWeight
                                                                            .bold
                                                                            : FontWeight
                                                                            .normal,
                                                                        fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                            ],
                                                          )),
                                                      onTap: () {
                                                        bool value =
                                                        filterStatus[index];
                                                        if (index == 0) {
                                                          for (int i = 0;
                                                          i <
                                                              filterStatus
                                                                  .length;
                                                          i++) {
                                                            if (value)
                                                              filterStatus[i] =
                                                              false;
                                                            else
                                                              filterStatus[i] =
                                                              true;
                                                          }
                                                        } else {
                                                          filterStatus[0] =
                                                          false;
                                                          if (filterStatus[
                                                          index]) {
                                                            filterStatus[
                                                            index] = false;
                                                          } else {
                                                            filterStatus[
                                                            index] = true;
                                                          }
                                                        }

                                                        // Refresh the All Check
                                                        int count = 0;
                                                        for (int i = 1;
                                                        i <
                                                            filterStatus
                                                                .length;
                                                        i++) {
                                                          if (!filterStatus[i])
                                                            count++;
                                                        }

                                                        if (count > 0) {
                                                          filterStatus[0] =
                                                          false;
                                                        } else {
                                                          filterStatus[0] =
                                                          true;
                                                        }

                                                        setState(() {
                                                          filterStatus;
                                                        });
                                                        Navigator.pop(context);
                                                        selectSkillDialog();
                                                      },
                                                    );
                                                  }
                                                }))
                                      ],
                                    ))
                              ])))))));
    }

    void typeSelection() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 10.0,
                              child:  Container(
                                  height: 160.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                           EdgeInsets
                                                              .fromLTRB(
                                                              0.0,
                                                              13.0,
                                                              0.0,
                                                              13.0),
                                                          child:  Text(
                                                            "Badge",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: ()async {
                                                        Navigator.pop(context);
                                                        var status = await Permission.photos.status;
                                                        if (status.isGranted) {
                                                          getImage("badges");
                                                        }  else {
                                                          checkPermissionPhoto(context);
                                                        }

                                                      },
                                                    ),
                                                     Container(
                                                      color:  ColorValues.BORDER_COLOR,
                                                      height: 1.0,
                                                    ),
                                                     InkWell(
                                                      child:  Container(
                                                          height: 50.0,
                                                          padding:
                                                           EdgeInsets
                                                              .fromLTRB(
                                                              0.0,
                                                              13.0,
                                                              0.0,
                                                              13.0),
                                                          child:  Text(
                                                            "Trophy",
                                                            textAlign: TextAlign
                                                                .center,
                                                            maxLines: 5,
                                                            style:  TextStyle(
                                                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                height: 1.2,
                                                                fontSize: 16.0,
                                                                fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      onTap: ()async {
                                                        Navigator.pop(context);
                                                        var status = await Permission.photos.status;
                                                        if (status.isGranted) {
                                                          getImage("trophy");
                                                        }  else {
                                                          checkPermissionPhoto(context);
                                                        }

                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 20.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    rectangleDecoration() {
      return BoxDecoration(
          border: Border.all(color: Palette.dividerColor), color: Colors.white);
    }

    showMediaFileWidget(double width, File image) {
      return Container(
        height: 54,
        width: width,
        decoration: rectangleDecoration(),
        margin: EdgeInsets.only(left: 0, right: 0),
        child: Image.file(
          image,
          fit: BoxFit.contain,
        ),
      );
    }

    final videoListUi =  Container(
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 3,
          children: mediaVideosList.map((file) {
            if (file == null) {
              return  Stack(children: <Widget>[
                 InkWell(
                  child:  Container(
                      height: 54.0,
                      width: 80.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      )),
                  onTap: () {
                    if (mediaAndVideoList.length <= 9) {
                      onTapVideoAddButton();
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_10_IMAGE_VIDEO_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);
            } else {
              return  Container(
                  child:  Stack(
                    children: <Widget>[
                      showMediaFileWidget(80, file.file),
                       Container(
                        height: 54.0,
                        width: 80.0,
                        color:  Color(0XFFC0C0C0).withOpacity(.4),
                      ),
                       Container(
                          height: 54.0,
                          width: 80.0,
                          child:  Center(
                              child:  Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                   InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                           Image.asset(
                                            "assets/newDesignIcon/achievment/remove.png",
                                            width: 35.0,
                                            height: 35.0,
                                          )),
                                      onTap: () {
                                        conformationDialog("video", file);
                                      })
                                ],
                              ))),
                    ],
                  ));
            }
          }).toList(),
        ));

    final mediaImageListUI =  Container(
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 3,
          children: mediaList.map((path) {
            if (path == "") {
              return  Stack(children: <Widget>[
                 InkWell(
                  child:  Container(
                      height: 54.0,
                      width: 80.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      )),
                  onTap: ()async {
                    if (assestList.length <=
                        TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                      var status = await Permission.photos.status;
                      if (status.isGranted) {
                        getImage("media");
                      }  else {
                        checkPermissionPhoto(context);
                      }

                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);
            } else {
              return  Container(
                  child:  Stack(
                    children: <Widget>[
                      FadeInImage.assetNetwork(
                        fit: BoxFit.cover,
                        placeholder: 'assets/aerial/default_img.png',
                        image: Constant.IMAGE_PATH + path,
                        height: 54.0,
                        width: 80.0,
                      ),
                       Container(
                        height: 54.0,
                        width: 80.0,
                        color:  Color(0XFFC0C0C0).withOpacity(.4),
                      ),
                      isPredefinedMediaSelected
                          ?  Container(
                        height: 0.0,
                      )
                          :  Container(
                          height: 54.0,
                          width: 80.0,
                          child:  Center(
                              child:  Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                   InkWell(
                                      child: PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                           Image.asset(
                                            "assets/newDesignIcon/achievment/remove.png",
                                            width: 35.0,
                                            height: 35.0,
                                          )),
                                      onTap: () {
                                        conformationDialog("media", path);
                                      })
                                ],
                              ))),
                    ],
                  ));
            }
          }).toList(),
        ));

    final certificateListUI =  Container(
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 3,
          children: certificateList.map((path) {
            if (path == "") {
              return  Stack(children: <Widget>[
                 InkWell(
                  child:  Container(
                      height: 54.0,
                      width: 80.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      )),
                  onTap: () async{
                    if (assestList.length <=
                        TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                      var status = await Permission.photos.status;
                      if (status.isGranted) {
                        getImage("certificates");
                      }  else {
                        checkPermissionPhoto(context);
                      }

                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);
            } else {
              return  Stack(
                children: <Widget>[
                  FadeInImage.assetNetwork(
                    fit: BoxFit.cover,
                    placeholder: 'assets/aerial/default_img.png',
                    image: Constant.IMAGE_PATH + path,
                    height: 54.0,
                    width: 80.0,
                  ),
                   Container(
                    height: 54.0,
                    width: 80.0,
                    color:  Color(0XFFC0C0C0).withOpacity(.4),
                  ),
                   Container(
                      height: 54.0,
                      width: 80.0,
                      child:  Center(
                          child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                 InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         Image.asset(
                                          "assets/newDesignIcon/achievment/remove.png",
                                          width: 35.0,
                                          height: 35.0,
                                        )),
                                    onTap: () {
                                      conformationDialog("certificate", path);
                                    })
                              ]))),
                ],
              );
            }
          }).toList(),
        ));

    final trophyListUi =  Container(
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: badgeAndTrophyList.map((path) {
            if (path.file == "") {
              return  Stack(children: <Widget>[
                 InkWell(
                  child:  Container(
                      height: 54.0,
                      width: 54.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      )),
                  onTap: () {
                    if (assestList.length <=
                        TextLength.ACCOMPLISHMENT_FILE_MAX_LENGTH) {
                      typeSelection();
                      // getImage("trophy");
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
                    }
                  },
                )
              ]);
            } else {
              return  Stack(
                children: <Widget>[
                  FadeInImage.assetNetwork(
                    fit: BoxFit.cover,
                    placeholder: 'assets/aerial/default_img.png',
                    image: Constant.IMAGE_PATH + path.file,
                    height: 54.0,
                    width: 62.0,
                  ),
                   Container(
                    height: 54.0,
                    width: 62.0,
                    color:  Color(0XFFC0C0C0).withOpacity(.4),
                  ),
                   Container(
                      height: 54.0,
                      width: 80.0,
                      child:  Center(
                          child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                 InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         Image.asset(
                                          "assets/newDesignIcon/achievment/remove.png",
                                          width: 35.0,
                                          height: 35.0,
                                        )),
                                    onTap: () {
                                      conformationDialog("badge", path);
                                    })
                              ]))),
                ],
              );
            }
          }).toList(),
        ));
    void infoDialog(type) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: type == "" ? 220.0 : 185.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: type == "" ? 170.0 : 130.0,
                                          padding: const EdgeInsets.fromLTRB(
                                              8.0, 0, 8, 0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: ListView(children: <Widget>[
                                            Padding(
                                              padding:
                                              const EdgeInsets.fromLTRB(
                                                  0.0, 13, 0, 10),
                                              child: Image.asset(
                                                'assets/profile/parent/info.png',
                                                height: 25.0,
                                                width: 25.0,
                                              ),
                                            ),
                                             Container(
                                                child: RichText(
                                                  maxLines: 5,
                                                  textAlign: TextAlign.center,
                                                  text: TextSpan(
                                                    text: listCompetency.length >
                                                        0 &&
                                                        listCompetency[
                                                        level1Position]
                                                            .level1 ==
                                                            "Sports"
                                                        ? type == "Acc"
                                                        ? "Add your sports experience or accomplishment here. If you are an athlete, consider adding a sports portfolio."
                                                        : 'As an athlete you can create, maintain and share a detailed sports portfolio. Select Add Portfolio to get started. This will be added to your spikeview profile and will be sharable to meet your needs.'
                                                        : type == "Acc"
                                                        ? "Add your arts experience or accomplishment here. If you are an athlete, consider adding a arts portfolio."
                                                        : "As an artist you can create, maintain and share a detailed arts portfolio. Select Add Portfolio to get started. This will be added to your spikeview profile and will be sharable to meet your needs. ",
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ))
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Close",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    //=================================
    Column getCompetencyItem(position) {
      return  Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              13.0,
              10.0,
              13.0,
              0.0,
               Container(
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      border:  Border.all(
                          color:   ColorValues.DEVIDER_COLOR,
                          width: 1.0)),
                  child:  InkWell(
                      child: ListTile(
                        trailing:  Container(
                            padding:  EdgeInsets.all(7.0),
                            height: 40.0,
                            width: 30.0,
                            child:  Image.asset(
                              listCompetency[position].isSelected
                                  ? "assets/up_arrow.png"
                                  : "assets/newDesignIcon/competency/down_arrow.png",
                              height: 15.0,
                              width: 15.0,
                            )),
                        title:  Text(
                          listCompetency[position].level1,
                          style:  TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 16.0,
                              color:
                               ColorValues.BLUE_COLOR_BOTTOMBAR),
                        ),
                      ),
                      onTap: () {
                        try {
                          if (listCompetency[position].isSelected) {
                            listCompetency[position].isSelected = false;
                            isPortFolioSelected = false;
                            isAccSelected = false;

                            setState(() {
                              listCompetency[position]
                                  .level2Competencylist[level2Position]
                                  .isSelected = false;
                              isSelectedList = false;
                              isSelectedLevel2 = false;
                            });
                          } else {
                            listCompetency[position].isSelected = true;
                            isSelectedList = true;
                            level1Position = position;
                          }
                          setState(() {
                            isOtherCategory = false;
                            secondLevelCompetencyController.text = "";
                            competencySelected = null;
                            strCompetencyValue = "";

                            isSelectedList;
                            listCompetency[position].isSelected;
                          });
                        } catch (e) {
                        }
                      }))),
          listCompetency[position].isSelected
              ? listCompetency[position].level1 == "Sports" ||
              listCompetency[position].level1 == "Arts"
              ? PaddingWrap.paddingfromLTRB(
              13.0,
              10.0,
              13.0,
              5.0,
               Container(
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      border:  Border.all(
                          color:   ColorValues.DEVIDER_COLOR,
                          width: 1.0)),
                  child:  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      (!isPortFolioSelected & !isAccSelected) ||
                          isAccSelected
                          ? PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                           Column(
                            children: <Widget>[
                               Container(
                                  child: ListTile(
                                    trailing:  InkWell(
                                      child: Image.asset(
                                        'assets/profile/parent/info.png',
                                        height: 25.0,
                                        width: 25.0,
                                      ),
                                      onTap: () {
                                        infoDialog("Acc");
                                      },
                                    ),
                                    title:  Text(
                                      "Add Accomplishment",
                                      style:  TextStyle(
                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 16.0,
                                          color:  ColorValues.HEADING_COLOR_EDUCATION),
                                    ),
                                    onTap: () {
                                      isShiftBelow = true;
                                      secondLevelCompetencyController
                                          .text = "";
                                      level2Position = 0;
                                      isOtherCategory = false;
                                      if (isAccSelected) {
                                        setState(() {
                                          level3Competencylist.clear();
                                          competencySelected = null;
                                          strCompetencyValue = "";
                                          isPortFolioSelected = false;
                                          isAccSelected = false;
                                          isSelectedLevel2 = false;
                                          level2Competencylist.clear();
                                        });
                                      } else {
                                        setState(() {
                                          isPortFolioSelected = false;
                                          isAccSelected = true;
                                          isSelectedLevel2 = true;
                                          level2Competencylist.clear();
                                          level2Competencylist.addAll(
                                              listCompetency[position]
                                                  .level2Competencylist);
                                        });
                                      }
                                    },
                                  )),
                               Divider(
                                color:  ColorValues.DEVIDER_COLOR,
                                height: 1.0,
                              )
                            ],
                          ))
                          :  Container(
                        height: 0.0,
                      ),
                      (!isPortFolioSelected & !isAccSelected) ||
                          isPortFolioSelected
                          ? PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                           Column(
                            children: <Widget>[
                               Container(
                                  child: ListTile(
                                    trailing:  InkWell(
                                      child: Image.asset(
                                        'assets/profile/parent/info.png',
                                        height: 25.0,
                                        width: 25.0,
                                      ),
                                      onTap: () {
                                        infoDialog("");
                                      },
                                    ),
                                    title:  Text(
                                      "Add Portfolio",
                                      style:  TextStyle(
                                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                          fontSize: 16.0,
                                          color:  ColorValues.HEADING_COLOR_EDUCATION),
                                    ),
                                    onTap: () {
                                      isShiftBelow = true;
                                      secondLevelCompetencyController
                                          .text = "";
                                      level2Position = 0;
                                      isOtherCategory = false;
                                      if (isPortFolioSelected) {
                                        level3Competencylist.clear();
                                        level2Competencylist.clear();
                                        competencySelected = null;
                                        strCompetencyValue = "";
                                        setState(() {
                                          isPortFolioSelected = false;
                                          isAccSelected = false;
                                        });
                                      } else {
                                        setState(() {
                                          isPortFolioSelected = true;
                                          isAccSelected = false;
                                          level2Competencylist.clear();
                                          level2Competencylist.addAll(
                                              listCompetency[position]
                                                  .level2Competencylist);
                                        });
                                      }
                                    },
                                  )),
                            ],
                          ))
                          :  Container(
                        height: 0.0,
                      ),
                    ],
                  )))
              : PaddingWrap.paddingfromLTRB(
              13.0,
              10.0,
              13.0,
              5.0,
               Container(
                  decoration:  BoxDecoration(
                      color: Colors.white,
                      border:  Border.all(
                          color:   ColorValues.DEVIDER_COLOR,
                          width: 1.0)),
                  child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children:  List.generate(
                          listCompetency[position]
                              .level2Competencylist
                              .length, (int index) {
                        return !isSelectedLevel2
                            ? PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                             Column(
                              children: <Widget>[
                                 Container(
                                    child: ListTile(
                                      trailing: ClipOval(
                                          child:  Container(
                                              color:
                                               ColorValues.GREY__COLOR_DIVIDER,
                                              padding:  EdgeInsets
                                                  .fromLTRB(
                                                  2.0, 2, 2, 2),
                                              height: 27.0,
                                              width: 27.0,
                                              child:  Image.asset(
                                                listCompetency[position]
                                                    .level2Competencylist[
                                                index]
                                                    .isSelected
                                                    ? "assets/up_arrow_new.png"
                                                    : "assets/down_arrow_new.png",
                                                height: 15.0,
                                                width: 15.0,
                                              ))),
                                      title:  Text(
                                        listCompetency[position]
                                            .level2Competencylist[index]
                                            .name,
                                        style:  TextStyle(
                                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 16.0,
                                            color:  ColorValues.HEADING_COLOR_EDUCATION),
                                      ),
                                      onTap: () {
                                        competencySelected = null;
                                        isOtherCategory = false;
                                        strCompetencyValue = "";
                                        level3Competencylist.clear();
                                        if (listCompetency[position]
                                            .level2Competencylist[index]
                                            .isSelected) {
                                          listCompetency[position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected = false;
                                          level2Position = index;
                                          isSelectedLevel2 = false;
                                          competencySelected = null;
                                          strCompetencyValue = "";
                                        } else {
                                          level2Position = index;
                                          listCompetency[position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected = true;
                                          isSelectedLevel2 = true;
                                          if (listCompetency[position]
                                              .level2Competencylist[
                                          index]
                                              .level3Competencylist
                                              .length ==
                                              1) {
                                            competencySelected =
                                            listCompetency[position]
                                                .level2Competencylist[
                                            index]
                                                .level3Competencylist[0];
                                            strCompetencyValue =
                                                listCompetency[position]
                                                    .level2Competencylist[
                                                index]
                                                    .level3Competencylist[
                                                0]
                                                    .name;
                                          }
                                        }
                                        setState(() {});
                                        setState(() {
                                          secondLevelCompetencyController
                                              .text = "";

                                          level3Competencylist.addAll(
                                              listCompetency[position]
                                                  .level2Competencylist[
                                              index]
                                                  .level3Competencylist);
                                          strCompetencyValue;
                                          competencySelected;
                                          level2Position;
                                          listCompetency[position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected;

                                          isSelectedLevel2;
                                          if (listCompetency[position]
                                              .level2Competencylist[
                                          index]
                                              .name ==
                                              "Other" ||
                                              listCompetency[position]
                                                  .level2Competencylist[
                                              index]
                                                  .name ==
                                                  "General") {
                                            isOtherCategory = true;
                                            /*   if (level2Competencylist[
                                                                index]
                                                            .name ==
                                                        "Other")
                                                      isOtherOption = true;
                                                    else
                                                      isOtherOption = false;*/

                                            otherCategory =
                                                TextEditingController(
                                                    text: "");
                                            editCategoryDialog(
                                                false, false, false);
                                          } else {
                                            isOtherCategory = false;
                                            otherCategory =
                                                TextEditingController(
                                                    text: "");
                                          }
                                        });
                                        _scrollController.jumpTo(_scrollController.position.minScrollExtent);

                                      },
                                    )),
                                (listCompetency[position]
                                    .level2Competencylist
                                    .length -
                                    1) ==
                                    index
                                    ?  Container(
                                  height: 0.0,
                                )
                                    :  Divider(
                                  color:  ColorValues.DEVIDER_COLOR,
                                  height: 1.0,
                                )
                              ],
                            ))
                            : listCompetency[position]
                            .level2Competencylist[index]
                            .isSelected
                            ? isOtherCategory
                            ? PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                             Column(
                              children: <Widget>[
                                 Container(
                                    child: ListTile(
                                      trailing: ClipOval(
                                          child:  Container(
                                              color:  Color(
                                                  0xffdedede),
                                              padding:
                                               EdgeInsets
                                                  .fromLTRB(
                                                  6.0,
                                                  3,
                                                  6,
                                                  6),
                                              height: 27.0,
                                              width: 27.0,
                                              child:  Image
                                                  .asset(
                                                "assets/up_arrow.png",
                                                height: 15.0,
                                                width: 15.0,
                                              ))),
                                      title:  InkWell(
                                        onTap: () {
                                          editCategoryDialog(
                                              false,
                                              true,
                                              true);
                                        },
                                        child:  Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .center,
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .start,
                                          children: [
                                            Padding(
                                                padding:
                                                const EdgeInsets
                                                    .fromLTRB(
                                                    0.0,
                                                    0,
                                                    5,
                                                    1),
                                                child:  Image
                                                    .asset(
                                                  "assets/newDesignIcon/userprofile/edit_grey.png",
                                                  height: 16.0,
                                                  width: 17.0,
                                                )),
                                             Text(
                                              strCompetencyValue,
                                              textAlign:
                                              TextAlign
                                                  .center,
                                              style:
                                               TextStyle(
                                                  color:
                                                   ColorValues.HEADING_COLOR_EDUCATION,
                                                  fontSize:
                                                  18.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            ),
                                          ],
                                        ),
                                      ),
                                      onTap: () {
                                        if (listCompetency[
                                        position]
                                            .level2Competencylist[
                                        index]
                                            .isSelected) {
                                          listCompetency[
                                          position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected = false;
                                          level2Position =
                                              index;
                                          isSelectedLevel2 =
                                          false;
                                        } else {
                                          level2Position =
                                              index;
                                          listCompetency[
                                          position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected = true;
                                          isSelectedLevel2 =
                                          true;
                                        }

                                        setState(() {
                                          level2Position;
                                          listCompetency[
                                          position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected;
                                          isSelectedLevel2;
                                        });
                                      },
                                    )),
                                (listCompetency[position]
                                    .level2Competencylist
                                    .length -
                                    1) ==
                                    index
                                    ?  Container(
                                  height: 0.0,
                                )
                                    :  Divider(
                                  color: ColorValues.DEVIDER_COLOR,
                                  height: 1.0,
                                )
                              ],
                            ))
                            : PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                             Column(
                              children: <Widget>[
                                 Container(
                                    child: ListTile(
                                      trailing: ClipOval(
                                          child:  Container(
                                              color:  Color(
                                                  0xffdedede),
                                              padding:
                                               EdgeInsets
                                                  .fromLTRB(
                                                  6.0,
                                                  3,
                                                  6,
                                                  6),
                                              height: 27.0,
                                              width: 27.0,
                                              child:  Image
                                                  .asset(
                                                listCompetency[
                                                position]
                                                    .level2Competencylist[
                                                index]
                                                    .isSelected
                                                    ? "assets/up_arrow.png"
                                                    : "assets/down_arrow_new.png",
                                                height: 15.0,
                                                width: 15.0,
                                              ))),
                                      title:  Text(
                                        listCompetency[position]
                                            .level2Competencylist[
                                        index]
                                            .name,
                                        style:  TextStyle(
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 16.0,
                                            color:  ColorValues.HEADING_COLOR_EDUCATION),
                                      ),
                                      onTap: () {
                                        if (listCompetency[
                                        position]
                                            .level2Competencylist[
                                        index]
                                            .isSelected) {
                                          listCompetency[
                                          position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected = false;
                                          level2Position =
                                              index;
                                          isSelectedLevel2 =
                                          false;
                                        } else {
                                          level2Position =
                                              index;
                                          listCompetency[
                                          position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected = true;
                                          isSelectedLevel2 =
                                          true;
                                        }

                                        setState(() {
                                          isOtherCategory =
                                          false;
                                          secondLevelCompetencyController
                                              .text = "";
                                          level2Position;
                                          listCompetency[
                                          position]
                                              .level2Competencylist[
                                          index]
                                              .isSelected;
                                          isSelectedLevel2;
                                        });
                                      },
                                    )),
                                (listCompetency[position]
                                    .level2Competencylist
                                    .length -
                                    1) ==
                                    index
                                    ?  Container(
                                  height: 0.0,
                                )
                                    :  Divider(
                                  color: ColorValues.DEVIDER_COLOR,
                                  height: 1.0,
                                )
                              ],
                            ))
                            :  Container(
                          height: 0.0,
                        );
                      }))))
              :  Container(
            height: 0.0,
          ),
          isSelectedList && isSelectedLevel2
              ? Form(
              key: _formKey,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                      22.0,
                      19.0,
                      22.0,
                      0.0,
                       Text(
                        listCompetency[position].level1 == "Sports" ||
                            listCompetency[position].level1 == "Arts"
                            ? "Add a memorable moment, activity, experience,  achievement, or a portfolio"
                            : ////only for Sport and arts
                        "Add a memorable moment, activity, experience, or an achievement",
                        // for other
                        style:  TextStyle(
                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                            fontSize: 14.0,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      )),
                  isAccSelected
                      ? PaddingWrap.paddingfromLTRB(
                      17.0,
                      10.0,
                      13.0,
                      0.0,
                       Text(
                        listCompetency[position].level1 == "Arts"
                            ? "Select Arts"
                            : "Select Sports",
                        style:  TextStyle(
                            fontSize: 14.0,
                            color:
                             ColorValues.GREY_TEXT_COLOR,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      ))
                      :  Container(
                    height: 0.0,
                  ),
                  isAccSelected
                      ? secondLevelCompetency
                      :  Container(
                    height: 0.0,
                  ),
                   Container(
                      color:  ColorValues.SCREEN_BG_COLOR,
                      child: PaddingWrap.paddingfromLTRB(
                          12.0,
                          12.0,
                          12.0,
                          10.0,
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                               Container(
                                decoration:  BoxDecoration(
                                    color: Colors.white,
                                    border:  Border.all(
                                        color:  ColorValues.BORDER_COLOR,
                                        width: 1.0)),
                                child: PaddingWrap.paddingfromLTRB(
                                    14.0,
                                    0.0,
                                    5.0,
                                    10.0,
                                     Row(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: <Widget>[
                                         Expanded(
                                          child:
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              17.0,
                                              15.0,
                                              0.0,
                                               Image.asset(
                                                "assets/newDesignIcon/achievment/title.png",
                                                width: 30.0,
                                                height: 30.0,
                                              )),
                                          flex: 0,
                                        ),
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: <Widget>[
                                              titleUi,
                                              descriptrionUi,
                                              //personalReflectionUi,
                                            ],
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    )),
                              ),
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                   Container(
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        border:  Border.all(
                                            color:  ColorValues.BORDER_COLOR,
                                            width: 1.0)),
                                    child: PaddingWrap.paddingfromLTRB(
                                        14.0,
                                        10.0,
                                        5.0,
                                        10.0,
                                         Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                             Expanded(
                                              child: PaddingWrap
                                                  .paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  15.0,
                                                  0.0,
                                                   Image.asset(
                                                    "assets/newDesignIcon/achievment/competency.png",
                                                    width: 30.0,
                                                    height: 30.0,
                                                  )),
                                              flex: 0,
                                            ),
                                             Expanded(
                                              child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <Widget>[
                                                  isOtherCategory
                                                      ? getEditCategoryTextField(
                                                      false,
                                                      "Focus Area",
                                                      false)
                                                      :  Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      competencySelected ==
                                                          null
                                                          ?  Container(
                                                        height:
                                                        10.0,
                                                      )
                                                          : PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          0.0,
                                                          getTextLabel(
                                                              "Focus Area",
                                                              11.0,
                                                               ColorValues.GREY_TEXT_COLOR,
                                                              FontWeight.normal)),
                                                      secondLevelCompetencyController.text ==
                                                          "" &&
                                                          isAccSelected
                                                          ? TextFormField(
                                                        keyboardType:
                                                        TextInputType.text,
                                                        enabled:
                                                        false,
                                                        maxLength:
                                                        TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
                                                        textCapitalization:
                                                        TextCapitalization.sentences,
                                                        cursorColor:
                                                        Constant.CURSOR_COLOR,
                                                        style: Util
                                                            .errorTextStyle,
                                                        controller:
                                                        thirdLevelController,
                                                        validator: (val) => val.trim().isEmpty ||
                                                            val.length == 0
                                                            ? MessageConstant.FIELD_REQUIRED
                                                            : null,
                                                        decoration:
                                                         InputDecoration(
                                                          contentPadding:
                                                          const EdgeInsets.fromLTRB(
                                                            0.0,
                                                            5.0,
                                                            5.0,
                                                            5.0,
                                                          ),
                                                          errorStyle:
                                                          Util.errorTextStyle,
                                                          labelText:
                                                          "Focus Area",
                                                          hintText:  MessageConstant.FOCUS_AREA_HINT_TEXT ,
                                                          counterText:
                                                          "",
                                                          labelStyle:
                                                           TextStyle(color:  ColorValues.GREY_TEXT_COLOR),
                                                          fillColor:
                                                          Colors.transparent,
                                                          enabledBorder:
                                                          UnderlineInputBorder(
                                                            borderSide:
                                                            BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                                                          ),
                                                          focusedBorder:
                                                          UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                                                        ),
                                                        // ),
                                                      )
                                                          :  Container(
                                                          height:
                                                          28.0,
                                                          padding:  EdgeInsets.fromLTRB(
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              5.0),
                                                          decoration:
                                                           BoxDecoration(border:  Border(bottom: BorderSide(color:  ColorValues.DARK_GREY, width: 1.0))),
                                                          width: double.infinity,
                                                          child:  DropdownButtonHideUnderline(
                                                              child:  DropdownButton<Level3Competencies>(
                                                                  hint:  Text(
                                                                    "Focus Area",
                                                                    style:  TextStyle(fontSize: 16.0, color:  ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                                  value: competencySelected,
                                                                  items: level3Competencylist
                                                                      .map((Level3Competencies item) =>  DropdownMenuItem<Level3Competencies>(
                                                                      value: item,
                                                                      child:  Text(item.name,
                                                                          style:  TextStyle(
                                                                            fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                          ))))
                                                                      .toList(),
                                                                  onChanged: (Level3Competencies item) {
                                                                    setState(() {
                                                                      FocusScope.of(context).requestFocus(new FocusNode());
                                                                      competencySelected = item;
                                                                      strCompetencyValue = item.name;
                                                                      isThirLevelField = true;
                                                                      thirdLevelController.text="";
                                                                    });
                                                                  }))),
                                                    ],
                                                  ),
                                                  listCompetency[level1Position]
                                                      .level2Competencylist[
                                                  level2Position]
                                                      .name !=
                                                      "Other" &&
                                                      strCompetencyValue ==
                                                          "Other"
                                                      ? Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .only(
                                                        top:
                                                        15.0),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .start,
                                                      children: [
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            5.0,
                                                            getTextLabel(
                                                                "Other, please specify",
                                                                14.0,
                                                                 Color(
                                                                    0XFFA7A7A7),
                                                                FontWeight
                                                                    .normal)),
                                                         Container(
                                                            width: double
                                                                .infinity,
                                                            height:
                                                            30.0,
                                                            decoration:  BoxDecoration(
                                                                border:  Border.all(
                                                                    color:  Color(
                                                                        0XFFDEDEDE))),
                                                            padding:  EdgeInsets
                                                                .fromLTRB(
                                                                0.0,
                                                                0.0,
                                                                0.0,
                                                                0.0),
                                                            margin: EdgeInsets
                                                                .all(
                                                                0.0),
                                                            child:
                                                             TextFormField(
                                                              keyboardType:
                                                              TextInputType.text,
                                                              controller:
                                                              thirdLevelController,
                                                              maxLength:
                                                              25,
                                                              cursorColor:
                                                              Constant.CURSOR_COLOR,
                                                              style:  TextStyle(
                                                                  color:
                                                                   ColorValues.HEADING_COLOR_EDUCATION,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                              textCapitalization:
                                                              TextCapitalization.sentences,
                                                              decoration:
                                                               InputDecoration(
                                                                counterText:
                                                                "",
                                                                disabledBorder:
                                                                InputBorder.none,
                                                                focusedBorder:
                                                                InputBorder.none,
                                                                enabledBorder:
                                                                InputBorder.none,
                                                                isDense:
                                                                true,
                                                                // Added this
                                                                contentPadding: EdgeInsets.only(
                                                                    left: 5.0,
                                                                    top: 1.0,
                                                                    bottom: 0.0),
                                                                floatingLabelBehavior:
                                                                FloatingLabelBehavior.always,
                                                              ),
                                                            )),
                                                        isThirLevelField
                                                            ?  Container(
                                                          height:
                                                          0.0,
                                                        )
                                                            : PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            0.0,
                                                            0.0,
                                                             Text(
                                                              MessageConstant.THIRD_LEVEL_REQUIRED,
                                                              style:
                                                               TextStyle(color: ColorValues.ERROR_COLOR, fontSize: 12.0),
                                                            ))
                                                      ],
                                                    ),
                                                  )
                                                      :  Container(
                                                      height: 0.0),



                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      20.0,
                                                      0.0,
                                                      5.0,
                                                      Row(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        children: <Widget>[
                                                          Expanded(
                                                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
                                                              InkWell(

                                                                  child: TextViewWrap.textView(skillsSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skillsSelectedList.length == 0 ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.GREY_TEXT_COLOR, skillsSelectedList.length == 0 ? 16.0 : 13.0, FontWeight.normal),
                                                                  onTap: () {
                                                                    setState(() {
                                                                      addSkillsError= false;
                                                                    });
                                                                    if (skillsSelectedList.length == 0) selectSkillDialog();
                                                                  }),

                                                              addSkillsError ?
                                                              PaddingWrap.paddingfromLTRB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0,  Text(

                                                                MessageConstant.SELECT_SKILLS_VAL,
                                                                maxLines: 1,
                                                                style: TextStyle(fontSize: 12.0, color: ColorValues.ERROR_COLOR),
                                                              )):Container(height: 0,),

                                                            ]),
                                                            flex: 1,
                                                          )
                                                        ],
                                                      )),
                                                   Row(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .end,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: <Widget>[
                                                       Expanded(
                                                        child: Wrap(
                                                          children:
                                                          _buildChoiceList(),
                                                        ),
                                                        flex: 1,
                                                      ),
                                                       Expanded(
                                                        child: skillsSelectedList
                                                            .length ==
                                                            0
                                                            ?  Container(
                                                          height: 0.0,
                                                        )
                                                            :  InkWell(
                                                          child:  Container(
                                                              height: 20.0,
                                                              width: 40.0,
                                                              child: Icon(
                                                                Icons
                                                                    .add,
                                                                color:
                                                                Colors.black,
                                                                size:
                                                                20.0,
                                                              )),
                                                          onTap: () {
                                                            selectSkillDialog();
                                                          },
                                                        ),
                                                        flex: 0,
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              flex: 1,
                                            )
                                          ],
                                        )),
                                  )),
                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                   Container(
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        border:  Border.all(
                                            color:  ColorValues.BORDER_COLOR,
                                            width: 1.0)),
                                    child: PaddingWrap.paddingfromLTRB(
                                        14.0,
                                        10.0,
                                        5.0,
                                        10.0,
                                         Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                             Expanded(
                                              child: PaddingWrap
                                                  .paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  15.0,
                                                  0.0,
                                                   Image.asset(
                                                    "assets/newDesignIcon/achievment/achiewvement_level.png",
                                                    width: 30.0,
                                                    height: 30.0,
                                                  )),
                                              flex: 0,
                                            ),
                                             Expanded(
                                              child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .start,
                                                mainAxisAlignment:
                                                MainAxisAlignment.start,
                                                children: <Widget>[
                                                  /*skillUi,*/
                                                  levelSelected == null
                                                      ?  Container(
                                                    height: 10.0,
                                                  )
                                                      : PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      getTextLabel(
                                                          listCompetency[level1Position]
                                                              .level1 ==
                                                              "Life Experiences"
                                                              ? "Experiences Level"
                                                              : "Achievement Level",
                                                          12.0,
                                                           ColorValues.GREY_TEXT_COLOR,
                                                          FontWeight
                                                              .normal)),
                                                   Container(
                                                      height: 28.0,
                                                      padding:
                                                       EdgeInsets
                                                          .fromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          5.0),
                                                      decoration:  BoxDecoration(
                                                          border:  Border(
                                                              bottom: BorderSide(
                                                                  color:  ColorValues.DARK_GREY,
                                                                  width:
                                                                  1.0))),
                                                      width: double.infinity,
                                                      child:  DropdownButtonHideUnderline(
                                                          child:  DropdownButton<AchievementImportanceModal>(
                                                              hint:  Text(
                                                                listCompetency[level1Position].level1 ==
                                                                    "Life Experiences"
                                                                    ? "Experiences Level"
                                                                    : "Achievement Level",
                                                                style:  TextStyle(
                                                                    fontSize:
                                                                    16.0,
                                                                    color:   ColorValues.GREY_TEXT_COLOR,
                                                                    fontFamily:
                                                                    Constant.TYPE_CUSTOMREGULAR),
                                                              ),
                                                              value: levelSelected,
                                                              items: dropdownMenuLevel,
                                                              onChanged: (AchievementImportanceModal level) {
                                                                setState(
                                                                        () {
                                                                          selectAchivmentLevel= false;
                                                                      FocusScope.of(
                                                                          context)
                                                                          .requestFocus(
                                                                           FocusNode());
                                                                      levelSelected =
                                                                          level;
                                                                      strLevelValue =
                                                                          level
                                                                              .importanceId;
                                                                    });
                                                              }))),

                                                  selectAchivmentLevel ?
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      5.0,
                                                      0.0,
                                                      0.0,  Text(

                                                    MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL,
                                                    maxLines: 1,
                                                    style: TextStyle(fontSize: 12.0, color: ColorValues.ERROR_COLOR),
                                                  )):Container(height: 0,),



                                                  listCompetency[position]
                                                      .level2Competencylist[
                                                  level2Position]
                                                      .name ==
                                                      "Volunteering"
                                                      ? workingHours
                                                      :  Container(
                                                      height: 0.0),

                                                 listCompetency[position].level1 == "Sports" ?
                                                 PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          10.0,
                                                          0.0,
                                                          0.0,
                                                           Row(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            children: <Widget>[
                                                               Expanded(
                                                                child:  Column(
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  children: <Widget>[heightUi],
                                                                ),
                                                                flex: 5,
                                                              ),
                                                               Expanded(
                                                                child:  Container(),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:  Column(
                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                  children: <Widget>[weightUi],
                                                                ),
                                                                flex: 5,
                                                              ),
                                                            ],
                                                          )) : Container(),

                                                  PaddingWrap
                                                      .paddingfromLTRB(
                                                      0.0,
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                       Row(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .start,
                                                        children: <
                                                            Widget>[
                                                           Expanded(
                                                            child:
                                                             Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              children: <
                                                                  Widget>[
                                                                fromDateUi
                                                              ],
                                                            ),
                                                            flex: 6,
                                                          ),
                                                           Expanded(
                                                            child:
                                                             Container(),
                                                            flex: 1,
                                                          ),
                                                           Expanded(
                                                            child:
                                                             Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              children: <
                                                                  Widget>[
                                                                toDateUi
                                                              ],
                                                            ),
                                                            flex: 6,
                                                          ),
                                                        ],
                                                      )),
                                                  PaddingWrap
                                                      .paddingfromLTRB(
                                                      0.0,
                                                      8.0,
                                                      0.0,
                                                      8.0,
                                                       Row(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .end,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .end,
                                                        children: <
                                                            Widget>[
                                                           Expanded(
                                                            child:
                                                             Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              children: <
                                                                  Widget>[],
                                                            ),
                                                            flex: 6,
                                                          ),
                                                           Expanded(
                                                            child:
                                                             Container(),
                                                            flex: 1,
                                                          ),
                                                           Expanded(
                                                            child:
                                                             Row(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              children: <
                                                                  Widget>[
                                                                 Expanded(
                                                                  child:
                                                                   InkWell(
                                                                    child:
                                                                     Image.asset(
                                                                      isPresent ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                      width: 25.0,
                                                                      height: 25.0,
                                                                    ),
                                                                    onTap:
                                                                        () {
                                                                      if (isPresent)
                                                                        isPresent = false;
                                                                      else
                                                                        isPresent = true;
                                                                      setState(() {
                                                                        isPresent;
                                                                        toDate = null;
                                                                        strToDate = "";
                                                                        toDateController =  TextEditingController(text: "");
                                                                      });
                                                                    },
                                                                  ),
                                                                  flex:
                                                                  0,
                                                                ),
                                                                 Expanded(
                                                                  child:
                                                                  Container(
                                                                    padding:  EdgeInsets.fromLTRB(
                                                                        5.0,
                                                                        3.0,
                                                                        0.0,
                                                                        0.0),
                                                                    child:
                                                                     Container(child: TextViewWrap.textView("Ongoing   ", TextAlign.start,  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                  ),
                                                                  flex:
                                                                  0,
                                                                )
                                                              ],
                                                            ),
                                                            flex: 6,
                                                          )
                                                        ],
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            )
                                          ],
                                        )),
                                  )),

                              PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  10.0,
                                  0.0,
                                  0.0,
                                   Container(
                                    decoration:  BoxDecoration(
                                        color: Colors.white,
                                        border:  Border.all(
                                            color:  ColorValues.BORDER_COLOR,
                                            width: 1.0)),
                                    child: PaddingWrap.paddingfromLTRB(
                                        14.0,
                                        10.0,
                                        5.0,
                                        10.0,
                                         InkWell(
                                          child:  Row(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                            MainAxisAlignment.start,
                                            children: <Widget>[
                                               Expanded(
                                                child: PaddingWrap
                                                    .paddingfromLTRB(
                                                    0.0,
                                                    10.0,
                                                    15.0,
                                                    0.0,
                                                     Image.asset(
                                                      "assets/newDesignIcon/achievment/media.png",
                                                      width: 30.0,
                                                      height: 30.0,
                                                    )),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                child:  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        10.0,
                                                        TextViewWrap.textView(
                                                            "Add media",
                                                            TextAlign.start,
                                                             ColorValues.HEADING_COLOR_EDUCATION,
                                                            16.0,
                                                            FontWeight
                                                                .normal)),
                                                    PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        TextViewWrap.textViewMultiLine(
                                                            "Upload Photos, Videos or Images of Certificates, Trophies, and Badges to enrich and embellish your Profile",
                                                            TextAlign.start,
                                                             ColorValues.GREY_TEXT_COLOR,
                                                            14.0,
                                                            FontWeight
                                                                .normal,
                                                            4)),
                                                    isShowMedia
                                                        ?  Column(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            0.0,
                                                            20.0,
                                                            0.0,
                                                            10.0,
                                                             Text(
                                                              "Photos",
                                                              style:  TextStyle(
                                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                                  fontSize: 14.0,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            )),
                                                        mediaImageListUI,
                                                        Padding(
                                                          padding:
                                                          const EdgeInsets.fromLTRB(
                                                              0.0,
                                                              0,
                                                              20,
                                                              10),
                                                          child: isPredefinedMediaSelected &&
                                                              imageList.length >
                                                                  0
                                                              ?  Row(
                                                            children: <Widget>[
                                                               Expanded(
                                                                child:  Stack(
                                                                  children: <Widget>[
                                                                     InkWell(
                                                                      child:  Container(
                                                                          height: 65,
                                                                          width: 65,
                                                                          padding:  EdgeInsets.fromLTRB(0, 8, 10, 8),
                                                                          child: FadeInImage.assetNetwork(
                                                                            fit: BoxFit.fill,
                                                                            width: 65,
                                                                            alignment: Alignment.center,
                                                                            placeholder: 'assets/aerial/feed_default_img.png',
                                                                            image: Constant.IMAGE_PATH + imageList[0],
                                                                          )),
                                                                      onTap: () {
                                                                        setState(() {
                                                                          selectedIndexCover = 0;
                                                                          mediaList.removeLast();
                                                                          mediaList.removeLast();
                                                                          mediaList.add(imageList[0]);
                                                                          mediaList.add("");
                                                                        });
                                                                      },
                                                                    ),
                                                                    selectedIndexCover == 0
                                                                        ?  Align(
                                                                      alignment: Alignment.center,
                                                                      child: Padding(
                                                                        padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                        child:  Container(
                                                                            child:  Image.asset(
                                                                              "assets/profile/student/select_circle.png",
                                                                              height: 25.0,
                                                                              width: 25.0,
                                                                            )),
                                                                      ),
                                                                    )
                                                                        :  Container(
                                                                      height: 0.0,
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:  Stack(
                                                                  children: <Widget>[
                                                                     InkWell(
                                                                      child:  Container(
                                                                          height: 65,
                                                                          width: 65,
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                          child: FadeInImage.assetNetwork(
                                                                            fit: BoxFit.fill,
                                                                            width: 65,
                                                                            alignment: Alignment.center,
                                                                            placeholder: 'assets/aerial/feed_default_img.png',
                                                                            image: Constant.IMAGE_PATH + imageList[1],
                                                                          )),
                                                                      onTap: () {
                                                                        setState(() {
                                                                          selectedIndexCover = 1;
                                                                          mediaList.removeLast();
                                                                          mediaList.removeLast();
                                                                          mediaList.add(imageList[1]);
                                                                          mediaList.add("");
                                                                        });
                                                                      },
                                                                    ),
                                                                    selectedIndexCover == 1
                                                                        ?  Align(
                                                                      alignment: Alignment.center,
                                                                      child: Padding(
                                                                        padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                        child:  Container(
                                                                            child:  Image.asset(
                                                                              "assets/profile/student/select_circle.png",
                                                                              height: 25.0,
                                                                              width: 25.0,
                                                                            )),
                                                                      ),
                                                                    )
                                                                        :  Container(
                                                                      height: 0.0,
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:  Stack(
                                                                  children: <Widget>[
                                                                     InkWell(
                                                                      child:  Container(
                                                                          height: 65,
                                                                          width: 65,
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                          child: FadeInImage.assetNetwork(
                                                                            fit: BoxFit.fill,
                                                                            width: 65,
                                                                            alignment: Alignment.center,
                                                                            placeholder: 'assets/aerial/feed_default_img.png',
                                                                            image: Constant.IMAGE_PATH + imageList[2],
                                                                          )),
                                                                      onTap: () {
                                                                        setState(() {
                                                                          selectedIndexCover = 2;
                                                                          mediaList.removeLast();
                                                                          mediaList.removeLast();
                                                                          mediaList.add(imageList[2]);
                                                                          mediaList.add("");
                                                                        });
                                                                      },
                                                                    ),
                                                                    selectedIndexCover == 2
                                                                        ?  Align(
                                                                      alignment: Alignment.center,
                                                                      child: Padding(
                                                                        padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                        child:  Container(
                                                                            child:  Image.asset(
                                                                              "assets/profile/student/select_circle.png",
                                                                              height: 25.0,
                                                                              width: 25.0,
                                                                            )),
                                                                      ),
                                                                    )
                                                                        :  Container(
                                                                      height: 0.0,
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:  Stack(
                                                                  children: <Widget>[
                                                                     InkWell(
                                                                      child:  Container(
                                                                          height: 65,
                                                                          width: 65,
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                          child: FadeInImage.assetNetwork(
                                                                            fit: BoxFit.fill,
                                                                            width: 65,
                                                                            alignment: Alignment.center,
                                                                            placeholder: 'assets/aerial/feed_default_img.png',
                                                                            image: Constant.IMAGE_PATH + imageList[3],
                                                                          )),
                                                                      onTap: () {
                                                                        setState(() {
                                                                          selectedIndexCover = 3;
                                                                          mediaList.removeLast();
                                                                          mediaList.removeLast();
                                                                          mediaList.add(imageList[3]);
                                                                          mediaList.add("");
                                                                        });
                                                                      },
                                                                    ),
                                                                    selectedIndexCover == 3
                                                                        ?  Align(
                                                                      alignment: Alignment.center,
                                                                      child: Padding(
                                                                        padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                        child:  Container(
                                                                            child:  Image.asset(
                                                                              "assets/profile/student/select_circle.png",
                                                                              height: 25.0,
                                                                              width: 25.0,
                                                                            )),
                                                                      ),
                                                                    )
                                                                        :  Container(
                                                                      height: 0.0,
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:  Stack(
                                                                  children: <Widget>[
                                                                     InkWell(
                                                                      child:  Container(
                                                                          height: 65,
                                                                          width: 65,
                                                                          padding:  EdgeInsets.fromLTRB(0.0, 8, 10, 8),
                                                                          child: FadeInImage.assetNetwork(
                                                                            fit: BoxFit.fill,
                                                                            width: 65,
                                                                            alignment: Alignment.center,
                                                                            placeholder: 'assets/aerial/feed_default_img.png',
                                                                            image: Constant.IMAGE_PATH + imageList[4],
                                                                          )),
                                                                      onTap: () {
                                                                        setState(() {
                                                                          selectedIndexCover = 4;
                                                                          mediaList.removeLast();
                                                                          mediaList.removeLast();
                                                                          mediaList.add(imageList[4]);
                                                                          mediaList.add("");
                                                                        });
                                                                      },
                                                                    ),
                                                                    selectedIndexCover == 4
                                                                        ?  Align(
                                                                      alignment: Alignment.center,
                                                                      child: Padding(
                                                                        padding: const EdgeInsets.fromLTRB(0, 20.0, 12, 0),
                                                                        child:  Container(
                                                                            child:  Image.asset(
                                                                              "assets/profile/student/select_circle.png",
                                                                              height: 25.0,
                                                                              width: 25.0,
                                                                            )),
                                                                      ),
                                                                    )
                                                                        :  Container(
                                                                      height: 0.0,
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              )
                                                            ],
                                                          )
                                                              :  Container(
                                                            height:
                                                            0.0,
                                                          ),
                                                        ),
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            0.0,
                                                            10.0,
                                                            0.0,
                                                            10.0,
                                                             Text(
                                                              "Videos",
                                                              style:  TextStyle(
                                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                                  fontSize: 14.0,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            )),
                                                        videoListUi,
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            0.0,
                                                            20.0,
                                                            0.0,
                                                            10.0,
                                                             Text(
                                                              "Certificates",
                                                              style:  TextStyle(
                                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                                  fontSize: 14.0,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            )),
                                                        certificateListUI,
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                            0.0,
                                                            20.0,
                                                            0.0,
                                                            10.0,
                                                             Text(
                                                              "Trophies & Badges",
                                                              style:  TextStyle(
                                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                                  fontSize: 14.0,
                                                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            )),
                                                        trophyListUi
                                                      ],
                                                    )
                                                        :  Container(
                                                      height: 0.0,
                                                    ),
                                                  ],
                                                ),
                                                flex: 1,
                                              )
                                            ],
                                          ),
                                          onTap: () {
                                            setState(() {
                                              isShowMedia = true;
                                            });
                                          },
                                        )),
                                  )),
                              UIHelper.verticalGapBetweenBox,
                              externalLinkWidget(),
                              UIHelper.verticalGapBetweenBox,
                              personalReflectionWidget(),
                            ],
                          ))),
                   Container(
                      color:  ColorValues.SCREEN_BG_COLOR,
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          7.0,
                          0.0,
                          0.0,
                           Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                isPrompt
                                    ? PaddingWrap.paddingfromLTRB(
                                    16.0,
                                    0.0,
                                    16.0,
                                    10.0,
                                     Row(
                                      children: <Widget>[
                                        PaddingWrap.paddingAll(
                                            0.0,
                                             InkWell(
                                              child:  Image.asset(
                                                "assets/newDesignIcon/login/check.png",
                                                width: 25.0,
                                                height: 25.0,
                                              ),
                                              onTap: () {
                                                if (prefs.getString(
                                                    UserPreference
                                                        .ISACTIVE) ==
                                                    "true") {
                                                  if (isPrompt)
                                                    isPrompt = false;
                                                  else
                                                    isPrompt = true;
                                                  setState(() {
                                                    isPrompt;
                                                  });
                                                } else {
                                                  ToastWrap.showToast(
                                                      MessageConstant
                                                          .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                                      context);
                                                }
                                              },
                                            )),
                                         Text(
                                          "  Ask for recommendation",
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 16.0,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                        ),
                                      ],
                                    ))
                                    : PaddingWrap.paddingfromLTRB(
                                    16.0,
                                    0.0,
                                    16.0,
                                    10.0,
                                     Row(
                                      children: <Widget>[
                                        PaddingWrap.paddingAll(
                                            0.0,
                                            PaddingWrap.paddingAll(
                                                0.0,
                                                 InkWell(
                                                  child:
                                                   Image.asset(
                                                    isPrompt
                                                        ? "assets/newDesignIcon/login/check.png"
                                                        : "assets/newDesignIcon/login/uncheck.png",
                                                    width: 25.0,
                                                    height: 25.0,
                                                  ),
                                                  onTap: () {
                                                    if (prefs.getString(
                                                        UserPreference
                                                            .ISACTIVE) ==
                                                        "true") {
                                                      if (isPrompt)
                                                        isPrompt =
                                                        false;
                                                      else
                                                        isPrompt = true;
                                                      setState(() {
                                                        isPrompt;
                                                      });
                                                    } else {
                                                      ToastWrap.showToast(
                                                          MessageConstant
                                                              .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                                          context);
                                                    }
                                                  },
                                                ))),
                                         Text(
                                          "  Ask for recommendation",
                                          style:  TextStyle(
                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                              fontSize: 16.0,
                                              fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                        ),
                                      ],
                                    )),
                                isPrompt
                                    ?  Container(
                                    child:  Container(
                                        decoration:  BoxDecoration(
                                            color: Colors.white,
                                            border:  Border(
                                                bottom: BorderSide(
                                                    color:  ColorValues.DARK_GREY,
                                                    width: 1.0),
                                                top: BorderSide(
                                                    color:  ColorValues.DARK_GREY,
                                                    width: 1.0))),
                                        child:
                                        PaddingWrap.paddingfromLTRB(
                                            16.0,
                                            0.0,
                                            16.0,
                                            20.0,
                                             Column(
                                              children: <Widget>[
                                                recommendationTitle,
                                                recommendationRequest,
                                                PaddingWrap
                                                    .paddingfromLTRB(
                                                    0.0,
                                                    15.0,
                                                    0.0,
                                                    0.0,
                                                     Container(
                                                        padding:
                                                         EdgeInsets.all(
                                                            5.0),
                                                        color:  Color(
                                                            0XFFE9E9E9),
                                                        width: double
                                                            .infinity,
                                                        child:
                                                         Text(
                                                          "RECOMMENDER DETAILS",
                                                          style:  TextStyle(
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontSize: 12.0,
                                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                        ))),
                                                recommenderTitle,
                                                coachFirstName,
                                                coachLastName,
                                                coachEmail,
                                              ],
                                            ))))
                                    :  Container(
                                  height: 0.0,
                                )
                              ]))),
                  /*   Container(
                          child: Padding(
                              padding:  EdgeInsets.only(
                                  left: 15.0,
                                  top: 40.0,
                                  right: 15.0,
                                  bottom: 7.0),
                              child:  Container(
                                  height: 32.0,
                                  width: 148,
                                  child: FlatButton(
                                    onPressed: () {
                                      final form = _formKey.currentState;

                                      form.save();
                                      if (form.validate()) {
                                        if (validationCheck()) {
                                          apiCalling();
                                        }
                                      } else {
                                        ToastWrap.showToast(
                                            MessageConstant
                                                .ENTER_VALUE_ACCOMPLISHMENT_FIELD_VAL,
                                            context);
                                      }
                                    },
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(0)),
                                    color:  ColorValues.BLUE_COLOR,
                                    child: Row(
                                      // Replace with a Row for horizontal icon + text
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Text('SAVE ',
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                color: Colors.white)),
                                      ],
                                    ),
                                  ))))*/
                ],
              ))
              : isPortFolioSelected
              ? Form(
            key: _formKey,
            child:  Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    17.0,
                    19.0,
                    22.0,
                    0.0,
                     Text(
                      listCompetency[position].level1 == "Arts"
                          ? "Create your detailed arts portfolio and showcase your talents. The more details you can add, the better."
                          : "Create your detailed sports portfolio and showcase your talents. The more details you can add, the better.",
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    )),
                PaddingWrap.paddingfromLTRB(
                    17.0,
                    10.0,
                    13.0,
                    0.0,
                     Text(
                      listCompetency[position].level1 == "Arts"
                          ? "Select Arts"
                          : "Select Sports",
                      style:  TextStyle(
                          fontSize: 14.0,
                          color:
                           ColorValues.GREY_TEXT_COLOR,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    )),
                secondLevelCompetency,
                 Row(
                  children: [
                     Expanded(
                      child: Padding(
                        padding:
                        const EdgeInsets.fromLTRB(13.0, 0, 0, 0),
                        child: isImageSelectedView(),
                      ),
                      flex: 0,
                    ),
                     Expanded(
                      child: Padding(
                        padding:
                        const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
                        child:  Text(MessageConstant.ADD_PHOTO,
                            style:  TextStyle(
                                fontSize: 12.0,
                                color:  ColorValues.GREY__COLOR,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                      ),
                      flex: 1,
                    )
                  ],
                ),
                 Container(
                    color:  ColorValues.SCREEN_BG_COLOR,
                    child: PaddingWrap.paddingfromLTRB(
                        12.0,
                        12.0,
                        12.0,
                        10.0,
                        Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: <Widget>[
                             Container(
                              decoration: BoxDecoration(
                                borderRadius:
                                BorderRadius.circular(0),
                                color: Colors.white,
                                border: Border.all(
                                  color: Color(0xFFFDEDEDE),
                                  style: BorderStyle.solid,
                                  width: 1.0,
                                ),
                              ),
                              child: PaddingWrap.paddingfromLTRB(
                                  14.0,
                                  0.0,
                                  5.0,
                                  10.0,
                                   Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    children: <Widget>[
                                       Expanded(
                                        child: PaddingWrap
                                            .paddingfromLTRB(
                                            0.0,
                                            17.0,
                                            15.0,
                                            0.0,
                                             Image.asset(
                                              "assets/newDesignIcon/achievment/title.png",
                                              width: 30.0,
                                              height: 30.0,
                                            )),
                                        flex: 0,
                                      ),
                                       Expanded(
                                        child:  Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                              const EdgeInsets
                                                  .fromLTRB(
                                                  0.0, 13, 0, 3),
                                              child:  Text(
                                                "About Portfolio",
                                                style:  TextStyle(
                                                    color:  Color(
                                                        0XFF151515),
                                                    fontSize: 16.0,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR),
                                              ),
                                            ),
                                             Text(
                                              listCompetency[position]
                                                  .level1 ==
                                                  "Arts"
                                                  ? "Create an immersive, detailed art portfolio to showcase your talents. The more you can add the better."
                                                  : "Let your talent shine. Create you detailed sports portfolio here.",
                                              style:  TextStyle(
                                                  color:  Color(
                                                      0XFF9a9c9c),
                                                  fontSize: 12.0,
                                                  fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                            ),
                                            titleUi,
                                            listCompetency[position]
                                                .level1 ==
                                                "Arts"
                                                ? bioUi
                                                :  Container(
                                              height: 0.0,
                                            ),
                                            descriptrionUi,
                                            cityUi,
                                            stateUi
                                          ],
                                        ),
                                        flex: 1,
                                      )
                                    ],
                                  )),
                            ),

                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                 Container(
                                  decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.circular(0),
                                    color: Colors.white,
                                    border: Border.all(
                                      color: Color(0xFFFDEDEDE),
                                      style: BorderStyle.solid,
                                      width: 1.0,
                                    ),
                                  ),
                                  child: PaddingWrap.paddingfromLTRB(
                                      14.0,
                                      10.0,
                                      5.0,
                                      10.0,
                                       Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                           Expanded(
                                            child: PaddingWrap
                                                .paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                15.0,
                                                0.0,
                                                 Image.asset(
                                                  "assets/newDesignIcon/achievment/competency.png",
                                                  width: 30.0,
                                                  height: 30.0,
                                                )),
                                            flex: 0,
                                          ),
                                           Expanded(
                                            child:  Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                isOtherCategory
                                                    ? getEditCategoryTextField(
                                                    false,
                                                    "Focus Area",
                                                    false)
                                                    :  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: [
                                                    competencySelected ==
                                                        null
                                                        ?  Container(
                                                      height:
                                                      10.0,
                                                    )
                                                        : PaddingWrap.paddingfromLTRB(
                                                        0.0,
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        getTextLabel(
                                                            "Focus Area",
                                                            11.0,
                                                             ColorValues.GREY_TEXT_COLOR,
                                                            FontWeight.normal)),
                                                    secondLevelCompetencyController.text ==
                                                        ""
                                                        ? /*  InkWell(
                                                                            onTap:
                                                                                () {
                                                                              ToastWrap.showToast(listCompetency[position].level1 == "Arts" ? MessageConstant.REQUIRED_ARTS : MessageConstant.REQUIRED_SPORTS, context);
                                                                            },
                                                                            child:*/
                                                    TextFormField(
                                                      keyboardType:
                                                      TextInputType.text,
                                                      enabled:
                                                      false,
                                                      maxLength:
                                                      TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
                                                      textCapitalization:
                                                      TextCapitalization.sentences,
                                                      cursorColor:
                                                      Constant.CURSOR_COLOR,
                                                      controller:
                                                      thirdLevelController,
                                                      validator: (val) => val.trim().isEmpty || val.length == 0
                                                          ? MessageConstant.FIELD_REQUIRED
                                                          : null,
                                                      style:
                                                      Util.errorTextStyle,
                                                      decoration:
                                                       InputDecoration(
                                                        contentPadding: const EdgeInsets.fromLTRB(
                                                          0.0,
                                                          5.0,
                                                          5.0,
                                                          5.0,
                                                        ),
                                                        labelText: "Focus Area",
                                                        hintText:  MessageConstant.FOCUS_AREA_HINT_TEXT ,
                                                        counterText: "",
                                                        errorStyle: Util.errorTextStyle,
                                                        labelStyle:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR),
                                                        fillColor: Colors.transparent,
                                                        enabledBorder: UnderlineInputBorder(
                                                          borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                                                        ),
                                                        focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                                                      ),
                                                      //),
                                                    )
                                                        :  Container(
                                                        height:
                                                        28.0,
                                                        padding:  EdgeInsets.fromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            5.0),
                                                        decoration:
                                                         BoxDecoration(border:  Border(bottom: BorderSide(color:  ColorValues.DARK_GREY, width: 1.0))),
                                                        width: double.infinity,
                                                        child:  DropdownButtonHideUnderline(
                                                            child:  DropdownButton<Level3Competencies>(
                                                                hint:  Text(
                                                                  "Focus Area",
                                                                  style:  TextStyle(fontSize: 16.0, color:  ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                ),
                                                                value: competencySelected,
                                                                items: level3Competencylist
                                                                    .map((Level3Competencies item) =>  DropdownMenuItem<Level3Competencies>(
                                                                    value: item,
                                                                    child:  Text(item.name,
                                                                        style:  TextStyle(
                                                                          fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        ))))
                                                                    .toList(),
                                                                onChanged: (Level3Competencies item) {
                                                                  setState(() {
                                                                    FocusScope.of(context).requestFocus(new FocusNode());
                                                                    competencySelected = item;
                                                                    strCompetencyValue = item.name;
                                                                    isThirLevelField = true;
                                                                    thirdLevelController.text="";
                                                                  });
                                                                }))),
                                                  ],
                                                ),
                                                listCompetency[level1Position]
                                                    .level2Competencylist[
                                                level2Position]
                                                    .name !=
                                                    "Other" &&
                                                    strCompetencyValue ==
                                                        "Other"
                                                    ? Padding(
                                                  padding: const EdgeInsets
                                                      .only(
                                                      top:
                                                      15.0),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          5.0,
                                                          getTextLabel(
                                                              "Other, please specify",
                                                              14.0,
                                                               ColorValues.TEXT_LIGHT_GREY,
                                                              FontWeight.normal)),
                                                       Container(
                                                          width: double
                                                              .infinity,
                                                          height:
                                                          30.0,
                                                          decoration:  BoxDecoration(
                                                              border:  Border.all(
                                                                  color:  Color(
                                                                      0XFFDEDEDE))),
                                                          padding:  EdgeInsets.fromLTRB(
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              0.0),
                                                          margin: EdgeInsets.all(
                                                              0.0),
                                                          child:
                                                           TextFormField(
                                                            keyboardType:
                                                            TextInputType.text,
                                                            controller:
                                                            thirdLevelController,
                                                            maxLength:
                                                            25,
                                                            cursorColor:
                                                            Constant.CURSOR_COLOR,
                                                            style:
                                                             TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                            textCapitalization:
                                                            TextCapitalization.sentences,
                                                            decoration:
                                                             InputDecoration(
                                                              counterText: "",
                                                              disabledBorder: InputBorder.none,
                                                              focusedBorder: InputBorder.none,
                                                              enabledBorder: InputBorder.none,
                                                              isDense: true,
                                                              // Added this
                                                              contentPadding: EdgeInsets.only(left: 5.0, top: 1.0, bottom: 0.0),
                                                              floatingLabelBehavior: FloatingLabelBehavior.always,
                                                            ),
                                                          )),
                                                      isThirLevelField
                                                          ?  Container(
                                                        height: 0.0,
                                                      )
                                                          : PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          5.0,
                                                          0.0,
                                                          0.0,
                                                           Text(
                                                            MessageConstant.THIRD_LEVEL_REQUIRED,
                                                            style:  TextStyle(color: ColorValues.ERROR_COLOR, fontSize: 12.0),
                                                          ))
                                                    ],
                                                  ),
                                                )
                                                    :  Container(
                                                    height: 0.0),
                                                PaddingWrap
                                                    .paddingfromLTRB(
                                                    0.0,
                                                    20.0,
                                                    0.0,
                                                    5.0,
                                                     Row(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                         Expanded(
                                                          child:  InkWell(
                                                              child: TextViewWrap.textView(skillsSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skillsSelectedList.length == 0 ?  ColorValues.BLUE_COLOR_BOTTOMBAR :  ColorValues.GREY_TEXT_COLOR, skillsSelectedList.length == 0 ? 16.0 : 12.0, FontWeight.normal),
                                                              onTap: () {
                                                                if (skillsSelectedList.length == 0)
                                                                  selectSkillDialog();
                                                              }),
                                                          flex: 1,
                                                        )
                                                      ],
                                                    )),
                                                 Row(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .end,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: <Widget>[
                                                     Expanded(
                                                      child: Wrap(
                                                        children:
                                                        _buildChoiceList(),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                     Expanded(
                                                      child: skillsSelectedList
                                                          .length ==
                                                          0
                                                          ?  Container(
                                                        height:
                                                        0.0,
                                                      )
                                                          :  InkWell(
                                                        child:  Container(
                                                            height: 20.0,
                                                            width: 40.0,
                                                            child: Icon(
                                                              Icons.add,
                                                              color: Colors.black,
                                                              size: 20.0,
                                                            )),
                                                        onTap:
                                                            () {
                                                          selectSkillDialog();
                                                        },
                                                      ),
                                                      flex: 0,
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      )),
                                )),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                 Container(
                                  decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.circular(0),
                                    color: Colors.white,
                                    border: Border.all(
                                      color: Color(0xFFFDEDEDE),
                                      style: BorderStyle.solid,
                                      width: 1.0,
                                    ),
                                  ),
                                  child: PaddingWrap.paddingfromLTRB(
                                      14.0,
                                      10.0,
                                      5.0,
                                      10.0,
                                       Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        children: <Widget>[
                                           Expanded(
                                            child: PaddingWrap
                                                .paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                15.0,
                                                0.0,
                                                 Image.asset(
                                                  "assets/newDesignIcon/achievment/achiewvement_level.png",
                                                  width: 30.0,
                                                  height: 30.0,
                                                )),
                                            flex: 0,
                                          ),
                                           Expanded(
                                            child:  Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <Widget>[
                                                /*skillUi,*/
                                                levelSelected == null
                                                    ?  Container(
                                                  height: 10.0,
                                                )
                                                    : PaddingWrap.paddingfromLTRB(
                                                    0.0,
                                                    10.0,
                                                    0.0,
                                                    0.0,
                                                    getTextLabel(
                                                        "Achievement Level",
                                                        12.0,
                                                         ColorValues.GREY_TEXT_COLOR,
                                                        FontWeight
                                                            .normal)),
                                                competencyDropLevel,


                                                PaddingWrap
                                                    .paddingfromLTRB(
                                                    0.0,
                                                    10.0,
                                                    0.0,
                                                    0.0,
                                                     Row(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .start,
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                         Expanded(
                                                          child:
                                                           Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment.start,
                                                            children: <
                                                                Widget>[
                                                              fromDateUi
                                                            ],
                                                          ),
                                                          flex: 6,
                                                        ),
                                                         Expanded(
                                                          child:
                                                           Container(),
                                                          flex: 1,
                                                        ),
                                                         Expanded(
                                                          child:
                                                           Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment.start,
                                                            children: <
                                                                Widget>[
                                                              toDateUi
                                                            ],
                                                          ),
                                                          flex: 6,
                                                        ),
                                                      ],
                                                    )),
                                                PaddingWrap
                                                    .paddingfromLTRB(
                                                    0.0,
                                                    8.0,
                                                    0.0,
                                                    8.0,
                                                     Row(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment
                                                          .end,
                                                      mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .end,
                                                      children: <
                                                          Widget>[
                                                         Expanded(
                                                          child:
                                                           Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment.start,
                                                            children: <
                                                                Widget>[],
                                                          ),
                                                          flex: 6,
                                                        ),
                                                         Expanded(
                                                          child:
                                                           Container(),
                                                          flex: 1,
                                                        ),
                                                         Expanded(
                                                          child:
                                                           Row(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment.start,
                                                            children: <
                                                                Widget>[
                                                               Expanded(
                                                                child:  InkWell(
                                                                  child:  Image.asset(
                                                                    isPresent ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                    width: 25.0,
                                                                    height: 25.0,
                                                                  ),
                                                                  onTap: () {
                                                                    if (isPresent)
                                                                      isPresent = false;
                                                                    else
                                                                      isPresent = true;
                                                                    setState(() {
                                                                      isPresent;
                                                                      toDate = null;
                                                                      strToDate = "";
                                                                      toDateController =  TextEditingController(text: "");
                                                                    });
                                                                  },
                                                                ),
                                                                flex: 0,
                                                              ),
                                                               Expanded(
                                                                child: Container(
                                                                  padding:  EdgeInsets.fromLTRB(5.0, 3.0, 0.0, 0.0),
                                                                  child:  Container(child: TextViewWrap.textView("Ongoing   ", TextAlign.start,  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                ),
                                                                flex: 0,
                                                              )
                                                            ],
                                                          ),
                                                          flex: 6,
                                                        )
                                                      ],
                                                    )),
                                              ],
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      )),
                                )),

                            listCompetency[position].level1 == "Arts"
                                ?  Container(height: 0.0)
                                : Padding(
                              padding:
                              const EdgeInsets.fromLTRB(
                                  0.0, 10, 0, 0),
                              child:  Container(
                                decoration: BoxDecoration(
                                  borderRadius:
                                  BorderRadius.circular(0),
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Color(0xFFFDEDEDE),
                                    style: BorderStyle.solid,
                                    width: 1.0,
                                  ),
                                ),
                                child:
                                PaddingWrap.paddingfromLTRB(
                                    14.0,
                                    0.0,
                                    5.0,
                                    10.0,
                                     Row(
                                      crossAxisAlignment:
                                      CrossAxisAlignment
                                          .start,
                                      mainAxisAlignment:
                                      MainAxisAlignment
                                          .start,
                                      children: <Widget>[
                                         Expanded(
                                          child: PaddingWrap
                                              .paddingfromLTRB(
                                              0.0,
                                              17.0,
                                              15.0,
                                              0.0,
                                               Image
                                                  .asset(
                                                "assets/portfolio/trainer.png",
                                                width:
                                                30.0,
                                                height:
                                                30.0,
                                              )),
                                          flex: 0,
                                        ),
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .start,
                                            children: <
                                                Widget>[
                                              Padding(
                                                padding:
                                                const EdgeInsets.fromLTRB(
                                                    0.0,
                                                    13,
                                                    0,
                                                    3),
                                                child:
                                                 Text(
                                                  "Athletic Information",
                                                  style:  TextStyle(
                                                      color:  Color(
                                                          0XFF151515),
                                                      fontSize:
                                                      16.0,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                              ),
                                               Text(
                                                "Share your athletic information with the coaches here.",
                                                style:  TextStyle(
                                                    color:  Color(
                                                        0XFF9a9c9c),
                                                    fontSize:
                                                    12.0,
                                                    fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR),
                                              ),
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  0.0,
                                                  10.0,
                                                  0.0,
                                                  0.0,
                                                   Row(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    children: <Widget>[
                                                       Expanded(
                                                        child:  Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          children: <Widget>[
                                                            heightUi
                                                          ],
                                                        ),
                                                        flex: 1,
                                                      ),
                                                       Expanded(
                                                        child:  Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          children: <Widget>[
                                                            weightUi
                                                          ],
                                                        ),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  )),
                                              ageSelectionUi,
                                              stateWidget()
                                            ],
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    )),
                              ),
                            ),

                            listCompetency[position].level1 == "Arts"
                                ?  Container(height: 0.0)
                                : Padding(
                                padding:
                                const EdgeInsets.fromLTRB(
                                    0.0, 10, 0, 0),
                                child:  Container(
                                  decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.circular(0),
                                    color: Colors.white,
                                    border: Border.all(
                                      color: Color(0xFFFDEDEDE),
                                      style: BorderStyle.solid,
                                      width: 1.0,
                                    ),
                                  ),
                                  child:
                                  PaddingWrap.paddingfromLTRB(
                                      14.0,
                                      0.0,
                                      5.0,
                                      10.0,
                                       Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .start,
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .start,
                                        children: <Widget>[
                                           Expanded(
                                            child: PaddingWrap
                                                .paddingfromLTRB(
                                                0.0,
                                                17.0,
                                                15.0,
                                                0.0,
                                                 Image
                                                    .asset(
                                                  "assets/portfolio/team.png",
                                                  width:
                                                  30.0,
                                                  height:
                                                  30.0,
                                                )),
                                            flex: 0,
                                          ),
                                           Expanded(
                                            child:  Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .start,
                                              children: <
                                                  Widget>[
                                                Padding(
                                                  padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0,
                                                      10,
                                                      0,
                                                      3),
                                                  child:
                                                   Text(
                                                    "Select Team",
                                                    style:  TextStyle(
                                                        color:  Color(
                                                            0XFF151515),
                                                        fontSize:
                                                        16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ),
                                                Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(
                                                        0.0,
                                                        0,
                                                        0,
                                                        15),
                                                    child:
                                                     Text(
                                                      "Add details about all the team you have played with.",
                                                      style:  TextStyle(
                                                          color:  Color(
                                                              0XFF9a9c9c),
                                                          fontSize:
                                                          12.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                    )),
                                                 Row(
                                                  children: <
                                                      Widget>[
                                                    isClubTeam
                                                        ?  Expanded(
                                                        child: InkWell(
                                                            onTap: () {
                                                              setState(() {
                                                                isClubTeam = false;
                                                                clubTeamList.clear();
                                                              });
                                                            },
                                                            child:  Padding(
                                                                padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                child:  Image.asset(
                                                                  "assets/newDesignIcon/navigation/check.png",
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ))),
                                                        flex: 0)
                                                        :  Expanded(
                                                        child: InkWell(
                                                          child:  Padding(
                                                              padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                              child:  Image.asset(
                                                                "assets/newDesignIcon/navigation/uncheck.png",
                                                                height: 20.0,
                                                                width: 20.0,
                                                              )),
                                                          onTap: () {
                                                            setState(() {
                                                              isClubTeam = true;
                                                              clubTeamList.add(ClubTeamModel(
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                              ));
                                                            });
                                                          },
                                                        ),
                                                        flex: 0),
                                                     Expanded(
                                                        child:
                                                         Text(
                                                          "Club Team",
                                                          maxLines:
                                                          1,
                                                          style:  TextStyle(
                                                              fontSize:
                                                              16.0,
                                                              color:
                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                        )),
                                                  ],
                                                ),
                                                 Container(
                                                  height: 7.0,
                                                ),
                                                clubTeamWidget(),
                                                 Row(
                                                  children: <
                                                      Widget>[
                                                    isHighSchoolTeam
                                                        ?  Expanded(
                                                        child: InkWell(
                                                            onTap: () {
                                                              setState(() {
                                                                isHighSchoolTeam = false;
                                                                highSchoolTeamList.clear();
                                                              });
                                                            },
                                                            child:  Padding(
                                                                padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                child:  Image.asset(
                                                                  "assets/newDesignIcon/navigation/check.png",
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ))),
                                                        flex: 0)
                                                        :  Expanded(
                                                        child: InkWell(
                                                          child:  Padding(
                                                              padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                              child:  Image.asset(
                                                                "assets/newDesignIcon/navigation/uncheck.png",
                                                                height: 20.0,
                                                                width: 20.0,
                                                              )),
                                                          onTap: () {
                                                            setState(() {
                                                              isHighSchoolTeam = true;
                                                              highSchoolTeamList.add(ClubTeamModel(
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                              ));
                                                            });
                                                          },
                                                        ),
                                                        flex: 0),
                                                     Expanded(
                                                        child:
                                                         Text(
                                                          "High School Team",
                                                          maxLines:
                                                          1,
                                                          style:  TextStyle(
                                                              fontSize:
                                                              16.0,
                                                              color:
                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                        )),
                                                  ],
                                                ),
                                                 Container(
                                                  height: 7.0,
                                                ),
                                                highSchoolTeamWidget(),
                                                 Row(
                                                  children: <
                                                      Widget>[
                                                    isCollegeTeam
                                                        ?  Expanded(
                                                        child: InkWell(
                                                            onTap: () {
                                                              setState(() {
                                                                isCollegeTeam = false;
                                                                collegeTeamList.clear();
                                                              });
                                                            },
                                                            child:  Padding(
                                                                padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                child:  Image.asset(
                                                                  "assets/newDesignIcon/navigation/check.png",
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ))),
                                                        flex: 0)
                                                        :  Expanded(
                                                        child: InkWell(
                                                          child:  Padding(
                                                              padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                              child:  Image.asset(
                                                                "assets/newDesignIcon/navigation/uncheck.png",
                                                                height: 20.0,
                                                                width: 20.0,
                                                              )),
                                                          onTap: () {
                                                            setState(() {
                                                              isCollegeTeam = true;

                                                              collegeTeamList.add(ClubTeamModel(
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                              ));
                                                            });
                                                          },
                                                        ),
                                                        flex: 0),
                                                     Expanded(
                                                        child:
                                                         Text(
                                                          "College Team",
                                                          maxLines:
                                                          1,
                                                          style:  TextStyle(
                                                              fontSize:
                                                              16.0,
                                                              color:
                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                        )),
                                                  ],
                                                ),
                                                 Container(
                                                  height: 7.0,
                                                ),
                                                collegeTeamWidget(),
                                                 Row(
                                                  children: <
                                                      Widget>[
                                                    isOtherTeam
                                                        ?  Expanded(
                                                        child: InkWell(
                                                            onTap: () {
                                                              setState(() {
                                                                isOtherTeam = false;
                                                                otherTeamList.clear();
                                                              });
                                                            },
                                                            child:  Padding(
                                                                padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                child:  Image.asset(
                                                                  "assets/newDesignIcon/navigation/check.png",
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ))),
                                                        flex: 0)
                                                        :  Expanded(
                                                        child: InkWell(
                                                          child:  Padding(
                                                              padding:  EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                              child:  Image.asset(
                                                                "assets/newDesignIcon/navigation/uncheck.png",
                                                                height: 20.0,
                                                                width: 20.0,
                                                              )),
                                                          onTap: () {
                                                            setState(() {
                                                              isOtherTeam = true;

                                                              otherTeamList.add(ClubTeamModel(
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                                 TextEditingController(text: ""),
                                                              ));
                                                            });
                                                          },
                                                        ),
                                                        flex: 0),
                                                     Expanded(
                                                        child:
                                                         Text(
                                                          "Other Team(s)",
                                                          maxLines:
                                                          1,
                                                          style:  TextStyle(
                                                              fontSize:
                                                              16.0,
                                                              color:
                                                               ColorValues.HEADING_COLOR_EDUCATION,
                                                              fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                        )),
                                                  ],
                                                ),
                                                 Container(
                                                  height: 7.0,
                                                ),
                                                otherTeamWidget()
                                              ],
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      )),
                                )),

                            UIHelper.verticalGapBetweenBox,
                            mediaWidget(),
                            UIHelper.verticalGapBetweenBox,
                            externalLinkWidget(),
                            UIHelper.verticalGapBetweenBox,
                            personalReflectionWidget(),
                            //UIHelper.verticalGapBetweenBox,
                          ],
                        ))),
                 Container(
                    color:  ColorValues.SCREEN_BG_COLOR,
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        20.0,
                        0.0,
                        0.0,
                         Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: <Widget>[
                              isPrompt
                                  ? PaddingWrap.paddingfromLTRB(
                                  16.0,
                                  0.0,
                                  16.0,
                                  10.0,
                                   Row(
                                    children: <Widget>[
                                      PaddingWrap.paddingAll(
                                          0.0,
                                           InkWell(
                                            child:
                                             Image.asset(
                                              "assets/newDesignIcon/login/check.png",
                                              width: 25.0,
                                              height: 25.0,
                                            ),
                                            onTap: () {


                                              if (prefs.getString(
                                                  UserPreference
                                                      .ISACTIVE) ==
                                                  "true") {
                                                if (isPrompt)
                                                  isPrompt =
                                                  false;
                                                else
                                                  isPrompt = true;
                                                setState(() {
                                                  isPrompt;
                                                });
                                              } else {
                                                ToastWrap.showToast(
                                                    MessageConstant
                                                        .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                                    context);
                                              }
                                            },
                                          )),
                                       Text(
                                        "  Ask for recommendation",
                                        style:  TextStyle(
                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                            fontSize: 16.0,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR),
                                      ),
                                    ],
                                  ))
                                  : PaddingWrap.paddingfromLTRB(
                                  16.0,
                                  0.0,
                                  16.0,
                                  10.0,
                                   Row(
                                    children: <Widget>[
                                      PaddingWrap.paddingAll(
                                          0.0,
                                          PaddingWrap.paddingAll(
                                              0.0,
                                               InkWell(
                                                child:  Image
                                                    .asset(
                                                  isPrompt
                                                      ? "assets/newDesignIcon/login/check.png"
                                                      : "assets/newDesignIcon/login/uncheck.png",
                                                  width: 25.0,
                                                  height: 25.0,
                                                ),
                                                onTap: () {
                                                  if (prefs.getString(
                                                      UserPreference
                                                          .ISACTIVE) ==
                                                      "true") {
                                                    if (isPrompt)
                                                      isPrompt =
                                                      false;
                                                    else
                                                      isPrompt =
                                                      true;
                                                    setState(() {
                                                      isPrompt;
                                                    });
                                                  } else {
                                                    ToastWrap.showToast(
                                                        MessageConstant
                                                            .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                                        context);
                                                  }
                                                },
                                              ))),
                                       Text(
                                        "  Ask for recommendation",
                                        style:  TextStyle(
                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                            fontSize: 16.0,
                                            fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR),
                                      ),
                                    ],
                                  )),
                              isPrompt
                                  ?  Card(
                                  elevation: 0.0,
                                  child:  Container(
                                      decoration:  BoxDecoration(
                                          border:  Border(
                                              bottom: BorderSide(
                                                  color:  ColorValues.DARK_GREY,
                                                  width: 1.0),
                                              top: BorderSide(
                                                  color:  ColorValues.DARK_GREY,
                                                  width: 1.0))),
                                      child: PaddingWrap
                                          .paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          20.0,
                                           Column(
                                            children: <
                                                Widget>[
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  16.0,
                                                  0.0,
                                                  16.0,
                                                  0.0,
                                                  recommendationTitle),
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  16.0,
                                                  0.0,
                                                  16.0,
                                                  0.0,
                                                  recommendationRequest),
                                              PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                   Container(
                                                      padding:  EdgeInsets.all(5.0),
                                                      color:  Color(0XFFE9E9E9),
                                                      width: double.infinity,
                                                      child: PaddingWrap.paddingfromLTRB(
                                                          10.0,
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                           Text(
                                                            "RECOMMENDER DETAILS",
                                                            style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontSize: 12.0, fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                          )))),
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  16.0,
                                                  0.0,
                                                  16.0,
                                                  0.0,
                                                  recommenderTitle),
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  16.0,
                                                  0.0,
                                                  16.0,
                                                  0.0,
                                                  coachFirstName),
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  16.0,
                                                  0.0,
                                                  16.0,
                                                  0.0,
                                                  coachLastName),
                                              PaddingWrap
                                                  .paddingfromLTRB(
                                                  16.0,
                                                  0.0,
                                                  16.0,
                                                  0.0,
                                                  coachEmail),
                                            ],
                                          ))))
                                  :  Container(
                                height: 0.0,
                              )
                            ]))),
              ],
            ),
          )
              :  Container(
            height: 0.0,
          )
        ],
      );
    }

    void onNextClick() async {
      FocusScope.of(context).unfocus();
      // make Api Call
      final form = _formKey.currentState;

        if (listCompetency[level1Position]
            .level2Competencylist[level2Position]
            .name !=
            "Other" &&
            strCompetencyValue == "Other" && thirdLevelController.text
            .trim()
            .length > 0) {
          setState(() {
            isThirLevelField = true;
          });
        } else {
          setState(() {
            isThirLevelField = false;
          });
        }


     /* if (isPortFolioSelected) {
        setState(() {
          if (ageController.text == "") {
            isValidAge = false;
          } else {
            isValidAge = true;
          }
        });
      }*/

      form.save();
      if (form.validate()) {
        if (listCompetency[level1Position]
            .level2Competencylist[level2Position]
            .name !=
            "Other" &&
            strCompetencyValue == "Other" && thirdLevelController.text
            .trim()
            .length == 0) {
          return;
        }
        if (isPortFolioSelected) {
          int count = 0;
          mediaListData.map((v) {
            if (v.fileDataModelList.length == 1) {
              v.isSelectMedia = false;
            }
            if (!v.isSelectMedia) {
              count++;
            }
          }).toList();

          if (appliedFilter == "") {
            setState(() {
              addSkillsError = true;
            });

          }else {
            setState(() {
              addSkillsError = false;
            });

          }
          if (strLevelValue == "") {
            setState(() {
              selectAchivmentLevel = true;
            });

          }else {
            selectAchivmentLevel = false;
          }

          if (validationForPortFolio()) {
            if (count == 0) {
              apiCallingPortFolio();
            }
          }
        } else if (validationCheck()) {
          /* if ((strCompetencyValue == "Other" ||
              strCompetencyValue == "General") &&
              (otherCategory.text.trim() ==
                  "Other" ||
                  otherCategory.text.trim() == "General")) {
            editCategoryDialog(false,false,true);
          } else {*/
          apiCalling();
          //}
        }
      } else {
        if (isPortFolioSelected) {
          ToastWrap.showToast(
              MessageConstant.ENTER_VALUE_PORTFOLIO_FIELD_VAL, context);
        } else {
          ToastWrap.showToast(
              MessageConstant.ENTER_VALUE_ACCOMPLISHMENT_FIELD_VAL, context);
        }
      }
    }

    void onBackwordClick() {
      Navigator.pop(context);
    }

    Center getAddButtton() {
      return  Center(
          child:   InkWell(
              child: Container(
              height: 32.0,
              width: 148.0,
              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
              child:  Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                      child: TextViewWrap.textView(
                          "SAVE",
                          TextAlign.center,
                           ColorValues.WHITE,
                          14.0,
                          FontWeight.normal),
                    )

                ],
              )),
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              onNextClick();
            },));
    }

    Container getBottomBar() {
      return  Container(
          child:  Row(
            children: <Widget>[
               InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                    child: Image.asset(
                      'assets/newDesignIcon/parentProfile/backword.png',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  onBackwordClick();
                },
              ),
               Expanded(
                  child: (isSelectedList && isSelectedLevel2) ||
                      isAccSelected ||
                      isPortFolioSelected
                      ? getAddButtton()
                      :  Container(),
                  flex: 1),
              widget.pageName == "all"
                  ?  Container(
                height: 45.0,
                width: 45.0,
              )
                  :  InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 7.0),
                    child: Image.asset(
                      'assets/newDesignIcon/parentProfile/next.png',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  //conformationForSkip();
                  FocusScope.of(context).requestFocus(new FocusNode());

                  onNextClickSkip();
                },
              ),
            ],
          ));
    }

    void conformationForSkip() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      //"Are you sure you want to skip Accomplishment?",
                                                      "Are you sure you want to skip this step?",
                                                      textAlign:
                                                      TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                          Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Cancel",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                    "Skip",
                                                    textAlign: TextAlign.center,
                                                    style:  TextStyle(
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                  )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                //apiCallWizardCompleted(true);
                                                onNextClickSkip();
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  WillPopScope(
        onWillPop: () {},
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            body: FormKeyboardActions(
                nextFocus: false,
                keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                //optional
                keyboardBarColor: Colors.grey[200],
                //optional
                actions: [
                  KeyboardAction(
                    focusNode: workinHoursFocusNode,
                  ),
                  KeyboardAction(
                    focusNode: weightFocusNode,
                  ),
                ],
                child:
                     Column(
                      children: <Widget>[

                        Padding(
                          padding: EdgeInsets.only(
                              top: statusBarHeight + 20,
                              left: 13.0,
                              right: 13.0,
                              bottom: 7),
                          child: Center(
                            child:  Image.asset(
                                "assets/progress_indecator/indicator_step4.png",
                                height: 26.0,
                                width: 300.0,
                                fit: BoxFit.fitWidth),
                          ),
                        ),
                         Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(top: 20, left: 13, right: 13),
                            child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                 Text(
                                  "", //"Step 4 of 7",
                                  style:  TextStyle(
                                      fontSize: 15.0,
                                      fontFamily: Constant.customRegular,
                                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                                ),
                                InkWell(
                                  child:  Text(
                                    "SKIP ",
                                    style:  TextStyle(
                                        fontSize: 14.0,
                                        fontFamily: Constant.customRegular,
                                        color:
                                         ColorValues.GREY_TEXT_COLOR),
                                  ),
                                  onTap: () {
                                    if (isSelectedList && isSelectedLevel2)
                                      conformationForSkip();
                                    else
                                      onNextClickSkip();
                                  },
                                ),
                              ],
                            ),
                          ),
                          flex: 0,
                        ),
                         Expanded(
                          child:  ListView(
                            controller: _scrollController,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 10),
                                child:  Image.asset(
                                    "assets/profile/student/acc_student.png",
                                    height: 50.0,
                                    width: 50.0,
                                    fit: BoxFit.fitHeight),
                              ),
                              PaddingWrap.paddingfromLTRB(
                                  20.0,
                                  0.0,
                                  20.0,
                                  5.0,
                                  TextViewWrap.textViewMultiLine(
                                      "Add Accomplishment",
                                      TextAlign.center,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      18.0,
                                      FontWeight.bold,
                                      6)),
                              PaddingWrap.paddingfromLTRB(
                                  20.0,
                                  0.0,
                                  20.0,
                                  11.0,
                                  TextViewWrap.textViewMultiLine(
                                      "Share some of your child’s experiences, achievements, and accomplishments. Include extracurricular activities, clubs, hobbies, work, internships, awards, projects, performance videos, blogs etc.",

                                      //  "Share some of your child’s experiences, achievements, accomplishments or anything they are proud of. This can also include extracurricular activities, clubs, hobbies, work or volunteering experiences, awards, hand-on projects, performance videos, blogs etc. Things done at school, outside or online.",
                                      TextAlign.center,
                                       ColorValues.HEADING_COLOR_EDUCATION,
                                      14.0,
                                      FontWeight.normal,
                                      6)),
                              listCompetency.length > 0
                                  ?  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:  List.generate(
                                      listCompetency.length, (int position) {
                                    return !isSelectedList
                                        ? getCompetencyItem(position)
                                        : listCompetency[position].isSelected
                                        ? getCompetencyItem(position)
                                        :  Container(
                                      height: 0.0,
                                    );
                                  }))

                              /*new ListView.builder(
                              controller: _controller,
                              itemCount: listCompetency.length,
                              itemBuilder: (BuildContext context, int position) {
                                return !isSelectedList
                                    ? getCompetencyItem(position)
                                    : listCompetency[position].isSelected
                                        ? getCompetencyItem(position)
                                        :  Container(
                                            height: 0.0,
                                          );
                              })*/
                                  :  Container(),
                            ],
                          ),
                          flex: 1,
                        ),
                         Expanded(
                          child: getBottomBar(),
                          flex: 0,
                        )
                      ],
                    ),

                )));

    /*  return  WillPopScope(
        onWillPop: () {},
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            body:  Stack(
              children: <Widget>[
                 Positioned(
                    top: 0.0,
                    left: 0.0,
                    right: 0.0,
                    bottom: 30.0,
                    child:  Column(
                      children: <Widget>[
                        CustomViews.getSepratorLine(),
                         Container(),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0.0, 80, 0, 10),
                          child:  Image.asset(
                              "assets/profile/student/st14.png",
                              height: 10.0,
                              width: 100.0,
                              fit: BoxFit.fitHeight),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0.0, 12, 0, 5),
                          child:  Image.asset(
                              "assets/profile/student/acc_student.png",
                              height: 50.0,
                              width: 50.0,
                              fit: BoxFit.fitHeight),
                        ),
                        PaddingWrap.paddingfromLTRB(
                            20.0,
                            0.0,
                            20.0,
                            11.0,
                            TextViewWrap.textViewMultiLine(
                                "Share what your child have enjoyed doing most, spent the most time doing, their experiences and accomplishment. This can be clubs, extracurriculars, hobbies, hands-on projects, or things they do on their own. These can be for in and out of school. Select a category",
                                TextAlign.center,
                                 ColorValues.HEADING_COLOR_EDUCATION,
                                14.0,
                                FontWeight.normal,
                                5)),
                         Expanded(
                          child: listCompetency.length > 0
                              ?  ListView.builder(
                              controller: _controller,
                              itemCount: listCompetency.length,
                              itemBuilder:
                                  (BuildContext context, int position) {

                                return !isSelectedList
                                    ? getCompetencyItem(position)
                                    : listCompetency[position].isSelected
                                    ? getCompetencyItem(position)
                                    :  Container(
                                  height: 0.0,
                                );
                              })
                              :  Container(),
                          flex: 1,
                        )
                      ],
                    )),
                 Positioned(
                  bottom: 0.0,
                  child: getBottomBar(),
                )
              ],
            )));*/
  }

  void apiCallWizardCompleted(bool skip) {
    /*if(skip){
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           CompletedWizard(widget.studModel.userId)));
    }else {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>
           AllAccomplishmentListWidget(widget.studModel)));
    }*/
    Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         AllAccomplishmentListWidget(widget.studModel)));
  }

  void onNextClickSkip() {
/*    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  AddChildStudentInterestWidget(
            widget.studModel, '', sasToken, 4)));*/

    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  AddChildStudentInterestWidget(
            widget.studModel, widget.pageName, sasToken, 4)));
    // make Api Call

    //Move to Accomplishment Page
  }

  externalLinkWidget() {
    return  Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          14.0,
          10.0,
          5.0,
          10.0,
           Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                     Image.asset(
                      "assets/story_new/link_url.png",
                      width: 30.0,
                      height: 30.0,
                    )),
                flex: 0,
              ),
               Expanded(
                child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        TextViewWrap.textView(
                            "External Links & Mentions",
                            TextAlign.start,
                             ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            "Upload press coverage, video montages/highlight reels, documents.",
                            TextAlign.start,
                             ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    UIHelper.verticalGapBetweenBox,

                    //////////////////////////////////
                    Container(
                      child: ListView.builder(
                        itemCount: linkUrlListData.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                            child: Container(
                              //color: ColorValues.BLUE_COLOR,
                              //padding: EdgeInsets.only(top: 10,),

                              margin:
                              EdgeInsets.only(top: 0, bottom: 0, right: 0),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 5, 0),
                                    child: Container(
                                      color: ColorValues.SELECTION_GRAY,
                                      margin: EdgeInsets.only(top: 0, right: 0),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 5, 13, 5),
                                        child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            Expanded(
                                              child: Column(
                                                children: <Widget>[
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: 0,
                                                      top: 0,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                      linkUrlListData[index]
                                                          .labelController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                      textFormFieldDecorationWithLabel(
                                                          'Title'),
                                                      style:
                                                      textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (val) => linkUrlListData[
                                                      index]
                                                          .labelController
                                                          .text ==
                                                          "" &&
                                                          linkUrlListData[
                                                          index]
                                                              .urlController
                                                              .text ==
                                                              ""
                                                          ? null
                                                          : val.trim().isEmpty
                                                          ? MessageConstant
                                                          .FIELD_REQUIRED
                                                          : null,
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                      linkUrlListData[index]
                                                          .urlController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                      textFormFieldDecorationWithLabel(
                                                          'URL'),
                                                      style:
                                                      textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (value) {
                                                        return linkUrlListData[
                                                        index]
                                                            .labelController
                                                            .text ==
                                                            "" &&
                                                            linkUrlListData[
                                                            index]
                                                                .urlController
                                                                .text ==
                                                                ""
                                                            ? null
                                                            : ValidationChecks
                                                            .validateWebUrlPortFolio(
                                                            value);
                                                      },
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: UIHelper
                                                          .screenPadding,
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                      linkUrlListData[index]
                                                          .descController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                      textFormFieldDecorationWithLabel(
                                                          'Description'),
                                                      style:
                                                      textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      /*validator: (value) {
                                    return ValidationChecks
                                        .validateDescription(value);
                                },*/
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    right: 0.0,
                                    top: 0.0,
                                    child: InkWell(
                                      child: index > 0
                                          ? Container(
                                        padding: EdgeInsets.all(0),
                                        child: Image.asset(
                                          ImagePath.ICON_CLEAR,
                                          height: 24.18,
                                          width: 17,
                                        ),
                                      )
                                          :  Container(
                                        height: 24.18,
                                        width: 17,
                                      ),
                                      onTap: () {
                                        if (linkUrlListData.length > 1) {
                                          print(
                                              'link Index is =======>  $index');
                                          linkUrlListData.removeAt(index);
                                        }
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    ////////////////////////////
                    InkWell(
                      child: Padding(
                        padding:
                        EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
                        child: Text(
                          '+ Add More Link'.toUpperCase(),
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.accentColor, 14, FontType.Regular),
                        ),
                      ),
                      onTap: () {
                        if (linkUrlListData[linkUrlListData.length - 1]
                            .urlController
                            .text !=
                            "" &&
                            linkUrlListData[linkUrlListData.length - 1]
                                .labelController
                                .text !=
                                "") {
                          setState(() {
                            linkUrlListData.add(LinkUrlDataModel(
                               TextEditingController(text: ""),
                               TextEditingController(text: ""),
                               TextEditingController(text: ""),
                            ));
                          });
                        }
                      },
                    ),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  uploadMediaServer(index, filePath, imagePath, type) async {
    strAzureImageUploadPath = await uploadImgOnAzure(
        filePath.toString().replaceAll("File: ", "").replaceAll("'", "").trim(),
        strPrefixPathforPhoto);
    setState(() {
      strAzureImageUploadPath;
    });

    final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(filePath);
    CustomProgressLoader.cancelLoader(context);
    uploadMediaCount++;
    mediaListData[index].fileDataModelList.add(new FileDataModel(
        type: type,
        filePath: strPrefixPathforPhoto + strAzureImageUploadPath,
        thumbnailFile: thumbnailFile,
        imagePath: imagePath));
    setState(() {});
  }

  Future getImage(int index, type, context) async {
    imagePath = null;
    if (type == "video") {
      imagePath = await uploadMedia.pickVideoFromGallery();
    } else {
      imagePath = await UploadMedia(context).pickImageFromGallery();
     // imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
    }
    if (imagePath != null && imagePath != "") {
      String strPath = imagePath
          .toString()
          .replaceAll("File: ", "")
          .replaceAll("'", "")
          .trim();
      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        try {
          CustomProgressLoader.showLoader(context);
          if (type == "video") {
            /*    File file =
                await uploadMedia.compresssData(new File(strPath), true, type);
            imagePath = file;*/

            File file =
            await uploadMedia.compresssData(new File(strPath), true, type);
            strPath = file.path;

            mediaListData[index].type = "video";
            mediaListData[index].isSelectMedia = true;
          } else if (type == "image") {
            File file = await uploadMedia.compressImage(new File(strPath));
            imagePath = file;
            mediaListData[index].type = "image";
            mediaListData[index].isSelectMedia = true;
          }
          /*strPath = imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim();*/
          if (imagePath != null) {
            /*setState(() {
            isMedaiDialog = true;
          });
          addMediaDialog();*/
            setState(() {
              imagePath;
            });

            Timer _timer =  Timer(const Duration(milliseconds: 400), () {
              uploadMediaServer(index, strPath, imagePath, type);
            });
          }
        } catch (e) {
          CustomProgressLoader.cancelLoader(context);
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  void conformationDialog(index, model) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    "Are you sure you want to remove?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Cancel",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.GREY_TEXT_COLOR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                                  "Remove",
                                                  textAlign: TextAlign.center,
                                                  style:  TextStyle(
                                                      color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      fontSize: 16.0,
                                                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                                )),
                                            onTap: () {
                                              uploadMediaCount--;
                                              Navigator.pop(context);
                                              mediaListData[index]
                                                  .fileDataModelList
                                                  .remove(model);
                                              setState(() {
                                                if (mediaListData[index]
                                                    .fileDataModelList
                                                    .length ==
                                                    1) {
                                                  mediaListData[index].type =
                                                  "";
                                                }
                                                mediaListData[index]
                                                    .fileDataModelList;
                                              });
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  getImageAndVideoFile(index, type) {
    return  Container(
      child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 3,
          children:  List.generate(
              mediaListData[index].fileDataModelList.length, (int index1) {
            return mediaListData[index].fileDataModelList[index1].filePath == ""
                ?  Stack(children: <Widget>[
               InkWell(
                child:  Container(
                    height: 54.0,
                    width: 80.0,
                    decoration:  BoxDecoration(
                        border:
                         Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                    child:  Image.asset(
                      "assets/portfolio/add_white.png",
                      height: 25.0,
                      width: 25.0,
                    )),
                onTap: () async{

                  if (mediaListData[index].type == "video" &&
                      mediaListData[index].fileDataModelList.length ==
                          2) {
                    ToastWrap.showToast(
                        MessageConstant.MAXIMUM_1_VIDEO_UPLOADED_VAL,
                        context);
                  } else {
                    if (uploadMediaCount <
                        TextLength.PORTFOLIO_FILE_MAX_LENGTH) {
                      var status = await Permission.photos.status;
                      if (status.isGranted) {
                        getImage(index, type, context);
                      }  else {
                        checkPermissionPhoto(context);
                      }

                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAXIMUM_100_IMAGE_UPLOADED_VAL,
                          context);
                    }
                  }
                },
              )
            ])
                :  Container(
                child:  Stack(
                  children: <Widget>[
                    type == "image"
                        ? FadeInImage.assetNetwork(
                      fit: BoxFit.cover,
                      placeholder: 'assets/aerial/default_img.png',
                      image: Constant.IMAGE_PATH +
                          mediaListData[index]
                              .fileDataModelList[index1]
                              .filePath,
                      height: 54.0,
                      width: 80.0,
                    )
                        : Container(
                      height: 54.0,
                      width: 80.0,
                      decoration: rectangleDecoration(),
                      margin: EdgeInsets.only(left: 0, right: 0),
                      child: Image.file(
                        mediaListData[index]
                            .fileDataModelList[index1]
                            .thumbnailFile,
                        fit: BoxFit.contain,
                      ),
                    ),
                     Container(
                      height: 54.0,
                      width: 80.0,
                      color:  Color(0XFFC0C0C0).withOpacity(.4),
                    ),
                     Container(
                        height: 54.0,
                        width: 80.0,
                        child:  Center(
                            child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                 InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                         Image.asset(
                                          "assets/newDesignIcon/achievment/remove.png",
                                          width: 35.0,
                                          height: 35.0,
                                        )),
                                    onTap: () {
                                      conformationDialog(
                                          index,
                                          mediaListData[index]
                                              .fileDataModelList[index1]);
                                    })
                              ],
                            ))),
                  ],
                ));
          })),
    );
  }

  mediaWidget() {
    return  Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          14.0,
          10.0,
          5.0,
          10.0,
           Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                     Image.asset(
                      "assets/portfolio/media.png",
                      width: 30.0,
                      height: 30.0,
                    )),
                flex: 0,
              ),
               Expanded(
                child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        TextViewWrap.textView(
                            "Upload Media",
                            TextAlign.start,
                             ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            MessageConstant.MEDIA_TEXT_PORTFOLIO,
                            TextAlign.start,
                             ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    UIHelper.verticalGapBetweenBox,

                    //////////////////////////////////
                    ListView.builder(
                      itemCount: mediaListData.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                          child: Container(
                            //color: ColorValues.BLUE_COLOR,
                            //padding: EdgeInsets.only(top: 10,),

                            margin:
                            EdgeInsets.only(top: 0, bottom: 0, right: 0),
                            child: Stack(
                              children: <Widget>[
                                Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 5, 0),
                                    child: Container(
                                        color:
                                        ColorValues.SELECTION_GRAY,
                                        margin:
                                        EdgeInsets.only(top: 0, right: 0),
                                        child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                13.0, 5, 13, 5),
                                            child: Column(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: <Widget>[
                                                mediaListData[index].type ==
                                                    "video" ||
                                                    mediaListData[index]
                                                        .type ==
                                                        "link"
                                                    ?  Container(
                                                  height: 0.0,
                                                )
                                                    :  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: [
                                                    PaddingWrap
                                                        .paddingfromLTRB(
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        10.0,
                                                         Text(
                                                          "Photos",
                                                          style:  TextStyle(
                                                              color:   ColorValues.GREY_TEXT_COLOR,
                                                              fontSize:
                                                              14.0,
                                                              fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                        )),
                                                    getImageAndVideoFile(
                                                        index, "image"),
                                                  ],
                                                ),
                                                mediaListData[index].type ==
                                                    "image" ||
                                                    mediaListData[index]
                                                        .type ==
                                                        "link"
                                                    ?  Container(
                                                  height: 0.0,
                                                )
                                                    :  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: [
                                                    PaddingWrap
                                                        .paddingfromLTRB(
                                                        0.0,
                                                        12.0,
                                                        0.0,
                                                        10.0,
                                                         Text(
                                                          "Video",
                                                          style:  TextStyle(
                                                              color:   ColorValues.GREY_TEXT_COLOR,
                                                              fontSize:
                                                              14.0,
                                                              fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                        )),
                                                    mediaListData[index]
                                                        .type ==
                                                        "video"
                                                        ?  Stack(
                                                      children: <
                                                          Widget>[
                                                        mediaListData[index].fileDataModelList.length ==
                                                            1
                                                            ? Image
                                                            .asset(
                                                          'assets/aerial/default_img.png',
                                                          height:
                                                          54.0,
                                                          width:
                                                          80.0,
                                                        )
                                                            : Container(
                                                          height:
                                                          54.0,
                                                          width:
                                                          80.0,
                                                          decoration:
                                                          rectangleDecoration(),
                                                          margin:
                                                          EdgeInsets.only(left: 0, right: 0),
                                                          child:
                                                          Image.file(
                                                            mediaListData[index].fileDataModelList[1].thumbnailFile,
                                                            fit: BoxFit.contain,
                                                          ),
                                                        ),
                                                         Container(
                                                          height:
                                                          54.0,
                                                          width:
                                                          80.0,
                                                          color:  Color(
                                                              0XFFC0C0C0)
                                                              .withOpacity(
                                                              .4),
                                                        ),
                                                         Container(
                                                            height:
                                                            54.0,
                                                            width:
                                                            80.0,
                                                            child:  Center(
                                                                child:  Row(
                                                                  crossAxisAlignment:
                                                                  CrossAxisAlignment.center,
                                                                  mainAxisAlignment:
                                                                  MainAxisAlignment.center,
                                                                  children: <
                                                                      Widget>[
                                                                     InkWell(
                                                                        child: PaddingWrap.paddingfromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                             Image.asset(
                                                                              "assets/newDesignIcon/achievment/remove.png",
                                                                              width: 35.0,
                                                                              height: 35.0,
                                                                            )),
                                                                        onTap: () {
                                                                          conformationDialog(index, mediaListData[index].fileDataModelList[1]);
                                                                        })
                                                                  ],
                                                                ))),
                                                      ],
                                                    )
                                                        : getImageAndVideoFile(
                                                        index,
                                                        "video"),
                                                  ],
                                                ),
                                                mediaListData[index].type ==
                                                    "video" ||
                                                    mediaListData[index]
                                                        .type ==
                                                        "image" ||
                                                    mediaListData[index]
                                                        .type ==
                                                        "link"
                                                    ?  Container(
                                                  height: 0.0,
                                                )
                                                    :  Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: [
                                                      PaddingWrap
                                                          .paddingfromLTRB(
                                                          0.0,
                                                          12.0,
                                                          0.0,
                                                          10.0,
                                                           Text(
                                                            "Paste Link URL",
                                                            style:  TextStyle(
                                                                color:  ColorValues.GREY_TEXT_COLOR,
                                                                fontSize:
                                                                14.0,
                                                                fontFamily:
                                                                Constant.TYPE_CUSTOMREGULAR),
                                                          )),
                                                      Padding(
                                                        padding:
                                                        const EdgeInsets
                                                            .fromLTRB(
                                                            0.0,
                                                            0,
                                                            0,
                                                            13),
                                                        child:
                                                         Container(
                                                          decoration:  BoxDecoration(
                                                              color: Colors
                                                                  .white,
                                                              border:  Border
                                                                  .all(
                                                                  color:  ColorValues.BORDER_COLOR,
                                                                  width:
                                                                  0.5)),
                                                          child:  Row(
                                                            children: [
                                                               Expanded(
                                                                child: PaddingWrap.paddingfromLTRB(
                                                                    5.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0,
                                                                     TextFormField(
                                                                      maxLines:
                                                                      2,
                                                                      minLines:
                                                                      1,
                                                                      maxLength:
                                                                      200,
                                                                      keyboardType:
                                                                      TextInputType.text,
                                                                      style:
                                                                      TextStyle(fontFamily: Constant.customRegular),
                                                                      decoration:
                                                                       InputDecoration(
                                                                        hintText: "   Link URL",
                                                                        hintStyle: TextStyle(color: ColorValues.DARK_GREY, fontSize: 14.0, fontFamily: Constant.customRegular),
                                                                        errorStyle: TextStyle(fontFamily: Constant.customRegular),
                                                                        counterText: "",
                                                                        border: InputBorder.none,
                                                                      ),
                                                                      controller:
                                                                      mediaListData[0].fileDataModelList[0].linkController,
                                                                    )),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:
                                                                Padding(
                                                                  padding: const EdgeInsets.fromLTRB(
                                                                      0.0,
                                                                      0,
                                                                      0,
                                                                      0),
                                                                  child:
                                                                   Container(
                                                                    width:
                                                                    1.0,
                                                                    height:
                                                                    35.0,
                                                                    color:
                                                                     ColorValues.BORDER_COLOR,
                                                                  ),
                                                                ),
                                                                flex: 0,
                                                              ),
                                                               Expanded(
                                                                child: PaddingWrap.paddingfromLTRB(
                                                                    12.0,
                                                                    0.0,
                                                                    12.0,
                                                                    0.0,
                                                                     InkWell(
                                                                      onTap:
                                                                          () {
                                                                        String data = ValidationChecks.validateWebUrlPortFolio(mediaListData[0].fileDataModelList[0].linkController.text);
                                                                        if (data == null) {
                                                                          mediaListData[index].type = "link";
                                                                          mediaListData[index].isSelectMedia = true;
                                                                          mediaListData[index].fileDataModelList.add(new FileDataModel(type: "link", filePath: mediaListData[0].fileDataModelList[0].linkController.text, thumbnailFile: null, imagePath: null));
                                                                          mediaListData[0].fileDataModelList[0].linkController.text = "";
                                                                          setState(() {});
                                                                        } else {
                                                                          ToastWrap.showToast(data, context);
                                                                        }
                                                                      },
                                                                      child: TextViewWrap.textViewMultiLine(
                                                                          "ADD",
                                                                          TextAlign.start,
                                                                           ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                          14.0,
                                                                          FontWeight.normal,
                                                                          1),
                                                                    )),
                                                                flex: 0,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ]),
                                                mediaListData[index].type ==
                                                    "link"
                                                    ? Padding(
                                                    padding: const EdgeInsets
                                                        .fromLTRB(
                                                        0.0, 15, 13, 13),
                                                    child:  Container(
                                                        decoration:  BoxDecoration(
                                                            color: Colors
                                                                .white,
                                                            border:  Border
                                                                .all(
                                                                color:  ColorValues.BORDER_COLOR,
                                                                width:
                                                                0.5)),
                                                        child: Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .fromLTRB(
                                                              20.0,
                                                              8,
                                                              20,
                                                              8),
                                                          child:  Row(
                                                            children: [
                                                               Expanded(
                                                                child:
                                                                Padding(
                                                                  padding:
                                                                  const EdgeInsets.fromLTRB(
                                                                      0,
                                                                      0,
                                                                      10,
                                                                      0),
                                                                  child:
                                                                   Text(
                                                                    mediaListData[index]
                                                                        .fileDataModelList[1]
                                                                        .filePath,
                                                                    maxLines:
                                                                    1,
                                                                    overflow:
                                                                    TextOverflow.ellipsis,
                                                                    style:  TextStyle(
                                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                                        fontSize:
                                                                        14.0,
                                                                        fontFamily:
                                                                        Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                                ),
                                                                flex: mediaListData[index].fileDataModelList[1].filePath.length <
                                                                    25
                                                                    ? 0
                                                                    : 1,
                                                              ),
                                                               Expanded(
                                                                child:
                                                                InkWell(
                                                                  child:
                                                                  Container(
                                                                    padding:
                                                                    EdgeInsets.all(0),
                                                                    child: Image
                                                                        .asset(
                                                                      ImagePath
                                                                          .ICON_CLEAR,
                                                                      height:
                                                                      24.18,
                                                                      width:
                                                                      17,
                                                                    ),
                                                                  ),
                                                                  onTap:
                                                                      () {
                                                                    mediaListData[index]
                                                                        .fileDataModelList
                                                                        .removeLast();
                                                                    mediaListData[index].type =
                                                                    "";
                                                                    mediaListData[index].isSelectMedia =
                                                                    true;

                                                                    setState(
                                                                            () {});
                                                                  },
                                                                ),
                                                                flex: 0,
                                                              ),
                                                            ],
                                                          ),
                                                        )))
                                                    :  Container(height: 0),
                                                mediaListData[index]
                                                    .isSelectMedia
                                                    ?  Container(
                                                  height: 0.0,
                                                )
                                                    : Text(
                                                  "At least one media is required.",
                                                  textAlign:
                                                  TextAlign.start,
                                                  style:  TextStyle(
                                                      color: Palette
                                                          .redColor,
                                                      fontSize: 14,
                                                      fontFamily:
                                                      Constant.TYPE_CUSTOMREGULAR),
                                                ),
                                                mediaListData[index]
                                                    .isSelectMedia &&
                                                    mediaListData[index]
                                                        .type !=
                                                        null &&
                                                    mediaListData[index]
                                                        .type !=
                                                        ""
                                                    ?  Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      EdgeInsets.only(
                                                        top: 5,
                                                      ),
                                                      child:
                                                      TextFormField(
                                                        controller:
                                                        mediaListData[
                                                        index]
                                                            .labelController,
                                                        //controller: timeFrom,
                                                        //controller: timeFromController,
                                                        //enabled: false,
                                                        decoration:
                                                        textFormFieldDecorationWithLabel(
                                                            'Title',
                                                            hintText:
                                                            ""),
                                                        style:
                                                        textFormFieldValueStyle(),
                                                        onFieldSubmitted:
                                                            (term) {},
                                                        validator: (val) => val
                                                            .trim()
                                                            .isEmpty
                                                            ? MessageConstant
                                                            .FIELD_REQUIRED
                                                            : null,
                                                        maxLength: 200,
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                      EdgeInsets.only(
                                                        top: 5,
                                                      ),
                                                      child:
                                                      TextFormField(
                                                        controller:
                                                        mediaListData[
                                                        index]
                                                            .descController,
                                                        decoration: textFormFieldDecorationWithLabel(
                                                            'Description',
                                                            hintText: listCompetency[level1Position]
                                                                .level1 ==
                                                                "Arts"
                                                                ? "In detail describe your art or performance highlighting key features"
                                                                : "In detail describe your sports performance highlighting key features"),
                                                        style:
                                                        textFormFieldValueStyle(),
                                                        onFieldSubmitted:
                                                            (term) {},
                                                        validator: (val) => val
                                                            .trim()
                                                            .isEmpty
                                                            ? MessageConstant
                                                            .FIELD_REQUIRED
                                                            : null,
                                                        maxLength: 1000,
                                                      ),
                                                    ),
                                                    listCompetency[level1Position]
                                                        .level1 ==
                                                        "Arts"
                                                        ?  Container(
                                                      height: 0.0,
                                                    )
                                                        : Padding(
                                                      padding:
                                                      EdgeInsets
                                                          .only(
                                                        bottom: UIHelper
                                                            .screenPadding,
                                                        top: 5,
                                                      ),
                                                      child:
                                                      TextFormField(
                                                        controller:
                                                        mediaListData[index]
                                                            .statisticsController,
                                                        maxLength:
                                                        200,
                                                        decoration:
                                                        textFormFieldDecorationWithLabel(
                                                            'Statistics'),
                                                        style:
                                                        textFormFieldValueStyle(),
                                                        onFieldSubmitted:
                                                            (term) {},
                                                      ),
                                                    ),
                                                  ],
                                                )
                                                    :  Container(
                                                  height: 0.0,
                                                )
                                              ],
                                            )))),
                                Positioned(
                                  right: 0.0,
                                  top: 0.0,
                                  child: InkWell(
                                    child: index > 0
                                        ? Container(
                                      padding: EdgeInsets.all(0),
                                      child: Image.asset(
                                        ImagePath.ICON_CLEAR,
                                        height: 24.18,
                                        width: 17,
                                      ),
                                    )
                                        :  Container(
                                      height: 24.18,
                                      width: 17,
                                    ),
                                    onTap: () {
                                      mediaListData.removeAt(index);

                                      setState(() {});
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    ////////////////////////////
                    InkWell(
                      child: Padding(
                        padding:
                        EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
                        child: Text(
                          '+ ADD MORE MEDIA'.toUpperCase(),
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.accentColor, 14, FontType.Regular),
                        ),
                      ),
                      onTap: () {
                        final form = _formKey.currentState;

                        form.save();
                        form.validate();
                        int count = 0;
                        mediaListData.map((v) {
                          if (v.fileDataModelList.length == 1) {
                            v.isSelectMedia = false;
                          }
                          if (!v.isSelectMedia) {
                            count++;
                          }
                        }).toList();

                        if (count == 0 &&
                            mediaListData[mediaListData.length - 1]
                                .labelController
                                .text !=
                                "" &&
                            mediaListData[mediaListData.length - 1]
                                .descController
                                .text !=
                                "") {
                          setState(() {
                            MediaDataModelNew _mMediaDataModelNew =
                            MediaDataModelNew(
                                 TextEditingController(text: ""),
                                 TextEditingController(text: ""),
                                 TextEditingController(text: ""),
                                isSelectMedia: true,
                                fileDataModelList:
                                 List<FileDataModel>());
                            _mMediaDataModelNew.fileDataModelList.add(
                                 FileDataModel(
                                    filePath: "",
                                    type: "",
                                    thumbnailFile: null,
                                    imagePath: null,
                                    linkController:
                                     TextEditingController()));

                            mediaListData.add(_mMediaDataModelNew);
                          });
                        } else {
                          setState(() {});
                        }
                      },
                    ),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  stateWidget() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        PaddingWrap.paddingfromLTRB(
            0.0,
            10.0,
            0.0,
            0.0,
            TextViewWrap.textViewMultiLine(
                "Add all your playing position(s) with statistics",
                TextAlign.start,
                 ColorValues.GREY_TEXT_COLOR,
                14.0,
                FontWeight.normal,
                4)),

        //////////////////////////////////
        ListView.builder(
          itemCount: stateListData.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
              child: Container(
                //color: ColorValues.BLUE_COLOR,
                //padding: EdgeInsets.only(top: 10,),

                margin: EdgeInsets.only(top: 0, bottom: 0, right: 0),
                child: Stack(
                  children: <Widget>[
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 10, 5, 0),
                        child: Container(
                            color: ColorValues.SELECTION_GRAY,
                            margin: EdgeInsets.only(top: 0, right: 0),
                            child: Padding(
                                padding:
                                const EdgeInsets.fromLTRB(13.0, 5, 13, 5),
                                child: Column(
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(
                                        bottom: UIHelper.screenPadding,
                                        top: 5,
                                      ),
                                      child: TextFormField(
                                        controller: stateListData[index]
                                            .positionController,
                                        //controller: timeFrom,
                                        //controller: timeFromController,
                                        //enabled: false,
                                        decoration:
                                        textFormFieldDecorationWithLabelStats(
                                            'Playing Position',
                                            hintText: "Pitcher"),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (val) => stateListData[index]
                                            .positionController
                                            .text ==
                                            "" &&
                                            stateListData[index]
                                                .lableController
                                                .text ==
                                                "" &&
                                            stateListData[index]
                                                .valueController
                                                .text ==
                                                ""
                                            ? null
                                            : val.trim().isEmpty
                                            ? MessageConstant.FIELD_REQUIRED
                                            : null,
                                      ),
                                    ),
                                     Row(
                                      children: [
                                         Expanded(
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  bottom:
                                                  UIHelper.screenPadding,
                                                  top: 5,
                                                  right: 2),
                                              child: TextFormField(
                                                controller: stateListData[index]
                                                    .lableController,
                                                //controller: timeFrom,
                                                //controller: timeFromController,
                                                //enabled: false,
                                                decoration:
                                                textFormFieldDecorationWithLabelStats(
                                                    ' Statistics Label'),
                                                style:
                                                textFormFieldValueStyle(),
                                                onFieldSubmitted: (term) {},
                                                validator: (val) =>
                                                /*stateListData[
                                                                    index]
                                                                .positionController
                                                                .text ==
                                                            "" &&*/
                                                stateListData[index]
                                                    .lableController
                                                    .text ==
                                                    "" &&
                                                    stateListData[index]
                                                        .valueController
                                                        .text ==
                                                        ""
                                                    ? null
                                                    : val.trim().isEmpty
                                                    ? MessageConstant
                                                    .FIELD_REQUIRED
                                                    : null,
                                              ),
                                            ),
                                            flex: 1),
                                         Expanded(
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  bottom:
                                                  UIHelper.screenPadding,
                                                  top: 5,
                                                  left: 2),
                                              child: TextFormField(
                                                controller: stateListData[index]
                                                    .valueController,
                                                //controller: timeFrom,
                                                //controller: timeFromController,
                                                //enabled: false,
                                                decoration:
                                                textFormFieldDecorationWithLabelStats(
                                                    ' Statistics Value'),
                                                style:
                                                textFormFieldValueStyle(),
                                                onFieldSubmitted: (term) {},
                                                validator: (val) =>
                                                /*stateListData[
                                                                    index]
                                                                .positionController
                                                                .text ==
                                                            "" &&*/
                                                stateListData[index]
                                                    .lableController
                                                    .text ==
                                                    "" &&
                                                    stateListData[index]
                                                        .valueController
                                                        .text ==
                                                        ""
                                                    ? null
                                                    : val.trim().isEmpty
                                                    ? MessageConstant
                                                    .FIELD_REQUIRED
                                                    : null,
                                              ),
                                            ),
                                            flex: 1),
                                      ],
                                    ),
                                  ],
                                )))),
                    Positioned(
                      right: 0.0,
                      top: 0.0,
                      child: InkWell(
                        child: index > 0
                            ? Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.18,
                            width: 17,
                          ),
                        )
                            :  Container(
                          height: 24.18,
                          width: 17,
                        ),
                        onTap: () {
                          if (stateListData.length > 1) {
                            print('link Index is =======>  $index');
                            stateListData.removeAt(index);
                          }
                          setState(() {});
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );

          },
        ),
        ////////////////////////////
        InkWell(
          child: Padding(
            padding: EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
            child: Text(
              '+ ADD MORE POSITION(s)'.toUpperCase(),
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.accentColor, 14, FontType.Regular),
            ),
          ),
          onTap: () {
            setState(() {
              stateListData.add(StateModel(
                  position: "",
                  lable: "",
                  value: "",
                  positionController:  TextEditingController(),
                  lableController:  TextEditingController(),
                  valueController:  TextEditingController()));
            });
          },
        ),
      ],
    );
  }

  clubTeamWidget() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: clubTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'Club Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  clubTeamList.removeAt(index);
                                  if (clubTeamList.length == 0) {
                                    isClubTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].clubNameController,

                            decoration:
                            textFormFieldDecorationWithLabel('Club Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].teamController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Team Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('City'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].stateController,

                            decoration:
                            textFormFieldDecorationWithLabel('State'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                            textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].coachNameController,

                            decoration:
                            textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                ? MessageConstant
                                .COACH_NAME_CONTAIN_ALPHABET_VAL
                                : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            clubTeamList[index].coachEmailController,

                            decoration:
                            textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                ? MessageConstant.VALID_EMAIL_VAL
                                : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    clubTeamList[index].selectedCountryCode =
                                        country.dialingCode;
                                    clubTeamList[index].selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode:
                                clubTeamList[index].selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: clubTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                        textFormFieldDecorationWithLabel(
                                            'Coach Phone Number'),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isClubTeam
            ?  Container(
          height: 0.0,
        )
            : InkWell(
          child: Padding(
            padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
            child: Text(
              '+ ADD MORE CLUB TEAM'.toUpperCase(),
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.accentColor, 14, FontType.Regular),
            ),
          ),
          onTap: () {
            setState(() {
              clubTeamList.add(ClubTeamModel(
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
              ));
            });
          },
        ),
      ],
    );
  }

  highSchoolTeamWidget() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: highSchoolTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'High School Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  highSchoolTeamList.removeAt(index);
                                  if (highSchoolTeamList.length == 0) {
                                    isHighSchoolTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].clubNameController,

                            decoration:
                            textFormFieldDecorationWithLabel('High School'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].teamController,

                            decoration:
                            textFormFieldDecorationWithLabel('Team Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].cityController,

                            decoration:
                            textFormFieldDecorationWithLabel('City'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].stateController,

                            decoration:
                            textFormFieldDecorationWithLabel('State'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                            textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].coachNameController,

                            decoration:
                            textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                ? MessageConstant
                                .COACH_NAME_CONTAIN_ALPHABET_VAL
                                : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            highSchoolTeamList[index].coachEmailController,

                            decoration:
                            textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                ? MessageConstant.VALID_EMAIL_VAL
                                : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    highSchoolTeamList[index]
                                        .selectedCountryCode =
                                        country.dialingCode;
                                    highSchoolTeamList[index]
                                        .selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode: highSchoolTeamList[index]
                                    .selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: highSchoolTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                        textFormFieldDecorationWithLabel(
                                            'Coach Phone Number'),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isHighSchoolTeam
            ?  Container(
          height: 0.0,
        )
            : InkWell(
          child: Padding(
            padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
            child: Text(
              '+ ADD MORE HIGH SCHOOL TEAM'.toUpperCase(),
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.accentColor, 14, FontType.Regular),
            ),
          ),
          onTap: () {
            setState(() {
              highSchoolTeamList.add(ClubTeamModel(
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
              ));
            });
          },
        ),
      ],
    );
  }

  collegeTeamWidget() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: collegeTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'College Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  collegeTeamList.removeAt(index);
                                  if (collegeTeamList.length == 0) {
                                    isCollegeTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            collegeTeamList[index].clubNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('College'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].teamController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Team Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('City'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].stateController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('State'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                            textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            collegeTeamList[index].coachNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                ? MessageConstant
                                .COACH_NAME_CONTAIN_ALPHABET_VAL
                                : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            collegeTeamList[index].coachEmailController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                ? MessageConstant.VALID_EMAIL_VAL
                                : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    collegeTeamList[index].selectedCountryCode =
                                        country.dialingCode;
                                    collegeTeamList[index]
                                        .selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode:
                                collegeTeamList[index].selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: collegeTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                        textFormFieldDecorationWithLabel(
                                            'Coach Phone Number'),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isCollegeTeam
            ?  Container(
          height: 0.0,
        )
            : InkWell(
          child: Padding(
            padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
            child: Text(
              '+ ADD MORE COLLEGE TEAM'.toUpperCase(),
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.accentColor, 14, FontType.Regular),
            ),
          ),
          onTap: () {
            setState(() {
              collegeTeamList.add(ClubTeamModel(
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
              ));
            });
          },
        ),
      ],
    );
  }

  otherTeamWidget() {
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: otherTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'Other Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  otherTeamList.removeAt(index);
                                  if (otherTeamList.length == 0) {
                                    isOtherTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].clubNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Other'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].teamController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Team Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('City'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].stateController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('State'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                            textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            otherTeamList[index].coachNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                ? MessageConstant
                                .COACH_NAME_CONTAIN_ALPHABET_VAL
                                : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                            otherTeamList[index].coachEmailController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                            textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                ? MessageConstant.VALID_EMAIL_VAL
                                : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    otherTeamList[index].selectedCountryCode =
                                        country.dialingCode;
                                    otherTeamList[index]
                                        .selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode:
                                otherTeamList[index].selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: otherTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                        textFormFieldDecorationWithLabel(
                                            'Coach Phone Number'),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isOtherTeam
            ?  Container(
          height: 0.0,
        )
            : InkWell(
          child: Padding(
            padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
            child: Text(
              '+ ADD MORE OTHER TEAM'.toUpperCase(),
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.accentColor, 14, FontType.Regular),
            ),
          ),
          onTap: () {
            setState(() {
              otherTeamList.add(ClubTeamModel(
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
                 TextEditingController(text: ""),
              ));
            });
          },
        ),
      ],
    );
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
      child: Container(
        child:  Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  personalReflectionWidget() {
    return  Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          17.0,
          0.0,
          5.0,
          20.0,
           Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
               Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                     Image.asset(
                      "assets/newDesignIcon/ad_new/personal_rel.png",
                      width: 25.0,
                      height: 25.0,
                    )),
                flex: 0,
              ),
               Expanded(
                child:  Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        6.0,
                        TextViewWrap.textView(
                            "Personal Reflection",
                            TextAlign.start,
                             ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            "Add some notes/reminders for yourself that you want to remember.",
                            TextAlign.start,
                             ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    //UIHelper.verticalGapBetweenBox,
                    personalReflectionUi(),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLineItalic(
                            "Note: Personal reflection is a note to self and will not be shared with anyone.",
                            TextAlign.start,
                             ColorValues.ORANGE_TEXT_COLOR,
                            10.0,
                            FontWeight.normal,
                            4)),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  personalReflectionUi() {
    return  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: personalReflectionController,
          maxLength: TextLength.PERSONAL_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            floatingLabelBehavior: FloatingLabelBehavior.never,
            //labelText: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is best.",

            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            // hintText: "Include things like what makes this experience so unique, what you might want to highlight in a college app. or in a job interview etc.",
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                //fontSize: 16
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
          /*validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_Personal_Reflection_VAL : null,*/
          onSaved: (val) => strpersonalReflection = val.trim(),
        ));
  }
}
