// Updated COde

import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';

import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

import 'CreatePassword.dart';
import 'ForgotPasswordVerification.dart';

class ForgotPassword extends StatefulWidget {
  static String tag = 'login-page';
  String email;

  ForgotPassword(this.email);

  @override
  ForgotPasswordState createState() => ForgotPasswordState();
}

final formKey = GlobalKey<FormState>();
String _email = "";
bool _isLoading = false;

class ForgotPasswordState extends State<ForgotPassword> {
  Color borderColor = Colors.amber;
  TextEditingController emailTxtController;
  bool isAllDataCompleted = false;

  void _checkValidation() {
    final form = formKey.currentState;
    setState(() => _isLoading = true);
    form.save();
    if (form.validate()) {
      forgotpassworApiCalling();
    } else {
      setState(() => _isLoading = false);
      print("Failure 00");
    }
  }

  ontapCancel() {
    Navigator.pop(context);
  }

  showErrorDialog() {
    return showDialog(
        barrierDismissible: false,
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(10.0))),
            contentPadding: EdgeInsets.only(
                top: 24.0, left: 20.0, right: 20.0, bottom: 24.0),
            content: Container(
                height: 300,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
                      child: Image.asset(
                        "assets/newDesignIcon/error_icon.png",
                        height: 85.0,
                        width: 85,
                      ),
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    Text(
                      "Error",
                      style: TextStyle(
                          fontSize: 24.0,
                          color: ColorValues.circle4,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          fontWeight: FontWeight.w700),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      MessageConstant.EMAIL_FORGOT_ERROR,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 16.0,
                          color: ColorValues.GREY__COLOR,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          fontWeight: FontWeight.w400),
                    ),
                    SizedBox(
                      height: 22,
                    ),
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: InkWell(
                              child: Container(
                                margin: EdgeInsets.only(right: 5),
                                padding: const EdgeInsets.only(
                                    left: 15, right: 15, top: 10, bottom: 10),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10.0)),
                                  border: Border.all(
                                      color: ColorValues.search_error_text),
                                ), //       <--- BoxDecoration here
                                child: Text(
                                  "Cancel",
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      color: ColorValues.search_error_text),
                                ),
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              },
                            ),
                            flex: 0,
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 15.0),
                              child: InkWell(
                                child: Container(
                                  margin: EdgeInsets.only(right: 5),
                                  padding: const EdgeInsets.only(
                                      left: 15, right: 15, top: 10, bottom: 10),
                                  decoration: BoxDecoration(
                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10.0)),
                                    border: Border.all(
                                        color:
                                            ColorValues.BLUE_COLOR_BOTTOMBAR),
                                  ), //       <--- BoxDecoration here
                                  child: Text(
                                    "Reset email address",
                                    style: TextStyle(
                                        fontSize: 14.0, color: Colors.white),
                                  ),
                                ),
                                onTap: () {
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                            flex: 0,
                          ),
                        ]),
                  ],
                )),
          );
        });
  }

  @override
  void initState() {
    super.initState();
    _email = widget.email;
    emailTxtController = new TextEditingController(text: widget.email);
    setState(() {
      _email;
      emailTxtController;
    });

    if (emailTxtController.text.length>0) {
      setState(() {
        isAllDataCompleted = true;
      });
    } else {
      setState(() {
        isAllDataCompleted = false;
      });
    }
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 1000), () async {
      print("timer off");
      Navigator.pop(context);
      Navigator.pop(context);
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  forgotpassworApiCalling() async {
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      try {
        CustomProgressLoader.showLoader(context);
        var dio = Dio();
        dio.onHttpClientCreate = (HttpClient client) {
          client.badCertificateCallback =
              (X509Certificate cert, String host, int port) {
            return true;
          };
        };
        dio.options.baseUrl = Constant.BASE_URL;
        dio.options.connectTimeout = Constant.CONNECTION_TIME_OUT; //5s
        dio.options.receiveTimeout = Constant.SERVICE_TIME_OUT;
        dio.options.headers = {'user-agent': 'dio'};
        dio.options.headers = {'Accept': 'application/json'};
        dio.options.headers = {'Content-Type': 'application/json'};
        // Prepare Data
        print( Constant.ENDPOINT_FORGOT_PASSWORD + _email.toLowerCase());
        // Make API call
        Response response = await dio.post(
          Constant.ENDPOINT_FORGOT_PASSWORD + _email.toLowerCase(),
        );
        CustomProgressLoader.cancelLoader(context);
        setState(() => _isLoading = false);
        print(response.toString());
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String message = response.data[LoginResponseConstant.MESSAGE];

          if (status == "Success") {
            var value =await  Navigator.of(context).push(new MaterialPageRoute(
                builder: (BuildContext context) =>
                    ForgotPasswordVerification(emailTxtController.text)));
            if(value!=null&&value){
              Navigator.pop(context);
            }
            //  showSucessMsg(message, context);
          } else {
            ToastWrap.showToastLongNew(message, context);
          }
        } else {
          //  CustomProgressLoader.cancelLoader(context);
          setState(() => _isLoading = false);
          // If that call was not successful, throw an error.
          throw Exception('Something went wrong!!');
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "ForgotPassword", context);
        CustomProgressLoader.cancelLoader(context);
        print(e);
        ToastWrap.showToast(e.toString(), context);
      }
    } else {
      setState(() => _isLoading = false);
      // CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;


    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: customAppbar(
            context,
            Form(
                key: formKey,
                child: SingleChildScrollView(
                  child: Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Padding(
                            padding: const EdgeInsets.only(
                                left: 20.0, right: 0.0, top: 24.0, bottom: 0),
                            child: RichText(
                              maxLines: 1,
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                text: 'Forgot',
                                style: AppConstants
                                    .txtStyle.heading400LatoRegularDarkBlue
                                    .copyWith(
                                    fontSize: 28,
                                    fontWeight: FontWeight.w700),
                                children: [
                                  TextSpan(
                                      text: ' password',
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {},
                                      style: AppConstants.txtStyle
                                          .heading40018LatoRegularDarkBlue
                                          .copyWith(
                                          fontSize: 28,
                                          fontWeight: FontWeight.w700)),
                                ],
                              ),
                            )),
                        Padding(
                          padding: EdgeInsets.fromLTRB(20.0, 10, 20.0, 45.0),
                          child: InkWell(
                            child: BaseText(
                              text:
                              'Please enter email address associated to this account. A verification code will be sent to reset your password.',
                              textColor: AppConstants.colorStyle.lightPurple,
                              fontFamily:
                              AppConstants.stringConstant.latoSemibold,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                            onTap: () {},
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                            left: 20.0,
                            right: 20,
                          ),
                          child: CustomFormField(
                            autovalidateMode: AutovalidateMode.disabled,
                            prefixWidget: Image.asset(
                              getAssetsPNGImg('email'),
                              height: 20,
                              width: 20,
                            ),
                            onType: (e) {
                              if (emailTxtController.text.length>0) {
                                setState(() {
                                  isAllDataCompleted = true;
                                });
                              } else {
                                setState(() {
                                  isAllDataCompleted = false;
                                });
                              }
                            },
                            controller: emailTxtController,
                            label: "Enter email address",
                            validation: (val) => val.trim().length == 0
                                ? MessageConstant.ENTER_EMAIL_VAL
                                : !ValidationWidget.isEmail(val)
                                ? MessageConstant.ENTER_CORRECRT_EMAIL_VAL
                                : null,
                            onSaved: (val) => _email = val,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
            ), ()
        {
          Navigator.pop(context);
        },
            bottomNavigation: Container(
                child: Padding(
                    padding: EdgeInsets.only(
                        left: 20.0, top: 0.0, right: 20.0, bottom: 50.0),
                    child: Stack(
                      children: <Widget>[
                        Container(
                            height: 44.0,
                            width: double.infinity,
                            child: FlatButton(
                              onPressed: () async {
                                _checkValidation();
                              },
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              color: AppConstants.colorStyle.lightBlue,
                              child: Row(
                                // Replace with a Row for horizontal icon + text
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text('Reset password',
                                      style: AppConstants.txtStyle
                                          .heading18600LatoRegularWhite),
                                ],
                              ),
                            )),
                        isAllDataCompleted
                            ? SizedBox(
                                height: 0,
                              )
                            : Container(
                                height: 44.0,
                                width: double.infinity,
                                color: Colors.white.withOpacity(0.75),
                              )
                      ],
                    ))),
            isShowExplanation: false));
  }
}
