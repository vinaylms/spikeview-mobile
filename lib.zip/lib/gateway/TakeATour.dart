// Updated COde

import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/gestures.dart';

import 'package:http/http.dart' as http;
import 'dart:io';

import 'package:flutter/material.dart';

import 'package:dio/dio.dart';
import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/component/image_utils.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/profile/UpdateUserProfile.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class TakeATour extends StatefulWidget {
  static String tag = 'login-page';
  String sasToken = '';
  ProfileInfoModal profileInfoModal;

  TakeATour(this.profileInfoModal, this.sasToken);
  @override
  TakeATourState createState() => TakeATourState();
}

final formKey = GlobalKey<FormState>();

SharedPreferences prefs;
String roleId, userId, email;
class TakeATourState extends State<TakeATour> {
  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    userId = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    email = prefs.getString(UserPreference.EMAIL);
  }


  Future apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userId, "stage": "2"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("update data+++ apiCallingUpdate");
            if (status == "Success") {
              Navigator.of(context).popUntil((route) => route.isFirst);
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          UpdateUserProfile(widget.profileInfoModal, widget.sasToken)));
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: Scaffold(
            resizeToAvoidBottomPadding: true,
            resizeToAvoidBottomInset: true,

            body: Container(
              height: double.infinity,
              width: double.infinity,
              color: Colors.white,
              /*decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/login/splash.png"),
                      fit: BoxFit.fill)),*/
              child: Padding(

                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(child:Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                            padding: const EdgeInsets.only(top: 30.0, bottom: 0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Expanded(child:    RichText(
                              maxLines: 1,
                              textAlign: TextAlign.start,
                              text: TextSpan(
                                text: 'Take a ',
                                style: AppConstants
                                    .txtStyle.heading400LatoRegularDarkBlue
                                    .copyWith(
                                    fontSize: 28,
                                    fontWeight: FontWeight.w700),
                                children: [
                                  TextSpan(
                                      text: 'tour',
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {},
                                      style: AppConstants
                                          .txtStyle.heading40018LatoRegularDarkBlue
                                          .copyWith(
                                          fontSize: 28,
                                          fontWeight: FontWeight.w700)),
                                ],
                              ),
                            ),flex: 1,),
                                Expanded(child:   const HelpButtonWidget(),flex: 0,),

                              ],
                            )),
                        Padding(
                          padding: EdgeInsets.only(top: 11),
                          child: InkWell(
                            child: BaseText(
                              textAlign: TextAlign.start,
                              text: 'Explore the spikeview platform',
                              textColor: AppConstants.colorStyle.lightPurple,
                              fontFamily:
                              AppConstants.stringConstant.latoSemibold,
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                            ),
                            onTap: () {},
                          ),
                        ),

                      ],
                    ) ,flex: 1,),
                    Expanded(child:Container(

                      child: Padding(
                          padding: EdgeInsets.only(top: 30.0),
                          child: InkWell(
                            onTap: (){
                              apiCallingUpdate();
                            },
                            child: Align(
                              alignment: Alignment.center,
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 40),
                                child: SizedBox(
                                  height: 44.0,
                                  width: 121,
                                  child: Container(

                                      decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          borderRadius: BorderRadius.all(Radius.circular(10)),
                                          border:   Border.all(
                                              width: 1.0,
                                              color:   AppConstants.colorStyle.borderColorBTN)
                                      ),
                                      child:  Center(
                                        child: BaseText(
                                          text: 'Skip',
                                          textColor: AppConstants.colorStyle.lightPurple,
                                          fontFamily:
                                          AppConstants.stringConstant.latoSemibold,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                        ),
                                      )),
                                ),
                              ),
                            ),
                          )),
                    ) ,flex: 0,)


                  ],
                ),
              ),
            )));
  }
}
