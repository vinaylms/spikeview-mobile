
import 'dart:io';

class UserData{

  String userId,firstName,lastName,email,salt
  ,mobileNo,profilePicture,roleId;

  UserData(this.userId, this.firstName, this.lastName, this.email, this.salt,
      this.mobileNo, this.profilePicture, this.roleId);

}

