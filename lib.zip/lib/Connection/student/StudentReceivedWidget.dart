import 'dart:async';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

class StudentReceivedWidget extends StatefulWidget {
  @override
  State<StudentReceivedWidget> createState() => StudentReceivedWidgetState();
}

class StudentReceivedWidgetState extends State<StudentReceivedWidget>
    with AutomaticKeepAliveClientMixin {
  BuildContext context;
  ScrollController _scrollController = ScrollController();
  TextEditingController edtController = TextEditingController();
  List<RequestedTagModel> tagList = List();
  List<RequestedTagModel> searchtagList = List();
  int listType;
  String statusIndex = Constant.CHILD_RECIEVED, searchName = "";
  int skip = 0;
  int searchCount = 0;
  SharedPreferences prefs;
  String userIdPref, roleId, userProfilePath;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
//2 5 6
    listType = 0;
    statusIndex = Constant.CHILD_RECIEVED;
    apiToGetDetail();
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();

    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;

        print("No Index---- " + skip.toString());
        apiToGetDetail();
      }
    });
  }

  Future apiToGetDetail() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        searchtagList.clear();
        tagList.clear();
        setState(() {
          isLoading;
        });

        print(Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
            userIdPref +
            "&status=" +
            statusIndex.toString() +
            "&roleId=" +
            roleId +
            "&skip=" +
            skip.toString());

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                statusIndex.toString() +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString() +
                "&name=" +
                searchName +
                "&limit=" +
                "10",
            "get");
        isLoading = false;
        if (searchName.isEmpty) {
          searchtagList.clear();
        } else {
          if (searchCount == 0) {
            searchtagList.clear();
            searchCount = 1;
          }
        }

        setState(() {
          isLoading;
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              switch (listType) {
                case 0:
                  List<RequestedTagModel> tagListLocal = List();
                  tagListLocal = ParseJson.parseRequestedTagList(
                      response.data['result']); //['Requested']
                  if (searchName.isEmpty) {
                    for (int i = 0; i < tagList.length; i++) {
                      for (int j = 0; j < tagListLocal.length; j++) {
                        if (tagList[i].patner.userId ==
                            tagListLocal[j].patner.userId) {
                          tagListLocal.removeAt(j);
                        }
                      }
                    }
                  } else {
                    for (int i = 0; i < searchtagList.length; i++) {
                      for (int j = 0; j < tagListLocal.length; j++) {
                        if (searchtagList[i].userId == tagListLocal[j].userId) {
                          tagListLocal.removeAt(j);
                        }
                      }
                    }
                  }
                  if (searchName.isEmpty) {
                    tagList.addAll(tagListLocal);
                    searchtagList.addAll(tagList);
                    print("SSS 111 ${searchtagList.length}");
                  } else {
                    searchtagList.addAll(tagListLocal);
                    print("SSS 222 ${searchtagList.length}");
                  }

                  setState(() {
                    tagList;
                    searchtagList;
                  });
                  break;
              }

              if (tagList != null) {
                if (tagList.length > 0) {
                  prefs.setString(
                      UserPreference.ISACTIVE, tagList[0].userIsActive);
                }

                setState(() {
                  print("After Success Response");
                  tagList;
                  searchtagList;
                  // sendRequestList;
                  // pendingRequestList;
                  // recievedRequestList;
                  // peopleYouMayKnowList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  SlidableController slidableCtrl = SlidableController();

  bool isNeedToRefresh = false;
  bool isLoading = true;
  SlidableController slideCtrl = SlidableController();

  Widget build(BuildContext context) {
    this.context = context;

    return customAppbar(
      context,
      Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20, top: 24, bottom: 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    BaseText(
                      text: 'Student connection',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w700,
                      fontSize: 28,
                      textAlign: TextAlign.start,
                      maxLines: 3,
                    ),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        16.0,
                        0.0,
                        15.0,
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                child: Container(
                                  //width: MediaQuery.of(context).size.width*0.45,
                                  child: Text(
                                    'Received',
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: statusIndex ==
                                              Constant.CHILD_RECIEVED
                                          ? ColorValues.WHITE
                                          : AppConstants.colorStyle.darkBlue,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                    ),
                                  ),
                                  padding: EdgeInsets.only(
                                      top: 9, bottom: 9, left: 9, right: 9),
                                  decoration: BoxDecoration(
                                    color:
                                        statusIndex == Constant.CHILD_RECIEVED
                                            ? ColorValues.DARK_YELLOW
                                            : AppConstants.colorStyle.tabBg,
                                    border: Border.all(
                                        color: statusIndex == 1
                                            ? ColorValues.DARK_YELLOW
                                            : AppConstants.colorStyle
                                                .borderGenerateScript),
                                    borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(10),
                                        bottomLeft: Radius.circular(10)),
                                  ),
                                ),
                                onTap: () {
                                  setState(() {
                                    statusIndex = Constant.CHILD_RECIEVED;
                                  });
                                  apiToGetDetail();
                                },
                              ),
                            ),
                            Expanded(
                              child: InkWell(
                                child: Container(
                                  //width: MediaQuery.of(context).size.width*0.45,
                                  child: Text(
                                    'Sent ',
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: statusIndex == Constant.CHILD_SENT
                                          ? ColorValues.WHITE
                                          : AppConstants.colorStyle.darkBlue,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                    ),
                                  ),
                                  padding: EdgeInsets.only(
                                      top: 9, bottom: 9, left: 9, right: 9),
                                  decoration: BoxDecoration(
                                    color: statusIndex == Constant.CHILD_SENT
                                        ? ColorValues.DARK_YELLOW
                                        : AppConstants.colorStyle.tabBg,
                                    border: Border.all(
                                        color: AppConstants
                                            .colorStyle.borderGenerateScript),
                                    borderRadius: const BorderRadius.only(
                                        topRight: Radius.circular(10),
                                        bottomRight: Radius.circular(10)),
                                  ),
                                ),
                                onTap: () {
                                  setState(() {
                                    statusIndex = Constant.CHILD_SENT;
                                  });
                                  apiToGetDetail();
                                },
                              ),
                            ),
                          ],
                        )),
                  ],
                ),
              ),
              flex: 0,
            ),
            Expanded(
              child: /* tagList.length > 0
                  ?*/
                  Container(
                      child: Column(children: <Widget>[
                // CustomViews.getSepratorLine(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
                  child: SizedBox(
                    height: 40,
                    child: TextField(
                      textAlign: TextAlign.left,
                      controller: edtController,
                      onChanged: (value) {
                        searchName = value;
                        if (value.isEmpty) {
                          apiToGetDetail();
                        }
                      },
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                        hintText: "Search connections",
                        hintStyle: TextStyle(
                            fontSize: 14, fontFamily: Constant.latoRegular),
                        contentPadding:
                            EdgeInsets.fromLTRB(15.0, 10.0, 20.0, 10.0),
                        suffixIcon: IconButton(
                          onPressed: () {
                            if (edtController.text.trim() != "") {
                              apiToGetDetail();
                            }
                          },
                          icon: Image.asset(
                            "assets/newDesignIcon/connections/new_search.png",
                            height: 20,
                            width: 20,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10.0),
                          ),
                          borderSide:
                              BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10.0),
                          ),
                          borderSide:
                              BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                        ),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(10.0),
                            ),
                            borderSide: new BorderSide(
                                color: ColorValues.BORDER_COLOR_NEW)),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: searchtagList.length > 0
                      ? ListView(
                    padding: EdgeInsets.all(0),
                          controller: _scrollController,
                          children: <Widget>[
                              Column(
                                children: List.generate(searchtagList.length,
                                    (int index) {
                                  return getListview(searchtagList[index],
                                      index, false, "", tagList.length);
                                }),
                              )
                            ])
                      : isLoading?SizedBox():Center(
                          child: Container(
                            child:  Column(
                              children: <Widget>[
                                Padding(
                                    padding: EdgeInsets.fromLTRB(15.0, 100.0, 0.0, 0.0),
                                    child: Container(
                                      width: 120.0,
                                      height: 111.0,
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                              'assets/newDesignIcon/connections/man_to_guide.png',
                                            ),
                                            fit: BoxFit.cover),
                                      ),
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                    40.0,
                                    25.0,
                                    40.0,
                                    5.0,
                                    TextViewWrap.textView(
                                        "No connection request yet",
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        16.0,
                                        FontWeight.normal)),

                              ],
                            ),
                          )),
                )
              ]))
              /*: isLoading
                  ? Center(
                  child: Container(
                    // child: Center(
                    //   child: Container(
                    //       // A simplified version of dialog.
                    //       width: 30.0,
                    //       height: 30.0,
                    //       child: CircularProgressIndicator(
                    //         valueColor: AlwaysStoppedAnimation(Colors.black54),
                    //         strokeWidth: 2.0,
                    //       )),
                    // ),
                  ))
                  : Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                          padding: EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                          child:Container(
                            width: 120.0,
                            height: 111.0,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(
                                      'assets/newDesignIcon/connections/man_to_guide.png'),
                                  fit: BoxFit.cover),
                            ),
                          )),
                      Center(
                          child: Text(
                            "You don't have any pending connection requests.",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 18.0,
                                fontFamily: Constant.latoRegular),
                          )),


                    ],
                  ),


                ),
              )*/
              ,
              flex: 1,
            ),
          ],
        ),
      ),
      () {
        Navigator.pop(context);
      },
      isShowIcon: false,
    );
  }

  Widget getListview(
      requestedTagModel, index, bool isSentRequest, status, int length) {

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Slidable(
          controller: slideCtrl,
          // delegate: new SlidableDrawerDelegate(),
          actionPane: SlidableDrawerActionPane(),
          actionExtentRatio: 0.18,
          child: new Container(
              padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 5.0),
              child: Card(
                  color: Colors.transparent,
                  elevation: 0.0,
                  child: Column(

                    children: <Widget>[
                      InkWell(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                          Expanded(
                          child:    Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Expanded(
                                  child: InkWell(
                                    child:
                                    Container(
                                        height: 48.0,
                                        width: 48.0,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(15),
                                            border: Border.all(
                                                color: Colors.white,
                                                width: 1),
                                            boxShadow:[
                                              BoxShadow(
                                                spreadRadius: 3,
                                                blurRadius: 3,
                                                offset: Offset(0, 2),
                                                color: Color.fromRGBO(98, 175, 226,0.09),
                                              )
                                            ]
                                        ),
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(15.0),
                                          child:requestedTagModel
                                              .patner.profilePicture ==
                                              "null" ||
                                              requestedTagModel
                                                  .patner.profilePicture ==
                                                  ""
                                              ? Image.asset(
                                              'assets/profile/user_on_user.png')
                                              : FadeInImage(
                                            fit: BoxFit.cover,
                                            placeholder: AssetImage(
                                              'assets/profile/user_on_user.png',
                                            ),
                                            image: NetworkImage(
                                                Constant.IMAGE_PATH_SMALL +
                                                    ParseJson.getSmallImage(
                                                        requestedTagModel
                                                            .patner
                                                            .profilePicture)),
                                          ),
                                        )),
                                    onTap: () {
                                      if (requestedTagModel.patner.userId ==
                                          userIdPref) {
                                      } else {
                                        Util.onTapImageTile(
                                            tapedUserRole:
                                                requestedTagModel.patner.roleId,
                                            partnerUserId:
                                                requestedTagModel.patner.userId,
                                            context: context);
                                      }
                                    },
                                  ),
                                  flex: 0,
                                ),
                                Expanded(
                                  child: PaddingWrap.paddingfromLTRB(
                                      10.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: <Widget>[
                                          Row(
                                            children: <Widget>[
                                              Expanded(
                                                child: BaseText(
                                      text:  getName(
                                          null, requestedTagModel),
                                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants.stringConstant.latoMedium,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18,
                                        textAlign: TextAlign.start,
                                        maxLines: 3,
                                      ),

                                                flex: 1,
                                              ),
                                              /*  Expanded(
                                                flex: 0,
                                                child: requestedTagModel
                                                            .patner.roleId ==
                                                        "1"
                                                    ? Util.getStudentBadge12(
                                                        requestedTagModel
                                                            .patner.badge,
                                                        requestedTagModel
                                                            .patner.badgeImage)
                                                    : Container(),
                                              ),*/
                                            ],
                                          ),
                                          roleId == "2"
                                              ? PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              4.0,
                                              0.0,
                                              5.0,
                                              RichText(
                                                maxLines: 1,
                                                textAlign: TextAlign.start,
                                                text: TextSpan(
                                                  text: "For ",
                                                  style:  TextStyle(
                                                    color:        AppConstants.colorStyle.lightPurple,
                                                    fontSize: 12.0,
                                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                                  ),
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                        text: requestedTagModel
                                                            .userData
                                                            .lastName ==
                                                            null ||
                                                            requestedTagModel
                                                                .userData
                                                                .lastName ==
                                                                "null" ||
                                                            requestedTagModel
                                                                .userData
                                                                .lastName ==
                                                                ""
                                                            ? requestedTagModel
                                                            .userData.firstName
                                                            : requestedTagModel
                                                            .userData
                                                            .firstName +
                                                            " " +
                                                            requestedTagModel
                                                                .userData
                                                                .lastName,
                                                        style: TextStyle(
                                                            fontFamily:
                                                            Constant.TYPE_CUSTOMBOLD,
                                                            fontSize: 12.0,
                                                            color:        AppConstants.colorStyle.lightPurple,))
                                                  ],
                                                ),
                                              ))
                                              : PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              4.0,
                                              0.0,
                                              5.0,
                                              TextViewWrap.textViewMultiLine(
                                                  requestedTagModel.status ==
                                                      "Pending"
                                                      ? "Your parent approval pending"
                                                      : "Pending" /*requestedTagModel
                                                                    .patner.lastName ==
                                                                null ||
                                                            requestedTagModel.patner
                                                                    .lastName ==
                                                                "null" ||
                                                            requestedTagModel.patner
                                                                    .lastName ==
                                                                ""
                                                        ? "Pending From " +
                                                            requestedTagModel
                                                                .patner.firstName
                                                        : "Pending From " +
                                                            requestedTagModel
                                                                .patner
                                                                .firstName +
                                                            " " +
                                                            requestedTagModel
                                                                .patner.lastName*/
                                                  ,
                                                  TextAlign.start,
                                                  AppConstants.colorStyle.lightPurple,
                                                  12.0,
                                                  FontWeight.normal,
                                                  1))
                                        ],
                                      )),
                                  flex: 1,
                                ),

                              ],
                            ),flex: 1,),
                            Expanded(
                              child:   Center(
                                child: ButtonView(
                                  btnName: 'Approve',
                                  borderColor:
                                  AppConstants.colorStyle.lightBlue,
                                  bgColor:
                                  AppConstants.colorStyle.box_bg_color,
                                  txtColor:
                                  AppConstants.colorStyle.lightBlue,
                                  onButtonTap: () {
                                    apiCallingForAccept(
                                        requestedTagModel
                                            .connectId,
                                        index,
                                        "requested",
                                        requestedTagModel
                                            .userIsActive);
                                  },
                                ),
                              ),
                              flex: 0,
                            ),
                          ],
                        ),
                        onTap: () {
                          if (requestedTagModel.patner.userId == userIdPref) {
                          } else {
                            Util.onTapImageTile(
                                tapedUserRole:
                                    requestedTagModel.patner.roleId,
                                partnerUserId:
                                    requestedTagModel.patner.userId,
                                context: context);
                          }
                        },
                      )
                    ],
                  ))),
          secondaryActions: <Widget>[
            new SlideAction(
              child: Text("Delete",
                  style: TextStyle(
                      color: ColorValues.WHITE,
                      fontSize: 14.0,
                      fontFamily: Constant.latoRegular)),
              // color: ColorValues.Delete_lable_color,
              decoration:
                  BoxDecoration(color: ColorValues.Delete_lable_color),
              onTap: () {

                apiCallingForDeleteStudentConnection(
                  requestedTagModel
                      .connectId,
                  index,
                );
              },
            ),
          ],
        ),
        Padding(
            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 0.0),
            child: Divider(
              color: ColorValues.BORDER_COLOR_NEW,
              thickness: 1,
              height: 0,
            ),
        ),
      ],
    );
  }

  Future apiCallingForDeleteStudentConnection(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId),
        "userId": int.parse(userIdPref)
      };
      Response response = await  ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_DELETE_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isNeedToRefresh = true;
            searchtagList.clear();

            tagList.removeAt(index);
            searchtagList.addAll(tagList);
            setState(() {
              tagList;
              searchtagList;
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"connection_request",context);
      e.toString();
    }
  }

  Future apiCallingForAccept(connectionId, index, type, userIsActive) async {
    try {


      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId),
    "userId": int.parse(userIdPref),

    };
      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isNeedToRefresh = true;
            searchtagList.clear();

            tagList.removeAt(index);
            searchtagList.addAll(tagList);
            setState(() {
              tagList;
              searchtagList;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  void educationRemoveConfromationDialog(id, name, index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//

                                                  PaddingWrap.paddingfromLTRB(
                                                      20.0,
                                                      0.0,
                                                      20.0,
                                                      0.0,
                                                      RichText(
                                                        textAlign:
                                                            TextAlign.center,
                                                        text: TextSpan(
                                                          text:
                                                              'This connection request will be declined.',
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .HEADING_COLOR_EDUCATION,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        ),
                                                      )),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Remove",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);

                                              apiCallingForUnfriend(
                                                id,
                                                index,
                                              );
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Future apiCallingForUnfriend(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            print("Cancel -----=-=-=-=-=-=-=-= " + listType.toString());

            if (listType == 0) tagList.removeAt(index);

            isNeedToRefresh = true;

            //ToastWrap.showToast(msg);
            setState(() {
              tagList;
              // sendRequestList;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getName(PeopleYouMayKnow, requestedTagModel) {
    String firstName, lastName;

    if (PeopleYouMayKnow != null) {
      if (PeopleYouMayKnow.lastName == null ||
          PeopleYouMayKnow.lastName == "null" ||
          PeopleYouMayKnow.lastName == "") {
        lastName = "";
      } else {
        lastName = PeopleYouMayKnow.lastName;
      }

      if (PeopleYouMayKnow.firstName == null ||
          PeopleYouMayKnow.firstName == "null" ||
          PeopleYouMayKnow.firstName == "") {
        firstName = PeopleYouMayKnow.email;
      } else {
        firstName = PeopleYouMayKnow.firstName;
      }

      return firstName + " " + lastName;
    } else {
      if (requestedTagModel.patner.lastName == null ||
          requestedTagModel.patner.lastName == "null" ||
          requestedTagModel.patner.lastName == "") {
        lastName = "";
      } else {
        lastName = requestedTagModel.patner.lastName;
      }

      if (requestedTagModel.patner.firstName == null ||
          requestedTagModel.patner.firstName == "null" ||
          requestedTagModel.patner.firstName == "") {
        firstName = requestedTagModel.patner.email;
      } else {
        firstName = requestedTagModel.patner.firstName;
      }

      return firstName + " " + lastName;
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
