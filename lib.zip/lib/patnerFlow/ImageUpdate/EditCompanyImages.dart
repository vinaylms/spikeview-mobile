import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/CompanyModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';

import 'package:spike_view_project/values/ColorValues.dart';

class EditCompanyImages extends StatefulWidget {

  CompanyProfileModel companyModel;
  String sasToken, strPrefixPathforCoverPhoto, strPrefixPathforProfilePhoto;

  EditCompanyImages(this.companyModel, this.sasToken,
      this.strPrefixPathforCoverPhoto, this.strPrefixPathforProfilePhoto);

  @override
  EditCompanyImagesState createState() =>
       EditCompanyImagesState(
          companyModel,
          strPrefixPathforCoverPhoto,
          strPrefixPathforProfilePhoto);
}

class EditCompanyImagesState extends State<EditCompanyImages> {
  EditCompanyImagesState(this.companyModel,
      this.strPrefixPathforCoverPhoto, this.strPrefixPathforProfilePhoto);
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String strPrefixPathforCoverPhoto, strPrefixPathforProfilePhoto;
  CompanyProfileModel companyModel;
  String userIdPref;
  File imagePath, imagePathCover;
  String strAzureCoverImageUploadPath = "";
  String strAzureProfileImageUploadPath = "";
  String coverImagePath = "";
  String profileImagePath = "";
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
  }

  static const platform = const MethodChannel('samples.flutter.io/battery');

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("sasToken+++"+widget.sasToken);
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": widget.sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });

        print("image_path" + result);
        return result;
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  //--------------------------Upload Cover Image Data ------------------
  Future uploadCoverIMage() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;


          Map map = {

            "coverPicture": coverImagePath,
            "profilePicture": profileImagePath,
            "companyId": companyModel.companyId
          };

          response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_COMPANY_UPDATE, map);

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {


                prefs.setString(
                    UserPreference.COMPANY_IMAGE_PATH, profileImagePath);

                prefs.setString(
                    UserPreference.PROFILE_IMAGE_PATH, profileImagePath);

                widget.companyModel.profilePicture = profileImagePath;

                widget.companyModel.coverPicture = coverImagePath;

                setState(() {
                  widget.companyModel;
                });
                syncDoneController.add("sucess");
              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    super.initState();
    // TODO: implement initState

    getSharedPreferences();
    coverImagePath = companyModel.coverPicture;
    profileImagePath = companyModel.profilePicture;
    print("profilepath" + profileImagePath);
    print("coverPath" + coverImagePath);
    setState(() {
      coverImagePath;
      profileImagePath;
    });
  }



  @override
  Widget build(BuildContext context) {
    Future<Null> _cropImage(File imageFile, name) async {
      if (name == "imagePath") {
        print("imagepath printed");
        imagePath = await ImageCropper.cropImage(
          sourcePath: imageFile.path,
          ratioX: 1.0,
          ratioY: 1.0,


        );
      } else {
        print("imagepathcover printed");
        imagePathCover = await ImageCropper.cropImage(
          sourcePath: imageFile.path,
          ratioX: 1.0,
          ratioY: 1.0,


        );
      }
    }

    Future getImage() async {
      imagePath = await UploadMedia(context).pickImageFromGallery();
      //imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath
                .toString()
                .length);
        print("imagepath shubh" + strPath);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          if (imagePath != null) {
            await _cropImage(imagePath, "imagePath");
            if (imagePath != null) {
              CustomProgressLoader.showLoader(context);
              Timer _timer =
               Timer(const Duration(milliseconds: 400), () async {
                try {
                  strAzureProfileImageUploadPath = await uploadImgOnAzure(
                      imagePath
                          .toString()
                          .replaceAll("File: ", "")
                          .replaceAll("'", "")
                          .trim(),
                      strPrefixPathforProfilePhoto);
                } catch (e) {
                  CustomProgressLoader.cancelLoader(context);
                }
                print("prefixpath shubh" + strPrefixPathforProfilePhoto);
                print("profilepath" + strAzureProfileImageUploadPath);
                if (strAzureProfileImageUploadPath != "" &&
                    strAzureProfileImageUploadPath != "false") {
                  profileImagePath = strPrefixPathforProfilePhoto +
                      strAzureProfileImageUploadPath;
                  setState(() {
                    profileImagePath;
                    imagePath = imagePath;
                  });
                  CustomProgressLoader.cancelLoader(context);
                } else {
                  CustomProgressLoader.cancelLoader(context);
                }
              });
            }
          }
        } else {
          CustomProgressLoader.cancelLoader(context);
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR,
              context);
        }
      }
    }

    Future getImageCover() async {
      imagePathCover = await UploadMedia(context).pickImageFromGallery();
     // imagePathCover = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePathCover != null) {
        String strPath = imagePathCover.toString().substring(
            imagePathCover.toString().lastIndexOf("/") + 1,
            imagePathCover
                .toString()
                .length);

        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          if (imagePathCover != null) {
            await _cropImage(imagePathCover, "cover");
            if (imagePathCover != null) {
              CustomProgressLoader.showLoader(context);
              Timer _timer =
               Timer(const Duration(milliseconds: 400), () async {
                try {
                  strAzureCoverImageUploadPath = await uploadImgOnAzure(
                      imagePathCover
                          .toString()
                          .replaceAll("File: ", "")
                          .replaceAll("'", "")
                          .trim(),
                      strPrefixPathforCoverPhoto);
                } catch (e) {
                  CustomProgressLoader.cancelLoader(context);
                }
                print("azureimagepath   :-" + strAzureCoverImageUploadPath);
                if (strAzureCoverImageUploadPath != "" &&
                    strAzureCoverImageUploadPath != "false") {
                  coverImagePath =
                      strPrefixPathforCoverPhoto + strAzureCoverImageUploadPath;
                  setState(() {
                    imagePathCover = imagePathCover;
                    coverImagePath;
                  });

                  print("prefixpath cover " + strPrefixPathforCoverPhoto);
                  print("coverpath " + strAzureCoverImageUploadPath);
                  CustomProgressLoader.cancelLoader(context);
                } else {
                  CustomProgressLoader.cancelLoader(context);
                }
              });
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR,
              context);
        }
      }
    }

    return  Scaffold(
        backgroundColor:  ColorValues.SCREEN_BG_COLOR,
        appBar:  AppBar(
          elevation: 0.0,
          brightness: Brightness.light,
          automaticallyImplyLeading: false,
          title:  Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
               Expanded(
                child:  InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        30.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 15.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    Navigator.pop(context, "");
                  },
                ),
                flex: 0,
              ),
               Container(
                width: 15.0,
              ),
               Expanded(
                child:  Text(
                  "Profile Photo",
                  textAlign: TextAlign.center,
                  style:  TextStyle(
                      color:  ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 18.0,
                      fontFamily:Constant.TYPE_CUSTOMREGULAR),
                ),
                flex: 1,
              ),
               Expanded(
                child:  InkWell(
                  child:  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          2.0,
                          TextViewWrap.textView(
                              "Save",
                              TextAlign.center,
                               ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal))
                    ],
                  ),
                  onTap: () {
                    if (profileImagePath != companyModel.profilePicture ||
                        coverImagePath != companyModel.coverPicture) {
                      uploadCoverIMage();
                    }
                  },
                ),
                flex: 0,
              )
            ],
          ),
          actions: <Widget>[],
          backgroundColor: Colors.white,
        ),
        body:

         Container(
          child: Column(
            children: <Widget>[
              CustomViews.getSepratorLine(),
               Expanded(child:  Center(
                  child: PaddingWrap.paddingAll(
                      13.0,
                       Column(
                        crossAxisAlignment: CrossAxisAlignment.start,

                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                       PaddingWrap.paddingfromLTRB(0.0, 0.0, 20.0, 11.0,  TextViewWrap.textViewMultiLine(
                            "Click to add Profile Photo or Cover Photo",
                            TextAlign.start,
                             ColorValues.HEADING_COLOR_EDUCATION,
                            14.0, FontWeight.normal, 2)),

                         Container(
                          child:  Container(
                            height: 450.0,
                            color:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
                            child:  Stack(
                              children: <Widget>[
                                 Positioned(
                                    top: 0.0,
                                    bottom: 50.0,
                                    left: 0.0,
                                    right: 0.0,
                                    child:  InkWell(
                                      child:  Stack(
                                        children: <Widget>[
                                           Positioned(
                                            child: FadeInImage.assetNetwork(
                                              fit: BoxFit.cover,
                                              placeholder:
                                              'assets/newDesignIcon/background_new.png',
                                              image: Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getMediumImage(
                                                      coverImagePath),
                                            ),
                                            top: 0.0,
                                            bottom: 0.0,
                                            left: 0.0,
                                            right: 0.0,
                                          ),

                                        ],
                                      ),
                                      onTap: () async {
                                        var status = await Permission.photos.status;
                                        if (status.isGranted) {
                                          getImageCover();
                                        }  else {
                                          checkPermissionPhoto(context);
                                        }

                                      },
                                    )),

                                 Positioned(
                                    top: 0.0,
                                    bottom: 50.0,
                                    left: 0.0,
                                    right: 0.0,
                                    child:  InkWell(
                                      child:  Stack(
                                        children: <Widget>[
                                           Container(
                                            width: double.infinity,
                                            child:  Image.asset(
                                              "assets/newDesignIcon/navigation/layer_cover.png",
                                              fit: BoxFit.fill,
                                            ),
                                          )

                                        ],
                                      ),
                                      onTap: () async {
                                        var status = await Permission.photos.status;
                                        if (status.isGranted) {
                                          getImageCover();
                                        }  else {
                                          checkPermissionPhoto(context);
                                        }
                                      },
                                    )),
                                 Positioned(
                                    top: 100.0,
                                    bottom: 0.0,
                                    left: 0.0,
                                    right: 0.0,
                                    child:  Column(
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            20.0,
                                            0.0,
                                            0.0,
                                             Container(
                                                child:  Row(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                                  children: <Widget>[
                                                     Expanded(
                                                      child: PaddingWrap
                                                          .paddingAll(
                                                          10.0,
                                                           InkWell(
                                                            child:  Container(
                                                              width: 111.0,
                                                              height: 111.0,
                                                              child:  Stack(
                                                                children: <
                                                                    Widget>[
                                                                   Center(
                                                                      child:  Container(
                                                                        child:  ClipOval(
                                                                            child: FadeInImage
                                                                                .assetNetwork(
                                                                              fit: BoxFit
                                                                                  .cover,
                                                                              placeholder:
                                                                              'assets/profile/partner_img.png',
                                                                              image: Constant
                                                                                  .IMAGE_PATH_SMALL +
                                                                                  ParseJson
                                                                                      .getMediumImage(
                                                                                      profileImagePath),
                                                                            )),
                                                                        width: 111.0,
                                                                        height: 111.0,
                                                                        padding:  EdgeInsets
                                                                            .fromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                      )),
                                                                ],
                                                              ),
                                                            ),
                                                            onTap: () async {
                                                              var status = await Permission.photos.status;
                                                              if (status.isGranted) {
                                                                getImage();
                                                              }  else {
                                                                checkPermissionPhoto(context);
                                                              }
                                                            },
                                                          )),
                                                      flex: 0,
                                                    ),
                                                  ],
                                                ))),
                                      ],
                                    )),
                                 Positioned(
                                    top: 10.0,

                                    right: 10.0,
                                    child:  Container(

                                        child:  Image.asset(
                                          "assets/newDesignIcon/photo_picker.png",
                                          height: 31.0, width: 32.0,)))
                              ],
                            ),
                          ),
                        )
                      ],))), flex: 1,)

            ],),)


    );
  }
}
