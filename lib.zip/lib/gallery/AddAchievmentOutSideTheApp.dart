import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';

class AddAchievmentOutSideTheAppWidget extends StatefulWidget {
  List<Assest> assestList;
  String strCompetencyTypeId, strcompetencyTypeName;
  String userId;
  String level1Name;
  List<Level3Competencies> level3Competencylist;
  List<Level2Competencies> level2Competencylist;

  AddAchievmentOutSideTheAppWidget(
      this.level1Name,
      this.userId,
      this.assestList,
      this.strCompetencyTypeId,
      this.strcompetencyTypeName,
      this.level3Competencylist,
      this.level2Competencylist);

  @override
  AddAchievmentOutSideTheAppWidgetState createState() =>
      AddAchievmentOutSideTheAppWidgetState(assestList);
}

class AddAchievmentOutSideTheAppWidgetState
    extends State<AddAchievmentOutSideTheAppWidget> {
  AddAchievmentOutSideTheAppWidgetState(this.assestList);

  List<Level3Competencies> level3Competencylist = List();
  List<String> imageList = List();

  //String selectedImageType = "media";
  List<Assest> assestList;
  List<Assest2> finalList = List();
  final _formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  bool isParent = false;
  Level3Competencies competencySelected;
  String strTitle = "";
  String strCompetencyId = "", strCompetencyValue = "";
  FocusNode _focus = FocusNode();
  String sasToken = "", containerName = "";
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String strPrefixPathforPhoto = "";
  String imageType = "media";
  TextEditingController secondLevelCompetencyController =
      TextEditingController();
  TextEditingController otherCategory;
  final _formKey2 = GlobalKey<FormState>();
  bool isThirLevelField = true;

  TextEditingController thirdLevelController = TextEditingController(text: "");

  getEditCategoryTextField(isEnabled, label, isEdit) {
    return Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 5.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          autofocus: isEnabled,
          maxLength: isEnabled
              ? TextLength.OTHER_MAX_LENGTH
              : TextLength.OTHER_COMPETENCY_MAX_LENGTH,
          textCapitalization: TextCapitalization.sentences,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
          controller: isEnabled ? otherCategory : thirdLevelController,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              label, isEnabled ? "" : MessageConstant.FOCUS_AREA_HINT_TEXT),
          validator: (val) =>
              /*isEdit?
        val.trim().isEmpty||  val.trim()=="Other"||val.trim()=="General"?MessageConstant.ENTER_TITLE_VAL_CHANGE:null
              :*/
              val.trim().isEmpty
                  ? label == "Focus Area"
                      ? MessageConstant.FOCUS_AREA_VALIDATION
                      : widget.strcompetencyTypeName == "General"
                          ? MessageConstant.ENTER_TITLE_VAL_GENERAL_CHANGE
                          : MessageConstant.ENTER_TITLE_VAL_OTHER_CHANGE
                  : null,
        ));
  }

  editCategoryDialog(isEdit, isPortfolio, isCompulsary) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              // Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            top: 43.0,
                            child: Container(
                                height: 170.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        Container(
                                            height: 170.0,
                                            decoration: BoxDecoration(
                                              color: Colors.transparent,
                                              image: DecorationImage(
                                                image: AssetImage(
                                                    "assets/container.png"),
                                                fit: BoxFit.fill,
                                              ),
                                            ),
                                            padding: EdgeInsets.fromLTRB(
                                                13.0, 0, 13, 0),
                                            width: double.infinity,
                                            // color: Colors.white,
                                            child: Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  13.0, 0, 0, 0),
                                              child: Form(
                                                  key: _formKey2,
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: <Widget>[
                                                        isCompulsary
                                                            ? InkWell(
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                },
                                                                child:
                                                                    Container(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              13.0,
                                                                              5.0,
                                                                              0.0),
                                                                          child:
                                                                              Icon(
                                                                            Icons.close,
                                                                            color:
                                                                                ColorValues.search_error_text,
                                                                            size:
                                                                                20.0,
                                                                          )),
                                                                ))
                                                            : InkWell(
                                                                onTap: () {
                                                                  if (isEdit) {
                                                                    Navigator.pop(
                                                                        context);
                                                                  } else {
                                                                    Navigator.pop(
                                                                        context);
                                                                    Navigator.pop(
                                                                        context);
                                                                  }
                                                                },
                                                                child:
                                                                    Container(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              13.0,
                                                                              5.0,
                                                                              0.0),
                                                                          child:
                                                                              Icon(
                                                                            Icons.close,
                                                                            color:
                                                                                ColorValues.search_error_text,
                                                                            size:
                                                                                20.0,
                                                                          )),
                                                                )),
                                                        Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(0.0,
                                                                    0, 10, 0),
                                                            child: Container(
                                                              height: 84,
                                                              child: getEditCategoryTextField(
                                                                  true,
                                                                  widget.strcompetencyTypeName ==
                                                                          "General"
                                                                      ? MessageConstant
                                                                          .ENTER_GENERAL_DISPLAY_TITLE
                                                                      : MessageConstant
                                                                          .ENTER_OTHER_DISPLAY_TITLE,
                                                                  isCompulsary),
                                                            )),
                                                        Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(0.0,
                                                                    0, 10, 0),
                                                            child: InkWell(
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top:
                                                                            0.0,
                                                                        bottom:
                                                                            6.0),
                                                                child: Container(
                                                                    width: 80.0,
                                                                    height: 30.0,
                                                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                    child: Center(
                                                                      child:
                                                                          Text(
                                                                        isCompulsary
                                                                            ? "UPDATE"
                                                                            : "ADD",
                                                                        textAlign:
                                                                            TextAlign.center,
                                                                        style: TextStyle(
                                                                            color: Colors
                                                                                .white,
                                                                            fontSize:
                                                                                12.0,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                    )),
                                                              ),
                                                              onTap: () {
                                                                final form1 =
                                                                    _formKey2
                                                                        .currentState;

                                                                form1.save();
                                                                if (form1
                                                                    .validate()) {
                                                                  Navigator.pop(
                                                                      context);
                                                                  setState(() {
                                                                    strCompetencyValue =
                                                                        otherCategory
                                                                            .text;
                                                                  });
                                                                }
                                                              },
                                                            ))
                                                      ])),
                                            )))
                                  ],
                                )))
                      ],
                    )))));
  }

  Future mediaApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_MEDIA_ACCOM, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              imageList = ParseJson.parseMedia(response.data['result']);
              if (imageList != null) {
                setState(() {
                  imageList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    isParent = prefs.getBool("isParent");
    mediaApi(false);
    if (widget.strcompetencyTypeName == "Other" ||
        widget.strcompetencyTypeName == "General") {
      editCategoryDialog(false, false, false);
    }

    if (isParent == null) {
      isParent = false;
    }
    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        widget.userId +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    _timer = Timer(const Duration(milliseconds: 5000), () async {
      Navigator.pop(context);
      //  Navigator.of(context).popUntil((route) => route.isFirst);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: new Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //assestList.removeAt(0);
        var date = DateTime.now().toString();
        var dateParse = DateTime.parse(date);
        var formattedDate = "${dateParse.day}-${dateParse.month}-${dateParse.year}";



        Map map = {
          "achievementId": "",
          "competencyTypeId": widget.strCompetencyTypeId,
          "level2Competency": widget.strcompetencyTypeName,
          "level3Competency": strCompetencyValue,
          "focusArea": thirdLevelController.text,
          "userId": widget.userId,
          "badge": [],
          "certificate": [],
          "asset": finalList.map((item) => item.toJson()).toList(),
          "skills": [],
          "title": strTitle,
          "description": " ",
          "fromDate": "",
          "toDate": "",
          "importance": "",
          "guide": {
            "promptRecommendation": false,
            "firstName": "",
            "lastName": "",
            "email": "",
          },
          "stories": "",
          "isActive": false
        };

        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  void _onFocusChange() {
    debugPrint("Focus: " + _focus.hasFocus.toString());
  }

  ontapApply() async {
    try {
      final form = _formKey.currentState;
      form.save();

      if (form.validate()) {
        if (validationCheck()) {
          if ((assestList.length) <= 10) {
            CustomProgressLoader.showLoader(context);
            Timer _timer = Timer(const Duration(milliseconds: 400), () async {
              var isConnect = await ConectionDetecter.isConnected();
              if (isConnect) {
                bool isMediaAdded = false;
                for (int i = 0; i < assestList.length; i++) {
                  String strAzureImageUploadPath = await uploadImgOnAzure(
                      assestList[i]
                          .file
                          .toString()
                          .replaceAll("File: ", "")
                          .replaceAll("'", "")
                          .trim(),
                      strPrefixPathforPhoto);
                  // finalList[i].file = strAzureImageUploadPath;
                  if (assestList[i].tag == "media") {
                    isMediaAdded = true;
                  }
                  finalList.add(new Assest2(
                      assestList[i].type,
                      assestList[i].tag,
                      strPrefixPathforPhoto + strAzureImageUploadPath,
                      true));
                }
                if(!isMediaAdded&&imageList.length>0){
                  finalList.add(new Assest2(
                      'image',
                     'media',
                     imageList[0],
                      true));
                }
                setState(() {
                  finalList;
                });
                apiCalling();
              } else {
                ToastWrap.showToast(
                    MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
              }
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.MAXIMUM_10_IMAGE_UPLOADED_VAL, context);
          }
        }
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  bool isOtherCategory = false;

  @override
  void initState() {
    level3Competencylist.addAll(widget.level3Competencylist);

    if (widget.level3Competencylist.length == 1) {
      competencySelected = widget.level3Competencylist[0];
      strCompetencyValue = widget.level3Competencylist[0].name;
      setState(() {
        competencySelected;
        strCompetencyValue;
      });
    }

    if (widget.strcompetencyTypeName == "Other" ||
        widget.strcompetencyTypeName == "General") {
      isOtherCategory = true;
      strCompetencyValue = widget.strcompetencyTypeName;
      otherCategory = TextEditingController(text: "");
    }
    getSharedPreferences();
    _focus.addListener(_onFocusChange);
    callApiForSaas(false);
    super.initState();
  }

  bool validationCheck() {
    if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    }
    return true;
  }

  onBack() async {
    String roleId = prefs.getString(UserPreference.ROLE_ID);
    if (roleId == "2") {
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) => DashBoardWidgetParent(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    } else {
      bloc.loadData(widget.userId, context, prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) => DashBoardWidget(
              prefs.getString(UserPreference.IS_PARENT_ROLE),
              prefs.getString(UserPreference.IS_PARTNER_ROLE),
              prefs.getString(UserPreference.IS_USER_ROLE))));
    }

    /* if (isParent) {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>  DashBoardWidgetParent(prefs.getString(UserPreference.IS_PARENT_ROLE),prefs.getString(UserPreference.IS_PARTNER_ROLE),prefs.getString(UserPreference.IS_USER_ROLE))));
    } else {
      bloc.loadData(widget.userId, context, prefs);
      Navigator.pushReplacement(
          context,
           MaterialPageRoute(
              //   builder: (context) =>  DashBoardWidget()));
              builder: (context) =>  DashBoardWidget (prefs.getString(UserPreference.IS_PARENT_ROLE),prefs.getString(UserPreference.IS_PARTNER_ROLE),prefs.getString(UserPreference.IS_USER_ROLE))));
    }*/
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    final dropdownMenuCompetency = widget.level3Competencylist
        .map((Level3Competencies item) => DropdownMenuItem<Level3Competencies>(
            value: item,
            child: Text(item.name,
                style: TextStyle(
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                ))))
        .toList();

    Padding gridSelectedImages() {
      return assestList != null && assestList.length > 0
          ? PaddingWrap.paddingfromLTRB(
              13.0,
              10.0,
              13.0,
              10.0,
              Container(
                  height: 400.0,
                  child: GridView.count(
                    primary: true,
                    scrollDirection: Axis.vertical,
                    padding: const EdgeInsets.all(5.0),
                    crossAxisCount: 3,
                    childAspectRatio: .98,
                    mainAxisSpacing: 10.0,
                    crossAxisSpacing: 3.0,
                    children: List.generate(assestList.length, (int index) {
                      return Stack(
                        children: <Widget>[
                          InkWell(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Image.file(
                                  File(assestList[index].file),
                                  fit: BoxFit.fitWidth,
                                  height: 100.0,
                                  width: 145.0,
                                )
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(bottom:10.0),
                            child: Align(
                                alignment: Alignment.center,
                                child: Container(
                                  height: 28.0,
                                  width: 28.0,
                                  color: Colors.black54.withOpacity(.4),
                                )),
                          ),
                      Padding(
                      padding: const EdgeInsets.only(bottom:10.0),
                      child:Align(
                              alignment: Alignment.center,
                              child: InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      2.0,
                                      3.0,
                                      0.0,
                                      Image.asset(
                                        "assets/newIcon/gallery_del.png",
                                        width: 22.0,
                                        height: 22.0,
                                      )),
                                  onTap: () {
                                    assestList.removeAt(index);
                                    setState(() {
                                      assestList;
                                    });
                                  }))),
                        ],
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              10.0,
              5.0,
              10.0,
              Container(
                child: Text(""),
              ));
    }

    final titleUi = PaddingWrap.paddingfromLTRB(
        13.0,
        10.0,
        13.0,
        10.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.text,
          maxLength: TextLength.USER_TITLE_MAX_LENGTH,
          focusNode: _focus,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            labelText: "Title",
            errorStyle: Util.errorTextStyle,
            counterText: "",
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide:
                    BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle: TextStyle(color: ColorValues.TEXT_LIGHT_GREY),
            fillColor: Colors.transparent,
          ),
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_TITLE_VAL : null,
          onSaved: (val) => strTitle = val.trim(),
        )));

    final competencyDropDownUi = Container(
        height: 40.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<Level3Competencies>(
                hint: Text(
                  "Competency",
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.GREY_TEXT_COLOR,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: competencySelected,
                items: dropdownMenuCompetency,
                onChanged: (Level3Competencies item) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    competencySelected = item;
                    strCompetencyValue = item.name;
                  });
                })));
    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              elevation: 0.0,
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                            Center(
                                child: Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: isOtherCategory
                        ? InkWell(
                            onTap: () {
                              editCategoryDialog(true, false, true);
                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  strCompetencyValue,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                      fontSize: 18.0,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                ),
                                Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(5.0, 0, 7, 1),
                                    child: Image.asset(
                                      "assets/newDesignIcon/userprofile/edit_grey.png",
                                      height: 16.0,
                                      width: 17.0,
                                    ))
                              ],
                            ),
                          )
                        : Text(
                            "Accomplishment",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontSize: 18.0,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          13.0,
                          0.0,
                          TextViewWrap.textView(
                              "Save",
                              TextAlign.start,
                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                              16.0,
                              FontWeight.normal)),
                      onTap: () {
                        ontapApply();
                      },
                    )
                  ],
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                Expanded(
                  child: ListView(
                    children: <Widget>[
                      Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            titleUi,
                            PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                10.0,
                                competencySelected == null || isOtherCategory
                                    ? Container(
                                        height: 6.0,
                                      )
                                    : PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                        getTextLabel(
                                            "Competency",
                                            11.0,
                                            ColorValues.GREY_TEXT_COLOR,
                                            FontWeight.normal))),
                            PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                10.0,
                                isOtherCategory
                                    ? getEditCategoryTextField(
                                        false, "Focus Area", false)
                                    : Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          /* secondLevelCompetencyController.text == ""
                            && (widget.level1Name == "Sports" || widget.level1Name == "Arts")
                            ? TextFormField(
                          keyboardType: TextInputType.text,
                          maxLength: TextLength.ACCOMPLISHMENT_TITLE_MAX_LENGTH,
                          textCapitalization: TextCapitalization.sentences,
                          cursorColor: Constant.CURSOR_COLOR,
                          controller: thirdLevelController,
                          style:  TextStyle(color:  ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          validator: (val) => val.trim().isEmpty || val.length == 0 ? MessageConstant.FIELD_REQUIRED : null,
                          decoration: BaseCommonWidget.textFormFieldDecorationAchievment("Focus Area",""), */ /*InputDecoration(
                                                                                                              contentPadding: const EdgeInsets.fromLTRB(
                                                                                                                0.0,
                                                                                                                5.0,
                                                                                                                5.0,
                                                                                                                5.0,
                                                                                                              ),
                                                                                                              counterStyle:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                              labelText: "Focus Area",
                                                                                                              errorStyle: Util.errorTextStyle,
                                                                                                              hintText: MessageConstant.FOCUS_AREA_HINT_TEXT,
                                                                                                              counterText: "",
                                                                                                              floatingLabelBehavior: FloatingLabelBehavior.always,
                                                                                                              labelStyle:  TextStyle(color:  ColorValues.GREY_TEXT_COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                              fillColor: Colors.transparent,
                                                                                                              enabledBorder: UnderlineInputBorder(
                                                                                                                borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                                                                                                              ),
                                                                                                              focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                                                                                                            ),*/ /*
                          //  ),
                        )
                            :*/
                                          competencyDropDownUi,
                                          strCompetencyValue == "Other"
                                              ? Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          top: 15.0),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      PaddingWrap.paddingfromLTRB(
                                                          0.0,
                                                          0.0,
                                                          0.0,
                                                          5.0,
                                                          getTextLabel(
                                                              "Other, please specify",
                                                              14.0,
                                                              ColorValues
                                                                  .TEXT_LIGHT_GREY,
                                                              FontWeight
                                                                  .normal)),
                                                      Container(
                                                          width:
                                                              double.infinity,
                                                          height: 30.0,
                                                          decoration: BoxDecoration(
                                                              border: Border.all(
                                                                  color: ColorValues
                                                                      .GREY__COLOR_DIVIDER)),
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                          margin:
                                                              EdgeInsets.all(
                                                                  0.0),
                                                          child: TextFormField(
                                                            keyboardType:
                                                                TextInputType
                                                                    .text,
                                                            controller:
                                                                thirdLevelController,
                                                            maxLength: 25,
                                                            cursorColor: Constant
                                                                .CURSOR_COLOR,
                                                            style: TextStyle(
                                                                color: ColorValues
                                                                    .HEADING_COLOR_EDUCATION,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                            textCapitalization:
                                                                TextCapitalization
                                                                    .sentences,
                                                            decoration:
                                                                InputDecoration(
                                                              counterText: "",
                                                              disabledBorder:
                                                                  InputBorder
                                                                      .none,
                                                              focusedBorder:
                                                                  InputBorder
                                                                      .none,
                                                              enabledBorder:
                                                                  InputBorder
                                                                      .none,
                                                              isDense: true,
                                                              // Added this
                                                              contentPadding:
                                                                  EdgeInsets.only(
                                                                      left: 5.0,
                                                                      top: 1.0,
                                                                      bottom:
                                                                          0.0),
                                                              floatingLabelBehavior:
                                                                  FloatingLabelBehavior
                                                                      .always,
                                                            ),
                                                          )),
                                                      isThirLevelField
                                                          ? Container(
                                                              height: 0.0,
                                                            )
                                                          : PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0,
                                                                  Text(
                                                                    MessageConstant
                                                                        .THIRD_LEVEL_REQUIRED,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .ERROR_COLOR,
                                                                        fontSize:
                                                                            12.0),
                                                                  ))
                                                    ],
                                                  ),
                                                )
                                              : Container(height: 0.0),
                                        ],
                                      )),

                            /* PaddingWrap.paddingfromLTRB(
                    13.0,
                    0.0,
                    13.0,
                    10.0,competencyDropDownUi),*/

                            PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                TextViewWrap.textView("Media", TextAlign.start,
                                    Colors.black, 15.0, FontWeight.bold)),
                            gridSelectedImages()
                          ],
                        ),
                      )
                    ],
                  ),
                  flex: 1,
                )
              ],
            )));
  }
}
