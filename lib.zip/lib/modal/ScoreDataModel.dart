import 'dart:io';

import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';

class ScoreDataModel {
  String sId;
  int userTestId;
  String testId;
  String userId;
  String dateTaken;
  String dateOrigionl;
  List<String> imageUrl;
  List<String> docUrl;
  String name;
  bool isProfileDisplay;
  bool isShowMore = false;
  List<Subjects> subjects;

  ScoreDataModel(
      {this.sId,
        this.userTestId,
        this.testId,
        this.userId,
        this.dateTaken,
        this.imageUrl,
        this.docUrl,
        this.name,
        this.subjects,
        this.isProfileDisplay});
}


