import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';

class PublicViewModel {
  String status;
  Result result;

  PublicViewModel({this.status, this.result});

  PublicViewModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    result =
    json['result'] != null ?   Result.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class Result {
  String sId;
  int profileId;
  String profileView;

  Result({this.sId, this.profileId, this.profileView});

  Result.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    profileId = json['profileId'];
    profileView = json['profileView'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =   Map<String, dynamic>();
    data['_id'] = this.sId;
    data['profileId'] = this.profileId;
    data['profileView'] = this.profileView;
    return data;
  }
}