import 'dart:async';

import 'package:flutter/gestures.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:readmore/readmore.dart';
import 'package:spike_view_project/TestScore/DocumentPerformance.dart';
import 'package:spike_view_project/accomplishment/portfolio/PortfolioViewWidget.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/ScoreDataModel.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/checked_container.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/disable_view.dart';
import 'package:spike_view_project/widgets/read_more_text.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/PublicProfileFilter/model/AcoomplismentDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicProfileDataModel.dart';
import 'package:spike_view_project/PublicProfileFilter/model/PublicUrlModel.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicProfilePreViewWidget.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/publishwWidget.dart';
import 'package:spike_view_project/PublicProfileFilter/user/CustomPresoViewForUser.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/FullImageView.dart';

import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/modal/SkillBarModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import '../custom_portfolio_details_view.dart';

// Create a Form Widget
class PublicProfileFilterViewWidget extends StatefulWidget {
  String dob, publicUrl, profileType, userId;
  bool isUnderThirteen = false;
  bool isParentCalling, isFirstTimeCalling;

  PublicProfileFilterViewWidget(this.userId, this.dob, this.publicUrl,
      this.profileType, this.isParentCalling, this.isFirstTimeCalling,
      {this.isUnderThirteen});

  @override
  PublicProfileFilterViewWidgetState createState() {
    return PublicProfileFilterViewWidgetState();
  }
}

class PublicProfileFilterViewWidgetState
    extends State<PublicProfileFilterViewWidget> {
  bool isTextField = true;
  TextEditingController publicUrlController = TextEditingController(text: "");
  SharedPreferences prefs;
  String userIdPref, roleId, dob, errorText = "Please enter something here.";
  PublicProfileDataModel _mPublicProfileDataModel;
  bool isShowAllTestScore = false;
  bool isShowAllRecommendation = false;

  bool isViewAllBadges = false;

  AcoomplismentDataModel _mAcoomplismentDataModel;
  ScrollController _scrollController = ScrollController();

  final PageController pageController = PageController();
  final dataKey0 = GlobalKey();
  List<double> spiderChartList = List<double>();
  List<String> spiderChartName = List<String>();
  List<SkillBarModel> barListModel = List();
  bool isSpiderChartApiCalled = true;
  bool isShowSummary = false;
  bool isGPA = false;
  bool isLinearView = true;
  bool isPresoView = false;
  int counter = 30;
  static StreamController syncDoneController = StreamController.broadcast();
  bool isVideoPlay = false;
  StreamSubscription<dynamic> _streamSubscription;

  PublicUrlModel _mPublicUrlModel;

  List<double> parseSpiderChart(map) {
    List<double> dataList = List();
    for (int i = 0; i < map.length; i++) {
      try {
        String _id = map[i]["_id"].toString();
        String importance = map[i]["importance"].toString();
        String name = map[i]["name"].toString();
        String importanceTitle = map[i]["importanceTitle"].toString();

        if (importance == null) {
          importance = "0";
        }
        // dataList.add(new SpiderChartModel(_id, importance, name, importanceTitle));
        dataList.add(double.parse(importance));
        spiderChartName.add(name);
      } catch (e) {}
    }
    return dataList;
  }

  Future spiderChart(isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_SPIDER_CHART + userIdPref + "/0/1", "get");

        if (isShowLoader) CustomProgressLoader.cancelLoader(context);
        isSpiderChartApiCalled = true;
        setState(() {
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              spiderChartList.clear();
              spiderChartName.clear();

              spiderChartList = parseSpiderChart(response.data['result']);

              print("SpiderChat+++++" + spiderChartList.length.toString());
              if (mounted) {
                if (spiderChartList.length > 0) {
                  if (spiderChartList.length < 3) {
                    if (spiderChartList.length == 1) {
                      spiderChartList.add(0);
                      spiderChartName.add("");

                      spiderChartName.add("");
                      spiderChartList.add(0);
                    } else if (spiderChartList.length == 2) {
                      spiderChartList.add(0);
                      spiderChartName.add("");
                    }
                  }
                  setState(() {
                    spiderChartList;
                    spiderChartName;
                    print(
                        "SpiderChat+++++" + spiderChartList.length.toString());
                    print("spiderChartName+++++" +
                        spiderChartName.length.toString());
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isSpiderChartApiCalled = true;
      setState(() {
        isSpiderChartApiCalled;
      });

      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future skillApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_SKILL + userIdPref, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              barListModel =
                  ParseJson.parseMapSkillListData(response.data['message']);

              setState(() {
                barListModel;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  Future getProfileDetail(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        print("ENDPOINT_PROFILE_DETAIL++++++" +
            Constant.ENDPOINT_PROFILE_DETAIL +
            userIdPref +
            "&roleId=" +
            roleId +
            "&profileType=" +
            widget.profileType +
            "&viewType=filterview&parentId=&isunder13=" +
            widget.isUnderThirteen.toString());

        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PROFILE_DETAIL +
                userIdPref +
                "&roleId=" +
                roleId +
                "&profileType=" +
                widget.profileType +
                "&viewType=filterview&parentId=&isunder13=" +
                widget.isUnderThirteen.toString(),
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PROFILE_DETAIL++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS] == "Success") {
              Result.type = "public";
              _mPublicProfileDataModel =
                  PublicProfileDataModel.fromJson(response.data);
              try {
                _mPublicProfileDataModel.result.loveOtherInterests = List();
                if (_mPublicProfileDataModel.result.loveInterests != null &&
                    _mPublicProfileDataModel.result.loveInterests.length > 0)
                  _mPublicProfileDataModel.result.loveOtherInterests
                      .addAll(_mPublicProfileDataModel.result.loveInterests);
                if (_mPublicProfileDataModel.result.otherInterests != null &&
                    _mPublicProfileDataModel.result.otherInterests.length > 0)
                  _mPublicProfileDataModel.result.loveOtherInterests
                      .addAll(_mPublicProfileDataModel.result.otherInterests);

                print(
                    "apurva _mPublicProfileDataModel show email:::: ${_mPublicProfileDataModel.result.isDisplaySocialEmail}");

                if (_mPublicProfileDataModel.result.isGpa.toString() ==
                    "true") {
                  setState(() {
                    isGPA = true;
                  });
                } else if (_mPublicProfileDataModel.result.isGpa.toString() ==
                    "false") {
                  setState(() {
                    isGPA = false;
                  });
                }

                if (_mPublicProfileDataModel.result.profileView == "Linear") {
                  setState(() {
                    isLinearView = true;
                    isPresoView = false;
                  });
                } else if (_mPublicProfileDataModel.result.profileView ==
                    "Preso") {
                  setState(() {
                    isLinearView = false;
                    isPresoView = true;
                  });
                }
              } catch (e) {}
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      print("getProfileDetail_INFO++++" + e.toString());
    }
  }

  Future getAccomplishment(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        print("call+++" +
            Constant.ENDPOINT_ACCOMPLISHMENT_DETAIL +
            userIdPref +
            "&roleId=" +
            roleId +
            "&profileType=" +
            widget.profileType +
            "&viewType=filterview&parentId=&isunder13=" +
            widget.isUnderThirteen.toString());
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_ACCOMPLISHMENT_DETAIL +
                userIdPref +
                "&roleId=" +
                roleId +
                "&profileType=" +
                widget.profileType +
                "&viewType=filterview&parentId=&isunder13=" +
                widget.isUnderThirteen.toString(),
            "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("getAccomplishment++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS].toString() ==
                "Success") {
              Achievement.callingType = "public";
              _mAcoomplismentDataModel =
                  AcoomplismentDataModel.fromJson(response.data, "");

              if (!_mPublicProfileDataModel.result.isAccomplishment) {
                setToggelAccomplishment(false);
              }

              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      print("getAccomplishment++++" + e.toString());
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    dob = prefs.getString(UserPreference.DOB);
    roleId = "1";
    if (widget.userId != null &&
        widget.userId != "null" &&
        widget.userId != "") {
      userIdPref = widget.userId;
    }
    CustomProgressLoader.showLoader(context);
    await spiderChart(false);
    await skillApi(false);
    await getProfileDetail(false);
    await getAccomplishment(false);
    CustomProgressLoader.cancelLoader(context);
  }

  @override
  void initState() {
    getSharedPreferences();
    _streamSubscription =
        VideoPlayPauseState.syncDoneController.stream.listen((value) {
      setState(() {
        isVideoPlay = false;
      });
    });
    super.initState();
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  Widget introductionViewUI() {
    String videoThumbnailUrl =
        _mPublicProfileDataModel?.result?.introVideo?.thumbnailUrl ?? '';
    String videoUrl =
        _mPublicProfileDataModel?.result?.introVideo?.videoUrl ?? '';

    return _mPublicProfileDataModel.result == null ||
            _mPublicProfileDataModel.result.introVideo == null ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == null ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == "null" ||
            _mPublicProfileDataModel.result.introVideo.videoUrl == ""
        ? const SizedBox.shrink()
        : PaddingWrap.paddingfromLTRB(
            0.0,
            24.0,
            0.0,
            0.0,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: BaseText(
                        text: 'Introduction',
                        textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoMedium,
                        fontWeight: FontWeight.w600,
                        fontSize: 18,
                        maxLines: 1,
                      ),
                    ),
                  ],
                ),
                Container(
                  height: 200,
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(10)),
                  clipBehavior: Clip.antiAlias,
                  margin: const EdgeInsets.only(top: 14),
                  child: isVideoPlay ?? false
                      ? VideoPlayPause(
                          _mPublicProfileDataModel.result.introVideo.videoUrl,
                          "",
                          true,
                          pageName: "profile",
                        )
                      : Container(
                          color: Colors.black,
                          child: Stack(
                            children: [
                              videoThumbnailUrl?.isNotEmpty ?? false
                                  ? CachedNetworkImage(
                                      height: 200,
                                      width: double.infinity,
                                      imageUrl: videoThumbnailUrl
                                                  .toLowerCase()
                                                  .contains("http") ||
                                              videoThumbnailUrl
                                                  .toLowerCase()
                                                  .contains("www.")
                                          ? videoThumbnailUrl
                                          : "${Constant.IMAGE_PATH}$videoThumbnailUrl",
                                      fit: BoxFit.contain,
                                      placeholder: (context, url) =>
                                          Util.loader(context, ""),
                                      errorWidget: (context, url, error) =>
                                          Util.error(""),
                                    )
                                  : const SizedBox.shrink(),
                              Center(
                                child: InkWell(
                                  onTap: () {
                                    if (videoUrl
                                            .toLowerCase()
                                            .contains("http") ||
                                        videoUrl
                                            .toLowerCase()
                                            .contains("www.")) {
                                      if (videoUrl
                                          .toLowerCase()
                                          .contains("http")) {
                                        launch(videoUrl);
                                      } else {
                                        String url = "http://" + videoUrl;
                                        launch(url);
                                      }
                                    } else {
                                      setState(() {
                                        isVideoPlay = true;
                                      });
                                    }
                                  },
                                  child: Image.asset(
                                    'assets/ic_intro_play.png',
                                    height: 40,
                                    width: 40,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                )
              ],
            ),
          );
  }

  Widget _hideShowButton({
    @required bool value,
    @required Function(bool value) onChange,
  }) {
    return value
        ? GestureDetector(
            onHorizontalDragEnd: (details) => onChange(false),
            onTap: () => onChange(false),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Transform.translate(
                  offset: Offset(0, -2),
                  child: BaseText(
                    text: 'Show',
                    textColor: AppConstants.colorStyle.darkBlue,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 8),
                Image.asset(
                  "assets/newDesignIcon/icon/active.png",
                  width: 32,
                  height: 16,
                ),
              ],
            ),
          )
        : GestureDetector(
            onHorizontalDragEnd: (details) => onChange(true),
            onTap: () => onChange(true),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Transform.translate(
                  offset: Offset(0, -2),
                  child: BaseText(
                    text: 'Show',
                    textColor: AppConstants.colorStyle.darkBlue,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w400,
                    fontSize: 14,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 10),
                Image.asset(
                  "assets/newDesignIcon/icon/inactive.png",
                  width: 32,
                  height: 16,
                ),
              ],
            ),
          );
  }

  void conformationForBack() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    "Are you sure, want to leave public profile settings without publishing the URL.",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  Widget summaryView() {
    return Padding(
      padding: const EdgeInsets.only(top: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: ColorValues.LIST_BOTTOM_BG,
              borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(10.0),
                  topRight: const Radius.circular(10.0)),
            ),
            child: Row(
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    6.0,
                    10.0,
                    10.0,
                    10.0,
                    Image.asset(
                      "assets/newDesignIcon/icon/my_summary.png",
                      width: 35,
                      height: 35,
                    )),
                PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    10.0,
                    BaseText(
                      text: 'Summary',
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoMedium,
                      fontWeight: FontWeight.w600,
                      fontSize: 18,
                      maxLines: 1,
                    )),
              ],
            ),
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              color: ColorValues.SELECTION_BG,
              borderRadius: new BorderRadius.only(
                  bottomLeft: const Radius.circular(10.0),
                  bottomRight: const Radius.circular(10.0)),
            ),
            child: PaddingWrap.paddingfromLTRB(
                17.0,
                12.0,
                17.0,
                12.0,
                Text(
                    _mPublicProfileDataModel.result == null ||
                            _mPublicProfileDataModel.result.summary == null ||
                            _mPublicProfileDataModel.result.summary == "null"
                        ? "No Information Available"
                        : _mPublicProfileDataModel.result.summary,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 100,
                    style: TextStyle(
                        fontFamily: Constant.latoMedium,
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontWeight: FontWeight.w500,
                        fontSize: 16.0))),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final bottomBar = BottomAppBar(
      elevation: 15.0,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(color: ColorValues.BORDER_COLOR, width: 0.5),
              )),
          height: 45,
          child: InkWell(
            child: Container(
              height: 45,
              decoration: BoxDecoration(
                color: AppConstants.colorStyle.lightBlue,
                borderRadius: BorderRadius.circular(10),
              ),
              alignment: Alignment.center,
              child: Text(
                "Preview & Save",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: ColorValues.WHITE,
                  fontFamily: AppConstants.stringConstant.latoRegular,
                  fontSize: 18,
                ),
              ),
            ),
            onTap: () {
              if (widget.profileType == "Connected") {
                apiCalling(false);
              } else {
                if (widget.publicUrl == null ||
                    widget.publicUrl == "null" ||
                    widget.publicUrl == "") {
                  if (publicUrlController.text.toString().trim().length >= 4) {
                    if (ValidationChecks.isPublicUrlName(
                        publicUrlController.text.toString().trim())) {
                      apiCallForPublicURL();
                    } else {
                      errorText =
                          "Username name can only contain alphaNumeric.";
                      isTextField = false;
                      setState(() {});
                    }
                  } else {
                    errorText = "Username must have a minimum of 4 characters.";
                    isTextField = false;
                    setState(() {});
                  }
                } else {
                  apiCalling(false);
                }
              }
            },
          ),
        ),
      ),
    );

    final bottomBar2 = BottomAppBar(
      elevation: 15.0,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Container(
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                top: BorderSide(color: ColorValues.BORDER_COLOR, width: 0.5),
              )),
          height: 45,
          child: InkWell(
            child: Container(
              height: 45,
              decoration: BoxDecoration(
                color: AppConstants.colorStyle.lightBlue,
                borderRadius: BorderRadius.circular(10),
              ),
              alignment: Alignment.center,
              child: Text(
                "Send for approval",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: ColorValues.WHITE,
                  fontFamily: AppConstants.stringConstant.latoRegular,
                  fontSize: 18,
                ),
              ),
            ),
            onTap: () {
              apiCalling(true);
            },
          ),
        ),
      ),
    );

    return WillPopScope(
      onWillPop: () {
        if (widget.profileType != "Connected") {
          conformationForBack();
        } else {
          Navigator.pop(context);
        }
        return Future.value(false);
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          titleSpacing: 0.0,
          brightness: Brightness.light,
          leading: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: IconButton(
                icon: Image.asset(
                  "assets/newDesignIcon/icon/back_icon.png",
                  height: 32.0,
                  width: 32.0,
                  fit: BoxFit.fill,
                ),
                onPressed: () {
                  Navigator.pop(context);
                }),
          ),
          backgroundColor: Colors.white,
          elevation: 0.0,
        ),
        bottomNavigationBar: widget.isUnderThirteen & (!widget.isParentCalling)
            ? bottomBar2
            : bottomBar,
        backgroundColor: Colors.white,
        body: Container(
          color: Colors.white,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            shrinkWrap: true,
            children: [
              const SizedBox(height: 2),
              BaseText(
                text: 'Configure profile',
                textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                fontFamily: AppConstants.stringConstant.latoMedium,
                fontWeight: FontWeight.w700,
                fontSize: 28,
                maxLines: 1,
              ),
              widget.profileType == "Connected"
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _mPublicProfileDataModel != null &&
                                _mPublicProfileDataModel.result != null &&
                                (!_mPublicProfileDataModel.result.isActive) &&
                                widget.isUnderThirteen &
                                    (!widget.isParentCalling)
                            ? Container(
                                color: Colors.black,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.fromLTRB(0, 5, 0, 10),
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Expanded(
                                        child: PaddingWrap.paddingfromLTRB(
                                            13.0,
                                            0.0,
                                            10.0,
                                            0.0,
                                            Image.asset(
                                              "assets/newIcon/infowhite.png",
                                              height: 20.0,
                                              width: 20.0,
                                            )),
                                        flex: 0,
                                      ),
                                      Expanded(
                                        child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0.0, 0, 13, 0),
                                            child: RichText(
                                              maxLines: 10,
                                              textAlign: TextAlign.start,
                                              text: TextSpan(
                                                text:
                                                    'Parent approval pending on your profile configuration request.',
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 14.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                                children: <TextSpan>[
                                                  TextSpan(
                                                      text: ' Resend request.',
                                                      recognizer:
                                                          TapGestureRecognizer()
                                                            ..onTap = () {
                                                              apiCallingResend();
                                                            },
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .BLUE_COLOR_BOTTOMBAR,
                                                          fontSize: 14.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR)),
                                                ],
                                              ),
                                            )),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : const SizedBox.shrink(),
                        Padding(
                            padding: const EdgeInsets.fromLTRB(0, 4, 0, 0),
                            child: Text(
                                "Configure a view of the profile that is visible to your connections. If you are under 13 your parent approval will be required.",
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color(0xff455276),
                                    fontFamily: Constant.latoRegular))),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        widget.publicUrl == "null" ||
                                widget.publicUrl == "" ||
                                widget.publicUrl == null
                            ? customUrlUI()
                            : const SizedBox.shrink(),
                        linkExpireUI()
                      ],
                    ),
              widget.profileType == "Connected"
                  ? const SizedBox.shrink()
                  : TextViewWrap.textViewMultiLine(
                      "Use the toggles below and customize the view of the profile you want to share publicly.",
                      TextAlign.start,
                      ColorValues.GREY_TEXT_COLOR,
                      14.0,
                      FontWeight.normal,
                      3),
              _mPublicProfileDataModel == null ||
                      _mPublicProfileDataModel.result == null
                  ? const SizedBox.shrink()
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        introductionViewUI(),
                        _mPublicProfileDataModel.result == null ||
                                _mPublicProfileDataModel.result.summary ==
                                    null ||
                                _mPublicProfileDataModel.result.summary
                                        .trim() ==
                                    "" ||
                                _mPublicProfileDataModel.result.summary ==
                                    "null"
                            ? const SizedBox.shrink()
                            : summaryView(),
                        _mPublicProfileDataModel.result.educations == null ||
                                _mPublicProfileDataModel
                                            .result.educations.colleges.length +
                                        _mPublicProfileDataModel
                                            .result.educations.schools.length ==
                                    0
                            ? const SizedBox.shrink()
                            : Padding(
                                padding: const EdgeInsets.fromLTRB(0, 24, 0, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Container(
                                      decoration: BoxDecoration(
                                        color: ColorValues.LIST_BOTTOM_BG,
                                        borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0)),
                                      ),
                                      child: Row(
                                        children: [
                                          PaddingWrap.paddingfromLTRB(
                                              6.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Image.asset(
                                                "assets/png/education.png",
                                                width: 35,
                                                height: 35,
                                              )),
                                          Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                10.0,
                                                BaseText(
                                                  text: 'Education',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18,
                                                  maxLines: 1,
                                                )),
                                          ),
                                          _hideShowButton(
                                              value: _mPublicProfileDataModel
                                                  .result.isEducations,
                                              onChange: (value) {
                                                setState(() {
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .isEducations = value;
                                                  setToggel(
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .colleges,
                                                      value);
                                                });
                                              }),
                                          const SizedBox(width: 12),
                                        ],
                                      ),
                                    ),
                                    DisableView(
                                      isEnable: _mPublicProfileDataModel
                                          .result.isEducations,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: ColorValues.SELECTION_BG,
                                          borderRadius: new BorderRadius.only(
                                              bottomLeft:
                                                  const Radius.circular(10.0),
                                              bottomRight:
                                                  const Radius.circular(10.0)),
                                        ),
                                        child: Column(
                                          children: [
                                            Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 10, 0, 0),
                                              child: Row(
                                                children: [
                                                  isGPA
                                                      ? Expanded(
                                                          child: InkWell(
                                                              onTap: () {
                                                                setState(() {
                                                                  isGPA = false;
                                                                });
                                                              },
                                                              child: Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          13.0,
                                                                          0.0,
                                                                          13.0,
                                                                          0.0),
                                                                  child: Image
                                                                      .asset(
                                                                    "assets/newDesignIcon/icon/checked_box.png",
                                                                    height:
                                                                        22.0,
                                                                    width: 22.0,
                                                                  ))),
                                                          flex: 0)
                                                      : Expanded(
                                                          child: InkWell(
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        13.0,
                                                                        0.0,
                                                                        13.0,
                                                                        0.0),
                                                                child:
                                                                    Image.asset(
                                                                  "assets/newDesignIcon/icon/uncheked_box.png",
                                                                  height: 22.0,
                                                                  width: 22.0,
                                                                )),
                                                            onTap: () {
                                                              setState(() {
                                                                isGPA = true;
                                                              });
                                                              if (widget
                                                                      .profileType ==
                                                                  "Connected") {
                                                                conformationDialog(

                                                                    "Your connections will be able to see your GPA. Uncheck to hide from your profile.",
                                                                    context);
                                                              }
                                                            },
                                                          ),
                                                          flex: 0),
                                                  Expanded(
                                                      flex: 1,
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              BaseText(
                                                                text:
                                                                    'Show GPA with my education',
                                                                textColor:
                                                                    ColorValues
                                                                        .call_now_color,
                                                                fontFamily: AppConstants
                                                                    .stringConstant
                                                                    .latoMedium,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                fontSize: 14,
                                                                maxLines: 2,
                                                              )))
                                                ],
                                              ),
                                            ),
                                            _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .schools !=
                                                        null &&
                                                    _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .schools
                                                            .length >
                                                        0
                                                ? Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: List.generate(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .schools
                                                            .length,
                                                        (int index) {
                                                      return getSchoolEducationListItem22(
                                                          index);
                                                    }))
                                                : Container(),
                                            _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges !=
                                                        null &&
                                                    _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges
                                                            .length >
                                                        0
                                                ? Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: List.generate(
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges
                                                            .length,
                                                        (int index) {
                                                      return getCollegeEducationListItem22(
                                                          index);
                                                    }),
                                                  )
                                                : Container(),
                                            _mPublicProfileDataModel
                                                        .result.educations ==
                                                    null
                                                ? SizedBox()
                                                : Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            12.0),
                                                    child: InkWell(
                                                      onTap: () {
                                                        Util.onTapViewTimeLine(
                                                            context,'custom');
                                                      },
                                                      child: Center(
                                                        child: BaseText(
                                                          text: 'View timeline',
                                                          textColor:
                                                              Color(0xff4684EB),
                                                          fontFamily:
                                                              AppConstants
                                                                  .stringConstant
                                                                  .latoRegular,
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                        _mPublicProfileDataModel.result.testScores == null ||
                                _mPublicProfileDataModel
                                        .result.testScores.length ==
                                    0
                            ? const SizedBox.shrink()
                            : PaddingWrap.paddingfromLTRB(
                                0.0,
                                24.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      decoration: BoxDecoration(
                                        color: ColorValues.LIST_BOTTOM_BG,
                                        borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0)),
                                      ),
                                      child: Row(
                                        children: <Widget>[
                                          PaddingWrap.paddingfromLTRB(
                                              6.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Image.asset(
                                                "assets/newDesignIcon/icon/test_score.png",
                                                width: 35,
                                                height: 35,
                                              )),
                                          Expanded(
                                            child: BaseText(
                                              text: 'Test Score',
                                              textColor: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoMedium,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18,
                                              maxLines: 1,
                                            ),
                                          ),
                                          _hideShowButton(
                                              value: _mPublicProfileDataModel
                                                  .result.isTestScore,
                                              onChange: (value) {
                                                setState(() {
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .isTestScore = value;
                                                  setToggeltestScore(value);
                                                });
                                              }),
                                          const SizedBox(width: 12),
                                        ],
                                      ),
                                    ),
                                    DisableView(
                                      isEnable: _mPublicProfileDataModel
                                          .result.isTestScore,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: ColorValues.SELECTION_BG,
                                          borderRadius: new BorderRadius.only(
                                              bottomLeft:
                                                  const Radius.circular(10.0),
                                              bottomRight:
                                                  const Radius.circular(10.0)),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(
                                              0.0, 12, 0, 12),
                                          child: Column(children: <Widget>[
                                            PaddingWrap.paddingfromLTRB(
                                                12.0,
                                                0.0,
                                                12.0,
                                                0.0,
                                                BaseText(
                                                  text:
                                                      "Your test scores remain private and are not visible to any of you connections. If you want to share them, please select them during the ‘Filter’ step.",
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoRegular,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 12,
                                                )),
                                            Column(
                                              children: List.generate(
                                                  _mPublicProfileDataModel
                                                              .result
                                                              .testScores
                                                              .length >
                                                          2
                                                      ? isShowAllTestScore
                                                          ? _mPublicProfileDataModel
                                                              .result
                                                              .testScores
                                                              .length
                                                          : 2
                                                      : _mPublicProfileDataModel
                                                          .result
                                                          .testScores
                                                          .length, (int index) {
                                                return getTestScoreListItem(
                                                    index);
                                              }),
                                            ),
                                            _mPublicProfileDataModel.result
                                                        .testScores.length >
                                                    2
                                                ? PaddingWrap.paddingfromLTRB(
                                                    5.0,
                                                    12.0,
                                                    5.0,
                                                    6.0,
                                                    Center(
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        10),
                                                            border: Border.all(
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR)),
                                                        height: 30.0,
                                                        width:
                                                            isShowAllTestScore
                                                                ? 120.0
                                                                : 90,
                                                        child: FlatButton(
                                                            onPressed: () {
                                                              if (isShowAllTestScore) {
                                                                isShowAllTestScore =
                                                                    false;
                                                              } else {
                                                                isShowAllTestScore =
                                                                    true;
                                                              }
                                                              setState(() {});
                                                            },
                                                            child: Text(
                                                                isShowAllTestScore
                                                                    ? "View less"
                                                                    : "View all",
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .BLUE_COLOR_BOTTOMBAR,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR,
                                                                    fontSize:
                                                                        14.0))),
                                                      ),
                                                    ))
                                                : Container(
                                                    height: 0.0,
                                                  ),
                                          ]),
                                        ),
                                      ),
                                    ),
                                  ],
                                )),
                        _mAcoomplismentDataModel == null ||
                                _mAcoomplismentDataModel
                                        .accomplimentData.length ==
                                    0
                            ? const SizedBox.shrink()
                            : Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const SizedBox(height: 24),
                                  Container(
                                    decoration: BoxDecoration(
                                      color: ColorValues.LIST_BOTTOM_BG,
                                      borderRadius: new BorderRadius.all(
                                          const Radius.circular(10.0)),
                                    ),
                                    child: Row(
                                      children: [
                                        PaddingWrap.paddingfromLTRB(
                                            6.0,
                                            10.0,
                                            10.0,
                                            10.0,
                                            Image.asset(
                                              "assets/experience/ic_experience.png",
                                              width: 35,
                                              height: 35,
                                            )),
                                        Expanded(
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              10.0,
                                              0.0,
                                              10.0,
                                              BaseText(
                                                text: 'Experiences',
                                                textColor: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 18,
                                                maxLines: 1,
                                              )),
                                        ),
                                        _hideShowButton(
                                            value: _mPublicProfileDataModel
                                                .result.isAccomplishment,
                                            onChange: (value) {
                                              setState(() {
                                                _mPublicProfileDataModel.result
                                                    .isAccomplishment = value;
                                                setToggelAccomplishment(value);
                                              });
                                            }),
                                        const SizedBox(width: 12),
                                      ],
                                    ),
                                  ),
                                  DisableView(
                                    isEnable: _mPublicProfileDataModel
                                        .result.isAccomplishment,
                                    child: ListView.separated(
                                      itemBuilder: (_, index) => _storyItem(
                                          _mAcoomplismentDataModel
                                              .accomplimentData[index],
                                          index),
                                      separatorBuilder: (_, index) =>
                                          const SizedBox(height: 24),
                                      itemCount: _mAcoomplismentDataModel
                                              .accomplimentData?.length ??
                                          0,
                                      shrinkWrap: true,
                                      padding: const EdgeInsets.only(top: 24),
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                    ),
                                  ),
                                ],
                              ),
                        _mPublicProfileDataModel.result.loveInterests.length >
                                    0 ||
                                _mPublicProfileDataModel
                                        .result.goalInterests.length >
                                    0
                            ? getUserInterestAndGoals()
                            : const SizedBox.shrink(),
                        _mPublicProfileDataModel.result.skills.length == 0 &&
                                _mPublicProfileDataModel
                                        .result.certificates.length ==
                                    0
                            ? const SizedBox.shrink()
                            : skillView(),
                        _mPublicProfileDataModel.result.badges == null ||
                                _mPublicProfileDataModel
                                        .result.badges.collections.length ==
                                    0 ||
                                (_mPublicProfileDataModel
                                        .result.badges.collections.length ==
                                    0)
                            ? const SizedBox.shrink()
                            : Padding(
                                padding: const EdgeInsets.fromLTRB(0, 24, 0, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Container(
                                      decoration: BoxDecoration(
                                        color: ColorValues.LIST_BOTTOM_BG,
                                        borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0)),
                                      ),
                                      child: Row(
                                        children: [
                                          PaddingWrap.paddingfromLTRB(
                                              6.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Image.asset(
                                                "assets/newDesignIcon/icon/badges_icon.png",
                                                width: 35,
                                                height: 35,
                                              )),
                                          Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                10.0,
                                                BaseText(
                                                  text: 'Badges',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18,
                                                  maxLines: 1,
                                                )),
                                          ),
                                          _hideShowButton(
                                              value: _mPublicProfileDataModel
                                                  .result.isBadges,
                                              onChange: (value) {
                                                setState(() {
                                                  setToggel(
                                                      _mPublicProfileDataModel
                                                          .result
                                                          .badges
                                                          .collections,
                                                      value);

                                                  _mPublicProfileDataModel
                                                      .result.isBadges = value;
                                                });
                                              }),
                                          const SizedBox(width: 12),
                                        ],
                                      ),
                                    ),
                                    DisableView(
                                      isEnable: _mPublicProfileDataModel
                                          .result.isBadges,
                                      child: badgeList2(),
                                    ),
                                  ],
                                ),
                              ),
                        _mPublicProfileDataModel.result == null ||
                                _mPublicProfileDataModel
                                        .result.recommendations ==
                                    null ||
                                _mPublicProfileDataModel
                                        .result.recommendations.length ==
                                    0
                            ? const SizedBox.shrink()
                            : getRecommendation(),
                        (!dobCheck(widget.dob))
                            ? const SizedBox.shrink()
                            : PaddingWrap.paddingfromLTRB(
                                0.0,
                                24.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        color: ColorValues.LIST_BOTTOM_BG,
                                        borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0)),
                                      ),
                                      child: Row(
                                        children: [
                                          PaddingWrap.paddingfromLTRB(
                                              6.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Image.asset(
                                                "assets/newDesignIcon/icon/my_contact_info.png",
                                                width: 35,
                                                height: 35,
                                              )),
                                          Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                10.0,
                                                BaseText(
                                                  text: 'Contact information',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18,
                                                  maxLines: 1,
                                                )),
                                          ),
                                          _hideShowButton(
                                              value: _mPublicProfileDataModel
                                                  .result.isDisplaySocialEmail,
                                              onChange: (value) {
                                                setState(() {
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .isDisplaySocialEmail =
                                                      value;
                                                });
                                                if (value) {
                                                  conformationDialog(
                                                      "Your connections will be able to see your Contact Info. Uncheck to hide from profile.",
                                                      context);
                                                }
                                              }),
                                          const SizedBox(width: 12),
                                        ],
                                      ),
                                    ),
                                    DisableView(
                                      isEnable: _mPublicProfileDataModel
                                          .result.isDisplaySocialEmail,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: ColorValues.SELECTION_BG,
                                          borderRadius: new BorderRadius.only(
                                              bottomLeft:
                                                  const Radius.circular(10.0),
                                              bottomRight:
                                                  const Radius.circular(10.0)),
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      12.0, 0, 13, 13),
                                              child: Container(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              Image.asset(
                                                                "assets/newDesignIcon/userprofile/Mail.png",
                                                                height: 20.0,
                                                                width: 20.0,
                                                              )),
                                                      flex: 0,
                                                    ),
                                                    Expanded(
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              10.0,
                                                              10.0,
                                                              0.0,
                                                              10.0,
                                                              BaseText(
                                                                text:
                                                                    _mPublicProfileDataModel
                                                                        .result
                                                                        .email,
                                                                textColor:
                                                                    ColorValues
                                                                        .HEADING_COLOR_EDUCATION_1,
                                                                fontFamily: AppConstants
                                                                    .stringConstant
                                                                    .latoMedium,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                                fontSize: 16,
                                                                maxLines: 1,
                                                              )),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                )),
                        _mPublicProfileDataModel.result == null ||
                                _mPublicProfileDataModel.result.socialLinks ==
                                    null ||
                                _mPublicProfileDataModel
                                        .result.socialLinks.length ==
                                    0
                            ? const SizedBox.shrink()
                            : PaddingWrap.paddingfromLTRB(
                                0.0,
                                24.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        color: ColorValues.LIST_BOTTOM_BG,
                                        borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0)),
                                      ),
                                      child: Row(
                                        children: [
                                          PaddingWrap.paddingfromLTRB(
                                              6.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Image.asset(
                                                "assets/newDesignIcon/icon/social_links.png",
                                                width: 35,
                                                height: 35,
                                              )),
                                          Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                10.0,
                                                BaseText(
                                                  text: 'Social Links',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18,
                                                  maxLines: 1,
                                                )),
                                          ),
                                          _hideShowButton(
                                              value: _mPublicProfileDataModel
                                                  .result.isSocialLinks,
                                              onChange: (value) {
                                                setState(() {
                                                  setToggel(
                                                      _mPublicProfileDataModel
                                                          .result.socialLinks,
                                                      value);

                                                  _mPublicProfileDataModel
                                                      .result
                                                      .isSocialLinks = value;
                                                });
                                              }),
                                          const SizedBox(width: 12),
                                        ],
                                      ),
                                    ),
                                    DisableView(
                                      isEnable: _mPublicProfileDataModel
                                          .result.isSocialLinks,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: ColorValues.SELECTION_BG,
                                          borderRadius: new BorderRadius.only(
                                              bottomLeft:
                                                  const Radius.circular(10.0),
                                              bottomRight:
                                                  const Radius.circular(10.0)),
                                        ),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: List.generate(
                                              _mPublicProfileDataModel
                                                  .result
                                                  .socialLinks
                                                  .length, (int index) {
                                            return Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 7, 0, 7),
                                              child: Row(
                                                children: [
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .socialLinks[index]
                                                          .isProfileDisplay
                                                      ? Expanded(
                                                          child: InkWell(
                                                              onTap: () {
                                                                setState(() {
                                                                  _mPublicProfileDataModel
                                                                      .result
                                                                      .socialLinks[
                                                                          index]
                                                                      .isProfileDisplay = false;
                                                                  updateSocialToggel();
                                                                });
                                                              },
                                                              child: Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          13.0,
                                                                          5.0,
                                                                          13.0,
                                                                          5.0),
                                                                  child: Image
                                                                      .asset(
                                                                    "assets/newDesignIcon/icon/checked_box.png",
                                                                    height:
                                                                        22.0,
                                                                    width: 22.0,
                                                                  ))),
                                                          flex: 0)
                                                      : Expanded(
                                                          child: InkWell(
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        13.0,
                                                                        5.0,
                                                                        13.0,
                                                                        5.0),
                                                                child:
                                                                    Image.asset(
                                                                  "assets/newDesignIcon/icon/uncheked_box.png",
                                                                  height: 22.0,
                                                                  width: 22.0,
                                                                )),
                                                            onTap: () {
                                                              setState(() {
                                                                _mPublicProfileDataModel
                                                                    .result
                                                                    .socialLinks[
                                                                        index]
                                                                    .isProfileDisplay = true;

                                                                _mPublicProfileDataModel
                                                                        .result
                                                                        .isSocialLinks =
                                                                    true;
                                                              });
                                                            },
                                                          ),
                                                          flex: 0),
                                                  Expanded(
                                                      flex: 0,
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0, 4, 4, 4),
                                                        child: ClipOval(
                                                          child: Container(
                                                            child: FadeInImage
                                                                .assetNetwork(
                                                              fit: BoxFit.fill,
                                                              placeholder:
                                                                  'assets/profile/img_default.png',
                                                              image: Constant
                                                                      .IMAGE_PATH +
                                                                  _mPublicProfileDataModel
                                                                      .result
                                                                      .socialLinks[
                                                                          index]
                                                                      .image,
                                                              height: 40.0,
                                                              width: 40.0,
                                                            ),
                                                          ),
                                                        ),
                                                      )),
                                                  Expanded(
                                                      flex: 1,
                                                      child: PaddingWrap
                                                          .paddingfromLTRB(
                                                              11.0,
                                                              0.0,
                                                              0.0,
                                                              0.0,
                                                              BaseText(
                                                                text: _mPublicProfileDataModel
                                                                    .result
                                                                    .socialLinks[
                                                                        index]
                                                                    .socialName,
                                                                textColor:
                                                                    ColorValues
                                                                        .TEXT_COLOR,
                                                                fontFamily: AppConstants
                                                                    .stringConstant
                                                                    .latoMedium,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                                fontSize: 16,
                                                                textAlign:
                                                                    TextAlign
                                                                        .start,
                                                                maxLines: 2,
                                                              )))
                                                ],
                                              ),
                                            );
                                          }),
                                        ),
                                      ),
                                    ),
                                  ],
                                )),
                        _mPublicProfileDataModel.result.resume != null &&
                                _mPublicProfileDataModel
                                        .result.resume.displayName !=
                                    "null" &&
                                _mPublicProfileDataModel
                                        .result.resume.displayName !=
                                    ""
                            ? PaddingWrap.paddingfromLTRB(
                                0.0,
                                24.0,
                                0.0,
                                0.0,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        color: ColorValues.LIST_BOTTOM_BG,
                                        borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(10.0),
                                            topRight:
                                                const Radius.circular(10.0)),
                                      ),
                                      child: Row(
                                        children: [
                                          PaddingWrap.paddingfromLTRB(
                                              6.0,
                                              10.0,
                                              10.0,
                                              10.0,
                                              Image.asset(
                                                "assets/profile/skills/ic_resume.png",
                                                width: 35,
                                                height: 35,
                                              )),
                                          Expanded(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                10.0,
                                                0.0,
                                                10.0,
                                                BaseText(
                                                  text: 'Resume',
                                                  textColor: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily: AppConstants
                                                      .stringConstant
                                                      .latoMedium,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18,
                                                  maxLines: 1,
                                                )),
                                          ),
                                          _hideShowButton(
                                              value: _mPublicProfileDataModel
                                                  .result.isResume,
                                              onChange: (value) {
                                                setState(() {
                                                  _mPublicProfileDataModel
                                                      .result.isResume = value;
                                                });
                                              }),
                                          const SizedBox(width: 12),
                                        ],
                                      ),
                                    ),
                                    DisableView(
                                      isEnable: _mPublicProfileDataModel
                                          .result.isResume,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0.0, 0, 0, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: ColorValues.SELECTION_BG,
                                                borderRadius: new BorderRadius
                                                        .only(
                                                    bottomLeft:
                                                        const Radius.circular(
                                                            10.0),
                                                    bottomRight:
                                                        const Radius.circular(
                                                            10.0)),
                                              ),
                                              child: Row(
                                                children: [
                                                  Expanded(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            10.0,
                                                            10.0,
                                                            0.0,
                                                            10.0,
                                                            Image.asset(
                                                              "assets/newDesignIcon/icon/pdf_icon.png",
                                                              height: 33.0,
                                                              width: 33.0,
                                                            )),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        PaddingWrap
                                                            .paddingfromLTRB(
                                                                10.0,
                                                                5.0,
                                                                5.0,
                                                                10.0,
                                                                InkWell(
                                                                    onTap: () {
                                                                      Util.launchUrl(
                                                                          _mPublicProfileDataModel
                                                                              .result
                                                                              .resume
                                                                              .uploadType,
                                                                          _mPublicProfileDataModel
                                                                              .result
                                                                              .resume
                                                                              .resumeUrl);
                                                                    },
                                                                    child: Text(
                                                                      _mPublicProfileDataModel
                                                                          .result
                                                                          .resume
                                                                          .displayName,
                                                                      maxLines:
                                                                          1,
                                                                      style: TextStyle(
                                                                          fontWeight: FontWeight
                                                                              .normal,
                                                                          color: ColorValues
                                                                              .BLUE_COLOR_BOTTOMBAR,
                                                                          fontFamily: Constant
                                                                              .TYPE_CUSTOMREGULAR,
                                                                          fontSize:
                                                                              16.0),
                                                                    ))),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : const SizedBox.shrink(),
                        const SizedBox(height: 30),
                      ],
                    )
            ],
          ),
        ),
      ),
    );
  }

  conformationDialog(msg, context) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: msg,
            negativeText: 'OK',
            isSucessPopup: true,
            onNegativeTap: () {},
          );
        });
  }

  void conformationDialog1(msg) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    msg,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "OK",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  setToggel(var model, bool setFlag) {
    for (var dateModel in model) {
      dateModel.isProfileDisplay = setFlag;
    }
  }

  setToggelAccomplishment(bool setFlag) {
    for (AccomplimentData accomplimentDataList
        in _mAcoomplismentDataModel.accomplimentData) {
      for (Achievement achievementModel in accomplimentDataList.achievement) {
        achievementModel.isProfileDisplay = setFlag;
      }
    }
  }

  setToggeltestScore(bool setFlag) {
    for (TestScores testScoresList
        in _mPublicProfileDataModel.result.testScores) {
      for (Scores ScoresModel in testScoresList.scores) {
        ScoresModel.isProfileDisplay = setFlag;
      }
    }
  }

  updaetAccomplismentToggel() {
    bool isAccomplishmentValue = false;
    for (AccomplimentData accomplimentDataList
        in _mAcoomplismentDataModel.accomplimentData) {
      for (Achievement achievementModel in accomplimentDataList.achievement) {
        if (achievementModel.isProfileDisplay) {
          isAccomplishmentValue = true;
          break;
        }
      }
      if (isAccomplishmentValue) {
        break;
      }
    }
    if (isAccomplishmentValue) {
      _mPublicProfileDataModel.result.isAccomplishment = true;
    } else {
      _mPublicProfileDataModel.result.isAccomplishment = false;
    }
  }

  updateSocialToggel() {
    bool isSocialLinks = false;

    for (var socialLinksModel in _mPublicProfileDataModel.result.socialLinks) {
      if (socialLinksModel.isProfileDisplay) {
        isSocialLinks = true;
        break;
      }
    }
    if (isSocialLinks) {
      _mPublicProfileDataModel.result.isSocialLinks = true;
    } else {
      _mPublicProfileDataModel.result.isSocialLinks = false;
    }
  }

  updateBadgeToggel() {
    bool isBadgeValue = false;

    for (Collections collectionsModel
        in _mPublicProfileDataModel.result.badges.collections) {
      if (collectionsModel.isProfileDisplay) {
        isBadgeValue = true;
        break;
      }
    }
    if (isBadgeValue) {
      _mPublicProfileDataModel.result.isBadges = true;
    } else {
      _mPublicProfileDataModel.result.isBadges = false;
    }
  }

  updateEducationToggel() {
    bool isEducationVallue = false;

    for (Colleges collegesModel
        in _mPublicProfileDataModel.result.educations.colleges) {
      if (collegesModel.isProfileDisplay) {
        isEducationVallue = true;
        break;
      }
    }

    if (!isEducationVallue) {
      for (Schools schoolsModel
          in _mPublicProfileDataModel.result.educations.schools) {
        if (schoolsModel.isProfileDisplay) {
          isEducationVallue = true;
          break;
        }
      }
    }
    if (isEducationVallue) {
      _mPublicProfileDataModel.result.isEducations = true;
    } else {
      isGPA = false;
      _mPublicProfileDataModel.result.isEducations = false;
    }
  }

  updateTerstScoreToggel() {
    bool isTestScoreValue = false;
    for (TestScores testScoresList
        in _mPublicProfileDataModel.result.testScores) {
      for (Scores ScoresModel in testScoresList.scores) {
        {
          if (ScoresModel.isProfileDisplay) {
            isTestScoreValue = true;
            break;
          }
        }
        if (isTestScoreValue) {
          break;
        }
      }
      if (isTestScoreValue) {
        _mPublicProfileDataModel.result.isTestScore = true;
      } else {
        _mPublicProfileDataModel.result.isTestScore = false;
      }
    }
  }

  updateRecommendationToggel() {
    bool isRecommendation = false;

    for (Recommendations recommendationsModel
        in _mPublicProfileDataModel.result.recommendations) {
      if (recommendationsModel.isProfileDisplay) {
        isRecommendation = true;
        break;
      }
    }
    if (isRecommendation) {
      _mPublicProfileDataModel.result.isRecommendation = true;
    } else {
      _mPublicProfileDataModel.result.isRecommendation = false;
    }
  }

  Container getSchoolEducationListItem22(index) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          10.0,
          13.0,
          0.0,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              _mPublicProfileDataModel
                      .result.educations.schools[index].isProfileDisplay
                  ? Expanded(
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              _mPublicProfileDataModel.result.educations
                                  .schools[index].isProfileDisplay = false;

                              updateEducationToggel();
                            });
                          },
                          child: Padding(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 15.0, 13.0, 5.0),
                              child: Image.asset(
                                "assets/newDesignIcon/icon/checked_box.png",
                                height: 20.0,
                                width: 20.0,
                              ))),
                      flex: 0)
                  : Expanded(
                      child: InkWell(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 15.0, 13.0, 5.0),
                            child: Image.asset(
                              "assets/newDesignIcon/icon/uncheked_box.png",
                              height: 20.0,
                              width: 20.0,
                            )),
                        onTap: () {
                          setState(() {
                            _mPublicProfileDataModel.result.isEducations = true;
                            _mPublicProfileDataModel.result.educations
                                .schools[index].isProfileDisplay = true;
                          });
                        },
                      ),
                      flex: 0),
              Expanded(
                  flex: 1,
                  child: PaddingWrap.paddingfromLTRB(
                      8.0,
                      12.0,
                      4.0,
                      0.0,
                      Container(
                        height: 84,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: int.parse(_mPublicProfileDataModel
                                          .result
                                          .educations
                                          .schools[index]
                                          .fromYear) ==
                                      DateTime.now().year ||
                                  int.parse(_mPublicProfileDataModel.result
                                          .educations.schools[index].toYear) ==
                                      DateTime.now().year ||
                                  setRange(
                                      _mPublicProfileDataModel.result.educations
                                          .schools[index].fromYear,
                                      _mPublicProfileDataModel.result.educations
                                          .schools[index].toYear)
                              ? AppConstants.colorStyle.education_bg_green
                              : Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, top: 12, bottom: 12, right: 4),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  //color: Colors.transparent,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      BaseText(
                                        text: _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .schools[index]
                                            .institute,
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoRegular,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        maxLines: 2,
                                      ),
                                      SizedBox(
                                        height: 4,
                                      ),
                                      RichText(
                                        maxLines: 15,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          text: _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .schools[index]
                                                          .toYear ==
                                                      null ||
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .schools[index]
                                                          .toYear ==
                                                      "null" ||
                                                  _mPublicProfileDataModel
                                                          .result
                                                          .educations
                                                          .schools[index]
                                                          .toYear ==
                                                      ""
                                              ? _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .fromYear +
                                                  " - " +
                                                  "Ongoing" +
                                                  " | "
                                              : _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .fromYear +
                                                  " - " +
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .educations
                                                      .schools[index]
                                                      .toYear +
                                                  " | ",
                                          style: TextStyle(
                                              color: AppConstants
                                                  .colorStyle.lightPurple,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: Constant.latoRegular,
                                              fontSize: 13.0),
                                          children: [
                                            TextSpan(
                                                text: _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools[index]
                                                        .fromGrade +
                                                    " - " +
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .schools[index]
                                                        .toGrade,
                                                style: TextStyle(
                                                    color: AppConstants
                                                        .colorStyle.lightPurple,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontSize: 13.0)),
                                            TextSpan(
                                                text: _mPublicProfileDataModel
                                                                .result
                                                                .educations
                                                                .schools[index]
                                                                .gpa !=
                                                            null &&
                                                        _mPublicProfileDataModel
                                                                .result
                                                                .educations
                                                                .schools[index]
                                                                .gpa !=
                                                            ''
                                                    ? " | GPA: " +
                                                        _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .schools[index]
                                                            .gpa
                                                            .toString()
                                                    : '',
                                                style: TextStyle(
                                                    color: AppConstants
                                                        .colorStyle.lightPurple,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    fontSize: 13.0)),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child: Image.asset(
                                  'assets/new_onboarding/l1.png',
                                  height: 68,
                                  width: 72,
                                ),
                                flex: 0,
                              ),
                            ],
                          ),
                        ),
                      )))
            ],
          )),
      onTap: () {},
    ));
  }

  Container getCollegeEducationListItem22(index) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          0.0,
          13.0,
          0.0,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              _mPublicProfileDataModel
                      .result.educations.colleges[index].isProfileDisplay
                  ? Expanded(
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              _mPublicProfileDataModel.result.educations
                                  .colleges[index].isProfileDisplay = false;
                              updateEducationToggel();
                            });
                          },
                          child: Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 15.0, 8.0, 5.0),
                              child: Image.asset(
                                "assets/newDesignIcon/icon/checked_box.png",
                                height: 22.0,
                                width: 22.0,
                              ))),
                      flex: 0)
                  : Expanded(
                      child: InkWell(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 15.0, 8.0, 5.0),
                            child: Image.asset(
                              "assets/newDesignIcon/icon/uncheked_box.png",
                              height: 22.0,
                              width: 22.0,
                            )),
                        onTap: () {
                          setState(() {
                            _mPublicProfileDataModel.result.isEducations = true;
                            _mPublicProfileDataModel.result.educations
                                .colleges[index].isProfileDisplay = true;
                          });
                        },
                      ),
                      flex: 0),
              Expanded(
                  flex: 1,
                  child: PaddingWrap.paddingfromLTRB(
                      8.0,
                      12.0,
                      4.0,
                      0.0,
                      Container(
                        height: 84,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: int.parse(_mPublicProfileDataModel
                                          .result
                                          .educations
                                          .colleges[index]
                                          .fromYear) ==
                                      DateTime.now().year ||
                                  int.parse(_mPublicProfileDataModel.result
                                          .educations.colleges[index].toYear) ==
                                      DateTime.now().year ||
                                  setRange(
                                      _mPublicProfileDataModel.result.educations
                                          .colleges[index].fromYear,
                                      _mPublicProfileDataModel.result.educations
                                          .colleges[index].toYear)
                              ? AppConstants.colorStyle.education_bg_green
                              : Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, top: 12, bottom: 12, right: 4),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  //color: Colors.transparent,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      BaseText(
                                        text: _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .institute,
                                        textColor: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontFamily: AppConstants
                                            .stringConstant.latoRegular,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16,
                                        maxLines: 2,
                                      ),
                                      SizedBox(
                                        height: 4,
                                      ),
                                      Row(
                                        children: [
                                          BaseText(
                                            text: _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges[index]
                                                            .toYear ==
                                                        null ||
                                                    _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges[index]
                                                            .toYear ==
                                                        "null" ||
                                                    _mPublicProfileDataModel
                                                            .result
                                                            .educations
                                                            .colleges[index]
                                                            .toYear ==
                                                        ""
                                                ? _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges[index]
                                                        .fromYear +
                                                    " - " +
                                                    "Ongoing"
                                                : _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges[index]
                                                        .fromYear +
                                                    " - " +
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .educations
                                                        .colleges[index]
                                                        .toYear,
                                            textColor: AppConstants
                                                .colorStyle.lightPurple,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 13,
                                            maxLines: 2,
                                          ),
                                          BaseText(
                                            text: " | " +
                                                _mPublicProfileDataModel
                                                    .result
                                                    .educations
                                                    .colleges[index]
                                                    .degree,
                                            textColor: AppConstants
                                                .colorStyle.lightPurple,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 13,
                                            maxLines: 2,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                flex: 1,
                              ),
                              Expanded(
                                child: Image.asset(
                                  'assets/new_onboarding/l1.png',
                                  height: 68,
                                  width: 72,
                                ),
                                flex: 0,
                              ),
                            ],
                          ),
                        ),
                      ))),
            ],
          )),
      onTap: () {},
    ));
  }

  setRange(String fromYear, String toYear) {
    DateTime dateD = DateTime.now();
    //DateTime now = DateTime.now();

    String convertedDateTime =
        "${fromYear}-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";
    String convertedDateTime1 =
        "${toYear}-${dateD.month.toString().padLeft(2, '0')}-${dateD.day.toString().padLeft(2, '0')} ${dateD.hour.toString().padLeft(2, '0')}-${dateD.minute.toString().padLeft(2, '0')}";

    if (DateTime.parse(convertedDateTime).isBefore(dateD) &&
        DateTime.parse(convertedDateTime1).isAfter(dateD)) {
      return true;
    } else {
      return false;
    }
  }

  Container getSchoolEducationListItem(index) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          10.0,
          13.0,
          0.0,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              widget.profileType == "Connected"
                  ? Container(
                      width: 3.0,
                    )
                  : _mPublicProfileDataModel
                          .result.educations.schools[index].isProfileDisplay
                      ? Expanded(
                          child: InkWell(
                              onTap: () {
                                setState(() {
                                  _mPublicProfileDataModel.result.educations
                                      .schools[index].isProfileDisplay = false;
                                  updateEducationToggel();
                                });
                              },
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(0.0, 15.0, 13.0, 5.0),
                                  child: Image.asset(
                                    "assets/newDesignIcon/navigation/check.png",
                                    height: 20.0,
                                    width: 20.0,
                                  ))),
                          flex: 0)
                      : Expanded(
                          child: InkWell(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 15.0, 13.0, 5.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/navigation/uncheck.png",
                                  height: 20.0,
                                  width: 20.0,
                                )),
                            onTap: () {
                              setState(() {
                                _mPublicProfileDataModel.result.isEducations =
                                    true;
                                _mPublicProfileDataModel.result.educations
                                    .schools[index].isProfileDisplay = true;
                              });
                            },
                          ),
                          flex: 0),
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    5.0,
                    10.0,
                    0.0,
                    _mPublicProfileDataModel
                                    .result.educations.schools[index].logo ==
                                "" ||
                            _mPublicProfileDataModel
                                    .result.educations.schools[index].logo ==
                                "null"
                        ? Image.asset(
                            "assets/profile/img_default.png",
                            height: 37.0,
                            width: 37.0,
                          )
                        : InkWell(
                            onTap: () {
                              Navigator.of(context).push(new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      FullImageView(
                                        _mPublicProfileDataModel.result
                                            .educations.schools[index].logo,
                                        pageName:
                                            MessageConstant.EDUCATION_HEDING,
                                      )));
                            },
                            child: CachedNetworkImage(
                              height: 37.0,
                              width: 37.0,
                              imageUrl: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel
                                      .result.educations.schools[index].logo,
                              fit: BoxFit.cover,
                              placeholder: (context, url) => _loader(
                                  context, "assets/profile/img_default.png'"),
                              errorWidget: (context, url, error) =>
                                  _error("assets/profile/img_default.png'"),
                            )) /*new Container(
                            height: 37.0,
                            width: 37.0,
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: 'assets/profile/img_default.png',
                              image: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel
                                      .result.educations.schools[index].logo,
                            ))*/
                    ),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        Text(
                          _mPublicProfileDataModel
                              .result.educations.schools[index].institute,
                          maxLines: 5,
                          style: TextStyle(
                              fontWeight: FontWeight.normal,
                              color: ColorValues.HEADING_COLOR_EDUCATION,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 16.0),
                        )),
                    RichText(
                      maxLines: 15,
                      textAlign: TextAlign.start,
                      text: TextSpan(
                        text: _mPublicProfileDataModel.result.educations
                                        .schools[index].toYear ==
                                    null ||
                                _mPublicProfileDataModel.result.educations
                                        .schools[index].toYear ==
                                    "null" ||
                                _mPublicProfileDataModel.result.educations
                                        .schools[index].toYear ==
                                    ""
                            ? _mPublicProfileDataModel
                                    .result.educations.schools[index].fromYear +
                                " - " +
                                "Ongoing" +
                                " | "
                            : _mPublicProfileDataModel
                                    .result.educations.schools[index].fromYear +
                                " - " +
                                _mPublicProfileDataModel
                                    .result.educations.schools[index].toYear +
                                " | ",
                        style: TextStyle(
                            color: ColorValues.GREY__COLOR,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            fontSize: 14.0),
                        children: [
                          TextSpan(
                              text: _mPublicProfileDataModel.result.educations
                                      .schools[index].fromGrade +
                                  " - " +
                                  _mPublicProfileDataModel
                                      .result.educations.schools[index].toGrade,
                              style: TextStyle(
                                  color: ColorValues.GREY__COLOR,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 14.0)),
                          TextSpan(
                              text: _mPublicProfileDataModel.result.educations
                                              .schools[index].gpa !=
                                          null &&
                                      _mPublicProfileDataModel.result.educations
                                              .schools[index].gpa !=
                                          ''
                                  ? " | GPA: " +
                                      _mPublicProfileDataModel
                                          .result.educations.schools[index].gpa
                                          .toString()
                                  : '',
                              style: TextStyle(
                                  color: ColorValues.GREY__COLOR,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 14.0)),
                        ],
                      ),
                    ),
                    /*new Row(
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                              Text(
                              schoolsInfoList[index].toYear == null ||
                                      schoolsInfoList[index].toYear == "null" ||
                                      schoolsInfoList[index].toYear == ""
                                  ? schoolsInfoList[index].fromYear +
                                      " - " +
                                      "Ongoing" +
                                      " | "
                                  : schoolsInfoList[index].fromYear +
                                      " - " +
                                      schoolsInfoList[index].toYear +
                                      " | ",
                              style:   TextStyle(
                                  color:   ColorValues.GREY__COLOR,
                                  fontSize: 14.0),
                            )),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                              Text(
                              schoolsInfoList[index].fromGrade +
                                  " - " +
                                  schoolsInfoList[index].toGrade,
                              style:   TextStyle(
                                  color:   ColorValues.GREY__COLOR,
                                  fontSize: 14.0),
                            )),
                        schoolsInfoList[index].gpa != null &&
                                schoolsInfoList[index].gpa != ''
                            ? PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                  Text(
                                  schoolsInfoList[index].gpa != null
                                      ? " | GPA: " +
                                          schoolsInfoList[index].gpa.toString()
                                      : '',
                                  style:   TextStyle(
                                      color:   ColorValues.GREY__COLOR,
                                      fontSize: 14.0),
                                ))
                            :   Container(
                                height: 0.0,
                              ),
                      ],
                    ),*/
                  ],
                ),
                flex: 1,
              ),
            ],
          )),
      onTap: () {},
      /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
    ));
  }

  Container getCollegeEducationListItem(index) {
    return Container(
        child: InkWell(
      child: PaddingWrap.paddingfromLTRB(
          13.0,
          10.0,
          13.0,
          0.0,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              widget.profileType == "Connected"
                  ? Container(
                      width: 3.0,
                    )
                  : _mPublicProfileDataModel
                          .result.educations.colleges[index].isProfileDisplay
                      ? Expanded(
                          child: InkWell(
                              onTap: () {
                                setState(() {
                                  _mPublicProfileDataModel.result.educations
                                      .colleges[index].isProfileDisplay = false;
                                  updateEducationToggel();
                                });
                              },
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(0.0, 15.0, 8.0, 5.0),
                                  child: Image.asset(
                                    "assets/newDesignIcon/navigation/check.png",
                                    height: 20.0,
                                    width: 20.0,
                                  ))),
                          flex: 0)
                      : Expanded(
                          child: InkWell(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 15.0, 8.0, 5.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/navigation/uncheck.png",
                                  height: 20.0,
                                  width: 20.0,
                                )),
                            onTap: () {
                              setState(() {
                                _mPublicProfileDataModel.result.isEducations =
                                    true;
                                _mPublicProfileDataModel.result.educations
                                    .colleges[index].isProfileDisplay = true;
                              });
                            },
                          ),
                          flex: 0),
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    5.0,
                    10.0,
                    0.0,
                    _mPublicProfileDataModel
                                    .result.educations.colleges[index].logo ==
                                "" ||
                            _mPublicProfileDataModel
                                    .result.educations.colleges[index].logo ==
                                "null"
                        ? Image.asset(
                            "assets/profile/img_default.png",
                            height: 37.0,
                            width: 37.0,
                          )
                        : InkWell(
                            onTap: () {
                              Navigator.of(context).push(new MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      FullImageView(
                                        _mPublicProfileDataModel.result
                                            .educations.colleges[index].logo,
                                        pageName:
                                            MessageConstant.EDUCATION_HEDING,
                                      )));
                            },
                            child: CachedNetworkImage(
                              height: 37.0,
                              width: 37.0,
                              imageUrl: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel
                                      .result.educations.colleges[index].logo,
                              fit: BoxFit.cover,
                              placeholder: (context, url) => _loader(
                                  context, "assets/profile/img_default.png'"),
                              errorWidget: (context, url, error) =>
                                  _error("assets/profile/img_default.png'"),
                            ))

                    /*    Container(
                            height: 37.0,
                            width: 37.0,
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: 'assets/profile/img_default.png',
                              image: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel
                                      .result.educations.colleges[index].logo,
                            ))*/
                    ),
                flex: 0,
              ),
              Expanded(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Text(
                            _mPublicProfileDataModel
                                .result.educations.colleges[index].institute,
                            maxLines: 1,
                            style: TextStyle(
                                fontWeight: FontWeight.normal,
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 16.0),
                          )),

/*
                          _mPublicProfileDataModel
                              .result.educations.colleges[index].degree !=
                              null &&
                              _mPublicProfileDataModel
                                  .result.educations.colleges[index].degree !=
                                  "null" &&
                              _mPublicProfileDataModel
                                  .result.educations.colleges[index].degree !=
                                  ""
                              ? RichText(
                            maxLines: 15,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: _mPublicProfileDataModel.result.educations
                                  .colleges[index].degree +
                                  ", ",
                              style:   TextStyle(
                                  color:   ColorValues.GREY__COLOR,
                                  fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                  fontSize: 14.0),
                              children: [
                                  TextSpan(
                                    text: _mPublicProfileDataModel
                                        .result
                                        .educations
                                        .colleges[index]
                                        .degree !=
                                        'Professional Certificate'
                                        ? "Major: " +
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .major
                                    */ /*" | " +
                                      collegesInfoList[index].minor*/ /*
                                        : "Certification Name: " +
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .certifications,
                                    style:   TextStyle(
                                        color:
                                          ColorValues.GREY__COLOR,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                                  TextSpan(
                                    text: _mPublicProfileDataModel
                                        .result
                                        .educations
                                        .colleges[index]
                                        .minor !=
                                        '' &&
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .minor !=
                                            null &&
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .minor !=
                                            'null' &&
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .degree !=
                                            'Professional Certificate'
                                        ? ", Minor: " +
                                        _mPublicProfileDataModel
                                            .result
                                            .educations
                                            .colleges[index]
                                            .minor
                                    */ /*" | " +
                                      collegesInfoList[index].minor*/ /*
                                        : '',
                                    style:   TextStyle(
                                        color:
                                          ColorValues.GREY__COLOR,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                              ],
                            ),
                          )
                              : Container(
                            width: 0,
                            height: 0,
                          ),*/

                      _mPublicProfileDataModel.result.educations.colleges[index]
                                      .degree !=
                                  null &&
                              _mPublicProfileDataModel.result.educations
                                      .colleges[index].degree !=
                                  "null" &&
                              _mPublicProfileDataModel.result.educations
                                      .colleges[index].degree !=
                                  ""
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                RichText(
                                  maxLines: 15,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: _mPublicProfileDataModel
                                        .result
                                        .educations
                                        .colleges[index]
                                        .degree, //+ ", ",
                                    style: TextStyle(
                                        color: ColorValues.GREY__COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  ),
                                ),
                                Text(
                                    _mPublicProfileDataModel.result.educations
                                                .colleges[index].degree !=
                                            'Professional Certificate'
                                        ? "Major: " +
                                            _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .major
                                                .trim()
                                        /*" | " +
                                    collegesInfoList[index].minor*/
                                        : "Certification Name: " +
                                            _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .certifications
                                                .trim(),
                                    style: TextStyle(
                                        color: ColorValues.GREY__COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0)),
                                _mPublicProfileDataModel.result.educations
                                                .colleges[index].minor !=
                                            '' &&
                                        _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .minor !=
                                            null &&
                                        _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .minor !=
                                            'null' &&
                                        _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .degree !=
                                            'Professional Certificate'
                                    ? Text(
                                        "Minor: " +
                                            _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .minor
                                                .trim(),
                                        /*" | " +
                                    collegesInfoList[index].minor*/

                                        style: TextStyle(
                                            color: ColorValues.GREY__COLOR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0))
                                    : Container(
                                        width: 0,
                                        height: 0,
                                      ),
                              ],
                            )
                          : Container(
                              width: 0,
                              height: 0,
                            ),
                      Row(
                        children: <Widget>[
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              Text(
                                _mPublicProfileDataModel.result.educations
                                                .colleges[index].toYear ==
                                            null ||
                                        _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .toYear ==
                                            "null" ||
                                        _mPublicProfileDataModel
                                                .result
                                                .educations
                                                .colleges[index]
                                                .toYear ==
                                            ""
                                    ? _mPublicProfileDataModel.result.educations
                                            .colleges[index].fromYear +
                                        " - " +
                                        "Ongoing"
                                    : _mPublicProfileDataModel.result.educations
                                            .colleges[index].fromYear +
                                        " - " +
                                        _mPublicProfileDataModel.result
                                            .educations.colleges[index].toYear,
                                style: TextStyle(
                                    color: ColorValues.GREY__COLOR,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 14.0),
                              )),
                          /*  PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                    Text(
                                    _mPublicProfileDataModel.result.educations
                                        .colleges[index].graduationYear,
                                    style:   TextStyle(
                                        color:   ColorValues.GREY__COLOR,
                                        fontFamily:Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  )),*/
                          _mPublicProfileDataModel.result.educations
                                          .colleges[index].gpa !=
                                      null &&
                                  _mPublicProfileDataModel.result.educations
                                          .colleges[index].gpa !=
                                      ''
                              ? PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                  Text(
                                    _mPublicProfileDataModel.result.educations
                                                .colleges[index].gpa !=
                                            null
                                        ? " | GPA: " +
                                            _mPublicProfileDataModel.result
                                                .educations.colleges[index].gpa
                                                .toString()
                                        : '',
                                    style: TextStyle(
                                        color: ColorValues.GREY__COLOR,
                                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                        fontSize: 14.0),
                                  ))
                              : Container(
                                  height: 0.0,
                                ),
                        ],
                      ),
                    ],
                  ),
                ),
                flex: 1,
              ),
            ],
          )),
      onTap: () {},
      /*onLongPress: () {
              if (widget.isEditable) {
                showDialogDeleteAchievment(userEducationList[index].educationId,
                    userEducationList[index].institute, index);
              }
            },*/
    ));
  }

  Widget getTestScoreListItem(index) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        _mPublicProfileDataModel.result.testScores[index].scores.length,
        (index3) {
          return PaddingWrap.paddingfromLTRB(
            0.0,
            5.0,
            0.0,
            0.0,
            Container(
              decoration: BoxDecoration(
                color: ColorValues.WHITE,
                borderRadius: BorderRadius.circular(10),
              ),
              margin: EdgeInsets.only(left: 12, right: 12, top: 5, bottom: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 12.0, right: 12.0, top: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _mPublicProfileDataModel.result.testScores[index]
                                .scores[index3].isProfileDisplay
                            ? Expanded(
                                child: InkWell(
                                    onTap: () {
                                      setState(() {
                                        _mPublicProfileDataModel
                                            .result
                                            .testScores[index]
                                            .scores[index3]
                                            .isProfileDisplay = false;
                                      });

                                      updateTerstScoreToggel();
                                    },
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 5.0, 0.0, 5.0),
                                        child: Image.asset(
                                          "assets/newDesignIcon/icon/checked_box.png",
                                          height: 22.0,
                                          width: 22.0,
                                        ))),
                                flex: 0)
                            : Expanded(
                                child: InkWell(
                                  child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          0.0, 5.0, 0.0, 5.0),
                                      child: Image.asset(
                                        "assets/newDesignIcon/icon/uncheked_box.png",
                                        height: 22.0,
                                        width: 22.0,
                                      )),
                                  onTap: () {
                                    setState(() {
                                      _mPublicProfileDataModel
                                          .result.isTestScore = true;
                                      _mPublicProfileDataModel
                                          .result
                                          .testScores[index]
                                          .scores[index3]
                                          .isProfileDisplay = true;
                                    });
                                  },
                                ),
                                flex: 0),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 1,
                          child: BaseText(
                            text: _mPublicProfileDataModel
                                .result.testScores[index].name,
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            maxLines: 3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                      padding: const EdgeInsets.only(
                          left: 12.0, right: 12.0, bottom: 12),
                      child: Container(
                          child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Column(
                              children: List.generate(
                                  _mPublicProfileDataModel
                                      .result
                                      .testScores[index]
                                      .scores[index3]
                                      .subjects
                                      .length, (index2) {
                            return Padding(
                                padding: const EdgeInsets.only(top: 9.0),
                                child: Container(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        0.0,
                                        0.0,
                                        Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: BaseText(
                                                text: _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .scores[index3]
                                                    .subjects[index2]
                                                    .subject,
                                                textColor: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoRegular,
                                                fontWeight: FontWeight.w400,
                                                fontSize: 14,
                                                maxLines: 3,
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: BaseText(
                                                text: _mPublicProfileDataModel
                                                    .result
                                                    .testScores[index]
                                                    .scores[index3]
                                                    .subjects[index2]
                                                    .score
                                                    .toString(),
                                                textColor: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoRegular,
                                                fontWeight: FontWeight.w700,
                                                fontSize: 16,
                                                maxLines: 3,
                                              ),
                                              flex: 0,
                                            )
                                          ],
                                        ))));
                          })),
                        ],
                      ))),
                  PaddingWrap.paddingfromLTRB(
                      12.0,
                      0.0,
                      12.0,
                      16.0,
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: PaddingWrap.paddingfromLTRB(
                                0.0,
                                9.0,
                                0.0,
                                0.0,
                                BaseText(
                                  text: getConvertedDateStamp2(
                                      _mPublicProfileDataModel
                                          .result
                                          .testScores[index]
                                          .scores[index3]
                                          .dateTaken
                                          .toString()),
                                  textColor: ColorValues.labelColor,
                                  fontFamily:
                                      AppConstants.stringConstant.latoItalic,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12,
                                  maxLines: 3,
                                )),
                            flex: 1,
                          ),
                          Expanded(
                            child: _mPublicProfileDataModel
                                            .result
                                            .testScores[index]
                                            .scores[index3]
                                            .docUrl
                                            .length >
                                        0 ||
                                    _mPublicProfileDataModel
                                            .result
                                            .testScores[index]
                                            .scores[index3]
                                            .imageUrl
                                            .length >
                                        0
                                ? InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        9.0,
                                        0.0,
                                        0.0,
                                        BaseText(
                                          text: 'View attachment',
                                          textColor: ColorValues
                                              .HEADING_COLOR_EDUCATION_2,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 12,
                                          maxLines: 3,
                                        )),
                                    onTap: () {
                                      var score = _mPublicProfileDataModel
                                          .result
                                          .testScores[index]
                                          .scores[index3];

                                      ScoreDataModel model = ScoreDataModel(
                                          sId: score.sId,
                                          userTestId: score.userTestId,
                                          testId: score.testId,
                                          userId: score.userId,
                                          dateTaken: score.dateTaken,
                                          imageUrl: score.imageUrl,
                                          docUrl: score.docUrl,
                                          name: score.name,
                                          subjects: score.subjects,
                                          isProfileDisplay:
                                              score.isProfileDisplay);
                                      Navigator.of(context).push(
                                          new MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  DocumentPerformance(
                                                    null,
                                                    model: model,
                                                    subjectName:
                                                        score.subjects.length ==
                                                                1
                                                            ? score.subjects[0]
                                                                .subject
                                                            : '',
                                                  )));
                                    },
                                  )
                                : SizedBox(),
                            flex: 0,
                          ),
                        ],
                      )),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  badgeList2() {
    return Container(
      decoration: BoxDecoration(
        color: ColorValues.SELECTION_BG,
        borderRadius: new BorderRadius.only(
            bottomLeft: const Radius.circular(10.0),
            bottomRight: const Radius.circular(10.0)),
      ),
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 10, 0, 5),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: List.generate(
                    _mPublicProfileDataModel.result.badges.collections.length >
                            2
                        ? isViewAllBadges
                            ? _mPublicProfileDataModel
                                .result.badges.collections.length
                            : 2
                        : _mPublicProfileDataModel
                            .result.badges.collections.length, (int index) {
                  return Column(
                    children: <Widget>[
                      Container(
                        decoration: BoxDecoration(
                          color: ColorValues.WHITE,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        margin: EdgeInsets.only(
                            top: 6, bottom: 6, left: 12, right: 12),
                        padding: EdgeInsets.only(
                            top: 11, bottom: 11, left: 12, right: 12),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            _mPublicProfileDataModel.result.badges
                                    .collections[index].isProfileDisplay
                                ? Expanded(
                                    child: InkWell(
                                        onTap: () {
                                          setState(() {
                                            _mPublicProfileDataModel
                                                .result
                                                .badges
                                                .collections[index]
                                                .isProfileDisplay = false;

                                            updateBadgeToggel();
                                          });
                                        },
                                        child: Image.asset(
                                          "assets/newDesignIcon/icon/checked_box.png",
                                          height: 22.0,
                                          width: 22.0,
                                        )),
                                    flex: 0)
                                : Expanded(
                                    child: InkWell(
                                      child: Image.asset(
                                        "assets/newDesignIcon/icon/uncheked_box.png",
                                        height: 22.0,
                                        width: 22.0,
                                      ),
                                      onTap: () {
                                        setState(() {
                                          _mPublicProfileDataModel
                                              .result
                                              .badges
                                              .collections[index]
                                              .isProfileDisplay = true;
                                          _mPublicProfileDataModel
                                              .result.isBadges = true;
                                        });
                                      },
                                    ),
                                    flex: 0),
                            Expanded(
                              flex: 0,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 12.0,
                                    top: 0.0,
                                    right: 12.0,
                                    bottom: 0.0),
                                child: Container(
                                  height: 78.0,
                                  width: 76.0,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color:
                                            ColorValues.BORDER_GENERATE_SCRIPT),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(12)),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(3.0),
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.contain,
                                          placeholder:
                                              'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getMediumImage(
                                                  _mPublicProfileDataModel
                                                      .result
                                                      .badges
                                                      .collections[index]
                                                      .image),
                                          height: 94.0,
                                          width: 86.0,
                                        )),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  const SizedBox(height: 7),

                                  Text(
                                    _mPublicProfileDataModel
                                        .result.badges.collections[index].name
                                        .toString(),
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: Constant.latoRegular,
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  _mPublicProfileDataModel.result.badges
                                              .collections[index].companyName
                                              .toString() ==
                                          ""
                                      ? new Container(height: 0.0)
                                      : Text(
                                          _mPublicProfileDataModel.result.badges
                                              .collections[index].companyName
                                              .toString(),
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: Constant.latoRegular,
                                            color: ColorValues.labelColor,
                                          ),
                                        ),
                                  InkWell(
                                    child: Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        _mPublicProfileDataModel
                                                        .result
                                                        .badges
                                                        .collections[index]
                                                        .type ==
                                                    "request" &&
                                                _mPublicProfileDataModel
                                                        .result
                                                        .badges
                                                        .collections[index]
                                                        .status ==
                                                    "accepted"
                                            ? 'Issued on: ' +
                                                getConvertedDateStamp2(
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .badges
                                                        .collections[index]
                                                        .date
                                                        .toString())
                                            : 'Issued on: ' +
                                                getConvertedDateStamp2(
                                                    _mPublicProfileDataModel
                                                        .result
                                                        .badges
                                                        .collections[index]
                                                        .date
                                                        .toString()),
                                        style: TextStyle(
                                          color: ColorValues.labelColor,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: Constant.latoRegular,
                                        ),
                                      ),
                                    ),
                                    onTap: () {},
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  );
                })),
          ),
          _mPublicProfileDataModel.result.badges.collections == null
              ? Container(
                  height: 0,
                )
              : _mPublicProfileDataModel.result.badges.collections.length > 2
                  ? InkWell(
                      onTap: () {
                        if (isViewAllBadges) {
                          isViewAllBadges = false;
                        } else {
                          isViewAllBadges = true;
                        }
                        setState(() {
                          isViewAllBadges;
                        });
                      },
                      child: Container(
                        margin: const EdgeInsets.only(top: 8, bottom: 18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(7),
                          border: Border.all(
                            color: Color(0xff4684EB),
                            width: 1,
                          ),
                        ),
                        padding: const EdgeInsets.fromLTRB(20, 6, 19, 7),
                        child: Text(
                          isViewAllBadges ? 'View less' : 'View all',
                          style: TextStyle(
                            color: Color(0xff4684EB),
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                          ),
                        ),
                      ),
                    )
                  : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget getRecommendation() {
    return PaddingWrap.paddingfromLTRB(
        0.0,
        24.0,
        0.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: ColorValues.LIST_BOTTOM_BG,
                borderRadius: new BorderRadius.only(
                    topLeft: const Radius.circular(10.0),
                    topRight: const Radius.circular(10.0)),
              ),
              child: Row(
                children: [
                  PaddingWrap.paddingfromLTRB(
                      6.0,
                      10.0,
                      10.0,
                      10.0,
                      Image.asset(
                        "assets/profile/skills/ic_recommendation.png",
                        width: 35,
                        height: 35,
                      )),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        BaseText(
                          text: 'Recommendations',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w600,
                          fontSize: 18,
                          maxLines: 1,
                        )),
                  ),
                  _hideShowButton(
                      value: _mPublicProfileDataModel.result.isRecommendation,
                      onChange: (value) {
                        setState(() {
                          _mPublicProfileDataModel.result.isRecommendation =
                              value;
                          setToggel(
                              _mPublicProfileDataModel.result.recommendations,
                              value);
                        });
                      }),
                  const SizedBox(width: 12),
                ],
              ),
            ),
            DisableView(
              isEnable: _mPublicProfileDataModel.result.isRecommendation,
              child: Container(
                  decoration: BoxDecoration(
                    color: ColorValues.SELECTION_BG,
                    borderRadius: new BorderRadius.only(
                        bottomLeft: const Radius.circular(10.0),
                        bottomRight: const Radius.circular(10.0)),
                  ),
                  child: Column(
                    children: [
                      _mPublicProfileDataModel
                                  ?.result?.recommendations?.isNotEmpty ??
                              false
                          ? ListView.separated(
                              itemBuilder: (_, index) {
                                final item = _mPublicProfileDataModel
                                    .result.recommendations[index];
                                return _recommendationItem(item, index);
                              },
                              separatorBuilder: (_, index) =>
                                  const SizedBox(height: 16),
                              itemCount: (_mPublicProfileDataModel?.result
                                              ?.recommendations?.length ??
                                          0) >
                                      3
                                  ? isShowAllRecommendation
                                      ? (_mPublicProfileDataModel?.result
                                              ?.recommendations?.length ??
                                          0)
                                      : 3
                                  : _mPublicProfileDataModel
                                          ?.result?.recommendations?.length ??
                                      0,
                              shrinkWrap: true,
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 12),
                              physics: const NeverScrollableScrollPhysics(),
                            )
                          : const SizedBox.shrink(),
                      (_mPublicProfileDataModel
                                      ?.result?.recommendations?.length ??
                                  0) >=
                              3
                          ? InkWell(
                              onTap: () {
                                isShowAllRecommendation =
                                    !isShowAllRecommendation;
                                setState(() {});
                              },
                              child: Container(
                                margin:
                                    const EdgeInsets.only(top: 8, bottom: 12),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(7),
                                  border: Border.all(
                                    color: Color(0xff4684EB),
                                    width: 1,
                                  ),
                                ),
                                padding:
                                    const EdgeInsets.fromLTRB(20, 6, 19, 7),
                                child: Text(
                                  isShowAllRecommendation
                                      ? 'View less'
                                      : 'View all',
                                  style: TextStyle(
                                    color: Color(0xff4684EB),
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                  ),
                                ),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ],
                  )),
            )
          ],
        ));
  }

  Widget _recommendationItem(Recommendations item, int index) {
    return Container(
      padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _mPublicProfileDataModel
                      .result.recommendations[index].isProfileDisplay
                  ? InkWell(
                      onTap: () {
                        setState(() {
                          _mPublicProfileDataModel.result.recommendations[index]
                              .isProfileDisplay = false;

                          updateRecommendationToggel();
                        });
                      },
                      child: Image.asset(
                        "assets/newDesignIcon/icon/checked_box.png",
                        height: 22.0,
                        width: 22.0,
                      ))
                  : InkWell(
                      child: Image.asset(
                        "assets/newDesignIcon/icon/uncheked_box.png",
                        height: 22.0,
                        width: 22.0,
                      ),
                      onTap: () {
                        setState(() {
                          _mPublicProfileDataModel.result.recommendations[index]
                              .isProfileDisplay = true;

                          _mPublicProfileDataModel.result.isRecommendation =
                              true;
                        });
                      },
                    ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /*   Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: item.stage == "Requested"
                            ? Color(0xFFFFF3CD)
                            : item.stage == "Replied"
                            ? Color(0xffFCEAE2)
                            : Color(0xFFD1E7DD),
                      ),
                      padding: EdgeInsets.fromLTRB(12.0, 5.0, 12.0, 5.0),
                      child: Text(
                        item.stage == "Requested"
                            ? "REQUESTED"
                            : item.stage == "Replied"
                            ? "PENDING"
                            : "ACTIVE",
                        style: TextStyle(
                          color: item.stage == "Requested"
                              ? Color(0xFFDCA600)
                              : item.stage == "Replied"
                              ? Color(0xffC87C5B)
                              : Color(0xFF198754),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          fontFamily: AppConstants.stringConstant.latoRegular,
                        ),
                      ),
                    ),*/
                    item.recommenderFile != "null" && item.recommenderFile != ""
                        ? InkWell(
                            onTap: () {
                              launch(
                                  Constant.IMAGE_PATH + item.recommenderFile);
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: Row(
                                children: [
                                  Image.asset(
                                    'assets/recommendation/ic_list_recommendation.png',
                                    width: 16,
                                    height: 20,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: BaseText(
                                      text: 'Recommendation letter',
                                      textColor: Color(0xff4684EB),
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      maxLines: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : const SizedBox.shrink(),
                    ReadMoreText(
                      item.stage == "Added" || item.stage == "Replied"
                          ? item.recommendation ?? ''
                          : item.request,
                      trimLines: 3,
                      delimiter: '..',
                      colorClickableText: Color(0xff4684EB),
                      style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      trimMode: TrimMode.Line,
                      trimCollapsedText: 'More',
                      trimExpandedText: '',
                      delimiterStyle: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                      moreStyle: TextStyle(
                        color: Color(0xff4684EB),
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    const SizedBox(height: 12),
                    BaseText(
                      text:
                          "${item?.recommender[0]?.firstName ?? ''} ${item?.recommender[0]?.lastName ?? ''}",
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 5),
                    BaseText(
                      text: '${item.title ?? ''} ',
                      textColor: ColorValues.labelColor,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                  ],
                ),
                flex: 1,
              ),
            ],
          ),
          const SizedBox(height: 11),
          Divider(
            height: 0,
            thickness: 1,
            color: Color(0xffE8ECFF),
          ),
          const SizedBox(height: 11),
          item?.level3Competency?.toString() != 'null' &&
                  (item?.level3Competency?.isNotEmpty ?? false)
              ? Row(
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BaseText(
                            text: 'For',
                            textColor: ColorValues.labelColor,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            maxLines: 1,
                          ),
                          const SizedBox(height: 5),
                          BaseText(
                            text: item?.level3Competency?.toString() !=
                                            'null' &&
                                        item?.level3Competency?.isNotEmpty ??
                                    false
                                ? "${item.level3Competency}"
                                : '',
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          BaseText(
                            text: 'Sent On:',
                            textColor: ColorValues.labelColor,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                            maxLines: 1,
                          ),
                          const SizedBox(height: 5),
                          BaseText(
                            text: Util.getConvertedDateStampNew(
                                item.requestedDate),
                            textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontFamily: AppConstants.stringConstant.latoRegular,
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Expanded(
                    //   child: Column(
                    //     mainAxisSize: MainAxisSize.min,
                    //     crossAxisAlignment: CrossAxisAlignment.start,
                    //     children: [
                    //       BaseText(
                    //         text: item.title,
                    //         textColor: ColorValues.labelColor,
                    //         fontFamily: AppConstants.stringConstant.latoRegular,
                    //         fontSize: 12,
                    //         fontWeight: FontWeight.w500,
                    //         maxLines: 1,
                    //       ),
                    //       const SizedBox(height: 5),
                    //
                    //     ],
                    //   ),
                    // ),

                    BaseText(
                      text: 'Sent On:',
                      textColor: ColorValues.labelColor,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 5),
                    BaseText(
                      text: Util.getConvertedDateStampNew(item.requestedDate),
                      textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: AppConstants.stringConstant.latoRegular,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      maxLines: 1,
                    ),
                  ],
                ),
        ],
      ),
    );
  }

  Padding skillView() {
    return PaddingWrap.paddingfromLTRB(
      0.0,
      24.0,
      0.0,
      0.0,
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: ColorValues.LIST_BOTTOM_BG,
              borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(10.0),
                  topRight: const Radius.circular(10.0)),
            ),
            child: Row(
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    6.0,
                    10.0,
                    10.0,
                    10.0,
                    Image.asset(
                      "assets/newDesignIcon/icon/skills_certi.png",
                      width: 35,
                      height: 35,
                    )),
                Expanded(
                  child: BaseText(
                    text: 'Skills & Certifications',
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                    maxLines: 2,
                  ),
                ),
                _hideShowButton(
                    value:
                        _mPublicProfileDataModel.result.isSkillAndCertification,
                    onChange: (value) {
                      setState(() {
                        _mPublicProfileDataModel
                            .result.isSkillAndCertification = value;
                        setToggel(_mPublicProfileDataModel.result.certificates,
                            value);
                      });
                    }),
                const SizedBox(width: 12),
              ],
            ),
          ),
          DisableView(
            isEnable: _mPublicProfileDataModel.result.isSkillAndCertification,
            child: Container(
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: ColorValues.SELECTION_BG,
                borderRadius: new BorderRadius.only(
                    bottomLeft: const Radius.circular(10.0),
                    bottomRight: const Radius.circular(10.0)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  _mPublicProfileDataModel.result != null &&
                          _mPublicProfileDataModel.result.skills != null &&
                          _mPublicProfileDataModel.result.skills.length > 0
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            PaddingWrap.paddingfromLTRB(
                                17.0,
                                10.0,
                                0.0,
                                12.0,
                                TextViewWrap.textViewSingleLine(
                                    "Skills",
                                    TextAlign.start,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    16.0,
                                    FontWeight.w500)),
                            Padding(
                              padding:
                                  const EdgeInsets.fromLTRB(13.0, 0, 13, 12),
                              child: _skillsItem(
                                  _mPublicProfileDataModel.result.skills),
                            ),
                          ],
                        )
                      : const SizedBox.shrink(),
                  _mPublicProfileDataModel.result != null &&
                          _mPublicProfileDataModel.result.certificates !=
                              null &&
                          _mPublicProfileDataModel.result.certificates.length >
                              0
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            PaddingWrap.paddingfromLTRB(
                                17.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap.textViewSingleLine(
                                    "Certifications",
                                    TextAlign.start,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    16.0,
                                    FontWeight.w500)),
                            Column(
                                children: List.generate(
                                    _mPublicProfileDataModel.result.certificates
                                        .length, (int index) {
                              return getCertificateItem(index);
                            })),
                          ],
                        )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Container getCertificateItem(index) {
    return Container(
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          borderRadius: BorderRadius.circular(10),
        ),
        margin: EdgeInsets.only(top: 10, bottom: 10, left: 12, right: 12),
        child: InkWell(
          child: PaddingWrap.paddingfromLTRB(
              5.0,
              8.0,
              5.0,
              8.0,
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  _mPublicProfileDataModel
                          .result.certificates[index].isProfileDisplay
                      ? Expanded(
                          child: InkWell(
                              onTap: () {
                                setState(() {
                                  _mPublicProfileDataModel
                                      .result
                                      .certificates[index]
                                      .isProfileDisplay = false;
                                });
                              },
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 5.0, 13.0, 5.0),
                                  child: Image.asset(
                                    "assets/newDesignIcon/icon/checked_box.png",
                                    height: 22.0,
                                    width: 22.0,
                                  ))),
                          flex: 0)
                      : Expanded(
                          child: InkWell(
                            child: Padding(
                                padding:
                                    EdgeInsets.fromLTRB(13.0, 5.0, 13.0, 5.0),
                                child: Image.asset(
                                  "assets/newDesignIcon/icon/uncheked_box.png",
                                  height: 22.0,
                                  width: 22.0,
                                )),
                            onTap: () {
                              setState(() {
                                _mPublicProfileDataModel
                                    .result
                                    .certificates[index]
                                    .isProfileDisplay = true;
                              });
                            },
                          ),
                          flex: 0),
                  // Expanded(
                  //   child: PaddingWrap.paddingfromLTRB(
                  //     0.0,
                  //     5.0,
                  //     10.0,
                  //     5.0,
                  //     _mPublicProfileDataModel.result.certificates[index].image == "" ||
                  //         _mPublicProfileDataModel.result.certificates[index].image == "null"
                  //         ? Image.asset(
                  //       "assets/portfolio/certificate.png",
                  //       height: 50.0,
                  //       width: 50.0,
                  //     )
                  //         : InkWell(
                  //       child: ClipRRect(
                  //         borderRadius: BorderRadius.circular(10.0), // Set the border radius here
                  //         child: Container(
                  //           height: 50.0,
                  //           width: 50.0,
                  //           child: FadeInImage.assetNetwork(
                  //             fit: BoxFit.cover,
                  //             placeholder: 'assets/portfolio/certificate.png',
                  //             image: Constant.IMAGE_PATH +
                  //                 _mPublicProfileDataModel.result.certificates[index].image,
                  //           ),
                  //         ),
                  //       ),
                  //
                  //
                  //       onTap: () {
                  //         Navigator.of(context).push(MaterialPageRoute(
                  //             builder: (BuildContext context) => FullImageView(
                  //               _mPublicProfileDataModel.result.certificates[index].image,
                  //             )));
                  //       },
                  //     ),
                  //   ),
                  //   flex: 0,
                  // ),

                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      10.0,
                      5.0,
                      _mPublicProfileDataModel
                                      .result.certificates[index].image ==
                                  "" ||
                              _mPublicProfileDataModel
                                      .result.certificates[index].image ==
                                  "null"
                          ? ProfileImageView(
                              imagePath: 'assets/portfolio/certificate.png',
                              placeHolderImage:
                                  'assets/portfolio/certificate.png',
                              width: 50.0,
                              height: 50.0,
                              onTap: () async {},
                              borderRadius: 10,
                              withoutShadow: true,
                            )
                          : ProfileImageView(
                              imagePath: Constant.IMAGE_PATH +
                                  _mPublicProfileDataModel
                                      .result.certificates[index].image,
                              placeHolderImage:
                                  'assets/portfolio/certificate.png',
                              width: 50.0,
                              height: 50.0,
                              onTap: () async {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        FullImageView(
                                          _mPublicProfileDataModel
                                              .result.certificates[index].image,
                                        )));
                              },
                              borderRadius: 10,
                              withoutShadow: true,
                            ),
                    ),
                    flex: 0,
                  ),

                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            5.0,
                            0.0,
                            Text(
                              _mPublicProfileDataModel
                                  .result.certificates[index].title,
                              maxLines: 5,
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily: Constant.latoMedium,
                                  fontSize: 14.0),
                            )),
                        const SizedBox(
                          height: 3,
                        ),
                        PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            0.0,
                            0.0,
                            Text(
                              'Received on: ' +
                                  Util.getConvertedDateStamp(
                                      _mPublicProfileDataModel
                                          .result.certificates[index].date
                                          .toString()),
                              style: TextStyle(
                                  color: ColorValues.labelColor,
                                  fontFamily: Constant.latoRegular,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12.0),
                            )),
                      ],
                    ),
                    flex: 1,
                  ),
                ],
              )),
          onTap: () {},
        ));
  }

  Widget _skillsItem(List<SkillID> skills) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: List<Widget>.generate(skills.length, (index) {
        return Container(
          padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            '${skills[index].name}',
            style: const TextStyle(
              fontSize: 12.0,
              fontFamily: Constant.latoRegular,
              fontWeight: FontWeight.w400,
              color: const Color(0xff4684EB),
            ),
          ),
        );
      }).toList(),
    );
  }

  Container getSelectedWidgets() {
    return Container(
      //color: Colors.redAccent,
      child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          primary: true,
          shrinkWrap: true,
          children: <Widget>[
            Wrap(
              spacing: 5.0,
              runSpacing: 0.0,
              children: List<Widget>.generate(
                  _mPublicProfileDataModel.result.skills.length,
                  // place the length of the array here
                  (int index) {
                //int h = _items[index].name.toString().length % 36;
                //print('Height h:::: $h');
                return InputChip(
                  label: Text(
                    '${_mPublicProfileDataModel.result.skills[index].name}',
                    overflow: TextOverflow.clip,
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  // softWrap: true,maxLines: 100,
                  //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  backgroundColor: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                  shape: StadiumBorder(
                    side: BorderSide(
                      color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                    ),
                  ),
                  onSelected: (bool value) {},

                  labelStyle: TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16,
                  ),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 5.0, vertical: 3.0),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget getUserInterestAndGoals() {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 24, 0, 0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: ColorValues.LIST_BOTTOM_BG,
              borderRadius: new BorderRadius.only(
                  topLeft: const Radius.circular(10.0),
                  topRight: const Radius.circular(10.0)),
            ),
            child: Row(
              children: <Widget>[
                PaddingWrap.paddingfromLTRB(
                    6.0,
                    10.0,
                    10.0,
                    10.0,
                    Image.asset(
                      "assets/newDesignIcon/icon/intrest_icon.png",
                      width: 35,
                      height: 35,
                    )),
                Expanded(
                  child: BaseText(
                    text: 'Interests ',
                    textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                    maxLines: 2,
                  ),
                ),
                _hideShowButton(
                    value: _mPublicProfileDataModel.result.isInterests,
                    onChange: (value) {
                      setState(() {
                        _mPublicProfileDataModel.result.isInterests = value;
                      });
                    }),
                const SizedBox(width: 12),
              ],
            ),
          ),
          DisableView(
            isEnable: _mPublicProfileDataModel.result.isInterests,
            child: Container(
                decoration: BoxDecoration(
                  color: ColorValues.SELECTION_BG,
                  borderRadius: new BorderRadius.only(
                      bottomLeft: const Radius.circular(10.0),
                      bottomRight: const Radius.circular(10.0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[

                    const SizedBox(width: 10),




                    // _mPublicProfileDataModel.result.goalInterests.length > 0
                    //     ? PaddingWrap.paddingfromLTRB(
                    //         17.0,
                    //         10.0,
                    //         17.0,
                    //         5.0,
                    //         TextViewWrap.textViewSingleLine(
                    //             "Interests",
                    //             TextAlign.start,
                    //             ColorValues.HEADING_COLOR_EDUCATION,
                    //             16.0,
                    //             FontWeight.w500))
                    //     : const SizedBox.shrink(),


                    PaddingWrap.paddingfromLTRB(
                      15.0,
                      12.0,
                      15.0,
                      12.0,
                      getUserInterestChips(
                          _mPublicProfileDataModel.result.loveOtherInterests),
                    ),

                    _mPublicProfileDataModel.result.goalInterests.length > 0
                        ? Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[

                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 5, bottom: 8, left: 15, right: 15),
                                child: Divider(
                                  height: 0,
                                  thickness: 1,
                                  color: Color(0xffE8ECFF),
                                ),
                              ),

                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 10, bottom: 5, left: 15, right: 15),
                                child: Text(
                                  'Future goals',
                                  style: TextStyle(
                                    color: const Color(0xff27275A),
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: AppConstants.stringConstant.latoMedium,
                                  ),
                                ),
                              ),

                              PaddingWrap.paddingfromLTRB(
                                  15.0,
                                  10.0,
                                  15.0,
                                  7.0,
                                  Text(
                                    "What’s next after high school?",overflow: TextOverflow.ellipsis,maxLines:1 ,
                                    textAlign: TextAlign.start,
                                    style:  TextStyle(
                                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: Constant.latoMedium),
                                  )
                              ),

                              //getUserInterestChips(goalInterestsList,false),
                              PaddingWrap.paddingfromLTRB(
                                15.0,
                                0.0,
                                15.0,
                                0.0,
                                getUserInterestChips(_mPublicProfileDataModel
                                    .result.goalInterests),
                              ),

                              _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          null &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          'null' &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          ''
                                  ? PaddingWrap.paddingfromLTRB(
                                      15.0,
                                      10.0,
                                      15.0,
                                      5.0,
                                      TextViewWrap.textViewSingleLine(
                                          "Institute(s)",
                                          TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                          16.0,
                                          FontWeight.w500))
                                  : const SizedBox.shrink(),
                              _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          null &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          'null' &&
                                      _mPublicProfileDataModel
                                              .result.goalInterestInstitute !=
                                          ''
                                  ? PaddingWrap.paddingfromLTRB(
                                      15.0,
                                      0.0,
                                      15.0,
                                      13.0,
                                      TextViewWrap.textViewSingleLine(
                                          "${_mPublicProfileDataModel.result.goalInterestInstitute}",
                                          TextAlign.start,
                                          ColorValues.HEADING_COLOR_EDUCATION,
                                          14.0,
                                          FontWeight.normal))
                                  : const SizedBox.shrink(),
                            ],
                          )
                        : const SizedBox.shrink(),
                    const SizedBox(height: 12),
                  ],
                )),
          ),
        ],
      ),
    );
  }

  getUserInterestChips(List<SkillID> _items) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return Container(
                      padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Visibility(
                            visible:
                                (_items[index]?.image?.isNotEmpty ?? false) &&
                                    _items[index]?.image != 'null',
                            child: Padding(
                              padding: const EdgeInsets.only(right: 5),
                              child: SvgPicture.network(
                                Constant.IMAGE_PATH +
                                    ParseJson.getMediumImage(
                                        _items[index].image),
                                width: 16,
                                height: 16,
                                color: AppConstants.colorStyle.lightBlue,
                                placeholderBuilder: (context) => Container(
                                    width: 16,
                                    height: 16,
                                    alignment: Alignment.center,
                                    child: const CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                    )), //placeholder while downloading file.
                              ),
                            ),
                          ),
                          Text(
                            '${_items[index].name}',
                            style: const TextStyle(
                              fontSize: 12.0,
                              fontFamily: Constant.latoRegular,
                              fontWeight: FontWeight.w500,
                              color: Color(0xff4684EB),
                            ),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        : const SizedBox.shrink();
  }

  Widget isImageOrVideo(FileDataModel _mPortFolioAssest, heigt, type) {
    return _mPortFolioAssest.type == "image"
        ? Container(
            height: heigt,
            child: CachedNetworkImage(
              width: double.infinity,
              height: heigt,
              imageUrl: Constant.IMAGE_PATH + _mPortFolioAssest.filePath,
              fit: BoxFit.cover,
              placeholder: (context, url) => _loader(
                  context,
                  type == "Sports"
                      ? "assets/portfolio/sport_default.png"
                      : "assets/portfolio/arts_default.png"),
              errorWidget: (context, url, error) => _error(type == "Sports"
                  ? "assets/portfolio/sport_default.png"
                  : "assets/portfolio/arts_default.png"),
            ))
        : Container(
            height: heigt,
            width: double.infinity,
            child: /*new VideoPlayPause(Constant.IMAGE_PATH + _mPortFolioAssest.file, "")*/

                VideoView(Constant.IMAGE_PATH + _mPortFolioAssest.filePath, "",
                    false, type));
  }

  Widget _storyItem(AccomplimentData narrative, int mainIndex) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xffF5F6FA),
        borderRadius: BorderRadius.circular(10),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xffE8ECFF),
            ),
            child: Row(
              children: [
                Expanded(
                  child: BaseText(
                    text: narrative.name,
                    textColor: const Color(0xff27275A),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: AppConstants.stringConstant.latoRegular,
                  ),
                ),
                const SizedBox(width: 10),
                _mAcoomplismentDataModel.accomplimentData.length > 1 &&
                        mainIndex <
                            _mAcoomplismentDataModel.accomplimentData.length - 1
                    ? InkWell(
                        onTap: () {
                          AccomplimentData model = _mAcoomplismentDataModel
                              .accomplimentData[mainIndex];
                          _mAcoomplismentDataModel.accomplimentData
                              .removeAt(mainIndex);
                          _mAcoomplismentDataModel.accomplimentData
                              .insert(mainIndex + 1, model);
                          setState(() {});
                        },
                        child: Image.asset(
                          'assets/experience/ic_item_down.png',
                          height: 24,
                          width: 24,
                        ),
                      )
                    : const SizedBox.shrink(),
                const SizedBox(width: 10),
                mainIndex > 0
                    ? InkWell(
                        onTap: () {
                          AccomplimentData model = _mAcoomplismentDataModel
                              .accomplimentData[mainIndex];
                          _mAcoomplismentDataModel.accomplimentData
                              .removeAt(mainIndex);
                          _mAcoomplismentDataModel.accomplimentData
                              .insert(mainIndex - 1, model);

                          setState(() {});
                        },
                        child: Image.asset(
                          'assets/experience/ic_item_up.png',
                          height: 24,
                          width: 24,
                        ),
                      )
                    : const SizedBox.shrink(),
              ],
            ),
          ),
          ListView.separated(
            itemBuilder: (_, index) {
              final achieveItem = narrative.achievement[index];
              int size = achieveItem.fileList.length;
              return Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(12),
                    child: achieveItem.type == "portfolio"
                        ? Container(
                            clipBehavior: Clip.antiAlias,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SizedBox(
                                  height: 190,
                                  child: Stack(
                                    children: [
                                      achieveItem.fileList.length < 4
                                          ? achieveItem.fileList.length == 0
                                              ? ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  child: Image.asset(
                                                    narrative.level1 == "Sports"
                                                        ? "assets/portfolio/sport_default.png"
                                                        : "assets/portfolio/arts_default.png",
                                                    fit: BoxFit.fill,
                                                    height: 190,
                                                  ),
                                                )
                                              : isImageOrVideo(
                                                  achieveItem
                                                      .fileList[size - 1],
                                                  190.0,
                                                  narrative.level1)
                                          : Column(
                                              children: [
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: isImageOrVideo(
                                                          achieveItem.fileList[
                                                              size - 1],
                                                          95.0,
                                                          narrative.level1),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                      child: isImageOrVideo(
                                                          achieveItem.fileList[
                                                              size - 2],
                                                          95.0,
                                                          narrative.level1),
                                                      flex: 1,
                                                    )
                                                  ],
                                                ),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: isImageOrVideo(
                                                          achieveItem.fileList[
                                                              size - 3],
                                                          95.0,
                                                          narrative.level1),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                      child: isImageOrVideo(
                                                          achieveItem.fileList[
                                                              size - 4],
                                                          95.0,
                                                          narrative.level1),
                                                      flex: 1,
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ),
                                      Positioned(
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        top: 0,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              gradient: const LinearGradient(
                                            colors: [
                                              Color(0xff000000),
                                              Color(0x7A000000),
                                              Color(0xB5000000),
                                            ],
                                            begin: Alignment.topCenter,
                                            end: Alignment.bottomCenter,
                                          )),
                                        ),
                                      ),
                                      Positioned(
                                        left: 14,
                                        top: 53,
                                        right: 10,
                                        child: Row(
                                          children: [
                                            Center(
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                clipBehavior: Clip.antiAlias,
                                                child: CachedNetworkImage(
                                                  imageUrl:
                                                      Constant.IMAGE_PATH +
                                                          achieveItem.userImage,
                                                  fit: BoxFit.cover,
                                                  height: 54,
                                                  width: 54,
                                                  placeholder: (context, url) =>
                                                      Image.asset(
                                                    "assets/profile/user_on_user.png",
                                                    height: 54,
                                                    width: 54,
                                                  ),
                                                  errorWidget:
                                                      (context, url, error) =>
                                                          Image.asset(
                                                    "assets/profile/user_on_user.png",
                                                    height: 54,
                                                    width: 54,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Expanded(
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  BaseText(
                                                    text: achieveItem.title,
                                                    fontSize: 16,
                                                    textColor: Colors.white,
                                                    fontWeight: FontWeight.w700,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    maxLines: 1,
                                                  ),
                                                  const SizedBox(height: 4),
                                                  BaseText(
                                                    text:
                                                        "${achieveItem?.city ?? ''}, ${achieveItem?.state ?? ''}",
                                                    fontSize: 14,
                                                    textColor: Colors.white,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily:
                                                        Constant.latoRegular,
                                                    maxLines: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      achieveItem?.personalReflection
                                                  ?.isNotEmpty ??
                                              false
                                          ? Positioned(
                                              right: 11,
                                              bottom: 16,
                                              child: InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    achieveItem
                                                            .isShowMorePersonalRef =
                                                        !(achieveItem
                                                            .isShowMorePersonalRef);
                                                  });
                                                },
                                                child: Image.asset(
                                                  'assets/experience/ic_inner_portfolio_list.png',
                                                  height: 28,
                                                  width: 28,
                                                ),
                                              ),
                                            )
                                          : const SizedBox.shrink(),
                                    ],
                                  ),
                                ),
                                /*  Visibility(
                            visible: achieveItem.isShowMorePersonalRef,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 14),
                                BaseText(
                                  text: "Personal reflection",
                                  textColor: const Color(0xff27275A),
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                  fontFamily: Constant.latoRegular,
                                ),
                                const SizedBox(height: 6),
                                _personalReflectionView(achieveItem),
                                const SizedBox(height: 14),
                              ],
                            ),
                          ),*/
                                InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            CustomPortFolioDetailsView(
                                          achieveItem: achieveItem,
                                          levelOneName: narrative.level1,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Container(
                                    color: const Color(0xff27275A),
                                    padding: const EdgeInsets.fromLTRB(
                                        12, 7, 12, 12),
                                    alignment: Alignment.center,
                                    child: BaseText(
                                      text: narrative.level1 == "Sports"
                                          ? "View sports portfolio"
                                          : "View arts portfolio",
                                      fontSize: 16,
                                      textColor: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: Constant.latoRegular,
                                      maxLines: 1,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                clipBehavior: Clip.antiAlias,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                height: 184,
                                child: achieveItem.mediaAndVideoList.isNotEmpty
                                    ? PageIndicatorContainer(
                                        pageView: PageView.builder(
                                          itemCount: achieveItem
                                              .mediaAndVideoList.length,
                                          controller: PageController(),
                                          itemBuilder: (_, innerIndex) {
                                            return InkWell(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Colors.black,
                                                ),
                                                child: achieveItem
                                                            .mediaAndVideoList[
                                                                innerIndex]
                                                            .type ==
                                                        "image"
                                                    ? CachedNetworkImage(
                                                        width: double.infinity,
                                                        height: 184,
                                                        imageUrl: Constant
                                                                .IMAGE_PATH +
                                                            achieveItem
                                                                .mediaAndVideoList[
                                                                    innerIndex]
                                                                .file,
                                                        fit: BoxFit.cover,
                                                        placeholder: (context,
                                                                url) =>
                                                            Util.loader(context,
                                                                "assets/aerial/default_img.png"),
                                                        errorWidget: (context,
                                                                url, error) =>
                                                            Util.error(
                                                                "assets/aerial/default_img.png"),
                                                      )
                                                    : Center(
                                                        child: VideoPlayPauseNew(
                                                            achieveItem
                                                                .mediaAndVideoList[
                                                                    innerIndex]
                                                                .file,
                                                            "",
                                                            false,
                                                            _scrollController),
                                                      ),
                                              ),
                                              onTap: () {
                                                print('dffgdfgg--------');
                                                Navigator.of(context).push(
                                                  MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                        CommonFullViewWidget(
                                                      achieveItem
                                                          .mediaAndVideoList,
                                                      MessageConstant
                                                          .ACCOMPLISHMENT_HEDING,
                                                      innerIndex,
                                                      achieveItem.title,
                                                    ),
                                                  ),
                                                );
                                              },
                                            );
                                          },
                                          onPageChanged: (index) {},
                                        ),
                                        align: IndicatorAlign.bottom,
                                        length: achieveItem
                                            .mediaAndVideoList.length,
                                        indicatorSpace: 10.0,
                                        indicatorColor: achieveItem
                                                    .mediaAndVideoList.length ==
                                                1
                                            ? Colors.transparent
                                            : const Color(0xffc4c4c4),
                                        indicatorSelectorColor: achieveItem
                                                    .mediaAndVideoList.length ==
                                                1
                                            ? Colors.transparent
                                            : const Color(0XFFFFFFFF),
                                        shape: IndicatorShape.circle(size: 5.0),
                                      )
                                    : Image.asset(
                                        "assets/profile/default_achievement.png",
                                        fit: BoxFit.cover,
                                        height: 184,
                                        width: double.infinity,
                                      ),
                              ),
                              const SizedBox(height: 8),
                              RichText(
                                textAlign: TextAlign.start,
                                maxLines: 15,
                                text: TextSpan(
                                  text: achieveItem.focusArea == null ||
                                          achieveItem.focusArea == "null" ||
                                          achieveItem.focusArea == ""
                                      ? achieveItem.level3Competency + " | "
                                      : achieveItem.focusArea + " | ",
                                  style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  children: [
                                    TextSpan(
                                      text: achieveItem.title,
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16,
                                        fontFamily: Constant.latoRegular,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 6),
                              BaseText(
                                text:
                                    "${Util.getConvertedDateStamp2(achieveItem.fromDate.toString())} - ${Util.getConvertedDateStamp2(achieveItem.toDate.toString())}",
                                textColor: const Color(0xff666B9A),
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                fontFamily: Constant.latoRegular,
                                maxLines: 1,
                              ),
                              achieveItem.hoursWorkedPerWeek != null &&
                                      achieveItem.hoursWorkedPerWeek !=
                                          "null" &&
                                      achieveItem.hoursWorkedPerWeek.trim() !=
                                          ""
                                  ? Padding(
                                      padding: const EdgeInsets.only(top: 6),
                                      child: BaseText(
                                        text:
                                        "Hours worked per week ${achieveItem?.hoursWorkedPerWeek ?? ''}",
                                        textColor: const Color(0xff666B9A),
                                        fontWeight: FontWeight.w400,
                                        fontSize: 12,
                                        fontFamily: Constant.latoRegular,
                                        maxLines: 1,
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                              const SizedBox(height: 5),
                              ReadMoreTextWidget(
                                text: achieveItem.description,
                              ),
                              achieveItem
                                      .all_badge_trophy_certificate.isNotEmpty
                                  ? Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(height: 11),
                                        BaseText(
                                          text:
                                              "Certificates, trophies & badges",
                                          textColor: const Color(0xff27275A),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                          fontFamily: Constant.latoRegular,
                                          maxLines: 1,
                                        ),
                                        const SizedBox(height: 7),
                                        SingleChildScrollView(
                                          scrollDirection: Axis.horizontal,
                                          child: Row(
                                            children: achieveItem
                                                .all_badge_trophy_certificate
                                                .map((e) {
                                              return Container(
                                                margin: const EdgeInsets.only(
                                                    right: 10),
                                                clipBehavior: Clip.antiAlias,
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                                //padding: const EdgeInsets.fromLTRB(9, 2, 8, 2),
                                                child: InkWell(
                                                  child: CachedNetworkImage(
                                                    height: 51,
                                                    width: 64,
                                                    imageUrl:
                                                        Constant.IMAGE_PATH +
                                                            e.file,
                                                    fit: BoxFit.cover,
                                                    placeholder: (context,
                                                            url) =>
                                                        Util.loader(context,
                                                            "assets/profile/default_achievement.png"),
                                                    errorWidget: (context, url,
                                                            error) =>
                                                        Util.error(
                                                            "assets/profile/default_achievement.png"),
                                                  ),
                                                  onTap: () {
                                                    Navigator.of(context).push(
                                                      new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            CommonFullViewWidget(
                                                          achieveItem
                                                              .all_badge_trophy_certificate,
                                                          MessageConstant
                                                              .CERTIFICATES_TROPHIES_HEDING,
                                                          achieveItem
                                                              .all_badge_trophy_certificate
                                                              .indexOf(e),
                                                          MessageConstant
                                                              .CERTIFICATES_TROPHIES_HEDING,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                ),
                                              );
                                            }).toList(),
                                          ),
                                        ),
                                      ],
                                    )
                                  : const SizedBox.shrink(),
                              Visibility(
                                  visible: achieveItem.externalLinks.isNotEmpty,
                                  child: _showExternalLinks(achieveItem)),
                              /*           achieveItem.personalReflection.isNotEmpty
                            ? Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Divider(
                              thickness: 1,
                              color: const Color(0xffC0C8DD),
                              height: 24,
                            ),
                            InkWell(
                              onTap: () {
                                setState(() {
                                  achieveItem.isShowPersonalReflection =
                                  !(achieveItem
                                      .isShowPersonalReflection);
                                });
                              },
                              child: Row(
                                children: [
                                  Flexible(
                                    child: BaseText(
                                      text: "Personal reflection",
                                      textColor:
                                      const Color(0xff27275A),
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                      fontFamily: Constant.latoRegular,
                                      maxLines: 1,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Icon(
                                    achieveItem?.isShowPersonalReflection ??
                                        false
                                        ? Icons.keyboard_arrow_up
                                        : Icons.keyboard_arrow_down,
                                    color: const Color(0xff7C89AD),
                                  ),
                                ],
                              ),
                            ),
                            Visibility(
                              visible:
                              achieveItem.isShowPersonalReflection,
                              child:
                              _personalReflectionView(achieveItem),
                            ),
                          ],
                        )
                            : const SizedBox.shrink(),*/
                            ],
                          ),
                  ),
                  Visibility(
                    visible:
                        narrative.achievement[index].isProfileDisplay ?? false,
                    child: Positioned(
                      left: 0,
                      right: 0,
                      top: 0,
                      bottom: 0,
                      child: CheckContainer(),
                    ),
                  ),
                  Positioned(
                    left: 26,
                    top: 24,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          narrative.achievement[index].isProfileDisplay =
                              !(narrative.achievement[index].isProfileDisplay ??
                                  false);
                          updaetAccomplismentToggel();
                        });
                      },
                      child: Image.asset(
                        narrative.achievement[index].isProfileDisplay ?? false
                            ? "assets/newDesignIcon/icon/checked_box.png"
                            : "assets/newDesignIcon/icon/uncheked_box.png",
                        height: 22.0,
                        width: 22.0,
                      ),
                    ),
                  ),
                ],
              );
            },
            shrinkWrap: true,
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: narrative.achievement?.length ?? 0,
            separatorBuilder: (_, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 24),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        color: const Color(0xffC0C8DD),
                        height: 1,
                      ),
                    ),
                    const SizedBox(width: 18),
                    InkWell(
                      onTap: () {
                        final model = _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement[index + 1];
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .removeAt(index + 1);
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .insert(index, model);
                        setState(() {});
                      },
                      child: Image.asset(
                        'assets/experience/ic_up_arrow_circle.png',
                        height: 40,
                        width: 40,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      color: const Color(0xffC0C8DD),
                      width: 8,
                      height: 1,
                    ),
                    const SizedBox(width: 6),
                    InkWell(
                      onTap: () {
                        final model = _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement[index];
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .removeAt(index);
                        _mAcoomplismentDataModel
                            .accomplimentData[mainIndex].achievement
                            .insert(index + 1, model);
                        setState(() {});
                      },
                      child: Image.asset(
                        'assets/experience/ic_down_arrow_circle.png',
                        height: 40,
                        width: 40,
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Container(
                        color: const Color(0xffC0C8DD),
                        height: 1,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _personalReflectionView(Achievement achieveItem) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ReadMoreTextWidget(
            text: achieveItem.personalReflection,
          ),
          const SizedBox(height: 10),
          BaseText(
            text:
                "Note : Personal Reflection is only for yourself, this is not sharable to anyone",
            textColor: const Color(0xff828282),
            fontWeight: FontWeight.w400,
            fontSize: 12,
            fontFamily: Constant.latoRegular,
            fontStyle: FontStyle.italic,
          ),
        ],
      ),
    );
  }

  Widget _showExternalLinks(Achievement achieveItem) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListView.separated(
          itemCount: achieveItem.externalLinks.length,
          itemBuilder: (_, exIndex) {
            final exItem = achieveItem.externalLinks[exIndex];
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BaseText(
                  text: "External links:",
                  textColor: const Color(0xff27275A),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: Constant.latoRegular,
                  maxLines: 1,
                ),
                const SizedBox(height: 7),
                InkWell(
                  onTap: () {
                    if (exItem.url.toLowerCase().contains("https") ||
                        exItem.url.toLowerCase().contains("http")) {
                      launch(exItem.url.trim());
                    } else {
                      launch("https://" + exItem.url.trim());
                    }
                  },
                  child: BaseText(
                    text: exItem.label,
                    textColor: const Color(0xff4684EB),
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                    fontFamily: Constant.latoRegular,
                    maxLines: 3,
                    textDecoration: TextDecoration.underline,
                  ),
                ),
                const SizedBox(height: 11),
                BaseText(
                  text: "External description:",
                  textColor: const Color(0xff27275A),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: Constant.latoRegular,
                  maxLines: 1,
                ),
                const SizedBox(height: 5),
                ReadMoreTextWidget(
                  text: exItem.description,
                  textStyle: TextStyle(
                    color: Color(0xff666B9A),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            );
          },
          separatorBuilder: (_, ind) => const SizedBox(height: 10),
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(0, 11, 0, 0),
          physics: const NeverScrollableScrollPhysics(),
        ),
      ],
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      //  var formatter =   DateFormat('MMM dd, yyyy');
      //return formatter.format(new DateTime.now());
      return "Ongoing";
    }
  }

  int getLenthOfName() {
    int lenght = 0;
    if (_mPublicProfileDataModel.result == null) {
      return 0;
    } else {
      if (_mPublicProfileDataModel.result.lastName == null ||
          _mPublicProfileDataModel.result.lastName == "" ||
          _mPublicProfileDataModel.result.lastName == "null") {
        lenght = 0;
      } else {
        lenght = _mPublicProfileDataModel.result.firstName.length +
            _mPublicProfileDataModel.result.lastName.length;
      }
    }

    return lenght;
  }

  bool dobCheck(String time) {
    if (time != "null" || time != "") {
      int millis = int.tryParse(time);
      DateTime bod = DateTime.fromMillisecondsSinceEpoch(millis);
      int diffrenceInDob = DateTime.now().year - bod.year;

      print("dOB year +++++ ${bod.year}");
      print("current year +++++ ${new DateTime.now().year}");
      print("diffrenceInDob+day+++++" + diffrenceInDob.toString());

      DateTime currentDate = DateTime.now();
      int age = currentDate.year - bod.year;

      if (age > 13) {
        return true;
      }
      if (age == 13) {
        print("apurva equal" + '$age');
        int month1 = currentDate.month;
        int month2 = bod.month;
        if (month2 > month1) {
          print("apurva below" + '$age');
          _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
          return false;
        } else if (month1 == month2) {
          int day1 = currentDate.day;
          int day2 = bod.day;
          if (day2 > day1) {
            print("apurva below" + '$age');
            _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
            return false;
          } else {
            print("apurva equal or above" + '$age');
            return true;
          }
        } else {
          print("apurva equal or above" + '$age');
          return true;
        }
      } else {
        _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
        return false;
      }
    } else {
      _mPublicProfileDataModel.result.isDisplaySocialEmail = false;
      return false;
    }
  }

  showSucessMsg(msg, context, type) {
    Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      if (widget.profileType == "Connected") {
        if (type == "resend") {
          Navigator.pop(context, "push");
        } else if (isLinearView) {
          List<double> spiderChartList1 = List<double>();
          List<String> spiderChartName1 = List<String>();
          spiderChartList1.addAll(spiderChartList);
          spiderChartName1.addAll(spiderChartName);
          String result = await Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => PublicProfilePreViewWidget(
                  _mPublicProfileDataModel.result.isDisplaySocialEmail,
                  isGPA,
                  _mPublicProfileDataModel,
                  _mAcoomplismentDataModel,
                  Constant.PUBLIC_URL_PATH + widget.publicUrl,
                  widget.profileType,
                  userIdPref,
                  false,
                  widget.isParentCalling)));
          if (result == "push") {
            Navigator.pop(context, "push");
          }
        } else {
          try {
            String result = await Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) => CustomPresoViewForUser(
                    widget.publicUrl,
                    "preview",
                    "Public",
                    widget.isUnderThirteen.toString(),
                    Constant.PUBLIC_URL_PATH + widget.publicUrl)));
            if (result == "push") {
              Navigator.pop(context, "push");
            }
          } catch (e) {
            print('Exception 111 e: $e');
          }
        }
      } else {
        String result = await Navigator.of(context).push(MaterialPageRoute(
            builder: (BuildContext context) => publishwWidget(
                _mPublicProfileDataModel.result.isDisplaySocialEmail,
                isGPA,
                _mPublicProfileDataModel,
                _mAcoomplismentDataModel,
                widget.profileType,
                widget.isUnderThirteen.toString(),
                isLinearView,
                widget.publicUrl,
                widget.isParentCalling,
                userIdPref)));
        if (result == "push") {
          Navigator.pop(context, "push");
        }
      }
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCallingResend() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //assestList.removeAt(0);
        CustomProgressLoader.showLoader(context);

        Map map = {
          "userId": userIdPref,
          "profileId": _mPublicProfileDataModel.result.profileId,
        };

        print('map++++++++++++' + map.toString());

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_RESEND_PROFILE, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              showSucessMsg(msg, context, "resend");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCalling(isApproval) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        if (isGPA) {
          _mPublicProfileDataModel.result.isGpa = true;
        } else {
          _mPublicProfileDataModel.result.isGpa = false;
        }
        //assestList.removeAt(0);
        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "profileType": widget.profileType,
          "profileView": isLinearView ? "Linear" : "Preso",
          "isSummary":
              true /* widget.profileType == "Connected"
              ? true
              : _mPublicProfileDataModel.result.isSummary*/
          ,
          "isIntroVideo": widget.profileType == "Connected"
              ? true
              : _mPublicProfileDataModel.result.isIntroVideo,
          "isInterests": _mPublicProfileDataModel.result.isInterests,
          "isResume": _mPublicProfileDataModel.result.isResume,
          "education": {
            "isEducations": widget.profileType == "Connected"
                ? true
                : _mPublicProfileDataModel.result.isEducations,
            "isGpa": isGPA,
            "educationIds": _mPublicProfileDataModel.result.isEducations
                ? _mPublicProfileDataModel.result.educations.toJson()
                : []
          },
          "accomplishment": {
            "isAccomplishment":
                _mPublicProfileDataModel.result.isAccomplishment,
            "accomplishmentIds":
                /* _mPublicProfileDataModel.result.isAccomplishment
                ?*/
                _mAcoomplismentDataModel.toJson()
            // : [],
            ,
            "sortOrder": _mPublicProfileDataModel.result.isAccomplishment
                ? _mAcoomplismentDataModel.toJsonSortOrder()
                : [],
            "categorySortOrder":
                _mPublicProfileDataModel.result.isAccomplishment
                    ? _mAcoomplismentDataModel.toJsonCategoryOrder()
                    : [],
          },
          "recommendation": {
            "isRecommendation":
                _mPublicProfileDataModel.result.isRecommendation,
            "recommendationIds":
                /*  _mPublicProfileDataModel.result.isRecommendation
                ?*/
                _mPublicProfileDataModel.result.toJsonRec()
            //  : []
          },
          "badges": {
            "isBadges": _mPublicProfileDataModel.result.isBadges,
            "badgeReqIds": _mPublicProfileDataModel.result.badges == null ||
                    _mPublicProfileDataModel.result.badges.collections.length ==
                        0
                ? []
                : /*_mPublicProfileDataModel.result.isBadges
                ?*/
                _mPublicProfileDataModel.result.badges.toJsonBadge()
            // : []
          },
          "testScore": {
            "isTestScore": _mPublicProfileDataModel.result.isTestScore,
            "userTestIds":
                /*_mPublicProfileDataModel.result.isTestScore
                ?*/
                _mPublicProfileDataModel.result.toJsonTestScore()
            //  : []
          },
          "skillAndCertification": {
            "isSkillAndCertification":
                _mPublicProfileDataModel.result.isSkillAndCertification,
            "certificateIds":
                /*_mPublicProfileDataModel.result.isSkillAndCertification
                ?*/
                _mPublicProfileDataModel.result.toJsonCertificate()
            // : []
          },
          "socialLinks": {
            "isSocialLinks": _mPublicProfileDataModel.result.isSocialLinks,
            "isDisplaySocialEmail": widget.profileType == "Connected"
                ? (!dobCheck(widget.dob))
                    ? false
                    : _mPublicProfileDataModel.result.isDisplaySocialEmail
                : _mPublicProfileDataModel.result.isDisplaySocialEmail,
            "socialLinkIds":
                /*_mPublicProfileDataModel.result.isSocialLinks
                ?*/
                _mPublicProfileDataModel.result.toJsonLink()
            //: []
          },
          "linkExpirationDate": "",
          "parentId": widget.isParentCalling
              ? prefs.getString(UserPreference.PARENT_ID)
              : ""
        };
        print("map++++:-" + map.toString());
        Response response = await ApiCalling2().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_PROFILEL, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              if (isApproval) {
                showSucessMsg(msg, context, "");
              } else {
                if (widget.profileType == "Connected") {
                  if (isLinearView) {
                    List<double> spiderChartList1 = List<double>();
                    List<String> spiderChartName1 = List<String>();
                    spiderChartList1.addAll(spiderChartList);
                    spiderChartName1.addAll(spiderChartName);
                    print("PublicProfilePreViewWidget redirection");
                    String result = await Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (BuildContext context) =>
                                PublicProfilePreViewWidget(
                                    _mPublicProfileDataModel
                                        .result.isDisplaySocialEmail,
                                    isGPA,
                                    _mPublicProfileDataModel,
                                    _mAcoomplismentDataModel,
                                    Constant.PUBLIC_URL_PATH + widget.publicUrl,
                                    widget.profileType,
                                    userIdPref,
                                    widget.isParentCalling,
                                    false)));
                    if (result == "push") {
                      Navigator.pop(context, "push");
                    }
                  } else {
                    try {
                      print("CustomPresoViewForUser redirection");

                      String result = await Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  CustomPresoViewForUser(
                                      widget.publicUrl,
                                      "preview",
                                      "Public",
                                      widget.isUnderThirteen.toString(),
                                      Constant.PUBLIC_URL_PATH +
                                          widget.publicUrl)));
                      if (result == "push") {
                        Navigator.pop(context, "push");
                      }
                    } catch (e) {
                      print('Exception 111 e: $e');
                    }
                  }
                } else {
                  if (widget.isFirstTimeCalling) {
                    print("publishwWidget redirection");

                    String result = await Navigator.of(context).push(
                        MaterialPageRoute(
                            builder: (BuildContext context) => publishwWidget(
                                _mPublicProfileDataModel
                                    .result.isDisplaySocialEmail,
                                isGPA,
                                _mPublicProfileDataModel,
                                _mAcoomplismentDataModel,
                                widget.profileType,
                                widget.isUnderThirteen.toString(),
                                isLinearView,
                                widget.publicUrl,
                                widget.isParentCalling,
                                userIdPref)));
                    if (result == "push") {
                      Navigator.pop(context, "push");
                    }
                  } else {
                    if (isLinearView) {
                      List<double> spiderChartList1 = List<double>();
                      List<String> spiderChartName1 = List<String>();
                      spiderChartList1.addAll(spiderChartList);
                      spiderChartName1.addAll(spiderChartName);
                      print("PublicProfilePreViewWidget redirection");

                      String result = await Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  PublicProfilePreViewWidget(
                                      _mPublicProfileDataModel
                                          .result.isDisplaySocialEmail,
                                      isGPA,
                                      _mPublicProfileDataModel,
                                      _mAcoomplismentDataModel,
                                      Constant.PUBLIC_URL_PATH +
                                          widget.publicUrl,
                                      widget.profileType,
                                      userIdPref,
                                      widget.isParentCalling,
                                      widget.isFirstTimeCalling)));
                      if (result == "push") {
                        Navigator.pop(context, "push");
                      }
                    } else {
                      try {
                        print("CustomPresoViewForUser redirection");

                        String result = await Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    CustomPresoViewForUser(
                                        widget.publicUrl,
                                        "preview",
                                        "Public",
                                        widget.isUnderThirteen.toString(),
                                        Constant.PUBLIC_URL_PATH +
                                            widget.publicUrl)));
                        if (result == "push") {
                          Navigator.pop(context, "push");
                        }
                      } catch (e) {
                        print('Exception 111 e: $e');
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("data errorr++++++++++++++" + e.toString());
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  customUrlUI() {
    //UI for LinkExpire
    return PaddingWrap.paddingfromLTRB(
      0.0,
      13.0,
      0.0,
      0.0,
      Container(
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: ColorValues.BORDER_COLOR, width: 0.5)),
          child: PaddingWrap.paddingfromLTRB(
              13.0,
              13.0,
              13.0,
              4.0,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        2.0,
                        10.0,
                        0.0,
                        Image.asset(
                          "assets/newIcon/customurl.png",
                          width: 30,
                          height: 30,
                        )),
                    flex: 0,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            0.0,
                            0.0,
                            0.0,
                            TextViewWrap.textViewSingleLine(
                                "Create your custom URL link",
                                TextAlign.start,
                                ColorValues.HEADING_COLOR_EDUCATION,
                                16.0,
                                FontWeight.bold)),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            7.0,
                            TextViewWrap.textViewMultiLine(
                                "Link cannot change once set, so set it to something you will remember and can easily share with others.",
                                TextAlign.start,
                                ColorValues.GREY__COLOR,
                                14.0,
                                FontWeight.normal,
                                3)),
                        Container(
                          height: 30,
                          child: Row(
                            children: [
                              Expanded(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    2.0,
                                    0.0,
                                    TextViewWrap.textViewSingleLine(
                                        "www.spikeview.com/sv/",
                                        TextAlign.start,
                                        ColorValues.GREY__COLOR,
                                        16.0,
                                        FontWeight.normal)),
                                flex: 0,
                              ),
                              Expanded(
                                child: TextFormField(
                                  keyboardType: TextInputType.text,
                                  maxLength: 50,
                                  controller: publicUrlController,
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                  decoration: InputDecoration(
                                    counterText: "",
                                    contentPadding: const EdgeInsets.fromLTRB(
                                        5.0, 0.0, 5.0, 0.0),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(0.0),
                                      gapPadding: 0.0,
                                      borderSide: BorderSide(
                                          color: ColorValues.GREY__COLOR,
                                          width: 0.0),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      gapPadding: 0.0,
                                      borderSide: BorderSide(
                                          color: ColorValues.GREY__COLOR,
                                          width: 0.0),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      gapPadding: 0.0,
                                      borderSide: BorderSide(
                                          color: ColorValues.GREY__COLOR,
                                          width: 0.0),
                                    ),
                                    disabledBorder: OutlineInputBorder(
                                      gapPadding: 0.0,
                                      borderSide: BorderSide(
                                          color: ColorValues.GREY__COLOR,
                                          width: 0.0),
                                    ),
                                  ),
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                        !isTextField
                            ? PaddingWrap.paddingfromLTRB(
                                0.0,
                                10.0,
                                0.0,
                                0.0,
                                TextViewWrap.textViewMultiLine(
                                    errorText,
                                    TextAlign.start,
                                    ColorValues.ERROR_COLOR,
                                    14.0,
                                    FontWeight.normal,
                                    3))
                            : Container(
                                height: 0.0,
                              ),
                        getgridBadges(),
                        PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            7.0,
                            TextViewWrap.textViewMultiLine(
                                "Note: Your custom URL must contain 4-50 letters or numbers. Please do not use spaces, symbols, or special characters.",
                                TextAlign.start,
                                ColorValues.GREY__COLOR,
                                14.0,
                                FontWeight.normal,
                                5)),
                      ],
                    ),
                    flex: 1,
                  ),
                ],
              ))),
    );
  }

  linkExpireUI() {
    //UI for LinkExpire
    return PaddingWrap.paddingfromLTRB(
      0.0,
      13.0,
      0.0,
      0.0,
      Container(
          child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  border:
                      Border.all(color: ColorValues.BORDER_COLOR, width: 0.5)),
              child: PaddingWrap.paddingfromLTRB(
                  13.0,
                  13.0,
                  13.0,
                  4.0,
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            2.0,
                            10.0,
                            0.0,
                            Image.asset(
                              "assets/story_new/link.png",
                              width: 30,
                              height: 30,
                            )),
                        flex: 0,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                7.0,
                                TextViewWrap.textViewMultiLine(
                                    "Select the view of your profile you want to share",
                                    TextAlign.start,
                                    ColorValues.HEADING_COLOR_EDUCATION,
                                    16.0,
                                    FontWeight.bold,
                                    2)),

                            /* PaddingWrap.paddingfromLTRB(
                                0.0,
                                5.0,
                                0.0,
                                7.0,
                                TextViewWrap.textViewMultiLine(
                                    "You control your profile’s appearance for people who are not signed in to spikeview. ",
                                    TextAlign.start,
                                      ColorValues.GREY_TEXT_COLOR,
                                    14.0,
                                    FontWeight.bold,
                                    3)),*/

                            InkWell(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    child: Image.asset(
                                        isLinearView
                                            ? "assets/newDesignIcon/group/check_radio.png"
                                            : "assets/newDesignIcon/group/uncheck_radio.png",
                                        height: 22,
                                        width: 22),
                                    flex: 0,
                                  ),
                                  Expanded(
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(left: 10.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          TextViewWrap.textViewMultiLine(
                                              "Linear View",
                                              TextAlign.start,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              14.0,
                                              FontWeight.normal,
                                              1),
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              5.0,
                                              0.0,
                                              10.0,
                                              TextViewWrap.textViewMultiLine(
                                                  "Your profile will be vertically scrollable by viewers.",
                                                  TextAlign.start,
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  12.0,
                                                  FontWeight.normal,
                                                  3)),
                                        ],
                                      ),
                                    ),
                                    flex: 1,
                                  )
                                ],
                              ),
                              onTap: () {
                                if (isLinearView) {
                                } else {
                                  setState(() {
                                    isLinearView = true;
                                    isPresoView = false;
                                  });
                                }
                              },
                            ),
                            InkWell(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    child: Image.asset(
                                        isPresoView
                                            ? "assets/newDesignIcon/group/check_radio.png"
                                            : "assets/newDesignIcon/group/uncheck_radio.png",
                                        height: 22,
                                        width: 22),
                                    flex: 0,
                                  ),
                                  Expanded(
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(left: 10.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          TextViewWrap.textViewMultiLine(
                                              "Presentation View",
                                              TextAlign.start,
                                              ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              14.0,
                                              FontWeight.normal,
                                              1),
                                          PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              5.0,
                                              0.0,
                                              10.0,
                                              TextViewWrap.textViewMultiLine(
                                                  "Your profile will be seen as a presentation by the viewers.",
                                                  TextAlign.start,
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  12.0,
                                                  FontWeight.normal,
                                                  3)),
                                        ],
                                      ),
                                    ),
                                    flex: 1,
                                  )
                                ],
                              ),
                              onTap: () {
                                if (isPresoView) {
                                } else {
                                  setState(() {
                                    isLinearView = false;
                                    isPresoView = true;
                                  });
                                }
                              },
                            ),
                          ],
                        ),
                        flex: 1,
                      ),
                    ],
                  )))),
    );
  }

  Future apiCallForPublicURL() async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "publicProfileUrl": publicUrlController.text.toString().trim(),
      };

      print("map:-" + map.toString());

      response = await ApiCalling().apiCallPostWithMapData(
          context, Constant.ENDPOINT_CREATE_PUBLIC_URL, map);
      print("publicProfileUrl response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          _mPublicUrlModel = PublicUrlModel.fromJson(response.data);
          if (_mPublicUrlModel != null) {
            if (_mPublicUrlModel.status == "Success") {
              syncDoneController.add("sucess");
              widget.publicUrl = publicUrlController.text.toString().trim();
              setState(() {});
              apiCalling(false);
            } else if (_mPublicUrlModel.status == "Error") {
              errorText = _mPublicUrlModel.message;
              isTextField = false;
              setState(() {});
            }
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
    }
  }

  Container getgridBadges() {
    return _mPublicUrlModel != null && _mPublicUrlModel.result.length > 0
        ? Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            child: Column(
              children: <Widget>[
                Row(
                  children: [
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Text(
                            "Available:",
                            style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION,
                                fontSize: 14,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR),
                          )),
                      flex: 0,
                    ),
                    Expanded(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          Container(
                              height: 35.0,
                              child: GridView.count(
                                primary: true,
                                scrollDirection: Axis.horizontal,
                                padding: const EdgeInsets.all(5.0),
                                crossAxisCount: 1,
                                childAspectRatio: .30,
                                mainAxisSpacing: 5.0,
                                crossAxisSpacing: 4.0,
                                children: List.generate(
                                    _mPublicUrlModel.result.length,
                                    (int index2) {
                                  return Container(
                                      child: InkWell(
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        5.0,
                                        0.0,
                                        0.0,
                                        Text(
                                          _mPublicUrlModel.result[index2],
                                          style: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 14,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                    onTap: () {
                                      publicUrlController.text =
                                          _mPublicUrlModel.result[index2];
                                      setState(() {});
                                    },
                                  ));
                                }),
                              ))),
                      flex: 1,
                    ),
                  ],
                )

                /*
              PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  0.0,
                  0.0,
                    Container(
                      height: 48.0,
                      child:   GridView.count(
                        primary: true,
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.all(5.0),
                        crossAxisCount: 1,
                        childAspectRatio: .50,
                        mainAxisSpacing: 5.0,
                        crossAxisSpacing: 4.0,
                        children:   List.generate(
                            _mPublicUrlModel.result.length, (int index2) {
                          return   Container(

                              child:   InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                     Text( _mPublicUrlModel.result[index2],style:   TextStyle(color:
                                     ColorValues.BLUE_COLOR_BOTTOMBAR,fontSize: 14,fontFamily: Constant.TYPE_CUSTOMREGULAR
                                   ),)),
                                onTap: () {

                                },
                              ));
                        })


                        ,
                      ))),*/
              ],
            ))
        : Container(
            height: 1.0,
          );
  }
}
