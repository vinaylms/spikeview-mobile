class PromptsIds {
  bool status;
  List<Result> result;

  PromptsIds({this.status, this.result});

  PromptsIds.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result = <Result>[];
      json['result'].forEach((v) {
        result.add(new Result.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Result {
  int promptId;
  String inputField;
  String module;

  Result({this.promptId, this.inputField, this.module});

  Result.fromJson(Map<String, dynamic> json) {
    promptId = json['prompt_id']??0;
    inputField = json['inputField']??"";
    module = json['module']??"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['prompt_id'] = this.promptId;
    data['inputField'] = this.inputField;
    data['module'] = this.module;
    return data;
  }
}

