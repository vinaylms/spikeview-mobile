class CollegeInfoDetailModel {
  String status;
  List<CollegeInfoResult> result;

  CollegeInfoDetailModel({this.status, this.result});

  CollegeInfoDetailModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<CollegeInfoResult>();
      json['result'].forEach((v) {
        result.add(new CollegeInfoResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CollegeInfoResult {
  int organizationId;
  String name;
  String description;
  String type;
  String logo;

  CollegeInfoResult(
      {this.organizationId, this.name, this.description, this.type, this.logo});

  CollegeInfoResult.fromJson(Map<String, dynamic> json) {
    organizationId = json['organizationId'];
    name = json['name'];
    description = json['description'].toString();
    type = json['type'];
    logo = json['logo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['organizationId'] = this.organizationId;
    data['name'] = this.name;
    data['description'] = this.description;
    data['type'] = this.type;
    data['logo'] = this.logo;
    return data;
  }
}
