import 'dart:io';

class ConnectionModel {
  String connectId,userId,partnerId,dateTime,status;
  int lastSeen,online;
  ConnectionModel(this.connectId, this.userId, this.partnerId, this.dateTime,
      this.status,this.lastSeen,this.online);


}

