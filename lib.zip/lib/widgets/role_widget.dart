import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';

class RoleWidget extends StatelessWidget {
  final String name;
  final String role;
  final String profile;
  final VoidCallback onTap;
  const RoleWidget({
    @required this.name,
    @required this.role,
    @required this.profile,
    @required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            clipBehavior: Clip.antiAlias,
            child: CachedNetworkImage(
              height: 48,
              width: 48,
              fit: BoxFit.cover,
              imageUrl: Constant.IMAGE_PATH + profile,
              placeholder: (_, str) {
                return Center(
                  child: SizedBox(
                    height: 48,
                    width: 48,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(Colors.black54),
                      strokeWidth: 2.0,
                    ),
                  ),
                );
              },
              errorWidget: (_, str, e) {
                return Image.asset(
                  "assets/profile/user_on_user.png",
                  height: 48,
                  width: 48,
                  fit: BoxFit.fill,
                );
              },
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                BaseText(
                  text: name,
                  textColor: const Color(0xff27275A),
                  fontFamily: Constant.latoRegular,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                SizedBox(height: 5,),
                BaseText(
                  text: role,
                  textColor: const Color(0xff666B9A),
                  fontFamily: Constant.latoRegular,
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
