import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';

class SelectedDesignationModel {
  int index;
  String name;

  SelectedDesignationModel(this.index, this.name);

}



