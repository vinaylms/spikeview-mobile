import 'dart:io';
import 'package:flutter/material.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';

import 'NarrativeModel.dart';

class UserPostModal {
  String _id,
      feedId,
      postedBy,
      
      dateTime,
      visibility,
      firstName,
      lastName,
      email,
      profilePicture,
      title,
      tagline,
      shareText,
      shareTime,
      postOwner,
      postOwnerFirstName,
      postOwnerLastName,
      postOwnerTitle,
      postOwnerProfilePicture,
      lastActivityTime,
      lastActivityType,
      postOwnerRoleId,postedGroupName,postedGroupId,
      roleId,dateTime2,schoolCode;
  OpportunityModelForFeed opportunityModelForFeed;
  WebLinksModel webLinkModel;

  bool isReadMore = false;
  bool isLiked = false;
  bool isShareMore = false;
  PostData postdata;
  List<CommentData> commentList;
  List<Likes> likeList;
  List<Tags> tagList;
  List<Groups> groupList;
  List<ScopeModel> scopeList;
  bool isLike;
  bool isCommented;
  bool isCommentViewMore;
  bool isShowCommentIcon;
  bool postOwnerDeleted;
  bool isOpportunity;
  bool isCommentIconVisible = false;
  TextEditingController txtController;
  String isReported;

  String badge,feedStatus;
  String badgeImage;

  int gamificationPoints;
  int likesCount;
  List<String> reasonList;
  String reasonText;
  String postOwnerBadge;
  String postOwnerBadgeImage;
  int postOwnerGamificationPoints;


  UserPostModal(
      this._id,
      this.feedId,
      this.postedBy,
      this.isLiked,
      this.dateTime,
      this.visibility,
      this.firstName,
      this.lastName,
      this.email,
      this.profilePicture,
      this.title,
      this.tagline,
      this.shareText,
      this.shareTime,
      this.postOwner,
      this.postOwnerFirstName,
      this.postOwnerLastName,
      this.postOwnerTitle,
      this.postOwnerProfilePicture,
      this.isLike,
      this.isCommented,
      this.postdata,
      this.commentList,
      this.likeList,
      this.tagList,
      this.groupList,
      this.scopeList,
      this.isCommentIconVisible,
      this.txtController,
      this.lastActivityTime,
      this.lastActivityType,
      this.isReadMore,
      this.isShareMore,
      this.isCommentViewMore,
      this.isShowCommentIcon,
      this.isReported,
      this.isOpportunity,
      this.postOwnerRoleId,
      this.roleId,
      this.postOwnerDeleted,
      this.opportunityModelForFeed,
      this.webLinkModel,this.postedGroupName,this.postedGroupId,this.badge,this.gamificationPoints,this.likesCount
      ,this.badgeImage,this.postOwnerBadge,this.postOwnerGamificationPoints,this.postOwnerBadgeImage,this.dateTime2,this.feedStatus,this.schoolCode,{this.reasonList,this.reasonText});



}

class PostData {
  List<String> imageList;
  List<AssetIV>assetsList;
  String text, media;
  bool isShowMore=false;
  String metaUrl,
      metaSource,
      metaHeight,
      metaWidth,
      metaTitle,
      metaDescription,
      metaImage;

  PostData(
      this.imageList,
      this.assetsList,
      this.text,
      this.media,
      this.metaUrl,
      this.metaSource,
      this.metaHeight,
      this.metaWidth,
      this.metaTitle,
      this.metaDescription,
      this.metaImage);
}


class CommentData {
  bool isLike;
  bool isComment;
  String commentId,
      comment,
      commentedBy,
      dateTime,
      profilePicture,
      name,
      title,
      userId,
      roleId;
  List<Likes> likesList;

  String badge;
  String badgeImage;
  int gamificationPoints;
  CommentData(
      this.commentId,
      this.comment,
      this.commentedBy,
      this.dateTime,
      this.profilePicture,
      this.name,
      this.title,
      this.userId,
      this.likesList,
      this.isLike,
      this.roleId,this.badge,this.gamificationPoints,this.badgeImage,this.isComment);


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['commentId'] = this.commentId;
    data['comment'] = this.comment;
    data['commentedBy'] = this.commentedBy;
    data['commentRoleId'] = this.roleId;

    data['dateTime'] = this.dateTime;
    if (this.likesList != null) {
      data['likes'] = this.likesList.map((v) => v.toJson()).toList();
    }
    data['profilePicture'] = this.profilePicture;
    data['name'] = this.name;
    data['userId'] = this.userId;
    data['roleId'] = this.roleId;
    data['badge'] = this.badge;
    data['badgeImage'] = this.badgeImage;
    data['gamificationPoints'] = this.gamificationPoints;
    data['title'] = this.title;
    return data;
  }
}

class ScopeModel {
  String userId,  roleId;


  ScopeModel(this.userId,  this.roleId);
}

class Likes {
  String userId, name, profilePicture, title, status, statusValue, roleId;
  String badge;
  String badgeImage;
  int gamificationPoints;

  Likes(this.userId, this.name, this.profilePicture, this.title, this.status,
      this.statusValue, this.roleId,this.badge,this.gamificationPoints,this.badgeImage);


  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['userId'] = this.userId;
    data['roleId'] = this.roleId;
    data['dateTime'] = "";
    data['name'] = this.name;
    data['profilePicture'] = this.profilePicture;
    data['status'] = this.status;
    data['statusValue'] = this.statusValue;
    data['title'] = this.title;
    data['badge'] = this.badge;
    data['badgeImage'] = this.badgeImage;
    data['gamificationPoints'] = this.gamificationPoints;
    return data;
  }

}
class LikeDetailModel {
  String id;
  String likedBy;
  String likedByRole;
  String createdAt;
  String profilePicture;
  String firstName;
  String lastName;
  String statusValue;
  String status;

  LikeDetailModel(
      this.id,
      this.likedBy,
      this.likedByRole,
      this.createdAt,
      this.profilePicture,
      this.firstName,
      this.lastName,
      this.statusValue,
      this.status,
      );



  Map<String, dynamic> toJson() => {
    "_id": id,
    "likedBy": likedBy,
    "likedByRole": likedByRole,
    "createdAt": createdAt,
    "profilePicture": profilePicture,
    "firstName": firstName,
    "lastName": lastName,
    "statusValue": statusValue,
    "status": status,
  };
}

class CommentDetailModel {
  String id;
  String comment;
  String commentedBy;
  String commentedByRole;
  String createdAt;
  String profilePicture;
  String firstName;
  String lastName;
  String badge;
  String badgeImage;

  CommentDetailModel(
      this.id,
      this.comment,
      this.commentedBy,
      this.commentedByRole,
      this.createdAt,
      this.profilePicture,
      this.firstName,
      this.lastName,{this.badge,this.badgeImage,}
      );



  Map<String, dynamic> toJson() => {
    "_id": id,
    "comment": comment,
    "commentedBy": commentedBy,
    "commentedByRole": commentedByRole,
    "createdAt": createdAt,
    "profilePicture": profilePicture,
    "firstName": firstName,
    "lastName": lastName,
    "badge": badge,
    "badgeImage": badgeImage,
  };
}


class Tags {
  String userId, name, profilePicture, title, roleId;
  String badge;
  String badgeImage;
  int gamificationPoints;
  Tags(this.userId, this.name, this.profilePicture, this.title, this.roleId,this.badge,this.gamificationPoints,this.badgeImage);
}

class Groups {
  String groupId;
  String groupName;
  String groupImage;
  Groups(this.groupId, this.groupName, this.groupImage);
}

class WebLinksModel {
  String imageUrl, title, url, description;

  WebLinksModel(this.imageUrl, this.title, this.url, this.description);
}
