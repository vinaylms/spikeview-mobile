import 'dart:async';
import 'dart:io';
import 'dart:ui';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/presoView/simple_animations/controlled_animation.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/BadgeDataModel.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/ConnectionModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/rating/RatingModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:url_launcher/url_launcher.dart';


class PatnerProfilePreview extends StatefulWidget {
  String userId, callingType;
  String requestStatus;
  CompanyProfileModel companyModel;

  PatnerProfilePreview(this.userId, this.callingType,this.companyModel,
      {this.requestStatus});

  @override
  PatnerProfilePreviewState createState() =>
       PatnerProfilePreviewState(userId);
}

class PatnerProfilePreviewState
    extends State<PatnerProfilePreview> {
  int notificationCount = 0;

  String rejectionReason = '';

  String selectedCountryCode='';
  String partnerName='';
  String email='';
  String phone='';
  String companyName='';
  String companyAddress='';
  String companyPhone='';
  String webUrl='';
  String aboutCompany='';
  String companyid='';

  List<String> mediaImagesList =  List();
  List<AssetModel> assetModelMap =  List();
  List<FileModel> mediaVideosList =  List();

  List<String> googleDoclinkList =  List();

  UploadMedia uploadMedia;

  List<CategoryModel> selectedCategoryList=new List<CategoryModel>();

  List<Assest> assestVideoAndImage =  List();

  var style = TextStyle(
      color: ColorValues.GREY_TEXT_COLOR, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblack =
  TextStyle(color: Colors.black, fontSize: 16, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var stylextreLarge =
  TextStyle(color: Colors.black, fontSize: 24, fontFamily: Constant.TYPE_CUSTOMBOLD);
  var styleblackText =
  TextStyle(color: Colors.black, fontSize: 14, fontFamily: Constant.TYPE_CUSTOMBOLD);

  //static var mediaDocumentList;
  List<String> mediaDocumentList =  List();

  TextEditingController reasonTxtController =  TextEditingController();

  final FocusNode _reasonFocus = FocusNode();


  PatnerProfilePreviewState(this.userIdPref);

  bool isCallStudentRequestApi = false;

  Color borderColor = Colors.amber;
  bool isRememberMe = false;
  bool isDataRember = false;
  File imagePath, imagePathCover;
  String strNetworkImage = "";
  String userIdPref, roleId, token;
  ProfileInfoModal profileInfoModal;
  List<StudentDataModel> listStudent =  List();
  List<ProfileEducationModal> userEducationList =
       List<ProfileEducationModal>();
  List<NarrativeModel> narrativeList =  List<NarrativeModel>();
  List<Recomdation> recommendationtList =  List<Recomdation>();
  BuildContext context;
  SharedPreferences prefs;
  bool isSentRequest = true;
  bool isNarativeShow = false;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String sasToken, containerName;
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto,
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strSummary;
  String strAccCount = "", strRecCount = "";
  bool isActive = false;
  StreamSubscription<dynamic> _streamSubscription;
  StreamSubscription<dynamic> _streamSubscriptionWizard;
  ScrollController _scrollController =  ScrollController();
  bool isTitleVisible = false;
  bool _isAppbar = true;
  final _formKey = GlobalKey<FormState>();

  String strDoB = "";
  String strFirstName = "", strLastName = "", strEmail = "";
  bool isLoading = true;
  bool isRatingLodaing = true;
  static String isAchivmentAdded = "false";
  static String isEducationAdded = "false";
  bool isShowAllActiveOpportunity = false;
  bool isShowAllExpireOpportunity = false;
  static StreamController syncDoneController = StreamController.broadcast();

  bool isConnected = false;
  bool isRejected = false;
  bool isApproved = false;
  bool isPending = false;
  bool isParentApprovalPending = false;

  bool isAccepetd = false;
  String connectId = "0";
  bool isSubscribe = false;
  int subsCriberId = 0;
  ConnectionModel connectionModel;
  bool isDataLoading = true;
  CompanyProfileModel companyModel;
  List<OpportunityModel> activeOpportunityList =  List();
  List<OpportunityModel> expireOpportunityList =  List();
  List<BadgeDataModel> badgeList =  List();
  bool isViewAllBadges = false;
  List<RequestedTagModel> pendinForParentDataList =  List();
  List<RequestedTagModel> receivedRequestList =  List();

  //-----------for rating------------
  var rating = 4.0;
  bool isSelectTap = false;
  var ratingCalculation = 0.0;
  String creationDate = "";
  bool isView = false;
  List<RatingModel> reviewList =  List();
  RatingModel myRating;

  //--------------------------Profile Info api ------------------


  Future setCompanyInfo() async {
    try {
      companyModel = widget.companyModel;
      if (companyModel != null) {
        /*      prefs.setString(UserPreference.COMPANY_IMAGE_PATH,
                    companyModel.profilePicture);
                prefs.setString(
                    UserPreference.COMPANY_NAME_PATH, companyModel.name);
                syncDoneController.add("sucess");*/
        setState(() {
          companyModel;
          if(companyModel.partnerStatus.toString() == 'Pending'){
            isApproved = false;
            isRejected = false;
            isPending = true;
          }else if(companyModel.partnerStatus.toString() == 'Active'){
            isApproved = true;
            isRejected = false;
            isPending = false;
            //ToastWrap.showToastLong(MessageConstant.ACTIVE_PARTNER_VAL, context);
          }else if(companyModel.partnerStatus.toString() == 'Decline'){
            isApproved = false;
            isRejected = true;
            isPending = false;
            //ToastWrap.showToastLong(MessageConstant.DECLINE_PARTNER_VAL, context);
          }

          setData(companyModel);
          /*

                  isRejected=true && !isApproved= false

                  *
                  * */

        });
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"PatnerProfilePreview",context);
      //if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await  ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;

          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"PatnerProfilePreview",context);
      e.toString();
    }
  }

//***************************************************************************************************************

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    setState(() {
      isDataLoading = true;
    });
    prefs = await SharedPreferences.getInstance();

    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);

    //CustomProgressLoader.showLoader2(context);

    var isConnect = await ConectionDetecter.isConnected();

    /*if (isConnect) {
      await profileApi(false);
      await companyInfoApi(false);
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }*/

    setCompanyInfo();


    //CustomProgressLoader.cancelLoader(context);

    if (isConnect) {
      await callApiForSaas();
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }

    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_COVER +
        "/";

    strPrefixPathforProfilePhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";

    /*if(isApproved){
      ToastWrap.showToastLong(MessageConstant.ACTIVE_PARTNER_VAL, context);
    }else if(isRejected){
      ToastWrap.showToastLong(MessageConstant.DECLINE_PARTNER_VAL, context);
    }*/

    setState(() {
      isDataLoading = false;
    });
  }

  void appBarStatus(bool status) {
    setState(() {
      _isAppbar = status;
    });
  }


  @override
  void initState() {


    uploadMedia = UploadMedia(context);

    /*_streamSubscription =
        ManageOfferingWidgetState.syncDoneController.stream.listen((value) {
      print("value changes" + value);
      companyInfoApi(false);
    });*/

    /*_scrollController.addListener(() {
      if (_scrollController.offset < 150.0) {
        setState(() {
          isTitleVisible = false;
        });
      } else {
        setState(() {
          isTitleVisible = true;
        });
      }

      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        appBarStatus(false);
      }
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        appBarStatus(true);
      }
    });*/

    getSharedPreferences();

    super.initState();
  }




  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Main View for return final Output
    this.context = context;
    Widget _loader(BuildContext context, String placeHolderImage) => Center(
            child: Container(
          child:  Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }

    InkWell isImageSelectedView() {
      return  InkWell(
        child:  Container(
          width: 111.0,
          height: 111.0,
          child:  Stack(
            children: <Widget>[
               Center(
                  child:  Container(
                child:  ClipOval(
                    child:

                        companyModel != null
                            ?  CachedNetworkImage(
                                imageUrl: companyModel != null
                                    ? Constant.IMAGE_PATH_SMALL +
                                        ParseJson.getMediumImage(
                                            companyModel.profilePicture)
                                    : "",
                                fit: BoxFit.cover,
                                placeholder: (context, url) => _loader(
                                    context, "assets/profile/partner_img.png"),
                                errorWidget: (context, url, error) =>
                                    _error("assets/profile/partner_img.png"),
                              )
                            :  Image.asset(
                                "assets/profile/partner_img.png")),
                width: 111.0,
                height: 111.0,
                padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              )),
            ],
          ),
        ),
        onTap: () {},
      );
    }

    int getLenthOfName() {
      int lenght = 0;
      if (companyModel == null) {
        return 0;
      } else {
        lenght = companyModel.name.length;
      }

      return lenght;
    }

    Widget headerUiDesign() {
      return  Container(
        height: 375.0,
        color:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
        child:  Stack(
          children: <Widget>[
             Positioned(
              top: 0.0,
              bottom: 0.0,
              left: 0.0,
              right: 0.0,
              child: imagePathCover == null
                  ? companyModel != null &&
                          (companyModel.coverPicture != "" &&
                              companyModel.coverPicture != "null")
                      ?  Stack(
                          children: <Widget>[
                             Positioned(
                              child:

                                   CachedNetworkImage(
                                imageUrl: Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getMediumImage(
                                        companyModel.coverPicture),
                                fit: BoxFit.cover,
                                placeholder: (context, url) =>
                                    _loader(context, ""),
                                errorWidget: (context, url, error) =>
                                    _error(""),
                              ),
                              top: 0.0,
                              bottom: 0.0,
                              left: 0.0,
                              right: 0.0,
                            ),
                             Positioned(
                              child:  Container(
                                child:  Image.asset(
                                  "assets/newDesignIcon/navigation/layer_cover.png",
                                  fit: BoxFit.fill,
                                ),
                              ),
                              top: 0.0,
                              bottom: 0.0,
                              left: 0.0,
                              right: 0.0,
                            )
                          ],
                        )
                      :  Container(
                          color:  Color(0xff5E5E5E),
                        )
                  :  Stack(
                      children: <Widget>[
                         Positioned(
                          child:  Image.file(
                            imagePathCover,
                            fit: BoxFit.fitWidth,
                          ),
                          top: 0.0,
                          bottom: 0.0,
                          left: 0.0,
                          right: 0.0,
                        ),
                         Positioned(
                          child:  Container(
                            child:  Image.asset(
                              "assets/newDesignIcon/navigation/layer_cover.png",
                              fit: BoxFit.fill,
                            ),
                          ),
                          top: 0.0,
                          bottom: 0.0,
                          left: 0.0,
                          right: 0.0,
                        )
                      ],
                    ),
            ),
             Positioned(
                bottom: 45.0,
                left: 0.0,
                right: 0.0,
                child:  Column(
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        13.0,
                        20.0,
                        13.0,
                        0.0,
                         Container(
                            child:  Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0, 10.0, 13.0, 10.0, isImageSelectedView()),
                              flex: 0,
                            ),
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  5.0,
                                  0.0,
                                  0.0,
                                  8.0,
                                   Container(
                                      child:  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      PaddingWrap.paddingAll(
                                        2.0,
                                        TextViewWrap.textViewMultiLine(
                                            companyModel == null
                                                ? ""
                                                : companyModel.name,
                                            TextAlign.start,
                                            Colors.white,
                                            getLenthOfName() > 24 ? 22.0 : 28.0,
                                            FontWeight.normal,
                                            2),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 10.0),
                                        child: Container(
                                          decoration:  BoxDecoration(
                                              color:
                                              isApproved ?
                                               ColorValues.BUTTON_ACTIVE
                                                  :  ColorValues.BUTTON_PENDING,
                                              border:  Border.all(
                                                  color:  isApproved ?
                                                   ColorValues.BUTTON_ACTIVE
                                                      :  ColorValues.BUTTON_PENDING, width: 0.0),borderRadius: BorderRadius.circular(12) ),
                                          height: 22.0,
                                          child: PaddingWrap.paddingfromLTRB(
                                            12.0,
                                            3.0,
                                            12.0,
                                            3.0,  TextViewWrap.textViewSingleLine(
                                              isApproved ?
                                              "Active".toUpperCase()

                                                  : "Pending Approval".toUpperCase(),
                                              TextAlign.start,
                                               ColorValues.WHITE,
                                              12.0,
                                              FontWeight.normal),),
                                        ),
                                      ),

                                    ],
                                  ))),
                              flex: 1,
                            )
                          ],
                        ))),
                  ],
                )),
          ],
        ),
      );
    }



    return WillPopScope(
        child: Scaffold(
          appBar:  AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            title:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child:  InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      onBack();
                    },
                  ),
                  flex: 0,
                ),
                 Expanded(
                  child:  Text(
                    companyModel != null ?
                    "${companyModel.name}'s Profile" : "Profile",
                    textAlign: TextAlign.center,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 18.0,
                        fontFamily:Constant.TYPE_CUSTOMREGULAR),
                  ),
                  flex: 1,
                ),
                //widget.callingType == "rejectionReason" ?
                    Expanded(
                      child: InkWell(
                        onTap: (){
                          onTapSubmitProfile();
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(right: 16.0),
                          child:  Text(
                            //widget.callingType == "rejectionReason" ? "Submit" : "",
                              "Submit",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:
                                 ColorValues.BLUE_COLOR_BOTTOMBAR),
                          ),
                        ),
                      ),
                      flex: 0,
                    ),

              ],
            ),
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          body:  Stack(
            children: <Widget>[
               Positioned(
                  left: 0.0,
                  right: 0.0,
                  top: 0.0,
                  bottom: 0.0,
                  child:  SingleChildScrollView(
                    controller: _scrollController,
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        headerUiDesign(),
                        companyModel != null ? partnerDetails() : Container(),
                        companyModel != null && (googleDoclinkList.length > 0 || mediaDocumentList.length > 0 || assestVideoAndImage.length > 0) ? getMediaDetails() : Container(width: 0,height: 20,),
                        //isPending && widget.callingType != "rejectionReason" ? approveRejectButtons() : Container(height: 30,),
                        //approveRejectButtons()
                        Container(width: 0,height: 30,),
                      ],
                    ),
                  )),
            ],
          ),
        ),
        onWillPop: () {
          onBack();
        });
  }
  void onBack() {
    print('OnBack partner isDataLoading:: $isDataLoading');
    if (!isDataLoading) {
        print('inside Partner else 111 widget.pageRedirect:: ${widget.callingType}, roleID:: $roleId');
        Navigator.pop(context,'push');

    } else {
      print("Not partner perform");
    }
  }

  partnerDetails() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Company Name'),
            ),
            getValueText('$companyName'),
            partnerName != "" ? Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Partner’s Name'),
            ) : Container(),
            partnerName != "" ? getValueText('$partnerName') : Container(),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 4),
              child: getLabelText('Business Category'),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 5, 0, 0),
              child: Wrap(
                children: getSelectedWidgets(selectedCategoryList, "mainCategory"),
              ),
            ),

            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Company Address'),
            ),
            getValueText('$companyAddress'),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 1),
              child: getLabelText('Phone Number'),
            ),
            Row(
              children: <Widget>[
                CountryCodePicker(
                  dense: false,
                  showFlag: true,
                  //displays flag, true by default
                  showDialingCode: true,
                  //displays dialing code, false by default
                  showName: false,
                  showDropDownIcon: false,
                  showUnderLine: false,
                  isEnabled: false,
                 selectedCountryCode: selectedCountryCode,
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(8, 0, 0, 0),
                  child: getValueText('${Util.getPhoneNoFormate(companyPhone)}'),
                ),

              ],
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Email'),
            ),
            getValueText('$email'),
            webUrl != "" ? Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('Website URL'),
            ): Container(),
            webUrl != "" ? InkWell(
                onTap: (){
                  Navigator.push(
                      context,
                       MaterialPageRoute(
                        //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) =>  WebViewWidget(
                              webUrl, "spikeview")));
                },
                child: getValueTextBlue('$webUrl')
            ): Container(),
            Padding(
              padding: EdgeInsets.fromLTRB(0, 20, 0, 7),
              child: getLabelText('About Company'),
            ),
            getValueText('$aboutCompany'),
          ],
        ),
      ),
    );
  }

  getLabelText(String textString) {
    return  Text(
      "$textString",
      textAlign: TextAlign.left,
      style:  TextStyle(
          color:  ColorValues.GREY__COLOR,
          fontSize: 14.0,
          fontWeight: FontWeight.w400,
          fontFamily:Constant.TYPE_CUSTOMREGULAR),
    );
  }
  getValueText(String textString) {
    return  Text(
      "$textString",
      textAlign: TextAlign.left,
      style:  TextStyle(
          color:  ColorValues.RADIO_BLACK,
          fontSize: 16.0,
          fontWeight: FontWeight.w400,
          fontFamily:Constant.TYPE_CUSTOMREGULAR),
    );
  }
  getValueTextBlue(String textString) {
    return  Text(
      "$textString",
      textAlign: TextAlign.left,
      style:  TextStyle(
          color:  ColorValues.BLUE_COLOR,
          fontSize: 16.0,
          fontWeight: FontWeight.w400,
          fontFamily:Constant.TYPE_CUSTOMREGULAR),
    );
  }

  void setData(CompanyProfileModel companyProfileModel) async {
    String firstName='', lastname='';
    setState(() {
      if (companyProfileModel.countryCode != null)
        selectedCountryCode = companyProfileModel.countryCode;

      if (companyProfileModel.firstName != null &&
          companyProfileModel.firstName != "null")
        firstName = companyProfileModel.firstName;

      if (companyProfileModel.lastName != null &&
          companyProfileModel.lastName != "null"){
        lastname = companyProfileModel.lastName;

      }

      partnerName = firstName+" "+ lastname;
      print('firstName:: $firstName, lastName:: $lastname');

      if (companyProfileModel.email != null)
        email= companyProfileModel.email;

      if (companyProfileModel.mobileNo != null &&
          companyProfileModel.mobileNo != '0' &&
          companyProfileModel.mobileNo != 'null')
        phone = companyProfileModel.mobileNo;

      if (companyProfileModel.name != null &&
          companyProfileModel.name != "null")
        companyName = companyProfileModel.name;

      if (companyProfileModel.address != null &&
          companyProfileModel.address != "null")
        companyAddress = companyProfileModel.address;

      if (companyProfileModel.phone != null)
        companyPhone = companyProfileModel.phone;

      if (companyProfileModel.url != null)
        webUrl = companyProfileModel.url;

      if (companyProfileModel.about != null)
        aboutCompany = companyProfileModel.about;

      /*zipCode = companyProfileModel.zipCode == null ||
          companyProfileModel.zipCode == "null"
          ? "0"
          : companyProfileModel.zipCode;

      if (companyProfileModel.gender != null &&
          companyProfileModel.gender != "null" &&
          companyProfileModel.gender != "") {
        gender = companyProfileModel.gender;
      }*/

      companyid = companyProfileModel.companyId;
      print("compant Id---------" + companyid);

      for (Assest assest in companyModel.mediaList) {
        assestVideoAndImage.add(assest);
      }

      for (Assest assest in companyModel.docList) {
        mediaDocumentList.add(assest.file);
      }

      for (Assest assest in companyModel.videoList) {
        assestVideoAndImage.add(assest);
      }

      for (Assest assest in companyModel.googleLinkList) {
        googleDoclinkList.add(assest.file);
      }
      if(companyProfileModel.categoryModel != null && companyProfileModel.categoryModel.length > 0){
        bool first=true;
        for (var categoryModel in companyProfileModel.categoryModel) {
          print('categoryModel:::::: ${categoryModel.name}');

          selectedCategoryList.add(categoryModel);
        }
      }
      else{
        print('inside else companyProfileModel.categoryModel size:: ${companyProfileModel.categoryModel.length}');
        print('inside else no category selected');
      }

    });

    setState(() {
      companyName;
      partnerName;
      webUrl;
      email;
      selectedCountryCode;
      phone;
      companyAddress;
      companyPhone;
      companyid;
      aboutCompany;

      mediaVideosList;
      selectedCategoryList;
      mediaDocumentList;
      googleDoclinkList;
      assestVideoAndImage;
    });
  }

  getMediaDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(0.0,20,0,14),
          child: Container(
              height: 1,
              width: MediaQuery.of(context).size.width,
              color: ColorValues.BORDER_COLOR
          ),
        ),


        Padding(
          padding: EdgeInsets.fromLTRB(12, 0, 12, 7),
          child: getLabelText('Media'),
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.only(
                left: 0.0, right: 0.0, top: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                assestVideoAndImage.length > 0 ? PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    //
                    assestVideoAndImage.length > 0
                        ?  SizedBox(
                      // Pager view
                        height: 215.50,
                        child: PageIndicatorContainer(
                          pageView:  PageView.builder(
                            itemCount:
                            assestVideoAndImage.length,
                            controller:  PageController(),
                            itemBuilder: (context, index2) {
                              return  InkWell(
                                child:  Stack(
                                    children: <Widget>[
                                      assestVideoAndImage[
                                      index2]
                                          .type ==
                                          "image"
                                          ?  InkWell(
                                          onTap: () {
                                            Navigator.of(context).push(new MaterialPageRoute(
                                                builder: (BuildContext context) =>  CommonFullViewWidget(
                                                    assestVideoAndImage,
                                                    MessageConstant
                                                        .ACCOMPLISHMENT_HEDING,
                                                    index2,
                                                    MessageConstant
                                                        .COMPANY_PROFILE_HEDING)));
                                          },
                                          child:
                                          Container(
                                            decoration:
                                            BoxDecoration(
                                              color: Colors
                                                  .black,
                                            ),
                                            child:
                                             CachedNetworkImage(
                                              width: double
                                                  .infinity,
                                              height:
                                              215.50,
                                              imageUrl: Constant
                                                  .IMAGE_PATH +
                                                  assestVideoAndImage[index2]
                                                      .file,
                                              fit: BoxFit
                                                  .contain,
                                              placeholder: (context,
                                                  url) =>
                                                  _loader(
                                                      context),
                                              errorWidget: (context,
                                                  url,
                                                  error) =>
                                                  _error(),
                                            ),
                                          ))
                                          :  Container(
                                        decoration:
                                        BoxDecoration(
                                          color: Colors.black,
                                          borderRadius:
                                          BorderRadius
                                              .circular(
                                              0),
                                        ),
                                        height: 215.50,
                                        child:
                                         Center(
                                          child:  VideoPlayPause(
                                              assestVideoAndImage[
                                              index2]
                                                  .file,
                                              "",
                                              true),
                                        ),
                                      ),
                                      assestVideoAndImage
                                          .length ==
                                          1 ||
                                          assestVideoAndImage[
                                          index2]
                                              .type ==
                                              "video"
                                          ?  Container(
                                        height: 0.0,
                                      )
                                          :  Container(
                                        height: 215.50,
                                        width: double
                                            .infinity,
                                        child:  Image
                                            .asset(
                                          "assets/newDesignIcon/navigation/layer_image.png",
                                          fit: BoxFit
                                              .fill,
                                        ),
                                      )
                                    ]),
                                onTap: () {},
                              );
                            },
                            onPageChanged: (index) {},
                          ),
                          align: IndicatorAlign.bottom,
                          length: assestVideoAndImage.length,
                          indicatorSpace: 10.0,
                          indicatorColor:
                          assestVideoAndImage.length == 1
                              ? Colors.transparent
                              :  Color(0xffc4c4c4),
                          indicatorSelectorColor:
                          assestVideoAndImage.length == 1
                              ? Colors.transparent
                              :  ColorValues.WHITE,
                          shape: IndicatorShape.circle(
                              size: 5.0),
                        ))
                        :  Stack(children: <Widget>[
                       Image.asset(
                        "assets/profile/default_achievement.png",
                        fit: BoxFit.cover,
                        height: 215.50,
                        width: double.infinity,
                      ),
                       Container(
                        height: 215.50,
                        color:
                        Colors.black54.withOpacity(.4),
                      )
                    ])):Container(width: 0,height: 0,),

                mediaDocumentList.length == 0
                    ?  Container(
                  height: 0.0,
                )
                    : Padding(
                    padding: const EdgeInsets.fromLTRB(
                        13.0, 35.0, 13.0, 0.0),
                    child:  Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      children: <Widget>[
                        getLabelText(
                            'Attached Documents (PDF only)'),
                        docListUiData(),
                      ],
                    )),
                googleDoclinkList.length == 0
                    ?  Container(
                  height: 0.0,
                )
                    : Padding(
                    padding: const EdgeInsets.fromLTRB(
                        13.0, 35.0, 13.0, 0.0),
                    child:  Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      mainAxisAlignment:
                      MainAxisAlignment.start,
                      children: <Widget>[
                        getLabelText('Document Link'),
                        uploadGoogleDocLink(),
                      ],
                    )),



              ],
            ),
          ),
        ),
      ],
    );
  }
  docListUiData(){
    return  Container(
        padding: const EdgeInsets.fromLTRB(0.0, 18.0, 0.0, 0.0),
        child:  GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.3,
          scrollDirection: Axis.vertical,
          crossAxisCount: 4,
          children: mediaDocumentList.map((file) {
            return  Container(
                child:  Stack(
                  children: <Widget>[
                     InkWell(
                      onTap: () {
                        print("DOC++++" + Constant.IMAGE_PATH + file);
                        launch(Constant.IMAGE_PATH + (file.replaceAll(" ", "%20")));
                      },
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          5.0,
                           Container(
                              height: 80.0,
                              width: 62.0,
                              child:  Column(
                                children: <Widget>[
                                   Expanded(
                                    child:  Image.asset(
                                      "assets/newDesignIcon/patner/pdf.png",
                                      height: 54.0,
                                      width: 62.0,
                                    ),
                                    flex: 1,
                                  ),
                                   Expanded(
                                    child:  Text(
                                      file.substring(
                                          (file.lastIndexOf("/") + 1), file.length),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR)
                                    ),
                                    flex: 0,
                                  )
                                ],
                              ))),
                    ),
                  ],
                ));
          }).toList(),
        ));
  }

  mediaLabelText(String label) {
    return Text(
      label,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
    );
  }
  uploadGoogleDocLink() {
    return Column(
      children: <Widget>[
         Column(
          children: List.generate(googleDoclinkList.length, (index) {
            return Row(
              children: <Widget>[
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                    child:  InkWell(
                      child: Text(
                        googleDoclinkList[index],
                        style: TextStyle(
                            color: Palette.accentColor, fontSize: 16,fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      ),
                      onTap: () {
                        Navigator.push(
                            context,
                             MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) =>  WebViewWidget(
                                    googleDoclinkList[index], "spikeview")));
                      },
                    ),
                  ),
                ),
              ],
            );
          }),
        )
      ],
    );
  }


  Widget _loader(BuildContext context) => Center(
      child: Container(
        child:  Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }


  List<Widget> getSelectedWidgets(List<CategoryModel> selectedOption, String from) {
    List<Widget> widgets = [];
    for (CategoryModel item in selectedOption) {
      print("Name+++++" + item.name);
      double width = item.name.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return Container(
                  color: Colors.white,
                  //margin: EdgeInsets.all(5),
                  margin: EdgeInsets.only(right: 10,top:0,bottom: 0),
                  child:
                  InputChip(
                    label: Text('${item.name}',softWrap: true,style: TextStyle(
                      color: ColorValues.GREY_TEXT_COLOR,
                      fontSize: 16,
                        fontWeight: FontWeight.w400,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR
                    ),),
                    backgroundColor: Colors.white,
                    //shape: StadiumBorder(side: BorderSide(color: ColorValues.GREY_TEXT_COLOR,),),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(0),bottomRight: Radius.circular(0)),side: BorderSide(color: ColorValues.GREY_TEXT_COLOR,)),
                    labelStyle: TextStyle(
                      color: ColorValues.GREY_TEXT_COLOR,
                      fontSize: 16,
                        fontWeight: FontWeight.w400,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12.0,vertical: 3.0),
                    disabledColor: Colors.white,
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  onTapSubmitProfile() {

    for (Assest file in companyModel.mediaList) {
      assetModelMap.add(AssetModel(
        file: file.file,
        tag: 'media',
        type: "image",
      ));
    }

    for (Assest file in companyModel.docList) {
      assetModelMap.add(AssetModel(
        file: file.file,
        tag: 'media',
        type: "doc",
      ));
    }

    for (Assest file in companyModel.videoList) {
      assetModelMap.add(AssetModel(
        file: file.file,
        tag: 'media',
        type: "video",
      ));
    }

    for (Assest file in companyModel.googleLinkList) {
      assetModelMap.add(AssetModel(
        file: file.file,
        tag: 'media',
        type: "google",
      ));
    }

    apiCallingForUpdate();

  }

  Future apiCallingForUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        CustomProgressLoader.showLoader(context);

        Map map = {
          "firstName": partnerName,
          "lastName": "",//lastNameController.text,
          "mobileNo": companyPhone,
          "companyId": companyid,
          "userId": userIdPref,
          "roleId": 4,
          "name": companyName,
          "address": companyAddress,
          "phone": companyPhone,
          "url": webUrl,
          "about": aboutCompany,
          'gender':   companyModel.gender=="Non-Binary"?"NonBinary":companyModel.gender,
          'zipCode': companyModel.zipCode,
          'countryCode': selectedCountryCode,
          "state": companyModel.state,
          "city": companyModel.city,
          "country": companyModel.country,
          //"profilePicture":companyProfileModel.profilePicture,
          //"coverPicture":companyProfileModel.coverPicture ,
          // "offer": OfferModel.mapList(companyProfileModel.offers),
          "asset": AssetModel.mapList(assetModelMap),
          "businessCategory": CategoryModel.mapList(selectedCategoryList),
        };

        print("Apurva Updated preview map+++++++++" + map.toString());
        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_PARTNER_PROFILE, map);
        CustomProgressLoader.cancelLoader(context);
        print("response preview:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              syncDoneController.add("msg");
              //showSucessMsgLong(msg, context);
              ToastWrap.showToastGreenDismissibleFalse(msg,context);

              Timer _timer;
              print("apiCallApprovePartner timer on");
              _timer =  Timer(const Duration(milliseconds: 5000), () async {
                print("apiCallApprovePartner timer off");
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) =>  DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE))));
              });
            }
          }
        }
      } else {
            ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"PatnerProfilePreview",context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

}


