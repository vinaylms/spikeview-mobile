import 'package:flutter/material.dart';
import 'package:readmore/readmore.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ReadMoreTextWidget extends StatelessWidget {

  final String text;
  final TextStyle textStyle;

  const ReadMoreTextWidget({
    @required this.text,
    this.textStyle,
});

  @override
  Widget build(BuildContext context) {
    return  ReadMoreText(
      text,
      trimLines: 3,
      delimiter: '',
      colorClickableText: const Color(0xff4684EB),
      style: textStyle ?? TextStyle(
        color: ColorValues.HEADING_COLOR_EDUCATION_1,
        fontFamily: Constant.latoRegular,
        fontSize: 14,
        fontWeight: FontWeight.w400,
      ),
      trimMode: TrimMode.Line,
      trimCollapsedText: ' ...More',
      trimExpandedText: ' Less',
      delimiterStyle:  TextStyle(
        color: ColorValues.HEADING_COLOR_EDUCATION_1,
        fontFamily: Constant.latoRegular,
        fontSize: 14,
        fontWeight: FontWeight.w400,
      ),
      moreStyle: TextStyle(
        color: const Color(0xff4684EB),
        fontFamily: Constant.latoRegular,
        fontSize: 14,
        fontWeight: FontWeight.w400,
      ),
    );
  }
}
