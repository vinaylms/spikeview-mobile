class UserImageModelParam {
  String file;

  UserImageModelParam({this.file});
  
  static Map<String, dynamic> toMap(UserImageModelParam categoryObject) {
    Map<String, dynamic> categoryMap = Map();
    categoryMap['file'] = categoryObject.file;
    return categoryMap;
  }

  static List<Map<String, dynamic>> mapList(List<UserImageModelParam> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "file": category.file,
            })
        .toList();
    return listOfCategory;
  }
}
