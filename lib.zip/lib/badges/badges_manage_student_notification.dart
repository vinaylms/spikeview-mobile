import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/badges/model/CollectionResult.dart';
import 'package:spike_view_project/badges/model/RequestResult.dart';
import 'package:spike_view_project/badges/model/Request_badges.dart';
import 'package:spike_view_project/badges/new_badges/add_request_badges.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';

import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/badges/model/Collection_badges.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class ManageBadgesStudentNotification extends StatefulWidget {
  //const TabsBadges({Key key}) : super(key: key);

  String userId, dob, screenName, id="";

  ManageBadgesStudentNotification(this.dob, this.userId, this.screenName, this. id);

  @override
  State<ManageBadgesStudentNotification> createState() => _TabsBadgesState();
}

class _TabsBadgesState extends State<ManageBadgesStudentNotification>
    with SingleTickerProviderStateMixin {
  int initialIndex = 0;
  int cnt = 0;
  bool remainderFlag = false;
  TabController _tabController;

  String requestCount = "0";
  String collectionCount = "0";
  String presentedCount = "0";

  String strTabValue = 'Requested';


  @override
  void initState() {
print("widget.screenName///////"+widget.screenName.toString());
    if(widget.screenName=="notificationCollection"){
      setState(() {
        currentIndex=1;
        strTabValue = 'Collections';
      });
    }

    _tabController = TabController(vsync: this, length: 2)
      ..addListener(() async {
        if (!_tabController.indexIsChanging) {
          switch (_tabController.index) {
            case 0:
              print('PPPPPPPPPPP seem');

              break;
            case 1:
              print('seem PPPPPPPPPPP');
              break;
          }
        }
      });

    getSharedPreferences();
    super.initState();
  }

  int skip = 0;

  int skipCollection = 0;
  final ItemScrollController _scrollControllerRequest = ItemScrollController();
  final ItemScrollController _scrollControllerCollection = ItemScrollController();


  SharedPreferences prefs;
  String userIdPref, token, roleId;

  bool isDataLoadingRequest = false;
  bool isDataLoadingPending = false;
  int positionOfChild = 0;
  int positionOfCollection = 0;

  RequestBadges mRequestBadgesModel = RequestBadges();
  bool notificationLoader = true;
  CollectionBadges mCollectionBadgesModel = CollectionBadges();

  List<Result> mCollectionBadges = [];
  List<RequestResult> mRequestBadges = [];

  int currentIndex = 0;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    token = prefs.getString(UserPreference.USER_TOKEN);





    apiBadgesCount();
    apiCallingRequestBadges();
    apiCallingCollectiontBadges();


   /* _scrollControllerCollection.addListener(() {
      if (mCollectionBadges.length - 1 == positionOfCollection) {
        if (_scrollControllerCollection.position.pixels ==
            _scrollControllerCollection.position.maxScrollExtent) {
          setState(() {
            skipCollection = skipCollection + 1;
            apiCallingCollectiontBadges();
          });
        }
      }
    });*/
  }

  Future apiBadgesCount() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_BADGESCOUNT +
                "userId=" +
                widget.userId +
                "&roleId=" +
                "1",
            "get");

        print("api badges count - ${Constant.ENDPOINT_BADGESCOUNT +
            "userId=" +
            widget.userId +
            "&roleId=" +
            "1"}");

        print("requestedCount//////" + response.toString());
        print("requestedCount//////" + response.data['result'].toString());
        if (response != null) {
          if (response.statusCode == 200) {
            setState(() {
              requestCount = response.data['result']['requestCount'].toString();
              collectionCount =
                  response.data['result']['collectionCount'].toString();
              presentedCount =
                  response.data['result']['presentedCount'].toString();
            });

            print("strRequestCount//////" +
                requestCount +
                collectionCount +
                presentedCount);
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingRequestBadges() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        response = await ApiCalling().apiCall(
            context,
            Constant.BADGEBYTYPE +
                "userId=" +
                widget.userId +
                "&roleId=" +
                "1" +
                "&type=request" +
                "&redirectBy=notification",
            "get");

        print("Api calling requested badges url - ${ Constant.BADGEBYTYPE +
            "userId=" +
            widget.userId +
            "&roleId=" +
            "1" +
            "&type=request" +
            "&redirectBy=notification"}");

        MessageConstant.printWrapped(
            "BADGEBYTYPE........" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              setState(() {
                mRequestBadgesModel = RequestBadges.fromJson(response.data);
                mRequestBadges.addAll(mRequestBadgesModel.requestResult);
              });

              print("requested badges responce - ${response}");
              print('requested badges count - ${mRequestBadges.length}');

              if (!mRequestBadges.isEmpty && mRequestBadges.length > 0) {
                setState(() {
                  isDataLoadingRequest = false;
                });
              } else {
                setState(() {
                  isDataLoadingRequest = true;
                });
              }

              if (widget.screenName=="Notification") {
                for (int i = 0; i < mRequestBadges.length; i++) {
                  if (widget.id ==
                      mRequestBadges[i].badgeReqId.toString()) {
                    Timer(const Duration(milliseconds: 2000), () async {
                      if (notificationLoader) {
                        _scrollControllerRequest.jumpTo(index: i);

                        setState(() {
                          notificationLoader = false;
                        });
                      }
                    });
                  }
                }
              }

              if (widget.id==""||widget.screenName=="notificationCollection") {
              } else {
                List<RequestResult> results1 = mRequestBadges
                    .where((user) =>
                        user.badgeReqId.toString() == widget.id)
                    .toList();

                print("results1////" + results1.length.toString());

                if (results1.length==0) {
                  Future.delayed(Duration(seconds: 3), () {
                    setState(() {
                      ToastWrap.showToast("No longer exists ", context);
                    });
                  });
                }
              }

              try {} catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingCollectiontBadges() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        response = await ApiCalling().apiCall(
            context,
            Constant.BADGEBYTYPE +
                "userId=" +
                widget.userId +
                "&roleId=" +
                "1" +
                "&type=collection&skip=" +
                skipCollection.toString() +
                "&redirectBy=:redirectBy",
            "get");

        MessageConstant.printWrapped(
            "BADGEBYTYPE........" + response.toString());

        print("apiCallingCollectiontBadges  url - ${Constant.BADGEBYTYPE +
            "userId=" +
            widget.userId +
            "&roleId=" +
            "1" +
            "&type=collection&skip=" +
            skipCollection.toString() +
            "&redirectBy=:redirectBy"}");

        print("apiCallingCollectiontBadges - responce ${response.toString()}");

        //  mCollectionBadges = response.data;
        //
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              setState(() {
                mCollectionBadgesModel =
                    CollectionBadges.fromJson(response.data);
                mCollectionBadges.addAll(mCollectionBadgesModel.result);
              });

              print("mCollectionBadges" + mCollectionBadges.length.toString());

              if (mCollectionBadges == null || mCollectionBadges.isEmpty) {
                isDataLoadingPending = true;
              }


              if (widget.screenName=="notificationCollection") {
                for (int i = 0; i < mCollectionBadges.length; i++) {
                  if (widget.id == mCollectionBadges[i].badgeReqId.toString()) {
                    Timer(const Duration(milliseconds: 2000), () async {
                      if (notificationLoader) {
                        _scrollControllerRequest.jumpTo(index: i);

                        setState(() {
                          notificationLoader = false;
                        });
                      }
                    });
                  }
                }
              }

              try {} catch (e) {
                crashlytics_bloc.recordCrashlyticsError(
                    e, "AllRecommendationListPerformance", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  onBack() async {
    Navigator.pop(context);
  }

  Future<Null> onRefresh() async {}

  Future<Null> onRefreshPending() async {
    setState(() {
      skipCollection = 0;
      mCollectionBadges.clear();
    });
    apiBadgesCount();
    apiCallingCollectiontBadges();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: DefaultTabController(
          length: 2,
          initialIndex: currentIndex,
          child: Scaffold(
              floatingActionButton: Padding(
                padding: const EdgeInsets.only(bottom: 20,right: 10),
                child: FloatingActionButton(

                  onPressed: () async {
                    final result = await Navigator.of(context).push(
                        new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                ManageBadges(widget.dob, widget.userId)));

                    if (result == "push") {
                      setState(() {
                        skip = 0;
                        isDataLoadingRequest = false;
                        skipCollection = 0;
                        mCollectionBadges.clear();
                        mRequestBadges.clear();
                      });
                      getSharedPreferences();
                    }
                  },
                  //tooltip: 'My FloatingActionButton',
                  child: Image.asset('assets/badges/add_Badges.png'),
                  // You can adjust the icon size using the 'size' property.
                  // size: Size(56, 56),
                ),
              ),

              body: SafeArea(
                child: Container(
                  color: Colors.white,
                  child: Column(
                    children: [
                      Container(
                        color: Colors.white,
                        child: SizedBox(
                          height: 90,
                          width: double.infinity,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (widget.screenName == 'main' ||
                                        widget.screenName == 'mainRequest') {
                                      onBack();
                                    } else {
                                      onBack();
                                      // Navigator.pop(context, isPerformChanges);
                                    }
                                  },
                                  child: Image.asset(
                                    "assets/generateScript/back.png",
                                    height: 32.0,
                                    width: 32.0,
                                  ),
                                ),
                                const HelpButtonWidget(),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20, right: 20),
                        child: Column(children: [
                          Align(
                              alignment: Alignment.topLeft,
                              child: BaseText(
                                text: "Manage badges",
                                textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w700,
                                fontSize: 28,
                                maxLines: 1,
                              )),
                          SizedBox(
                            height: 5,
                          ),
                          Align(
                              alignment: Alignment.topLeft,
                              child: BaseText(
                                text: "Review and manage badges",
                                textColor: AppConstants.colorStyle.lightPurple,
                                fontFamily:
                                AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                maxLines: 2,
                              )),
                          PaddingWrap.paddingfromLTRB(
                              0.0,
                              25.0,
                              0.0,
                              0.0,
                              Row(
                                children: [
                                  Expanded(
                                    child: InkWell(
                                      child: Container(
                                        //width: MediaQuery.of(context).size.width*0.45,
                                        child: Text(
                                          'Requested' + " (" + requestCount + ")",
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: strTabValue == 'Requested'
                                                ? ColorValues.WHITE
                                                : AppConstants
                                                .colorStyle.darkBlue,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                          ),
                                        ),
                                        padding: EdgeInsets.only(
                                            top: 9, bottom: 9, left: 9, right: 9),
                                        decoration: BoxDecoration(
                                          color: strTabValue == 'Requested'
                                              ? ColorValues.DARK_YELLOW
                                              : AppConstants.colorStyle.tabBg,
                                          border: Border.all(
                                              color: strTabValue == 'Requested'
                                                  ? ColorValues.DARK_YELLOW
                                                  : AppConstants.colorStyle
                                                  .borderGenerateScript),
                                          borderRadius: const BorderRadius.only(
                                              topLeft: Radius.circular(10),
                                              bottomLeft: Radius.circular(10)),
                                        ),
                                      ),
                                      onTap: () {
                                        //Request tab -
                                        setState(() {
                                          strTabValue = 'Requested';
                                        });

                                        setState(() {});
                                      },
                                    ),
                                  ),
                                  Expanded(
                                    child: InkWell(
                                      child: Container(
                                        //width: MediaQuery.of(context).size.width*0.45,
                                        child: Text(
                                          'Collections' + " (" + collectionCount + ")",
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: strTabValue == 'Collections'
                                                ? ColorValues.WHITE
                                                : AppConstants
                                                .colorStyle.darkBlue,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w500,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                          ),
                                        ),
                                        padding: EdgeInsets.only(
                                            top: 9, bottom: 9, left: 9, right: 9),
                                        decoration: BoxDecoration(
                                          color: strTabValue == 'Collections'
                                              ? ColorValues.DARK_YELLOW
                                              : AppConstants.colorStyle.tabBg,
                                          border: Border.all(
                                              color: AppConstants.colorStyle
                                                  .borderGenerateScript),
                                          borderRadius: const BorderRadius.only(
                                              topRight: Radius.circular(10),
                                              bottomRight: Radius.circular(10)),
                                        ),
                                      ),
                                      onTap: () {
                                        setState(() {
                                          strTabValue = 'Collections';
                                        });
                                        setState(() {
                                        });
                                      },
                                    ),
                                  ),

                                ],
                              )),
                        ]),
                      ),
                      SizedBox(
                        height: 15,
                      ),

                      strTabValue == 'Requested'
                          ?   Expanded(
                        flex: 1,
                        child:      RefreshIndicator(
                            onRefresh: onRefresh,
                            displacement: 0.0,

                            child: isDataLoadingRequest
                                ? Padding(
                              padding: const EdgeInsets.only(top: 20.0),
                              child: Padding(
                                padding: const EdgeInsets.only(top: 20.0),
                                child: Container(
                                  // width: 349,
                                  height: 336,

                                  child: Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                            width: 250.0,
                                            height: 180.0,
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                0.0,
                                                0.0,
                                                Image.asset(
                                                  "assets/badges/noBadgesAvailable.png",
                                                ))),

                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            )
                                :
                                 requestView(context)

                        ),
                      )
                          :  Expanded(
                        flex: 1,
                        // pending_recomendation
                        child:    RefreshIndicator(
                            onRefresh: onRefreshPending,
                            displacement: 0.0,
                            child: isDataLoadingPending
                                ? Padding(
                              padding: const EdgeInsets.only(top: 20.0),
                              child: Container(
                                // width: 349,
                                height: 336,

                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                          width: 250.0,
                                          height: 180.0,
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              Image.asset(
                                                "assets/badges/noBadgesAvailable.png",
                                              ))),

                                    ],
                                  ),
                                ),
                              ),
                            )
                                : collectionView(context)),
                      ),

                      SizedBox(height: 5)
                    ],
                  ),
                ),
              )
          ),
        ));
  }



  Widget requestView(BuildContext context) {
    return Container(
      child: ScrollablePositionedList.builder(
          physics: AlwaysScrollableScrollPhysics(),
          itemScrollController: _scrollControllerRequest,
          itemCount: mRequestBadgesModel == null ? 0 : mRequestBadges.length,
          itemBuilder: (BuildContext context, int index) {
            return requestListTile(context, index);
          }),
    );
  }

  Widget collectionView(BuildContext context) {
    return Container(

      margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0,0.0),
      child:ScrollablePositionedList.builder(
          physics: AlwaysScrollableScrollPhysics(),
          itemScrollController: _scrollControllerCollection,
          itemCount:  mCollectionBadgesModel == null ? 0 : mCollectionBadges.length,
          itemBuilder: (BuildContext context, int index) {
            return collectionListTile(context, index);
          }), /*ListView.builder(
          physics: AlwaysScrollableScrollPhysics(),
          controller: _scrollControllerCollection,
          itemCount:
              mCollectionBadgesModel == null ? 0 : mCollectionBadges.length,
          itemBuilder: (BuildContext context, int index) {
            positionOfCollection = index;
            return collectionListTile(context, index);
          }),*/
    );
  }

  Widget requestEmptyView(BuildContext context) {
    return Container(
      color: const Color(0xffFFFFFF),
      margin: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height -
                MediaQuery.of(context).size.height / 2,
            padding: const EdgeInsets.all(10),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/badges/request_not_available.png',
                      width: 180),
                  const SizedBox(height: 15),
                  Text(
                    'No request sending by you.',
                    textAlign: TextAlign.start,
                    style: TxtStyle.nunito_16_600Grey,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget collectionEmptyView(BuildContext context) {
    return Container(
      color: const Color(0xffFFFFFF),
      margin: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height -
                MediaQuery.of(context).size.height / 2,
            padding: const EdgeInsets.all(10),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/badges/collection_not_available.png',
                      width: MediaQuery.of(context).size.width),
                  const SizedBox(height: 15),
                  Text(
                    'No badge received by you.',
                    textAlign: TextAlign.start,
                    style: TxtStyle.nunito_16_600Grey,
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget requestedBottmAction(index) {
    return Container(
      decoration: BoxDecoration(
        color: ColorValues
            .LIST_BOTTOM_BG,
        borderRadius:
        BorderRadius.only(
          bottomLeft:
          Radius.circular(
              10.0),
          bottomRight:
          Radius.circular(
              10.0),
        ),
      ),
      child: Row(
        children: [

          // Send Reminder ---
          Expanded(
            child:  Container(
              alignment:
              Alignment
                  .center,
              child:  GestureDetector(
                  onTap: () {

                    setState(() {
                      if (cnt == 0) {
                        remainderFlag = true;
                        cnt = 1;
                      } else {
                        remainderFlag = false;
                        cnt = 0;
                      }
                    });

                  },
                  child: InkWell(
                    child: Row(
                      children: [
                        Spacer(),

                        Text(
                          'Send reminder',
                          maxLines: 1,
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              fontSize: 14.0,
                              fontFamily: Constant.latoMedium,
                              fontWeight: FontWeight.w600,
                              color:
                              mRequestBadges[index].isReminderEnable == true
                                  ? ColorValues.HEADING_COLOR_EDUCATION_2
                                  : ColorValues.HEADING_COLOR_EDUCATION_2
                                  .withOpacity(0.3)),
                        ),

                        Spacer(),

                      ],
                    ),
                    onTap: () {
                      if (mRequestBadges[index].isReminderEnable ==
                          true) {
                        apiForReminder(
                            mRequestBadges[index].badgeReqId.toString(),
                            index);
                      } else {
                        showSucessMsg(Util.getConvertedDateStampNew(
                            mRequestBadges[index]
                                .reminderDay
                                .toString()));
                       }
                    },
                  )),

            ),

          ),
          //separator viw
          Container(
            alignment: Alignment
                .center,
            width: 1,
            height: 40,
            color: ColorValues
                .BORDER_GENERATE_SCRIPT,
          ),

          //Cancel Button
          Expanded(
            child: Container(
              alignment:
              Alignment
                  .center,
              child: InkWell(
                child: PaddingWrap
                    .paddingfromLTRB(
                  0.0,
                  3.0,
                  0.0,
                  0.0,
                  Text("Cancel request",
                      style: TextStyle(
                          color: ColorValues
                              .HEADING_COLOR_EDUCATION_1,
                          fontSize:
                          14.0,
                          fontFamily: Constant
                              .latoMedium,
                          fontWeight:
                          FontWeight.w600)),
                ),
                onTap: () {
                  badgeDialog(index);
                },
              ),
            ),
            flex: 1,
          )
        ],
      ),

    );
  }

  Widget requestListTile(BuildContext context, int index) {
    return
        Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20,right: 20,top: 12,bottom: 10),
          child: Container(
            decoration: BoxDecoration(
              color: widget.screenName == "Notification"&&widget.id ==
                  mRequestBadges[index].badgeReqId.toString()
                  ? ColorValues.light_COLOR
                  : ColorValues.SELECTION_BG,

              border: Border.all(
                  color: ColorValues
                      .BORDER_GENERATE_SCRIPT),
              borderRadius:
              const BorderRadius.all(
                  Radius.circular(10)
              ),
            ),

            child: Column(
              children: [

                Padding(
                  padding: const EdgeInsets.only(top: 10,left: 10,right: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      mRequestBadges[index].status == "created"
                          ? Container(
                        height: 23,
                        width: 90,
                        margin: const EdgeInsets.only(top: 0),
                        decoration: const BoxDecoration(
                          color: Color(0xffFFF3CD),
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Center(
                          child: Text(
                            'Requested'.toUpperCase(),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              fontFamily: Constant.latoRegular,
                              color: Color(0xffDCA600),
                            ),
                          ),
                        ),
                      )
                          : Container(
                        height: 20,
                        width: 67,
                        margin: const EdgeInsets.only(right: 5),
                        decoration: const BoxDecoration(
                          color: Color(0xFFD1E7DD),
                          borderRadius: BorderRadius.all(Radius.circular(12)),
                        ),
                        child: Center(
                          child: Text(
                            'Active'.toUpperCase(),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              fontFamily: Constant.latoRegular,
                              color: Color(0xFF198754),
                            ),
                          ),
                        ),
                      ),


                    ],
                  ),
                ),

                const SizedBox(height: 5),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.only(left: 12,right: 10),
                  child: Row(
                    children: [

                      Container(
                        width: 75,
                        height: 78,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10), // half of the height to make it circular
                          border: Border.all(width: 1, color: Color(0xffD4E4FF)),
                        ),
                        child: Center(
                            child: SizedBox(
                              height: 50,
                              width: 50,
                              child: FadeInImage.assetNetwork(
                                placeholder: 'assets/profile/user_on_user.png',
                                image: Constant.IMAGE_PATH_SMALL +
                                    ParseJson.getMediumImage(mRequestBadges[index].image),
                                width: 50,
                                height: 50,
                                fit: BoxFit.cover,
                              ),
                            )
                        ),
                      ),


                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            mRequestBadges[index].name,
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              fontFamily: Constant.latoRegular,
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                            ),
                          ),
                          const SizedBox(height: 7),
                          Text(
                            mRequestBadges[index].companyName,
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              fontFamily: Constant.latoMedium,
                              color: ColorValues.labelColor,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Sent On: ' +
                                Util.getConvertedDateStampNew(
                                    mRequestBadges[index].date.toString()),
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              fontFamily: Constant.latoMedium,
                              color: ColorValues.labelColor,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                mRequestBadges[index].showReminderTimer
                    ?
                Padding(
                  padding: const EdgeInsets.only(top: 7,bottom: 5,left: 10,right: 10),
                  child: Container(
                    height: 55,
                    decoration: BoxDecoration(
                      color: Color(0xffFFEBEB),

                      borderRadius:
                      const BorderRadius.all(
                          Radius.circular(7)
                      ),
                    ),

                    padding:
                    EdgeInsets
                        .only(
                        top: 8),
                    alignment:
                    Alignment
                        .topLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 5,bottom: 5,left: 7),
                      child: Text(
                        'Reminder sent. You can send another reminder on ' +
                            Util.getConvertedDateStampNew(
                                mRequestBadges[index].reminderDay.toString()) +
                            '.',
                        overflow:
                        TextOverflow
                            .ellipsis,
                        textAlign:
                        TextAlign
                            .start,
                        maxLines: 3,
                        style:
                        TextStyle(
                          fontSize:
                          12,
                          fontWeight:
                          FontWeight
                              .w500,
                          color: ColorValues
                              .circle4,
                          fontFamily:
                          Constant
                              .TYPE_CUSTOMREGULAR,
                        ),
                      ),
                    ),
                  ),
                )
                    :
                const SizedBox(),

                Padding(
                  padding: const EdgeInsets.only(top:10),
                  child: Container(
                    height:1,
                    color: ColorValues.BORDER_GENERATE_SCRIPT,
                  ),
                ),

                requestedBottmAction(index)


              ],
            ),
          ),
        ),

      ],
      /*  ),*/
    );
  }

  Future apiCallForUpdateBadgesStatus(
      badges, badgeReqId,isHide, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("${mCollectionBadges[index].userId}");
        print("${mCollectionBadges[index].userRoleId}");
        print("${mCollectionBadges[index]}");
        Map map = {
          "badgeReqId": mCollectionBadges[index].badgeReqId ,
          "isActive":  isHide,
          "userId" : widget.userId,
          "roleId":"1",
        };
        print("${map}");

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_BADGESCHANGESTATUS, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            print("msg");

            if (status == "Success") {
              // ToastWrap.showToast("Recommendation Added Successfully");
              // recommendation.stag = "Added";
              print("called");

              bloc.fetcprofileData(userIdPref, context, prefs, true);

              if (mCollectionBadges[index].isActive == "true") {
                setState(() {
                  mCollectionBadges[index].isActive = "false";
                });
              } else {
                setState(() {
                  mCollectionBadges[index].isActive = "true";
                });
              }

              // isPerformChanges = "push";
              setState(() {
                mCollectionBadges;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiForReminder(String badgeReqId, int index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": widget.userId,
          "roleId": "1",
          "badgeReqId": badgeReqId,
        };

        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_SEND_REMINDER_BADGES, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String reminderDay =
                  response.data['result']['reminderDay'].toString();

              setState(() {
                setState(() {
                  mRequestBadges[index].isReminderEnable = false;
                  mRequestBadges[index].showReminderTimer = true;
                  mRequestBadges[index].reminderDay = int.parse(reminderDay);
                });

                Future.delayed(Duration(seconds: 20), () {
                  setState(() {
                    mRequestBadges[index].showReminderTimer = false;
                  });
                });
              });
            } else {
              ToastWrap.showToasSucess(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }


  void showSucessMsg(String date)  {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: "You can send another reminder on " + date + ".",
          positiveText: "OK",
          positiveTextColor: ColorValues.BLUE_COLOR,
          onPositiveTap: (){
            //apiCallForDeleteOppo();

          },
        );
      },
    );
  }



  showSucessMsgold(String date) {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(height: 15.0),
              Image.asset(
                "assets/recommendation/reminder_info.png",
                height: 80.0,
                width: 79.0,
              ),
              SizedBox(height: 12.0),
              Text(
                "You can send another reminder on \n" + date+".",
                textAlign: TextAlign.center,
                maxLines: 3,
                style: TextStyle(
                    fontSize: 16.0,
                    color: ColorValues.riminderColor,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontWeight: FontWeight.w400),
              ),
              Padding(
                  padding: EdgeInsets.only(
                      left: 20.0, top: 20.0, right: 20.0, bottom: 15.0),
                  child: InkWell(
                    child: Container(
                        height: 40.0,
                        width: 60.0,
                        color: ColorValues.BLUE_COLOR,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              MessageConstant.OK,
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 20.0,
                              ),
                            )
                          ],
                        )),
                    onTap: () {
                      Navigator.of(context).pop(true);
                    },
                  ))
            ],
          ),
        );
      },
    );
  }

  Future apiCallingForDeleteBadges(badgeReqId, index) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "badgeReqId": badgeReqId,
      };

      Response response = await ApiCalling()
          .apiCallDeleteWithMapData(context, Constant.ENDPOINT_BADGES, map);
      CustomProgressLoader.cancelLoader(context);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            mRequestBadges.removeAt(index);
            apiBadgesCount();

            if (mRequestBadges == null || mRequestBadges.isEmpty) {
              setState(() {
                isDataLoadingRequest = true;
              });
            }
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallUpdateStatus(badgeId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {"badgeReqId": badgeId};

        print(map.toString());
        Response response = await ApiCalling()
            .apiCallDeleteWithMapData(context, Constant.ENDPOINT_BADGES, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              mRequestBadges.removeAt(index);
              setState(() {
                mRequestBadges;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }


  void badgeDialog(index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: "Are you sure you want to withdraw your request?",
          onPositiveTap: (){
            apiCallingForDeleteBadges(
                mRequestBadges[index]
                    .badgeReqId,
                index);
          },
        );
      },
    );
  }

  void badgeDialogold(index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 195.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        25.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(20.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
//

                                                  RichText(
                                                    textAlign: TextAlign.center,
                                                    text: TextSpan(
                                                      text:
                                                          "Are you sure you want to withdraw your request?",
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                      children: <TextSpan>[],
                                                    ),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Ok",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              // Delete

                                              Navigator.pop(context);

                                              apiCallingForDeleteBadges(
                                                  mRequestBadges[index]
                                                      .badgeReqId,
                                                  index);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

   /// Old CollectionListTileNew
  /*
  Widget collectionListTile(BuildContext context, int index) {
    return  Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
            margin: EdgeInsets.fromLTRB(3.0, 3.0, 3.0,2.0),
            color:widget.screenName == "notificationCollection"&&widget.id ==
                mCollectionBadges[index].badgeReqId.toString()
                ? ColorValues.light_COLOR
                : Colors.transparent,

            child: Row(
                children: [
                  ClipOval(
                      child: FadeInImage.assetNetwork(
                    fit: BoxFit.contain,
                    placeholder: 'assets/profile/user_on_user.png',
                    image: Constant.IMAGE_PATH_SMALL +
                        ParseJson.getMediumImage(
                            mCollectionBadges[index].image),
                    height: 71.0,
                    width: 60.0,
                  )),
                  const SizedBox(width: 15),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        mCollectionBadges[index].name,
                        textAlign: TextAlign.start,
                        style: TxtStyle.nunito_16_600Black,
                      ),
                      const SizedBox(height: 5),
                      Text(
                        mCollectionBadges[index].companyName,
                        textAlign: TextAlign.start,
                        style: TxtStyle.nunito_14_500Black,
                      ),
                      const SizedBox(height:5),
                      Text(
                        mCollectionBadges[index].type == "request"
                            ? 'Issued on: ' +
                                Util.getConvertedDateStampNew(
                                    mCollectionBadges[index].date.toString())
                            : 'Issued on: ' +Util.getConvertedDateStampNew(
                                mCollectionBadges[index].date.toString()),
                        textAlign: TextAlign.start,
                        style: TxtStyle.nunito_12_400Grey,
                      ),
                    ],
                  )
                ],
              )),
          Container(
            color: const Color(0xffDEDEDE),
            width: MediaQuery.of(context).size.width,
            height: 1,
          )
        ],
    );
  }

 */
  Widget collectionBottmAction(index) {
    return Container(
      height: 40,
      decoration: BoxDecoration(
        color: ColorValues
            .LIST_BOTTOM_BG,
        borderRadius:
        BorderRadius.only(
          bottomLeft:
          Radius.circular(
              10.0),
          bottomRight:
          Radius.circular(
              10.0),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Expanded(
            child: Container(
              alignment:
              Alignment
                  .center,
              child: InkWell(
                child: PaddingWrap
                    .paddingfromLTRB(
                  0.0,
                  3.0,
                  0.0,
                  0.0,
                  Text(
                      mCollectionBadges[index].isActive == "true"
                          ? "Hide"
                          : "Show",
                      style: TextStyle(
                          color: ColorValues
                              .HEADING_COLOR_EDUCATION_1,
                          fontSize:
                          14.0,
                          fontFamily: Constant
                              .latoMedium,
                          fontWeight:
                          FontWeight.w600)
                  ),
                ),
                onTap: () {

                  print(mCollectionBadges[index].isActive);

                  if  (mCollectionBadges[index].isActive == "true") {
                    apiCallForUpdateBadgesStatus(mCollectionBadges[index], mCollectionBadges[index].badgeReqId, false, index);

                  } else {
                    apiCallForUpdateBadgesStatus(mCollectionBadges[index], mCollectionBadges[index].badgeReqId, true, index);

                  }
                },
              ),
            ),
          ),

        ],
      ),

    );
  }


  Widget collectionListTile(BuildContext context, int index) {
    return Container(
      margin: const EdgeInsets.only(top: 5, bottom: 0),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20,top: 5),
            child: Container(
              decoration: BoxDecoration(

                color:widget.screenName == "notificationCollection"&&widget.id ==
                    mCollectionBadges[index].badgeReqId.toString()
                    ? ColorValues.light_COLOR
                    : ColorValues.SELECTION_BG,

                border: Border.all(
                    color: ColorValues
                        .BORDER_GENERATE_SCRIPT),
                borderRadius:
                const BorderRadius.all(
                    Radius.circular(10)
                ),
              ),

              child: Padding(
                  padding: const EdgeInsets.only(left: 0.0, right: 0,top: 10),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 5,left: 10,right: 10),
                        child: Row(
                          children: [

                            Container(
                              width: 75,
                              height: 78,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10), // half of the height to make it circular
                                border: Border.all(width: 1, color: Color(0xffD4E4FF)),
                              ),
                              child: Center(
                                  child: SizedBox(
                                    height: 50,
                                    width: 50,
                                    child:
                                    FadeInImage.assetNetwork(
                                      placeholder: 'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getMediumImage(
                                              mCollectionBadges[index].image),
                                      width: 50,
                                      height: 50,
                                      fit: BoxFit.cover,
                                    )
                                    // mCollectionBadges[index].isActive == "true" ?
                                    // FadeInImage.assetNetwork(
                                    //   placeholder: 'assets/profile/user_on_user.png',
                                    //   image: Constant.IMAGE_PATH_SMALL +
                                    //       ParseJson.getMediumImage(
                                    //           mCollectionBadges[index].image),
                                    //   width: 50,
                                    //   height: 50,
                                    //   fit: BoxFit.cover,
                                    // ) : SizedBox(),
                                  )
                              ),
                            ),

                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  mCollectionBadges[index].name,
                                  textAlign: TextAlign.start,
                                  style:
                                  TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: Constant.latoRegular,
                                    color:ColorValues.HEADING_COLOR_EDUCATION_1,

                                  )
                                  // mCollectionBadges[index].isActive == "true" ? TextStyle(
                                  //   fontSize: 16,
                                  //   fontWeight: FontWeight.w600,
                                  //   fontFamily: Constant.latoRegular,
                                  //   color:ColorValues.HEADING_COLOR_EDUCATION_1,
                                  //
                                  // ) :  TextStyle(
                                  //   fontSize: 16,
                                  //   fontWeight: FontWeight.w600,
                                  //   fontFamily: Constant.latoRegular,
                                  //   color:ColorValues.light_grey,
                                  // ),

                                ),
                                const SizedBox(height: 7),
                                Text(
                                  mCollectionBadges[index].companyName,
                                  textAlign: TextAlign.start,

                                    style:TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: Constant.latoMedium,
                                      color: ColorValues.labelColor,

                                  )
                                  // mCollectionBadges[index].isActive == "true" ? TextStyle(
                                  //   fontSize: 12,
                                  //   fontWeight: FontWeight.w500,
                                  //   fontFamily: Constant.latoRegular,
                                  //   color:ColorValues.labelColor,
                                  //
                                  // ) :  TextStyle(
                                  //   fontSize: 12,
                                  //   fontWeight: FontWeight.w500,
                                  //   fontFamily: Constant.latoRegular,
                                  //   color:ColorValues.light_grey,
                                  // ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  mCollectionBadges[index].type == "request"
                                      ? 'Issued on: ' +
                                      Util.getConvertedDateStampNew(
                                          mCollectionBadges[index].date.toString())
                                      : 'Issued on: ' +
                                      Util.getConvertedDateStampNew(
                                          mCollectionBadges[index].date.toString()),
                                  textAlign: TextAlign.start,
                                  style:
                                  TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: Constant.latoRegular,
                                    color: ColorValues.labelColor,

                                  )
                                  // mCollectionBadges[index].isActive == "true" ? TextStyle(
                                  //   fontSize: 12,
                                  //   fontWeight: FontWeight.w500,
                                  //   fontFamily: Constant.latoRegular,
                                  //   color:ColorValues.labelColor,
                                  //
                                  // ) :  TextStyle(
                                  //   fontSize: 12,
                                  //   fontWeight: FontWeight.w500,
                                  //   fontFamily: Constant.latoRegular,
                                  //   color:ColorValues.light_grey,
                                  // ),
                                ),
                                const SizedBox(height: 2),


                              ],
                            )
                          ],
                        ),
                      ),
                      const SizedBox(height: 15),
                      // Padding(
                      //   padding: const EdgeInsets.only(top:10),
                      //   child: Container(
                      //     height:1,
                      //     color: ColorValues.BORDER_GENERATE_SCRIPT,
                      //   ),
                      // ),
                     // collectionBottmAction(index)
                    ],
                  )),
            ),
          ),
          const SizedBox(height: 15),

        ],
      ),
    );
  }


  _buildChoiceList(type) {
    List<Widget> choices = List();

    choices.add(Container(
        padding: const EdgeInsets.all(0.0),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15.0),
            color: type == "request"
                ? Color(0xFFDDD74A)
                : type == "Replied"
                    ? ColorValues.BUTTON_PENDING
                    : Color(0xFF3D9B6E),
          ),
          padding: EdgeInsets.fromLTRB(15.0, 5.0, 15.0, 5.0),
          child: Text(
            type == MessageConstant.ABOUT_GROUP_REQUESTED
                ? "REQUESTED"
                : type == "Replied"
                    ? "PENDING"
                    : "ACTIVE",
            style: TextStyle(
                color: Colors.white,
                fontSize: 12.0,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
          ),
        )));

    return choices;
  }
}
