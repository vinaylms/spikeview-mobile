import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class RefferalModel {
  String referralId,
      referralType,
      referredByID,
      referredByRoleId,
      referredTo,
      referralStatus,
      userId,
      dateTime,
      updateDateTime,
      referredById,
      updateDate;

  RefferalModel(
      this.referralId,
      this.referralType,
      this.referredByID,
      this.referredByRoleId,
      this.referredTo,
      this.referralStatus,
      this.userId,
      this.dateTime,
      this.updateDateTime,
      this.referredById,
      this.updateDate);
}
