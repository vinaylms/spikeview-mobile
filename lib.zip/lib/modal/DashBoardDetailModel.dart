import 'dart:io';


class DashBoardDetailModel{
  String actedBy,profileImage,actedOn,actedUserId,message1,message2,actedRoleId;

  String badge;
  String badgeImage;
  int gamificationPoints;
  DashBoardDetailModel(this.actedBy, this.profileImage, this.actedOn, this.actedUserId, this.message1,this.message2,this.actedRoleId,this.badge,this.gamificationPoints
      ,this.badgeImage
     );

}
