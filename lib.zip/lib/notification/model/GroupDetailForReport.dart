import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';

import 'package:intl/intl.dart';

class GroupDetailForReport {
  String status;
  Result result;

  GroupDetailForReport({this.status, this.result});

  GroupDetailForReport.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    result =
        json['result'] != null ? new Result.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.toJson();
    }
    return data;
  }
}

class Result {
  String sId;
  int groupId;
  String groupName;
  String type;
  int creationDate;
  String creationConvertedDate;
  int createdBy;
  int roleId;
  bool isActive;
  String aboutGroup;
  String otherInfo;
  String groupImage;
  bool isOpportunityAdded;
  int iV;
  String groupMessage;
  Report report;

  Result(
      {this.sId,
      this.groupId,
      this.groupName,
      this.type,
      this.creationDate,
      this.createdBy,
      this.roleId,
      this.isActive,
      this.aboutGroup,
      this.otherInfo,
      this.groupImage,
      this.isOpportunityAdded,
      this.iV,
      this.groupMessage,
      this.report});

  Result.fromJson(Map<String, dynamic> json) {
    print("group data+++"+json.toString());
    sId = json['_id'];
    groupId = json['groupId'];
    groupName = json['groupName']== null ? "" : json['groupName'].toString();
    type = json['type']== null ? "" : json['type'].toString();
    creationDate = json['creationDate'];
    creationConvertedDate = "";
    if (creationDate != null && creationDate != "" && creationDate != "null") {
      var now = DateTime.fromMillisecondsSinceEpoch(creationDate);
      var formatter = DateFormat('MMM dd, yyyy');
      creationConvertedDate = formatter.format(now);
    }
    createdBy = json['createdBy'];
    roleId = json['roleId'];
    isActive = json['isActive']==null?false:json['isActive'];
    aboutGroup = json['aboutGroup']== null ? "" : json['aboutGroup'].toString();
    otherInfo = json['otherInfo'] == null ? "" : json['otherInfo'].toString();
    groupImage = json['groupImage'] == null ? "" : json['groupImage'];
    isOpportunityAdded = json['isOpportunityAdded'];
    iV = json['__v'];
    groupMessage = json['groupMessage']== null ? "" : json['groupMessage'];
    report =
        json['report'] != null ? new Report.fromJson(json['report']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['groupId'] = this.groupId;
    data['groupName'] = this.groupName;
    data['type'] = this.type;
    data['creationDate'] = this.creationDate;
    data['createdBy'] = this.createdBy;
    data['roleId'] = this.roleId;
    data['isActive'] = this.isActive;
    data['aboutGroup'] = this.aboutGroup;
    data['otherInfo'] = this.otherInfo;
    data['groupImage'] = this.groupImage;
    data['isOpportunityAdded'] = this.isOpportunityAdded;
    data['__v'] = this.iV;
    data['groupMessage'] = this.groupMessage;
    if (this.report != null) {
      data['report'] = this.report.toJson();
    }
    return data;
  }
}

class Report {
  List<String> reasonType;
  String sId;
  int reportId;
  int reportedBy;
  int reportedRoleId;
  String reportType;
  ReportTypeId reportTypeId;
  String reason;
  int reportDate;
  int iV;

  Report(
      {this.reasonType,
      this.sId,
      this.reportId,
      this.reportedBy,
      this.reportedRoleId,
      this.reportType,
      this.reportTypeId,
      this.reason,
      this.reportDate,
      this.iV});

  Report.fromJson(Map<String, dynamic> json) {
    reasonType = json['reasonType'].cast<String>();
    sId = json['_id'];
    reportId = json['reportId'];
    reportedBy = json['reportedBy'];
    reportedRoleId = json['reportedRoleId'];
    reportType = json['reportType'];
    reportTypeId = json['reportTypeId'] != null
        ? new ReportTypeId.fromJson(json['reportTypeId'])
        : null;
    reason = json['reason'];
    reportDate = json['reportDate'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['reasonType'] = this.reasonType;
    data['_id'] = this.sId;
    data['reportId'] = this.reportId;
    data['reportedBy'] = this.reportedBy;
    data['reportedRoleId'] = this.reportedRoleId;
    data['reportType'] = this.reportType;
    if (this.reportTypeId != null) {
      data['reportTypeId'] = this.reportTypeId.toJson();
    }
    data['reason'] = this.reason;
    data['reportDate'] = this.reportDate;
    data['__v'] = this.iV;
    return data;
  }
}

class ReportTypeId {
  int groupId;

  ReportTypeId({this.groupId});

  ReportTypeId.fromJson(Map<String, dynamic> json) {
    groupId = json['groupId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['groupId'] = this.groupId;
    return data;
  }
}
