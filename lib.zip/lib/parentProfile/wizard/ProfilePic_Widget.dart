// Create a Form Widget
import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/wizard/AddSummary_Widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfilePic_Widget extends StatefulWidget {
  String title, parentName;
  String studentId;
  StudentDataModel studModel;

  ProfilePic_Widget(StudentDataModel studModel) {
    this.studModel = studModel;
  }

  @override
  ProfilePicState createState() {
    return  ProfilePicState(studModel);
  }
}

class ProfilePicState extends State<ProfilePic_Widget> {
  SharedPreferences prefs;
  String userIdPref, token;
  File imagePath = null;

  ProfilePicState(this.studModel);

  StudentDataModel studModel;
  final _formKey = GlobalKey<FormState>();
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String strPrefixPathforCoverPhoto,
      strPrefixPathforProfilePhoto = "sv_532/profile/",
      strAzureCoverImageUploadPath = "",
      strAzureProfileImageUploadPath = "";
  String strNetworkImage = "";
  static StreamController syncDoneController = StreamController.broadcast();
  String coverImagePath = "";
  String profileImagePath = "";
  TextEditingController tagLineController =  TextEditingController(text: "");
  bool isSelectedPredefindImage=true;
  File imagePathCover;
  final PageController controller =  PageController(
    viewportFraction: 0.25,
  );
  String strTagline;
  int selectedIndexCover = 0;
  List<String> imageList =  List();

  Future getImages(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await  ApiCalling2()
            .apiCall(context, Constant.ENDPOINT_MEDIA, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              imageList = ParseJson.parseMedia(response.data['result']);
              if (imageList != null) {
                setState(() {
                  imageList;
                  if (imageList.length > 0) coverImagePath = imageList[0];

                  imageList.add("add");
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    // userIdPref = prefs.getString(UserPreference.PARENT_ID);
    userIdPref = prefs.getString(UserPreference.PARENT_WIZARD_USERID);

    getImages(true);
    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_COVER +
        "/";

    strPrefixPathforProfilePhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";

    token = prefs.getString(UserPreference.USER_TOKEN);
    coverImagePath = studModel.coverImage;
    profileImagePath = studModel.profilePicture;
    print('apurva tagline studModel.tagline;;; ${studModel.tagline}');
    tagLineController.text = studModel.tagline == "null" || studModel.tagline == null || studModel.tagline == '' ? "" : studModel.tagline;
    setState(() {
      coverImagePath;
      profileImagePath;
      tagLineController;
    });
    var isConnect = await ConectionDetecter.isConnected();
    if (isConnect) {
      await callApiForSaas(false);
    } else {
      ToastWrap.showToast(
          MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    strNetworkImage =
        studModel.profilePicture == "null" ? "" : studModel.profilePicture;


    setState(() {
      strNetworkImage;
      //strTagline = studModel.tagline;
      //tagLineController.text = studModel.tagline;
    });
    // TODO: implement initState
    super.initState();
  }

  // API Calling here

  Future<Null> _cropImage(File imageFile, name) async {
    if (name == "imagePath") {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.0,
        ratioY: 1.0,
      );
    }
  }

  //--------------------------Upload Cover Image Data ------------------
  Future uploadCoverIMage() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        CustomProgressLoader.showLoader(context);
        Map map = {
          "coverImage": coverImagePath,
          "profilePicture": profileImagePath,
          "userId": userIdPref,
          "tagline": tagLineController.text,
        };
        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_USER_COVER_PHOTO_UPDATE, map);
        //  }
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              prefs.setString(
                  UserPreference.PROFILE_IMAGE_PATH, profileImagePath);

              studModel.profilePicture = profileImagePath;

              studModel.coverImage = coverImagePath;
              studModel.tagline = tagLineController.text;

              setState(() {
                studModel;
              });
              onNextClick();

              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await  ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above


    Row getUpperDots() {
      return  Row(
        children: <Widget>[
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
           Container(
            width: 10.0,
          ),
           Container(
            decoration:  BoxDecoration(
              color: ColorValues.GREY_TEXT_COLOR,
              shape: BoxShape.circle,
            ),
            height: 15.0,
            width: 15.0,
          ),
        ],
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
      );
    }

    InkWell isImageSelectedView() {
      return  InkWell(
        child:  Container(
          height: 170.0,
          width: 170.0,
          child:  Stack(
            children: <Widget>[
               Center(
                  child:  Container(
                child:  ClipOval(
                    child:  Image.file(
                  imagePath,
                  height: 170.0,
                  width: 170.0,
                  fit: BoxFit.cover,
                )),
                height: 170.0,
                width: 170.0,
                padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              )),
            ],
          ),
        ),
      );
    }

    Container getBottomBar() {
      return  Container(
          color: Colors.transparent,
          child:  Row(
            children: <Widget>[
               InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 20.0),
                    child: Image.asset(
                      '',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  //  Navigator.pop(context, "push");
                  // syncDoneController.add("refresh");
                },
              ),
               Expanded(
                child:  InkWell(
                  child:  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                      child:  Text(
                        "",
                        style: TextStyle(
                            fontSize: 16.0,
                            fontFamily: Constant.customRegular,
                            color: ColorValues.GREY_TEXT_COLOR),
                        textAlign: TextAlign.center,
                      )),
                  onTap: () {
                    // skipOnClick();
                  },
                ),
                flex: 1,
              ),
      profileImagePath != null&& profileImagePath != "null" &&
                      profileImagePath != ""

                  ?  InkWell(
                      child:  Padding(
                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 20.0),
                          child: Image.asset(
                            'assets/newDesignIcon/parentProfile/next.png',
                            height: 45.0,
                            width: 45.0,
                          )),
                      onTap: () {

//                        if (studModel.profilePicture != profileImagePath)
//                          uploadCoverIMage();
//                        else
//                          onNextClick();
                        uploadCoverIMage();
                      },
                    )
                  :  Padding(
                      padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                      child: Image.asset(
                        'assets/newDesignIcon/parentProfile/next_gray.png',
                        height: 45.0,
                        width: 45.0,
                      ))
            ],
          ));
    }

    final tagline =  Container(
        padding:  EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          maxLength: 100,
          cursorColor: Constant.CURSOR_COLOR,
          maxLines: null,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          controller: tagLineController,
          decoration:  InputDecoration(
            errorStyle:Util.errorTextStyle,
            fillColor: Colors.transparent,
            counterText: "",
            contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            labelText: "Tagline For Your Child",
            hintText: "Work Hard, Play Hard",
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: ColorValues.DARK_GREY,width: 1.0),
            ),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
          ),
          onSaved: (val) => strTagline = val.trim(),
        ));

    Future<Null> _cropImage(File imageFile, name) async {
      if (name == "imagePath") {
        imagePath = await ImageCropper.cropImage(
          sourcePath: imageFile.path,
          ratioX: 1.0,
          ratioY: 1.0,
        );
      } else {
        imagePathCover = await ImageCropper.cropImage(
          sourcePath: imageFile.path,
          ratioX: 1.0,
          ratioY: 1.0,
        );
      }
    }

    Future getImage() async {
      imagePath = await UploadMedia(context).pickImageFromGallery();
    //  imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null&&imagePath != "") {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          if (imagePath != null) {
            await _cropImage(imagePath, "imagePath");
            try {
              CustomProgressLoader.showLoader(context);
              Timer _timer =
               Timer(const Duration(milliseconds: 400), () async {
                try {
                  strAzureProfileImageUploadPath = await uploadImgOnAzure(
                      imagePath
                          .toString()
                          .replaceAll("File: ", "")
                          .replaceAll("'", "")
                          .trim(),
                      strPrefixPathforProfilePhoto);
                } catch (e) {
                  CustomProgressLoader.cancelLoader(context);
                }

                if (strAzureProfileImageUploadPath != "" &&
                    strAzureProfileImageUploadPath != "false") {
                  profileImagePath = strPrefixPathforProfilePhoto +
                      strAzureProfileImageUploadPath;
                  setState(() {
                    profileImagePath;
                    imagePath = imagePath;
                  });
                  CustomProgressLoader.cancelLoader(context);
                } else {
                  CustomProgressLoader.cancelLoader(context);
                }
              });
            }catch(e){
              CustomProgressLoader.cancelLoader(context);
            }
          }
        } else {

          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    Future getImageCover() async {
      imagePathCover = await UploadMedia(context).pickImageFromGallery();
      //imagePathCover = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePathCover != null&&imagePathCover != "") {
        String strPath = imagePathCover.toString().substring(
            imagePathCover.toString().lastIndexOf("/") + 1,
            imagePathCover.toString().length);

        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          if (imagePathCover != null) {
            await _cropImage(imagePathCover, "cover");
            CustomProgressLoader.showLoader(context);
            try{
            Timer _timer =
                 Timer(const Duration(milliseconds: 400), () async {
              try {
                strAzureCoverImageUploadPath = await uploadImgOnAzure(
                    imagePathCover
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    strPrefixPathforCoverPhoto);
              } catch (e) {
                CustomProgressLoader.cancelLoader(context);
              }
              if (strAzureCoverImageUploadPath != "" &&
                  strAzureCoverImageUploadPath != "false") {
                coverImagePath =
                    strPrefixPathforCoverPhoto + strAzureCoverImageUploadPath;
                setState(() {
                  isSelectedPredefindImage=false;
                  imagePathCover = imagePathCover;
                  coverImagePath;
                });


                CustomProgressLoader.cancelLoader(context);
              } else {
                CustomProgressLoader.cancelLoader(context);
              }
            });
            }catch(e){
              CustomProgressLoader.cancelLoader(context);
            }
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  WillPopScope(
        onWillPop: () {},
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            body:  Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  //CustomViews.getSepratorLine(),
                  /*Padding(
                    padding:  EdgeInsets.only(top:statusBarHeight+20,left: 13.0,right: 13.0),
                    child:  Text(
                      //"Step 1 of 7",
                      "",
                      style:  TextStyle(
                          fontSize: 15.0,
                          fontFamily: Constant.customRegular,
                          color:  ColorValues.HEADING_COLOR_EDUCATION),
                    ),
                  ),*/

                  Padding(
                    padding:  EdgeInsets.only(top:statusBarHeight+20,left: 13.0,right: 13.0,bottom: 7),
                    child: Center(
                      child:  Image.asset(
                          "assets/progress_indecator/indicator_step1.png",
                          height: 26.0,
                          width: 300.0,
                          fit: BoxFit.fitWidth
                      ),
                    ),
                  ),



                   Expanded(
                    child:  Center(
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            13.0,
                            13.0,
                            0.0,
                            ListView(
                              children: <Widget>[
                                 Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    /*Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 20, 0, 10),
                                      child:  Image.asset(
                                          "assets/profile/student/st11.png",
                                          height: 10.0,
                                          width: 100.0,
                                          fit: BoxFit.fitHeight),
                                    ),*/
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 0, 0, 10),
                                      child:  Image.asset(
                                          "assets/profile/student/add_image.png",
                                          height: 50.0,
                                          width: 50.0,
                                          fit: BoxFit.fitHeight),
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        13.0,
                                        13.0,
                                        TextViewWrap.textViewMultiLine(
                                            "Let's create your child’s profile. Choose a photo and background that represents them well.",
                                            TextAlign.center,
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            16.0,
                                            FontWeight.bold,
                                            5 )),
                                     Container(
                                      child:  Container(
                                        height: 350.0,
                                        color:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
                                        child:  Stack(
                                          children: <Widget>[
                                             Positioned(
                                                top: 0.0,
                                                bottom: 20.0,
                                                left: 30.0,
                                                right: 30.0,
                                                child:  InkWell(
                                                  child:  Stack(
                                                    children: <Widget>[
                                                       Positioned(
                                                        child: FadeInImage
                                                            .assetNetwork(
                                                          fit: BoxFit.fill,
                                                          placeholder:
                                                              'assets/newDesignIcon/background_new.png',
                                                          image: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                              ParseJson
                                                                  .getMediumImage(
                                                                      coverImagePath),
                                                        ),
                                                        top: 0.0,
                                                        bottom: 0.0,
                                                        left: 0.0,
                                                        right: 0.0,
                                                      ),
                                                    ],
                                                  ),
                                                  onTap: () async{
                                                    var status = await Permission.photos.status;
                                                    if (status.isGranted) {
                                                      getImageCover();
                                                    }  else {
                                                      checkPermissionPhoto(context);
                                                    }

                                                  },
                                                )),
                                             Positioned(
                                                top: 0.0,
                                                bottom: 20.0,
                                                left: 30.0,
                                                right: 30.0,
                                                child:  InkWell(
                                                  child:  Stack(
                                                    children: <Widget>[
                                                       Container(
                                                        width: double.infinity,
                                                        height: double.infinity,
                                                        child:  Image.asset(
                                                          "assets/newDesignIcon/navigation/layer_cover.png",
                                                          fit: BoxFit.fill,
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  onTap: () {
                                                    //  getImageCover();
                                                  },
                                                )),
                                             Positioned(
                                                top: 120.0,
                                                bottom: 0.0,
                                                left: 13.0,
                                                right: 0.0,
                                                child:  Column(
                                                  children: <Widget>[
                                                    PaddingWrap.paddingfromLTRB(
                                                        30.0,
                                                        30.0,
                                                        0.0,
                                                        0.0,
                                                         Container(
                                                            child:  Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                             Expanded(
                                                              child: PaddingWrap
                                                                  .paddingAll(
                                                                      10.0,
                                                                       InkWell(
                                                                        child:
                                                                             Container(
                                                                          width:
                                                                              111.0,
                                                                          height:
                                                                              111.0,
                                                                          child:
                                                                               Stack(
                                                                            children: <Widget>[
                                                                               Center(
                                                                                  child:  Container(
                                                                                child:  ClipOval(
                                                                                    child: FadeInImage.assetNetwork(
                                                                                  fit: BoxFit.cover,
                                                                                  placeholder: 'assets/profile/user_on_user.png',
                                                                                  image: Constant.IMAGE_PATH_SMALL + ParseJson.getMediumImage(profileImagePath),
                                                                                )),
                                                                                width: 111.0,
                                                                                height: 111.0,
                                                                                padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                              )),
                                                                               Align(
                                                                                  alignment: Alignment.bottomRight,
                                                                                  child:  Container(
                                                                                    padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                                                                                    child:  Image.asset("assets/newDesignIcon/edit_img.png"),
                                                                                    height: 40.0,
                    width: 40.0,
                                                                                  ))
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        onTap:
                                                                            () async{
                                                                              var status = await Permission.photos.status;
                                                                              if (status.isGranted) {
                                                                                getImage();
                                                                              }  else {
                                                                                checkPermissionPhoto(context);
                                                                              }

                                                                        },
                                                                      )),
                                                              flex: 0,
                                                            ),
                                                          ],
                                                        ))),
                                                  ],
                                                )),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(30.0,0,20,20),
                                      child: imageList.length>0?          Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  Stack(
                                              children: <Widget>[
                                                 InkWell(
                                                  child:  Container(
                                                      padding: const EdgeInsets
                                                          .fromLTRB(
                                                          0, 8.0, 12, 8),
                                                      height: 65,
                                                      width: 65,
                                                      child:  Container(
                                                          decoration:  BoxDecoration(
                                                              color: Colors
                                                                  .white,
                                                              border:  Border
                                                                  .all(
                                                                  color:  ColorValues.BORDER_COLOR,
                                                                  width: 0.5)),
                                                          child:  Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                            children: <Widget>[
                                                               Container(
                                                                padding:
                                                                const EdgeInsets
                                                                    .fromLTRB(
                                                                    4,
                                                                    0.0,
                                                                    4,
                                                                    0),
                                                                child:  Text(
                                                                  "Upload Photo",
                                                                  textAlign:
                                                                  TextAlign
                                                                      .center,
                                                                  style:  TextStyle(
                                                                      color:  ColorValues.BLUE_COLOR,

                                                                      fontSize:
                                                                      10.0),
                                                                ),
                                                              ),
                                                            ],
                                                          ))),
                                                  onTap: () async{
                                                    var status = await Permission.photos.status;
                                                    if (status.isGranted) {
                                                      getImageCover();
                                                    }  else {
                                                      checkPermissionPhoto(context);
                                                    }
                                                  },
                                                )
                                              ],
                                            ),
                                            flex: 1,
                                          ),

                                           Expanded(
                                            child:  Stack(
                                              children: <Widget>[
                                                 InkWell(
                                                  child:  Container(
                                                      height: 65,
                                                      width: 65,
                                                      padding:
                                                       EdgeInsets.fromLTRB(
                                                          0, 8, 10, 8),
                                                      child: FadeInImage
                                                          .assetNetwork(
                                                        fit: BoxFit.fill,
                                                        width: 65,
                                                        alignment:
                                                        Alignment.center,
                                                        placeholder:
                                                        'assets/aerial/feed_default_img.png',
                                                        image:
                                                        Constant.IMAGE_PATH +
                                                            imageList[0],
                                                      )),
                                                  onTap: () {
                                                    setState(() {
                                                      isSelectedPredefindImage=true;
                                                      selectedIndexCover = 0;
                                                      coverImagePath =
                                                      imageList[0];
                                                    });
                                                  },
                                                ),
                                                isSelectedPredefindImage&&  selectedIndexCover == 0
                                                    ?  Align(
                                                  alignment: Alignment.center,
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .fromLTRB(
                                                        0, 20.0, 12, 0),
                                                    child:  Container(
                                                        child:
                                                         Image.asset(
                                                          "assets/profile/student/select_circle.png",
                                                          height: 25.0,
                                                          width: 25.0,
                                                        )),
                                                  ),
                                                )
                                                    :  Container(
                                                  height: 0.0,
                                                )
                                              ],
                                            ),
                                            flex: 1,
                                          ),

                                           Expanded(
                                            child:  Stack(
                                              children: <Widget>[
                                                 InkWell(
                                                  child:  Container(
                                                      height: 65,
                                                      width: 65,
                                                      padding:
                                                       EdgeInsets.fromLTRB(
                                                          0.0, 8, 10, 8),
                                                      child: FadeInImage
                                                          .assetNetwork(
                                                        fit: BoxFit.fill,
                                                        width: 65,
                                                        alignment:
                                                        Alignment.center,
                                                        placeholder:
                                                        'assets/aerial/feed_default_img.png',
                                                        image:
                                                        Constant.IMAGE_PATH +
                                                            imageList[1],
                                                      )),
                                                  onTap: () {
                                                    setState(() {
                                                      isSelectedPredefindImage=true;
                                                      selectedIndexCover = 1;
                                                      coverImagePath =
                                                      imageList[1];
                                                    });
                                                  },
                                                ),
                                                isSelectedPredefindImage&&   selectedIndexCover == 1
                                                    ?  Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .fromLTRB(
                                                        0, 20.0, 12, 0),
                                                    child:  Container(
                                                        child:
                                                         Image.asset(
                                                          "assets/profile/student/select_circle.png",
                                                          height: 25.0,
                                                          width: 25.0,
                                                        )),
                                                  ),
                                                )
                                                    :  Container(
                                                  height: 0.0,
                                                )
                                              ],
                                            ),
                                            flex: 1,
                                          ),

                                           Expanded(
                                            child:  Stack(
                                              children: <Widget>[
                                                 InkWell(
                                                  child:  Container(
                                                      height: 65,
                                                      width: 65,
                                                      padding:
                                                       EdgeInsets.fromLTRB(
                                                          0.0, 8, 10, 8),
                                                      child: FadeInImage
                                                          .assetNetwork(
                                                        fit: BoxFit.fill,
                                                        width: 65,
                                                        alignment:
                                                        Alignment.center,
                                                        placeholder:
                                                        'assets/aerial/feed_default_img.png',
                                                        image:
                                                        Constant.IMAGE_PATH +
                                                            imageList[2],
                                                      )),
                                                  onTap: () {
                                                    setState(() {
                                                      isSelectedPredefindImage=true;
                                                      selectedIndexCover = 2;
                                                      coverImagePath =
                                                      imageList[2];
                                                    });
                                                  },
                                                ),
                                                isSelectedPredefindImage&&   selectedIndexCover == 2
                                                    ?  Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .fromLTRB(
                                                        0, 20.0, 12, 0),
                                                    child:  Container(
                                                        child:
                                                         Image.asset(
                                                          "assets/profile/student/select_circle.png",
                                                          height: 25.0,
                                                          width: 25.0,
                                                        )),
                                                  ),
                                                )
                                                    :  Container(
                                                  height: 0.0,
                                                )
                                              ],
                                            ),
                                            flex: 1,
                                          ),

                                           Expanded(
                                            child:  Stack(
                                              children: <Widget>[
                                                 InkWell(
                                                  child:  Container(  height: 65,width: 65,

                                                      padding:
                                                       EdgeInsets.fromLTRB(
                                                          0.0, 8, 10, 8),
                                                      child: FadeInImage
                                                          .assetNetwork(
                                                        fit: BoxFit.fill,
                                                        width: 65,
                                                        alignment:
                                                        Alignment.center,
                                                        placeholder:
                                                        'assets/aerial/feed_default_img.png',
                                                        image:
                                                        Constant.IMAGE_PATH +
                                                            imageList[3],
                                                      )),
                                                  onTap: () {
                                                    setState(() {
                                                      isSelectedPredefindImage=true;
                                                      selectedIndexCover = 3;
                                                      coverImagePath =
                                                      imageList[3];
                                                    });
                                                  },
                                                ),
                                                isSelectedPredefindImage&&        selectedIndexCover == 3
                                                    ?  Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .fromLTRB(
                                                        0, 20.0, 12, 0),
                                                    child:  Container(
                                                        child:
                                                         Image.asset(
                                                          "assets/profile/student/select_circle.png",
                                                          height: 25.0,
                                                          width: 25.0,
                                                        )),
                                                  ),
                                                )
                                                    :  Container(
                                                  height: 0.0,
                                                )
                                              ],
                                            ),
                                            flex: 1,
                                          )

                                        ],
                                      ):new Container(height: 0.0,),
                                    ),
                                   /* Container(
                                      height: 90,
                                      child:  PageView.builder(
                                        itemCount: imageList.length,
                                        controller: controller,
                                        itemBuilder: (context, index) {
                                          return imageList[index] != "add"
                                              ?  Stack(
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Container(
                                                          padding:
                                                               EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0,
                                                                  0,
                                                                  10,
                                                                  0),
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                            fit: BoxFit.fill,
                                                            width: 80,
                                                            alignment: Alignment
                                                                .center,
                                                            placeholder:
                                                                'assets/profile/user_on_user.png',
                                                            image: Constant
                                                                    .IMAGE_PATH +
                                                                imageList[
                                                                    index],
                                                          )),
                                                      onTap: () {
                                                        setState(() {
                                                          selectedIndexCover =
                                                              index;
                                                          coverImagePath =
                                                              imageList[index];
                                                        });
                                                      },
                                                    ),
                                                    selectedIndexCover == index
                                                        ?  Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      0,
                                                                      0.0,
                                                                      12,
                                                                      0),
                                                              child:
                                                                   Container(
                                                                      child:  Image
                                                                          .asset(
                                                                "assets/profile/student/select_circle.png",
                                                                height: 25.0,
                                                                width: 25.0,
                                                              )),
                                                            ),
                                                          )
                                                        :  Container(
                                                            height: 0.0,
                                                          )
                                                  ],
                                                )
                                              :  InkWell(
                                                  child:  Container(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          0, 0.0, 12, 0),
                                                      height: 100,
                                                      child:  Container(
                                                          decoration:  BoxDecoration(
                                                              color: Colors
                                                                  .white,
                                                              border:  Border
                                                                      .all(
                                                                  color:  ColorValues.BORDER_COLOR,
                                                                  width: 0.5)),
                                                          child:  Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: <Widget>[
                                                               Container(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        10,
                                                                        0.0,
                                                                        10,
                                                                        0),
                                                                child:  Text(
                                                                  "Upload Photo",
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style:  TextStyle(
                                                                      color:  ColorValues.BLUE_COLOR,
                                                                      wordSpacing:
                                                                          2.5,
                                                                      fontSize:
                                                                          12.0),
                                                                ),
                                                              ),
                                                            ],
                                                          ))),
                                                  onTap: () {
                                                    getImageCover();
                                                  },
                                                );
                                        },
                                        onPageChanged: (index) {
                                          setState(() {});
                                        },
                                      ),
                                    ),*/
                                    tagline,
                                  ],
                                ),
                              ],
                            ))),
                    flex: 1,
                  ),
                   Expanded(
                    child: getBottomBar(),
                    flex: 0,
                  )
                ],
              ),
            )));

    /* return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                body:  Container(
                  color: ColorValues.LIGHT_GRAY_BG,
                  child:  Stack(children: <Widget>[
                     Positioned(
                        bottom: 0.0,
                        right: 0.0,
                        left: 0.0,
                        top: 0.0,
                        child:  SingleChildScrollView(
                            child: Column(children: <Widget>[
                               Expanded(
                                child:  Padding(
                                    padding:
                                    EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
                                    child: getUpperDots()),
                                flex: 0,
                              ),
                               Expanded(
                                child:  Padding(
                                    padding:
                                    EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                                    child:  Text(
                                      "Add Profile Picture",
                                      style: TextStyle(
                                          fontFamily: Constant.customRegular,
                                          fontSize: 28.0,
                                          fontWeight: FontWeight.normal,
                                          color: ColorValues.HEADING_COLOR_EDUCATION),
                                    )),
                                flex: 0,
                              ),
                     Expanded(
                      child:  Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                        child:  Container(
                            child:  Stack(
                              children: <Widget>[
                                imagePath == null
                                    ?  Container(
                                  height: 170.0,
                                  width: 170.0,
                                  child:  Stack(
                                    children: <Widget>[
                                       Center(
                                          child:  Container(
                                            child:  ClipOval(
                                                child: FadeInImage
                                                    .assetNetwork(
                                                  fit: BoxFit.cover,
                                                  placeholder:
                                                  'assets/newDesignIcon/parentProfile/avtar_add_student.png',
                                                  image: Constant
                                                      .IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          studModel
                                                              .profilePicture),
                                                )),
                                            height: 170.0,
                                            width: 170.0,
                                            padding:
                                             EdgeInsets.fromLTRB(
                                                0.0, 0.0, 0.0, 0.0),
                                          )),
                                    ],
                                  ),
                                )
                                    : isImageSelectedView(),
                                 Positioned(
                                  child:  InkWell(
                                    child: Image.asset(
                                      'assets/newDesignIcon/edit_img.png',
                                      height: 30.0,
                                      width: 30.0,
                                    ),
                                    onTap: () {
                                      getImage(ImageSource.gallery);
                                    },
                                  ),
                                  top: 135.0,
                                  left: 120.0,
                                )
                              ],
                            )),
                      ),
                      flex: 0,
                    ),
                            ]))),
                     Positioned(
                        bottom: 0.0, right: 0.0, left: 0.0, child: getBottomBar())
                  ]),
                ))));*/

    /*   return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child: MaterialApp(
              home: Scaffold(
                  body:  Container(
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                           Expanded(
                            child:  Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
                                child: getUpperDots()),
                            flex: 0,
                          ),
                           Expanded(
                            child:  Padding(
                                padding:
                                    EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                                child:  Text(
                                  "Add Profile Picture",
                                  style: TextStyle(
                                      fontFamily: Constant.customRegular,
                                      fontSize: 28.0,
                                      fontWeight: FontWeight.normal,
                                      color: ColorValues.HEADING_COLOR_EDUCATION),
                                )),
                            flex: 0,
                          ),
                           Expanded(
                            child:  Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                              child:  Container(
                                  child:  Stack(
                                children: <Widget>[
                                  imagePath == null
                                      ?  Container(s
                                          height: 150.0,
                                          width: 150.0,
                                          child:  Stack(
                                            children: <Widget>[
                                               Center(
                                                  child:  Container(
                                                child:  ClipOval(
                                                    child: FadeInImage
                                                        .assetNetwork(
                                                  fit: BoxFit.cover,
                                                  placeholder:
                                                      'assets/newDesignIcon/parentProfile/avtar_add_student.png',
                                                  image: Constant
                                                          .IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          studModel
                                                              .profilePicture),
                                                )),
                                                height: 150.0,
                                                width: 150.0,
                                                padding:
                                                     EdgeInsets.fromLTRB(
                                                        0.0, 0.0, 0.0, 0.0),
                                              )),
                                            ],
                                          ),
                                        )
                                      : isImageSelectedView(),
                                   Positioned(
                                    child:  InkWell(
                                      child: Image.asset(
                                        'assets/newDesignIcon/edit_img.png',
                                        height: 30.0,
                                        width: 30.0,
                                      ),
                                      onTap: () {
                                        getImage(ImageSource.gallery);
                                      },
                                    ),
                                    top: 110.0,
                                    left: 110.0,
                                  )
                                ],
                              )),
                            ),
                            flex: 0,
                          ),
                           Padding(
                            padding: EdgeInsets.fromLTRB(10.0, 20.0, 10.0, 0.0),
                            child: imagePath != null || strNetworkImage != ""
                                ?  Text(
                                    "",
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontFamily: Constant.customRegular,
                                        color: ColorValues.HEADING_COLOR_EDUCATION),
                                  )
                                :  Container(
                                    width: 0.0,
                                  ),
                          )
                        ],
                      )),
                  bottomNavigationBar: getBottomBar())),
        ));*/
  }

  void skipOnClick() {
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  AddSummary_Widget(studModel)));
  }

  void onNextClick() {
    print('inside onNextClick()');
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>  AddSummary_Widget(studModel)));
  }
}
