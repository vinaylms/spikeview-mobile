import 'dart:developer';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/chat/GlobalSocketConnection.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/CustomFormFieldWithPrefix.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/MobileNumberVerification.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/UserModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/positive_button.dart';
import 'package:intl/intl.dart';

class ParentProfileView extends StatefulWidget {
  final SignUpUsing signUpUsing;
  final bool isRedirectToRecommendation;

  const ParentProfileView({
    @required this.signUpUsing,
    @required this.isRedirectToRecommendation,
  });

  @override
  State<ParentProfileView> createState() => _ParentProfileViewState();
}

class _ParentProfileViewState extends State<ParentProfileView> {
  static const platform = const MethodChannel('samples.flutter.io/battery');
  GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: Constant.kGoogleApiKey);
  final firstnameCtrl = TextEditingController();
  final lastnameCtrl = TextEditingController();
  final dobCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final firstnameNode = FocusNode();
  final lastnameNode = FocusNode();
  final dobNode = FocusNode();
  final addressNode = FocusNode();
  final phoneNode = FocusNode();
  File profileImageFile;
  int selectedGenderIndex = 0;


  String profileImagePath = "";


  String userIdPref = '',
      strPrefixPathOrganization = '',
      sasToken = '',
      containerName = '',
      isMostCloselyIdentified = "";
  SharedPreferences prefs;
  DateTime dobDateTime;
  Map addressData = {};
  CountryCode selectedCountry = CountryCode.US;

  //List<String> _genderList = ["Male", "Female", "Non-binary", "NA"];
  final _formKey = GlobalKey<FormState>();
  ProfileInfoModal profileInfoModal;

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  Future<void> _profileApi(bool isShowLoader) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLoader) CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");
        if (isShowLoader) CustomProgressLoader.cancelLoader(context);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              try {
                profileInfoModal =
                    ParseJson.parseMapUserProfile(response.data['result']);
                if (profileInfoModal != null) {
                  if (mounted) {
                    firstnameCtrl.text = profileInfoModal?.firstName == 'null'
                        ? ''
                        : "${profileInfoModal?.firstName}";
                    lastnameCtrl.text = profileInfoModal?.lastName == 'null'
                        ? ''
                        : "${profileInfoModal?.lastName}";
                    addressCtrl.text =
                        profileInfoModal?.address?.street1 == 'null'
                            ? ''
                            : profileInfoModal?.address?.street1 ?? '';

                    if (profileInfoModal?.gender != null &&
                        profileInfoModal?.gender != "null" &&
                        profileInfoModal?.gender != "") {
                      isMostCloselyIdentified = profileInfoModal.gender;
                    }
                    if (profileInfoModal.countryCode != null &&
                        profileInfoModal.countryCode != "null" &&
                        profileInfoModal.countryCode != "") {
                      final index = CountryCode.ALL.indexWhere((element) =>
                          element.dialingCode == profileInfoModal?.countryCode);
                      if (index > -1) {
                        selectedCountry = CountryCode.ALL[index];
                      }
                    }

                    if (profileInfoModal.mobileNo != null &&
                        profileInfoModal.mobileNo != "null" &&
                        profileInfoModal.mobileNo != "" &&
                        profileInfoModal.mobileNo != "0") {
                      phoneCtrl.text = profileInfoModal.mobileNo;
                    }
                    try {
                      if (profileInfoModal?.dob != "0") {
                        dobDateTime = DateTime.fromMillisecondsSinceEpoch(
                            int.tryParse(profileInfoModal.dob));
                        dobCtrl.text =
                            DateFormat("MMM dd, yyyy").format(dobDateTime);
                      }
                      setState(() {});
                    } catch (e) {
                      setState(() {});
                    }

                    checkAllFieldSubmitter();
                  }
                }
              } catch (e) {
                print("e++++" + e.toString());
                setState(() {});
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditUserProfile", context);
      if (isShowLoader) CustomProgressLoader.cancelLoader(context);
    }
  }

  Future<void> getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    //email = prefs.getString(UserPreference.EMAIL);
    //token = prefs.getString(UserPreference.USER_TOKEN);
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_PROFILE +
        "/";
    _callApiForSaas();
    _profileApi(true);
  }

  Future<void> _callApiForSaas() async {
    try {
      final response = await ApiCalling().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }
  bool allFieldCompleted = false;

  checkAllFieldSubmitter() {
    if (ValidationWidget.isName(firstnameCtrl.text) &&
        ValidationWidget.isName(lastnameCtrl.text) &&
        addressCtrl.text.length > 0 &&
        dobCtrl.text.length > 0 &&
        isMostCloselyIdentified.length > 0) {
      print('++++++true');
      if (phoneCtrl.text.length == 0) {
        allFieldCompleted = true;
        setState(() {});
      } else if (phoneCtrl.text.length > 0 &&
          ValidationChecks.validatePhone(phoneCtrl.text).toString() ==
              'null') {
        allFieldCompleted = true;
        setState(() {});
      } else {
        print('++++++22false');
        allFieldCompleted = false;
        setState(() {});
      }
    } else {
      allFieldCompleted = false;
      setState(() {});
    }


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: FormKeyboardActions(
        keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
        keyboardBarColor: Colors.grey[200],
        actions: [
          KeyboardAction(
            focusNode: phoneNode,
          ),
        ],
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 50, 20, 20),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Expanded(
                          child: BaseText(
                        text: "Profile",
                        textColor: const Color(0xff27275A),
                        fontFamily: Constant.latoRegular,
                        fontWeight: FontWeight.w700,
                        fontSize: 28,
                      )),
                      InkWell(
                        onTap: () {
                          apiCallForLogout();
                        },
                        child: Image.asset(
                          "assets/png/logout.png",
                          height: 32.0,
                          width: 32.0,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const HelpButtonWidget(),
                    ],
                  ),
                  const SizedBox(height: 10),
                  BaseText(
                    text: 'Provide profile details',
                    textColor: const Color(0xff666B9A),
                    fontFamily: Constant.latoRegular,
                    fontWeight: FontWeight.w600,
                    fontSize: 18,
                  ),
                  const SizedBox(height: 25),
                  Center(
                    child: SizedBox(
                      width: 115,
                      height: 115,
                      child: InkWell(
                        child: Stack(
                          children: <Widget>[

                            profileImageFile != null
                                ?  Container(
                                width: 115,
                                height: 115,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(35),
                                    border: Border.all(
                                        color: Colors.white,
                                        width: 2),
                                    boxShadow: [
                                      BoxShadow(
                                        spreadRadius: 3,
                                        blurRadius: 3,
                                        offset: Offset(0, 2),
                                        color: Color.fromRGBO(98, 175, 226, 0.15),
                                      )
                                    ]
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(35.0),
                                  child:Image.file(
                                    profileImageFile,
                                    width: 115,
                                    height: 115,
                                    fit: BoxFit.cover,
                                  ),
                                ))
                            : profileInfoModal
                                ?.profilePicture?.isNotEmpty ??
                                false
                                ?Container(
                                width: 115,
                                height: 115,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(35),
                                    border: Border.all(
                                        color: Colors.white,
                                        width: 2),
                                    boxShadow: [
                                      BoxShadow(
                                        spreadRadius: 3,
                                        blurRadius: 3,
                                        offset: Offset(0, 2),
                                        color: Color.fromRGBO(98, 175, 226, 0.15),
                                      )
                                    ]
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(35.0),
                                  child:CachedNetworkImage(
                                    imageUrl: Constant.IMAGE_PATH_SMALL +
                                        profileInfoModal.profilePicture,
                                    width: 115,
                                    height: 115,
                                    fit: BoxFit.cover,
                                    placeholder: (_, str) {
                                      return Center(
                                        child: SizedBox(
                                          width: 30,
                                          height: 30,
                                          child: CircularProgressIndicator(
                                            valueColor:
                                            AlwaysStoppedAnimation(
                                              Colors.black54,
                                            ),
                                            strokeWidth: 2.0,
                                          ),
                                        ),
                                      );
                                    },
                                    errorWidget: (_, str, e) {
                                      return _errorEmptyProfileView();
                                    },
                                  )
                                )):Container(
                                width: 115,
                                height: 115,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(35),
                                    border: Border.all(
                                        color: Colors.white,
                                        width: 2),
                                    boxShadow: [
                                      BoxShadow(
                                        spreadRadius: 3,
                                        blurRadius: 3,
                                        offset: Offset(0, 2),
                                        color: Color.fromRGBO(98, 175, 226, 0.15),
                                      )
                                    ]
                                ),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(35.0),
                                    child:CachedNetworkImage(
                                      imageUrl: '',
                                      width: 115,
                                      height: 115,
                                      fit: BoxFit.cover,
                                      placeholder: (_, str) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30,
                                            height: 30,
                                            child: CircularProgressIndicator(
                                              valueColor:
                                              AlwaysStoppedAnimation(
                                                Colors.black54,
                                              ),
                                              strokeWidth: 2.0,
                                            ),
                                          ),
                                        );
                                      },
                                      errorWidget: (_, str, e) {
                                        return _errorEmptyProfileView();
                                      },
                                    )
                                )),




                            Positioned(
                              bottom: 12.0,
                              right: 12.0,
                              child: Image.asset(
                                "assets/png/edit.png",
                                height: 24,
                                width: 24,
                              ),
                            )
                          ],
                        ),
                        onTap: () => _chooseImage(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  CustomFormField(
                    maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                    controller: firstnameCtrl,
                    focusNode: firstnameNode,
                    onType: (e){
                      checkAllFieldSubmitter();
                    },
                    label: "First name",
                    alignLabelWithHint: true,
                    validation: (val) => val.trim().length == 0
                        ? MessageConstant.ENTER_FIRST_NAME_VAL
                        : !ValidationWidget.isName(val)
                            ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                            : null,
                  ),
                  const SizedBox(height: 18),
                  CustomFormField(
                    controller: lastnameCtrl,
                    focusNode: lastnameNode,
                    onType: (e){
                      checkAllFieldSubmitter();
                    },
                    maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
                    label: "Last name",
                    alignLabelWithHint: true,
                    validation: (val) => val.trim().length == 0
                        ? MessageConstant.ENTER_LAST_NAME_VAL
                        : !ValidationWidget.isName(val)
                            ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                            : null,
                  ),
                  const SizedBox(height: 18),
                  CustomFormField(
                    readOnly: true,
                    maxLength: TextLength.MOBILE_NUMBER_MAX_LENGTH,
                    controller: dobCtrl,
                    focusNode: dobNode,
                    label: "Date of birth",
                    alignLabelWithHint: true,
                    onClick: () async {
                      DateTime pickedDate = await showDatePicker(
                        context: context,
                        initialDate:
                            dobDateTime == null ? DateTime.now() : dobDateTime,
                        firstDate: DateTime(1900),
                        lastDate: DateTime.now(),
                        confirmText: 'Apply',
                        cancelText: 'Cancel',
                      );
                      if (pickedDate != null) {
                        dobDateTime = pickedDate;
                        dobCtrl.text = Util.getDate(pickedDate);
                        setState(() {});
                      }
                      checkAllFieldSubmitter();
                    },
                    validation: (value) {
                      return value.length == 0
                          ? 'Please select Date of Birth'
                          : Util.currentAge(dobDateTime, 18) < 18
                              ? "Sorry, you need to be over 18 to become a parent"
                              : null;
                    },
                  ),
                  const SizedBox(height: 18),
                  CustomFormField(
                    readOnly: true,
                    controller: addressCtrl,
                    focusNode: addressNode,
                    alignLabelWithHint: true,
                    label: "Address",
                    onClick: () {
                      _handlePressButton();
                    },
                    validation: (value) {
                      return value.length == 0
                          ? 'Please enter valid address'
                          : null;
                    },
                  ),
                  const SizedBox(height: 18),
                  CustomFormFieldWithPrefix(
                    prefixWidget: Padding(
                      padding: const EdgeInsets.only(right: 5.0),
                      child: Container(
                        width: 55,
                        child: CountryCodePicker(
                          dense: false,
                          showFlag: true,
                          isNew: true,
                          showDialingCode: false,
                          showUnderLine: false,
                          showName: false,
                          onChanged: (CountryCode country) {
                            selectedCountry = country;
                            setState(() {});
                          },
                          selectedCountryCode: selectedCountry.dialingCode,
                        ),
                      ),
                    ),
                    focusNode: phoneNode,
                    baseAlign: true,
                    textInputType: TextInputType.number,
                    maxLength: TextLength.MOBILE_NUMBER_MAX_LENGTH,
                    controller: phoneCtrl,
                    label: "Phone number",
                    suffixWidget: Padding(
                      padding: const EdgeInsets.only(top: 10.0),
                      child: BaseText(
                        textAlign: TextAlign.center,
                        text: 'Optional  ',
                        textColor: AppConstants.colorStyle.darkBlue,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontStyle: FontStyle.italic,
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                      ),
                    ),
                    validation: (value) {
                      return value.length > 0
                          ? ValidationChecks.validatePhone(value)
                          : null;
                    },
                  ),
                  const SizedBox(height: 41),
                  _genderView(),
                  const SizedBox(height: 18),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Stack(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(20, 20, 20, 40),
            child: SizedBox(
              height: 44,
              child: PositiveButton(
                isEnable: true,
                title: 'Proceed',
                onTap: () => _checkValidation(),
              ),
            ),
          ),
          allFieldCompleted
              ? SizedBox(
            height: 0,
          )
              : Container(
            height: 76.0,
            width: double.infinity,
            color: Colors.white.withOpacity(0.75),
          )
        ],
      ),
    );
  }



  Widget _genderView() {
    return Row(
      children: <Widget>[
        Flexible(
          child: InkWell(
            onTap: () {
              isMostCloselyIdentified = "Male";
              FocusScope.of(context).requestFocus(new FocusNode());
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Male"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Male"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10.0),
                    bottomLeft: Radius.circular(10.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Male',
                  textColor: isMostCloselyIdentified == "Male"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Female";
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Female"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Female"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'Female',
                  textColor: isMostCloselyIdentified == "Female"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "Non-Binary";
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              width: 96,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "Non-Binary"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "Non-Binary"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(0.0),
                    bottomLeft: Radius.circular(0.0)),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: ' Non-binary ',
                  textColor: isMostCloselyIdentified == "Non-Binary"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 2,
        ),
        Flexible(
          child: InkWell(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
              isMostCloselyIdentified = "NA";
              setState(() {});
              checkAllFieldSubmitter();
            },
            child: Container(
              height: 35,
              decoration: BoxDecoration(
                color: isMostCloselyIdentified == "NA"
                    ? AppConstants.colorStyle.orangeShade
                    : AppConstants.colorStyle.fillShade,
                border: Border.all(
                    color: isMostCloselyIdentified == "NA"
                        ? AppConstants.colorStyle.orangeShade
                        : AppConstants.colorStyle.btnBg,
                    width: 1),
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(10.0),
                  topRight: Radius.circular(10.0),
                ),
              ),
              child: Center(
                child: BaseText(
                  textAlign: TextAlign.center,
                  text: 'NA',
                  textColor: isMostCloselyIdentified == "NA"
                      ? Colors.white
                      : AppConstants.colorStyle.darkBlue,
                  fontFamily: AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          flex: 1,
        ),
      ],
    );
  }

  Widget _errorEmptyProfileView() {
    return Container(
      height: 115,
      width: 115,
      color: const Color(0xff666B9A),
      alignment: Alignment.center,
      child: Image.asset(
        'assets/default_avatar.png',
        height: 64,
        width: 64,
      ),
    );
  }

  Future<void> apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {
          "deviceId": prefs.getString("deviceId"),
        };

        final response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      crashlytics_bloc.recordCrashlyticsError(e, "PartnerDashboard", context);
    }
  }

  Future<void> onTapSignOut() async {
    Constant.isAlreadyLoggedIn = false;
    Map map = {
      "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
      "deviceId": prefs.getString("deviceId")
    };
    GlobalSocketConnection.socket
        .emitWithAck("disconnect1", [map]).then((data) {
      print("chat-login++++" + data.toString());
    });
    GlobalSocketConnection.socket.emit("disconnect2", []);
    prefs.setString(UserPreference.NAME, "");
    prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
    prefs.setBool(UserPreference.LOGIN_STATUS, false);
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
    prefs.setBool(UserPreference.IS_USER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
    prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
    prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
    bloc.resetData(prefs);
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage(null)),
    );
  }

  Future<void> _chooseImage() async {
    var status = await Permission.photos.status;
    if (status.isGranted) {
      _getImage();
    } else {
      checkPermissionPhoto(context);
    }
  }

  Future<void> _getImage() async {
    final imagePath = await UploadMedia(context).pickImageFromGallery();
    if (imagePath != null) {
      String strPath = imagePath.toString().substring(
          imagePath.toString().lastIndexOf("/") + 1,
          imagePath.toString().length);
      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        if (imagePath != null) {
          profileImageFile = imagePath;
          setState(() {});
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  Future<void> checkPermissionPhoto(BuildContext context) async {
    showDialog(
      context: context,
      builder: (BuildContext context) => CupertinoAlertDialog(
        title: Text('Please allow access'),
        content: RichText(
          maxLines: 2,
          textAlign: TextAlign.center,
          text: TextSpan(
            text: '',
            style: TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            children: <TextSpan>[
              TextSpan(
                text: 'This app needs access to photos and camera roll',
                style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  fontSize: 15.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          CupertinoDialogAction(
            child: Text('Deny'),
            onPressed: () => Navigator.of(context).pop(),
          ),
          CupertinoDialogAction(
              child: Text('Settings'),
              onPressed: () {
                Navigator.of(context).pop();
                openAppSettings();
              }),
        ],
      ),
    );
  }

  Future<void> _handlePressButton() async {
    Prediction p = await PlacesAutocomplete.show(
      context: context,
      apiKey: Constant.kGoogleApiKey,
      onError: onError,
      hint: "Search here..",
      logo: Image.asset("assets/logo"),
      mode: Mode.fullscreen,
      components: [
        Component(Component.country, "ind"),
        Component(Component.country, "uk"),
        Component(Component.country, "usa"),
      ],
    );
    displayPrediction(p);
  }

  void onError(PlacesAutocompleteResponse response) {
    ToastWrap.showToast(response.errorMessage, context);
  }

  Future<Null> displayPrediction(Prediction p) async {
    if (p != null) {
      PlacesDetailsResponse detail =
          await _places.getDetailsByPlaceId(p.placeId);
      final lat = detail.result.geometry.location.lat;
      final lng = detail.result.geometry.location.lng;
      try {
        final coordinates = Coordinates(lat, lng);
        var addresses =
            await Geocoder.local.findAddressesFromCoordinates(coordinates);
        var first = addresses.first;
        setState(() {
          addressCtrl.text =
              first.addressLine != null && p.description != "null"
                  ? p.description
                  : "";
          addressData = {
            "street1": addressCtrl.text.trim(),
            "street2": first.subLocality != null && first.subLocality != "null"
                ? first.subLocality
                : "",
            "city": first.subAdminArea != null && first.subAdminArea != "null"
                ? first.subAdminArea
                : "",
            "state": first.adminArea != null && first.adminArea != "null"
                ? first.adminArea
                : "",
            "country": first.countryName != null && first.countryName != "null"
                ? first.countryName
                : "",
            "zip": first.postalCode != null && first.postalCode != "null"
                ? first.postalCode
                : ""
          };
        });
        checkAllFieldSubmitter();
      } catch (e) {
        setState(() {
          addressCtrl.text = p.description;
        });
      }
    }
  }

  void _checkValidation() {
    if (_formKey?.currentState?.validate() ?? false) {
      _callApi();
    }
  }

  Future<void> _callApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        if (profileImageFile != null) {
          await uploadImgOnAzure(profileImageFile
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim());
        }

        Map request = {
          "userId": int.parse(userIdPref),
          "roleId": 2,
          "profilePicture": profileImageFile == null ? '' : profileImagePath,
          "firstName": firstnameCtrl.text.trim(),
          "lastName": lastnameCtrl.text.trim(),
          "gender": isMostCloselyIdentified == "Non-Binary"
              ? "NonBinary"
              : isMostCloselyIdentified,
          "genderAtBirth": isMostCloselyIdentified == "Non-Binary"
              ? "NonBinary"
              : isMostCloselyIdentified,
          "dob": dobDateTime.millisecondsSinceEpoch,
          "city": addressData['city'] ?? "",
          "state": addressData['state'] ?? "",
          "country": addressData['country'] ?? "",
          "zipCode": addressData['zip'] ?? "",
          //  "address": add1Controller.text,
          "address": addressData,

          "countryCode":"+${selectedCountry.dialingCode}",
          "mobileNo": phoneCtrl.text.trim(),
          "isUnderAge": false
        };

        log("request-" + request.toString());
        final response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_PROFILE, request);
        CustomProgressLoader.cancelLoader(context);
        log("response-" + response.toString());
        if (response != null && response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setBool(UserPreference.IS_ADDED_DOB, true);
            prefs.setString(UserPreference.NAME,
                firstnameCtrl.text.trim() + " " + lastnameCtrl.text.trim());
            //onParentSuccess(response);
            apiCallingUpdate();
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditUserProfile", context);
    }
  }

  void onParentSuccess(Response response) {
    prefs.setString(UserPreference.chat_skip_count, "0");
    prefs.setBool(UserPreference.iSACCOMPLISHMENTADD, false);
    prefs.setBool(UserPreference.isEducationAdded, false);
    Constant.isAlreadyLoggedIn = true;
    prefs.setString(UserPreference.IS_USER_ROLE, "false");
    prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
    prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
    var companyMap = response.data['result']['company'];
    Company company = Company('', '', false);
    if (companyMap != null) {
      company = Company(companyMap['name'].toString(),
          companyMap['partnerStatus'].toString(), companyMap['isActive']);
      prefs.setBool(UserPreference.IS_SHOW_REJECTION_POPUP,
          company?.partnerStatus?.toString() == 'Decline');
    }
    String dob = response.data['result']['dob'].toString();
    if (dob == null || dob == "null" || dob == "") {
      dob = "0";
    }
    String isPasswordChanged1 =
        response.data['result']['isPasswordChanged'].toString();
    if (widget.signUpUsing == SignUpUsing.apple ||
        widget.signUpUsing == SignUpUsing.google) {
      isPasswordChanged1 = "true";
    }
    String gender = response.data['result']['gender'].toString();
    if (gender == "Non-binary" || gender == "NonBinary") {
      gender = "Non-Binary";
    }
    String creationTime = "0";
    creationTime = response.data['result']['creationTime'].toString();
    if (creationTime == "null") {
      creationTime = "0";
    }
    bool userLoginFirstTime = response.data['result']['userLoginFirstTime'];
    if (userLoginFirstTime == null) {
      userLoginFirstTime = false;
    }
    String publicUrl = response.data['result']['publicUrl'].toString().trim();
    if (publicUrl == "null") {
      publicUrl = "";
    }
    String referCode = response.data['result']['referCode'].toString();
    String schoolCode = response.data['result']['schoolCode'].toString();
    if (schoolCode == "null" || schoolCode == "") {
      schoolCode = "";
    }
    bool isPreLoginSetting = response.data["result"]["isLeaderboardDisplay"];
    if (isPreLoginSetting == null) {
      isPreLoginSetting = false;
    }
    String companyName = response.data['result']['companyName'].toString();
    String companyProfilePicture =
        response.data['result']['companyProfilePicture'].toString();
    bool profileCreatedByParent =
        response.data['result']['profileCreatedByParent'];
    if (profileCreatedByParent == null) {
      profileCreatedByParent = false;
    }
    String badgeImage = response.data['result']['badgeImage'].toString();
    if (badgeImage == null || badgeImage == "null" || badgeImage == "") {
      badgeImage = "";
    }
    String badge = response.data['result']['badge'].toString();
    if (badge == null || badge == "null" || badge == "") {
      badge = "";
    }
    String gamification =
        response.data['result']['gamificationPoints'].toString();
    int gamificationPoints;
    if (gamification == null || gamification == "" || gamification == "null") {
      gamificationPoints = 0;
    } else {
      gamificationPoints = int.parse(gamification);
    }
    List<SocialLinkData> socialLinkList = List();
    var socalLinkMap = response.data['result']['socialLinks'];
    if (socalLinkMap != null && socalLinkMap.length > 0) {
      for (int i = 0; i < socalLinkMap.length; i++) {
        String image = socalLinkMap[i]['image'].toString();
        String socialName = socalLinkMap[i]['socialName'].toString();
        String socialUrl = socalLinkMap[i]['socialUrl'].toString();
        int socialId = socalLinkMap[i]['socialId'];
        socialLinkList.add(new SocialLinkData(
            image: image,
            socialName: socialName,
            socialUrl: socialUrl,
            socialId: socialId));
      }
    }
    ProfileInfoModal profileInfoModal = ProfileInfoModal(
        response.data['result']['userId'].toString(),
        response.data['result']['firstName'].toString(),
        response.data['result']['lastName'].toString(),
        response.data['result']['email'].toString(),
        response.data['result']['mobileNo'].toString(),
        response.data['result']['profilePicture'].toString(),
        response.data['result']['roleId'].toString(),
        response.data['result']['isActive'].toString(),
        response.data['result']['requireParentApproval'].toString(),
        response.data['result']['ccToParents'].toString(),
        response.data['result']['lastAccess'].toString(),
        isPasswordChanged1,
        response.data['result']['organizationId'].toString(),
        gender,
        dob,
        response.data['result']['genderAtBirth'].toString(),
        response.data['result']['usCitizenOrPR'].toString(),
        null,
        response.data['result']['summary'].toString(),
        response.data['result']['coverImage'].toString(),
        response.data['result']['tagline'].toString(),
        response.data['result']['title'].toString(),
        response.data['result']['tempPassword'].toString(),
        response.data['result']['isArchived'].toString(),
        null,
        false,
        response.data['result']['groupId'].toString(),
        response.data['result']['groupName'].toString(),
        response.data['result']['groupImage'].toString(),
        "",
        "",
        response.data['result']['zipCode'].toString(),
        response.data['result']['isHide'].toString(),
        response.data['result']['referralPopup'],
        userLoginFirstTime,
        response.data['result']['stage'].toString(),
        creationTime,
        badge,
        gamificationPoints,
        badgeImage,
        referCode,
        socialLinkList,
        publicUrl,
        response.data['result']['isPublicUrlActive'] ?? false,
        response.data['result']['isPublicProfileGlobalyActive'] ?? false,
        null,
        company,
        false,
        false,
        null,
        schoolCode,
        '',
        "",
        false,false);
    bloc.fetchSetting('', context, prefs);
    if (widget.signUpUsing == SignUpUsing.apple ||
        widget.signUpUsing == SignUpUsing.google ||
        widget.signUpUsing == SignUpUsing.email) {
      String salt = response.data['result']['salt'].toString();
      prefs.setBool(UserPreference.SHOW_BOT_DEFAULT_COUNT, userLoginFirstTime);
      prefs.setBool(
          UserPreference.IS_USER_LOGIN_FIRST_TIME, userLoginFirstTime);
      prefs.setString(UserPreference.DOB, dob);
      bool isPasswordChanged = response.data['result']['isPasswordChanged'];
      if (widget.signUpUsing == SignUpUsing.apple ||
          widget.signUpUsing == SignUpUsing.google) {
        isPasswordChanged = true;
      }
      userList.add(UserData(
        profileInfoModal.userId,
        profileInfoModal.firstName,
        profileInfoModal.lastName,
        profileInfoModal.email,
        salt,
        profileInfoModal.mobileNo,
        profileInfoModal.profilePicture,
        profileInfoModal.roleId,
      ));
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
      prefs.setString(UserPreference.ISACTIVE, profileInfoModal.isActive);
      prefs.setString(UserPreference.chat_skip_count, "0");
      prefs.setBool(UserPreference.LOGIN_STATUS, true);
      prefs.setString(UserPreference.ROLE_ID, profileInfoModal.roleId);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, isPasswordChanged);
      prefs.setBool(
          UserPreference.IS_PROFILECRETED_BY_PARENT, profileCreatedByParent);
      prefs.setString(UserPreference.USER_ID, profileInfoModal.userId);
      prefs.setBool(UserPreference.IS_PARENT,
          profileInfoModal.roleId == "2" ? true : false);
      prefs.setString(UserPreference.PARENT_ID, profileInfoModal.userId);
      prefs.setString(UserPreference.EMAIL, profileInfoModal.email);
      prefs.setString(UserPreference.MOBILE, profileInfoModal.mobileNo);
      prefs.setString(UserPreference.PASSWORD, "");
      prefs.setString(
          UserPreference.PROFILE_IMAGE_PATH, profileInfoModal.profilePicture);
      prefs.setString(UserPreference.COMPANY_IMAGE_PATH, companyProfilePicture);
      prefs.setString(UserPreference.COMPANY_NAME_PATH, companyName);
      prefs.setString(UserPreference.USER_TOKEN,
          "Spike " + response.data['result']['token'].toString());
      prefs.setBool(UserPreference.IS_PRE_LOGIN, isPreLoginSetting);
      prefs.setString(UserPreference.referCode, referCode);
      prefs.setString(UserPreference.badgeType, badge);
      prefs.setInt(UserPreference.gamificationPoints, gamificationPoints);
      prefs.setString(UserPreference.badgeImage, badgeImage);
      prefs.setString(
          UserPreference.CREATION_TIME, profileInfoModal.creationTime);
      prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
      prefs.setString(UserPreference.ZIPCODE, profileInfoModal.zipCode);
      prefs.setString(UserPreference.NAME,
          profileInfoModal.firstName + " " + profileInfoModal.lastName);
      prefs.setString(
          UserPreference.PROFILE_IMAGE_PATH, profileInfoModal.profilePicture);
      prefs.setString(UserPreference.TAGLINE, profileInfoModal.tagline);
      prefs.setString(UserPreference.ISACTIVE, profileInfoModal.isActive);
    } else if (widget.isRedirectToRecommendation) {
      prefs.setBool(UserPreference.LOGIN_STATUS, true);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
      prefs.setBool(UserPreference.IS_USER_LOGIN_FIRST_TIME, true);
      prefs.setBool(UserPreference.IS_PARENT, true);
      prefs.setString(UserPreference.IS_PARTNER_ROLE, "false");
      prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
      prefs.setString(UserPreference.IS_USER_ROLE, "false");
      prefs.setString(UserPreference.ROLE_ID, "2");
      prefs.setBool(UserPreference.IS_ADDED_DOB, false);
      prefs.setBool(UserPreference.IS_UNDER_AGE, true);
      Constant.ROLE_ID = "2";
      prefs.setString(UserPreference.NAME,
          firstnameCtrl.text.trim() + " " + lastnameCtrl.text.trim());
    } else {
      prefs.setString(UserPreference.PATHURL, "");
    }
    apiCallingUpdate();
  }

  Future<void> apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map = {"userId": userIdPref, "stage": "2"};
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_STAGE, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String preMobile =
                  "${profileInfoModal?.countryCode?.toString() != 'null' ? "${profileInfoModal?.countryCode}" : ''}${profileInfoModal?.mobileNo?.toString() != 'null' ? '${profileInfoModal?.mobileNo}' : ''}"
                      .trim();
              String newMobile =
                  "${selectedCountry.dialingCode}${phoneCtrl.text.trim()}";

              if (phoneCtrl.text.length > 0 &&
                  (profileInfoModal.mobileNo != 'null' &&
                      profileInfoModal.mobileNo != '')) {
                if (phoneCtrl.text
                    .trim()
                    .isNotEmpty && newMobile != preMobile) {
                  Navigator.of(context).push(
                    new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          MobileNumberVerification(
                            LoginRole.parent,
                            profileInfoModal,
                            sasToken,
                            phoneCtrl.text.trim(),
                            selectedCountry.dialingCode,
                          ),
                    ),
                  );
                } else if (preMobile.isNotEmpty &&
                    !(profileInfoModal?.isPhoneVerified ?? false)) {
                  Navigator.of(context).push(
                    new MaterialPageRoute(
                      builder: (BuildContext context) =>
                          MobileNumberVerification(
                            LoginRole.parent,
                            profileInfoModal,
                            sasToken,
                            phoneCtrl.text.trim(),
                            selectedCountry.dialingCode,
                          ),
                    ),
                  );
                } else {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          DashBoardWidgetParent(
                            prefs.getString(UserPreference.IS_PARENT_ROLE),
                            prefs.getString(UserPreference.IS_PARTNER_ROLE),
                            prefs.getString(UserPreference.IS_USER_ROLE),
                          ),
                    ),
                  );
                }
              }else{
                Navigator.of(context).popUntil((route) => route.isFirst);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        DashBoardWidgetParent(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                        ),
                  ),
                );
              }

            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }


  Future<String> uploadImgOnAzure(imagePath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          profileImagePath = "";
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + strPrefixPathOrganization
          });

          print("image_path" + result);
          profileImagePath = strPrefixPathOrganization + result;
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      CustomProgressLoader.cancelLoader(context);
      return "";
    }
  }

}
