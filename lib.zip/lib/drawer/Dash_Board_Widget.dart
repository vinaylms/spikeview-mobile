import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_friend_list_with_header.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:package_info/package_info.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_friend_list.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';

import 'package:spike_view_project/CoachMark/new_coach_mark_slider.dart';

import 'package:spike_view_project/chat/GlobalSocketConnection.dart';

import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';

import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/drawer/Acount_Setting.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/drawer/OpportunitySearch.dart';
import 'package:spike_view_project/drawer/drawer_menu.dart';
import 'package:spike_view_project/group/New/GroupBaseWidgetNew.dart';
import 'package:spike_view_project/group/group_list_share_flow.dart';
import 'package:spike_view_project/home/AddPost.dart';

import 'package:spike_view_project/home_page/ui/new_home_widget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/newfeature/NewFeautreBasePageWidget.dart';
import 'package:spike_view_project/patnerFlow/InviteNonSpikeViewMember.dart';

import 'package:spike_view_project/profile/studentWizard/CompetenciesStudent.dart';
import 'package:spike_view_project/profile/studentWizard/CompletedStudentWizard.dart';

import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

import 'package:spike_view_project/profile/AddGoalForExistingUser.dart';
import 'package:spike_view_project/profile_bloc_pattern/student_profile_screen_widget.dart';
import 'package:spike_view_project/story/PartnerStory.dart';
import 'package:spike_view_project/story/parent_storey.dart';
import 'package:spike_view_project/profile/EditProfileImageWidget.dart';

import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/ConnectionNotificationModel.dart';
import 'package:spike_view_project/notification/NotificationWidget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/Connection/Connections.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/profile/UserProfileDashBoard.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/role_widget.dart';

class DashBoardWidget extends StatefulWidget {
  String isParentRole, isPartnerRole, isUserRole, currentPage, userId;
  ProfileInfoModal profileInfoModal;

  DashBoardWidget(this.isParentRole, this.isPartnerRole, this.isUserRole,
      {this.currentPage, this.userId, this.profileInfoModal});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return DashBoardState(isParentRole, isPartnerRole, isUserRole);
  }
}

class DashBoardState extends State<DashBoardWidget>
    with WidgetsBindingObserver {
  // SkillIntrestDataModel _mSkillIntrestDataModel;

  bool showCoachMarks = false;

  DashBoardState(this.isParentRole, this.isPartnerRole, this.isUserRole);

  String badgeType = '', badgeImage;

  int gamificationPoints;
  PackageInfo packageInfo;
  Timer _timer1;

  bool isUserProfile = true;
  bool isHome = false;
  bool isConnection = false;
  bool isFeed_AccessControl = true;
  bool isGroup_AccessControl = true;

  bool isConnection_AccessControl = true;
  bool isChat_AccessControl = true;
  bool isMessage = false;
  bool isMore = false;
  final GlobalKey<ScaffoldState> _scaffoldKey1 = GlobalKey<ScaffoldState>();

  // PageController pageController = PageController();
  final pageController = PageController();
  StreamSubscription<dynamic> _streamSubscription;
  List<Friends> spikeBotdataList = List();
  StreamSubscription<dynamic> _streamSubscription2;
  StreamSubscription<dynamic> _streamSubscriptionEdit;
  StreamSubscription<dynamic> _streamSubscription3;
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String profilePath = "",
      companyPath = "",
      companyName = "",
      userIdPref,
      roleId,
      deviceId,
      userName = " ";
  String isParentRole = "false", isPartnerRole = "false", isUserRole = "false";
  ConnectionNotificationModel connectionNotificationModel;
  String dateOfBirth = "1591343688213", creationTime;
  bool isAllowToSwitch = true;
  ProfileInfoModal profileInfoModal;
  bool isCongratulationVisible = true;
  int diffrenceInDob = 0;
  bool isUserLoginFirstTime;
  bool isFeedPopUP = false;
  bool isDisplayNewFeaturePopUp = false;
  RewardStatus rewardStatus;

  onTapSignOut() async {
    try {
      // setState(() {
      Constant.isAlreadyLoggedIn = false;
      // });
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setBool(UserPreference.LOGIN_STATUS, false);
      prefs.setBool(UserPreference.IS_USER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARTNER_ROLE, false);
      prefs.setBool(UserPreference.IS_PARENT_ROLE, false);
      prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, false);
      prefs.setString(UserPreference.PATHURL,'');
      prefs.setString(UserPreference.IS_DIALOG_SHOW, "true");
      prefs.setString(UserPreference.NAME, "");
      prefs.setString(UserPreference.COMPANY_NAME_PATH, "");
      print("onTapSignOut signout++++");

      Map map = {
        "userId": int.parse(prefs.getString(UserPreference.USER_ID)),
        "deviceId": prefs.getString("deviceId")
      };
      GlobalSocketConnection.socket
          .emitWithAck("disconnect1", [map]).then((data) {
        print("chat-login++++" + data.toString());
      });

      GlobalSocketConnection.socket.emit("disconnect2", []);

      bloc.resetData(prefs);
      Navigator.of(context).popUntil((route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LoginPage(null)),
      );
    } catch (e) {
      print("error signout++++" + e.toString());
    }
  }

  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;

            print("sastoken++++" + sasToken);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  String sasToken, containerName;

  Future apiCallingUpdateDialogStatus() async {
    try {
      Response response;
      print("DatatCallingmap:-");
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": ["gamification", "exploreOpportunity"],
        "display": false
      };

      print("map   ENDPOINT_UPDATE_DIALOG_STATUS:-" + map.toString());
      response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            setState(() {});
          }
        }
      }
    } catch (e) {
      print("Errorr:-" + e.toString());
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future fetchSpikeBotInfo() async {
    try {
      print("------------SPIKE BOAT");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall3(
            context,
            Constant.ENDPOINT_SPIKE_BOT_USER + userIdPref + "&roleId=" + roleId,
            "get");
        print("------------SPIKE BOAT" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              spikeBotdataList.clear();

              spikeBotdataList =
                  ParseJson.parseBotData(response.data['result'], userIdPref);
              print("creation++++++++++" +
                  spikeBotdataList[0].creationTime.toString());
              print(Util.getConvertedDateStamp(
                  spikeBotdataList[0].creationTime.toString()));
              if (spikeBotdataList != null) {
                setState(() {
                  spikeBotdataList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future apiCallForLogout() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        //assestList.removeAt(0);
        Map map = {"deviceId": prefs.getString("deviceId"), "roleId": roleId};

        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_LOGOUT, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              onTapSignOut();
            } else {
              ToastWrap.showToast(msg, context);
            }
          } else {
            if (response.statusCode == 401) {
              onTapSignOut();
            }
          }
        } else {
          onTapSignOut();
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      onTapSignOut();
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future apiCallingForGetNotificationCount() async {
    print("roleId+++++++ Child" + "&roleId=" + Constant.ROLE_ID);

    try {
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_NOTIFICATION_COUNT +
              userIdPref +
              "&roleId=" +
              roleId,
          "get");

      print("response Child" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            connectionNotificationModel =
                ParseJson.parseConnectionNotification(response.data['result']);
            if (connectionNotificationModel != null) {
              setState(() {
                connectionNotificationModel;
              });

              if (int.parse(connectionNotificationModel.notificationCount) >
                  0) {
                syncDoneController
                    .add(connectionNotificationModel.notificationCount);
              }
            }
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future refresh() async {
    try {
      print("Notification count loading////" +
          Constant.ENDPOINT_NOTIFICATION_COUNT +
          userIdPref +
          "&roleId=" +
          prefs.getString(UserPreference.ROLE_ID));
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_NOTIFICATION_COUNT +
              userIdPref +
              "&roleId=" +
              prefs.getString(UserPreference.ROLE_ID),
          "get");
      print("Notification count loading" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            connectionNotificationModel =
                ParseJson.parseConnectionNotification(response.data['result']);
            if (connectionNotificationModel != null) {
              //  print("messagecount"+connectionNotificationModel.messagingCount);
              if (mounted) {
                setState(() {
                  connectionNotificationModel;
                });
                if (int.parse(connectionNotificationModel.notificationCount) >
                    0) {
                  syncDoneController
                      .add(connectionNotificationModel.notificationCount);
                }
              }
            }
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future apiCallingForUpdateFeed2(
      connectionCount, messageCount, notificationCount, groupCount) async {
    try {
      Map map = {
        "userId": int.parse(userIdPref),
        "connectionCount": connectionCount,
        "messagingCount": messageCount,
        "notificationCount": "0",
        "roleId": roleId
      };
      Response response = await ApiCalling2().apiCallPutWithMapData(
          Constant.applicationContext,
          Constant.ENDPOINT_NOTIFICATION_UPDATE,
          map);

      print("response api update notification:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            connectionNotificationModel = ConnectionNotificationModel(
                connectionCount, messageCount, "0", groupCount);
            syncDoneController.add("0");
            setState(() {
              connectionNotificationModel;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future apiCallingForUpdateFeed(
      connectionCount, messageCount, notificationCount, groupCount) async {
    try {
      Map map = {
        "userId": int.parse(userIdPref),
        "connectionCount": connectionCount,
        "messagingCount": messageCount,
        "notificationCount": notificationCount,
        "groupCount": groupCount,
        "roleId": roleId
      };
      Response response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_NOTIFICATION_UPDATE, map);

      print("response chat:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            connectionNotificationModel = ConnectionNotificationModel(
                connectionCount, messageCount, notificationCount, groupCount);

            setState(() {
              connectionNotificationModel;
            });
          }
        }
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  changeState(value) {
    switch (value) {
      case 0:
        {
          setState(() {
            isUserProfile = true;
            isHome = false;
            isConnection = false;
            isMessage = false;
            isMore = false;
          });
          print("clicked 1");

          break;
        }
      case 1:
        {
          setState(() {
            isHome = true;
            isUserProfile = false;
            isConnection = false;
            isMessage = false;
            isMore = false;
          });
          print("clicked 1");

          break;
        }
      case 2:
        {
          setState(() {
            isHome = false;
            isUserProfile = false;
            isConnection = true;
            isMessage = false;
            isMore = false;
          });
          if (connectionNotificationModel != null &&
              connectionNotificationModel.connectionCount != "0" &&
              connectionNotificationModel.connectionCount != "" &&
              connectionNotificationModel.connectionCount != "null") {
            connectionNotificationModel.connectionCount = "0";
            setState(() {
              connectionNotificationModel.connectionCount;
            });
            // if(int.parse(connectionNotificationModel.connectionCount)>0)
            apiCallingForUpdateFeed(
                "0",
                connectionNotificationModel.messagingCount,
                connectionNotificationModel.notificationCount,
                connectionNotificationModel.groupCount);
          }
          break;
        }

      case 3:
        {
          setState(() {
            isHome = false;
            isConnection = false;
            isUserProfile = false;
            isMessage = true;
            isMore = false;
            pageController.jumpToPage(3);
          });
          if (connectionNotificationModel != null &&
              connectionNotificationModel.messagingCount != "0" &&
              connectionNotificationModel.messagingCount != "" &&
              connectionNotificationModel.messagingCount != "null") {
            connectionNotificationModel.messagingCount = "0";
            setState(() {
              connectionNotificationModel.messagingCount;
            });
            //  if(int.parse(connectionNotificationModel.messagingCount)>0)
            apiCallingForUpdateFeed(
                connectionNotificationModel.connectionCount,
                "0",
                connectionNotificationModel.notificationCount,
                connectionNotificationModel.groupCount);
          }
          print("clicked 4");
          break;
        }
      case 4:
        {
          setState(() {
            isHome = false;
            isConnection = false;
            isUserProfile = false;
            isMessage = false;
            isMore = true;
          });
          print("clicked 5");
          // if(int.parse(connectionNotificationModel.groupCount)>0)
          apiCallingForUpdateFeed(
              connectionNotificationModel.connectionCount,
              connectionNotificationModel.messagingCount,
              connectionNotificationModel.notificationCount,
              "0");

          break;
        }
    }
  }

  ontapBottomNavigationBar(value) {
    updateRewardPoint();

    try {
      switch (value) {
        case 0:
          {
            try {
              setState(() {
                isUserProfile = true;
                isHome = false;
                isConnection = false;
                isMessage = false;
                isMore = false;
                pageController.jumpToPage(0);
              });
              print("clicked 1");
            } catch (e) {
              print("onTapBottomNavigationBar case 0 Errror+++0+0" +
                  e.toString());
              crashlytics_bloc.recordCrashlyticsError(
                  e, "studentDashboard", context);
            }

            break;
          }
        case 1:
          {
            try {
              setState(() {
                isHome = true;
                isUserProfile = false;
                isConnection = false;
                isMessage = false;
                isMore = false;
                pageController.jumpToPage(1);
              });
              print("clicked 1");
            } catch (e) {
              print("onTapBottomNavigationBar case 1 Errror+++0+0" +
                  e.toString());
              crashlytics_bloc.recordCrashlyticsError(
                  e, "studentDashboard", context);
            }

            break;
          }
        case 2:
          {
            try {
              setState(() {
                isHome = false;
                isUserProfile = false;
                isConnection = true;
                isMessage = false;
                isMore = false;
                pageController.jumpToPage(2);
              });
              if (connectionNotificationModel != null &&
                  connectionNotificationModel.connectionCount != "0" &&
                  connectionNotificationModel.connectionCount != "" &&
                  connectionNotificationModel.connectionCount != "null") {
                connectionNotificationModel.connectionCount = "0";
                setState(() {
                  connectionNotificationModel.connectionCount;
                });
                // if(int.parse(connectionNotificationModel.connectionCount)>0)
                apiCallingForUpdateFeed(
                    "0",
                    connectionNotificationModel.messagingCount,
                    connectionNotificationModel.notificationCount,
                    connectionNotificationModel.groupCount);
              }
              print("clicked 2");
            } catch (e) {
              print("onTapBottomNavigationBar case 2 Errror+++0+0" +
                  e.toString());
              crashlytics_bloc.recordCrashlyticsError(
                  e, "studentDashboard", context);
            }
            break;
          }

        case 3:
          {
            try {
              setState(() {
                isHome = false;
                isConnection = false;
                isUserProfile = false;
                isMessage = true;
                isMore = false;
                pageController.jumpToPage(3);
              });
              if (connectionNotificationModel != null &&
                  connectionNotificationModel.messagingCount != "0" &&
                  connectionNotificationModel.messagingCount != "" &&
                  connectionNotificationModel.messagingCount != "null") {
                connectionNotificationModel.messagingCount = "0";
                setState(() {
                  connectionNotificationModel.messagingCount;
                });
                //  if(int.parse(connectionNotificationModel.messagingCount)>0)
                apiCallingForUpdateFeed(
                    connectionNotificationModel.connectionCount,
                    "0",
                    connectionNotificationModel.notificationCount,
                    connectionNotificationModel.groupCount);
              }
              print("clicked 4");
            } catch (e) {
              print("onTapBottomNavigationBar case 3 Errror+++0+0" +
                  e.toString());
              crashlytics_bloc.recordCrashlyticsError(
                  e, "studentDashboard", context);
            }
            break;
          }
        case 4:
          {
            setState(() {
              isHome = false;
              isConnection = false;
              isUserProfile = false;
              isMessage = false;
              isMore = true;
              pageController.jumpToPage(4);
            });
            print("clicked 5");
            // if(int.parse(connectionNotificationModel.groupCount)>0)
            apiCallingForUpdateFeed(
                connectionNotificationModel.connectionCount,
                connectionNotificationModel.messagingCount,
                connectionNotificationModel.notificationCount,
                "0");

            break;
          }
      }
    } catch (e) {
      print("onTapBottomNavigationBar Errror+++0+0" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future apiCallForAcessControl() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("apiCallForAcessControl+++");
        Response response = await ApiCalling2().apiCall(
            context,
            "ui/user/accessControl?schoolCode=WyixBjRi&userId=4515&roleId=1",
            "get");
        //if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("apiCallForAcessControl+++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {}
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++ 1111" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future profileApi(isShowLaoder, value) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        // if (isShowLaoder) CustomProgressLoader.showLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++ 3333" +
            Constant.ENDPOINT_PERSONAL_INFO_NEW +
            userIdPref +
            "/false/1/0");
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/1/0",
            "get");
        //if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("Mona ENDPOINT_PERSONAL_INFO++++ 4444" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                if (mounted) {
                  setState(() {
                    profileInfoModal;
                    prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                        profileInfoModal.profilePicture);
                    var introducingFeature =
                        response.data['result']["introducingFeatures"];
                    print("introducingFeature++++++" +
                        introducingFeature.toString());
                    prefs.setString(
                        UserPreference.STAGE, profileInfoModal.stage);

                    prefs.setString(
                        UserPreference.NAME,
                        profileInfoModal.firstName +
                            " " +
                            profileInfoModal.lastName);
                    setState(() {
                      userName = profileInfoModal.firstName +
                          " " +
                          profileInfoModal.lastName;
                    });

                    for (int i = 0; i < introducingFeature.length; i++) {
                      if (introducingFeature[i]["roleId"].toString() ==
                          roleId) {
                        if (introducingFeature[i]["exploreOpportunity"]
                                    .toString() !=
                                'null' &&
                            introducingFeature[i]["exploreOpportunity"]
                                    .toString() !=
                                '') {
                          isFeedPopUP =
                              introducingFeature[i]["exploreOpportunity"];
                        }
                        if ((introducingFeature[i]["gamification"].toString() !=
                                    'null' &&
                                introducingFeature[i]["gamification"]
                                        .toString() !=
                                    '') ||
                            introducingFeature[i]["exploreOpportunity"]
                                        .toString() !=
                                    'null' &&
                                introducingFeature[i]["exploreOpportunity"]
                                        .toString() !=
                                    '') {
                          if (introducingFeature[i]["gamification"] ||
                              introducingFeature[i]["exploreOpportunity"]) {
                            isFeedPopUP = true;
                          }
                        }
                        try {
                          String schoolCode = profileInfoModal.schoolCode;
                          if (schoolCode == null ||
                              schoolCode == "" ||
                              schoolCode == "null") {
                            schoolCode = "";
                            prefs.setBool(UserPreference.IS_SCHOOL, false);
                          } else {
                            prefs.setBool(UserPreference.IS_SCHOOL, true);
                          }
                          prefs.setString(
                              UserPreference.SCHOOL_CODE, schoolCode);
                        } catch (e) {}
                        prefs.setBool(UserPreference.IS_COMMUNITY_POPUP, false);

                        //for  coach mark Apurva
                        print(
                            'profileApi introducingFeature[i]["coachMark"]:: ${introducingFeature[i]["coachMark"]}');

                        prefs.setBool(
                            UserPreference.IS_COACHMARK_POPUP,
                            introducingFeature[i]["selfRecommendation"] ==
                                        null ||
                                    introducingFeature[i]
                                            ["selfRecommendation"] ==
                                        '' ||
                                    introducingFeature[i]
                                            ["selfRecommendation"] ==
                                        'null'
                                ? false
                                : introducingFeature[i]["selfRecommendation"]);

                        prefs.setString(
                            UserPreference.COACH_MARK_NAME_POPUP, 'coachMark');

                        showCoachMarks =
                            prefs.getBool(UserPreference.IS_COACHMARK_POPUP);

                        isDisplayNewFeaturePopUp =
                            introducingFeature[i]["display1"];
                        if (isDisplayNewFeaturePopUp == null) {
                          isDisplayNewFeaturePopUp = false;
                        }

                        if (isDisplayNewFeaturePopUp) {
                          print('syncDoneController.add("dialogVisible") 111');
                          syncDoneController.add("dialogVisible");
                        }
                        setState(() {
                          isFeedPopUP;
                          isDisplayNewFeaturePopUp;
                        });
                      }
                    }
                    bool isPreLoginSetting =
                        response.data["result"]["isLeaderboardDisplay"];
                    if (isPreLoginSetting == null) {
                      isPreLoginSetting = false;
                    }
                    try {
                      if (profileInfoModal.stage != null &&
                          int.parse(profileInfoModal.stage) < 5) {
                        //setState((){
                        isCongratulationVisible = true;
                        //syncDoneController.add("dialogVisible");
                        //});
                      } else {
                        isCongratulationVisible = false;
                      }
                      prefs.setBool(
                          UserPreference.IS_PRE_LOGIN, isPreLoginSetting);
                      prefs.setString(
                          UserPreference.ISHide, profileInfoModal.isHide);
                      prefs.setString(
                          UserPreference.TAGLINE, profileInfoModal.tagline);
                      prefs.setString(
                          UserPreference.ISACTIVE, profileInfoModal.isActive);
                      prefs.setString(
                          UserPreference.NAME,
                          profileInfoModal.firstName +
                              " " +
                              profileInfoModal.lastName);
                      prefs.setString(UserPreference.PROFILE_IMAGE_PATH,
                          profileInfoModal.profilePicture);
                      //Update user gamification points, badge and image
                      badgeImage = profileInfoModal.badgeImage;
                      badgeType = profileInfoModal.badge;
                      gamificationPoints = profileInfoModal.gamificationPoints;
                      prefs.setString(
                          UserPreference.badgeType, profileInfoModal.badge);
                      prefs.setString(UserPreference.badgeImage,
                          profileInfoModal.badgeImage);
                      prefs.setInt(UserPreference.gamificationPoints,
                          profileInfoModal.gamificationPoints);

                      print('Apurva gamificationPoints:: $gamificationPoints');
                    } catch (e) {
                      crashlytics_bloc.recordCrashlyticsError(
                          e, "studentDashboard", context);
                    }
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++ 1111" + e.toString());
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future updateRewardPoint() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("rewarPoint updating++++" +
            Constant.ENDPOINT_PERSONAL_INFO_NEW +
            userIdPref +
            "/false/1/0");
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_PERSONAL_INFO_NEW + userIdPref + "/false/1/0",
            "get");

        //if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("rewarPoint updating++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                if (mounted) {
                  try {
                    setState(() {
                      //Update user gamification points, badge and image
                      badgeImage = profileInfoModal.badgeImage;
                      badgeType = profileInfoModal.badge;
                      gamificationPoints = profileInfoModal.gamificationPoints;
                      prefs.setString(
                          UserPreference.badgeType, profileInfoModal.badge);
                      prefs.setString(UserPreference.badgeImage,
                          profileInfoModal.badgeImage);
                      prefs.setInt(UserPreference.gamificationPoints,
                          profileInfoModal.gamificationPoints);
                    });
                  } catch (e) {
                    print("error+++++++++++++" + e.toString());
                    crashlytics_bloc.recordCrashlyticsError(
                        e, "studentDashboard", context);
                  }
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  String linkData;

  getSharedPrefrence() async {
    try {
      packageInfo = await PackageInfo.fromPlatform();
      prefs = await SharedPreferences.getInstance();
      profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
      userIdPref = prefs.getString(UserPreference.USER_ID);
      roleId = prefs.getString(UserPreference.ROLE_ID);
      deviceId = prefs.getString(UserPreference.DEVICE_ID);
      userName = prefs.getString(UserPreference.NAME);
      companyPath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
      companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
      try {
        linkData = prefs.getString(UserPreference.LINK);
      } catch (e) {
        linkData = "";
        crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
      }
      try {
        var access_feedLike = prefs.getBool(UserPreference.IS_SCHOOL);
        if (access_feedLike == null) {
          bloc.accessControlParam(prefs);
        }
      } catch (e) {
        bloc.accessControlParam(prefs);
      }
      dateOfBirth = prefs.getString(UserPreference.DOB);

      print("dateOfBirth++++++++++" + dateOfBirth.toString());

      if (dateOfBirth == "null" || dateOfBirth == null || dateOfBirth == "") {
        dateOfBirth = "0";
        setState(() {
          dateOfBirth;
        });
      }

      // apiCallForAcessControl();

      creationTime = prefs.getString(UserPreference.CREATION_TIME);
      isUserLoginFirstTime =
          prefs.getBool(UserPreference.IS_USER_LOGIN_FIRST_TIME);
      isParentRole = prefs.getString(UserPreference.IS_PARENT_ROLE);
      isPartnerRole = prefs.getString(UserPreference.IS_PARTNER_ROLE);
      isUserRole = prefs.getString(UserPreference.IS_USER_ROLE);
      badgeImage = prefs.getString(UserPreference.badgeImage);
      badgeType = prefs.getString(UserPreference.badgeType);
      gamificationPoints = prefs.getInt(UserPreference.gamificationPoints);




      try {
        isFeed_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_FEED_STATUS)
            .toLowerCase() ==
            "true";
        isGroup_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_GROUP)
            .toLowerCase() ==
            "true";
        isChat_AccessControl =
        prefs.getString(UserPreference.ACCESS_CONTROL_CHAT).toLowerCase() ==
            "disable"
            ? false
            : true;
        isConnection_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
            .toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isFeed_AccessControl = true;
        isGroup_AccessControl = true;
        isChat_AccessControl = true;
        isConnection_AccessControl = true;
      }



      if (widget.currentPage != null && widget.currentPage.length > 0)
        setCurentPage();
      // Api call for get setting data
      bloc.fetchSetting('', context, prefs);
      profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);

      GlobalSocketConnection.socket.onConnect((data) {
        print("=====connected...");
        addUser();
      });
      apiCallForAcessControl();
      setState(() {});
      addUser();
      GlobalSocketConnection.socket.onConnectError((data) {});
      // await getVersion();

      await profileApi(false, "");
      try {
        print("linkData++++" + linkData.toString());
        if (linkData != null &&
            linkData != "" &&
            !isDisplayNewFeaturePopUp &&
            !prefs.getBool(UserPreference.IS_COACHMARK_POPUP)) {
          prefs.setString(UserPreference.LINK, "");
          if (isFeed_AccessControl ||
              isGroup_AccessControl ||
              isChat_AccessControl) {
            shareUrlOption(linkData);
          }
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
      }
      apiCallingForGetNotificationCount();
      fetchSpikeBotInfo();
      setState(() {});

      // if (true) {
      if (isDisplayNewFeaturePopUp) {
        syncDoneController.add("dialogVisible");
        String result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => NewFeautreBasePageWidget()));
        try {
          CustomProgressLoader.cancelLoader(context);
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(
              e, "studentDashboard", context);
        }
        await checkCoachMarkSliderTOShow();
        // navigateToCoachMarksSlider();
      } else {
        try {
          //if(!isCongratulationVisible){
          // syncDoneController.add("dialogVisible");
          //}
          await checkCoachMarkSliderTOShow();
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(
              e, "studentDashboard", context);
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  void shareUrlOption(link) {
    showDialog(
        barrierDismissible: false,
        context: Constant.applicationContext,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(Constant.applicationContext);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 24.0,
                            child: Container(
                                height: prefs.getString(
                                            UserPreference.ROLE_ID) ==
                                        "4"
                                    ? 248.0
                                    : prefs != null &&
                                            prefs.getString(UserPreference
                                                    .ACCESS_CONTROL_ALLOWFEEDPOST) !=
                                                null &&
                                            prefs.getString(UserPreference
                                                    .ACCESS_CONTROL_ALLOWFEEDPOST) ==
                                                "true"
                                        ? 200.0
                                        : 145.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          "Chat",
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        )),
                                                    onTap: () {
                                                      if (prefs.getString(
                                                              UserPreference
                                                                  .ISACTIVE) ==
                                                          "true") {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        Navigator.of(Constant
                                                                .applicationContext)
                                                            .push(
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        ChatFriendListWithHeader(
                                                                          link,
                                                                          "",
                                                                          userIdPref,
                                                                          pageName:
                                                                              "notification",
                                                                          roleId:
                                                                              roleId,
                                                                        )));
                                                      } else {
                                                        Navigator.pop(Constant
                                                            .applicationContext);
                                                        ToastWrap.showToast(
                                                            MessageConstant
                                                                .PENDING_PROFILE_ACTIVATION,
                                                            Constant
                                                                .applicationContext);
                                                      }
                                                    },
                                                  ),
                                                  prefs != null &&
                                                          prefs.getString(
                                                                  UserPreference
                                                                      .ACCESS_CONTROL_ALLOWFEEDPOST) !=
                                                              null &&
                                                          prefs.getString(
                                                                  UserPreference
                                                                      .ACCESS_CONTROL_ALLOWFEEDPOST) ==
                                                              "true"
                                                      ? Column(
                                                          children: <Widget>[
                                                            Container(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              height: 1.0,
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                  height: 50.0,
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          13.0,
                                                                          0.0,
                                                                          13.0),
                                                                  child: Text(
                                                                    "Feed",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        height:
                                                                            1.2,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                              onTap: () async {
                                                                if (prefs.getString(
                                                                        UserPreference
                                                                            .ISACTIVE) ==
                                                                    "true") {
                                                                  if (prefs
                                                                      .getString(
                                                                      UserPreference.ACCESS_CONTROL_FEED_STATUS)
                                                                      .toLowerCase() ==
                                                                      "true") {
                                                                    Navigator.pop(
                                                                        Constant
                                                                            .applicationContext);
                                                                    Navigator.of(
                                                                        Constant.applicationContext)
                                                                        .push(MaterialPageRoute(
                                                                        builder: (BuildContext context) => AddPost(
                                                                          profileInfoModal,
                                                                          "",
                                                                          groupDetailModel: null,
                                                                          link: link,
                                                                        )));
                                                                  } else {
                                                                    ToastWrap.showToastForAccessDenied(
                                                                        MessageConstant
                                                                            .FEATURE_DIABLED,
                                                                        context);
                                                                  }
                                                                } else {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  ToastWrap.showToast(
                                                                      MessageConstant
                                                                          .PENDING_PROFILE_ACTIVATION,
                                                                      Constant
                                                                          .applicationContext);
                                                                }
                                                              },
                                                            ),
                                                          ],
                                                        )
                                                      : SizedBox(),
                                                  Column(
                                                    children: <Widget>[
                                                      Container(
                                                        color: ColorValues
                                                            .BORDER_COLOR,
                                                        height: 1.0,
                                                      ),
                                                      InkWell(
                                                        child: Container(
                                                            height: 50.0,
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    0.0,
                                                                    13.0,
                                                                    0.0,
                                                                    13.0),
                                                            child: Text(
                                                              "Group",
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  height: 1.2,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                            )),
                                                        onTap: () async {
                                                          if (prefs.getString(
                                                                  UserPreference
                                                                      .ISACTIVE) ==
                                                              "true") {
                                                            if (prefs
                                                                .getString(
                                                                UserPreference
                                                                    .ACCESS_CONTROL_GROUP)
                                                                .toLowerCase() ==
                                                                "true") {
                                                              Navigator.pop(Constant
                                                                  .applicationContext);
                                                              Navigator.of(Constant
                                                                  .applicationContext)
                                                                  .push(new MaterialPageRoute(
                                                                  builder: (BuildContext
                                                                  context) =>
                                                                      GroupListShareFlow(
                                                                          profileInfoModal,
                                                                          link)));
                                                            } else {
                                                              ToastWrap.showToastForAccessDenied(
                                                                  MessageConstant
                                                                      .FEATURE_DIABLED,
                                                                  context);
                                                            }
                                                          } else {
                                                            Navigator.pop(Constant
                                                                .applicationContext);
                                                            ToastWrap.showToast(
                                                                MessageConstant
                                                                    .PENDING_PROFILE_ACTIVATION,
                                                                Constant
                                                                    .applicationContext);
                                                          }
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                  prefs.getString(UserPreference
                                                              .ROLE_ID) ==
                                                          "4"
                                                      ? Column(
                                                          children: <Widget>[
                                                            Container(
                                                              color: ColorValues
                                                                  .BORDER_COLOR,
                                                              height: 1.0,
                                                            ),
                                                            InkWell(
                                                              child: Container(
                                                                  height: 50.0,
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          0.0,
                                                                          13.0,
                                                                          0.0,
                                                                          13.0),
                                                                  child: Text(
                                                                    "Opportunity",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .BLUE_COLOR_BOTTOMBAR,
                                                                        height:
                                                                            1.2,
                                                                        fontSize:
                                                                            16.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                              onTap: () async {
                                                                if (prefs.getString(
                                                                        UserPreference
                                                                            .ISACTIVE) ==
                                                                    "true") {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                } else {
                                                                  Navigator.pop(
                                                                      Constant
                                                                          .applicationContext);
                                                                  ToastWrap.showToast(
                                                                      MessageConstant
                                                                          .PENDING_PROFILE_ACTIVATION,
                                                                      Constant
                                                                          .applicationContext);
                                                                }

                                                                //}
                                                              },
                                                            ),
                                                          ],
                                                        )
                                                      : Container(height: 0.0),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(
                                                  Constant.applicationContext);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('state+++++++++ = $state');
    if (state == AppLifecycleState.resumed) {
      profileApi(false, '');
    } else {
      // calling();
    }
    print("dispose test13 method call");
  }

  calling() async {
    print("disconnectApi++++calling+++");
    Map map = {
      "userId": int.parse(userIdPref),
    };
    print("dispose disconnect1 method call");
  }

  @override
  void dispose() {
    // TODO: implement dispose
    print("dispose test12 method call");
    calling();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void addUser() {
    Map map = {
      "userId": int.parse(userIdPref),
    };
    print("data for addUser" + map.toString());
    GlobalSocketConnection.socket.emitWithAck("chat-login", [map]).then((data) {
      // this callback runs when this specific message is acknowledged by the server
      print("chat-login++++" + data.toString());
    });
  }

  bool isConnect = false;

  getdat() async {
    isConnect = await ConectionDetecter.isConnected();
    await getSharedPrefrence();
  }

  bool dobCheck(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      DateTime now = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(now, 13);

      if (diffrenceInDob < 15)
        return false;
      else
        return true;
    } else {
      return true;
    }
  }

  setCurentPage() {
    switch (widget.currentPage) {
      case Constant.PROFILE_TYPE:
        {
          ontapBottomNavigationBar(0);
          break;
        }
      case Constant.FEED_TYPE:
        {
          ontapBottomNavigationBar(1);
          break;
        }
      case Constant.CHAT_TYPE:
        {
          ontapBottomNavigationBar(3);
          break;
        }
      case Constant.CONNECTIONS_TYPE:
        {
          ontapBottomNavigationBar(2);
          break;
        }
      case Constant.GROUP_TYPE:
        {
          ontapBottomNavigationBar(4);
          break;
        }
    }
  }

  bool isUserRepoted = true;

  List<DrawerMenu> drawerMenu = [];
  bool _showOtherRole = false;

  @override
  void initState() {
    drawerMenu.addAll([
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/invite_friend_earn.png",
        title: "Invite friends & earn",
        onTap: () {
          Navigator.of(context).pop();
          String referCode = prefs.getString(UserPreference.referCode);
          Util.shareAppLinkViaOtherApp(
              context, referCode, prefs.getString(UserPreference.NAME));
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/spikeview_boot.png",
        title: "Help (spikeview bot)",
        onTap: () {
          Navigator.of(context).pop();
          if (spikeBotdataList.length > 0) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) =>
                    ChatRoomWidget(spikeBotdataList[0], "", ""),
              ),
            );
          }
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/account_setting.png",
        title: "Account settings",
        onTap: () {
          Navigator.of(context).pop();
          onTapEditUserDetail();
        },
      ),
     /* DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/help.png",
        title: "Help",
        onTap: () {
          Navigator.of(context).pop();
          if (spikeBotdataList.length > 0) {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) =>
                    ChatRoomWidget(spikeBotdataList[0], "", ""),
              ),
            );
          }
        },
      ),*/
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/privacy_policy.png",
        title: "Privacy policy",
        onTap: () {
          Navigator.of(context).pop();
          Navigator.push(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) =>
                    WebViewWidget(Constant.PRIVACY_POLICY, "Privacy Policy")),
          );
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/about_spike_view.png",
        title: "About spikeview",
        onTap: () {
          Navigator.of(context).pop();
          Navigator.push(
            Constant.applicationContext,
            MaterialPageRoute(
                builder: (context) =>
                    WebViewWidget(Constant.ABOUT_US, "About spikeview")),
          );
        },
      ),
      DrawerMenu(
        assetIcon: "assets/drawer/ic_explore_opportunities.png",
        title: "Explore opportunities",
        onTap: () {
          Navigator.of(context).pop();
          if (prefs.getString(UserPreference.ISACTIVE) == "true") {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) => OpportunitySearch("")));
          } else {
            ToastWrap.showToast(
                MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                context);
          }
        },
      ),
      DrawerMenu(
        assetIcon: "assets/newDesignIcon/icon/sigen_out.png",
        title: "Sign out",
        onTap: () {
          Navigator.of(context).pop();
          showSignOutDialog();
        },
      ),
    ]);
    //  GlobalSocketConnection.initSocket();
    if (widget.currentPage == Constant.GROUP_TYPE) {
      if (widget.userId != null) {
        userIdPref = widget.userId;
        setState(() {});
      }
    }
    isUserRepoted = UserPreference.getIsUserReported();

    callApiForSaas(false);
    getdat();

    WidgetsBinding.instance.addObserver(this);

    _streamSubscription2 =
        CompletedStudentWizardState.syncDoneController.stream.listen((value) {
      try {
        profileApi(true, value);

        setState(() {
          profileInfoModal.stage = "8";
          print(
              'Dash_board isCongratulationVisible:: before:: $isCongratulationVisible');
          //setState(() {
          isCongratulationVisible = false;
          //});
          print(
              'Dash_board isCongratulationVisible:: after:: $isCongratulationVisible');
        });
        if (value == "feed") {
          ontapBottomNavigationBar(1);
        } else if (value == "connection") {
          ontapBottomNavigationBar(2);
        }
      } catch (e) {
        print("CompletedStudentWizardState.syncDoneController Errror+++0+0" +
            e.toString());
        crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
      }
    });
    _streamSubscriptionEdit =
        EditUserProfileState.syncDoneController.stream.listen((event) {
      try {
        print("syncDoneController..value." + event);
        userName = prefs.getString(UserPreference.NAME);
        profileApi(false, '');
        setState(() {
          prefs.setString(UserPreference.NAME, event);
          userName;
        });
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
      }
    });

    _streamSubscription2 =
        AddGoalForExistingUsreState.syncDoneController.stream.listen((value) {
      try {
        setState(() {
          profileInfoModal.stage = "8";
        });
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
      }
    });

    _streamSubscription2 =
        InviteNonSpikeViewMemberState.syncDoneController.stream.listen((value) {
      //profileApi(true,value);

      setState(() {
        profileInfoModal.stage = "8";
      });

      ontapBottomNavigationBar(2);
    });

    _streamSubscription2 =
        ChatFriendListView.syncDoneController.stream.listen((value) {
      //profileApi(true,value);

      apiCallingForUpdateFeed(
          connectionNotificationModel.connectionCount,
          "0",
          connectionNotificationModel.notificationCount,
          connectionNotificationModel.groupCount);
    });

    // TODO: implement initState
    _streamSubscription2 =
        EditProfileImageWidgetState.syncDoneController.stream.listen((value) {
      profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
      userName = prefs.getString(UserPreference.NAME);
      setState(() {});
    });

    _streamSubscription2 =
        EditProfileImageWidgetState.syncDoneController.stream.listen((value) {
      profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
      userName = prefs.getString(UserPreference.NAME);
      setState(() {});
    });

    _streamSubscription3 =
        UserProfileDashBoardState.syncDoneController.stream.listen((dob) {
      if (dob == "refresh") {
        setState(() {
          profileInfoModal.stage = "8";
        });
      } else {
        profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
        userName = prefs.getString(UserPreference.NAME);
        if (dob == "dialogVisible") {
          dob = "0";
        }
        dateOfBirth = dob;
        if (dob != null || dob != "null" || dob != "") {
          isAllowToSwitch = dobCheck(dob);
          dateOfBirth = "0";
          setState(() {});
        }

        setState(() {});
      }
    });

    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
      print("dashbaord....syncDoneController changes" + value);

      refresh();

      if (value == Constant.REWARD_TYPE) {
        //call personal info API
        profileApi(false, "");
      }
      /*else if (value == "RecommendationReplied") {

        print("dashbaord....syncDoneController changes//////" + value);

        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => ManageRecommendationParent(
                profileInfoModal, true, false, userIdPref, sasToken)));
      }*/
    });

    _streamSubscription =
        NotificationWidgetState.syncDoneController.stream.listen((value) {
      if (value == "connectionPage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(2);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "Feed") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(1);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "groupPage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(4);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "chatPage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(3);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else if (value == "profilePage") {
        if (prefs.getString(UserPreference.ISACTIVE) == "true") {
          ontapBottomNavigationBar(0);
        } else {
          ToastWrap.showToast(
              MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
              context);
        }
      } else {
        apiCallingForUpdateFeed2(
            connectionNotificationModel.connectionCount,
            connectionNotificationModel.messagingCount,
            0,
            connectionNotificationModel.groupCount);
      }
    });

    _streamSubscription2 = Util.syncDoneController.stream.listen((value) {
      rewardStatus = value;
      print(
          'Apurva Gamification updated points:: ${rewardStatus.gamificationPoints}');
      setState(() {
        badgeType = rewardStatus.badge;
        gamificationPoints = rewardStatus.gamificationPoints;
        prefs.setString(UserPreference.badgeType, badgeType);
        prefs.setInt(UserPreference.gamificationPoints, gamificationPoints);

        if (rewardStatus.badgeImage != '' &&
            rewardStatus.badgeImage != 'null' &&
            rewardStatus.badgeImage != null)
          badgeImage = rewardStatus.badgeImage;
        prefs.setString(UserPreference.badgeImage, badgeImage);
        print(
            'Apurva badgeType stream:: $badgeType, gamificationPoints:: $gamificationPoints');
      });
    });

    _streamSubscription2 =
        CompetenciesStudentState.syncDoneController.stream.listen((value) {
      rewardStatus = value;
      print(
          'Apurva CompetenciesStudentState Gamification updated points:: ${rewardStatus.gamificationPoints}');
      setState(() {
        badgeType = rewardStatus.badge;
        gamificationPoints = rewardStatus.gamificationPoints;
        prefs.setString(UserPreference.badgeType, badgeType);
        prefs.setInt(UserPreference.gamificationPoints, gamificationPoints);
        if (rewardStatus.badgeImage != '' &&
            rewardStatus.badgeImage != 'null' &&
            rewardStatus.badgeImage != null)
          badgeImage = rewardStatus.badgeImage;
        prefs.setString(UserPreference.badgeImage, badgeImage);
      });
    });
    super.initState();
  }

  Future apiForUpdateRole(roleID) async {
    try {
      print("calling+++");
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleID),
        };

        response = await ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_UPDATE_ROLE, map);

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            prefs.setString(UserPreference.ROLE_ID, roleID);
            Constant.ROLE_ID = roleID;
            if (status == "Success") {
              if (roleID == "4") {
                prefs.setString(UserPreference.IS_PARTNER_ROLE, "true");
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) => DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE))));
              } else {
                prefs.setString(UserPreference.IS_PARENT_ROLE, "true");
                Navigator.of(context).pop();
                Navigator.of(context).pushReplacement(new MaterialPageRoute(
                    builder: (BuildContext context) => DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE))));
              }

              //  ToastWrap.showToast(msg);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }

  Future<void> onTapEditUserDetail() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => Account_Setting(userIdPref, "1")));
    if (result == "push") {
      syncDoneController.add("success");
    }
  }

  void showSignOutDialog() {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to sign out?',
            negativeText: 'No',
            positiveText: 'Yes',
            isSucessPopup: false,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              apiCallForLogout();
            },
          );
        });



  }

  Widget _drawerView() {
    return Drawer(
      child: Container(
        color: ColorValues.SELECTION_BG,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(20, 33, 13, 0),
              //color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                      onTap: () => Navigator.pop(context),
                      child: Padding(
                        padding: const EdgeInsets.only(top:5.0,right: 5),
                        child: Image.asset(
                          'assets/drawer/ic_back_drawer.png',
                          height: 22,
                          width: 22,
                        ),
                      )),
                  const SizedBox(height: 20),
                  InkWell(
                    onTap: () {
                      if (isParentRole == "true" || isPartnerRole == "true") {
                        setState(() {
                          _showOtherRole = !_showOtherRole;
                        });
                      }
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Row(
                          children: [
                            Expanded(
                              child: RichText(
                                maxLines: 3,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: userName,
                                  style: TextStyle(
                                    color:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 22.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: Constant.latoMedium,
                                  ),
                                  children: [
                                    WidgetSpan(
                                      child: badgeImage != '' &&
                                          badgeImage != 'null'
                                          ? Padding(
                                          padding: const EdgeInsets.only(
                                              left: 5.0,
                                              bottom: 4.0,
                                              right: 10),
                                          child: Util
                                              .getStudentBadgeDashBoard(
                                              badgeType, badgeImage))
                                          : const SizedBox.shrink(),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            isParentRole == "true" || isPartnerRole == "true"
                                ? Image.asset(
                              _showOtherRole
                                  ? "assets/drawer/ic_arrow_up.png"
                                  : 'assets/drawer/ic_arrow_down.png',
                              height: 12,
                              width: 12,
                            )
                                : const SizedBox.shrink()
                          ],
                        ),
                        const SizedBox(height: 6),
                        BaseText(
                          text: "Student",
                          textColor: const Color(0xff666B9A),
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Visibility(
                    visible: _showOtherRole,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          isParentRole == "true"
                              ? RoleWidget(
                            name: userName,
                            role: "Parent",
                            profile: profilePath,
                            onTap: () {
                              if (isParentRole == "true") {
                                DbHelper().deleteTable();
                                prefs.setString(
                                    UserPreference.ROLE_ID, "2");
                                Constant.ROLE_ID = "2";
                                Navigator.of(context).pop();
                                Navigator.of(context).pushReplacement(
                                    MaterialPageRoute(
                                        builder: (BuildContext
                                        context) =>
                                            DashBoardWidgetParent(
                                                prefs.getString(
                                                    UserPreference
                                                        .IS_PARENT_ROLE),
                                                prefs.getString(
                                                    UserPreference
                                                        .IS_PARTNER_ROLE),
                                                prefs.getString(
                                                    UserPreference
                                                        .IS_USER_ROLE))));
                              } else {
                                if (Util.currentAge(
                                    DateTime
                                        .fromMillisecondsSinceEpoch(
                                        int.tryParse(
                                            dateOfBirth)),
                                    18) >
                                    18) {
                                  Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder:
                                              (BuildContext context) =>
                                              ParentStory()));
                                } else {
                                  ToastWrap.showToast(
                                      MessageConstant
                                          .SORRY_OVER_18_BECOME_PARENT_ERROR,
                                      context);
                                }
                                //apiForUpdateRole("2");
                              }
                            },
                          )
                              : const SizedBox.shrink(),
                          const Divider(
                            color: Color(0xffE5EBF0),
                            height: 28,
                            thickness: 1,
                          ),
                          isPartnerRole == "true"
                              ? RoleWidget(
                            name: companyName,
                            role: "Partner",
                            profile: companyPath,
                            onTap: () {
                              if (isPartnerRole == "true") {
                                DbHelper().deleteTable();
                                prefs.setString(
                                    UserPreference.ROLE_ID, "4");
                                Constant.ROLE_ID = "4";
                                Navigator.of(context).pop();
                                Navigator.of(context).pushReplacement(
                                    MaterialPageRoute(
                                        builder: (BuildContext
                                        context) =>
                                            DashBoardWidgetPartner(
                                                prefs.getString(
                                                    UserPreference
                                                        .IS_PARENT_ROLE),
                                                prefs.getString(
                                                    UserPreference
                                                        .IS_PARTNER_ROLE),
                                                prefs.getString(
                                                    UserPreference
                                                        .IS_USER_ROLE))));
                              } else {
                                if (isAllowToSwitch) {
                                  onTapPartnerMenu();
                                } else {
                                  ToastWrap.showToast(
                                      MessageConstant
                                          .SORRY_OVER_15_BECOME_PARTNER_ERROR,
                                      context);
                                }
                              }
                            },
                          )
                              : const SizedBox.shrink(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Divider(
              color: Color(0xffE5EBF0),
              height: 0,
              thickness: 1,
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(20, 24, 20, 12),
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 9),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: badgeType.toLowerCase() == 'gold'
                      ? const [Color(0x54FBBD2E), Color(0x54FBE248)]
                      : badgeType.toLowerCase() == 'silver'
                      ? const [Color(0x547E8D90), Color(0x54C8CFD0)]
                      : badgeType.toLowerCase() == 'bronze'
                      ? const [Color(0x54E8A57A), Color(0x54FDE1CF)]
                      : const [Color(0x54E8A57A), Color(0x54FDE1CF)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(5),
              ),
              clipBehavior: Clip.antiAlias,
              child: Row(
                children: [
                  Image.asset(
                    'assets/drawer/ic_gold_trophy.png',
                    height: 40,
                    width: 40,
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        BaseText(
                          text: "Reward points",
                          textColor: const Color(0xff27275A),
                          fontFamily: Constant.latoRegular,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        BaseText(
                          text: "$gamificationPoints",
                          textColor: const Color(0xff27275A),
                          fontFamily: Constant.latoRegular,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ],
                    ),
                  ),
                  badgeType != '' && badgeType != 'null'
                      ? Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Image.asset(
                      badgeType.toLowerCase() == 'gold'
                          ? 'assets/drawer/ic_gold_label.png'
                          : badgeType.toLowerCase() == 'silver'
                          ? 'assets/drawer/ic_silver_label.png'
                          : badgeType.toLowerCase() == 'bronze'
                          ? 'assets/drawer/ic_bronze_label.png'
                          : 'assets/drawer/ic_bronze_label.png',
                      height: 20,
                    ),
                  )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
            Expanded(
              child: ListView.separated(
                itemBuilder: (_, index) {
                  final item = drawerMenu[index];
                  return InkWell(
                    onTap: item.onTap,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(20, 10, 20, 15),
                      child: Row(
                        children: [
                          Image.asset(
                            item.assetIcon,
                            height: 40,
                            width: 40,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: BaseText(
                                text: item.title,
                                fontFamily: Constant.latoMedium,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                textColor:
                                ColorValues.HEADING_COLOR_EDUCATION_1),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (_, index) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: const Divider(
                    color: Color(0xffE5EBF0),
                    height: 0,
                    thickness: 1,
                  ),
                ),
                itemCount: drawerMenu.length,
                shrinkWrap: true,
                padding: EdgeInsets.zero,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> onTapPartnerMenu() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => PartnerStory(
              userIdPref,
            )));
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    //SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);

    onTapChangePass() {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) =>
                ChangePassword("", prefs.getString(UserPreference.ROLE_ID))),
      );
    }


    final bottomBar = BottomAppBar(
      elevation: 0.0,
      child: Container(
          clipBehavior: Clip.antiAlias,
          decoration:  BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.only(
              topRight: Radius.circular(25.0),
              topLeft: Radius.circular(25.0),
            ),

          ),

        height: 72.0,
        child: Padding(
          padding: const EdgeInsets.only(top:2.0),
          child: Container(
            // ***
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(25.0),
                topLeft: Radius.circular(25.0),
              ),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: const Color(0x75CCDCF7),
                  spreadRadius: 1,
                  blurRadius: 2,
                )
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.only(left:10.0,right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              isUserProfile
                                  ? "assets/newDesignIcon/profile_blue.png"
                                  : "assets/newDesignIcon/profile_new.png",
                              width: 40.0,
                              height: 40.0,
                            ),
                            TextViewWrap.textView(
                                "Profile",
                                TextAlign.center,
                                isUserProfile
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          if (isConnect) {
                            if (profileInfoModal != null &&
                                int.parse(profileInfoModal.stage) >= 5)
                              ontapBottomNavigationBar(0);
                          } else {
                            ontapBottomNavigationBar(0);
                          }
                        }),
                    flex: 2,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              isHome
                                  ? "assets/newDesignIcon/feed_blue.png"
                                  : "assets/newDesignIcon/feed.png",
                              width: 40.0,
                              height: 40.0,  color: !isFeed_AccessControl
                                ? Colors.grey.withOpacity(.5)
                                : null,
                            ),
                            TextViewWrap.textView(
                                "Feed",
                                TextAlign.center,
                                !isFeed_AccessControl
                                    ? Colors.grey.withOpacity(.5)
                                    : isHome
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          if (isConnect) {
                            print(
                                "profileInfoModal.stage++" + profileInfoModal.stage);
                            if (profileInfoModal != null &&
                                int.parse(profileInfoModal.stage) >= 5) if (prefs
                                .getString(UserPreference.ISACTIVE) ==
                                "true") {

                              if (isFeed_AccessControl) {
                                ontapBottomNavigationBar(1);
                              } else {
                                ToastWrap.showToastForAccessDenied(
                                    MessageConstant.FEATURE_DIABLED, context);
                              }
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                  context);
                            }
                          } else {
                            ontapBottomNavigationBar(1);
                          }
                        }),
                    flex: 2,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            connectionNotificationModel == null ||
                                connectionNotificationModel.connectionCount ==
                                    "null" ||
                                connectionNotificationModel.connectionCount ==
                                    "" ||
                                int.parse(connectionNotificationModel
                                    .connectionCount) ==
                                    0
                                ? Image.asset(
                              isConnection
                                  ? "assets/newDesignIcon/connection_blue.png"
                                  : "assets/newDesignIcon/connection.png",
                              width: 40.0,
                              height: 40.0,
                              color: !isConnection_AccessControl
                                  ? Colors.grey.withOpacity(.5)
                                  : null,
                            )
                                : Stack(
                              children: <Widget>[
                                Image.asset(
                                  isConnection
                                      ? "assets/newDesignIcon/connection_blue.png"
                                      : "assets/newDesignIcon/connection.png",
                                  width: 40.0,
                                  height: 40.0,
                                  color: !isConnection_AccessControl
                                      ? Colors.grey.withOpacity(.5)
                                      : null,
                                ),
                                Positioned(
                                  top: 4.0,
                                  right: 4.0,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        boxShadow: [
                                          BoxShadow(


                                            color: Color.fromRGBO(255, 0, 0, 0.65),
                                          )
                                        ]
                                    ),
                                    height: 8.0,
                                    width: 8.0,),
                                )
                              ],
                            ),
                            TextViewWrap.textView(
                                "Connections",
                                TextAlign.center,
                                !isConnection_AccessControl
                                    ? Colors.grey.withOpacity(.5)
                                    : isConnection
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          if (profileInfoModal != null &&
                              int.parse(profileInfoModal.stage) >= 5) {
                            if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                              if (isConnection_AccessControl) {
                                ontapBottomNavigationBar(2);
                              } else {
                                ToastWrap.showToastForAccessDenied(
                                    MessageConstant.FEATURE_DIABLED, context);
                              }
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                  context);
                            }
                          }
                        }),
                    flex: 3,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            connectionNotificationModel == null ||
                                connectionNotificationModel.messagingCount ==
                                    "null" ||
                                connectionNotificationModel.messagingCount ==
                                    "" ||
                                int.parse(connectionNotificationModel
                                    .messagingCount) ==
                                    0
                                ? Image.asset(
                              isMessage
                                  ? "assets/newDesignIcon/chat_blue.png"
                                  : "assets/newDesignIcon/chat_new.png",
                              width: 40.0,
                              height: 40.0,

                            )
                                : Stack(
                              children: <Widget>[
                                Image.asset(
                                  "assets/newDesignIcon/chat_new.png",

                                  width: 40.0,
                                  height: 40.0,
                                ),
                                Positioned(
                                  top: 4.0,
                                  right: 4.0,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        boxShadow: [
                                          BoxShadow(


                                            color: Color.fromRGBO(255, 0, 0, 0.65),
                                          )
                                        ]
                                    ),
                                    height: 8.0,
                                    width: 8.0,),
                                )
                              ],
                            ),
                            PaddingWrap.paddingfromLTRB(
                                0.0,
                                0.0,
                                0.0,
                                0.0,
                                TextViewWrap.textView(
                                    "Chat",
                                    TextAlign.center,
                                    isMessage
                                        ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                        : AppConstants.colorStyle.lightPurple,
                                    14.0,
                                    FontWeight.normal)),
                          ],
                        ),
                        onTap: () {
                          if (profileInfoModal != null &&
                              int.parse(profileInfoModal.stage) >= 5) {
                            if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                              ontapBottomNavigationBar(3);
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                  context);
                            }
                          }
                        }),
                    flex: 2,
                  ),
                  Expanded(
                    child: InkWell(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            connectionNotificationModel == null ||
                                connectionNotificationModel.groupCount ==
                                    "null" ||
                                connectionNotificationModel.groupCount ==
                                    "" ||
                                int.parse(connectionNotificationModel
                                    .groupCount) ==
                                    0
                                ? Image.asset(
                              isMore
                                  ? "assets/newDesignIcon/group_blue.png"
                                  : "assets/newDesignIcon/group_n.png",
                              width: 40.0,
                              height: 40.0,
                              color: !isGroup_AccessControl
                                  ? Colors.grey.withOpacity(.5)
                                  : null,
                            )
                                : Stack(
                              children: <Widget>[
                                Image.asset(
                                  isMore
                                      ? "assets/newDesignIcon/group_blue.png"
                                      : "assets/newDesignIcon/group_n.png",
                                  width: 40.0,
                                  height: 40.0,
                                  color: !isGroup_AccessControl
                                      ? Colors.grey.withOpacity(.5)
                                      : null,
                                ),
                                Positioned(
                                  top: 4.0,
                                  right: 4.0,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        boxShadow: [
                                          BoxShadow(


                                            color: Color.fromRGBO(255, 0, 0, 0.65),
                                          )
                                        ]
                                    ),
                                    height: 8.0,
                                    width: 8.0,),
                                )
                              ],
                            ),
                            TextViewWrap.textView(
                                "Groups",
                                TextAlign.center,
                                !isGroup_AccessControl
                                    ? Colors.grey.withOpacity(.5)
                                    :isMore
                                    ? ColorValues.BLUE_COLOR_BOTTOMBAR
                                    : AppConstants.colorStyle.lightPurple,
                                14.0,
                                FontWeight.normal),
                          ],
                        ),
                        onTap: () {
                          if (profileInfoModal != null &&
                              int.parse(profileInfoModal.stage) >= 5) {
                            if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                              if (isGroup_AccessControl) {
                                ontapBottomNavigationBar(4);
                              } else {
                                ToastWrap.showToastForAccessDenied(
                                    MessageConstant.FEATURE_DIABLED, context);
                              }
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR,
                                  context);
                            }
                          }
                        }),
                    flex: 2,
                  )
                     ,
                ],
              ),
            ),
          ),
        ),
      ),
    );



    final List<Widget> pages = [
      //UserProfileDashBoard
      //PublicProfileViewWidget
      PublicProfileViewWidget(
        "",
        _scaffoldKey1,
        connectionNotificationModel == null ||
                connectionNotificationModel.notificationCount == "null" ||
                connectionNotificationModel.notificationCount == "" ||
                int.parse(connectionNotificationModel.notificationCount) == 0
            ? 0
            : int.parse(
                connectionNotificationModel.notificationCount,
              ),
        profileInfoModal: widget.profileInfoModal,
      ),
      NewHomeWidget(
          _scaffoldKey1,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount)),
      /*  HomeWidget(
          _scaffoldKey1,
          connectionNotificationModel == null ||
              connectionNotificationModel.notificationCount == "null" ||
              connectionNotificationModel.notificationCount == "" ||
              int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount)),*/

      ConnectionsWidget(
          _scaffoldKey1,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount),roleId),
      ChatFriendListView(
          _scaffoldKey1,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount)),
/*      GroupBaseWidget(
          userIdPref,
          _scaffoldKey1,
          connectionNotificationModel == null ||
              connectionNotificationModel.notificationCount == "null" ||
              connectionNotificationModel.notificationCount == "" ||
              int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount)),*/
      GroupBaseWidgetNew(
          userIdPref,
          _scaffoldKey1,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount))
    ];

    final List<Widget> pages2 = [
      PublicProfileViewWidget(
          "",
          _scaffoldKey1,
          connectionNotificationModel == null ||
                  connectionNotificationModel.notificationCount == "null" ||
                  connectionNotificationModel.notificationCount == "" ||
                  int.parse(connectionNotificationModel.notificationCount) == 0
              ? 0
              : int.parse(connectionNotificationModel.notificationCount),
          profileInfoModal: widget.profileInfoModal),
    ];

    return Stack(children: <Widget>[
      WillPopScope(
          onWillPop: () {
            CustomProgressLoader.showDialogBackDialog(context);
          },
          child: Scaffold(
            key: _scaffoldKey1,
            backgroundColor: ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
            resizeToAvoidBottomInset: false,
            drawer: _drawerView(),
            body: PageView(
                scrollDirection: Axis.horizontal,
                onPageChanged: (index) {
                  changeState(index);
                },
                physics: NeverScrollableScrollPhysics(),
                controller: pageController,
                children:

                    pages),
            bottomNavigationBar: MediaQuery.of(context).viewInsets.bottom == 0
                ? bottomBar
                : null,
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerDocked,
          )),
      isFeedPopUP
          ? Positioned(
              left: 0.0,
              right: 0.0,
              top: 0.0,
              bottom: 0.0,
              child: Material(
                  type: MaterialType.transparency,
                  child: InkWell(
                      onTap: () {
                        isFeedPopUP = false;
                        if (mounted) {
                          setState(() {});
                        }
                        apiCallingUpdateDialogStatus();
                      },
                      child: Container(
                        color: Colors.black.withOpacity(.8),
                        child: Stack(
                          children: [
                            Positioned(
                              top: -20,
                              right: -15,
                              child: Image.asset(
                                  'assets/newFeature/Group 4527.png',
                                  height: 150,
                                  width: 150),
                            ),
                            Positioned(
                              top: 45.98,
                              right: 0,
                              left: 0.0,
                              bottom: 0.0,
                              child: Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Container(),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                0.0, 0, 15, 0),
                                            child: Image.asset(
                                                'assets/newFeature/Group 4528.png',
                                                height: 104.9),
                                          ),
                                          flex: 2,
                                        ),
                                      ],
                                    ),
                                    Text('Explore Opportunities',
                                        style: TextStyle(
                                            fontSize: 18,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            color: Colors.white)),
                                    Text(
                                        'Take advantage of amazing opportunities.',
                                        style: TextStyle(
                                            fontSize: 12,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            color: Colors.white)),
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          0.0, 70, 20, 0),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: Container(),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Image.asset(
                                                    'assets/newFeature/Group 4530.png',
                                                    height: 104.9),
                                              ],
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Container(),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: Column(
                                            children: [
                                              Text('Reward Points',
                                                  style: TextStyle(
                                                      fontSize: 18,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      color: Colors.white)),
                                              Text(
                                                  'Engage and earn more points.',
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      color: Colors.white))
                                            ],
                                          ),
                                          flex: 2,
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              top: 160,
                              right: 0,
                              child: Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(15.0, 0, 0, 0),
                                child: Image.asset(
                                    'assets/newFeature/reward_img.png',
                                    height: 150,
                                    width: 150),
                              ),
                            ),
                          ],
                        ),
                      ))),
            )
          : Container(
              height: 0.0,
            ),
      showCoachMarks
          ? Positioned(
              right: 0.0,
              left: 0.0,
              top: 0.0,
              bottom: 0.0,
              child: Container(
                color: Colors.transparent,
              ),
            )
          : Container(
              width: 0,
              height: 0,
            ),
    ]);
  }

  Future<void> navigateToCoachMarksSlider() async {
    print('Apurva navigateToCoachMarksSlider() 11111111');
    String result = await Navigator.of(Constant.applicationContext).push(
        MaterialPageRoute(
            builder: (BuildContext context) => NewCoachMarkSlider()));
    if (result == "coachMark") {
      try {
        await apiCallingUpdateCoachMarkStatus();
        prefs.setBool(UserPreference.IS_COACHMARK_POPUP, false);
        if (mounted) {
          setState(() {
            showCoachMarks = false;
          });
        }
        syncDoneController.add("coachMarkCompleted");
      } catch (e) {}
    }
  }

  Future<void> checkCoachMarkSliderTOShow() async {
    print(
        'Apurva checkCoachMarkTOShow() isDisplayNewFeaturePopUp:: $isDisplayNewFeaturePopUp');
    print(
        'Apurva checkCoachMarkTOShow() UserPreference.IS_COACHMARK_POPUP:: ${prefs.getBool(UserPreference.IS_COACHMARK_POPUP)}');
    if (prefs.getBool(UserPreference.IS_COACHMARK_POPUP) != null &&
        prefs.getBool(UserPreference.IS_COACHMARK_POPUP)) {
      print('Apurva navigateToCoachMarksSlider()');
      syncDoneController.add("dialogVisible");
      navigateToCoachMarksSlider();
    } else if (!isDisplayNewFeaturePopUp) {
      print(
          'Apurva ekse checkCoachMarkSliderTOShow isDisplayNewFeaturePopUp:: $isDisplayNewFeaturePopUp');
    }
  }

  Future apiCallingUpdateCoachMarkStatus() async {
    print('apiCallingUpdateCoachMarkStatus Update status for::: ');

    try {
      Response response;
      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "featureKey": [
          'selfRecommendation',
        ],
        //  "display": false
      };
      print("DatatCallingmap:-");
      print(
          "apiCallingUpdateCoachMarkStatus map   ENDPOINT_UPDATE_DIALOG_STATUS:-" +
              map.toString());
      response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_UPDATE_DIALOG_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            setState(() {
              showCoachMarks = false;
            });
          }
        }
      }
    } catch (e) {
      print("apiCallingUpdateCoachMarkStatus catch Errorr:-" + e.toString());
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "studentDashboard", context);
    }
  }
}
