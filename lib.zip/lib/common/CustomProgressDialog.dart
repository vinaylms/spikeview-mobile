import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class CustomProgressLoader {
  static showLoader(context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child: Center(
              // Aligns the container to center
              child: Container(
                  // A simplified version of dialog.
                  width: 30.0,
                  height: 30.0,
                  child:  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(Colors.black54),
                    strokeWidth: 2.0,
                  )),
            )));
  }

  static showLoaderNew(context, _controller) {
    showDialog(
        context: context,
        barrierDismissible: false,useSafeArea: false,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child: Stack(children: [
               Positioned(
                  top: 0.0,left: 0.0,bottom: 0.0,right: 0.0,
                  child: Center(
                // Aligns the container to center
                child: Container(
                  color: Colors.black.withOpacity(.4),
                  height: double.infinity,
                  width: double.infinity,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      RotationTransition(
                        turns: Tween(begin: 0.0, end: 1.0).animate(_controller),
                        child:  Image.asset(
                          "assets/ic_loader.png",
                          width: 30.0,
                          height: 30.0,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child:  Text(
                          "Loading Profile ...",
                          style:  TextStyle(
                              decoration: TextDecoration.none,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color:  Color(0xffBDBDBD),
                              fontSize: 12.0,
                              fontWeight: FontWeight.w600),
                        ),
                      )
                    ],
                  ),
                ),
              ))
            ],)));
  }

  static showLoaderWhite(context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child: Center(
              // Aligns the container to center
              child: Container(
                  // A simplified version of dialog.
                  width: 30.0,
                  height: 30.0,
                  child:  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(Colors.white),
                  )),
            )));
  }

  static showLoader2(context) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              //onBack();
            },
            child: Center(
              // Aligns the container to center
              child: Container(
                  // A simplified version of dialog.
                  width: 30.0,
                  height: 30.0,
                  child:  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(Colors.black54),
                    strokeWidth: 2.0,
                  )),
            )));
  }

  static cancelLoader(context) {
    if (context != null)
      Navigator.of(context, rootNavigator: true).pop('dialog');
  }

  static void showDialogBackDialog(context1) {

    showModalBottomSheet(
        context: context1,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to exit?',
            negativeText: 'Cancel',
            positiveText: 'Done',
            isSucessPopup: false,
              positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              Navigator.of(context1).pop(true);
              SystemChannels.platform.invokeMethod(
                  'SystemNavigator.pop');
            },
          );
        });



/*    showDialog(
        barrierDismissible: false,
        context: context1,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context1);
            },
            child:  Scaffold(
                backgroundColor: Colors.black38,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child:  Container(
                            height: 193.0,
                            color: Colors.transparent,
                            child:  Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                       Container(
                                        height: 145.0,
                                        padding:  EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                               Text(
                                                "Are you sure you want to exit?",
                                                textAlign: TextAlign.center,
                                                maxLines: 5,
                                                style:  TextStyle(
                                                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                    height: 1.2,
                                                    fontSize: 16.0,
                                                    fontFamily:
                                                        Constant.TYPE_CUSTOMREGULAR),
                                              ),
                                            ]),
                                      )
                                    ])),
                              ],
                            ))),
                     Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child:  Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                             Container(
                                color: Colors.white,
                                padding:  EdgeInsets.all(10.0),
                                height: 51.0,
                                child:  Row(
                                  children: <Widget>[
                                     Expanded(
                                      child:  InkWell(
                                        child:  Container(
                                            child:  Text(
                                          "Cancel",
                                          textAlign: TextAlign.center,
                                          style:  TextStyle(
                                              color:  ColorValues.GREY_TEXT_COLOR,
                                              fontSize: 16.0,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.of(context1).pop();
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                     Expanded(
                                      child:  InkWell(
                                        child:  Container(
                                            child:  Text(
                                          "Done",
                                          textAlign: TextAlign.center,
                                          style:  TextStyle(
                                              color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 16.0,
                                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.of(context1).pop(true);
                                          SystemChannels.platform.invokeMethod(
                                              'SystemNavigator.pop');
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));*/
  }
}
