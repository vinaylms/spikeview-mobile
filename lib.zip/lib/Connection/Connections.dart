import 'dart:async';

import 'package:flutter/material.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'package:spike_view_project/Connection/ConnectedWidget.dart';

import 'package:spike_view_project/Connection/NewConnectedWidget.dart';

import 'package:spike_view_project/Connection/NewDiscoverWidget.dart';

import 'package:spike_view_project/Connection/NewRequestSentWidget.dart';

import 'package:spike_view_project/Connection/NewReceivedWidget.dart';

import 'package:spike_view_project/Connection/Connection_Requests.dart';
import 'package:spike_view_project/Connection/student/StudentReceivedWidget.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';

import 'package:spike_view_project/constant/Constant.dart';

import 'package:spike_view_project/customViews/CustomViews.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';

import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';

import 'package:spike_view_project/values/ColorValues.dart';

class ConnectionsWidget extends StatefulWidget {
  final GlobalKey<ScaffoldState> _scaffoldKey;

  int notificationCount = 0;
String roleId;
  ConnectionsWidget(this._scaffoldKey, this.notificationCount,this.roleId);

  @override
  State<StatefulWidget> createState() {
    return ConnectionsWidgetState(notificationCount);
  }
}

class ConnectionsWidgetState extends State<ConnectionsWidget>
    with SingleTickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  TabController _controller;

  int _currentIndex = 0;
  bool isStudentFilterSelected = true;
  bool isPartnerFilterSelected = false;
  bool isParentFilterSelected = false;
  bool isGroupFilterSelected = false;

  // final pageController = PageController();

  ConnectionsWidgetState(this.notificationCount);

  int notificationCount = 0;
  String roleId = '';

  void floationOnClick() {
    print("clicked");
  }

  StreamSubscription<dynamic> _streamSubscription;

  SharedPreferences prefs;

  getSharedPrefrence() async {
    prefs = await SharedPreferences.getInstance();
    roleId = prefs.getString(UserPreference.ROLE_ID);
    setState(() {});
  }

  @override
  void initState() {
    getSharedPrefrence();

    _controller = TabController(vsync: this, length: 4);
    _controller.addListener(handleTabSelection);
    _streamSubscription =
        DashBoardState.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        setState(() {});
      }
    });

    _streamSubscription =
        DashBoardStateParent.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        setState(() {});
      }
    });

    DashBoardStatePartner.syncDoneController.stream.listen((value) {
      if (value == "success") {
      } else {
        notificationCount = int.parse(value);
        if (mounted) setState(() {});
      }
    });
    super.initState();
  }

  handleTabSelection() {
    setState(() {
      _currentIndex = _controller.index;
      //pageController.jumpToPage(_currentIndex);
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    Constant.applicationContext = context;
    return Scaffold(
        appBar: CustomViews.getAppBar(
            "", widget._scaffoldKey, context, prefs, notificationCount),
        body: Container(
          color: Colors.white, //ColorValues.GRAY_BG,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.fromLTRB(20.0, 5.0, 15.0, 10.0),
                child: Text(
                  "Connections",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                      fontSize: 28.0,
                      fontWeight: FontWeight.w700,
                      color: ColorValues.HEADING_COLOR_EDUCATION_1,
                      fontFamily: Constant.latoRegular),
                ),
              ),
              roleId == '2'
                  ? Padding(
                      padding: EdgeInsets.fromLTRB(21.0, 5.0, 15.0, 10.0),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  StudentReceivedWidget()));
                        },
                        child: Text(
                          "View student connection",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                              fontSize: 16.0,
                              fontWeight: FontWeight.w600,
                              color: ColorValues.MY_MSG_BORDER_COLOR,
                              fontFamily: Constant.latoRegular),
                        ),
                      ),
                    )
                  : SizedBox(
                      height: 0,
                    ),
              Padding(
                  padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
                  child: Row(
                    children: <Widget>[
                      Flexible(
                        child: InkWell(
                          onTap: () {
                            isStudentFilterSelected = true;
                            isGroupFilterSelected = false;
                            isParentFilterSelected = false;
                            isPartnerFilterSelected = false;
                            setState(() {
                              isStudentFilterSelected;
                              _currentIndex = 0;
                            });
                            //onFilterClick(0);
                          },
                          child: Container(
                            height: 35,
                            decoration: BoxDecoration(
                              color: isStudentFilterSelected
                                  ? AppConstants.colorStyle.orangeShade
                                  : AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: isStudentFilterSelected
                                      ? AppConstants.colorStyle.orangeShade
                                      : AppConstants
                                          .colorStyle.borderGenerateScript,
                                  width: 1),
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(10.0),
                                  bottomLeft: Radius.circular(10.0)),
                            ),
                            child: Center(
                              child: BaseText(
                                textAlign: TextAlign.center,
                                text: "Connected",
                                textColor: isStudentFilterSelected
                                    ? Colors.white
                                    : AppConstants.colorStyle.darkBlue,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                     widget.roleId=='4'?SizedBox():      Flexible(
                        child: InkWell(
                          onTap: () {
                            isStudentFilterSelected = false;
                            isGroupFilterSelected = false;
                            isParentFilterSelected = true;
                            isPartnerFilterSelected = false;
                            setState(() {
                              isParentFilterSelected;
                              _currentIndex = 1;
                            });
                            //  onFilterClick(1);
                          },
                          child: Container(
                            height: 35,
                            decoration: BoxDecoration(
                              color: isParentFilterSelected
                                  ? AppConstants.colorStyle.orangeShade
                                  : AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: isParentFilterSelected
                                      ? AppConstants.colorStyle.orangeShade
                                      : AppConstants
                                          .colorStyle.borderGenerateScript,
                                  width: 1),
                              borderRadius: BorderRadius.only(
                                  topRight: Radius.circular(0.0),
                                  bottomRight: Radius.circular(0.0),
                                  topLeft: Radius.circular(0.0),
                                  bottomLeft: Radius.circular(0.0)),
                            ),
                            child: Center(
                              child: BaseText(
                                textAlign: TextAlign.center,
                                text: "Sent",
                                textColor: isParentFilterSelected
                                    ? Colors.white
                                    : AppConstants.colorStyle.darkBlue,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: InkWell(
                          onTap: () {
                            isStudentFilterSelected = false;
                            isGroupFilterSelected = true;
                            isParentFilterSelected = false;
                            isPartnerFilterSelected = false;
                            setState(() {
                              isGroupFilterSelected;
                              _currentIndex = 2;
                            });
                            //  onFilterClick(2);
                          },
                          child: Container(
                            height: 35,
                            decoration: BoxDecoration(
                              color: isGroupFilterSelected
                                  ? AppConstants.colorStyle.orangeShade
                                  : AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: isGroupFilterSelected
                                      ? AppConstants.colorStyle.orangeShade
                                      : AppConstants
                                          .colorStyle.borderGenerateScript,
                                  width: 1),
                              borderRadius: BorderRadius.only(
                                  topRight: Radius.circular(0.0),
                                  bottomRight: Radius.circular(0.0),
                                  topLeft: Radius.circular(0.0),
                                  bottomLeft: Radius.circular(0.0)),
                            ),
                            child: Center(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  BaseText(
                                    textAlign: TextAlign.center,
                                    text: "Received",
                                    textColor: isGroupFilterSelected
                                        ? Colors.white
                                        : AppConstants.colorStyle.darkBlue,
                                    fontFamily:
                                        AppConstants.stringConstant.latoMedium,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                  ),
                                  //                PaddingWrap.paddingfromLTRB(
                                  //         0.0,
                                  //         0.0,
                                  //         0.0,
                                  //         15.0, Image.asset(
                                  //     'assets/newDesignIcon/connections/small_red_dot.png',
                                  //    height: 15.0,
                                  // width: 15.0,
                                  //   )),
                                ],
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: InkWell(
                          onTap: () {
                            isStudentFilterSelected = false;
                            isGroupFilterSelected = false;
                            isParentFilterSelected = false;
                            isPartnerFilterSelected = true;
                            setState(() {
                              _currentIndex = 3;
                            });
                            // onFilterClick(3);
                          },
                          child: Container(
                            height: 35,
                            decoration: BoxDecoration(
                              color: isPartnerFilterSelected
                                  ? AppConstants.colorStyle.orangeShade
                                  : AppConstants.colorStyle.tabBg,
                              border: Border.all(
                                  color: isPartnerFilterSelected
                                      ? AppConstants.colorStyle.orangeShade
                                      : AppConstants
                                          .colorStyle.borderGenerateScript,
                                  width: 1),
                              borderRadius: BorderRadius.only(
                                bottomRight: Radius.circular(10.0),
                                topRight: Radius.circular(10.0),
                              ),
                            ),
                            child: Center(
                              child: BaseText(
                                textAlign: TextAlign.center,
                                text: "Discover",
                                textColor: isPartnerFilterSelected
                                    ? Colors.white
                                    : AppConstants.colorStyle.darkBlue,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                    ],
                  )),
              Expanded(
                child: _currentIndex == 0
                    ? NewConnectedWidget() //ConnectionRequests()//
                    : _currentIndex == 1
                        ? NewRequestWidget()
                        : _currentIndex == 2
                            ? NewReceivedWidget()
                            : NewDiscoverWidget(), //,NewDiscoverWidget(),

                flex: 1,
              )
            ],
          ),
        ));

    // DefaultTabController(
    //   length: 4,
    //   child:  );
  }

  final List<Widget> pages = [new ConnectionRequests(), ConnectedWidget()];

  @override
  // TODO: implement wantKeepAlive

  bool get wantKeepAlive => true;
}
