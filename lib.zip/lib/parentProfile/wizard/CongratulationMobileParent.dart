import 'dart:async';

import 'package:adhara_socket_io/manager.dart';
import 'package:flutter/material.dart';

import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/new_onboarding/calendar_list.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/parentProfile/wizard/newpages/AddEducationWidgetParentChild.dart';
import 'package:spike_view_project/parentProfile/wizard/CongratulationStepsParent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/services.dart';

import 'package:spike_view_project/parentProfile/wizard/ProfilePic_Widget.dart';

import 'newpages/onboarding_education_added_list_student.dart';
class CongratulationMobileParent extends StatefulWidget {
  String isActive = "false", pageName;
  StudentDataModel studModel;
  String sasToken;
  int stage;
  CongratulationMobileParent(this.studModel);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return  CongratulationMobileParentState();
  }
}

class CongratulationMobileParentState extends State<CongratulationMobileParent> {
  List<NotificationModel> dataList =  List();
  static StreamController syncDoneController = StreamController.broadcast();
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool showFirst = true;


  getSharedPreferences() async {

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //getSharedPreferences();
    print("==================== INIT STATE");
  }



  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return  WillPopScope(
        onWillPop: () {

          print("not perform");
        },

        child:  Scaffold(
            backgroundColor: Colors.white,
            appBar:  AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              brightness: Brightness.light,

              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 0,
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        //Navigator.pop(context);
                      },
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child:  Image.asset(
                        "assets/newDesignIcon/blue_spike_logo.png",
                        width: 114.0,
                        height: 29.0,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 0,
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),),
                  ),
                ],
              ),

              backgroundColor: Colors.white,
              elevation: 0.0,
            ),
            body: Container(
              //color: Color(0xffDADADA),
              child: Stack(
                children: <Widget>[
                  Positioned(

                    top: 0,
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Column(

                      children: <Widget>[
                        //CustomViews.getSepratorLine(),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 44.0, vertical: 0.0),
                          child:  Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [

                              Padding(
                                padding: const EdgeInsets.only(top: 0.0, bottom: 22.0),
                                child:  Center(
                                  child:  Image.asset(
                                    "assets/progress_indecator/congratulations_msg_child.png",
                                    width: 285.0,
                                    height: 79.0,
                                  ),
                                ),
                              ),
                              showFirst ? Padding(
                                padding: const EdgeInsets.only(top: 0.0, bottom: 0.0),
                                child:  GestureDetector(
                                  onVerticalDragUpdate: (details) {
                                    int sensitivity = 8;
                                    if (details.delta.dy > sensitivity) {
                                      // Down Swipe
                                      print('Apurva GestureDetector Down Swipe');
                                    } else if(details.delta.dy < -sensitivity){
                                      // Up Swipe
                                      print('Apurva GestureDetector Up Swipe');
                                      //goToNextState();
                                      changeScreen();
                                    }
                                  },
                                  child: Center(
                                  child:  Image.asset(
                                    "assets/progress_indecator/mobile_cong.png",
                                    //width: MediaQuery.of(context).size.width - 88,
                                    height: MediaQuery.of(context).size.height - statusBarHeight - AppBar().preferredSize.height - 0.0 -0 - 22 -79,
                                     fit: BoxFit.fitHeight,
                                  ),
                                ), ),
                              ):GestureDetector(
                                onVerticalDragUpdate: (details) {
                                  int sensitivity = 8;
                                  if (details.delta.dy > sensitivity) {
                                    // Down Swipe
                                    print('Apurva GestureDetector Down Swipe');
                                    //goToUpperScreen();
                                    changeScreen();
                                  } else if(details.delta.dy < -sensitivity){
                                    // Up Swipe
                                    print('Apurva GestureDetector Up Swipe');

                                  }
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 0.0, bottom: 0.0),
                                  child:  Center(
                                    child:  Image.asset(
                                      "assets/progress_indecator/all_steps.png",
                                      width: 241,//MediaQuery.of(context).size.width - 88,
                                      height: 400,//MediaQuery.of(context).size.height - statusBarHeight - AppBar().preferredSize.height - 200.0 -10 - 27 -61,
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  showFirst ? Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: GestureDetector(
                      onVerticalDragUpdate: (details) {
                        int sensitivity = 8;
                        if (details.delta.dy > sensitivity) {
                          // Down Swipe
                          print('Apurva GestureDetector Down Swipe');
                        } else if(details.delta.dy < -sensitivity){
                          // Up Swipe
                          print('Apurva GestureDetector Up Swipe');
                          //goToNextState();
                          changeScreen();
                        }
                      },
                      child: Center(
                        child:  Image.asset(
                          "assets/progress_indecator/semi_c_arrow.png",
                          width: 100.0,
                          height: 50.0,
                        ),
                      ),
                    ),): Positioned(
                    bottom: 40,
                    left: 0,
                    right: 0,
                    child: InkWell(
                      onTap: (){
                        goToNextState();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Center(
                            child:  Image.asset(
                            "assets/progress_indecator/lets_start.png",
                            //width: 150.0,
                              height: 44.0,
                            fit: BoxFit.fitHeight,
                          ),
                            /*Text(
                              "Let’s get started!",
                              textAlign: TextAlign.start,
                              style:  TextStyle(
                                  color:  ColorValues.BLUE_COLOR,
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
                            )*/
                        ),
                      ),
                    ),)
                ],
              ),
            )));
  }

  Future<void> goToNextStateOld() async {
    String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         CongratulationStepsParent(widget.studModel)));
  }
  Future<void> goToNextState() async {
    DateTime date = DateTime.fromMillisecondsSinceEpoch(
        int.tryParse(widget.studModel.dob));
    int endYar = DateTime.now().year + 10;
    if(widget.studModel.isEducation=='false') {
      String result = await Navigator.of(context).push(
          new MaterialPageRoute(
              builder: (BuildContext context) =>
                  AddEducationWidgetParentChild(
                    studModel: widget.studModel,
                    startYear: date.year,
                    endYear: endYar,
                    userId: widget.studModel.userId,
                  )));
    }else {
      String result = await Navigator.of(context).push(
          new MaterialPageRoute(
              builder: (BuildContext context) =>
                  EducationAddedWeightParentChild(
                    studModel: widget.studModel, screenName: "onBoarding",    userId: widget.studModel.userId,)));
    }
/*    String result = await Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         ProfilePic_Widget(widget.studModel)));*/
  }

  void changeScreen() {
    setState(() {
      showFirst = !showFirst;
    });
  }
}
