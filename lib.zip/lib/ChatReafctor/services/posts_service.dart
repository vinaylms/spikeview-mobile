import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:injectable/injectable.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ChatReafctor/model/ChatModel.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/constant/Constant.dart';

@lazySingleton
class PostsService {

  SharedPreferences prefs;
  String userIdPref, roleId;
  List<Friends> _posts=new List();

  List<Friends> get posts => _posts;

  bool get hasPosts => _posts != null;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    print("ChatViewModel++++++++getSharedPreferences");
  }

  Future<List<Friends>> getPosts() async {
    try {
      print('chatApi+++++++++==');
      ChatModel.previousDateStamp="";
      await getSharedPreferences();
      print('chatApi+++++++++=='+Constant.ENDPOINT_NEW_CHAT_LIST + userIdPref + "&roleId=" + roleId);
      Response response = await  ApiCalling2().apiCall(
          null,   Constant.ENDPOINT_NEW_CHAT_LIST + userIdPref + "&roleId=" + roleId,

          "get");
      _posts.clear();
      print("chatApiResponse++++"+response.toString());
      FrienndListModel _mFrienndListModel= await FrienndListModel.fromJson(response.data);
      _posts.addAll(_mFrienndListModel.friendsList);
    } catch (e) {
      print("Error+++" + e.toString());
    }
    return _posts;
  }
}
