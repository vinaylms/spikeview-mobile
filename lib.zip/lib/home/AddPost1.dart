import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:video_compress/video_compress.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:path/path.dart' as path;
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class AddPost extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  String groupId;
  GroupDetailModel groupDetailModel;

  AddPost(this.profileInfoModal, this.groupId, this.groupDetailModel);

  @override
  AddPostState createState() {
    return  AddPostState();
  }
}

class AddPostState extends State<AddPost> {
  SharedPreferences prefs;
  String userIdPref, roleId, token, userProfilePath;
  final _formKey = GlobalKey<FormState>();
  String isType = "AllConnections";
  List<AssestForPost> assestList =  List();
  VoidCallback listener;
  File videoPath;
  String strVideo;
  TextEditingController edtController;

  String sasToken, containerName, strPrefixPathforFeed;
  String strFirstName, strLastName, strEmail;
  List<dynamic> images;

  Future<File> videoFile;
  List<String> azureImageUploadList =  List();
  VideoPlayerController _controller;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<TagsPost> selectedUerTagLIst =  List();

  List<TagModel> selectedUerTagLIst1 =  List();
  List<TagsPost> selectedtScopeList =  List();
  File imagePath;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    setState(() {
      userProfilePath;
    });
    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
    callApiForSaas();
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePath = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 1.6,
      ratioY: 0.9,
    );
  }

  @override
  void initState() {
    getSharedPreferences();
    edtController =  TextEditingController(text: '');
    // TODO: implement initState
    listener = () {
      setState(() {});
    };

    super.initState();
  }

  @override
  void deactivate() {
    if (_controller != null) {
      _controller.setVolume(0.0);
      _controller.removeListener(listener);
    }
    super.deactivate();
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await  ApiCalling().apiCall2(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

 // static final _flutterVideoCompress = FlutterVideoCompress();

  Future<String> compressonVideoFile(File file, String targetPath) async {
    File uploadingFile;

    final MediaInfo info =   await VideoCompress.compressVideo(
      file.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
    );

    debugPrint(info.toJson().toString());
//uploadingFile =  File(info.path);

    return info.path;
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath, isImage) async {
    if (!isImage) {
      File file =  File(imagePath);
      imagePath = await compressonVideoFile(file, imagePath);
    }
    try {
      if (sasToken != "" && containerName != "") {
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });

        print("image_path" + result);
        return result;
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  //-------------------------------------Api Calling for feed--------------------------

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map;

        print("edtControllr shubh " + edtController.text);
        if (edtController.text != "" ||
            assestList.length > 0 ||
            videoPath != null) {
          if (assestList.length > 0) {
            map = {
              "post": {
                "text": edtController.text,
                "images": azureImageUploadList.map((item) => item).toList(),
                "media": ""
              },
              "postedBy": int.parse(userIdPref),
              "dateTime":  DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId)
            };
          } else if (videoPath != null) {
            map = {
              "post": {
                "text": edtController.text,
                "images": [],
                "media": strPrefixPathforFeed + strVideo
              },
              "postedBy": int.parse(userIdPref),
              "dateTime":  DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": false,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId)
            };
          } else {
            map = {
              "post": {"text": edtController.text, "images": [], "media": ""},
              "postedBy": int.parse(userIdPref),
              "dateTime":  DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": false,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime":  DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId)
            };
          }
          print("map:-" + map.toString());
          Response response = await  ApiCalling()
              .apiCallPostWithMapData(context, Constant.ENDPOINT_ADD_FEED, map);
          CustomProgressLoader.cancelLoader(context);
          print("response:-" + response.toString());
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                //ToastWrap.showToast(msg);

                Navigator.pop(context, "push");
              }
            }
          }
        } else {
          ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_controller != null) _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    void onTapTagBtn() async {
      if (widget.groupId == "") {
        List<TagModel> result = await Navigator.of(context).push(
             MaterialPageRoute(
                builder: (BuildContext context) =>
                     AddTagWidget("Tag Connections", selectedUerTagLIst1)));

        if (result != null) {
          selectedUerTagLIst1.clear();
          selectedUerTagLIst.clear();
          selectedUerTagLIst1 = result;
        }

        // Create List for API Calling

        setState(() {
          for (int i = 0; i < selectedUerTagLIst1.length; i++) {
            selectedUerTagLIst.add(new TagsPost(
                selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
          }
        });
      } else {
        List<TagModel> result = await Navigator.of(context).push(
             MaterialPageRoute(
                builder: (BuildContext context) =>
                     AddTagGroupWidget("Tagging", widget.groupId, selectedUerTagLIst1)));

        if (result != null) {
          selectedUerTagLIst1.clear();
          selectedUerTagLIst.clear();
          selectedUerTagLIst1 = result;
        }

        // Create List for API Calling

        setState(() {
          for (int i = 0; i < selectedUerTagLIst1.length; i++) {
            selectedUerTagLIst.add(new TagsPost(
                selectedUerTagLIst1[i].userId, selectedUerTagLIst1[i].roleId));
          }
        });
      }
    }

    void onTapTagSelectedConnection() async {
      List<TagsPost> result = await Navigator.of(context).push(
           MaterialPageRoute(
              builder: (BuildContext context) =>  AddMyConnectionSharePost(
                  "Select Connections", selectedtScopeList)));

      if (result != null) {
        selectedtScopeList = result;
      }
    }

    onTapPostButton() async {
      if (assestList.length > 0 ||
          edtController.text.trim() != "" ||
          videoPath != null) {
        if (assestList.length > 0) {
          for (int i = 0; i < assestList.length; i++) {
            String azureUploadPath = await uploadImgOnAzure(
                assestList[i].imagePath, strPrefixPathforFeed, true);
            azureImageUploadList.add(strPrefixPathforFeed + azureUploadPath);
          }

          String s = "ss";
        } else if (videoPath != null) {
          strVideo = await uploadImgOnAzure(
              videoPath
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim(),
              strPrefixPathforFeed,
              false);

          String s = "";
        }

        apiCalling();
      } else {
        ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
      }
    }

    getVideo() async {
      try {
        if (_controller != null && (videoPath != null)) {
          _controller.setVolume(0.0);
          _controller.removeListener(listener);
          _controller.dispose();
        }

        videoPath = null;
        setState(() {
          videoPath;
        });

        String getFileExtension(File file) {
          return path.extension(file.path);
        }

        await ImagePicker.pickVideo(source: ImageSource.gallery)
            .then((File file) {
          if (file != null &&
              getFileExtension(file) != null &&
              getFileExtension(file).length > 0) {
            setState(() {
              _controller = VideoPlayerController.file(file)
                ..addListener(listener)
                ..setVolume(1.0)
                ..initialize()
                ..setLooping(false);
              videoPath = file;
            });
          } else {
            ToastWrap.showToast(
                MessageConstant.VIDEO_SOURCE_INCORRECT_ERROR, context);
          }
        });
      } catch (e) {
        print("error+" + e.toString());
      }
    }

    getImage(type) async {
      if (assestList.length < 8) {
        int numberOfItems = 8 - assestList.length;
        // if (numberOfItems == 1) {

        if (type == ImageSource.gallery) {
          imagePath = await UploadMedia(context).pickImageFromGallery();
         // imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);


          if (imagePath != null) {
            String strPath = imagePath.toString().substring(
                imagePath.toString().lastIndexOf("/") + 1,
                imagePath.toString().length);
            print("imagepath shubh" + strPath);
            if (strPath.toString().contains(".") &&
                (!strPath.toString().contains(".gif"))) {
              await _cropImage(imagePath);
              if (imagePath != null) {
                assestList.add(new AssestForPost(
                    imagePath
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    "image",
                    "",
                    false));
                setState(() {
                  assestList;
                });
                // }
              }
            } else {
              ToastWrap.showToast(
                  MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
            }
          }
        } else if (type == ImageSource.camera) {
          imagePath = await ImagePicker.pickImage(source: ImageSource.camera);

          if (imagePath != null) {
            String strPath = imagePath.toString().substring(
                imagePath.toString().lastIndexOf("/") + 1,
                imagePath.toString().length);
            print("imagepath shubh" + strPath);
            if (strPath.toString().contains(".") &&
                (!strPath.toString().contains(".gif"))) {
              await _cropImage(imagePath);
              if (imagePath != null) {
                assestList.add(new AssestForPost(
                    imagePath
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    "image",
                    "",
                    false));
                setState(() {
                  FocusScope.of(context).requestFocus(FocusNode());
                  assestList;
                });
                // }
              }
            } else {
              ToastWrap.showToast(
                  MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.MAXIMUM_8_IMAGE_UPLOADED_VAL, context);
      }
    }

    void _settingModalBottomSheet(context) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 33.0,
                              child:  Container(
                                  height: 222.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              padding: EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  isType ==
                                                                          "Private"
                                                                      ?  Image
                                                                          .asset(
                                                                          "assets/profile/post/radio_selected.png",
                                                                          width:
                                                                              0.0,
                                                                          height:
                                                                              0.0,
                                                                        )
                                                                      :  Image
                                                                          .asset(
                                                                          "assets/profile/post/radio_inactive.png",
                                                                          width:
                                                                              0.0,
                                                                          height:
                                                                              0.0,
                                                                        )),
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  5.0,
                                                                  10.0,
                                                                  5.0,
                                                                  10.0,
                                                                   Image
                                                                      .asset(
                                                                    "assets/profile/post/private.png",
                                                                    width: 0.0,
                                                                    height: 0.0,
                                                                  )),
                                                          PaddingWrap.paddingfromLTRB(
                                                              5.0,
                                                              13.0,
                                                              5.0,
                                                              13.0,
                                                              TextViewWrap.textView(
                                                                  "Make it Private",
                                                                  TextAlign
                                                                      .center,
                                                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontWeight
                                                                      .normal))
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        selectedUerTagLIst1
                                                            .clear();
                                                        selectedUerTagLIst
                                                            .clear();
                                                        isType = "Private";
                                                        setState(() {
                                                          isType;
                                                          selectedUerTagLIst1;
                                                          selectedUerTagLIst;
                                                        });
                                                      },
                                                    ),
                                                    CustomViews
                                                        .getSepratorLine(),
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  isType ==
                                                                          "SelectedConnections"
                                                                      ?  Image
                                                                          .asset(
                                                                          "assets/profile/post/radio_selected.png",
                                                                          width:
                                                                              0.0,
                                                                          height:
                                                                              0.0,
                                                                        )
                                                                      :  Image
                                                                          .asset(
                                                                          "assets/profile/post/radio_inactive.png",
                                                                          width:
                                                                              0.0,
                                                                          height:
                                                                              0.0,
                                                                        )),
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  5.0,
                                                                  10.0,
                                                                  5.0,
                                                                  10.0,
                                                                   Image
                                                                      .asset(
                                                                    "assets/profile/post/selected_connections.png",
                                                                    width: 0.0,
                                                                    height: 0.0,
                                                                  )),
                                                          PaddingWrap.paddingfromLTRB(
                                                              5.0,
                                                              13.0,
                                                              5.0,
                                                              13.0,
                                                              TextViewWrap.textView(
                                                                  "Selected Connections",
                                                                  TextAlign
                                                                      .center,
                                                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontWeight
                                                                      .normal))
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                        onTapTagSelectedConnection();
                                                        isType =
                                                            "SelectedConnections";
                                                        setState(() {
                                                          isType;
                                                        });
                                                      },
                                                    ),
                                                    CustomViews
                                                        .getSepratorLine(),
                                                     InkWell(
                                                      child:  Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  isType ==
                                                                          "AllConnections"
                                                                      ?  Image
                                                                          .asset(
                                                                          "assets/profile/post/radio_selected.png",
                                                                          width:
                                                                              0.0,
                                                                          height:
                                                                              0.0,
                                                                        )
                                                                      :  Image
                                                                          .asset(
                                                                          "assets/profile/post/radio_inactive.png",
                                                                          width:
                                                                              0.0,
                                                                          height:
                                                                              0.0,
                                                                        )),
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  5.0,
                                                                  10.0,
                                                                  5.0,
                                                                  10.0,
                                                                   Image
                                                                      .asset(
                                                                    "assets/profile/post/all_connections.png",
                                                                    width: 0.0,
                                                                    height: 0.0,
                                                                  )),
                                                          PaddingWrap.paddingfromLTRB(
                                                              5.0,
                                                              15.0,
                                                              5.0,
                                                              10.0,
                                                              TextViewWrap.textView(
                                                                  "Connections",
                                                                  TextAlign
                                                                      .center,
                                                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                  16.0,
                                                                  FontWeight
                                                                      .normal))
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);

                                                        isType =
                                                            "AllConnections";
                                                        setState(() {
                                                          isType;
                                                        });
                                                      },
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:
                                                        Constant.customRegular),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    _buildChoiceList() {
      List<Widget> choices = List();
      selectedUerTagLIst1.forEach((item) {
        if (item.isSelected) {
          choices.add(PaddingWrap.paddingAll(
              5.0,
              Container(
                decoration:  BoxDecoration(
                    border:  Border.all(
                        width: 1.0,
                        color:  ColorValues.GREY_TEXT_COLOR)),
                padding: const EdgeInsets.all(3.0),
                child: Wrap(
                  children: <Widget>[
                     Text(
                      item.firstName + " " + item.lastName,
                      overflow: TextOverflow.ellipsis,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                     InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          5.0,
                          3.0,
                          0.0,
                          0.0,
                           Icon(
                            Icons.clear,
                            color: Colors.black,
                            size: 17.0,
                          )),
                      onTap: () {
                        setState(() {
                          selectedUerTagLIst1.remove(item);
                          selectedUerTagLIst.remove(item);
                        });
                      },
                    )
                  ],
                ), /*  Row(
              children: <Widget>[
                 Text(
                    item.firstName,
                    overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),

              */ /*   Expanded(
                  child:  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                         Icon(
                          Icons.cancel,
                          color: Colors.transparent,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        item.isSelected = false;
                      });
                    },
                  ),
                  flex: 0,
                ),*/ /*
              ],
            ) */ /*ChoiceChip(
            selectedColor: Colors.transparent,

            label: Wrap(
              children: <Widget>[
                 Row(children: <Widget>[
                   Flexible(child:     Text(
                   item.label,overflow: TextOverflow.ellipsis,
                    style:  TextStyle(
                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 14.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),flex: 1,)
                  ,
           Expanded(child:   PaddingWrap.paddingfromLTRB(
                      5.0,
                      3.0,
                      0.0,
                      0.0,
                       Icon(
                        Icons.cancel,
                        color:  ColorValues.BG_CIRCLE_COLOR,
                        size: 17.0,
                      )),flex: 0,),
                ],)

              ],
            ),
            selected: true,
            onSelected: (selected) {
              setState(() {
                skeelSelectedList.remove(item);
                filterStatus[item.index] = false;
              });
              filterData = "";
              appliedFilter = "";
              skeelSelectedList.clear();
              filterStatus.forEach(iterateFilters);
            },
          ),*/
              )));
        }
      });
      return choices;
    }

    Padding getTextView(String text) {
      return  Padding(
          padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
          child:  Align(
              alignment: Alignment.centerLeft,
              child:  Text(
                text,
                style: TextStyle(
                    fontSize: 12.0,
                    fontFamily: Constant.customRegular,
                    color:  ColorValues.GREY_TEXT_COLOR),
                textAlign: TextAlign.left,
              )));
    }

    Padding gridSelectedImages() {
      return assestList != null && assestList.length > 0
          ? PaddingWrap.paddingfromLTRB(
              15.0,
              15.0,
              15.0,
              0.0,
               Container(
                  height: 200.0,
                  child:  GridView.count(
                    primary: true,
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.all(0.0),
                    crossAxisCount: 1,
                    childAspectRatio: assestList.length < 2 ? 0.60 : 0.85,
                    mainAxisSpacing: 15.0,
                    crossAxisSpacing: 2.0,
                    children:  List.generate(assestList.length, (int index) {
                      return  Stack(
                        children: <Widget>[
                           InkWell(
                            child:  Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                 Stack(
                                  children: <Widget>[
                                     Image.file(
                                       File(assestList[index].imagePath),
                                      fit: BoxFit.fitWidth,
                                      height: 180.0,
                                      width: MediaQuery.of(context).size.width -
                                          30,
                                    ),
                                     Container(
                                      height: 180.0,
                                      width: MediaQuery.of(context).size.width -
                                          30,
                                      color: Colors.black54.withOpacity(.4),
                                    ),
                                     Center(
                                        child:  Container(
                                      height: 180.0,
                                      child:  Align(
                                          alignment: Alignment.center,
                                          child:  InkWell(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      0.0,
                                                      0.0,
                                                      assestList.length == 1
                                                          ? 20.0
                                                          : 0.0,
                                                      0.0,
                                                       Image.asset(
                                                        "assets/profile/post/add_post_delete.png",
                                                        width: 50.0,
                                                        height: 50.0,
                                                      )),
                                              onTap: () {
                                                assestList.removeAt(index);
                                                setState(() {
                                                  assestList;
                                                });
                                              })),
                                    )),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              0.0,
              5.0,
              0.0,
               Container(
                height: 0.0,
              ));
    }

    Widget _previewVideo(VideoPlayerController controller) {
      if (controller == null) {
        return  Text(
          'You have not yet picked a video',
          textAlign: TextAlign.center,
        );
      } else if (controller.value.initialized) {
        return PaddingWrap.paddingfromLTRB(
            15.0,
            15.0,
            15.0,
            25.0,
             Container(
              height: 200.0,
              child:  Stack(
                children: <Widget>[
                   Container(
                      height: 200.0,
                      child:  Align(
                        alignment: Alignment.center,
                        child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: AspectRatio(
                              aspectRatio: controller.value.aspectRatio,
                              child: VideoPlayer(_controller),
                            )),
                      )),
                   Container(
                    color:  Color(0XFFC0C0C0).withOpacity(.4),
                  ),
                   Container(
                      height: 200.0,
                      child:  Align(
                          alignment: Alignment.center,
                          child:  InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  7.0,
                                  0.0,
                                   Image.asset(
                                    "assets/newDesignIcon/achievment/remove.png",
                                    width: 35.0,
                                    height: 35.0,
                                  )),
                              onTap: () {
                                videoPath = null;

                                if (_controller != null) {
                                  _controller.setVolume(0.0);
                                  _controller.removeListener(listener);
                                }
                                setState(() {
                                  _controller;
                                  videoPath;
                                });
                              })))
                ],
              ),
            ));
      } else {
        return  Text(
          'Error Loading Video',
          textAlign: TextAlign.center,
        );
      }
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
            appBar:  AppBar(
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  )
                ],
              ),
              actions: <Widget>[
                 InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      0.0,
                      5.0,
                      13.0,
                      0.0,
                       Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           Text(
                            "Post",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                          )
                        ],
                      )),
                  onTap: () {
                    if (assestList.length > 0 ||
                        edtController.text.trim() != "" ||
                        videoPath != null) {
                      CustomProgressLoader.showLoader(context);
                      Timer _timer =
                           Timer(const Duration(milliseconds: 400), () {
                        onTapPostButton();
                      });
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.WRITE_SOMETHING_ERROR, context);
                    }
                  },
                )
              ],
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Create",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              backgroundColor: Colors.white,
            ),
            body:  Column(
              children: <Widget>[
                CustomViews.getSepratorLine(),
                 Expanded(
                  child:  ListView(
                    children: <Widget>[
                       Container(
                        child:  Column(
                          children: <Widget>[
                             Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                 Expanded(
                                  child:  Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          14.0, 15.0, 10.0, 0.0),
                                      child:  Container(
                                        height: 60.0,
                                        width: 60.0,
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(100),
                                          child: FadeInImage(
                                            fit: BoxFit.cover,
                                            placeholder: AssetImage(
                                              'assets/profile/user_on_user.png',
                                            ),
                                            image: NetworkImage(
                                                Constant.IMAGE_PATH_SMALL +
                                                    ParseJson.getSmallImage(
                                                        userProfilePath)),
                                          ),
                                        ),
                                      )),
                                  flex: 0,
                                ),
                                 Expanded(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      35.0,
                                      13.0,
                                      0.0,
                                       Text(
                                        widget.profileInfoModal != null
                                            ? widget.profileInfoModal
                                                            .lastName ==
                                                        null ||
                                                    widget.profileInfoModal
                                                            .lastName ==
                                                        "null" ||
                                                    widget.profileInfoModal
                                                            .lastName ==
                                                        ""
                                                ? widget
                                                    .profileInfoModal.firstName
                                                : widget.profileInfoModal
                                                        .firstName +
                                                    " " +
                                                    widget.profileInfoModal
                                                        .lastName
                                            : "",
                                        overflow: TextOverflow.ellipsis,
                                        style:  TextStyle(
                                            fontFamily: Constant.customRegular,
                                            fontWeight: FontWeight.bold,
                                            color:  ColorValues.HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0),
                                      )),
                                  flex: 1,
                                )
                              ],
                            ), // User Image and Name
                             Container(
                                child:  Card(
                                    elevation: 0.0,
                                    color: Colors.transparent,
                                    child:  Column(
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            0.0,
                                            5.0,
                                            0.0,
                                             Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[
                                                gridSelectedImages(),
                                                // Image GRID
                                                assestList.length > 1
                                                    ? PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        getTextView("Uploads(" +
                                                            assestList.length
                                                                .toString() +
                                                            ")"))
                                                    :  Container(
                                                        height: 0.0,
                                                      ),

                                                videoPath != null
                                                    ? _previewVideo(_controller)
                                                    : Container(
                                                        height: 1.0,
                                                      ),

                                                PaddingWrap.paddingfromLTRB(
                                                    3.0,
                                                    0.0,
                                                    0.0,
                                                    0.0,
                                                     TextField(
                                                      cursorColor:
                                                          Constant.CURSOR_COLOR,
                                                      style: TextStyle(
                                                          color: ColorValues.HEADING_COLOR_EDUCATION,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .customRegular,
                                                          fontWeight: FontWeight
                                                              .normal),
                                                      maxLines: 5,
                                                      textCapitalization:
                                                          TextCapitalization
                                                              .sentences,
                                                      maxLength: TextLength.POST_MSG_MAX_LENGTH,
                                                      controller: edtController,
                                                      autofocus: true,
                                                      keyboardType:
                                                          TextInputType.text,
                                                      textAlign:
                                                          TextAlign.start,
                                                      decoration:
                                                           InputDecoration(
                                                        border:
                                                            InputBorder.none,
                                                        filled: true,
                                                        hintText:
                                                            "Share your thoughts",
                                                        hintStyle:
                                                             TextStyle(
                                                                color: ColorValues.hintColor),
                                                        fillColor:
                                                            Colors.transparent,
                                                      ),
                                                    )),

                                                selectedUerTagLIst1.length > 0
                                                    ? PaddingWrap.paddingfromLTRB(
                                                        10.0,
                                                        0.0,
                                                        0.0,
                                                        0.0,
                                                        getTextView("Tags(" +
                                                            selectedUerTagLIst1
                                                                .length
                                                                .toString() +
                                                            ")"))
                                                    :  Container(
                                                        height: 0.0,
                                                      ),
                                                 Container(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child:  Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              10.0,
                                                              10.0,
                                                              0.0,
                                                              0.0),
                                                      child: Wrap(
                                                        children:
                                                            _buildChoiceList(),
                                                      ),
                                                    )),
                                              ],
                                            )),
                                      ],
                                    ))), // Selected Image and Text View
                          ],
                        ),
                      ),
                    ],
                  ),
                  flex: 1,
                ),
                 Container(
                  height: 60.0,
                  color: Colors.white,
                  child: Column(
                    children: <Widget>[
                       Container(
                        height: 1.0,
                        color:  ColorValues.LIGHT_GREY_TEXT_COLOR,
                      ),
                       Row(
                        children: <Widget>[
                           Expanded(
                            child:  Row(
                              children: <Widget>[
                                 InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      14.0,
                                      15.0,
                                      10.0,
                                      10.0,
                                       Image.asset(
                                        "assets/profile/post/camera.png",
                                        fit: BoxFit.cover,
                                        color: ColorValues.GREY__COLOR,
                                        height: 30.0,
                                        width: 30.0,
                                      )),
                                  onTap: () {
                                    videoPath == null
                                        ? getImage(ImageSource.camera)
                                        : null;
                                  },
                                ),
                                assestList == null || assestList.length == 0
                                    ?  InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            10.0,
                                            10.0,
                                            5.0,
                                             Image.asset(
                                              "assets/profile/post/video.png",
                                              fit: BoxFit.cover,
                                              color: ColorValues.GREY__COLOR,
                                              height: 35.0,
                                              width: 35.0,
                                            )),
                                        onTap: () {
                                          assestList == null ||
                                                  assestList.length == 0
                                              ? getVideo()
                                              : null;
                                        },
                                      )
                                    :  Container(
                                        height: 0.0,
                                      ),
                                isType == "Private"
                                    ?  Container(
                                        height: 0.0,
                                      )
                                    :  InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            15.0,
                                            10.0,
                                            10.0,
                                             Image.asset(
                                              "assets/profile/post/tagging.png",
                                              fit: BoxFit.cover,
                                              color: ColorValues.GREY__COLOR,
                                              height: 26.0,
                                              width: 26.0,
                                            )),
                                        onTap: () {
                                          onTapTagBtn();
                                        },
                                      ),
                                videoPath == null
                                    ?  InkWell(
                                        child: PaddingWrap.paddingfromLTRB(
                                            10.0,
                                            15.0,
                                            10.0,
                                            10.0,
                                             Image.asset(
                                              "assets/profile/post/gallery.png",
                                              fit: BoxFit.cover,
                                              color: ColorValues.GREY__COLOR,
                                              height: 30.0,
                                              width: 30.0,
                                            )),
                                        onTap: () {
                                          videoPath == null
                                              ? getImage(ImageSource.gallery)
                                              : null;
                                        },
                                      )
                                    :  Container(
                                        height: 0.0,
                                      ),
                              ],
                            ),
                            flex: 1,
                          ),
                          widget.groupId != ""
                              ?  Container(
                                  height: 0.0,
                                )
                              :




                        /*   Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                                  child:  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: <Widget>[
                                      isType == "Public"
                                          ?  InkWell(
                                              child:  Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: <Widget>[
                                                   Image.asset(
                                                    "assets/newDesignIcon/connections/public.png",
                                                    width: 25.0,
                                                    height: 25.0,
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  ),
                                                  PaddingWrap.paddingfromLTRB(
                                                      5.0,
                                                      5.0,
                                                      10.0,
                                                      5.0,
                                                      TextViewWrap.textView(
                                                          "Public",
                                                          TextAlign.center,
                                                           ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                          12.0,
                                                          FontWeight.normal))
                                                ],
                                              ),
                                              onTap: () {
                                                _settingModalBottomSheet(
                                                    context);
                                              })
                                          : isType == "Private"
                                              ?  InkWell(
                                                  child:  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment.end,
                                                    children: <Widget>[
                                                       Image.asset(
                                                        "assets/newDesignIcon/connections/private.png",
                                                        fit: BoxFit.cover,
                                                        height: 25.0,
                                                        width: 25.0,
                                                        color:   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                      ),
                                                      PaddingWrap.paddingfromLTRB(
                                                          5.0,
                                                          5.0,
                                                          10.0,
                                                          5.0,
                                                          TextViewWrap.textView(
                                                              "Private",
                                                              TextAlign.center,
                                                               Color(ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR),
                                                              12.0,
                                                              FontWeight
                                                                  .normal))
                                                    ],
                                                  ),
                                                  onTap: () {
                                                    _settingModalBottomSheet(
                                                        context);
                                                  })
                                              : isType == "AllConnections"
                                                  ?  InkWell(
                                                      child:  Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child:
                                                                 Image.asset(
                                                              "assets/profile/post/all_connections.png",
                                                              height: 14.0,
                                                              width: 35.0,
                                                            ),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child:  Container(
                                                                width: 85.0,
                                                                child: PaddingWrap.paddingAll(
                                                                    5.0,
                                                                    TextViewWrap.textViewMultiLine(
                                                                        "Connections",
                                                                        TextAlign
                                                                            .start,
                                                                         ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        12.0,
                                                                        FontWeight
                                                                            .normal,
                                                                        2))),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        _settingModalBottomSheet(
                                                            context);
                                                      })
                                                  :  InkWell(
                                                      child:  Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: <Widget>[
                                                           Expanded(
                                                            child:
                                                                 Image.asset(
                                                              "assets/profile/post/selected_connections.png",
                                                              height: 14.0,
                                                              width: 35.0,
                                                            ),
                                                            flex: 0,
                                                          ),
                                                           Expanded(
                                                            child:  Container(
                                                                width: 85.0,
                                                                child: PaddingWrap.paddingAll(
                                                                    5.0,
                                                                    TextViewWrap.textViewMultiLine(
                                                                        "Selected Connections",
                                                                        TextAlign
                                                                            .start,
                                                                         ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                        12.0,
                                                                        FontWeight
                                                                            .normal,
                                                                        2))),
                                                            flex: 0,
                                                          )
                                                        ],
                                                      ),
                                                      onTap: () {
                                                        _settingModalBottomSheet(
                                                            context);
                                                      }),
                                    ],
                                  ),
                                )
*/



                           Padding(
                            padding:
                            EdgeInsets.fromLTRB(0.0, 5.0, 20.0, 0.0),
                            child:  Container(

                              child:   Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: <Widget>[
                                  isType == "Public"
                                      ?  InkWell(
                                      child:  Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.end,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.end,
                                        children: <Widget>[
                                           Image.asset(
                                            "assets/newDesignIcon/connections/public.png",
                                            width: 25.0,
                                            height: 25.0,

                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          ),
                                          PaddingWrap.paddingfromLTRB(
                                              5.0,
                                              5.0,
                                              10.0,
                                              5.0,
                                              TextViewWrap.textView(
                                                  "Public",
                                                  TextAlign.center,
                                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  12.0,
                                                  FontWeight.normal))
                                        ],
                                      ),
                                      onTap: () {
                                        _settingModalBottomSheet(
                                            context);
                                      })
                                      : isType == "Private"
                                      ?  InkWell(
                                      child:  Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.end,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.end,
                                        children: <Widget>[
                                           Image.asset(
                                            "assets/newDesignIcon/connections/private.png",
                                            fit: BoxFit.cover,
                                            height: 25.0,
                                            width: 25.0,
                                            color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          ),
                                          PaddingWrap.paddingfromLTRB(
                                              5.0,
                                              5.0,
                                              10.0,
                                              5.0,
                                              TextViewWrap.textView(
                                                  "Private",
                                                  TextAlign.center,
                                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  12.0,
                                                  FontWeight
                                                      .normal))
                                        ],
                                      ),
                                      onTap: () {
                                        _settingModalBottomSheet(
                                            context);
                                      })
                                      : isType == "AllConnections"
                                      ?  InkWell(
                                      child:  Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .center,
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .center,
                                        children: <Widget>[
                                           Expanded(
                                            child:
                                             Image.asset(
                                              "assets/profile/post/all_connections.png",
                                              height: 14.0,
                                              width: 35.0,
                                            ),
                                            flex: 0,
                                          ),
                                           Expanded(
                                            child:  Container(
                                                width: 85.0,
                                                child: PaddingWrap.paddingAll(
                                                    5.0,
                                                    TextViewWrap.textViewMultiLine(
                                                        "Connections",
                                                        TextAlign
                                                            .start,
                                                          ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        12.0,
                                                        FontWeight
                                                            .normal,
                                                        2))),
                                            flex: 0,
                                          )
                                        ],
                                      ),
                                      onTap: () {
                                        _settingModalBottomSheet(
                                            context);
                                      })
                                      :  InkWell(
                                      child:  Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .center,
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .center,
                                        children: <Widget>[
                                           Expanded(
                                            child:
                                             Image.asset(
                                              "assets/profile/post/selected_connections.png",
                                              height: 14.0,
                                              width: 35.0,
                                            ),
                                            flex: 0,
                                          ),
                                           Expanded(
                                            child:  Container(
                                                width: 85.0,
                                                child: PaddingWrap.paddingAll(
                                                    5.0,
                                                    TextViewWrap.textViewMultiLine(
                                                        "Selected Connections",
                                                        TextAlign
                                                            .start,
                                                          ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        12.0,
                                                        FontWeight
                                                            .normal,
                                                        2))),
                                            flex: 0,
                                          )
                                        ],
                                      ),
                                      onTap: () {
                                        _settingModalBottomSheet(
                                            context);
                                      }),
                                ],
                              ),
                              decoration: BoxDecoration(


                                border: Border.all(
                                  color: Color(0xfff4684EB),
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.circular(0),
                              ),
                            ),
                          )




                        ],
                      )
                    ],
                  ),
                )
              ],
            )));
  }

// Updated View for POST TYPE

}
