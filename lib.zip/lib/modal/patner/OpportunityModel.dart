import 'dart:io';

import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/age_between.dart';
import 'package:spike_view_project/modal/patner/designation_model_param.dart';
import 'package:spike_view_project/modal/patner/qualification_model_param.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/modal/patner/subject_model_param.dart';
import 'package:spike_view_project/modal/patner/user_image_model_param.dart';

class OpportunityModel {
  bool isViewMore=false;
  String opportunityId,
      userId,
      roleId,
      jobTitle,
      jobType,
      jobLocation,
      project,
      duration,
      status,
      fromDate,
      toDate,
      groupId,
      targetAudience,
      title,
      gender,
      companyId,
      offerId,
      serviceTitle,
      serviceDesc,expiresOn,numberOfClick,url,actionType,urlLinkForLearn, groupIdAction, callingNumber,formId,groupName,linkUrlPosition,timeZone;
bool groupIsPublic=true;
  List<Address> locationList;
  List<Assest> assestList;
  List<AgeBetween> ageList;
  List<Assest> videoList ;
  List<Assest> docList ;
  List<Assest> googleLinkList ;
  List<Assest> mediaList ;
  List<Assest> assestVideoAndImage ;
  List<IntrestModel> interestType ;

  String fees;
  String description;
  String bio;
  //String menteeSupport;
  String supportOffered;
  String projectAreas;
  String category;
  //String userImagepath;

  //String qualification;
  List<QualificationModelParam> qualificationModelParam;
  List<DesignationModelParam> designationModelParam;
  List<SubjectModelParam> subjectModelParam;
  List<ScheduleModelParam> scheduleModelParam;
  List<UserImageModelParam> userImageModelParam;
  List<OtherCategory> otherCategoryList;
   List<OtherCategory> otherCareerList;
   List<OtherCategory> otherSubjectList;

  String toMapStringForDesignation() {
    String data = "";
    if (this.designationModelParam != null) {
      /*data = this.designationModelParam.map((v) {
        print('v::: ${v.name}');
        return v.toMapString();
      }).toString();*/
      for(int i=0; i< this.designationModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.designationModelParam[i].name;
        else
          data = this.designationModelParam[i].name;
      }
    }
    //print('toMapStringForDesignation data:::: ${data}');
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }

  String toMapStringSubject() {
    String data = "";
    if (this.subjectModelParam != null) {
      //data = this.subjectModelParam.map((v) => v.toMapString()).toString();
      print('Subject length::: ${this.subjectModelParam.length}');
      for(int i=0; i< this.subjectModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.subjectModelParam[i].name;
        else
          data = this.subjectModelParam[i].name;
        print('Subject i::: ${i}');
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }


  String toMapStringQualification() {
    String data = "";
    if (this.qualificationModelParam != null) {
      //data = this.qualificationModelParam.map((v) => v.toMapString()).toString();
      for(int i=0; i< this.qualificationModelParam.length; i++){
        if(i != 0)
          data = data + " | " +this.qualificationModelParam[i].name;
        else
          data = this.qualificationModelParam[i].name;
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }

  String toMapStringSubjectOther() {
    String data = "";
    if (this.otherSubjectList != null) {
      //data = this.selectedSubjectOtherOption.map((v) => v).toString();
      for(int i=0; i< this.otherSubjectList.length; i++){
        if(i != 0)
          data = data + " | " +this.otherSubjectList[i].name;
        else
          data = this.otherSubjectList[i].name;
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }
  String toMapStringForDesignationOther() {
    String data = "";
    if (this.otherCategoryList != null) {
      //data = this.otherCategoryList.map((v) => v.toMapString()).toString();
      for(int i=0; i< this.otherCategoryList.length; i++){
        if(i != 0)
          data = data + " | " +this.otherCategoryList[i].name;
        else
          data = this.otherCategoryList[i].name;
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }
  String toMapStringForDesignationCareer() {
    String data = "";
    if (this.otherCareerList != null) {
      //data = this.otherCareerList.map((v) => v.toMapString()).toString();
      for(int i=0; i< this.otherCareerList.length; i++){
        if(i != 0)
          data = data + " | " +this.otherCareerList[i].name;
        else
          data = this.otherCareerList[i].name;
      }
    }
    //return data.replaceAll("(", "").replaceAll(")", "").replaceAll(",", " |");
    return data;
  }


  OpportunityModel(
      this.opportunityId,
      this.userId,
      this.roleId,
      this.jobTitle,
      this.jobType,
      this.jobLocation,
      this.project,
      this.duration,
      this.status,
      this.fromDate,
      this.toDate,
      this.groupId,
      this.targetAudience,
      this.title,
      this.gender,
      this.companyId,
      this.offerId,
      this.serviceTitle,
      this.serviceDesc,
      this.locationList,
      this.ageList,
      this.assestList,
      this.videoList,
      this.mediaList,
      this.docList,
      this.googleLinkList,
      this.assestVideoAndImage,
      this.interestType,
      this.expiresOn,
      this.numberOfClick,
      this.url,
      this.actionType,
      this.urlLinkForLearn,
      this. groupIdAction,
      this.callingNumber,
      this.formId,
      this.groupName,
      this.linkUrlPosition,
      this.groupIsPublic,

      this.fees,
      this.description,
      this.bio,
      this.supportOffered,
      //this.menteeSupport,
      //this.advisorSupportOffered,
      this.projectAreas,
      this.userImageModelParam,
      //this.qualification,
      this.qualificationModelParam,
      this.designationModelParam,
      this.subjectModelParam,
      this.scheduleModelParam,this.otherCategoryList,this. otherCareerList,this.otherSubjectList,this.timeZone
      //this.category,


      );
}

class AgeModel {
  String to, from;

  AgeModel(this.to, this.from);
}


class IntrestModel {
  String id, name;
bool isSelected=false;
  IntrestModel(this.id, this.name);


  IntrestModel.fromJson(Map<String, dynamic> json) {
    id = json['interestsId'].toString();

    name = json['name'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }

  Map<String, dynamic> toJson2() => {
    'id': id,
    'name': name,

  };
}