import 'dart:io';

import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';

class OpportunityCategoryModel {
  String status;
  List<OpportunityCategory> categoryList;

  OpportunityCategoryModel({this.status, this.categoryList});

  OpportunityCategoryModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      categoryList =  List<OpportunityCategory>();
      json['result'].forEach((v) {
        categoryList.add(new OpportunityCategory.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.categoryList != null) {
      data['result'] = this.categoryList.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class OpportunityCategory {
  int oppCategoryId;
  String name;
  String image;
  String description;

  OpportunityCategory(
      {this.oppCategoryId, this.name, this.image, this.description});

  OpportunityCategory.fromJson(Map<String, dynamic> json) {
    oppCategoryId = json['oppCategoryId'];
    name = json['name'];
    image = json['image'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['oppCategoryId'] = this.oppCategoryId;
    data['name'] = this.name;
    data['image'] = this.image;
    data['description'] = this.description;
    return data;
  }
}
