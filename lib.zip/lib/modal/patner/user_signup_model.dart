import 'package:spike_view_project/gateway/BusinessCategoryResponse.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';

class UserModel {
  String referCode;
  String firstName;
  String lastName;
  String email;
  String password;
  String dateOfBirth;
  int dateOfBirthInMls;
  String phoneNumber;
  String companyName;
  String companyAddress;
  String companyPhoneNumber;
  String webUrl;
  String aboutCompany;
  String profilePicture = "";
  String deviceId = "";
  String coverPicture = "";
  bool intrenship;
  bool advertise;
  bool collageAdmission;
  List<OfferModel> offers = [];
  List<AssetModel> assets = [];
  List<Map<String, dynamic>> categoryResult;

  UserModel(
      {this.firstName,
        this.lastName,
        this.email,
        this.dateOfBirth,
        this.phoneNumber,
        this.companyName,
        this.companyAddress,
        this.companyPhoneNumber,
        this.webUrl,
        this.aboutCompany,
        this.intrenship,
        this.advertise,
        this.collageAdmission,
        this.password,
        this.categoryResult,
        this.referCode

      });

  static Map<String, dynamic> toArrayMap(
      UserModel personalInfoObject,
      bool isRedirectToRecommendation,
      String encryptedstrNewPassword,
      Address address2,
      zip,
      gender,
      referralUserId,
      referralUserroleId,
      selectedCountryCode,signupType,deviceId) {
    Map<String, dynamic> personalInfo = Map();
    personalInfo['firstName'] = personalInfoObject.firstName;
    personalInfo['lastName'] = personalInfoObject.lastName;
    personalInfo['email'] = personalInfoObject.email;
    personalInfo['dob'] = personalInfoObject.dateOfBirthInMls;
    personalInfo['mobileNo'] = personalInfoObject.phoneNumber;
    personalInfo['businessCategory'] = personalInfoObject.categoryResult;
    personalInfo['roleId'] = 4;
    // personalInfo['recommendationFlag'] = isRedirectToRecommendation;
    personalInfo['recommendationWebFlag'] = isRedirectToRecommendation;
    personalInfo['password'] = encryptedstrNewPassword;
    personalInfo['state'] = address2 != null ? address2.state : "";
    personalInfo['city'] = address2 != null ? address2.city : "";
    personalInfo['country'] = address2 != null ? address2.country : "";
    personalInfo['zipCode'] = zip.toString();
    personalInfo['gender'] =   gender.toString()=="Non-Binary"?"NonBinary":gender.toString();
    personalInfo['referralUserId'] = referralUserId;
    personalInfo['referralUserRoleId'] = referralUserroleId;
    personalInfo['countryCode'] = selectedCountryCode;
    personalInfo['referCode'] = personalInfoObject.referCode;
    personalInfo['companyName'] = personalInfoObject.companyName;
    personalInfo['signupType'] = signupType;
    personalInfo['socialId'] = "";
    personalInfo['platformType'] = "mobile";
    personalInfo['deviceId'] = deviceId;

    Map<String, dynamic> companyInfo = Map();
    companyInfo['name'] = personalInfoObject.companyName;
    companyInfo['address'] = personalInfoObject.companyAddress;
    companyInfo['phone'] = personalInfoObject.companyPhoneNumber;
    companyInfo['url'] = personalInfoObject.webUrl;
    companyInfo['about'] = personalInfoObject.aboutCompany;
    companyInfo['profilePicture'] = personalInfoObject.profilePicture;
    companyInfo['coverPicture'] = personalInfoObject.coverPicture;
    companyInfo['businessCategory'] = personalInfoObject.categoryResult;
    companyInfo['offer'] = OfferModel.mapList(personalInfoObject.offers);
    //   companyInfo['asset'] = Assest.mapList(personalInfoObject.assets);
    companyInfo['asset'] =
        personalInfoObject.assets.map((item) => item.toJson()).toList();
    companyInfo['signupType'] = signupType;
    companyInfo['socialId'] = "";
    companyInfo['platformType'] = "mobile";
    personalInfo['company'] = companyInfo;

    print('personalInfoObject Params  => $personalInfoObject');
    print('personalInfo Params  => $personalInfo');

    return personalInfo;
  }

  static Map<String, dynamic> toArrayMapForSideNavigation(
      UserModel personalInfoObject,
      userId,
      isRedirectToRecommendation,
      selectedCountryCode,signupType) {
/*    Map<String, dynamic> personalInfo = Map();

    personalInfo['roleId'] = 4;
    personalInfo['userId'] = userId;
    personalInfo['email'] = personalInfoObject.email;*/
    Map<String, dynamic> companyInfo = Map();
    companyInfo['userId'] = userId;
    companyInfo['roleId'] = 4;
    companyInfo['name'] = personalInfoObject.companyName;
    companyInfo['address'] = personalInfoObject.companyAddress;
    companyInfo['phone'] = personalInfoObject.companyPhoneNumber;
    companyInfo['url'] = personalInfoObject.webUrl;
    companyInfo['about'] = personalInfoObject.aboutCompany;
    companyInfo['profilePicture'] = personalInfoObject.profilePicture;
    companyInfo['coverPicture'] = personalInfoObject.coverPicture;
    companyInfo['businessCategory'] = personalInfoObject.categoryResult;
    companyInfo['isActive'] = true;
    companyInfo['password'] = personalInfoObject.password;
    companyInfo['recommendationWebFlag'] = isRedirectToRecommendation;
    companyInfo['offer'] = OfferModel.mapList(personalInfoObject.offers);
    companyInfo['countryCode'] = selectedCountryCode;
    companyInfo['asset'] =
        personalInfoObject.assets.map((item) => item.toJson()).toList();
    companyInfo['signupType'] = signupType;
    companyInfo['socialId'] = "";
    companyInfo['platformType'] = "mobile";

    //   personalInfo['company'] = companyInfo;

    print('Params  => $personalInfoObject');

    return companyInfo;
  }
}
