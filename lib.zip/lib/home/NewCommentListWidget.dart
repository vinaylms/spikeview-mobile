import 'dart:async';
import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/ProfileImageView11.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class NewCommentListWidget extends StatefulWidget {
  List<CommentData> commentList;
  String profile_image_path, feedId, name;
  UserPostModal userPostModel;
  String userIdPref, roleId;
  String badge;
  String badgeImage;
  int gamificationPoints;

  NewCommentListWidget(
      this.commentList,
      this.profile_image_path,
      this.feedId,
      this.name,
      this.userPostModel,
      this.userIdPref,
      this.roleId,
      this.badge,
      this.gamificationPoints,
      this.badgeImage);

  @override
  NewCommentListWidgetState createState() {
    return NewCommentListWidgetState(commentList, userIdPref, feedId);
  }
}

class NewCommentListWidgetState extends State<NewCommentListWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, token, summary = "";
  final _formKey = GlobalKey<FormState>();
  int skip = 0;
  bool isLoading = true;
  TextEditingController addComment;
  bool isCommentIconVisible = false;
  String companyName = "",
      companyImage = "",
      userNAme = "",
      userImage = "",
      feedId;
  ScrollController _scrollController = ScrollController();

  NewCommentListWidgetState(this.commentList, this.userIdPref, this.feedId);

  int commentLength = 0;
  List<CommentData> commentList;
  List<CommentDetailModel> commentListnew;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    roleId = prefs.getString(UserPreference.ROLE_ID);
    companyName = prefs.getString(UserPreference.COMPANY_NAME_PATH);
    companyImage = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    userImage = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    userNAme = prefs.getString(UserPreference.NAME);
    apiToGetDetail();
    setState(() {
    });
  }

  @override
  void initState() {
    getSharedPreferences();
    addComment = TextEditingController(text: '');

    super.initState();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;

        print("sss  comment 1" + skip.toString());
        apiToGetDetail();
      }
    });
  }

  Future apiToGetDetail() async {
    try {
      print("sss  comment 1111" + skip.toString());
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        commentList.clear();
        setState(() {
        });

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_COMMENT_LIST_ALL +
                userIdPref +
                "&feedId=" +
                feedId +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString(),
            "get");
        isLoading = false;
        setState(() {

        });
        log(response.data.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              commentListnew =
                  ParseJson.parseCommentList(response.data['result']);
              for (int i = 0; i < commentListnew.length; i++) {
                print("sss  comment 4 length ${commentListnew.length}");
                commentList.add( CommentData(
                    commentListnew[i].id,
                    commentListnew[i].comment,
                    commentListnew[i].commentedBy.toString(),
                    commentListnew[i].createdAt.toString(),
                    commentListnew[i].profilePicture,
                    commentListnew[i].firstName +
                        " " +
                        commentListnew[i].lastName,
                    "",
                    userIdPref,
                    [],
                    false,
                    commentListnew[i].commentedByRole.toString(),
                    commentListnew[i].badge.toString(),
                    0,
                    commentListnew[i].badgeImage.toString(),
                    false));
              }
              setState(() {
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {

      });
      e.toString();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future apiCallingForAddComment(localCommentId, commentText) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": widget.feedId,
          "userId": int.parse(userIdPref),
          "comment": commentText,
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "name": "",
          "title": "",
          "roleId": int.parse(roleId),
          "profilePicture": "",
          "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "CommentOnFeed"
        };

        Response response = await ApiCalling2().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_FEED_COMMENT, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widget.userPostModel.isCommented = true;
              for (CommentData _comment in commentList) {
                if (_comment.commentId == localCommentId) {
                  _comment.commentId =
                      response.data["result"]["commentId"].toString();
                  _comment.isComment = true;
                  break;
                }
              }
              if (mounted) {
                setState(() {});
              }
              DbHelper().updateFeedDataComments(widget.feedId, commentList);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForRemoveComment(index, commentId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": int.parse(widget.feedId),
          "commentId": commentId,
          "roleId": int.parse(roleId),
          "dateTime": DateTime.now().millisecondsSinceEpoch
        };

        Response response = await ApiCalling2().apiCallPostWithMapData(
            context, Constant.ENDPOINT_REMOVE_COMMENT, map);

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {}
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == userIdPref) {
    } else {
      Util.onTapImageTile(
          tapedUserRole: roleId,
          partnerUserId: tapedUserId,
          context: context);
    }
  }

  void onlyDeletePopUp(index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 50.0,
                            child: Container(
                                height: 100.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        20.0,
                                        0.0,
                                        20.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                              const BorderRadius.all(
                                                  Radius.circular(10)),
                                            ),
                                            width: double.infinity,
                                            child: Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                MainAxisAlignment.center,
                                                children: <Widget>[
                                                  // Container(
                                                  //   color: AppConstants
                                                  //       .colorStyle
                                                  //       .dividerPopUp,
                                                  //   height: 1.0,
                                                  // ),
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding: EdgeInsets
                                                            .fromLTRB(
                                                            0.0,
                                                            12.0,
                                                            0.0,
                                                            13.0),
                                                        child: Text(
                                                          "Delete",
                                                          textAlign: TextAlign
                                                              .center,
                                                          style: TextStyle(
                                                              color:
                                                              ColorValues
                                                                  .circle4,
                                                              fontFamily: Constant
                                                                  .latoRegular,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w500,
                                                              fontSize: 16),
                                                        )),
                                                    onTap: () async {
                                                      String commentId =
                                                          commentList[index]
                                                              .commentId;
                                                      commentList
                                                          .removeAt(index);
                                                      if (commentList
                                                          .length ==
                                                          0)
                                                        widget.userPostModel
                                                            .isCommented =
                                                        false;

                                                      DbHelper()
                                                          .updateFeedDataComments(
                                                          widget.feedId,
                                                          commentList);
                                                      setState(() {
                                                      });

                                                      Navigator.pop(context);
                                                      apiCallForRemoveComment(
                                                          index, commentId);
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 32.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                0.0,
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: const BorderRadius.all(
                                          Radius.circular(10)),
                                    ),
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                                  AppConstants
                                                      .stringConstant.cancel,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION_1,
                                                      fontFamily:
                                                      Constant.latoRegular,
                                                      fontWeight: FontWeight.w500,
                                                      fontSize: 16),
                                                )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  SlidableController slidableCtrl = SlidableController();

  Widget getListItem(index) {
    print('------ - image badge ${commentList[index].badgeImage}');
    return Slidable(
      controller: slidableCtrl,
      actionPane: SlidableDrawerActionPane(),
      actionExtentRatio: 0.18,
      closeOnScroll: true,
      secondaryActions: userIdPref ==
          commentList[index].commentedBy
          ?[
        SlideAction(
          child: Text("Delete",
              style: TextStyle(
                  color: ColorValues.WHITE,
                  fontSize: 14.0,
                  fontFamily: Constant.latoRegular)),
          decoration: BoxDecoration(color: ColorValues.Delete_lable_color),
          onTap: () {
            onlyDeletePopUp(index);
          },
        ),
      ]
        :[],
      child: index == commentList.length - 1
          ? PaddingWrap.paddingfromLTRB(
        20.0,
        15.0,
        20.0,
        10.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  commentList[index].profilePicture,
              placeHolderImage: commentList[index].roleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 48.0,
              height: 48.0,
              onTap: () {
                onTapImageTile(commentList[index].commentedBy,
                    commentList[index].roleId);
              },
            ),
            SizedBox(width: 14),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      RichText(
                        maxLines: null,
                        text: TextSpan(
                          children: <TextSpan>[
                            TextSpan(
                                text: commentList[index].name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontFamily: Constant.latoRegular,
                                  fontSize: 16.0,
                                )),
                          ],
                        ),
                      ),
                      commentList[index] != null &&
                          commentList[index].roleId == "1"
                      //true
                          ? Util.getStudentBadge12(
                          commentList[index].badge,
                          commentList[index].badgeImage)
                          : const SizedBox.shrink(),
                    ],
                  ),
                  Container(
                    child: Linkify(
                      onOpen: (link) async {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) => WebViewWidget(
                                    link.url, "spikeview")));
                      },
                      text: commentList[index].comment,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontSize: 14.0,
                          fontWeight: FontWeight.normal,
                          fontFamily: Constant.latoRegular),
                      linkStyle: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: Constant.latoRegular,
                          fontSize: 14.0),
                    ),
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          commentList[index].dateTime,
                          style: TextStyle(
                              color: ColorValues.labelColor,
                              fontSize: 12.0,
                              fontFamily: Constant.latoRegular),
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ],
              ),
              flex: 1,
            ),
          ],
        ),
      )
          : PaddingWrap.paddingfromLTRB(
        20.0,
        15.0,
        20.0,
        10.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  commentList[index].profilePicture,
              placeHolderImage: commentList[index].roleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 48.0,
              height: 48.0,
              onTap: () {
                onTapImageTile(commentList[index].commentedBy,
                    commentList[index].roleId);
              },
            ), // User Image
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      RichText(
                        maxLines: null,
                        text: TextSpan(
                          children: <TextSpan>[
                            TextSpan(
                                text: commentList[index].name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: ColorValues
                                      .HEADING_COLOR_EDUCATION_1,
                                  fontFamily: Constant.latoRegular,
                                  fontSize: 16.0,
                                )),
                          ],
                        ),
                      ),
                      commentList[index] != null &&
                          commentList[index].roleId == "1"
                      //true
                          ? Util.getStudentBadge12(
                          commentList[index].badge,
                          commentList[index].badgeImage)
                          : const SizedBox.shrink(),
                    ],
                  ),
                  Container(
                    child: Linkify(
                      onOpen: (link) async {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              //   builder: (context) =>  DashBoardWidget()));
                                builder: (context) => WebViewWidget(
                                    link.url, "spikeview")));
                      },
                      text: commentList[index].comment,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontSize: 14.0,
                          fontWeight: FontWeight.normal,
                          fontFamily: Constant.latoRegular),
                      linkStyle: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: Constant.latoRegular,
                          fontSize: 14.0),
                    ),
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          commentList[index].dateTime?.trim(),
                          style: TextStyle(
                              color: ColorValues.labelColor,
                              fontSize: 12.0,
                              fontFamily: Constant.latoRegular),
                        ),
                      ),
                      /*Container(
                        width: 10.0,
                      ),
                      Expanded(
                        child: userIdPref ==
                            commentList[index].commentedBy
                            ? InkWell(
                          child:
                          Image.asset(
                            "assets/feed/three_dot_blue.png",
                            width: 16.0,
                            height: 16.0,
                          ),
                          onTap: () {
                            onlyDeletePopUp(index);
                            // optionForDelete(index);
                          },
                        )
                            : const SizedBox.shrink(),
                        flex: 0,
                      )*/
                    ],
                  ),
                ],
              ),
              flex: 1,
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    return Scaffold(
      backgroundColor: ColorValues.WHITE,
      body: SafeArea(
        child: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                "assets/generateScript/script_background.png",
              ),
              fit: BoxFit.fill,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 40, 20, 22),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Image.asset(
                        "assets/generateScript/back.png",
                        height: 32.0,
                        width: 32.0,
                      ),
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  padding: const EdgeInsets.fromLTRB(0, 25, 0, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                        child: Text(
                          "Comments",
                          textAlign: TextAlign.left,
                          style: TextStyle(
                              fontSize: 28.0,
                              fontWeight: FontWeight.w700,
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: ListView(
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          children: <Widget>[
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: List.generate(
                                commentList.length, (index) {
                                  return getListItem(index);
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 15),
                      Container(
                        margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                        padding: const EdgeInsets.fromLTRB(19,0,15,0),
                        decoration: BoxDecoration(
                            borderRadius:
                                const BorderRadius.all(Radius.circular(15)),
                            border: Border.all(
                                width: 1.0,
                                color: ColorValues.BORDER_COLOR_NEW)),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: TextField(
                                style: TextStyle(
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                controller: addComment,
                                keyboardType: TextInputType.text,
                                textCapitalization:
                                    TextCapitalization.sentences,
                                maxLines: null,
                                maxLength: TextLength.COMMENT_MAX_LENGTH,
                                onChanged: (s) {
                                  if (s.trim().length > 0) {
                                    isCommentIconVisible = true;
                                  } else {
                                    isCommentIconVisible = false;
                                  }
                                  setState(() {
                                    commentLength = s.length;
                                  });
                                },
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  filled: true,
                                  counterText: "",
                                  contentPadding: EdgeInsets.zero,
                                  counterStyle: TextStyle(
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                  hintText: roleId == "4"
                                      ? "Write a comment" //+ companyName
                                      : "Write a comment",
                                  //+ userNAme,
                                  hintStyle: TextStyle(
                                      color: ColorValues.hintColor,
                                      fontSize: 14.0,
                                      fontFamily: Constant.latoRegular),
                                  fillColor: Colors.transparent,
                                ),
                              ),
                            ),
                            InkWell(
                              child: Image.asset(
                                "assets/feed/sent_icon.png",
                                width: 22.0,
                                height: 22.0,
                              ),
                              onTap: () {
                                if (addComment.text.trim().length > 0) {
                                  String commentId = DateTime.now()
                                      .millisecondsSinceEpoch
                                      .toString()
                                      .toString();
                                  String commentText = addComment.text;
                                  widget.userPostModel.isCommented = true;
                                  List<Likes> likesList = List();
                                  commentList.insert(
                                      0,
                                      CommentData(
                                          commentId,
                                          commentText,
                                          userIdPref,
                                          "a few seconds ago",
                                          roleId == "4"
                                              ? prefs.getString(UserPreference
                                                  .COMPANY_IMAGE_PATH)
                                              : widget.profile_image_path,
                                          roleId == "4"
                                              ? prefs.getString(UserPreference
                                                  .COMPANY_NAME_PATH)
                                              : widget.name,
                                          "",
                                          userIdPref,
                                          likesList,
                                          false,
                                          prefs.getBool(
                                                  UserPreference.IS_PARENT)
                                              ? "2"
                                              : "1",
                                          widget.badge,
                                          widget.gamificationPoints,
                                          widget.badgeImage,
                                          false));
                                  DbHelper().updateFeedDataComments(
                                      widget.feedId, commentList);
                                  setState(() {
                                    addComment.text = "";
                                    commentLength = 0;
                                  });
                                  apiCallingForAddComment(
                                      commentId, commentText);
                                }
                              },
                            )
                          ],
                        ),
                      ),
                      /*Align(
                        alignment: Alignment.bottomRight,
                        child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          8.0,
                          20.0,
                          0.0,
                          Text(
                            commentLength.toString() + "/200",
                            textAlign: TextAlign.end,
                            style: TextStyle(
                                color: ColorValues.labelColor, fontSize: 10.0),
                          ),
                        ),
                      ),*/
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void optionForDelete(int index) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Container(
                                height: 110.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        0.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  InkWell(
                                                    child: Container(
                                                        height: 50.0,
                                                        padding:
                                                            EdgeInsets.fromLTRB(
                                                                0.0,
                                                                13.0,
                                                                0.0,
                                                                13.0),
                                                        child: Text(
                                                          "Delete",
                                                          textAlign:
                                                              TextAlign.center,
                                                          maxLines: 5,
                                                          style: TextStyle(
                                                              color: ColorValues
                                                                  .BLUE_COLOR_BOTTOMBAR,
                                                              height: 1.2,
                                                              fontSize: 16.0,
                                                              fontFamily: Constant
                                                                  .TYPE_CUSTOMREGULAR),
                                                        )),
                                                    onTap: () {
                                                      String commentId =
                                                          commentList[index]
                                                              .commentId;
                                                      commentList
                                                          .removeAt(index);
                                                      if (commentList.length ==
                                                          0)
                                                        widget.userPostModel
                                                                .isCommented =
                                                            false;

                                                      DbHelper()
                                                          .updateFeedDataComments(
                                                              widget.feedId,
                                                              commentList);
                                                      setState(() {
                                                      });

                                                      Navigator.pop(context);
                                                      apiCallForRemoveComment(
                                                          index, commentId);
                                                    },
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }
}
