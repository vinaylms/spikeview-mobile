import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class ListExternalLinkItem extends StatelessWidget {
  final String title;
  final String url;
  final String desc;
  final VoidCallback onEditTap;
  final VoidCallback onRemoveTap;

  const ListExternalLinkItem({
    @required this.title,
    @required this.url,
    @required this.desc,
    @required this.onEditTap,
    @required this.onRemoveTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: BaseText(
                text: title,
                textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                fontFamily: AppConstants.stringConstant.latoRegular,
                fontWeight: FontWeight.w700,
                fontSize: 14,
                maxLines: 1,
              ),
            ),
            const SizedBox(width: 12),
            InkWell(
              child: Image.asset(
                'assets/profile/skills/ic_edit_blue.png',
                width: 18,
                height: 18,
              ),
              onTap: onEditTap,
            ),
            const SizedBox(width: 12),
            InkWell(
              child: Image.asset(
                'assets/experience/ic_remove.png',
                height: 14,
                width: 14,
              ),
              onTap: onRemoveTap,
            ),
          ],
        ),
        SizedBox(height: 2),
        BaseText(
          text: url,
          textColor: ColorValues.labelColor,
          fontFamily: AppConstants.stringConstant.latoRegular,
          fontWeight: FontWeight.w500,
          fontSize: 14,
          maxLines: 2,
        ),
        SizedBox(height: 3),
        BaseText(
          text: desc,
          textColor: ColorValues.labelColor,
          fontFamily: AppConstants.stringConstant.latoRegular,
          fontWeight: FontWeight.w500,
          fontSize: 14,
          maxLines: 3,
        ),
      ],
    );
  }
}
