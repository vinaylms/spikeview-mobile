

class BadgeModel {
  String status;
  List<BadgeData> result;

  BadgeModel({this.status, this.result});

  BadgeModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result = <BadgeData>[];
      json['result'].forEach((v) {
        result.add(new BadgeData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class BadgeData {
  int badgeId;
  String name;
  String image;
  String status;
  String type;
  int createdAt;

  BadgeData(
      {this.badgeId,
        this.name,
        this.image,
        this.status,
        this.type,
        this.createdAt});

  BadgeData.fromJson(Map<String, dynamic> json) {
    badgeId = json['badgeId'];
    name = json['name'];
    image = json['image'];
    status = json['status'];
    type = json['type'];
    createdAt = json['createdAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['badgeId'] = this.badgeId;
    data['name'] = this.name;
    data['image'] = this.image;
    data['status'] = this.status;
    data['type'] = this.type;
    data['createdAt'] = this.createdAt;
    return data;
  }
}


