class ReferalCodeResponse {
  String status;
  String message;
  //Result result;


  ReferalCodeResponse(
      {this.status,
        this.message
        //this.result
      });

  ReferalCodeResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    //result = json['result'] != null ?  Result.fromJson(json['result']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;

    return data;
  }
}


