import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';

//import 'package:simple_permissions/simple_permissions.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/API.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/gateway/BusinessCategoryResponse.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/patner/VideoModel.dart';
import 'package:spike_view_project/modal/patner/asset_model.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/CongratulationWidget.dart';
import 'package:spike_view_project/patnerFlow/opportunity/add_google_doc_link_view.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/presoView/simple_animations/controlled_animation.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_document_picker/flutter_document_picker.dart';

import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class Company_Edit_Widget extends StatefulWidget {
  String userId;
  String pageName;

  Company_Edit_Widget(this.userId, {this.pageName});

  @override
  State<StatefulWidget> createState() => Company_Edit_WidgetState(userId);
}

class Company_Edit_WidgetState extends State<Company_Edit_Widget>
    with BaseCommonWidget {
  bool isOtherSelected = false;
  List<String> selectedOtherOption = [];
  final categoryController = TextEditingController();
  List<CategoryResult> businessCategoryList =  List<CategoryResult>();
  List<String> selectedCategoryOption = [];
  List<CategoryModel> selectedCategoryList =  List<CategoryModel>();
  List<CategoryResult> removedBusinessCategoryList =  List<CategoryResult>();
  List<CategoryResult> orignalBusinessCategoryList =  List<CategoryResult>();

  //String selectedCategory = 'Select Business Category';

  final FocusNode _otherCategoryFocus = FocusNode();

  bool showList = false;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();

  bool isBusinessCategoryError = false;

  Color bottomViewColor = Palette.dividerColor;

  bool isShowMore = true;
  bool isShowOtherMore = true;

  Company_Edit_WidgetState(this.userid);

  bool isMediaExpanded = true;
  bool internship = false;
  bool advertise = false;
  bool collageAdmission = false;

  /* final _formKey = GlobalKey<FormState>();
  final FocusNode _companyNameFocus = FocusNode();
  final FocusNode _companyAddressFocus = FocusNode();
  final FocusNode _websiteURLFocus = FocusNode();
  final FocusNode _aboutCompanyFocus = FocusNode();
  final FocusNode _phoneNumberNameFocus = FocusNode();*/
  String file = "", type = "";

  /* final companyNameController = TextEditingController();
  final companyAddressController = TextEditingController();
  final websiteController = TextEditingController();
  final phoneNumberController = TextEditingController();
  final aboutCompanyController = TextEditingController();*/
  List<Assest> assestList =  List();
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String selectedCountryCode = '1';
  File imagePath;
  CompanyProfileModel companyProfileModel;
  String sasToken, sasContainer;
  String googleDocLink, googleDocTitle, selectedGroup;
  String userid, companyid, token;
  List<String> googleDoclinkList =  List();
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "";
  SharedPreferences prefs;
  bool isMediaSelected = false;

  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final dobController = TextEditingController();
  String dateOfBirth;
  final companyNameController = TextEditingController();
  final companyAddressController = TextEditingController();
  final webUrlController = TextEditingController();
  final companyPhoneController = TextEditingController();
  final aboutCompanyController = TextEditingController();
  UploadMedia uploadMedia;
  final FocusNode firstNameFocus = FocusNode();
  final FocusNode lastnameFocus = FocusNode();
  final FocusNode emailFocus = FocusNode();
  final FocusNode phoneFocus = FocusNode();
  final FocusNode dobFocus = FocusNode();

  final FocusNode companyNameFocus = FocusNode();
  final FocusNode companyAddressFocus = FocusNode();
  final FocusNode webUrlFocus = FocusNode();
  final FocusNode companyPhoneFocus = FocusNode();
  final FocusNode aboutFocus = FocusNode();
  File mediaImage, mediaVideo, mediaDoc;
  String fname = '',
      lname = '',
      email = '',
      phone = '',
      pin = '',
      dob = '',
      cname = '',
      caddress = '',
      webUrl = '',
      cphone = '',
      cabout = '',
      coverPicture,
      profilePicture;
  String isParentGender = "";
  String strParentZip = "";
  TextEditingController parentZipController =
       TextEditingController(text: "");
  bool isUpdateAdded = false;
  bool nameValidation = true;
  List<String> mediaImagesList =  List();
  List<AssetModel> assetModelMap =  List();
  List<FileModel> mediaVideosList =  List();
  List<String> mediaDocumentList =  List();
  String dropdownvalue = '+91';
  bool isApiCalling = false;
  static StreamController syncDoneController = StreamController.broadcast();

  _fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

//  final GlobalKey<FormState> _profileFormKey = GlobalKey<FormState>();
  final GlobalKey<FormState> _companyProfileFormKey = GlobalKey<FormState>();
  FocusNode parentZipcodeFocusNode = FocusNode();

  void _validateCardDetail() async {
    generateChipsForOther();
    if (_companyProfileFormKey.currentState.validate()) {
      if (selectedCategoryOption.length > 0) {
        /*     if (firstNameController.text.length <= 0) {
        nameValidation = false;
      } else {*/
        try {
          isApiCalling = true;
          nameValidation = true;

          // If all data are correct then save data to out variables

          _companyProfileFormKey.currentState.save();

          mediaImagesList.removeAt(0);
          mediaDocumentList.removeAt(0);
          mediaVideosList.removeAt(0);

          for (var file in mediaImagesList) {
            assetModelMap.add(AssetModel(
              file: file,
              tag: 'media',
              type: "image",
            ));
          }

          for (var file in mediaDocumentList) {
            assetModelMap.add(AssetModel(
              file: file,
              tag: 'media',
              type: "doc",
            ));
          }

          for (var file in mediaVideosList) {
            assetModelMap.add(AssetModel(
              file: file.path,
              tag: 'media',
              type: "video",
            ));
          }

          print('Apurva mediaVideosList size:: ${mediaVideosList.length}');
          print('Apurva assetModelMap size:: ${assetModelMap.length}');
          print('Apurva mediaImagesList size:: ${mediaImagesList.length}');

          for (var file in googleDoclinkList) {
            assetModelMap.add(AssetModel(
              file: file,
              tag: 'media',
              type: "google",
            ));
          }

          apiCallingForUpdate();
        } catch (e) {
          isApiCalling = false;
        }
      } else {
        setState(() {
          isBusinessCategoryError = true;
          //bottomViewColor = Palette.redColor;
          bottomViewColor = Colors.red[700];
        });
      }
    }
    /*   } else {
      //    If all data are not valid then start auto validation.
      setState(() {
        isUpdateAdded = true;
      });
    }*/
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && sasContainer != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      return "";
    }
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(context);
      if (widget.pageName == 'rejectionReason') {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) =>  DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else
        Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Text getTextLabel(txt, size, color, fontWeight) {
      return  Text(
        txt,
        style:
             TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Padding getParentGender() {
      return PaddingWrap.paddingAll(
          5.0,
           Row(
            children: <Widget>[
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 35.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "Male"
                              ? "assets/newDesignIcon/male_blue.png"
                              : "assets/newDesignIcon/male.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "Male",
                            13.0,
                            isParentGender == "Male"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "Male";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 35.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "Female"
                              ? "assets/newDesignIcon/female.png"
                              : "assets/newDesignIcon/female_grey.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "Female",
                            13.0,
                            isParentGender == "Female"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "Female";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 35.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "Non-Binary"
                              ? "assets/newDesignIcon/binary_blue.png"
                              : "assets/newDesignIcon/non_binary.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "Non-Binary",
                            13.0,
                            isParentGender == "Non-Binary"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "Non-Binary";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 20.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "NA"
                              ? "assets/newDesignIcon/na_blue.png"
                              : "assets/newDesignIcon/na.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "NA",
                            13.0,
                            isParentGender == "NA"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "NA";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
            ],
          ));
    }

    final parentZipUi =  Padding(
      padding:
           EdgeInsets.only(left: 13.0, top: 15.0, right: 13.0, bottom: 10.0),
      child:  Theme(
          data:  ThemeData(
              backgroundColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              indicatorColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              cursorColor:  ColorValues.HEADING_COLOR_EDUCATION,
              textSelectionColor: Colors.black54,
              accentColor:  ColorValues.LIGHT_GREY_TEXT_COLOR,
              hintColor:  ColorValues.LIGHT_GREY_TEXT_COLOR),
          child:  TextFormField(
            focusNode: parentZipcodeFocusNode,
            keyboardType: TextInputType.text,
            controller: parentZipController,
            maxLength: TextLength.ZIPCODE_MAX_LENGTH,
            cursorColor: Constant.CURSOR_COLOR,
            /*  validator: (val) =>
                val.trim().length >= 4 && val.trim().length <= 10
                    ? null
                    : MessageConstant.ENTER_VALID_ZIP_CODE_VAL,*/
            onSaved: (val) => strParentZip = val,
            style:
                 TextStyle(color: Colors.black, fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration:  InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                counterText: "",
                /*    suffixIcon:  GestureDetector(
                    child:  Padding(
                      padding:  EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 0.0),
                      child:  Image.asset(
                        "assets/newDesignIcon/navigation/zip.png",
                        width: 25.0,
                        height: 25.0,
                      ),
                    )),*/
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: ColorValues.DARK_GREY, width: 1.0)),
                labelText: "Zip Code",errorStyle: Util.errorTextStyle,
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                border:  UnderlineInputBorder(
                    borderSide:  BorderSide(
                        color:  ColorValues.DARK_GREY, width: 1.0))),
          )),
    );

    // TODO: implement build
    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    void conformationDialog(type, path) {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to remove?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                if (type == "image") {
                                                  mediaImagesList.remove(path);
                                                  setState(() {
                                                    mediaImagesList;
                                                  });
                                                } else if (type == "video") {
                                                  mediaVideosList.remove(path);
                                                  setState(() {
                                                    mediaVideosList;
                                                  });
                                                } else if (type == "doc") {
                                                  mediaDocumentList
                                                      .remove(path);
                                                  setState(() {
                                                    mediaDocumentList;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    void checkMediaAndUpload({
      @required String imagePath,
      @required String type,
    }) async {
      setState(() {});
      if (type == "video") {
        File file =
            await uploadMedia.compresssData(new File(imagePath), true, type);
        imagePath = file.path;
      } else if (type == "image") {
        // Alok 26 feb
//        File file = await uploadMedia.compressImage(new File(imagePath));
//        imagePath = file.path;
//
//        Future<File> _futureImage;
//        File _imageFile;

        print("Image Path -----");
      }
      String strAzureImageUploadPath = await uploadImgOnAzure(
          imagePath
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);

      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPath != null ||
          strAzureImageUploadPath != "false") {
        if (type == "video") {
          String path = Constant.IMAGE_PATH +
              strPrefixPathforPhoto +
              strAzureImageUploadPath;
          print("path+++++" + path);
          final thumbnailFile =
              await uploadMedia.getVideoThumbnailFromUrl(imagePath);

          mediaVideosList.add(new FileModel(
              thumbnailFile, strPrefixPathforPhoto + strAzureImageUploadPath));
          setState(() {
            mediaVideosList;
          });
          if (mediaImagesList.length > 0 && mediaVideosList.length > 0) {
            isMediaSelected = true;
          } else {
            isMediaSelected = false;
          }
        } else if (type == "image") {
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
          setState(() {
            mediaImagesList.add(path);
          });
          if (mediaImagesList.length > 0 && mediaVideosList.length > 0) {
            isMediaSelected = true;
          } else {
            isMediaSelected = false;
          }
        } else {
          String path = strPrefixPathforPhoto + strAzureImageUploadPath;
          mediaDocumentList.add(path);
          setState(() {
            mediaDocumentList;
          });
        }

        //assetModelMap.add(model);
      } else {
        //  showToastMessage('Upload failed. Please try again.');
      }
    }

    //---------------------Add media View and core logics  ---------------------
    onTapImageAddButton() async {
      mediaImage = await uploadMedia.pickImageFromGallery();
      if (mediaImage != null) {
        // await _cropImage(mediaImage);
        imagePath = mediaImage;
        if (imagePath != null) {
          CustomProgressLoader.showLoader(context);
          Timer _timer =  Timer(const Duration(milliseconds: 400), () {
            checkMediaAndUpload(
                imagePath: imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                type: "image");
          });
        }
      } else {
        //ToastWrap.showToast("'No file was selected'", context);
      }
    }

    onTapVideoAddButton() async {
      mediaVideo = await uploadMedia.pickVideoFromGallery();
      if (mediaVideo != null) {
/*         final thumbnailFile = await uploadMedia.flutterVideoCompress
                      .getThumbnailWithFile(mediaVideo.path);
                  setState(() {
                    mediaVideosList.add(thumbnailFile);
                  });*/
        CustomProgressLoader.showLoader(context);
        Timer _timer =  Timer(const Duration(milliseconds: 400), () {
          checkMediaAndUpload(
              imagePath: mediaVideo
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim(),
              type: "video");
        });
      } else {
        // ToastWrap.showToast("'No file was selected'", context);
      }
    }

    getDocuments() async {
      try {
        // Platform messages may fail, so we use a try/catch PlatformException.
        try {
          FlutterDocumentPickerParams params = FlutterDocumentPickerParams(
            allowedFileExtensions: ['pdf'],
            allowedMimeTypes: ['application/pdf'],
            invalidFileNameSymbols: ['/'],
          );

          String path =
              await FlutterDocumentPicker.openDocument(params: params);
          if ((Util.getFileExtension(path) == ".pdf") && path != null) {
            if (path != null) {
              CustomProgressLoader.showLoader(context);
              Timer _timer =  Timer(const Duration(milliseconds: 400), () {
                checkMediaAndUpload(
                    imagePath: path
                        .toString()
                        .replaceAll("File: ", "")
                        .replaceAll("'", "")
                        .trim(),
                    type: "doc");
              });
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.INVALID_FILE_FORMAT_VAL, context);
          }
        } catch (e) {
          ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
        }
      } catch (e) {
        ToastWrap.showToast(MessageConstant.INVALID_FILE_FORMAT_VAL, context);
      }
    }

    final docListUiData =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 0.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 4,
      children: mediaDocumentList.map((file) {
        if (file == null) {
          return  Stack(children: <Widget>[
             InkWell(
              child: Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 5, 20, 0),
                  child:  Container(
                      height: 54.0,
                      width: 64.0,
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  Image.asset(
                        "assets/newDesignIcon/userprofile/add.png",
                        height: 25.0,
                        width: 25.0,
                      ))),
              onTap: () {
                if (mediaDocumentList.length <= 5) {
                  getDocuments();
                } else {
                  ToastWrap.showToast(
                      MessageConstant.MAX_5_DOC_UPLOADED_VAL, context);
                }
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 5, 20, 0),
                  child:  Container(
                      decoration:  BoxDecoration(
                          border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                      child:  InkWell(
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child:  Container(
                              height: 75.0,
                              width: 64.0,
                              child:  Image.asset(
                                "assets/newDesignIcon/patner/pdf.png",
                                height: 58.0,
                                width: 58.0,
                              )),
                        ),
                        onTap: () {
                          launch(Constant.IMAGE_PATH + file);
                        },
                      ))),
               Positioned(
                  right: 10.0,
                  top: 0.0,
                  child:  Container(
                      height: 20.0,
                      width: 20.0,
                      child:  Center(
                          child:  Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           InkWell(
                              child: PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0,
                                   Image.asset(
                                    "assets/remove_grey.png",
                                    width: 20.0,
                                    height: 20.0,
                                  )),
                              onTap: () {
                                conformationDialog("doc", file);
                              })
                        ],
                      )))),
            ],
          ));
        }
      }).toList(),
    ));

    final mediaImageListUIData =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaImagesList.map((file) {
        if (file == null) {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                onTapImageAddButton();
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              FadeInImage.assetNetwork(
                fit: BoxFit.cover,
                placeholder: 'assets/aerial/default_img.png',
                image: Constant.IMAGE_PATH + file,
                height: 54.0,
                width: 80.0,
              ),
               Container(
                height: 54.0,
                width: 84.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                               Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("image", file);
                          })
                    ],
                  ))),
            ],
          ));
        }
      }).toList(),
    ));

    final videoListUi =  Container(
        child:  GridView.count(
      primary: false,
      shrinkWrap: true,
      padding: const EdgeInsets.all(0.0),
      crossAxisSpacing: 10.0,
      childAspectRatio: 1.50,
      scrollDirection: Axis.vertical,
      crossAxisCount: 3,
      children: mediaVideosList.map((file) {
        if (file == null) {
          return  Stack(children: <Widget>[
             InkWell(
              child:  Container(
                  height: 54.0,
                  width: 80.0,
                  decoration:  BoxDecoration(
                      border:  Border.all(color:  ColorValues.LIGHT_GREY_TEXT_COLOR)),
                  child:  Image.asset(
                    "assets/newDesignIcon/userprofile/add.png",
                    height: 25.0,
                    width: 25.0,
                  )),
              onTap: () {
                onTapVideoAddButton();
              },
            )
          ]);
        } else {
          return  Container(
              child:  Stack(
            children: <Widget>[
              showMediaFileWidget(80, file.file),
               Container(
                height: 54.0,
                width: 80.0,
                color:  Color(0XFFC0C0C0).withOpacity(.4),
              ),
               Container(
                  height: 54.0,
                  width: 80.0,
                  child:  Center(
                      child:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                               Image.asset(
                                "assets/newDesignIcon/achievment/remove.png",
                                width: 35.0,
                                height: 35.0,
                              )),
                          onTap: () {
                            conformationDialog("video", file);
                          })
                    ],
                  ))),
            ],
          ));
        }
      }).toList(),
    ));
    uploadGoogleDocLink() {
      return Column(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              InkWell(
                  onTap: () async {
                    if (googleDoclinkList.length < 5) {
                      final String result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => AddGoogleDocLink(
                                  googleDocLink: "",
                                  googleDocTitle: "",
                                )),
                      );
                      if (result != null) {
                        setState(() {
                          googleDocLink = result.split('#####')[0];
                          googleDocTitle = result.split('#####')[1];

                          googleDoclinkList.add(googleDocLink);
                        });
                      }
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.MAX_5_LINK_UPLOADED_VAL, context);
                    }
                  },
                  child: Text(
                    googleDoclinkList.length == 0
                        ? 'Upload document link'
                        : "Add More",
                    style: TextStyle(color: Palette.accentColor, fontSize: 14,fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  )),
               Column(
                children: List.generate(googleDoclinkList.length, (index) {
                  return Row(
                    children: <Widget>[
                      Expanded(
                        child: Text(
                          googleDoclinkList[index],
                          style: TextStyle(
                              color: Palette.primaryTextColor, fontSize: 16,fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                      ),
                      InkWell(
                        child: Container(
                          padding: EdgeInsets.all(0),
                          child: Image.asset(
                            ImagePath.ICON_CLEAR,
                            height: 24.4,
                            width: 17,
                          ),
                        ),
                        onTap: () {
                          setState(() {
                            googleDoclinkList.removeAt(index);
                          });
                        },
                      ),
                    ],
                  );
                }),
              )
            ],
          ),
        ],
      );
    }

    mediaPickerWidgets() {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          UIHelper.verticalSpaceMedium,
          mediaLabelText('Photos'),
          UIHelper.verticalSpaceSmall,
          mediaImageListUIData,
          UIHelper.verticalSpaceMedium,
          mediaLabelText('Videos'),
          UIHelper.verticalSpaceSmall,
          videoListUi,
          UIHelper.verticalSpaceMedium,
          mediaLabelText('Documents (PDF only)'),
          UIHelper.verticalSpaceSmall,
          docListUiData,
          UIHelper.verticalSpaceMedium,
          uploadGoogleDocLink(),
          UIHelper.verticalSpaceMedium
        ],
      );
    }

    mediaHeaderWidget() {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.all(UIHelper.screenPadding),
            child: colorIcon(ImagePath.ICON_MEDIA, 25, 25),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(
                  right: UIHelper.screenPadding,
                  bottom: UIHelper.screenPadding,
                  top: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  UIHelper.verticalSpaceExtraSmall,
                   InkWell(
                    child:  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          'Add media',
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.primaryTextColor, 16, FontType.Regular),
                        ),
                        UIHelper.verticalSpaceExtraSmall,
                        Text(
                          'Please Add media (Photos, Videos and Documents)',
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.secondaryTextColor, 14, FontType.Regular),
                        ),
                      ],
                    ),
                    onTap: () {
                      setState(() {
                        isMediaExpanded = !isMediaExpanded;
                      });
                    },
                  ),
                  isMediaExpanded ? mediaPickerWidgets() : Container(),
                ],
              ),
            ),
          ),
        ],
      );
    }

    mediaWidget() {
      return Container(
        decoration: rectangleDecoration(),
        child: mediaHeaderWidget(),
      );
    }

    var firstNameField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 20.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR, style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        controller: firstNameController,
        onTap: () {
          generateChipsForOther();
        },
        focusNode: firstNameFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, firstNameFocus, lastnameFocus);
        },
        validator: (val) =>val.trim().length == 0
            ? null
            : !ValidationWidget.isName(val)
            ? MessageConstant.NAME_CONTAIN_ALPHABT_VAL
            : null,
        onSaved: (String val) {
          fname = val;
        },
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        decoration: textFormFieldDecorationWithHint('Your Name',
            ImagePath.ICON_COMPANY, 23, 23, "First Name, Last Name"),
      ),
    );
    var lastNameField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 35.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR, style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        controller: lastNameController,
        focusNode: lastnameFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, lastnameFocus, emailFocus);
        },
        validator: (String arg) {
          if (arg.length > 0) {
            if (ValidationWidget.isName(arg)) {
              return null;
            } else {
              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
            }
          } else {
            // return MessageConstant.ENTER_LAST_NAME_VAL;
            return null;
          }
        },
        onSaved: (String val) {
          lname = val;
        },
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        decoration:  InputDecoration(
          labelText: "Last Name",errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );
    var emailField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 20.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR, style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        controller: emailController,
        onTap: () {
          generateChipsForOther();
        },
        enabled: false,
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.emailAddress,
        decoration:  InputDecoration(
          labelText: "Email",errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );

    var companyNameField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 35.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,  style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        controller: companyNameController,
        onTap: () {
          generateChipsForOther();
        },
        focusNode: companyNameFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, companyNameFocus, companyAddressFocus);
        },
        validator: (String arg) {
          if (arg.length > 0) {
            if (ValidationWidget.isName(arg)) {
              return null;
            } else {
              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
            }
          } else {
            return MessageConstant.ENTER_COMPANY_NAMEL_VAL;
          }
        },
        onSaved: (String val) {
          cname = val;
        },
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        decoration:  InputDecoration(
          labelText: "Company / Display name",errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );

    var companyAddressField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 20.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: companyAddressController,
        style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        onTap: () {
          generateChipsForOther();
        },
        focusNode: companyAddressFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, companyAddressFocus, companyPhoneFocus);
        },
        validator: (String arg) {
          if (arg.length > 0) {
            if (ValidationWidget.isMessage(arg)) {
              return null;
            } else {
              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
            }
          } else {
            return MessageConstant.ENTER_COMPANY_ADDRESS_VAL;
          }
        },
        onSaved: (String val) {
          caddress = val;
        },
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        maxLines: null,
        decoration:  InputDecoration(
          labelText: "Company / Your Address",errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );

    var companyPhoneField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 20.0),
      child: Stack(
        /*crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,*/
        children: <Widget>[
          Positioned(
            top: 3,
            left: 0,
            right: 0,
            child:  Text(
              "Phone Number",
              textAlign: TextAlign.left,
              style:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontSize: 13.0,
                  fontWeight: FontWeight.w400,
                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  0.0,
                  11.0,
                  0.0,
                  0.0,
                ),
                child: CountryCodePicker(
                  dense: false,
                  showFlag: true,
                  //displays flag, true by default
                  showDialingCode: true,
                  //displays dialing code, false by default
                  showName: false,
                  //displays country name, true by default
                  onChanged: (CountryCode country) {
                    setState(() {
                      selectedCountryCode = country.dialingCode;
                    });
                  },
                  selectedCountryCode: selectedCountryCode,
                ),
              ),
              SizedBox(
                width: 12,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    TextFormField(
                      cursorColor: ColorValues.GREY_TEXT_COLOR,
                      controller: companyPhoneController, style: TextStyle(
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                      onTap: () {
                        generateChipsForOther();
                      },
                      focusNode: companyPhoneFocus,
                      onFieldSubmitted: (term) {
                        _fieldFocusChange(
                            context, companyPhoneFocus, webUrlFocus);
                      },
                      validator: (String arg) {
                        if (arg.length > 0) {
                          if (ValidationWidget.isphone(arg)) {
                            return null;
                          } else {
                            return MessageConstant.ENTER_CORRECT_INPUT_VAL;
                          }
                        } else {
                          return MessageConstant.ENTER_PHONE_NUMBER_VAL;
                        }
                      },
                      onSaved: (String val) {
                        cphone = val;
                      },
                      autocorrect: false,
                      textInputAction: TextInputAction.next,
                      obscureText: false,
                      keyboardType: TextInputType.phone,
                      decoration:  InputDecoration(
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        labelText: "Phone Number",errorStyle: Util.errorTextStyle,
                        labelStyle: TextStyle(
                            fontSize: 16,
                            fontFamily: Constant.TYPE_CUSTOMREGULAR,
                            color: ColorValues.GREY_TEXT_COLOR),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                              color: ColorValues.DARK_GREY, width: 1.0),
                        ),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(
                                color: ColorValues.DARK_GREY,
                                width: 1.0)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
    var companyWebUrlField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 20.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: webUrlController, style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        onTap: () {
          generateChipsForOther();
        },
        focusNode: webUrlFocus,
        onFieldSubmitted: (term) {
          _fieldFocusChange(context, webUrlFocus, aboutFocus);
        },
        /*validator: (String arg) {
          if (arg.length > 0) {
            if (ValidationChecks.validateWebUrl(arg)) {
              return null;
            } else {
              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
            }
          } else {
            //return MessageConstant.ENTER_WEB_URL_VAL;
            return null;
          }
        },*/

        validator: (value) {
          return value.trim().length == 0
              ? null
              : ValidationChecks.validateWebUrl(value);
        },
        onSaved: (String val) {
          webUrl = val;
        },
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        maxLines: null,
        decoration:  InputDecoration(
          labelText: "Website URL",errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );
    var otherCategoryField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 0.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: categoryController, style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        onChanged: (value) {},
        textInputAction: TextInputAction.done,
        onFieldSubmitted: (term) {
          _otherCategoryFocus.unfocus();
          selectedOtherOption.add(categoryController.text);
          //selectedCategoryList.add(new CategoryModel(categoryController.text,otherCategoryId, true));
          categoryController.clear();
          setState(() {});
        },
        /*validator: (String arg) {
          if (arg.length > 0) {
            if (ValidationWidget.isUrl(arg)) {
              return null;
            } else {
              return MessageConstant.ENTER_CORRECT_INPUT_VAL;
            }
          } else {
            //return MessageConstant.ENTER_WEB_URL_VAL;
            return null;
          }
        },*/
        onSaved: (String val) {
          webUrl = val;
        },
        autocorrect: false,
        obscureText: false,
        keyboardType: TextInputType.text,
        maxLines: null,
        decoration:  InputDecoration(
          labelText: "Other",errorStyle: Util.errorTextStyle,
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );
    var companyAboutField = Padding(
      padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 20.0),
      child: TextFormField(
        cursorColor: ColorValues.GREY_TEXT_COLOR,
        controller: aboutCompanyController,
        onTap: () {
          generateChipsForOther();
        },
        maxLength: TextLength.COMAPNY_ABOUT_MAX_LENGTH,
        focusNode: aboutFocus, style: TextStyle(
          fontFamily: Constant.TYPE_CUSTOMREGULAR),
        validator: (value) {
          return ValidationChecks.validateAboutCompany(value.trim());
        },
        onSaved: (String val) {
          cabout = val;
        },
        autocorrect: false,
        textInputAction: TextInputAction.next,
        obscureText: false,
        keyboardType: TextInputType.text,
        maxLines: null,
        decoration:  InputDecoration(
          labelText: "About Your Company / Service",counterStyle:   TextStyle( fontFamily: Constant.TYPE_CUSTOMREGULAR),
          labelStyle: TextStyle(
              fontSize: 16, fontFamily: Constant.TYPE_CUSTOMREGULAR, color: ColorValues.GREY_TEXT_COLOR),
          enabledBorder: UnderlineInputBorder(
            borderSide:
                BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
          ),
          focusedBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
        ),
      ),
    );
    return SafeArea(
      child:  WillPopScope(
        onWillPop: () async {
          goToPrevious();
          return false;
        },
        child: Scaffold(
          appBar:  AppBar(
            elevation: 0.0,
            automaticallyImplyLeading: false,
            titleSpacing: 2.0,
            brightness: Brightness.light,
            leading:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                 InkWell(
                  child:  SizedBox(
                    height: 40.0,
                    width: 40.0,
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        3.0,
                         Center(
                            child:  Image.asset(
                                "assets/newDesignIcon/navigation/back.png",
                                height: 20.0,
                                width: 10.0,
                                fit: BoxFit.fitHeight))),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                  },
                )
              ],
            ),
            actions: <Widget>[
               InkWell(
                child: PaddingWrap.paddingfromLTRB(
                    5.0,
                    7.0,
                    10.0,
                    5.0,
                     Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                         Text(
                          "Submit ",
                          style:  TextStyle(
                              fontSize: 16.0,
                              fontFamily: Constant.customRegular,
                              color:
                                   ColorValues.BLUE_COLOR_BOTTOMBAR),
                        )
                      ],
                    )),
                onTap: () {
                  if (!isApiCalling) _validateCardDetail();
                },
              )
            ],
            title:  Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                 Text(
                  "My Detail",
                  style:  TextStyle(
                      fontSize: 18.0,
                      fontFamily: Constant.customRegular,
                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                )
              ],
            ),
            backgroundColor: Colors.white,
          ),
          body: GestureDetector(
            onTap: () {
              generateChipsForOther();
            },
            child: FormKeyboardActions(
                nextFocus: false,
                keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                //optional
                keyboardBarColor: Colors.grey[200],
                //optional
                actions: [
                  KeyboardAction(
                    focusNode: phoneFocus,
                  ),
                  KeyboardAction(
                    focusNode: parentZipcodeFocusNode,
                  ),
                  KeyboardAction(
                    focusNode: companyPhoneFocus,
                  ),
                ],
                child:  Column(
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                     Expanded(
                      child: SingleChildScrollView(
                          child: Column(
                        children: <Widget>[
                          /*   Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                color: ColorValues.GREY__COLOR_DIVIDER,
                                height: 25.0,
                                width: MediaQuery.of(context).size.width,
                                child: Padding(
                                  padding:
                                      const EdgeInsets.only(top: 5.0, left: 18.0),
                                  child: Text(
                                    "PERSONAL INFO",
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.black,
                                        fontFamily: Constant.TYPE_CUSTOMBOLD),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 13.0, right: 15.0),
                                child: Form(
                                  key: _profileFormKey,
                                  autovalidate: isUpdateAdded,
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: <Widget>[
                                        firstNameField,
                                        lastNameField,
                                        emailField,
                                        //dobField,
                                        //phoneField,
                                        parentZipUi,
                                        PaddingWrap.paddingfromLTRB(
                                            13.0,
                                            20.0,
                                            13.0,
                                            0.0,
                                            getTextLabel(
                                                "I identify my gender as:",
                                                14.0,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                FontWeight.normal)),
                                        PaddingWrap.paddingfromLTRB(13.0, 0.0,
                                            13.0, 0.0, getParentGender()),
                                      ]),
                                ),
                              )
                            ],
                          ),*/
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 0.0,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                /*       Container(
                                  color: ColorValues.GREY__COLOR_DIVIDER,
                                  height: 25.0,
                                  width: MediaQuery.of(context).size.width,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 5.0, left: 18.0),
                                    child: Text(
                                      "COMPANY INFO",
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: Colors.black,
                                          fontFamily: Constant.TYPE_CUSTOMBOLD),
                                    ),
                                  ),
                                ),*/
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 13.0,
                                    right: 15.0,
                                  ),
                                  child: Form(
                                    key: _companyProfileFormKey,
                                    autovalidate: isUpdateAdded,
                                    child: Column(children: <Widget>[
                                      companyNameField,
                                      firstNameField,
                                      Container(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 10.0,
                                              right: 10.0,
                                              top: 20,
                                              bottom: 0.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                decoration: bottomBorderDynamic(
                                                    bottomViewColor),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    selectedCategoryOption
                                                                .length >
                                                            0
                                                        ? Text(
                                                            'Business Category',
                                                            style: AppTextStyle
                                                                .getDynamicFontStyle(
                                                                    Palette
                                                                        .secondaryTextColor,
                                                                    12,
                                                                    FontType
                                                                        .Regular),
                                                          )
                                                        : Container(),
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: <Widget>[
                                                        selectedCategoryOption
                                                                    .length >
                                                                0
                                                            ? Expanded(
                                                                flex: 1,
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    setState(
                                                                        () {
                                                                      showList =
                                                                          !showList;
                                                                    });
                                                                  },
                                                                  child: Wrap(
                                                                    children: isShowMore
                                                                        ? getSelectedWidgets(
                                                                            selectedCategoryOption.sublist(0,
                                                                                1),
                                                                            "mainCategory")
                                                                        : getSelectedWidgets(
                                                                            selectedCategoryOption,
                                                                            "mainCategory"),
                                                                  ),
                                                                ),
                                                              )
                                                            : Expanded(
                                                                flex: 1,
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    setState(
                                                                        () {
                                                                      showList =
                                                                          !showList;
                                                                    });
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    child:
                                                                        Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          bottom:
                                                                              14.0),
                                                                      child:
                                                                          Text(
                                                                        'Business Category',
                                                                        style: AppTextStyle.getDynamicFontStyle(
                                                                            Palette.secondaryTextColor,
                                                                            16,
                                                                            FontType.Regular),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                        selectedCategoryOption
                                                                    .length >
                                                                1
                                                            ? InkWell(
                                                                onTap: () {
                                                                  setState(() {
                                                                    isShowMore =
                                                                        !isShowMore;
                                                                  });
                                                                },
                                                                child: Padding(
                                                                  padding: const EdgeInsets
                                                                          .only(
                                                                      bottom:
                                                                          16.0,
                                                                      left:
                                                                          8.0),
                                                                  child: Text(
                                                                    isShowMore
                                                                        ? '+${selectedCategoryOption.length - 1} More'
                                                                        : 'Less',
                                                                    style: AppTextStyle.getDynamicFontStyle(
                                                                        Palette
                                                                            .accentColor,
                                                                        14,
                                                                        FontType
                                                                            .Regular),
                                                                  ),
                                                                ),
                                                              )
                                                            : Container(),
                                                        IconButton(
                                                          onPressed: () {
                                                            showList =
                                                                !showList;
                                                            setState(() {});
                                                          },
                                                          icon: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 15.0),
                                                            child: Icon(showList
                                                                ? Icons
                                                                    .keyboard_arrow_up
                                                                : Icons
                                                                    .keyboard_arrow_down),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    /*selectedOtherOption.length > 0
                            ? selectOtherCategoryTextField()
                            : Container(),*/
                                                  ],
                                                ),
                                              ),
                                              //isOtherSelected ?
                                              businessCategoryList != null &&
                                                      businessCategoryList
                                                              .length >
                                                          0
                                                  ? businessCategoryListWidget()
                                                  : Container(),

                                              isBusinessCategoryError
                                                  ? Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 6.0),
                                                      child: Text(
                                                        '${MessageConstant.ENTER_BUSINESS_CATE_VAL}',
                                                        style: AppTextStyle
                                                            .getDynamicFontStyle(
                                                                //Palette.redColor,
                                                                Colors.red[700],
                                                                12,
                                                                FontType
                                                                    .Regular),
                                                      ),
                                                    )
                                                  : Container(),

                                              isOtherSelected
                                                  ? Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        UIHelper
                                                            .verticalSpaceSmall1,
                                                        Container(
                                                          //decoration: bottomBorder(),
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              selectedOtherOption
                                                                          .length >
                                                                      0
                                                                  ? Text(
                                                                      'Other Business Category',
                                                                      style: AppTextStyle.getDynamicFontStyle(
                                                                          Palette
                                                                              .secondaryTextColor,
                                                                          12,
                                                                          FontType
                                                                              .Regular),
                                                                    )
                                                                  : Container(),
                                                              Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                children: <
                                                                    Widget>[
                                                                  selectedOtherOption
                                                                              .length >
                                                                          0
                                                                      ? Expanded(
                                                                          flex:
                                                                              1,
                                                                          child:
                                                                              Wrap(
                                                                            //children: getSelectedWidgets(selectedOtherOption,"otherCategory"),
                                                                            children: isShowOtherMore
                                                                                ? getSelectedWidgets(selectedOtherOption.sublist(0, 1), "otherCategory")
                                                                                : getSelectedWidgets(selectedOtherOption, "otherCategory"),
                                                                          ),
                                                                        )
                                                                      : Expanded(
                                                                          flex:
                                                                              1,
                                                                          child: isOtherSelected
                                                                              ? selectOtherCategoryTextField()
                                                                              : Container(),
                                                                        ),
                                                                  selectedOtherOption
                                                                              .length >
                                                                          1
                                                                      ? InkWell(
                                                                          onTap:
                                                                              () {
                                                                            setState(() {
                                                                              isShowOtherMore = !isShowOtherMore;
                                                                            });
                                                                          },
                                                                          child:
                                                                              Padding(
                                                                            padding: const EdgeInsets.only(
                                                                                bottom: 16.0,
                                                                                left: 8.0,
                                                                                right: 16.0),
                                                                            child:
                                                                                Text(
                                                                              isShowOtherMore ? '+${selectedOtherOption.length - 1} More' : 'Less',
                                                                              style: AppTextStyle.getDynamicFontStyle(Palette.accentColor, 14, FontType.Regular),
                                                                            ),
                                                                          ),
                                                                        )
                                                                      : Container(),
                                                                  /*IconButton(
                                                              icon: Padding(
                                                                padding: const EdgeInsets.only(left: 15.0),
                                                                child: Icon(Icons.keyboard_arrow_down, color: Colors.transparent,),
                                                              ),
                                                            ),*/
                                                                ],
                                                              ),
                                                              selectedOtherOption
                                                                          .length >
                                                                      0
                                                                  ? selectOtherCategoryTextField()
                                                                  : Container(),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  : Container(),
                                            ],
                                          ),
                                        ),
                                      ),
                                      companyAddressField,
                                      companyPhoneField,
                                      emailField,
                                      companyWebUrlField,
                                      companyAboutField,
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            top: 12.0, bottom: 30.0),
                                        child: Text(
                                          "Make your message compelling and don't forget to include how the user can contact you and apply to your opportunity. ",
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: ColorValues.GREY_TEXT_COLOR,
                                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 30.0),
                                        child: InkWell(
                                          child: mediaWidget(),
                                        ),
                                      ),
                                    ]),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      )),
                    )
                  ],
                )),
          ),
        ),
      ),
    );
  }

  void goToPrevious() async {
    Navigator.pop(context, "pop");
    /* if (widget.pageName == "dashBoard") {
      Navigator.pop(context, "pop");
    } else {
      personalInfoObject.companyName = companyNameController.text;
      personalInfoObject.companyAddress = companyAddressController.text;
      personalInfoObject.companyPhoneNumber = phoneNumberController.text;
      personalInfoObject.webUrl = websiteController.text;
      personalInfoObject.aboutCompany = aboutCompanyController.text;
      Navigator.pop(context, personalInfoObject);
    }*/
  }

  generateSasToken(token) async {
    Map<String, dynamic> result = await API.generateSasToken(token);

    sasToken = result['sasToken'];
    sasContainer = result['container'];

    //Navigator.of(context).pop();
  }

  getSharedPrefrence() async {
    prefs = await SharedPreferences.getInstance();
    userid = prefs.getString(UserPreference.USER_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userid +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    generateSasToken(token);
    await companyInfoApi(true);
  }

  Future companyInfoApi(isShowLaoder) async {
    print("userId------------------------" + userid);
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await  ApiCalling2().apiCall(context,
          Constant.ENDPOINT_COMPANY_INFO + userid + "&roleId=4", "get");

      //if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      print("response comapny " + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          print(status + "---------status--------");
          if (status == "Success") {
            var map = response.data['result'];
            if (map != null) {
              companyProfileModel = ParseJson.parseCompanyInfoData(map);
              print('companyProfileModel::: $companyProfileModel');
              if (companyProfileModel != null) {
                //set data
                setData(companyProfileModel);
              }
            }
          }
        }
      }
    } catch (e) {
      if (isShowLaoder) {
        print("error----------------" + e.toString());
        CustomProgressLoader.cancelLoader(context);
      }
      e.toString();
    }
  }

  Future apiCallingForUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        getSelectedCategoryDetail();
        Response response;
        CustomProgressLoader.showLoader(context);
        Address address2;
        if (companyProfileModel.zipCode != parentZipController.text) {
          try {
            /*     String formatedAddres = await Util.getDetailUsingZipCode(
                false, context, parentZipController.text);
            address2 = ParseJson.addressParse(
                formatedAddres, parentZipController.text);
            print("addres" + formatedAddres);
            print("data" + address2.zip);
            print("data" + address2.city);
            print("data" + address2.state);
            print("data" + address2.country);*/

            Response response1 = await Util.getDetailUsingZipCodeNew(
                false, context, parentZipController.text);

            final data = response1.data['results'][0]["address_components"];

            String city = "", state = "", country = "";
            if (data.length > 3) {
              city = data[data.length-3]['long_name'];
              state = data[data.length-2]['long_name'];
              country = data[data.length-1]['long_name'];
            } else if (data.length > 0) {
              //city=json[1]['long_name'];
              state = data[data.length-2]['long_name'];
              country = data[data.length-1]['long_name'];
            }

            address2=new Address ("", "", city, state, country,
                "","");
          } catch (e) {}
        }

        Map map = {
          "firstName": firstNameController.text,
          "lastName": "", //lastNameController.text,
          "mobileNo": phoneController.text,
          "companyId": companyid,
          "userId": userid,
          "roleId": 4,
          "name": companyNameController.text,
          "address": companyAddressController.text,
          "phone": companyPhoneController.text,
          "url": webUrlController.text,
          "about": aboutCompanyController.text.trim(),
          'gender':
              isParentGender == "Non-Binary" ? "NonBinary" : isParentGender,
          'zipCode': parentZipController.text,
          'countryCode': selectedCountryCode,
          "state":
              address2 != null ? address2.state : companyProfileModel.state,
          "city": address2 != null ? address2.city : companyProfileModel.city,
          "country":
              address2 != null ? address2.country : companyProfileModel.country,
          //"profilePicture":companyProfileModel.profilePicture,
          //"coverPicture":companyProfileModel.coverPicture ,
          // "offer": OfferModel.mapList(companyProfileModel.offers),
          "asset": AssetModel.mapList(assetModelMap),
          "businessCategory": CategoryModel.mapList(selectedCategoryList),
        };

        print("Apurva Updated map+++++++++" + map.toString());
        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_PARTNER_PROFILE, map);
        CustomProgressLoader.cancelLoader(context);
        isApiCalling = false;
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              syncDoneController.add("msg");
              showSucessMsgLong(msg, context);
            }
          }
        }
      } else {
        isApiCalling = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isApiCalling = false;
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    mediaImagesList.add(null);
    mediaVideosList.add(null);
    mediaDocumentList.add(null);
    callApiGetCategory();
    getSharedPrefrence();
    //callApiForSaas();
    setState(() {
      internship = !internship;
      // checkInOfferArray(offer, internship);
    });
    uploadMedia = UploadMedia(context);

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        Constant.CONTAINER_PARTNER +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";

    /*categoryController.addListener(() {
      if (categoryController.text.isEmpty) {
        setState(() {
          countries.clear();
        });
      } else {
        if (categoryController.text.trim().length >= 1) {
          initCountryList(searchCountryController.text.trim());
        }
      }
    });*/

    /*   mediaList.add("");
    docPaths.add("");
    videoList.add(null);

    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userid +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";*/
    super.initState();
  }

  getData() async {
    if (companyProfileModel.categoryModel != null &&
        companyProfileModel.categoryModel.length > 0) {
      bool first = true;
      for (var categoryModel in companyProfileModel.categoryModel) {
        print('categoryModel:::::: ${categoryModel.name}');

        selectedCategoryList.add(categoryModel);

        if (categoryModel.isOther) {
          selectedOtherOption.add(categoryModel.name);
          if (first) {
            print('first::: $first');
            selectedCategoryOption.add("Other");
            removedBusinessCategoryList.add(CategoryResult(
                businessCategoryId: categoryModel.businessCategoryId,
                name: "Other",
                description: "Other"));
            first = false;
          }
          isOtherSelected = true;
        } else {
          selectedCategoryOption.add(categoryModel.name);
          removedBusinessCategoryList.add(CategoryResult(
              businessCategoryId: categoryModel.businessCategoryId,
              name: categoryModel.name,
              description: categoryModel.name));
        }
      }

      if (removedBusinessCategoryList.length > 0) {
        businessCategoryList.clear();
      }
      /*List<double> first = [1,2,3,4,5,6,7];
    List<double> second = [3,5,6,7,9,10];
    List<double> output = [];//[1,2,4]
    first.forEach((element) {
      if(!second.contains(element)){
        output.add(element);
      }
    });*/

      print(
          'orignalBusinessCategoryList size:: ${orignalBusinessCategoryList.length}');
      print(
          'removedBusinessCategoryList size:: ${removedBusinessCategoryList.length}');
      print(
          'businessCategoryList before size:: ${businessCategoryList.length}');

      /*removedBusinessCategoryList.forEach((element) {
      if(!orignalBusinessCategoryList.contains(element)){
        businessCategoryList.add(element);
      }
    });*/

      /*List x = ['one' , 'two' , 'three' , 'four'];
    List y = ['one' , 'two',];
    List output = [];*/

      for (final e in orignalBusinessCategoryList) {
        bool found = false;
        for (final f in removedBusinessCategoryList) {
          if (e.businessCategoryId == f.businessCategoryId) {
            found = true;
            break;
          }
        }
        if (!found) {
          businessCategoryList.add(e);
        }
      }
      //print(output);

      print(
          'businessCategoryList after diff size:: ${businessCategoryList.length}');

      if (businessCategoryList.length > 0) {
        businessCategoryList.insert(
            0,
            CategoryResult(
                businessCategoryId: -1,
                name: 'Select All',
                description: 'Select All'));
      }
    } else {
      print(
          'inside else companyProfileModel.categoryModel size:: ${companyProfileModel.categoryModel.length}');
      print('inside else no category selected');
    }

    print('selectedCategoryList size:: ${selectedCategoryList.length}');
    print('businessCategoryList size:: ${businessCategoryList.length}');
    print('selectedOtherOption size:: ${selectedOtherOption.length}');
    print('selectedCategoryOption size:: ${selectedCategoryOption.length}');

    setState(() {
      mediaVideosList;
    });
  }

  void setData(CompanyProfileModel companyProfileModel) async {
    String firstName = '', lastname = '';
    //setState(() async {
    if (companyProfileModel.countryCode != null)
      selectedCountryCode = companyProfileModel.countryCode;

    if (companyProfileModel.firstName != null &&
        companyProfileModel.firstName != "null")
      firstName = companyProfileModel.firstName;

    if (companyProfileModel.lastName != null &&
        companyProfileModel.lastName != "null") {
      lastname = companyProfileModel.lastName;
    }

    firstNameController.text = firstName + " " + lastname;
    print('firstName:: $firstName, lastName:: $lastname');

    if (companyProfileModel.email != null)
      emailController.text = companyProfileModel.email;

    print('');

    if (companyProfileModel.mobileNo != null &&
        companyProfileModel.mobileNo != '0' &&
        companyProfileModel.mobileNo != 'null')
      phoneController.text = companyProfileModel.mobileNo;

    if (companyProfileModel.name != null && companyProfileModel.name != "null")
      companyNameController.text = companyProfileModel.name;

    if (companyProfileModel.address != null &&
        companyProfileModel.address != "null")
      companyAddressController.text = companyProfileModel.address;

    if (companyProfileModel.phone != null)
      companyPhoneController.text = companyProfileModel.phone;

    if (companyProfileModel.url != null)
      webUrlController.text = companyProfileModel.url;

    if (companyProfileModel.about != null)
      aboutCompanyController.text = companyProfileModel.about;

    parentZipController.text = companyProfileModel.zipCode == null ||
            companyProfileModel.zipCode == "null"
        ? "0"
        : companyProfileModel.zipCode;

    if (companyProfileModel.gender != null &&
        companyProfileModel.gender != "null" &&
        companyProfileModel.gender != "") {
      isParentGender = companyProfileModel.gender;
    }

    companyid = companyProfileModel.companyId;
    print("compant Id---------" + companyid);
    /* coverPicture=  companyProfileModel.coverPicture;
              profilePicture=  companyProfileModel.profilePicture;*/

    for (Assest assest in companyProfileModel.mediaList) {
      mediaImagesList.add(assest.file);
    }

    for (Assest assest in companyProfileModel.docList) {
      mediaDocumentList.add(assest.file);
    }

    for (Assest assest in companyProfileModel.googleLinkList) {
      googleDoclinkList.add(assest.file);
    }

    for (Assest assest in companyProfileModel.videoList) {
      //final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(Constant.IMAGE_PATH + assest.file);
      //mediaVideosList.add(new FileModel(thumbnailFile, assest.file));

      /*final thumbnailFile = await uploadMedia
            .getVideoThumbnailFromUrl(Constant.IMAGE_PATH + assest.file);*/

      mediaVideosList.add(new FileModel(new File(''), assest.file));
    }
    print('mediaVideosList size:: ${mediaVideosList.length}');

    // });

    //await getData();

    if (companyProfileModel.categoryModel != null &&
        companyProfileModel.categoryModel.length > 0) {
      bool first = true;
      for (var categoryModel in companyProfileModel.categoryModel) {
        print('categoryModel:::::: ${categoryModel.name}');

        selectedCategoryList.add(categoryModel);

        if (categoryModel.isOther) {
          selectedOtherOption.add(categoryModel.name);
          if (first) {
            print('first::: $first');
            selectedCategoryOption.add("Other");
            removedBusinessCategoryList.add(CategoryResult(
                businessCategoryId: categoryModel.businessCategoryId,
                name: "Other",
                description: "Other"));
            first = false;
          }
          isOtherSelected = true;
        } else {
          selectedCategoryOption.add(categoryModel.name);
          removedBusinessCategoryList.add(CategoryResult(
              businessCategoryId: categoryModel.businessCategoryId,
              name: categoryModel.name,
              description: categoryModel.name));
        }
      }

      if (removedBusinessCategoryList.length > 0) {
        businessCategoryList.clear();
      }
      /*List<double> first = [1,2,3,4,5,6,7];
    List<double> second = [3,5,6,7,9,10];
    List<double> output = [];//[1,2,4]
    first.forEach((element) {
      if(!second.contains(element)){
        output.add(element);
      }
    });*/

      print(
          'orignalBusinessCategoryList size:: ${orignalBusinessCategoryList.length}');
      print(
          'removedBusinessCategoryList size:: ${removedBusinessCategoryList.length}');
      print(
          'businessCategoryList before size:: ${businessCategoryList.length}');

      /*removedBusinessCategoryList.forEach((element) {
      if(!orignalBusinessCategoryList.contains(element)){
        businessCategoryList.add(element);
      }
    });*/

      /*List x = ['one' , 'two' , 'three' , 'four'];
    List y = ['one' , 'two',];
    List output = [];*/

      for (final e in orignalBusinessCategoryList) {
        bool found = false;
        for (final f in removedBusinessCategoryList) {
          if (e.businessCategoryId == f.businessCategoryId) {
            found = true;
            break;
          }
        }
        if (!found) {
          businessCategoryList.add(e);
        }
      }
      //print(output);

      print(
          'businessCategoryList after diff size:: ${businessCategoryList.length}');

      if (businessCategoryList.length > 0) {
        businessCategoryList.insert(
            0,
            CategoryResult(
                businessCategoryId: -1,
                name: 'Select All',
                description: 'Select All'));
      }
    } else {
      print(
          'inside else companyProfileModel.categoryModel size:: ${companyProfileModel.categoryModel.length}');
      print('inside else no category selected');
    }

    print('selectedCategoryList size:: ${selectedCategoryList.length}');
    print('businessCategoryList size:: ${businessCategoryList.length}');
    print('selectedOtherOption size:: ${selectedOtherOption.length}');
    print('selectedCategoryOption size:: ${selectedCategoryOption.length}');

    setState(() {
      mediaVideosList;
      orignalBusinessCategoryList;
      removedBusinessCategoryList;
      selectedCategoryList;
      businessCategoryList;
      selectedOtherOption;
      selectedCategoryOption;
    });

    CustomProgressLoader.cancelLoader(context);
  }

  bool isSelected(List<OfferModel> offers, int id) {
    for (OfferModel offerModel in offers) {
      if (offerModel.offerId == id) return true;
    }
    return false;
  }

/////////////////////////////////////////////

  Future callApiGetCategory() async {
    print('inside callApiGetCategory() ');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCallWithouAuth(
            context, Constant.ENDPOINT_GET_BUSINESS_CATEGORY_API, "get");

        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              BusinessCategoryResponse apiResponse =
                   BusinessCategoryResponse.fromJson(response.data);
              setState(() {
                businessCategoryList = apiResponse.result;
                /*for(int i; i<businessCategoryList.length; i++){
                  _categoryArray.insert(i+1, businessCategoryList[i].name);
                }*/
                if (businessCategoryList != null &&
                    businessCategoryList.isNotEmpty) {
                  orignalBusinessCategoryList.addAll(businessCategoryList);
                  businessCategoryList.insert(
                      0,
                      CategoryResult(
                          businessCategoryId: -1,
                          name: 'Select All',
                          description: 'Select All'));
                  //selectedCategory = businessCategoryList[0].name;
                  print(
                      'businessCategoryList[businessCategoryList.length - 1].businessCategoryId:: ${businessCategoryList[businessCategoryList.length - 1].businessCategoryId}');
                  //otherCategoryId = businessCategoryList[businessCategoryList.length - 1].businessCategoryId;

                }
              });

              print(
                  'Apurva businessCategoryList size::::: ${businessCategoryList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  List<Widget> getSelectedWidgets(List<String> selectedOption, String from) {
    List<Widget> widgets = [];
    for (String item in selectedOption) {
      print("Name+++++" + item);
      double width = item.length.toDouble() * 11;
      print('before width -> ' + width.toString());
      // if (width <= 60) {
      //   width = 80;
      // } else
      if (width > 100) {
        width = 100;
      }
      print('after width -> ' + width.toString());
      widgets.add(
        ControlledAnimation(
          duration: Duration(milliseconds: 1500),
          curve: Curves.linearToEaseOut,
          delay: Duration(milliseconds: 700),
          tween: Tween(begin: 0.0, end: width),
          builder: (context, value) {
            /* if (value <= 50) {
              return Container(
                height: 35,
                width: value + 5,
                margin: EdgeInsets.all(5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(
                    color: Palette.accentColor,
                  ),
                ),
              );
            } else*/
            return ControlledAnimation(
              duration: Duration(milliseconds: 500),
              curve: Curves.linearToEaseOut,
              delay: Duration(milliseconds: 700),
              tween: Tween(begin: 50.0, end: width),
              builder: (context, value) {
                print('Apurva getSelectedWidgets value:: $value');
                return Container(
                  margin: EdgeInsets.all(5),
                  child: Chip(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5),
                      side: BorderSide(
                        color: Palette.accentColor,
                      ),
                    ),
                    backgroundColor: Palette.white,
                    deleteIcon: value >= (width)
                        ? Icon(Icons.cancel, color: Palette.accentColor)
                        : Icon(Icons.cancel, color: Palette.accentColor),
                    onDeleted: () {
                      if (from == "mainCategory") {
                        if (businessCategoryList.length == 0) {
                          businessCategoryList.insert(
                              0,
                              CategoryResult(
                                  businessCategoryId: -1,
                                  name: 'Select All',
                                  description: 'Select All'));
                        }
                        if (item == 'Other') {
                          //setState(() {
                          isOtherSelected = false;
                          selectedOtherOption.clear();
                          isShowOtherMore = true;
                          //});
                        }
                        updateList(item);

                        setState(() {});
                      } else {
                        selectedOtherOption.remove(item);
                        selectedCategoryList.remove(item);
                        setState(() {});
                      }

                      /*print('onDeleted before selectedCategoryList size:: ${selectedCategoryList.length}');
                      for (var listItem in businessCategoryList) {
                        if(listItem.name == item){
                          selectedCategoryList.remove(listItem);
                        }
                      }
                      print('onDeleted after selectedCategoryList size:: ${selectedCategoryList.length}');*/
                      /*businessCategoryList.add(item);
                        businessCategoryList.sort((item1, item2) {
                          return item1.index.compareTo(item2.index);
                        });*/
                      showList = false;
                      setState(() {});
                    },
                    label: Container(
                      alignment: AlignmentDirectional.center,
                      /*height: item.name.length > 16 && item.name.length <= 40
                            ? 55
                            : item.name.length > 40 && item.name.length <= 50
                                ? 80
                                : item.name.length > 50 ? 110 : 30,*/
                      width: width,
                      //width: value + 5,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6.0),
                        child: Text(
                          item,
                          //'Address: 26/1 Brigade Gateway, Dr Rajkumar Rd 22nd Floor, Malleshwaram, Bengaluru, Karnataka 560055',
                          //'sd sdg sgersg rgesrgerge ergehe erhgethb erhrtdhbrtn ethrtnfrnfryn tnrnrnyn',
                          maxLines: 20,
                          softWrap: true,style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      );
    }
    return widgets;
  }

  businessCategoryListWidget() {
    //print('Apurva countryOrCityListWidget businessCategoryList size:: ${businessCategoryList.length}');
    /*businessCategoryList = removeAlreadyAddedItems(businessCategoryList, selectedCountries);
    setState(() {
      businessCategoryList;
    });*/
    //print('Apurva countryOrCityListWidget businessCategoryList size:: ${businessCategoryList.length}');
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? businessCategoryList.length > 0
                ? Card(
                    child: Container(
                      padding: businessCategoryList.length > 0
                          ? EdgeInsets.all(10)
                          : EdgeInsets.all(0),
                      child: AnimatedList(
                        key: _listKey,
                        initialItemCount: businessCategoryList.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index, animation) {
                          animation = CurvedAnimation(
                              curve: Curves.linear, parent: animation);

                          return _buildAddedItem(
                              businessCategoryList[index], animation, index);
                        },
                      ),
                    ),
                  )
                : Container()
            : Container(),
      ],
    );
  }

  Widget _buildAddedItem(CategoryResult item, Animation animation, int index) {
    return FadeTransition(
      opacity: animation,
      child: SizeTransition(
        axis: Axis.vertical,
        sizeFactor: animation,
        child: InkWell(
          onTap: () {
            //CustomProgressLoader.showLoader(context);
            print("item++++" + item.name);
            //displayPrediction(item.id, item.name, item.index);
            //_removeSingleItems(businessCategoryList.indexOf(item));

            if (businessCategoryList[index].name == 'Select All') {
              setState(() {
                isOtherSelected = true;
              });
              //getSelectedCategoryDetail(item.name);
              //selectedCategory = 'Select All';
              //selectedCategoryOption.clear();
              //removedBusinessCategoryList.clear();
              for (item in businessCategoryList) {
                if (item.name != 'Select All')
                  selectedCategoryOption.add(item.name);
                removedBusinessCategoryList.add(item);
              }
              businessCategoryList.clear();
            } else {
              if (businessCategoryList[index].name == 'Other') {
                setState(() {
                  isOtherSelected = true;
                });
              }
              //getSelectedCategoryDetail(item.name);
              removedBusinessCategoryList.add(businessCategoryList[index]);
              //selectedCategory = businessCategoryList[index].name;

              selectedCategoryOption.add(businessCategoryList[index].name);
              if (businessCategoryList.length > 0)
                businessCategoryList.removeAt(index);
            }

            showList = !showList;
            //searchCountryController.clear();
            setState(() {});
            setState(() {
              isBusinessCategoryError = false;
              bottomViewColor = Palette.dividerColor;
            });
          },
          child: AnimatedContainer(
            curve: Curves.easeIn,
            duration: Duration(milliseconds: 500),
            width: MediaQuery.of(context).size.width,
            child: Text(item.name,style: TextStyle(fontFamily: Constant.customRegular)),
            padding: EdgeInsets.all(8),
          ),
        ),
      ),
    );
  }

  selectOtherCategoryTextField() {
    String name = '';
    String help = '';
    if (selectedOtherOption.length == 0) {
      name = "Other Business Category";
      help = "Other Business Category";
    }
    setState(() {
      name;
      help;
    });
    return TextFormField(
      /*decoration: textFormFieldDecorationWithNoBorders(
          'Other'),*/
      cursorColor: ColorValues.GREY_TEXT_COLOR,
      decoration: textFormFieldDecorationWithHint(
          name, ImagePath.ICON_COMPANY, 23, 23, help),
      controller: categoryController, style: TextStyle(
        fontFamily: Constant.TYPE_CUSTOMREGULAR),
      onChanged: (value) {},
      textInputAction: TextInputAction.done,
      focusNode: _otherCategoryFocus,
      autocorrect: false,
      onFieldSubmitted: (term) {
        _otherCategoryFocus.unfocus();
        if (categoryController.text != null && categoryController.text != "") {
          if (!selectedOtherOption.contains(categoryController.text)) {
            selectedOtherOption.add(categoryController.text);
          }
        }
        //getSelectedCategoryDetail('Other');
        //selectedCategoryList.add(new CategoryModel(categoryController.text,otherCategoryId, true));
        categoryController.clear();
        setState(() {});
      },
      validator: (String arg) {
        if (selectedOtherOption.length > 0) {
          return null;
        } else {
          return MessageConstant.ENTER_OTHER_BUSINESS_CATE_VAL;
        }
      },
    );
  }

  void getSelectedCategoryDetail() {
    print('getSelectedCategoryDetail() ');
    selectedCategoryList.clear();
    for (var selectedItem in selectedCategoryOption) {
      print(
          'getSelectedCategoryDetail() inside loop businessCategoryList size:: ${businessCategoryList.length}');
      //if(selectedCatOption == item.name){
      for (var item in orignalBusinessCategoryList) {
        if (item.name == selectedItem) {
          //CategoryResult categoryResult = ;
          if (selectedItem != 'Other') {
            CategoryModel categoryModel =  CategoryModel(
                name: item.name,
                businessCategoryId: item.businessCategoryId,
                isOther: false);
            selectedCategoryList.add(categoryModel);
          } else {
            for (var option in selectedOtherOption) {
              CategoryModel categoryModel =  CategoryModel(
                  name: option,
                  businessCategoryId: item.businessCategoryId,
                  isOther: true);
              selectedCategoryList.add(categoryModel);
            }
          }
        }
      }

      //}
    }
    print(
        'inside getSelectedCategoryDetail() selectedCategoryList size:: ${selectedCategoryList.length}');
  }

  void updateList(String item) {
    print('inside updateList');
    for (var removeitem in removedBusinessCategoryList) {
      print('inside updateList removeitem name:: ${removeitem.name}');
      if (item == removeitem.name) {
        print('update this inside name:: ${removeitem.name}');
        businessCategoryList.add(removeitem);
        removedBusinessCategoryList.remove(removeitem);
        selectedCategoryOption.remove(item);
      }
    }
    setState(() {});
  }

  void generateChipsForOther() {
    if (categoryController.text != null && categoryController.text != "") {
      if (!selectedOtherOption.contains(categoryController.text)) {
        selectedOtherOption.add(categoryController.text);
      }
    }
    categoryController.clear();
    setState(() {});
  }
}
