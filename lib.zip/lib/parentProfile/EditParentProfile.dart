import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geocoder/model.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/LocationData.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';


// to get places detail (lat/lng)
GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey:  Constant.kGoogleApiKey);

// Create a Form Widget
class EditParentProfile extends StatefulWidget {
  @override
  EditParentProfileState createState() {
    return  EditParentProfileState();
  }
}

class EditParentProfileState extends State<EditParentProfile> {
  SharedPreferences prefs;
  String userIdPref, token;
  final _formKey = GlobalKey<FormState>();
  TextEditingController firstNameController,
      lastNameController,
      emailController,
      add1Controller,
      add2Controller,
      cityController,
      stateController,
      zipController,
      dobController,
      countryController;
  String strFirstName,
      strLastName,
      strEmmail,
      strAdd1,
      strAdd2,
      strCity,
      strState,
      strZipcode,
      strCountry;
  ProfileInfoModal profileInfoModal;
  Mode _mode = Mode.fullscreen;
  String zipCodePrevious = "";
  bool isApiCalling = false;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    profileApi();
  }

  FocusNode parentZipcodeFocusNode = FocusNode();

  String isParentGender = "";

  @override
  void initState() {
    super.initState();
    firstNameController =  TextEditingController(text: "");
    lastNameController =  TextEditingController(text: "");
    emailController =  TextEditingController(text: "");
    add1Controller =  TextEditingController(text: "");
    add2Controller =  TextEditingController(text: "");
    cityController =  TextEditingController(text: "");
    stateController =  TextEditingController(text: "");
    zipController =  TextEditingController(text: "");
    countryController =  TextEditingController(text: "");
    getSharedPreferences();

  }

//--------------------------Profile Info api ------------------
  Future profileApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                firstNameController.text = profileInfoModal.firstName == "null"
                    ? ""
                    : profileInfoModal.firstName;
                lastNameController.text = profileInfoModal.lastName == "null"
                    ? ""
                    : profileInfoModal.lastName;
                emailController.text = profileInfoModal.email;
                prefs.setString(UserPreference.ISHide, profileInfoModal.isHide);
                add1Controller.text = profileInfoModal.address.street1;
                add2Controller.text = profileInfoModal.address.street2;
                cityController.text = profileInfoModal.address.city;
                stateController.text = profileInfoModal.address.state;

                zipController =  TextEditingController(
                    text: profileInfoModal.address.zip == "" ||
                            profileInfoModal.address.zip == "null"
                        ? profileInfoModal.zipCode=="null"?"0":profileInfoModal.zipCode
                        : profileInfoModal.address.zip);

                /*zipCodePrevious = profileInfoModal.address.zip == "" ||
                        profileInfoModal.address.zip == "null"
                    ? profileInfoModal.zipCode=="null"?"0":profileInfoModal.zipCode
                    : profileInfoModal.address.zip;*/
                zipCodePrevious = zipController.text;

                if (profileInfoModal.dob == null ||
                    profileInfoModal.dob == "") {
                  dobController =  TextEditingController(text: "");
                } else {
                  DateTime date =  DateTime.fromMillisecondsSinceEpoch(
                      int.tryParse(profileInfoModal.dob));
                  dobController =  TextEditingController(
                      text:  DateFormat("MMM dd, yyyy").format(date));
                }
                countryController.text = profileInfoModal.address.country;
                if (profileInfoModal.gender != null &&
                    profileInfoModal.gender != "null" &&
                    profileInfoModal.gender != "") {
                  isParentGender = profileInfoModal.gender;
                }

                setState(() {
                  firstNameController;
                  profileInfoModal;
                  add1Controller;
                  add2Controller;
                  cityController;
                  stateController;
                  zipController;
                  countryController;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditParentProfile",context);
      e.toString();
    }
  }

  showSucessMsgLong(msg, context) {
    Timer _timer;

    print("timer on");
    _timer =  Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");

      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {},
            child:  GestureDetector(
              child:  Scaffold(
                backgroundColor: Colors.transparent,
                body:  Stack(
                  children: <Widget>[
                     Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child:  Container(
                          height: 65.0,
                          padding:  EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color:  Color(0xffF1EDC3),
                          child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style:  TextStyle(
                                        color:  Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  //--------------------------Api Calling ------------------
  Future apiCallingForEdit() async {
    print('apurva address2.country:: apiCallingForEdit()');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        isApiCalling = true;
        LocationData address2;
        if (zipCodePrevious != zipController.text) {
          try {
            Response response1 = await Util.getDetailUsingZipCodeNew(
                false, context, zipController.text);

            //apurva added for zip code validation start
            if(response1 == null){
              print('apurva address2.country:: response:: $response1');
              //CustomProgressLoader.cancelLoader(context);
              isApiCalling = false;
              ToastWrap.showToast2Sec(MessageConstant.ENTER_VALID_ZIP_CODE_VAL, context);
              return;
            }else{
              print('apurva address2.country:: response:: elseee $response1');
            }
            //apurva added for zip code validation end

            final data = response1.data['results'][0]["address_components"];

            if (data.length > 3) {


              cityController.text = data[data.length-3]['long_name'];
              stateController.text = data[data.length-2]['long_name'];
              countryController.text = data[data.length-1]['long_name'];
            } else if (data.length > 0) {
              //city=json[1]['long_name'];
              stateController.text = data[data.length-2]['long_name'];
              countryController.text = data[data.length-1]['long_name'];
            }



          } catch (e) {
            crashlytics_bloc.recordCrashlyticsError(e,"EditParentProfile",context);
          }
        }


        Map map = {
          "userId": int.parse(userIdPref),
          "firstName": firstNameController.text,
          "lastName": lastNameController.text,
          "roleId": 2,
          "isActive": profileInfoModal.isActive,
          'gender': isParentGender=="Non-Binary"?"NonBinary":isParentGender,
          'zipCode': zipController.text,
          "city": cityController.text,
          "state": stateController.text,
          "country": countryController.text,
          "address": {
            "street1": add1Controller.text,
            "street2": add2Controller.text,
            "city": cityController.text,
            "state": stateController.text,
            "country": countryController.text,
            "zip": zipController.text
          }
        };
        print("gender:-" + map.toString());
        response = await  ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_USER_COVER_PHOTO_UPDATE, map);
        print("response:-" + response.toString());
        isApiCalling = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              showSucessMsgLong(msg, context);
            }
          }
        }
      } else {
        isApiCalling = false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditParentProfile",context);
      isApiCalling = false;
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above
    Text getTextLabel(txt, size, color, fontWeight) {
      return  Text(
        txt,
        style:
             TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Padding getParentGender() {
      return PaddingWrap.paddingAll(
          5.0,
           Row(
            children: <Widget>[
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 35.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "Male"
                              ? "assets/newDesignIcon/male_blue.png"
                              : "assets/newDesignIcon/male.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "Male",
                            13.0,
                            isParentGender == "Male"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "Male";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 35.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "Female"
                              ? "assets/newDesignIcon/female.png"
                              : "assets/newDesignIcon/female_grey.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "Female",
                            13.0,
                            isParentGender == "Female"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "Female";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 35.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "Non-Binary"
                              ? "assets/newDesignIcon/binary_blue.png"
                              : "assets/newDesignIcon/non_binary.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "Non-Binary",
                            13.0,
                            isParentGender == "Non-Binary"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "Non-Binary";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
               Container(
                  padding:  EdgeInsets.fromLTRB(0.0, 20.0, 20.0, 20.0),
                  child:  InkWell(
                    child:  Stack(children: <Widget>[
                       Column(children: <Widget>[
                         Image.asset(
                          isParentGender == "NA"
                              ? "assets/newDesignIcon/na_blue.png"
                              : "assets/newDesignIcon/na.png",
                          width: 22.0,
                          height: 22.0,
                        ),
                        getTextLabel(
                            "NA",
                            13.0,
                            isParentGender == "NA"
                                ?  ColorValues.BLUE_COLOR_BOTTOMBAR
                                :  ColorValues.GREY_TEXT_COLOR,
                            FontWeight.normal),
                      ]),
                    ]),
                    onTap: () {
                      isParentGender = "NA";
                      setState(() {
                        isParentGender;
                      });
                    },
                  )),
            ],
          ));
    }

    final dateOBUI =  InkWell(
      child:  Container(
          child:  Column(
        children: <Widget>[
           TextField(
            keyboardType: TextInputType.text,
            controller: dobController,
            style:  TextStyle(
                color:  ColorValues.HEADING_COLOR_EDUCATION,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            decoration:  InputDecoration(
              border: InputBorder.none,
              enabled: false,
              contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
              hintText: "Date of Birth",
              labelText: "Date of Birth",errorStyle: Util.errorTextStyle,
              labelStyle:  TextStyle(
                  color:  ColorValues.GREY_TEXT_COLOR,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              enabledBorder: null,
              focusedBorder: null,
            ),
          ),
           Container(
            height: 1.0,
            color: ColorValues.DARK_GREY,
          )
        ],
      )),
    );
    final firnameUi =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          controller: firstNameController,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
          decoration:  InputDecoration(
            fillColor: Colors.transparent,
            labelText: "First Name",errorStyle: Util.errorTextStyle,
            counterText: "",
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          validator: (val) => val.trim().length == 0
              ? MessageConstant.ENTER_FIRST_NAME_VAL
              : !ValidationWidget.isName(val)
                  ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                  : null,
          onSaved: (val) => strFirstName = val,
        ));

    final lastNameui =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          controller: lastNameController,
          maxLength: TextLength.FIRST_AND_LAST_NAME_MAX_LENGTH,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          decoration:  InputDecoration(
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            counterText: "",
            fillColor: Colors.transparent,
            labelText: "Last Name",errorStyle: Util.errorTextStyle,
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          validator: (val) => val.trim().length == 0
              ? MessageConstant.ENTER_LAST_NAME_VAL
              : !ValidationWidget.isName(val)
                  ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                  : null,
          onSaved: (val) => strFirstName = val,
        ));

    final email =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          controller: emailController,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          enabled: false,
          decoration:  InputDecoration(
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            fillColor: Colors.transparent,
            hintText: "Email",errorStyle: Util.errorTextStyle,
            labelText: "Email",
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          onSaved: (val) => strFirstName = val,
        ));

    final add1 =  Column(
      children: <Widget>[
         Container(
            padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
            child:  InkWell(
              child:  Center(
                  child:  TextFormField(
                keyboardType: TextInputType.text,
                cursorColor: Constant.CURSOR_COLOR,
                maxLines: null,
                style:  TextStyle(
                    color:  ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16.0,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                controller: add1Controller,
                textCapitalization: TextCapitalization.sentences,
                enabled: false,
                decoration:  InputDecoration(
                    hintText: "Street Address 1",
                    enabledBorder: UnderlineInputBorder(
                      borderSide:
                      BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
                    ),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: ColorValues.DARK_GREY,width: 1.0)),
                    labelText: "Street Address 1",errorStyle: Util.errorTextStyle,
                    contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                    labelStyle:  TextStyle(
                        color:  ColorValues.GREY_TEXT_COLOR,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    hintStyle:  TextStyle(color: ColorValues.hintColor),
                    fillColor: Colors.transparent),
                onSaved: (val) => strAdd1 = val,
              )),
              onTap: () {
                _handlePressButton();
              },
            )),
         Container(
          height: 1.0,
          color: ColorValues.DARK_GREY,
        )
      ],
    );

    final add2 =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          controller: add2Controller,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          decoration:  InputDecoration(
            labelText: "Street Address 2",errorStyle: Util.errorTextStyle,
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
            fillColor: Colors.transparent,
          ),
          onSaved: (val) => strAdd2 = val,
        ));

    final city =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          textCapitalization: TextCapitalization.sentences,
          controller: cityController,
          decoration:  InputDecoration(
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            fillColor: Colors.transparent,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            labelText: "City",errorStyle: Util.errorTextStyle,
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          onSaved: (val) => strCity = val,
        ));

    final state =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          controller: stateController,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          decoration:  InputDecoration(
            fillColor: Colors.transparent,
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            labelText: "State",errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          onSaved: (val) => strState = val,
        ));

    final zipcode =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          focusNode: parentZipcodeFocusNode,
          validator: (val) =>
          !ValidationWidget.isZipCode(val)
              ? MessageConstant.ENTER_VALID_ZIP_CODE_VAL
              : null,
          controller: zipController,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          decoration:  InputDecoration(
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            fillColor: Colors.transparent,
            labelText: "Zip Code",errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          onSaved: (val) => strZipcode = val,
        ));

    final country =  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 25.0, 0.0, 0.0),
        child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: countryController,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              fontSize: 16.0),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            contentPadding:  EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            fillColor: Colors.transparent,
            labelText: "Country",errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
              BorderSide(color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY,width: 1.0)),
            labelStyle:  TextStyle(
              color:  ColorValues.GREY_TEXT_COLOR,
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
            ),
          ),
          onSaved: (val) => strCountry = val,
        ));

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child:  Scaffold(
                backgroundColor:  ColorValues.SCREEN_BG_COLOR,
                appBar:  AppBar(
                  brightness: Brightness.light,
                  automaticallyImplyLeading: false,
                  titleSpacing: 0.0,
                  elevation: 0.0,
                  title:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                       Expanded(
                        child:  InkWell(
                          child: CustomViews.getBackButton(),
                          onTap: () {
                            Navigator.pop(context);
                          },
                        ),
                        flex: 0,
                      ),
                       Expanded(
                        child:  Text(
                          "My Detail",
                          textAlign: TextAlign.center,
                          style:  TextStyle(
                              color:  ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 18.0,
                              fontFamily:Constant.TYPE_CUSTOMREGULAR),
                        ),
                        flex: 1,
                      )
                    ],
                  ),
                  actions: <Widget>[
                     Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                         InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              5.0,
                              13.0,
                              0.0,
                              TextViewWrap.textView(
                                  "Save",
                                  TextAlign.start,
                                   ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  16.0,
                                  FontWeight.normal)),
                          onTap: () {
                            final form = _formKey.currentState;
                            form.save();
                            if (form.validate()) {
                              if (!isApiCalling) apiCallingForEdit();
                            }
                          },
                        )
                      ],
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                body: FormKeyboardActions(
                    nextFocus: false,
                    keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                    //optional
                    keyboardBarColor: Colors.grey[200],
                    //optional
                    actions: [
                      KeyboardAction(
                        focusNode: parentZipcodeFocusNode,
                      ),
                    ],
                    child:  Theme(
                        data:  ThemeData(hintColor: Colors.grey[300]),
                        child: Form(
                            key: _formKey,
                            child:  Container(
                                color: Colors.white,
                                child:  Stack(
                                  children: <Widget>[
                                     Positioned(
                                        bottom: 0.0,
                                        left: 0.0,
                                        top: 0.0,
                                        right: 0.0,
                                        child:  Column(
                                          children: <Widget>[
                                            CustomViews.getSepratorLine(),
                                             Expanded(
                                                child:  ListView(
                                              children: <Widget>[
                                                PaddingWrap.paddingAll(
                                                    13.0,
                                                    Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          firnameUi,
                                                          lastNameui,
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  10.0,
                                                                  0.0,
                                                                  0.0,
                                                                  email),
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  10.0,
                                                                  0.0,
                                                                  0.0,
                                                                  dateOBUI),
                                                          add1,
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            add2,
                                                          ),
                                                           Row(
                                                            children: <Widget>[
                                                               Expanded(
                                                                child:
                                                                     Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .end,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    city,
                                                                  ],
                                                                ),
                                                                flex: 4,
                                                              ),
                                                               Expanded(
                                                                child:
                                                                     Container(),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:
                                                                     Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    state,
                                                                  ],
                                                                ),
                                                                flex: 4,
                                                              )
                                                            ],
                                                          ),
                                                           Row(
                                                            children: <Widget>[
                                                               Expanded(
                                                                child:
                                                                     Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .end,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    zipcode,
                                                                  ],
                                                                ),
                                                                flex: 4,
                                                              ),
                                                               Expanded(
                                                                child:
                                                                     Container(),
                                                                flex: 1,
                                                              ),
                                                               Expanded(
                                                                child:
                                                                     Column(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    country,
                                                                  ],
                                                                ),
                                                                flex: 4,
                                                              )
                                                            ],
                                                          ),
                                                          PaddingWrap.paddingfromLTRB(
                                                              0.0,
                                                              20.0,
                                                              0.0,
                                                              0.0,
                                                              getTextLabel(
                                                                  "I identify my gender as:",
                                                                  14.0,
                                                                   ColorValues.HEADING_COLOR_EDUCATION,
                                                                  FontWeight
                                                                      .normal)),
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  getParentGender()),
                                                        ]))
                                              ],
                                            ))
                                          ],
                                        )),
                                  ],
                                ))))))));
  }

  void onError(PlacesAutocompleteResponse response) {
    homeScaffoldKey.currentState.showSnackBar(
      SnackBar(content: Text(response.errorMessage)),
    );
  }

  Future<void> _handlePressButton() async {
    // show input autocomplete with selected mode
    // then get the Prediction selected
    Prediction p = await PlacesAutocomplete.show(
      context: context,
      apiKey:  Constant.kGoogleApiKey,
      onError: onError,
      hint: "Search here..",
      logo:  Image.asset("assets/logo"),
      mode: _mode,
      components: [
        Component(Component.country, "ind"),
        Component(Component.country, "uk"),
        Component(Component.country, "usa"),
      ],
    );

    displayPrediction(p, homeScaffoldKey.currentState);
  }

  Future<Null> displayPrediction(Prediction p, ScaffoldState scaffold) async {
    if (p != null) {
      // get detail (lat/lng)
      PlacesDetailsResponse detail =
          await _places.getDetailsByPlaceId(p.placeId);
      final lat = detail.result.geometry.location.lat;

      final lng = detail.result.geometry.location.lng;
      List<String> s = p.description.split(",");
      //Locale locale = p.getLocale();

      print("addres:-" + s.last);
      print("addres:-" + s.toString());
      print("addres:-" + p.description);

      final coordinates =  Coordinates(lat, lng);
      var addresses =
          await Geocoder.local.findAddressesFromCoordinates(coordinates);
      var first = addresses.first;
      String postalCode = first.postalCode;
      print('Apurva postalCode val:: $postalCode');

      print("${first.coordinates} : ${first.thoroughfare}");
      print("${first.addressLine} : ${first.adminArea}");
      print("${first.countryName} : ${first.postalCode}");
      print("${first.locality} : ${first.subLocality}");
      print("${first.adminArea} : ${first.subAdminArea}");


      //print("${first.thoroughfare} :" + "zip" + "${first.subThoroughfare}");
      //print("zipcode:- ${first.postalCode}, ${first.thoroughfare}, ${first.subThoroughfare}");
      setState(() {

        add1Controller.text =
            first.addressLine != null && p.description != "null"
                ? p.description
                : "";
        add2Controller.text =
            first.subLocality != null && first.subLocality != "null"
                ? first.subLocality
                : "";
        cityController.text =
            first.subAdminArea != null && first.subAdminArea != "null"
                ? first.subAdminArea
                : "";
        stateController.text =
            first.adminArea != null && first.adminArea != "null"
                ? first.adminArea
                : "";
        countryController.text =
            first.countryName != null && first.countryName != "null"
                ? first.countryName
                : "";
        zipController.text =
        first.postalCode != null && first.postalCode != "null"
            ? first.postalCode
            : "";

        zipCodePrevious = zipController.text;


        /*zipController.text =
        '${first.postalCode}' != null && '${first.postalCode}' != "null"
            ? '${first.postalCode}'
            : "";*/

      });
      print('Apurva zipCode:: ${zipController.text}');
      print('Apurva postalCode:: ${first.postalCode}');
      /*  scaffold.showSnackBar(
        SnackBar(content: Text("${p.description} - $lat/$lng")),
      );*/
    }
  }
}
