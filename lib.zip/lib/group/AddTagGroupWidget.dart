import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class AddTagGroupWidget extends StatefulWidget {
  String title;
  String groupId;
  List<TagModel> selectedUerTagLIst1;

  AddTagGroupWidget(this.title, this.groupId, this.selectedUerTagLIst1);

  @override
  AddTagGroupWidgetState createState() {
    return AddTagGroupWidgetState();
  }
}

class AddTagGroupWidgetState extends State<AddTagGroupWidget> {
  List<MemberModelDetail> tagList = List();
  List<GroupDetailModel> groupList = List();
  List<bool> selectedCheckedList = List();
  var isButtonEnable = false;
  List<MemberModelDetail> filteredRecored = List();
  List<TagModel> selectedUerId = List();
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, roleId;

  // Variables for Search
  TextEditingController _textController = TextEditingController();
  bool isLoading = true;
  bool cross = false;

  //--------------------------api Calling for tag------------------
  Future apiCallingForTag() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GROUP_MEMBER_LIST +
                widget.groupId +
                "/" +
                userIdPref,
            "get");

        print("Group+++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupList.clear();
              filteredRecored.clear();
              tagList.clear();
              groupList = ParseJson.parseGroupDetailMap2(
                  response.data['result'], userIdPref);
              if (groupList.length > 0) {
                for (int i = 0; i < groupList[0].memberList.length; i++) {
                  if (groupList[0].memberList[i].isActive == "true") {
                    tagList.add(groupList[0].memberList[i]);
                  }
                }

                if (!widget.selectedUerTagLIst1.isEmpty) {
                  for (int k = 0; k < widget.selectedUerTagLIst1.length; k++) {
                    for (int j = 0; j < tagList.length; j++) {
                      if (tagList[j].userId ==
                          widget.selectedUerTagLIst1[k].userId) {
                        tagList[j].isSelected = true;
                      }
                    }
                  }
                }

                setState(() {
                  filteredRecored.addAll(tagList);
                });
              }
            }
          }
        }
        setState(() {
          isLoading = false;
        });
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    apiCallingForTag();
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  void updateSearchQuery(String newQuery) {
    filteredRecored.clear();
    if (newQuery.length > 0) {
      Set<MemberModelDetail> set = Set.from(tagList);
      set.forEach((element) => filterList(element, newQuery));
    }
    if (newQuery.isEmpty) {
      filteredRecored.addAll(tagList);
    }
    setState(() {});
  }

  //Filtering the list item with found match string.
  filterList(MemberModelDetail model, String searchQuery) {
    setState(() {
      if (model.firstName.toLowerCase().contains(searchQuery) ||
          model.firstName.contains(searchQuery)) {
        filteredRecored.add(model);
      }
    });
  }

  onTapOkBtn() {
    for (int i = 0; i < tagList.length; i++) {
      if (tagList[i].isSelected)
        selectedUerId.add(new TagModel(
          tagList[i].userId,
          tagList[i].firstName,
          tagList[i].lastName,
          tagList[i].email,
          tagList[i].profilePicture,
          tagList[i].isSelected,
          tagList[i].roleId,
          tagList[i].badge,
          tagList[i].gamificationPoints,
          tagList[i].badgeImage,
        ));
    }
    print("size  " + selectedUerId.length.toString());
    Navigator.pop(context, selectedUerId);
  }

  Widget tagListItem(position) {
    return Padding(
        padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
        child: Row(
          children: <Widget>[
            Container(
              height: 48.0,
              width: 48.0,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: FadeInImage(
                  fit: BoxFit.cover,
                  placeholder: AssetImage(
                    'assets/profile/user_on_user.png',
                  ),
                  image: NetworkImage(Constant.IMAGE_PATH_SMALL +
                      ParseJson.getSmallImage(
                          filteredRecored[position].profilePicture)),
                ),
              ),
            ),
            Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    12.0,
                    0.0,
                    0.0,
                    0.0,
                    TextViewWrap.textView(
                        filteredRecored[position].lastName == "" ||
                                filteredRecored[position].lastName == "null"
                            ? filteredRecored[position].firstName
                            : filteredRecored[position].firstName +
                                " " +
                                filteredRecored[position].lastName,
                        TextAlign.start,
                        ColorValues.HEADING_COLOR_EDUCATION,
                        14.0,
                        FontWeight.bold)),
                flex: 1),
            Expanded(
                child: SizedBox(
                    width: 30.0,
                    height: 30.0,
                    child: Theme(
                      data: ThemeData(
                        unselectedWidgetColor: Colors.transparent,
                      ),
                      child: InkWell(
                        child: Padding(
                            padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 5.0),
                            child: Row(
                              children: <Widget>[
                                filteredRecored[position].isSelected
                                    ? Expanded(
                                        child: Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0, 0.0, 0.0, 0.0),
                                            child: Image.asset(
                                              "assets/feed/checkedBox.png",
                                              height: 20.0,
                                              width: 20.0,
                                            )),
                                        flex: 0)
                                    : Expanded(
                                        child: Padding(
                                            padding: EdgeInsets.fromLTRB(
                                                0.0, 0.0, 0.0, 0.0),
                                            child: Image.asset(
                                              "assets/feed/unCheckedBox.png",
                                              height: 20.0,
                                              width: 20.0,
                                            )),
                                        flex: 0),
                              ],
                            )),
                        onTap: () {
                          bool value = filteredRecored[position].isSelected;

                          if (value) {
                            filteredRecored[position].isSelected = false;
                            selectedCheckedList.remove(true);
                          } else {
                            filteredRecored[position].isSelected = true;
                            selectedCheckedList.add(true);
                          }

                          setState(() {
                            filteredRecored[position].isSelected;
                            if (selectedCheckedList.length != 0) {
                              isButtonEnable = true;
                            } else {
                              isButtonEnable = false;
                            }
                          });
                        },
                      ),
                    )),
                flex: 0),
          ],
        ));
  }

  addButton() {
    return Container(
      margin: EdgeInsets.fromLTRB(20, 15, 20, 30),
      height: 44.0,
      child: FlatButton(
        onPressed: () {
          if (isButtonEnable) {
            onTapOkBtn();
          }
        },
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        color: isButtonEnable
            ? AppConstants.colorStyle.lightBlue
            : AppConstants.colorStyle.lightBlueButtonDisableColor,
        child: Row(
          // Replace with a Row for horizontal icon + text
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Add',
                style: AppConstants.txtStyle.heading18600LatoRegularWhite),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;

    return Scaffold(
      bottomNavigationBar:
          tagList.length == 0 ? const SizedBox.shrink() : addButton(),
      backgroundColor: ColorValues.WHITE,
      body: Container(
        height: double.infinity,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
              "assets/generateScript/script_background.png",
            ),
            fit: BoxFit.fill,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 40, 20, 23),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Image.asset(
                      "assets/generateScript/back.png",
                      height: 32.0,
                      width: 32.0,
                    ),
                  ),
                  const HelpButtonWidget(),
                ],
              ),
            ),
            Expanded(
              child: Container(
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(30),
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: isLoading
                ? Center()
                :tagList?.isNotEmpty ?? false
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const SizedBox(height: 25),
                          Text(
                            AppConstants.stringConstant.selectToTag,
                            style: AppConstants
                                .txtStyle.heading28700LatoRegularDarkBlue,
                          ),
                          const SizedBox(height: 24),
                          Container(
                              height: 45.0,
                              decoration: BoxDecoration(
                                color: AppConstants.colorStyle.tabBg,
                                border: Border.all(
                                    color: AppConstants.colorStyle.btnBg),
                                borderRadius:
                                    const BorderRadius.all(Radius.circular(10)),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.only(left: 15),
                                child: TextField(
                                  cursorColor: Constant.CURSOR_COLOR,
                                  controller: _textController,
                                  decoration: InputDecoration(
                                      enabledBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                        ),
                                      ),
                                      focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                        ),
                                      ),
                                      hintText: 'Search',
                                      suffixIcon: _textController.text.length >
                                              0
                                          ? Padding(
                                              padding: EdgeInsets.all(0.0),
                                              child: InkWell(
                                                child: Icon(Icons.cancel,
                                                    color: Colors.black26),
                                                onTap: () {
                                                  setState(() {
                                                    _textController.text = "";
                                                    updateSearchQuery("");
                                                  });
                                                },
                                              ),
                                            )
                                          : Padding(
                                              padding: EdgeInsets.all(12.0),
                                              child: Image.asset(
                                                "assets/feed/search.png",
                                              ),
                                            )),
                                  onChanged: updateSearchQuery,
                                ),
                              )),
                          const SizedBox(height: 5),
                          filteredRecored.length > 0
                              ? Expanded(
                                  child: ListView(
                                    shrinkWrap: true,
                                    padding: EdgeInsets.zero,
                                    children: List.generate(
                                        filteredRecored.length, (int position) {
                                      return tagListItem(position);
                                    }),
                                  ),
                                )
                              : PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  30.0,
                                  0.0,
                                  0.0,
                                  TextViewWrap.textViewMultiLine(
                                      "No Data Found.",
                                      TextAlign.center,
                                      ColorValues.GREY_TEXT_COLOR,
                                      16.0,
                                      FontWeight.normal,
                                      2)),
                        ],
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: 120.0,
                            height: 111.0,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                    'assets/newDesignIcon/connections/man_to_guide.png'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Center(
                            child: Text(
                              "No connections found",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontSize: 18.0,
                                  fontFamily: Constant.latoRegular),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
