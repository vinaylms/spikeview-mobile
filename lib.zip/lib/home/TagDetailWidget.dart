import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parentProfile/ParentProfileWithHeader.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';

// Create a Form Widget
class TagDetailWidget extends StatefulWidget {
  List<Tags> tagList;

  TagDetailWidget(this.tagList);

  @override
  TagDetailWidgetState createState() {
    return  TagDetailWidgetState(tagList);
  }
}

class TagDetailWidgetState extends State<TagDetailWidget> {
  List<Tags> tagList;
  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, userProfilePath;

  TagDetailWidgetState(this.tagList);

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above

    return  customAppbar(
        context,
        GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, right: 20, top: 24, bottom: 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        BaseText(
                          text: 'Tagged connections',
                          textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontFamily: AppConstants.stringConstant.latoMedium,
                          fontWeight: FontWeight.w700,
                          fontSize: 28,
                          textAlign: TextAlign.start,
                          maxLines: 3,
                        ),
                      ],
                    ),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child:  ListView.builder(
                      itemCount: tagList.length,
                      itemBuilder: (BuildContext context, int position) {
                        return  Padding(
                            padding:  EdgeInsets.only(left:10.0,right: 10),
                            child:  InkWell(
                              child:  Column(
                                children: [
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: <Widget>[



                                      Expanded(
                                        child: PaddingWrap.paddingfromLTRB(
                                          10.0,
                                          10.0,
                                          10.0,
                                          10.0,
                                          ProfileImageView(
                                            imagePath: Constant.IMAGE_PATH_SMALL +
                                                ParseJson.getSmallImage(
                                                    tagList[position].profilePicture),
                                            placeHolderImage: 'assets/profile/user_on_user.png',
                                            height: 50.0,
                                            width: 50.0,
                                            onTap: () async{

                                            },
                                          ),
                                        ),
                                        flex: 0,
                                      ),
                                      Expanded(
                                          child:  Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: <Widget>[

                                              Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: TextViewWrap.textView(tagList[position].name,
                                                        TextAlign.left,
                                                        ColorValues.HEADING_COLOR_EDUCATION,
                                                        14.0,
                                                        FontWeight.bold),
                                                    flex: 0,
                                                  ),
                                                  Expanded(
                                                    child:    tagList[position] != null && tagList[position].roleId == "1"
                                                    //true
                                                        ? Util.getStudentBadge15 (tagList[position].badge,tagList[position].badgeImage)
                                                        : Container(),
                                                    flex: 0,
                                                  ),
                                                ],
                                              ),

                                              tagList[position].title == "null"||  tagList[position].title == ""
                                                  ? SizedBox():   PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  5.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textViewMultiLine(
                                                      tagList[position].title == "null"
                                                          ? ""
                                                          : tagList[position].title,
                                                      TextAlign.start,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal,
                                                      2)  ),
                                            ],
                                          ),
                                          flex: 2),
                                    ],
                                  ),

                                  Padding(
                                    padding: const EdgeInsets.only(top:4.0,bottom: 4),
                                    child: Divider(
                                      thickness: 1,
                                      height: 0,
                                      color: Color(0xffE5EBF0),
                                    ),
                                  )
                                ],
                              ),
                              onTap: () {
                                if (tagList[position].userId == userIdPref) {
                                } else {

                                  Util.onTapImageTile(
                                      tapedUserRole:  tagList[position].roleId
                                      , partnerUserId:   tagList[position].userId ,
                                      context: context
                                  );


                                }


                              },
                            ));
                      }),
                  flex: 1,
                ),
              ],
            )),
            () {
              Navigator.pop(context);
        },
        isShowIcon: false,
        isShowExplanation: false
    );


    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            backgroundColor:  ColorValues.SCREEN_BG_COLOR,
            appBar:  AppBar(
              elevation: 0.0,
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                   InkWell(
                    child:  SizedBox(
                      height: 40.0,
                      width: 40.0,
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          0.0,
                          3.0,
                           Center(
                              child:  Image.asset(
                                  "assets/newDesignIcon/navigation/back.png",
                                  height: 20.0,
                                  width: 10.0,
                                  fit: BoxFit.fitHeight))),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  )
                ],
              ),
              actions: <Widget>[
                 InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      5.0,
                      0.0,
                      8.0,
                      5.0,
                       Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                           Text(
                            " ",
                            style:  TextStyle(
                                fontSize: 16.0,
                                fontFamily: Constant.customRegular,
                                color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                          )
                        ],
                      )),
                  onTap: () {},
                )
              ],
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Text(
                    "Tagged Connections",
                    style:  TextStyle(
                        fontSize: 18.0,
                        fontFamily: Constant.customRegular,
                        color:  ColorValues.HEADING_COLOR_EDUCATION),
                  )
                ],
              ),
              backgroundColor: Colors.white,
            ),
            body:  ListView.builder(
                itemCount: tagList.length,
                itemBuilder: (BuildContext context, int position) {
                  return  Padding(
                      padding:  EdgeInsets.all(0.0),
                      child:  InkWell(
                        child:  Row(
                         crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                10.0,
                                 10.0,
                                            10.0,
                                            10.0,
                                 Container(
                                    width: 50.0,
                                    height: 50.0,
                                    child:  ClipOval(
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.cover,
                                          placeholder:
                                          'assets/profile/user_on_user.png',
                                          image: Constant.IMAGE_PATH_SMALL +
                                              ParseJson.getSmallImage(
                                                  tagList[position].profilePicture),
                                        ))),
                              ),
                              flex: 0,
                            ),
                             Expanded(
                                child:  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        PaddingWrap.paddingfromLTRB(
                                            5.0,
                                            10.0,
                                            0.0,
                                            2.0,
                                            TextViewWrap.textView(
                                                tagList[position].name,
                                                TextAlign.start,
                                                 ColorValues.HEADING_COLOR_EDUCATION,
                                                15.0,
                                                FontWeight.normal)),
                                        tagList[position] != null && tagList[position].roleId == "1"
                                        //true
                                            ?  PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            10.0,
                                            0.0,
                                            0.0,Util.getStudentBadge12(tagList[position].badge,tagList[position].badgeImage)):Container(),

                                      ],
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        5.0,
                                        0.0,
                                        0.0,
                                        0.0,
                                        TextViewWrap.textView(
                                            tagList[position].title == "null"
                                                ? ""
                                                : tagList[position].title,
                                            TextAlign.start,
                                             ColorValues.GREY_TEXT_COLOR,
                                            13.0,
                                            FontWeight.normal)),
                                  ],
                                ),
                                flex: 2),
                          ],
                        ),
                        onTap: () {
                          if (tagList[position].userId == userIdPref) {
                          } else {

                            Util.onTapImageTile(
                                tapedUserRole:  tagList[position].roleId
                                , partnerUserId:   tagList[position].userId ,
                                context: context
                            );


                          }


                        },
                      ));
                })));
  }
}
