import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/education/model/UniversityModel.dart';
import 'package:spike_view_project/gateway/EmailVerification.dart';
import 'package:spike_view_project/gateway/Login_Widget.dart';
import 'package:spike_view_project/gateway/MobileNumberVerification.dart';
import 'package:spike_view_project/gateway/TakeATour.dart';
import 'package:spike_view_project/gateway/more_data.dart';
import 'package:spike_view_project/gateway/parent_add_more.dart';
import 'package:spike_view_project/gateway/parent_signup/parent_proofile_view.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/new_onboarding/All_education_list_model.dart';
import 'package:spike_view_project/new_onboarding/onboarding_add_education.dart';
import 'package:spike_view_project/new_onboarding/onboarding_education_added_list.dart';
import 'package:spike_view_project/new_onboarding/onboarding_interest_widget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/studentWizard/AddEducationInitial.dart';
import 'package:spike_view_project/profile/studentWizard/AddFutureGoalsWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddGoalsInterestWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddInterestWidget.dart';
import 'package:spike_view_project/profile/studentWizard/AddOtherInterestWidget.dart';

import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

class ParentOnBoarding {
  ProfileInfoModal profileInfoModal = null;
  BuildContext context;

  String userId = '';

  SharedPreferences prefs;

  onBoardingInit(
      BuildContext context, ProfileInfoModal profileInfoModal, String userId) {
    this.context = context;
    this.profileInfoModal = profileInfoModal;
    this.userId = userId;

    getData();
  }

  bool isAdded = true;

  Future<void> getData() async {
    prefs = await SharedPreferences.getInstance();
    prefs.setBool(UserPreference.IS_PASSWORD_CHANGED, true);
    if (profileInfoModal == null) {
      await profileApi(true);
    } else {
      getStage(context);
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    print('profileApi userId onboarding partner++++ ::: $userId');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userId + "/false", "get");
        print('profileApi response++++ :::' + response.data.toString());
        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                try {
                  prefs.setString(UserPreference.DOB, profileInfoModal.dob);
                } catch (e) {}

                getStage(context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("error++++" + e.toString());
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<void> getStage(BuildContext context) async {
    print('getStage() 111 profileInfoModal.stage:: ${profileInfoModal.stage}');
    if (profileInfoModal != null) {
      try {
        if (profileInfoModal.stage != null &&
            int.parse(profileInfoModal.stage) < 5) {
          if (profileInfoModal.stage == "0") {
            stage1();
          } else if (profileInfoModal.stage == "1") {
            stage2();
          } else {
            if (profileInfoModal.mobileNo.toString() == 'null' ||
                profileInfoModal.mobileNo == '' ||
                profileInfoModal.mobileNo.length == 0) {
              Navigator.of(context).popUntil((route) => route.isFirst);

              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DashBoardWidgetParent(
                            prefs.getString(UserPreference.IS_PARENT_ROLE),
                            prefs.getString(UserPreference.IS_PARTNER_ROLE),
                            prefs.getString(UserPreference.IS_USER_ROLE),
                            profileInfoModal: profileInfoModal,
                          )));
            } else {
              if ((profileInfoModal.mobileNo.length > 0 &&
                  profileInfoModal.isPhoneVerified)) {
                Navigator.of(context).popUntil((route) => route.isFirst);

                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DashBoardWidgetParent(
                          prefs.getString(UserPreference.IS_PARENT_ROLE),
                          prefs.getString(UserPreference.IS_PARTNER_ROLE),
                          prefs.getString(UserPreference.IS_USER_ROLE),
                          profileInfoModal: profileInfoModal,
                        )));

              } else {
                stage2();
              }
            }
          }
        }else{
          Navigator.of(context).popUntil((route) => route.isFirst);

          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (context) => DashBoardWidgetParent(
                    prefs.getString(UserPreference.IS_PARENT_ROLE),
                    prefs.getString(UserPreference.IS_PARTNER_ROLE),
                    prefs.getString(UserPreference.IS_USER_ROLE),
                    profileInfoModal: profileInfoModal,
                  )));
        }
      } catch (e) {}
    }
  }

  stage2() async {
    Navigator.of(context).popUntil((route) => route.isFirst);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) {
          return ParentProfileView(
            signUpUsing: SignUpUsing.email,
            isRedirectToRecommendation: false,
          );
        },
      ),
    );
  }

  stage1() async {
    Navigator.of(context).popUntil((route) => route.isFirst);
    Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) => EmailVerification(
              profileInfoModal,
              '',
              loginRole: LoginRole.parent,
            )));
  }
}
