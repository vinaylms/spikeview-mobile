import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/values/ColorValues.dart';

class PositiveButton extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  final bool isEnable;

  const PositiveButton({
    @required this.title,
    @required this.onTap,
    @required this.isEnable,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        InkWell(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 11),
              decoration: BoxDecoration(
                color: AppConstants.colorStyle.lightBlue,
                borderRadius: BorderRadius.circular(10),
              ),
              alignment: Alignment.center,
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: ColorValues.WHITE,
                  fontFamily: AppConstants.stringConstant.latoRegular,
                  fontSize: 16,
                ),
              ),
            ),
            onTap: isEnable ? onTap : null),
        isEnable == false
            ? Container(
                padding: EdgeInsets.symmetric(vertical: 11),
                decoration: BoxDecoration(
                  color: Colors.white60,
                  borderRadius: BorderRadius.circular(10),
                ),
                alignment: Alignment.center,
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: ColorValues.WHITE,
                    fontFamily: AppConstants.stringConstant.latoMedium,
                    fontSize: 16,
                  ),
                ),
              )
            : const SizedBox.shrink(),
      ],
    );
  }
}
