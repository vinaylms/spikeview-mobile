import 'package:flutter/material.dart';
import 'package:spike_view_project/common/theme/palette.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/positive_button.dart';

enum OtherLinkAction { add, edit }

class OtherLinkView extends StatefulWidget {
  final String url;
  final OtherLinkAction action;

  const OtherLinkView({
    @required this.action,
    this.url,
  });

  @override
  State<OtherLinkView> createState() => _OtherLinkViewState();
}

class _OtherLinkViewState extends State<OtherLinkView> {
  final urlCtrl = TextEditingController();
  final urlNode = FocusNode();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    urlCtrl.text = widget.url ?? '';
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Palette.webColor,
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage("assets/new_onboarding/background_screen.png"),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 54, 20, 18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      child: SizedBox(
                        height: 32.0,
                        width: 32.0,
                        child: Center(
                            child: Image.asset(
                                "assets/new_onboarding/back_blue_icon.png",
                                height: 32.0,
                                width: 32.0,
                                fit: BoxFit.fitHeight)),
                      ),
                      onTap: () => Navigator.pop(context),
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
              ),
              Expanded(
                child: Form(
                  key: _formKey,
                  child: Container(
                    padding: EdgeInsets.fromLTRB(20, 25, 20, 40),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(35),
                      ),
                    ),
                    child: Column(
                      children: [
                        Expanded(
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                BaseText(
                                  text: '${widget.action == OtherLinkAction.edit ? "Edit" : "Add"} other link',
                                  textColor: const Color(0xff3D4361),
                                  fontSize: 28,
                                  fontWeight: FontWeight.w700,
                                  fontFamily:
                                      AppConstants.stringConstant.latoRegular,
                                ),
                                const SizedBox(height: 24),
                                CustomFormField(
                                  controller: urlCtrl,
                                  focusNode: urlNode,
                                  label: "URL",
                                  hint: "https://www.example.com",
                                  alignLabelWithHint: true,
                                  validation: (val) => val.trim().isEmpty
                                      ? MessageConstant.FIELD_REQUIRED
                                      : ValidationChecks
                                          .validateWebUrlPortFolio(val),
                                ),
                                const SizedBox(height: 24),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        PositiveButton(
                          title: widget.action == OtherLinkAction.edit
                              ? "Update"
                              : 'Add',
                          onTap: () {
                            if (_formKey.currentState.validate()) {
                                Navigator.pop(
                                  context,
                                  urlCtrl.text.trim(),
                                );
                            }
                          },
                          isEnable: true,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
