import 'dart:io';

class CoachMarkImagePagerModel {
  String width,height;



  CoachMarkImagePagerModel(this.width, this.height);
}