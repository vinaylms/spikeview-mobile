import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/gallery/Accomplishment_Add_Screen.dart';
import 'package:spike_view_project/gallery/AddAchievmentOutSideTheApp.dart';
import 'package:spike_view_project/gallery/SelectCompetencyWidget.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class StudentSelectionIfUserIsParent extends StatefulWidget {
  List<Assest> value;
  List<StudentDataModel> listStudent;
  StudentSelectionIfUserIsParent(this.value,this.listStudent);

  @override
  StudentSelectionIfParentLoginState createState() {
    return  StudentSelectionIfParentLoginState(listStudent);
  }
}

class StudentSelectionIfParentLoginState
    extends State<StudentSelectionIfUserIsParent> {
  List<StudentDataModel> listStudent ;
  StudentSelectionIfParentLoginState(this.listStudent);
  String userIdPref = "";
  SharedPreferences prefs;



  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);

  }

  @override
  void initState() {
    // TODO: implement initState
    getSharedPreferences();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    Padding getStudentsUi() {
      return  Padding(
          padding:  EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
          child:  Column(
              children:  List.generate(listStudent.length, (int index) {
            return  InkWell(
              child: PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  0.0,
                  10.0,
                   Container(
                      decoration:  BoxDecoration(
                          color: listStudent[index].isActive == "true"
                              ? Colors.white
                              : Colors.white.withOpacity(0.4),
                          border:  Border.all(
                              color:
                                   ColorValues.LIGHT_GREY_TEXT_COLOR,
                              width: 0.5)),
                      child:  Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                             Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  11.0,
                                  11.0,
                                  11.0,
                                  11.0,
                                   Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                       Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  Stack(
                                              children: <Widget>[
                                                 InkWell(
                                                  child:  ClipOval(
                                                      child: FadeInImage
                                                          .assetNetwork(
                                                    fit: BoxFit.cover,
                                                    width: 50.0,
                                                    height: 50.0,
                                                    placeholder:
                                                        'assets/profile/user_on_user.png',
                                                    image: Constant
                                                            .IMAGE_PATH_SMALL +
                                                        ParseJson.getMediumImage(
                                                            listStudent[index]
                                                                .profilePicture),
                                                  )),

                                                ),
                                                listStudent[index].isActive ==
                                                        "true"
                                                    ?  Container(
                                                        height: 0.0,
                                                      )
                                                    :  Container(
                                                        height: 50.0,
                                                        width: 50.0,
                                                        color: Colors.white
                                                            .withOpacity(0.4),
                                                      )
                                              ],
                                            ),
                                            flex: 0,
                                          ),
                                           Expanded(
                                              child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  PaddingWrap.paddingfromLTRB(
                                                    12.0,
                                                    5.0,
                                                    0.0,
                                                    0.0,
                                                    TextViewWrap.textView(
                                                        listStudent[index]
                                                                    .lastName ==
                                                                "null"
                                                            ? listStudent[index]
                                                                .firstName
                                                            : listStudent[index]
                                                                    .firstName +
                                                                " " +
                                                                listStudent[
                                                                        index]
                                                                    .lastName,
                                                        TextAlign.start,
                                                        listStudent[index]
                                                                    .isActive ==
                                                                "true"
                                                            ?  ColorValues.HEADING_COLOR_EDUCATION
                                                            :   ColorValues.HEADING_COLOR_EDUCATION
                                                                .withOpacity(
                                                                    0.4),
                                                        14.0,
                                                        FontWeight.bold),
                                                  ),
                                                  PaddingWrap.paddingfromLTRB(
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      13.0,
                                                      PaddingWrap.paddingAll(
                                                        2.0,
                                                        TextViewWrap.textView(
                                                            listStudent[index]
                                                                        .tagline ==
                                                                    "null"
                                                                ? ""
                                                                : listStudent[
                                                                        index]
                                                                    .tagline,
                                                            TextAlign.center,
                                                            listStudent[index]
                                                                        .isActive ==
                                                                    "true"
                                                                ?  ColorValues.GREY_TEXT_COLOR
                                                                :   ColorValues.GREY_TEXT_COLOR
                                                                    .withOpacity(
                                                                        0.4),
                                                            12.0,
                                                            FontWeight.normal),
                                                      )),
                                                ],
                                              ),
                                              flex: 1),
                                        ],
                                      ),
                                    ],
                                  )),
                            ),
                          ]))),onTap: (){

              Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) =>
                   Accomplishment_Add_Screen(
                      listStudent[index].userId, widget.value)));


            },
            );
          })));
    }

    onBack() async {
      Navigator.of(context).pushReplacement(new MaterialPageRoute(
          builder: (BuildContext context) =>DashBoardWidgetParent(prefs.getString(UserPreference.IS_PARENT_ROLE),prefs.getString(UserPreference.IS_PARTNER_ROLE),prefs.getString(UserPreference.IS_USER_ROLE))));
    }

    return  WillPopScope(
        onWillPop: () {
          onBack();
        },
        child:  Scaffold(
            backgroundColor:  Color(0XFFF4F8FB),
            appBar:  AppBar(
              brightness: Brightness.light,
              automaticallyImplyLeading: false,
              titleSpacing: 0.0,
              elevation: 0.0,
              title:  Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                   Expanded(
                    child:  InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        onBack();
                      },
                    ),
                    flex: 0,
                  ),
                   Expanded(
                    child:  Text(
                      "Select Student",
                      textAlign: TextAlign.center,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 18.0,
                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                    ),
                    flex: 1,
                  )
                ],
              ),
              actions: <Widget>[
                 Container(
                  height: 10.0,
                  width: 30.0,
                )
              ],
              backgroundColor: Colors.white,
            ),
            body:  Container(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    CustomViews.getSepratorLine(),
                     Expanded(
                      child:  ListView(
                        children: <Widget>[getStudentsUi()],
                      ),
                      flex: 1,
                    )
                  ],
                ))));
  }
}
