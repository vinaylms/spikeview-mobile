import 'dart:developer';

import 'package:flutter/gestures.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/modal/FileModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';

import 'home.dart';

class OpportunityDetaill extends StatefulWidget {
  String roleId, searchText = '', categoryType = '';
  String opportunityId;

  OpportunityDetaill(
      this.opportunityId, this.roleId, this.searchText, this.categoryType);

  @override
  State<StatefulWidget> createState() => OpportunityDetaillState(opportunityId);
}

class OpportunityDetaillState extends State<OpportunityDetaill>
    with BaseCommonWidget {
  bool isActivate = true;
  OpportunityModelForFeed opportunity = null;
  SharedPreferences prefs;
  List<Assest> mediaDocumentList = List();
  List<Assest> googleLinkList = List();
  List<FileModel> mediaVideosList = List();

  String userIdPref, roleId;
  String location = "";

  String opportunityId;
  UploadMedia uploadMedia;

  String firstHalf = '';
  String secondHalf = '';
  bool flag = true;

  String firstHalfDesc = '';
  String secondHalfDesc = '';
  bool flagDesc = true;

  String descVal = '';

  String categoryString = '';

  String subjectString = '';

  OpportunityDetaillState(this.opportunityId);

  int diffrenceInDob = 14;
  bool isGroup_AccessControl = true;
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    String dob = prefs.getString(UserPreference.DOB);
    try {
      isGroup_AccessControl =
          prefs.getString(UserPreference.ACCESS_CONTROL_GROUP)
              .toLowerCase() ==
              "true";

    }catch(e){
      isGroup_AccessControl = true;
    }
    if (dob != null && dob != 'null' && dob != '') {
      int millis = int.tryParse(dob);
      print('Apurva dob:: $dob, millis:: $millis');
      DateTime dobDate = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
    }
    setState(() {});
  }

  getData() async {
    //category
    try {
      categoryString = opportunity.toMapStringForDesignation();
    } catch (e) {
      categoryString = "";
    }
    try {
      if (opportunity.selectedDesignationCareerOption != null &&
          opportunity.selectedDesignationCareerOption.length > 0) {
        if (categoryString != "")
          categoryString = categoryString +
              " | " +
              opportunity.toMapStringForDesignationCareer();
        else
          categoryString = opportunity.toMapStringForDesignationCareer();
      }
    } catch (e) {
      categoryString = "";
    }
    try {
      if (opportunity.selectedDesignationOtherOption != null &&
          opportunity.selectedDesignationOtherOption.length > 0) {
        if (categoryString != "")
          categoryString = categoryString +
              " | " +
              opportunity.toMapStringForDesignationOther();
        else
          categoryString = opportunity.toMapStringForDesignationOther();
      }
    } catch (e) {
      categoryString = "";
    }
    //Subject
    try {
      subjectString = opportunity.toMapStringSubject();
    } catch (e) {
      subjectString = "";
    }
    try {
      if (opportunity.selectedSubjectOtherOption != null &&
          opportunity.selectedSubjectOtherOption.length > 0) {
        if (subjectString != "")
          subjectString =
              subjectString + " | " + opportunity.toMapStringSubjectOther();
        else
          subjectString = opportunity.toMapStringSubjectOther();
      }
    } catch (e) {
      subjectString = "";
    }

    setState(() {
    });

    //////////////////////////////////////
    for (Assest assest in opportunity.videoList) {
      final thumbnailFile = await uploadMedia
          .getVideoThumbnailFromUrl(Constant.IMAGE_PATH + assest.file);

      mediaVideosList.add(new FileModel(thumbnailFile, assest.file));
    }

    if (opportunity.bio != null) {
      if (opportunity.bio.length > 150) {
        firstHalf = opportunity.bio.substring(0, 150);
        secondHalf = opportunity.bio.substring(150, opportunity.bio.length);
      } else {
        firstHalf = opportunity.bio;
        secondHalf = "";
      }
    }

    descVal = '';
    if (opportunity.offerId == "1" ||
        opportunity.offerId == "2" ||
        opportunity.offerId == "3") {
      descVal = opportunity.project;
    } else if (opportunity.offerId == "4" || opportunity.offerId == "5") {
      descVal = opportunity.serviceDesc;
    } else {
      descVal = opportunity.description;
    }

    if (descVal != null) {
      if (descVal.length > 150) {
        firstHalfDesc = descVal.substring(0, 150);
        secondHalfDesc = descVal.substring(150, descVal.length);
      } else {
        firstHalfDesc = descVal;
        secondHalfDesc = "";
      }
    }
  }

  Future callGetOpportunityDetailsAPI() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'callGetOpportunityDetailsAPI URL:: ${Constant.ENDPOINT_Opportunity_detail_api}${widget.opportunityId}');
        CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_Opportunity_detail_api + widget.opportunityId,
            "get");

        log("callGetOpportunityDetailsAPI data" + response.data.toString());
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              print('Status:: $status');
              http: //15.206.172.61:3004/ui/opportunity/opportunityDetails?opportunityId=179
              opportunity = ParseJson.parseOpportunityDetailData(
                  response.data['result'], userIdPref, widget.roleId);
              print('opportunity after parsing:::::: $opportunity');
              if (opportunity != null) {
                print('inside if::::: ++' + opportunity.category);
                mediaDocumentList.addAll(opportunity.docList);

                googleLinkList.addAll(opportunity.googleLinkList);
                for (Address adress in opportunity.locationList) {
                  if (location == "") {
                    location = location + " " + adress.street1;
                  } else {
                    location = location + "   /  " + adress.street1;
                  }
                }

                await getData();
              }
              setState(() {
                opportunity = opportunity;
              });
            }
          }
        } catch (e) {}
        CustomProgressLoader.cancelLoader(context);
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      e.toString();
    }
  }

  Future<void> getInitData() async {
    await getSharedPreferences();
    await callGetOpportunityDetailsAPI();
  }

  @override
  void initState() {
    uploadMedia = UploadMedia(context);
    getInitData();
    super.initState();
  }

  void groupInvitationAccepted() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 200.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Center(
                                          child: Container(
                                              child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text: opportunity
                                                      .groupIsPublic
                                                      ? ' Awesome! You have successfully joined this group '
                                                      : ' Awesome! You have successfully sent request for this group ',
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                        ),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  Future apiCallJoin(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(widget.roleId)
        };
        print("map++++" + map.toString());
        response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForForwardParent(groupId, opportunityModelForFeed) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "parentId": int.parse(userIdPref),
          "userId": int.parse(opportunityModelForFeed.studentJoinId)
        };

        print("joinMap++++" + map.toString());

        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              groupInvitationAccepted();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  getHoursData(index) {
    return RichText(
      textAlign: TextAlign.start,
      maxLines: null,
      text: TextSpan(
        text:
        opportunity.scheduleModelParam[index].day + ": " + getHours(index),
        style: AppTextStyle.getDynamicFont(
            ColorValues.HEADING_COLOR_EDUCATION_1, 14, FontType.Regular),
        children: <TextSpan>[
          TextSpan(
            text: opportunity.timeZone == null ||
                opportunity.timeZone == "" ||
                opportunity.timeZone == "null"
                ? ""
                : "(" + opportunity.timeZone + ")",
            style: TextStyle(
                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                fontSize: 14.0,
                fontFamily: Constant.latoMedium,
                fontWeight: FontWeight.w600),
          )
        ],
      ),
    );
  }


  Widget loaderNew(BuildContext context) => Center(
      child: Container(
        child:  Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget errorNew() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }

  void feedForwardConformation() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 200.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Center(
                                          child: Container(
                                              child: RichText(
                                                maxLines: 5,
                                                textAlign: TextAlign.center,
                                                text: TextSpan(
                                                  text:
                                                  ' Your post has been forwarded to your parent. Please follow up with them ',
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION,
                                                      fontSize: 16.0,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR),
                                                ),
                                              )),
                                        ),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "OK",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  Future apiCallForForwardFeed(id) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "opportunityId": int.parse(id),
          "userId": int.parse(userIdPref)
        };
        print("map+++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_FEED_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              if (msg.contains("Opportunity already forwarded to parent")) {
                ToastWrap.showToast(msg, context);
              } else {
                feedForwardConformation();
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  void forwardToParentConformAtionDialog(id) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 195.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(20.0),
                                        width: double.infinity,
                                        color: Colors.white,
                                        child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                "Are you sure you want to forward this feed to your parent?",
                                                textAlign:
                                                TextAlign.center,
                                                maxLines: 5,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    height: 1.2,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                            ]),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.pop(context);
                                          apiCallForForwardFeed(id);
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  void infoDialog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 200.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  20.0,
                                  13.0,
                                  0.0,
                                  Container(
                                    height: 145.0,
                                    padding: const EdgeInsets.all(8.0),
                                    width: double.infinity,
                                    color: Colors.white,
                                    child: ListView(children: <Widget>[
                                      Image.asset(
                                        'assets/profile/parent/info.png',
                                        height: 25.0,
                                        width: 25.0,
                                      ),
                                      Container(
                                          padding:
                                          const EdgeInsets.all(3.0),
                                          child: RichText(
                                            maxLines: 1,
                                            textAlign: TextAlign.center,
                                            text: TextSpan(
                                              text: 'Forward to Parent',
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMBOLD),
                                            ),
                                          )),
                                      Container(
                                          child: RichText(
                                            maxLines: 5,
                                            textAlign: TextAlign.center,
                                            text: TextSpan(
                                              text:
                                              'Great that you are interested on this opportunity. Because you are under 13, please follow up your parent/guardian to help with next steps. They will see the details in their feed.',
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            ),
                                          ))
                                    ]),
                                  ),
                                ),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                color: Colors.white,
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                              "Close",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 20.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == userIdPref) {
    } else {
      Util.onTapImageTile(
          tapedUserRole: roleId,
          partnerUserId: tapedUserId,
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {

    final docListUiData = Container(
        padding: const EdgeInsets.fromLTRB(0.0, 7.0, 0.0, 0.0),
        child:Wrap(
          runSpacing: 10,
          spacing: 10,
          children: mediaDocumentList.map((file) {
            /*var fileName = file.file.split("/");
            String docName = "";
            if(fileName.length>0){
              docName = fileName[fileName.length - 1];
            }*/
            var fileName;
            String docName = "";
            if (file.file != null) {
              fileName = file.file.split("/");
              if (fileName != null && fileName.length > 0) {
                docName = fileName[fileName.length - 1];
              }
            }
            print('Apurva docListUiData docName:: $docName, file:: $file');
            return Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                    height: 60.0,
                    width: 64.0,
                    child: Stack(
                      children: <Widget>[
                        InkWell(
                          onTap: () {
                            print("DOC++++" + Constant.IMAGE_PATH + file.file);
                            launch(Constant.IMAGE_PATH +
                                ((file.file)
                                    .replaceAll("pdf'", 'pdf')
                                    .replaceAll(" ", "%20")));
                          },
                          child: Container(
                              height: 60.0,
                              width: 62.0,
                              child: Image.asset(
                                "assets/resume/ic_doc_pdf.png",
                                height: 54.0,
                                width: 62.0,
                              )),
                        ),
                      ],
                    )),
                /*Expanded(
                  child: Container(
                    height: 14.0,
                    child: Padding(
                      padding: EdgeInsets.only(top: 3.0),
                      child: docNameLabelText('${docName}'),
                    ),
                  ),
                ),*/
              ],
            );
          }).toList(),
        ));

    return customAppbar(context, Column(
      children: [
        Expanded(child: opportunity != null?SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20.0, 12, 24.0, 55.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[

              Padding(padding: const EdgeInsets.fromLTRB(0.0, 15, 0, 15),
                child: BaseText(
                  text: opportunity.offerId == "4" ||
                      opportunity.offerId == "5"
                      ? opportunity.serviceTitle
                      : opportunity.jobTitle,
                  textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                  fontFamily:
                  AppConstants.stringConstant.latoMedium,
                  fontWeight: FontWeight.w700,
                  fontSize: 28,
                  textAlign: TextAlign.start,
                  maxLines: 4,
                ),
              ),
              PaddingWrap.paddingfromLTRB(
                  0.0,
                  0.0,
                  0.0,
                  10.0,
                  InkWell(
                    onTap: () {
                      print('Apurva onTap Image');
                      onTapImageTile(opportunity.userId,
                          opportunity.roleId);
                    },
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            child: Center(
                              child: Container(
                                  width: 52.0,
                                  height: 52.0,
                                  child: ProfileImageView(
                                    imagePath:Constant
                                        .IMAGE_PATH_SMALL +
                                        ParseJson.getSmallImage(
                                            opportunity
                                                .opportunityCretedUserImage),
                                    placeHolderImage:
                                    'assets/profile/user_on_user.png',
                                    height: 80.0,
                                    width:80.0,
                                    onTap: () async {},
                                    borderRadius: 10,
                                  ),

                                  // ClipOval(
                                  //     child: FadeInImage.assetNetwork(
                                  //       fit: BoxFit.cover,
                                  //       width: double.infinity,
                                  //       placeholder:
                                  //       'assets/profile/user_on_user.png',
                                  //       image: Constant
                                  //           .IMAGE_PATH_SMALL +
                                  //           ParseJson.getSmallImage(
                                  //               opportunity
                                  //                   .opportunityCretedUserImage),
                                  //     ))
                              ),
                            ),
                            onTap: () {
                              onTapImageTile(
                                  opportunity.userId,
                                  opportunity.roleId);
                            },
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              15.0,
                              0.0,
                              Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                children: <Widget>[
                                  InkWell(
                                    child: Container(
                                        child: RichText(
                                          maxLines: 2,
                                          textAlign:
                                          TextAlign.start,
                                          text: TextSpan(
                                            text: opportunity.opportunityCretedUserName,
                                            style: TextStyle(
                                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                              fontSize: 18.0,
                                              fontFamily: AppConstants.stringConstant.latoMedium,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        )),
                                  ),
                                  InkWell(
                                    child: Padding(
                                      padding:
                                      const EdgeInsets
                                          .fromLTRB(
                                          0.0, 2, 0, 0),
                                      child: Container(
                                          child: RichText(
                                            maxLines: 1,
                                            textAlign:
                                            TextAlign.start,
                                            text: TextSpan(
                                              text: opportunity
                                                  .category,
                                              style: TextStyle(
                                                color: ColorValues.labelColor,
                                                fontSize: 14.0,
                                                fontFamily: AppConstants.stringConstant.latoRegular,
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                          )),
                                    ),
                                  ),
                                ],
                              )),
                          flex: 4,
                        ),
                      ],
                    ),
                  )),

              Padding(
                padding: const EdgeInsets.fromLTRB(
                    0.0, 12, 0, 0),
                child: RichText(
                  text: TextSpan(
                      text: secondHalfDesc == null &&
                          secondHalfDesc == ""
                          ? firstHalfDesc
                          : flagDesc
                          ? (firstHalfDesc + "")
                          : (firstHalfDesc +
                          secondHalfDesc),
                      style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontSize: 16.0,
                        fontFamily: Constant.latoMedium,
                        fontWeight: FontWeight.w400,
                      ),
                      children: [
                        TextSpan(
                          text: secondHalfDesc == ''
                              ? ''
                              : flagDesc
                              ? " More"
                              : " Less",
                          style: AppTextStyle.getDynamicFont(
                              ColorValues.BLUE_COLOR,
                              14,
                              FontType.Regular),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              print('Tap Here onTap');
                              setState(() {
                                flagDesc = !flagDesc;
                              });
                            },
                        )
                      ]),
                ),
              ),
              diffrenceInDob < 13 && roleId != "4" && roleId != "2"
                  ? Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Palette.webColor,
                  border: Border.all(
                      color: ColorValues.DARK_GREY),
                ),
                padding: const EdgeInsets.fromLTRB(
                    0.0, 10.0, 0.0, 10.0),
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                        0.0, 10.0, 0.0, 10.0),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: InkWell(
                            child: Padding(
                              padding:
                              EdgeInsets.fromLTRB(
                                  0.0,
                                  0.0,
                                  0.0,
                                  0.0),
                              child: Text(
                                "FORWARD TO PARENT",
                                style: TextStyle(
                                    fontFamily: Constant
                                        .customRegular,
                                    fontSize: 12.0,
                                    color: ColorValues
                                        .BLUE_COLOR_BOTTOMBAR),
                              ),
                            ),
                            onTap: () {
                              forwardToParentConformAtionDialog(
                                  opportunity
                                      .opportunityId);
                            },
                          ),
                          flex: 1,
                        ),
                        Expanded(
                            child: InkWell(
                              child: Image.asset(
                                'assets/profile/parent/info.png',
                                height: 25.0,
                                width: 25.0,
                              ),
                              onTap: () {
                                infoDialog();
                              },
                            ),
                            flex: 0),
                      ],
                    )),
              )
                  : SizedBox(),

              Container(
                width: double.infinity,
                padding: EdgeInsets.only(top: 10,bottom: 10),
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    opportunity.offerId == "6" ||
                        opportunity.offerId == "7" ||
                        opportunity.offerId == "8"
                        ? getMentorAdvisorTutor()
                        : opportunity.offerId == "1" ||
                        opportunity.offerId == "2" ||
                        opportunity.offerId == "3"
                        ? getJobInternship()
                        : Container(height: 0.0),

                    opportunity.offerId == "6" ||
                        opportunity.offerId == "7" ||
                        opportunity.offerId == "8"
                        ? UIHelper.verticalSpaceSmall1
                        : Container(height: 0.0),

                    opportunity.offerId == "6" ||
                        opportunity.offerId == "7" ||
                        opportunity.offerId == "8"
                        ? getScheduleWidget(opportunity)
                        : Container(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            BaseText(
                                text: 'Scheduled for',
                                textColor: ColorValues.labelColor,
                                fontSize: 12.0,
                                fontFamily: Constant.latoMedium,
                                fontWeight: FontWeight.w400
                            ),
                            UIHelper.verticalSpaceSmall,
                            BaseText(
                                text: getConvertedDateStamp2(
                                    opportunity
                                        .toDate),
                                textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 14.0,
                                fontFamily: Constant.latoMedium,
                                fontWeight: FontWeight.w400
                            ),
                          ],
    )),




                    // Row(children: <Widget>[
                    //   AppTextStyle.getLableTextForDetailRow(
                    //       'Scheduled For',
                    //       getConvertedDateStamp2(
                    //           opportunity
                    //               .fromDate) +
                    //           " - " +
                    //           getConvertedDateStamp2(
                    //               opportunity
                    //                   .toDate)),
                    // ],
                    // ),
                  ],
                ),
              ),
              opportunity.docList.length == 0 ||
                  opportunity.offerId == "6"
                  ? Container(
                height: 0.0,
              )
                  : Padding(
                  padding: const EdgeInsets.fromLTRB(
                      0.0, 0.0, 0.0, 0.0),
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      PaddingWrap.paddingfromLTRB(
                          0.0,
                          5.0,
                          0.0,
                          0.0,
                          mediaLabelTextNew('Documents')),
                      docListUiData,
                    ],
                  )),

              opportunity.offerId == "7" ||
                  opportunity.offerId == "8"
                  ? Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                mainAxisAlignment:
                MainAxisAlignment.start,
                children: <Widget>[
                  opportunity != null &&
                      opportunity
                          .userImageModelParam
                          .length >
                          0
                      ? PaddingWrap.paddingfromLTRB(
                      0.0,
                      14.0,
                      0.0,
                      5.0,
                      Text(
                        "${opportunity.offerId == "8" ? "Advisors photo" : "Mentor photo"}",
                        style: TextStyle(
                            color:  ColorValues.labelColor,
                            fontWeight: FontWeight.w400,
                            fontSize: 12.0,
                            fontFamily: Constant.latoMedium),
                      ))
                      : Container(
                    height: 0.0,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(
                      0.0,
                      0.0,
                      0.0,
                      0.0,
                    ),
                    child: userImageListUI(),
                  ),
                ],
              )
                  : Container(),
              opportunity.offerId == "6" ||
                  opportunity.offerId == "7" ||
                  opportunity.offerId == "8"
                  ? Padding(
                padding: const EdgeInsets.fromLTRB(
                  0.0,
                  3.0,
                  0.0,
                  0.0,
                ),
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  mainAxisAlignment:
                  MainAxisAlignment.start,
                  children: <Widget>[
                    UIHelper.verticalSpaceSmall,
                    Text(
                      "Bio",
                      style: TextStyle(
                          color:  ColorValues.labelColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 12.0,
                          fontFamily: Constant.latoMedium),
                    ),
                    const SizedBox(height: 8,),

                    RichText(
                      text: TextSpan(
                          text: secondHalf == ""
                              ? firstHalf
                              : flag
                              ? (firstHalf + "")
                              : (firstHalf +
                              secondHalf),
                          //style: underlineStyle.copyWith(decoration: TextDecoration.none),
                          style: AppTextStyle
                              .getDynamicFont(
                              ColorValues
                                  .HEADING_COLOR_EDUCATION_1,
                              14,
                              FontType.Regular),
                          children: [
                            TextSpan(
                              text: secondHalf == ''
                                  ? ''
                                  : flag
                                  ? " More"
                                  : " Less",
                              style: AppTextStyle
                                  .getDynamicFont(
                                  ColorValues
                                      .BLUE_COLOR,
                                  14,
                                  FontType.Regular),
                              recognizer:
                              TapGestureRecognizer()
                                ..onTap = () {
                                  print(
                                      'Tap Here onTap');
                                  setState(() {
                                    flag = !flag;
                                  });
                                },
                            )
                          ]),
                    ),
                  ],
                ),
              )
                  : Container(),

              opportunity.docList.length != 0 &&
                  opportunity.offerId == "6"
                  ? Padding(
                  padding: const EdgeInsets.fromLTRB(
                      0.0, 10.0, 0.0, 0.0),
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    mainAxisAlignment:
                    MainAxisAlignment.start,
                    children: <Widget>[
                      mediaLabelTextNew(
                          'Teaching certifications'),
                      UIHelper.verticalSpaceMedium,
                      docListUiData,
                    ],
                  ))
                  : new Container(
                height: 0.0,
              ),

            //  UIHelper.verticalSpaceSmall,

              googleLinkList.length == 0
                  ? Container(
                height: 0.0,
              )
                  : Padding(
                  padding: const EdgeInsets.fromLTRB(
                    0.0,
                    15.0,
                    0.0,
                    0.0,
                  ),
                  child: mediaLabelTextNew('Additional link(s)')),

              googleLinkList.length == 0
                  ? Container(
                height: 0.0,
              ) :
              Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: List.generate(
                      googleLinkList.length, (index) {
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(
                          0.0, 10.0, 0.0, 10.0),
                      child: InkWell(
                        child: Text(
                          googleLinkList[index]
                              .label
                              .trim() ==
                              "null"
                              ? googleLinkList[index]
                              .file
                              .trim()
                              : googleLinkList[index]
                              .label
                              .trim(),
                          textAlign: TextAlign.start,
                          style: TextStyle(
                              color:  ColorValues.HEADING_COLOR_EDUCATION_2,
                              fontWeight: FontWeight.w600,
                              fontSize: 14.0,
                              fontFamily: Constant.latoMedium),
                        ),
                        onTap: () {
                          String url = "";
                          if (googleLinkList[index]
                              .file
                              .contains("http")) {
                            url = googleLinkList[index].file;
                          } else {
                            url = "http://" +
                                googleLinkList[index].file;
                          }
                          Navigator.push(
                              Constant.applicationContext,
                              MaterialPageRoute(
                                //   builder: (context) =>  DashBoardWidget()));
                                  builder: (context) =>
                                      WebViewWidget(url,
                                          "Document Link")));
                        },
                      ),
                    );
                  })),



                 Padding(
                   padding: const EdgeInsets.fromLTRB(0.0, 15.0, 0.0, 0.0,),
                 child: Column(
                     crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                     children: <Widget>[
                       //UIHelper.verticalSpaceSmall,
                       Text("Photos", style: TextStyle(
                           color:  ColorValues.labelColor,
                           fontWeight: FontWeight.w600,
                           fontSize: 12.0,
                           fontFamily: Constant.latoMedium),
                       ),
              ])),
              PaddingWrap.paddingfromLTRB(
                  0.0,
                  20.0,
                  0.0,
                  20.0,
                  opportunity.assestVideoAndImage.length > 0
                      ?  SizedBox(
                    // Pager view
                      height: 215.50,
                      child: PageIndicatorContainer(
                        pageView:  PageView.builder(
                          itemCount: opportunity.assestVideoAndImage.length,
                          controller:  PageController(),
                          itemBuilder: (context, index2) {
                            return  Stack(children: <Widget>[
                              opportunity
                                  .assestVideoAndImage[
                              index2]
                                  .type ==
                                  "image"
                                  ?Container(
                                  decoration: BoxDecoration(
                                      color:
                                      Colors.black,
                                      borderRadius: BorderRadius.circular(0)
                                  ),
                                  child:  CachedNetworkImage(
                                    width: double.infinity,
                                    height: 215.50,
                                    imageUrl: Constant
                                        .IMAGE_PATH +
                                        opportunity
                                            .assestVideoAndImage[
                                        index2]
                                            .file,
                                    fit: BoxFit.contain,
                                    placeholder:
                                        (context, url) => loaderNew(context),
                                    errorWidget: (context,
                                        url, error) =>
                                        errorNew(),
                                  ))
                                  : InkWell(
                                  child:  Container(
                                    decoration:
                                    BoxDecoration(
                                      color:
                                      Colors.black,
                                      borderRadius:
                                      BorderRadius.circular(0),
                                    ),
                                    height: 215.50,
                                    child: Center(
                                        child:

                                        VideoPlayPause(
                                            opportunity
                                                .assestVideoAndImage[
                                            index2]
                                                .file,
                                            "",true)
                                    ),
                                  )),
                              opportunity.assestVideoAndImage
                                  .length ==
                                  1 ||
                                  opportunity
                                      .assestVideoAndImage[
                                  index2]
                                      .type ==
                                      "video"
                                  ?  Container(
                                height: 0.0,
                              )
                                  :new InkWell(
                                  onTap:
                                      () {

                                    Navigator.of(context)
                                        .push(new MaterialPageRoute(builder: (BuildContext context) =>
                                        CommonFullViewWidget(opportunity.assestVideoAndImage,
                                            MessageConstant.ACCOMPLISHMENT_HEDING, index2,
                                            MessageConstant. VIEWER_END_REWCOMMENDATION_HEDING)));
                                  },
                                  child:  Container(
                                    height: 215.50,
                                    width: double.infinity,
                                    child:  Image.asset(
                                      "assets/newDesignIcon/navigation/layer_image.png",
                                      fit: BoxFit.fill,
                                    ),
                                  ))
                            ]);
                          },
                          onPageChanged: (index) {},
                        ),
                        align: IndicatorAlign.bottom,
                        length: opportunity
                            .assestVideoAndImage.length,
                        indicatorSpace: 10.0,
                        indicatorColor: opportunity
                            .assestVideoAndImage.length ==
                            1
                            ? Colors.transparent
                            :  Color(0xffc4c4c4),
                        indicatorSelectorColor: opportunity
                            .assestVideoAndImage.length ==
                            1
                            ? Colors.transparent
                            :  ColorValues.WHITE,
                        shape: IndicatorShape.circle(size: 5.0),
                      ))
                      :  Stack(children: <Widget>[
                    Image.asset(
                      "assets/profile/default_achievement.png",
                      fit: BoxFit.cover,
                      height: 215.50,
                      width: double.infinity,
                    ),
                    Container(
                      height: 215.50,
                      color: Colors.black54.withOpacity(.4),
                    )
                  ])),
            ],
          ),
        ):SizedBox() ,flex: 1,),

        Expanded(child: opportunity==null?SizedBox():PaddingWrap.paddingfromLTRB(
            20.0,
            15.0,
            20.0,
            15.0,
            InkWell(
              onTap: (){
                if (opportunity.actionType ==
                    Constant.LINK_URL) {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        //   builder: (context) =>  DashBoardWidget()));
                          builder: (context) =>
                              WebViewWidget(
                                  opportunity.url
                                      .contains(
                                      "http")
                                      ? opportunity
                                      .url
                                      : "https://" +
                                      opportunity
                                          .url,
                                  opportunity.linkUrlPosition ==
                                      Constant
                                          .LEARN_MORE
                                      ? "Learn More"
                                      : opportunity
                                      .linkUrlPosition ==
                                      Constant
                                          .GET_OFFER
                                      ? "Get Offer"
                                      : "Apply Now")));
                } else if (opportunity.actionType ==
                    Constant.JOIN_GROUP) {
                  if (prefs != null &&
                      opportunity != null &&
                      Util.showJoinGroupButton(
                          prefs,
                          opportunity.schoolCode,
                          opportunity
                              .actionType) ==
                          "true") {
                    if (opportunity.studentJoinId ==
                        "" ||
                        opportunity.studentJoinId ==
                            "null") {
                      if (isGroup_AccessControl) {
                        apiCallJoin(
                            opportunity.groupIdAction);
                        ;
                      } else {
                        ToastWrap.showToastForAccessDenied(
                            MessageConstant.JOIN_GROUP_DISABLE, context);
                      }
                    } else {
                      apiCallForForwardParent(
                          opportunity.groupIdAction,
                          opportunity);
                    }
                  } else {
                    ToastWrap.showToast(
                        MessageConstant
                            .OPPORTUNITY_NOT_IN_COMMUNITY,
                        context);
                  }
                } else if (opportunity.actionType ==
                    Constant.CALL_NOW) {
                  String callingNumber =
                      opportunity.callingNumber;
                  launch("tel:" + callingNumber);
                } else {
                  Navigator.of(context).push(
                      MaterialPageRoute(
                          builder: (BuildContext
                          context) =>
                              InquireNowScreen(
                                  opportunity
                                      .opportunityId,
                                  userIdPref,
                                  opportunity.formId,
                                  opportunity.offerId
                                      .toString(),
                                  "")));
                }
              },
              child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: ColorValues.SEARCH_CATEGORY_BOX_BG_SELCTED,
                    borderRadius:
                    BorderRadius.circular(10),
                  ),
                  padding: EdgeInsets.all(10.0),
                  height: 44.0,
                  child: BaseText(
                    text: opportunity.actionType ==
                        Constant.LINK_URL
                        ? opportunity
                        .linkUrlPosition ==
                        Constant
                            .LEARN_MORE
                        ? "Learn more"
                        : opportunity
                        .linkUrlPosition ==
                        Constant
                            .GET_OFFER
                        ? "Get offer"
                        : "Apply now"
                        : opportunity
                        .actionType ==
                        Constant
                            .JOIN_GROUP
                        ? "Join group"
                        : opportunity
                        .actionType ==
                        Constant
                            .CALL_NOW
                        ? "Call now"
                        : "Inquire now",//Learn More
                    textColor: ColorValues.WHITE,
                    fontFamily:
                    AppConstants.stringConstant.latoMedium,
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                  )),
            )),flex: 0,)

      ],
    ), () {Navigator.pop(context);},
      isShowIcon: false,
      isShowExplanation: true,
    );
  }

  Widget getAgeList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(opportunity.ageList.length, (index) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(0.0, 2.0, 0.0, 0.0),
          child: Text(
            opportunity.ageList[index].from +
                "-" +
                opportunity.ageList[index].to +
                " years ",
            style: AppTextStyle.getDynamicFontStyle(
                Palette.primaryTextColor, 16, FontType.Regular),
          ),
        );
      }),
    );
  }

  otherInformationHeader(String title) {
    return Text(
      title,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.secondaryTextColor, 14, FontType.Regular),
    );
  }

  otherInformationValue(String value) {
    return Text(
      value,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.primaryTextColor, 16, FontType.Regular),
    );
  }

  bottomWidgetDataTitleWidget(String text, Color color) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(color, 14, FontType.Regular),
    );
  }

  bottomWidgetDataValueWidget(String text) {
    return Text(
      text,
      style: AppTextStyle.getDynamicFontStyle(
          Palette.accentColor, 24, FontType.Regular),
    );
  }

  getData22(path) async {
    final thumbnailFile =
    await uploadMedia.getVideoThumbnailFromUrl(Constant.IMAGE_PATH + path);

    return Image.file(
      thumbnailFile,
      fit: BoxFit.contain,
    );
  }

  String getConvertedDateStamp2(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      var now = DateTime.fromMillisecondsSinceEpoch(millis);
      var formatter = DateFormat('MMM dd, yyyy');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      var formatter = DateFormat('MMM dd, yyyy');
      return formatter.format(new DateTime.now());
    }
  }

  String getConvertedTime(int time) {
    if (time != null) {
      var now = DateTime.fromMillisecondsSinceEpoch(time);
      var formatter = DateFormat('hh:mm a');
      String formatted = formatter.format(now);
      return formatted;
    } else {
      return "";
    }
  }

  String getHours(index) {
    String timeReturn = "";
    try {
      for (HoursData hours in opportunity.scheduleModelParam[index].hours) {
        timeReturn = Util.getConvertedTimeForScheduleDate(hours.timeFrom) +
            " - " +
            Util.getConvertedTimeForScheduleDate(
                hours.timeTo == null ? hours.timeFrom : hours.timeTo) +
            " | " +
            timeReturn;
      }

      return timeReturn.substring(0, timeReturn.lastIndexOf("|"));
    } catch (e) {
      return timeReturn;
    }
  }

  String getAge() {
    String ageReturn = "";

    for (AgeModel age in opportunity.ageList) {
      ageReturn = age.from + "-" + age.to + " years" + " | " + ageReturn;
    }

    return ageReturn;
  }

  oldAllData() {
    return Column(
      children: <Widget>[
        opportunity.category == "Internship" ||
            opportunity.category == "Job" ||
            opportunity.category == "Volunteering"
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              'Job Type: ' + opportunity.jobType,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall,
            Text(
              'Job Location: ' + opportunity.jobLocation,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall,
            Text(
              'Scheduled For: ' +
                  getConvertedDateStamp2(opportunity.fromDate) +
                  " - " +
                  getConvertedDateStamp2(opportunity.toDate),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall,
            Text(
              'Expiration Date: ' +
                  getConvertedDateStamp2(opportunity.expiresOn),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /*opportunity.targetAudience ==
                                                            "true" &&
                                                        (opportunity.ageList
                                                                    .length >
                                                                0 ||
                                                            (opportunity.gender !=
                                                                    "" &&
                                                                opportunity
                                                                        .gender !=
                                                                    "null"))
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0, 15, 0, 0),
                                                        child: Text(
                                                          "Eligible For: " +
                                                              getAge() +
                                                              " " +
                                                              opportunity
                                                                  .gender,
                                                          style: AppTextStyle
                                                              .getDynamicFont(
                                                                   ColorValues.HEADING_COLOR_EDUCATION,
                                                                  12,
                                                                  FontType
                                                                      .Bold),
                                                        ),
                                                      )
                                                    :  Container(
                                                        height: 0.0,
                                                      ),*/
            UIHelper.verticalSpaceSmall1,
            Text(
              opportunity.jobTitle,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              opportunity.project,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
          ],
        )
            : opportunity.category == "Services" ||
            opportunity.category == "Programs"
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              'Scheduled For: ' +
                  getConvertedDateStamp2(opportunity.fromDate) +
                  " - " +
                  getConvertedDateStamp2(opportunity.toDate),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /* UIHelper.verticalSpaceSmall,
                      Text(
                        'Expiration Date: ' +
                            getConvertedDateStamp2(opportunity.expiresOn),
                        style: AppTextStyle.getDynamicFont(
                             ColorValues.HEADING_COLOR_EDUCATION,
                            12,
                            FontType.Regular),
                      ),*/
            /*opportunity.targetAudience ==
                                                                "true" &&
                                                            (opportunity.ageList
                                                                        .length >
                                                                    0 ||
                                                                (opportunity.gender !=
                                                                        "" &&
                                                                    opportunity
                                                                            .gender !=
                                                                        "null"))
                                                        ? Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    0.0,
                                                                    15,
                                                                    0,
                                                                    0),
                                                            child: Text(
                                                              "Eligible For: " +
                                                                  getAge() +
                                                                  " " +
                                                                  opportunity
                                                                      .gender,
                                                              style: AppTextStyle
                                                                  .getDynamicFont(
                                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                                      12,
                                                                      FontType
                                                                          .Bold),
                                                            ),
                                                          )
                                                        :  Container(
                                                            height: 0.0,
                                                          ),*/
            UIHelper.verticalSpaceSmall1,
            Text(
              opportunity.serviceTitle,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /*  UIHelper
                                                        .verticalSpaceSmall1,
                                                    Text(
                                                        opportunity.serviceTitle !=
                                                                    "null" &&
                                                                opportunity
                                                                        .serviceTitle !=
                                                                    ""
                                                            ? opportunity
                                                                    .companyName +
                                                                "(" +
                                                                opportunity
                                                                    .serviceTitle
                                                                    .replaceAll(
                                                                        "null",
                                                                        "") +
                                                                ")"
                                                            : opportunity
                                                                .companyName,
                                                        style: AppTextStyle.getDynamicFont(
                                                             ColorValues.HEADING_COLOR_EDUCATION,
                                                            14,
                                                            FontType.Regular)),*/
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.serviceDesc,
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
          ],
        )
            : opportunity.category == "Tutors"
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              opportunity.bio,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall,
            Text(
              "Category: " +
                  opportunity.toMapStringForDesignation(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              "Subject: " + opportunity.toMapStringSubject(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              "Qualification: " +
                  opportunity.toMapStringForQualification(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              opportunity.fees == "null"
                  ? "Fees: "
                  : opportunity.fees == "0"
                  ? "Fees: " + MessageConstant.FEE_EMPTY_VAL
                  : "Fees: " + opportunity.fees,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /*opportunity.targetAudience ==
                                                                    "true" &&
                                                                (opportunity.ageList
                                                                            .length >
                                                                        0 ||
                                                                    (opportunity.gender !=
                                                                            "" &&
                                                                        opportunity.gender !=
                                                                            "null"))
                                                            ? Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        0.0,
                                                                        15,
                                                                        0,
                                                                        0),
                                                                child: Text(
                                                                  "Eligible For: " +
                                                                      getAge() +
                                                                      " " +
                                                                      opportunity
                                                                          .gender,
                                                                  style: AppTextStyle.getDynamicFont(
                                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                                      14,
                                                                      FontType
                                                                          .Bold),
                                                                ),
                                                              )
                                                            :  Container(
                                                                height: 0.0,
                                                              ),*/
            UIHelper.verticalSpaceSmall1,
            Text("Scheduled For:",
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: List.generate(
                  opportunity.scheduleModelParam.length, (index) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  child:
                  /* Text(
                                    opportunity.scheduleModelParam[index].day +
                                        " : " +
                                        getHours(index),
                                    maxLines: null,
                                    style: AppTextStyle.getDynamicFont(
                                         ColorValues.HEADING_COLOR_EDUCATION,
                                        14,
                                        FontType.Regular))*/
                  getHoursData(index),
                );
              }),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.jobTitle.replaceAll("null", ""),
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.description,
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
          ],
        )
            : opportunity.category == "Mentors"
            ? Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              opportunity.bio,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall,
            Text(
              "Category: " +
                  opportunity.toMapStringForDesignation(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              "Mentee Support Offered: " +
                  opportunity.supportedOffer,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              opportunity.fees == "null"
                  ? "Fees: "
                  : opportunity.fees == "0"
                  ? "Fees: " +
                  MessageConstant.FEE_EMPTY_VAL
                  : "Fees: " + opportunity.fees,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /*opportunity.targetAudience ==
                                                                        "true" &&
                                                                    (opportunity.ageList.length >
                                                                            0 ||
                                                                        (opportunity.gender !=
                                                                                "" &&
                                                                            opportunity.gender !=
                                                                                "null"))
                                                                ? Padding(
                                                                    padding:
                                                                        const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            15,
                                                                            0,
                                                                            0),
                                                                    child: Text(
                                                                      "Eligible For: " +
                                                                          getAge() +
                                                                          " " +
                                                                          opportunity
                                                                              .gender,
                                                                      style: AppTextStyle.getDynamicFont(
                                                                           ColorValues.HEADING_COLOR_EDUCATION,
                                                                          14,
                                                                          FontType
                                                                              .Bold),
                                                                    ),
                                                                  )
                                                                :  Container(
                                                                    height: 0.0,
                                                                  ),*/
            UIHelper.verticalSpaceSmall1,
            Text("Scheduled For:",
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: List.generate(
                  opportunity.scheduleModelParam.length,
                      (index) {
                    return Padding(
                      padding:
                      const EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child:
                      /*Text(
                                        opportunity
                                                .scheduleModelParam[index].day +
                                            " : " +
                                            getHours(index),
                                        maxLines: null,
                                        style: AppTextStyle.getDynamicFont(
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14,
                                            FontType.Regular))*/
                      getHoursData(index),
                    );
                  }),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.jobTitle.replaceAll("null", ""),
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.description,
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
          ],
        )
            : Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
              opportunity.bio,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall,
            Text(
              "Category: " +
                  opportunity.toMapStringForDesignation(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              "Subject: " + opportunity.toMapStringSubject(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(
              "Qualification: " +
                  opportunity.toMapStringForQualification(),
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /*  UIHelper
                                                                .verticalSpaceSmall1,
                                                            Text(
                                                              "Advisor Support Offered: Consectetur adipiscing",
                                                              style: AppTextStyle
                                                                  .getDynamicFont(
                                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                                      14,
                                                                      FontType
                                                                          .Bold),
                                                            ),
                                                            UIHelper
                                                                .verticalSpaceSmall1,
                                                            Text(
                                                              "Project Areas: Consectetur adipiscing",
                                                              style: AppTextStyle
                                                                  .getDynamicFont(
                                                                      ColorValues.HEADING_COLOR_EDUCATION,
                                                                      14,
                                                                      FontType
                                                                          .Bold),
                                                            ),*/
            UIHelper.verticalSpaceSmall1,
            Text(
              opportunity.fees == "null"
                  ? "Fees: "
                  : opportunity.fees == "0"
                  ? "Fees: " +
                  MessageConstant.FEE_EMPTY_VAL
                  : "Fees: " + opportunity.fees,
              style: AppTextStyle.getDynamicFont(
                  ColorValues.HEADING_COLOR_EDUCATION,
                  14,
                  FontType.Regular),
            ),
            /*opportunity.targetAudience ==
                                                                        "true" &&
                                                                    (opportunity.ageList.length >
                                                                            0 ||
                                                                        (opportunity.gender !=
                                                                                "" &&
                                                                            opportunity.gender !=
                                                                                "null"))
                                                                ? Padding(
                                                                    padding:
                                                                        const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            15,
                                                                            0,
                                                                            0),
                                                                    child: Text(
                                                                      "Eligible For: " +
                                                                          getAge() +
                                                                          " " +
                                                                          opportunity
                                                                              .gender,
                                                                      style: AppTextStyle.getDynamicFont(
                                                                           ColorValues.HEADING_COLOR_EDUCATION,
                                                                          14,
                                                                          FontType
                                                                              .Bold),
                                                                    ),
                                                                  )
                                                                :  Container(
                                                                    height: 0.0,
                                                                  ),*/
            UIHelper.verticalSpaceSmall1,
            Text("Scheduled For:",
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: List.generate(
                  opportunity.scheduleModelParam.length,
                      (index) {
                    return Padding(
                      padding:
                      const EdgeInsets.fromLTRB(0, 10, 0, 0),
                      child:
                      /* Text(
                                        opportunity
                                                .scheduleModelParam[index].day +
                                            " : " +
                                            getHours(index),
                                        maxLines: null,
                                        style: AppTextStyle.getDynamicFont(
                                             ColorValues.HEADING_COLOR_EDUCATION,
                                            14,
                                            FontType.Regular))*/
                      getHoursData(index),
                    );
                  }),
            ),
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.jobTitle.replaceAll("null", ""),
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
            UIHelper.verticalSpaceSmall1,
            Text(opportunity.description,
                style: AppTextStyle.getDynamicFont(
                    ColorValues.HEADING_COLOR_EDUCATION,
                    14,
                    FontType.Regular)),
          ],
        )
      ],
    );
  }

  Widget getMentorAdvisorTutor() {
    print('opportunity.fees:: ${opportunity.fees}');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall,
        AppTextStyle.getLableTextForDetailRow('Category ', categoryString),
        //opportunity.toMapStringForDesignation()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getLableTextForDetailRow('Subject ', subjectString),
        //opportunity.toMapStringSubject()),
        opportunity.offerId == "7" ? Container() : UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7"
            ? Container()
            : AppTextStyle.getLableTextForDetailRow(
            'Qualification ', opportunity.toMapStringQualification()),

        /*opportunity.offerId == "6" ? Container(): UIHelper.verticalSpaceSmall1,
        opportunity.offerId == "7" ? Text(
          "Mentee Support Offered: " +
              opportunity
                  .menteeSupport,
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        )
            :
        opportunity.offerId == "8" ? Text(
            "Advisor Support Offered: " +
                opportunity.advisorSupportOffered,
            style: AppTextStyle
                .getDynamicFont(
                 Color(
                    ColorValues
                        .HEADING_COLOR_EDUCATION),
                14,
                FontType
                    .Regular)) : Container(),
                    opportunity.offerId == "8" ? UIHelper
            .verticalSpaceSmall1: Container(),
        opportunity.offerId == "8" ? Text(
          "Project Areas: ${opportunity.projectAreas}",
          style: AppTextStyle
              .getDynamicFont(
               ColorValues.HEADING_COLOR_EDUCATION,
              14,
              FontType
                  .Regular),
        ): Container(),

                    */

        UIHelper.verticalSpaceSmall1,
        AppTextStyle.getLableTextForDetailRow(
            'Fees ',
            opportunity.fees == "0"
                ? MessageConstant.FEE_EMPTY_VAL
                : opportunity.fees),
      ],
    );
  }

  getJobInternship() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        UIHelper.verticalSpaceSmall1,
        AppTextStyle.getLableTextForDetailRow('Job type', opportunity.jobType),
        UIHelper.verticalSpaceSmall1,
        AppTextStyle.getLableTextForDetailRow(
            'Job location', opportunity.jobLocation),
        UIHelper.verticalSpaceSmall1,
      ],
    );
  }

  Widget getScheduleWidget(OpportunityModelForFeed opportunity) {
    print('opportunity.scheduleModelParam.length::: ${opportunity.scheduleModelParam.length}');
    return Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            BaseText(
                text: 'Scheduled for',
                textColor: ColorValues.labelColor,
                fontSize: 12.0,
                fontFamily: Constant.latoMedium,
                fontWeight: FontWeight.w600
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: List.generate(opportunity.scheduleModelParam.length, (index) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  child: getHoursData(index),
                );
              }),
            )
          ],
        ));
  }

  userImageListUI() {
    return Container(
      child: opportunity != null && opportunity.userImageModelParam.length > 0
          ? PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          15.0,
          10.0,
          Container(
              child: GridView.count(
                  primary: false,
                  shrinkWrap: true,
                  padding: const EdgeInsets.all(0.0),
                  crossAxisSpacing: 10.0,
                  childAspectRatio: 1.5,
                  scrollDirection: Axis.vertical,
                  crossAxisCount: 3,
                  children: List.generate(
                      opportunity.userImageModelParam.length, (index2) {
                    return Container(
                        child: Stack(
                          children: <Widget>[
                            InkWell(
                                child: FadeInImage.assetNetwork(
                                  fit: BoxFit.cover,
                                  placeholder: 'assets/aerial/default_img.png',
                                  image: Constant.IMAGE_PATH +
                                      opportunity
                                          .userImageModelParam[index2].file,
                                  height: 80.0,
                                  width: 120.0,
                                ),
                                onTap: () {
                                  Navigator.of(context).push(new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          CommonFullViewWidget(
                                              opportunity.userImageModelParam,
                                              MessageConstant.HOME_HEDING,
                                              index2,
                                              MessageConstant
                                                  .VIEWER_END_REWCOMMENDATION_HEDING)));

                                  /*  Navigator.push(
                                  context,
                                   HeroDialogRoute(
                                    builder: (BuildContext context) {
                                      return  Center(
                                        child:  AlertDialog(
                                          content:  Container(
                                            child:  Hero(
                                              tag: 'developer-hero',
                                              child:  Container(
                                                height: 200.0,
                                                width: 200.0,
                                                child: Image.network(
                                                  Constant.IMAGE_PATH_SMALL +
                                                      ParseJson.getMediumImage(
                                                          path.file),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              ),
                                            ),
                                          ),
                                          actions: <Widget>[
                                             FlatButton(
                                              child:  Text('Close'),
                                              onPressed: Navigator.of(context).pop,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                );*/
                                }),
                          ],
                        ));
                  })

                /*
                opportunity.userImageModelParam.map((path) {
                  return  Container(
                      child:  Stack(
                    children: <Widget>[
                       InkWell(
                          child: FadeInImage.assetNetwork(
                            fit: BoxFit.cover,
                            placeholder: 'assets/aerial/default_img.png',
                            image: Constant.IMAGE_PATH + path.file,
                            height: 80.0,
                            width: 120.0,
                          ),
                          onTap: () {
                            Navigator.push(
                              context,
                               HeroDialogRoute(
                                builder: (BuildContext context) {
                                  return  Center(
                                    child:  AlertDialog(
                                      content:  Container(
                                        child:  Hero(
                                          tag: 'developer-hero',
                                          child:  Container(
                                            height: 200.0,
                                            width: 200.0,
                                            child: Image.network(
                                              Constant.IMAGE_PATH_SMALL +
                                                  ParseJson.getMediumImage(
                                                      path.file),
                                              fit: BoxFit.fitHeight,
                                            ),
                                          ),
                                        ),
                                      ),
                                      actions: <Widget>[
                                         FlatButton(
                                          child:  Text('Close'),
                                          onPressed: Navigator.of(context).pop,
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          }),
                    ],
                  ));
                }).toList(),*/
              )))
          : Container(
        height: 0.0,
      ),
    );
  }
}
