/*
import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/group/AddTagGroupWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddMyConnectionSharePost.dart';
import 'package:spike_view_project/home/AddTagWidget.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';

// Create a Form Widget
class AddPostGroup extends StatefulWidget {
  ProfileInfoModal profileInfoModal;
  String groupId;
  GroupDetailModel groupDetailModel;

  AddPostGroup(this.profileInfoModal, this.groupId, this.groupDetailModel);

  @override
  AddPostGroupState createState() {
    return AddPostGroupState();
  }
}

class AddPostGroupState extends State<AddPostGroup> {
  SharedPreferences prefs;
  String userIdPref, token, userProfilePath;
  final _formKey = GlobalKey<FormState>();
  String isType = "Public";
  List<AssestForPost> assestList = List();
  VoidCallback listener;
  File videoPath;
  String strVideo;
  TextEditingController edtController;

  String sasToken, roleId, containerName, strPrefixPathforFeed;
  String strFirstName, strLastName, strEmail;
  List<dynamic> images;

  Future<File> videoFile;
  List<String> azureImageUploadList = List();
  VideoPlayerController _controller;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<TagsPost> selectedUerTagLIst = List();
  List<TagsPost> selectedtScopeList = List();
  List<TagModel> selectedUerTagLIst1;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    setState(() {
      userProfilePath;
    });
    strPrefixPathforFeed = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
    callApiForSaas();
  }

  @override
  void initState() {
    getSharedPreferences();
    edtController = TextEditingController(text: '');
    // TODO: implement initState
    listener = () {
      setState(() {});
    };

    super.initState();
  }

  @override
  void deactivate() {
    if (_controller != null) {
      _controller.setVolume(0.0);
      _controller.removeListener(listener);
    }
    super.deactivate();
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling().apiCall2(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddPostGroup", context);
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      if (sasToken != "" && containerName != "") {
        final String result = await platform.invokeMethod('getBatteryLevel', {
          "sasToken": sasToken,
          "imagePath": imagePath,
          "uploadPath": Constant.IMAGE_PATH + prefixPath
        });

        return result;
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddPostGroup", context);
      return "";
    }
  }

  //-------------------------------------Api Calling for feed--------------------------

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map;

        if (edtController.text != "" ||
            assestList.length > 0 ||
            videoPath != null) {
          if (assestList.length > 0) {
            map = {
              "post": {
                "text": edtController.text,
                "images": azureImageUploadList.map((item) => item).toList(),
                "media": ""
              },
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": widget.profileInfoModal.isActive,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
            };
          } else if (videoPath != null) {
            map = {
              "post": {
                "text": edtController.text,
                "images": [],
                "media": strPrefixPathforFeed + strVideo
              },
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": false,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
            };
          } else {
            map = {
              "post": {"text": edtController.text, "images": [], "media": ""},
              "postedBy": int.parse(userIdPref),
              "dateTime": DateTime.now().millisecondsSinceEpoch,
              "status": "",
              "visibility": isType,
              "scope": selectedtScopeList.map((item) => item.toJson()).toList(),
              "isActive": false,
              "tags": selectedUerTagLIst.map((item) => item.toJson()).toList(),
              "groupId": widget.groupId == "" ? "" : int.parse(widget.groupId),
              "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
              "lastActivityType": "CreateFeed",
              "roleId": int.parse(roleId),
            };
          }
          Response response = await ApiCalling()
              .apiCallPostWithMapData(context, Constant.ENDPOINT_ADD_FEED, map);

          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];
              if (status == "Success") {
                //ToastWrap.showToast(msg);
                RewardStatusResponse apiResponse =
                    RewardStatusResponse.fromJson(response.data);
                CustomProgressLoader.cancelLoader(context);
                Util.showRewardPointPush(apiResponse.rewardStatus, context);
                //Navigator.pop(context, "push");
              }
            }
          }
        } else {
          CustomProgressLoader.cancelLoader(context);
          ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddPostGroup", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    void onTapTagBtn() async {
      List<TagsPost> result = await Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) => AddTagGroupWidget(
                  "Tagging", widget.groupId, selectedUerTagLIst1)));

      if (result != null) {
        selectedUerTagLIst = result;
      }
    }

    void onTapTagSelectedConnection() async {
      List<TagsPost> result = await Navigator.of(context).push(
          new MaterialPageRoute(
              builder: (BuildContext context) => AddMyConnectionSharePost(
                  "MY CONNECTIONS", selectedtScopeList)));

      if (result != null) {
        selectedtScopeList = result;
      }
    }

    onTapPostButton() async {
      if (assestList.length > 0 ||
          edtController.text.trim() != "" ||
          videoPath != null) {
        if (assestList.length > 0) {
          for (int i = 0; i < assestList.length; i++) {
            String azureUploadPath = await uploadImgOnAzure(
                assestList[i].imagePath, strPrefixPathforFeed);
            azureImageUploadList.add(strPrefixPathforFeed + azureUploadPath);
          }

          String s = "ss";
        } else if (videoPath != null) {
          strVideo = await uploadImgOnAzure(
              videoPath
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim(),
              strPrefixPathforFeed);

          String s = "";
        }

        apiCalling();
      } else {
        ToastWrap.showToast(MessageConstant.WRITE_SOMETHING_ERROR, context);
      }
    }

    getVideo() {
      videoPath = null;
      setState(() {
        videoPath;
      });
      if (_controller != null) {
        _controller.setVolume(0.0);
        _controller.removeListener(listener);
      }
      ImagePicker.pickVideo(source: ImageSource.gallery).then((File file) {
        if (file != null && mounted) {
          setState(() {
            _controller = VideoPlayerController.file(file)
              ..addListener(listener)
              ..setVolume(1.0)
              ..initialize()
              ..setLooping(true)
              ..play();
            videoPath = file;
          });
        }
      });
    }

    getImage(type) async {
      if (assestList.length < 8) {
        int numberOfItems = 8 - assestList.length;
        // if (numberOfItems == 1) {
        File imagePath =
            await ImagePicker.pickImage(source: ImageSource.gallery);
        if (imagePath != null) {
          String strPath = imagePath.toString().substring(
              imagePath.toString().lastIndexOf("/") + 1,
              imagePath.toString().length);

          if (strPath.toString().contains(".") &&
              (!strPath.toString().contains(".gif"))) {
            if (imagePath != null) {
              assestList.add(new AssestForPost(
                  imagePath
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  "image",
                  "",
                  false));
              setState(() {
                assestList;
              });
              // }
            }
          } else {
            ToastWrap.showToast(
                MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.MAXIMUM_8_IMAGE_UPLOADED_VAL, context);
      }
    }

    Padding gridSelectedImages() {
      return assestList != null && assestList.length > 0
          ? PaddingWrap.paddingfromLTRB(
              5.0,
              0.0,
              5.0,
              10.0,
              Container(
                  height: 130.0,
                  child: GridView.count(
                    primary: true,
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.all(5.0),
                    crossAxisCount: 1,
                    childAspectRatio: .95,
                    mainAxisSpacing: 0.0,
                    crossAxisSpacing: 2.0,
                    children: List.generate(assestList.length, (int index) {
                      return Stack(
                        children: <Widget>[
                          InkWell(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Stack(
                                  children: <Widget>[
                                    Image.file(
                                      File(assestList[index].imagePath),
                                      fit: BoxFit.cover,
                                      height: 100.0,
                                      width: 120.0,
                                    ),
                                    Container(
                                      height: 100.0,
                                      width: 120.0,
                                      color: Colors.black54.withOpacity(.4),
                                    ),
                                    Align(
                                        alignment: Alignment.topRight,
                                        child: InkWell(
                                            child: PaddingWrap.paddingfromLTRB(
                                                0.0,
                                                0.0,
                                                7.0,
                                                0.0,
                                                Image.asset(
                                                  "assets/profile/delete_red.png",
                                                  width: 25.0,
                                                  height: 25.0,
                                                )),
                                            onTap: () {
                                              assestList.removeAt(index);
                                              setState(() {
                                                assestList;
                                              });
                                            }))
                                  ],
                                )
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  )))
          : PaddingWrap.paddingfromLTRB(
              5.0,
              10.0,
              5.0,
              10.0,
              Container(
                height: 1.0,
              ));
    }

    Widget _previewVideo(VideoPlayerController controller) {
      if (controller == null) {
        return Text(
          MessageConstant.ABOUT_GROUP_YOU_HAVE_NOT_PICKED_VIDEO,
          textAlign: TextAlign.center,
        );
      } else if (controller.value.initialized) {
        return Container(
          height: 120.0,
          child: Stack(
            children: <Widget>[
              Container(
                  height: 120.0,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: AspectRatio(
                      aspectRatio:
                          controller.value.size.height > 500 ? 0.5 : (16 / 9),
                      child: VideoPlayer(_controller),
                    ),
                  )),
              Positioned(
                  top: 8.0,
                  right: 3.0,
                  child: InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          7.0,
                          0.0,
                          Image.asset(
                            "assets/profile/delete_red.png",
                            width: 30.0,
                            height: 30.0,
                          )),
                      onTap: () {
                        videoPath = null;

                        if (_controller != null) {
                          _controller.setVolume(0.0);
                          _controller.removeListener(listener);
                        }
                        setState(() {
                          _controller;
                          videoPath;
                        });
                      }))
            ],
          ),
        );
      } else {
        return Text(
          'Error Loading Video',
          textAlign: TextAlign.center,
        );
      }
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: Scaffold(
            backgroundColor: ColorValues.NAVIGATION_DRAWER_BG_COLOUR,
            appBar: AppBar(
              automaticallyImplyLeading: false,
              titleSpacing: 2.0,
              brightness: Brightness.light,
              leading: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        Image.asset(
                          "assets/profile/post/back_arrow_blue.png",
                          height: 30.0,
                          width: 30.0,
                        )),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  )
                ],
              ),
              title: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Text(
                    "POST",
                    style: AppTextStyle.getDynamicStyleGroup(
                        ColorValues.BLUE_COLOR, null, FontType.Regular),
                    */
/*TextStyle(color:  ColorValues.BLUE_COLOR,fontFamily: Constant.TYPE_CUSTOMREGULAR,)*//*

                  )
                ],
              ),
              actions: <Widget>[
                InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      5.0,
                      0.0,
                      8.0,
                      5.0,
                      Image.asset(
                        "assets/newIcon/post_icon.png",
                        height: 35.0,
                        width: 35.0,
                      )),
                  onTap: () {
                    if (assestList.length > 0 ||
                        edtController.text.trim() != "" ||
                        videoPath != null) {
                      CustomProgressLoader.showLoader(context);
                      Timer _timer =
                          Timer(const Duration(milliseconds: 400), () {
                        onTapPostButton();
                      });
                    } else {
                      ToastWrap.showToast(
                          MessageConstant.WRITE_SOMETHING_ERROR, context);
                    }
                  },
                )
              ],
              backgroundColor: Colors.white,
            ),
            body: ListView(
              children: <Widget>[
                Container(
                  height: assestList.length > 0 || videoPath != null
                      ? 355.0
                      : 255.0,
                  child: Stack(
                    children: <Widget>[
                      Positioned(
                        bottom: 0.0,
                        right: 0.0,
                        left: 0.0,
                        top: 70.0,
                        child: Container(
                            child: Card(
                                elevation: 2.0,
                                child: Column(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        5.0,
                                        30.0,
                                        5.0,
                                        0.0,
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            TextField(
                                              maxLines: 3,
                                              textCapitalization:
                                                  TextCapitalization.sentences,
                                              maxLength: 2000,
                                              controller: edtController,
                                              autofocus: true,
                                              style: TextStyle(
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                              keyboardType: TextInputType.text,
                                              textAlign: TextAlign.start,
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                errorStyle: Util.errorTextStyle,
                                                filled: true,
                                                counterStyle: TextStyle(
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                                hintText: "Write Here..",
                                                hintStyle: TextStyle(
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR,
                                                    color: Colors.grey),
                                                fillColor: Colors.transparent,
                                              ),
                                            ),
                                            videoPath != null
                                                ? _previewVideo(_controller)
                                                : Container(
                                                    height: 1.0,
                                                  ),
                                            gridSelectedImages(),
                                          ],
                                        )),
                                  ],
                                ))),
                      ),
                      Positioned(
                        top: 15.0,
                        left: 10.0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Container(
                              child: userProfilePath == null ||
                                      userProfilePath == "null" ||
                                      userProfilePath == ""
                                  ? Image.asset(
                                      "assets/profile/user_on_user.png",
                                      fit: BoxFit.cover,
                                    )
                                  : FadeInImage.assetNetwork(
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      placeholder:
                                          'assets/profile/user_on_user.png',
                                      image: Constant.IMAGE_PATH_SMALL +
                                          ParseJson.getSmallImage(
                                            userProfilePath,
                                          ),
                                    ),
                              width: 80.0,
                              height: 100.0,
                              padding:
                                  EdgeInsets.fromLTRB(10.0, 20.0, 0.0, 20.0),
                            ),
                            PaddingWrap.paddingfromLTRB(
                                5.0,
                                0.0,
                                5.0,
                                20.0,
                                Text(
                                  widget.profileInfoModal != null
                                      ? widget.profileInfoModal.lastName !=
                                                  null ||
                                              widget.profileInfoModal
                                                      .lastName ==
                                                  "null" ||
                                              widget.profileInfoModal
                                                      .lastName ==
                                                  ""
                                          ? widget.profileInfoModal.firstName
                                          : widget.profileInfoModal.firstName +
                                              " " +
                                              widget.profileInfoModal.lastName
                                      : "",
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      fontSize: 20.0),
                                ))
                          ],
                        ),
                      ),
                      Align(
                          alignment: Alignment.bottomLeft,
                          child: Row(
                            children: <Widget>[
                              InkWell(
                                child: PaddingWrap.paddingAll(
                                    10.0,
                                    Image.asset(
                                      "assets/profile/post/camera.png",
                                      fit: BoxFit.cover,
                                      color: ColorValues.GREY_TEXT_COLOR,
                                      height: 25.0,
                                      width: 25.0,
                                    )),
                                onTap: () async {
                                  if (videoPath == null) {
                                    var status = await Permission.photos.status;
                                    if (status.isGranted) {
                                      getImage(ImageSource.gallery);
                                    } else {
                                      checkPermissionPhoto(context);
                                    }
                                  } else
                                    null;
                                },
                              ),
                              InkWell(
                                child: PaddingWrap.paddingAll(
                                    10.0,
                                    Image.asset(
                                      "assets/profile/post/video.png",
                                      fit: BoxFit.cover,
                                      height: 28.0,
                                      color: ColorValues.GREY_TEXT_COLOR,
                                      width: 28.0,
                                    )),
                                onTap: () async {
                                  if (assestList.length == 0) {
                                    var status = await Permission.photos.status;
                                    if (status.isGranted) {
                                      getVideo();
                                    } else {
                                      checkPermissionPhoto(context);
                                    }
                                  } else
                                    null;
                                },
                              ),
                              InkWell(
                                child: PaddingWrap.paddingAll(
                                    10.0,
                                    Image.asset(
                                      "assets/profile/post/tagging.png",
                                      fit: BoxFit.cover,
                                      height: 26.0,
                                      color: ColorValues.GREY_TEXT_COLOR,
                                      width: 26.0,
                                    )),
                                onTap: () {
                                  onTapTagBtn();
                                },
                              ),
                            ],
                          )),
                    ],
                  ),
                )
              ],
            )));
  }
}
*/
