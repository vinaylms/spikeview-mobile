class ReferPointResponse {
  String status;
  List<Result> result;

  ReferPointResponse({this.status, this.result});

  ReferPointResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result =  List<Result>();
      json['result'].forEach((v) {
        result.add(new Result.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Result {
  String sId;
  int gamificationId;
  String activityType;
  int creationTime;
  int iV;
  List<Actions> actions;

  Result(
      {this.sId,
      this.gamificationId,
      this.activityType,
      this.creationTime,
      this.iV,
      this.actions});

  Result.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    gamificationId = json['gamificationId'];
    activityType = json['activityType'];
    creationTime = json['creationTime'];
    iV = json['__v'];
    if (json['actions'] != null) {
      actions =  List<Actions>();
      json['actions'].forEach((v) {
        actions.add(new Actions.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['_id'] = this.sId;
    data['gamificationId'] = this.gamificationId;
    data['activityType'] = this.activityType;
    data['creationTime'] = this.creationTime;
    data['__v'] = this.iV;
    if (this.actions != null) {
      data['actions'] = this.actions.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Actions {
  int actionId;
  String action;
  String type;
  String actionLabel;
  int point;

  Actions(
      {this.actionId, this.action, this.type, this.actionLabel, this.point});

  Actions.fromJson(Map<String, dynamic> json) {
    actionId = json['actionId'];
    action = json['action'];
    type = json['type'];
    actionLabel = json['actionLabel'];
    point = json['point'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  Map<String, dynamic>();
    data['actionId'] = this.actionId;
    data['action'] = this.action;
    data['type'] = this.type;
    data['actionLabel'] = this.actionLabel;
    data['point'] = this.point;
    return data;
  }
}
