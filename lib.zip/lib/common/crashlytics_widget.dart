import 'dart:io';
import 'package:flutter/services.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

class CrashlyticsWidget {
  static const platform = const MethodChannel('samples.flutter.io/battery');

  recordCrashlyticsError(error , screenName ,contextNeme)async{
    FirebaseCrashlytics.instance.setCustomKey('spikeview_exception',
        Platform.isIOS?"Ios::"+screenName+":-"+error.toString(): "Android::"+screenName+":-"+error.toString());

    //FirebaseCrashlytics.instance.crash();

/*// Set a key to a boolean.
    FirebaseCrashlytics.instance.setCustomKey("spikeview_bool_key", true);

// Set a key to an int.
    FirebaseCrashlytics.instance.setCustomKey("spikeview_int_key", 1);

// Set a key to a double.
    FirebaseCrashlytics.instance.setCustomKey("spikeview_double_key", 1.0);

    FirebaseCrashlytics.instance.recordError(error, screenName, reason:error );*/
  }
}

final crashlytics_bloc = CrashlyticsWidget();

