import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/PublicProfileFilter/publicview/PublicProfileFilterViewWidget.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ProfileLogDataModel.dart';
import 'package:spike_view_project/modal/ProfileShareLogModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/UserProfileDashBoardForOtherUser.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'CustomProfileShareLog.dart';

class ProfileVisibilitySetting extends StatefulWidget {
  String userId, pageName;
  bool isParentCalling;

  ProfileVisibilitySetting(this.userId, this.isParentCalling, {this.pageName});

  @override
  ProfileVisibilitySettingState createState() =>
      ProfileVisibilitySettingState();
}

class ProfileVisibilitySettingState extends State<ProfileVisibilitySetting> {
  bool selectActiveButton1 = false;
  bool selectActiveButton2 = true;
  String isPerformChanges = "pop", userIdPref, roleId, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;
  ProfileInfoModal profileInfoModal;
  bool isLoading = false;
  bool isCoomunitySetting = true;
  bool isPreLoginSetting = true;

  List<ProfileShareModel> profileShareLogLIst = List();

  ProfileLogDataModel _mProfileLogDataModel;

  showSucessMsg(msg, context, duration, maxLine) {
    Timer _timer;

    print("timer on");
    _timer = Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            ));
  }

  onBack() async {
    if (widget.pageName != null && widget.pageName == "main") {
      if (widget.isParentCalling) {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context, isPerformChanges);
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PERSONAL_INFO++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                if (mounted) {
                  try {
                    isPreLoginSetting =
                        response.data["result"]["isLeaderboardDisplay"];
                    var communityPostSubscription =
                        response.data["result"]["communityPostSubscription"];
                    if (communityPostSubscription != null &&
                        communityPostSubscription.length > 0) {
                      for (int i = 0;
                          i < communityPostSubscription.length;
                          i++) {
                        if (communityPostSubscription[i]["roleId"].toString() ==
                            roleId) {
                          print("Community+++++++" +
                              communityPostSubscription[i]["isSubscribed"]
                                  .toString());
                          isCoomunitySetting =
                              communityPostSubscription[i]["isSubscribed"];
                          setState(() {});
                        }
                      }
                    }
                  } catch (e) {}
                  setState(() {
                    isHide = profileInfoModal.isHide;
                    prefs.setString(
                        UserPreference.ISHide, profileInfoModal.isHide);
                    prefs.setString(
                        UserPreference.ISACTIVE, profileInfoModal.isActive);
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
      print("ENDPOINT_PERSONAL_INFO++++" + e.toString());
    }
  }

  Future apiCallingForCommunitySetting(value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "isSubscribed": value
      };
      print("map:-" + map.toString());

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_COMMUNITY_SETTING, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isCoomunitySetting = value;
            showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForPreLogin(value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "isLeaderboardDisplay": value
      };
      print("map:-" + map.toString());

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_LEADERBOARD_SETTING, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isPreLoginSetting = value;
            showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();

    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = "1";

    isHide = prefs.getString(UserPreference.ISHide);
    if (widget.userId != null &&
        widget.userId != "null" &&
        widget.userId != "") {
      userIdPref = widget.userId;
    }
    setState(() {
      isLoading = true;
    });
    //getData(true);
    await profileApi(true);
    if (profileInfoModal != null) dob = profileInfoModal.dob;

    setState(() {
      isLoading = false;
    });
    setState(() {});
  }

  Future apiCallingForUpdateStudentHideStatus(isHideBool) async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "isHide": isHideBool,
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          //String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setString(UserPreference.ISHide, isHideBool);
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallForGetShareLog() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {});
        print(
            'Log Api URL:: ${Constant.ENDPOINT_SHARE_LOG + widget.userId + "&roleId=" + roleId}');
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_SHARE_LOG + widget.userId + "&roleId=" + roleId,
            "get");

        isLoading = false;
        setState(() {});

        print(Constant.ENDPOINT_SHARE_LOG + widget.userId);
        print("LOg Api response profile+++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileShareLogLIst.clear();
              profileShareLogLIst =
                  ParseJson.parseMapShareLog(response.data['result']);
              if (profileShareLogLIst.length > 0) {
                setState(() {});
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {});
    }
  }

  //--------------------------Api Calling for update user Status ------------------
  Future apiCallingForUpdateStudentStatus(index) async {
    try {
      print(
          'inside apiCallingForUpdateStudentStatus isActive:: ${_mProfileLogDataModel.result[index].isActive}');
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "sharedId": int.parse(profileShareLogLIst[index].sharedId),
          "isActive": profileShareLogLIst[index].isActive
        };

        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_SHARE_UPDATE, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            //String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg+profileShareLogLIst[index].isActive.toString());
              setState(() {
                profileShareLogLIst[index].isActive = "false";
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForUpdateURl(index) async {
    print(
        'inside apiCallingForUpdateURl isActive:: ${_mProfileLogDataModel.result[index].isActive}');
    print(
        'inside apiCallingForUpdateURl customProfileLink:: ${_mProfileLogDataModel.result[index].customProfileLink}');
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String profileId = "";
        if (_mProfileLogDataModel.result[index].customProfileLink
            .contains("Linear"))
          profileId = _mProfileLogDataModel.result[index].customProfileLink
              .split("/Linear/")[1];
        else
          profileId = _mProfileLogDataModel.result[index].customProfileLink
              .split("/Preso/")[1];
        Codec<String, String> stringToBase64 = utf8.fuse(base64);
        String decodedSharedId =
            stringToBase64.decode(profileId.replaceAll("&SPK", "="));
        Map map = {
          "userId": userIdPref,
          "roleId": roleId,
          "profileId": decodedSharedId,
          "isActive": _mProfileLogDataModel.result[index].isActive
        };
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_PROFILE_SHARE_UPDATE, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            //String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg+profileShareLogLIst[index].isActive.toString());
              setState(() {
                _mProfileLogDataModel.result[index].isActive = false;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Future getData(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);

        Response response = await ApiCalling2().apiCall(
            context, Constant.ENDPOINT_PROFILE_SHARE_LOG + userIdPref, "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        print("ENDPOINT_PROFILE_DETAIL++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            if (response.data[LoginResponseConstant.STATUS] == "Success") {
              _mProfileLogDataModel =
                  ProfileLogDataModel.fromJson(response.data);
              setState(() {});
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      print("getProfileDetail_INFO++++" + e.toString());
    }
  }

  @override
  void initState() {
    getSharedPreferences();
    super.initState();
  }

  bool dobCheck(String time) {
    if (time != "null") {
      int millis = int.tryParse(time);
      DateTime bod = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = DateTime.now().year - bod.year;

      DateTime currentDate = DateTime.now();
      int age = currentDate.year - bod.year;

      if (age > 13) {
        return true;
      }
      if (age == 13) {
        print("apurva equal" + '$age');
        int month1 = currentDate.month;
        int month2 = bod.month;
        if (month2 > month1) {
          print("apurva below" + '$age');
          return false;
        } else if (month1 == month2) {
          int day1 = currentDate.day;
          int day2 = bod.day;
          if (day2 > day1) {
            print("apurva below" + '$age');
            return false;
          } else {
            print("apurva equal or above" + '$age');
            return true;
          }
        } else {
          print("apurva equal or above" + '$age');
          return true;
        }
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  onTapPublicConnecedLinear() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => PublicProfileFilterViewWidget(
            profileInfoModal.userId,
            profileInfoModal.dob,
            /*         Constant.PUBLIC_URL_PATH +*/
            profileInfoModal.publicUrl,
            "Connected",
            widget.isParentCalling,
            false,
            isUnderThirteen: false)));
    if (result == "push") {
      Navigator.pop(context, "push");
    }
  }

  onTapPublicNonConnecedLinear() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            UserProfileDashBoardForOther(userIdPref, false, "setting", "1")));
    if (result == "push") {
      Navigator.pop(context, "push");
    }
  }

  onTapCustomProfile() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            CustomProfileShareLog(userIdPref, false)));
    if (result == "push") {
      Navigator.pop(context, "push");
    }
  }

  void infoDialog() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => SafeArea(
            child: Scaffold(
                backgroundColor: Colors.black38,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        left: 0.0,
                        bottom: 40.0,
                        child: Container(
                            height: 200.0,
                            color: Colors.transparent,
                            child: Stack(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    13.0,
                                    0.0,
                                    ListView(children: <Widget>[
                                      Container(
                                        height: 145.0,
                                        padding: EdgeInsets.all(10.0),
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                        ),
                                        child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                  "You can set up custom profile visibility for your connections, users not connected to you. If you are under 13, your parents will have to approve the visibility settings.",
                                                  textAlign:
                                                      TextAlign.center,
                                                  maxLines: 5,
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION_1,
                                                      height: 1.2,
                                                      fontSize: 16.0,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR)),
                                            ]),
                                      )
                                    ])),
                              ],
                            ))),
                    Positioned(
                      right: 0.0,
                      left: 0.0,
                      bottom: 10.0,
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: PaddingWrap.paddingfromLTRB(
                            13.0,
                            0.0,
                            13.0,
                            0.0,
                            Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                ),
                                padding: EdgeInsets.all(10.0),
                                height: 51.0,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: InkWell(
                                        child: Container(
                                            child: Text(
                                          "Ok",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontSize: 16.0,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR),
                                        )),
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      flex: 1,
                                    )
                                  ],
                                ))),
                      ),
                    ),
                  ],
                ))));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          onBack();
          return Future.value(false);
        },
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: IconButton(
                icon: Image.asset("assets/newDesignIcon/icon/back_icon.png",
                    height: 32.0, width: 32.0, fit: BoxFit.fill),
                onPressed: () {
                  onBack();
                }),
            backgroundColor: Colors.white,
            elevation: 0.0,
            actions: <Widget>[
              InkWell(
                child: Center(
                  child: Image.asset(
                    "assets/png/info_new.png",
                    height: 30.0,
                    width: 30.0,
                    fit: BoxFit.fill,
                  ),
                ),
                onTap: () {
                  infoDialog();
                },
              ),
              const SizedBox(width: 10),
            ],
          ),
          backgroundColor: Colors.white,
          body: isLoading
              ? Container(
                  height: 0.0,
                )
              : Container(
                  child: Column(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        alignment: Alignment.topLeft,
                        padding: EdgeInsets.only(bottom: 10),
                        color: AppConstants.colorStyle.white,
                        child: PaddingWrap.paddingfromLTRB(
                            15.0,
                            5.0,
                            15.0,
                            5.0,
                            BaseText(
                              text: 'Profile visibility',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 1,
                            )),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      flex: 1,
                      child: ListView(
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(top: 25.0),
                            child: InkWell(
                              child: Container(
                                margin: EdgeInsets.only(left: 15, right: 15),
                                padding: EdgeInsets.only(
                                    left: 15, right: 15, top: 12, bottom: 12),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                              widget.isParentCalling
                                                  ? "Profile visibility for your child's connections."
                                                  : "Profile visibility to your connections.",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily:
                                                      Constant.latoMedium)),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                              widget.isParentCalling
                                                  ? "Review profile view for your child's connections."
                                                  : "Review your profile view for your connections.",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color:
                                                      ColorValues.TEXT_HEADER,
                                                  fontFamily:
                                                      Constant.latoRegular)),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                        child: Image.asset(
                                      "assets/newDesignIcon/icon/arrow_left.png",
                                      height: 18.0,
                                    )),
                                  ],
                                ),
                              ),
                              onTap: () async {
                                if (dobCheck(dob)) {
                                  onTapPublicConnecedLinear();
                                } else {
                                  String result = await Navigator.of(context)
                                      .push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              PublicProfileFilterViewWidget(
                                                  profileInfoModal.userId,
                                                  profileInfoModal.dob,
                                                  /* Constant.PUBLIC_URL_PATH +*/
                                                  profileInfoModal.publicUrl,
                                                  "Connected",
                                                  widget.isParentCalling,
                                                  false,
                                                  isUnderThirteen: true)));

                                  if (result == "push") {
                                    Navigator.pop(context, "push");
                                  }
                                }
                              },
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 15.0),
                            child: InkWell(
                              child: Container(
                                margin: EdgeInsets.only(left: 15, right: 15),
                                padding: EdgeInsets.only(
                                    left: 15, right: 15, top: 12, bottom: 12),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                              widget.isParentCalling
                                                  ? "Profile visibility to users not connected to your child."
                                                  : "Profile visibility to users not connected to you.",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily:
                                                      Constant.latoMedium)),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                              widget.isParentCalling
                                                  ? "Review your child's profile view for users not connected to them."
                                                  : "Review your profile view for users not connected to you.",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color:
                                                      ColorValues.TEXT_HEADER,
                                                  fontFamily:
                                                      Constant.latoRegular)),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                        child: Image.asset(
                                      "assets/newDesignIcon/icon/arrow_left.png",
                                      height: 18.0,
                                    )),
                                  ],
                                ),
                              ),
                              onTap: () async {
                                onTapPublicNonConnecedLinear();
                              },
                            ),
                          ),
                          profileInfoModal != null &&
                                  dobCheck(dob) &&
                                  profileInfoModal.isPublicProfileGlobalyActive
                              ? Padding(
                                  padding: const EdgeInsets.only(top: 15.0),
                                  child: InkWell(
                                    child: Container(
                                      margin:
                                          EdgeInsets.only(left: 15, right: 15),
                                      padding: EdgeInsets.only(
                                          left: 15,
                                          right: 15,
                                          top: 12,
                                          bottom: 12),
                                      decoration: BoxDecoration(
                                        color: ColorValues.SELECTION_BG,
                                        border: Border.all(
                                          color: ColorValues.SELECTION_BG,
                                          width: 1.0,
                                        ),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: <Widget>[
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                    "Public profile visibility.",
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoMedium)),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                    "Configure your public profile visibility.",
                                                    style: TextStyle(
                                                        fontSize: 12,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: ColorValues
                                                            .TEXT_HEADER,
                                                        fontFamily: Constant
                                                            .latoRegular)),
                                              ],
                                            ),
                                          ),
                                          InkWell(
                                              child: Image.asset(
                                            "assets/newDesignIcon/icon/arrow_left.png",
                                            height: 18.0,
                                          )),
                                        ],
                                      ),
                                    ),
                                    onTap: () async {
                                      String result = await Navigator.of(
                                              context)
                                          .push(new MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  PublicProfileFilterViewWidget(
                                                      profileInfoModal.userId,
                                                      profileInfoModal.dob,
                                                      /*        Constant.PUBLIC_URL_PATH +*/
                                                      profileInfoModal
                                                          .publicUrl,
                                                      "Public",
                                                      widget.isParentCalling,
                                                      profileInfoModal.publicUrl ==
                                                                  null ||
                                                              profileInfoModal
                                                                      .publicUrl ==
                                                                  "null" ||
                                                              profileInfoModal
                                                                      .publicUrl ==
                                                                  ""
                                                          ? true
                                                          : false,
                                                      isUnderThirteen: false)));
                                      if (result == "push") {
                                        Navigator.pop(context, "push");
                                      }
                                    },
                                  ),
                                )
                              : Container(
                                  height: 0.0,
                                ),
                          Padding(
                            padding: const EdgeInsets.only(top: 15.0),
                            child: InkWell(
                              child: Container(
                                margin: EdgeInsets.only(left: 15, right: 15),
                                padding: EdgeInsets.only(
                                    left: 15, right: 15, top: 12, bottom: 12),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text("Custom profile share.",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily:
                                                      Constant.latoMedium)),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                              widget.isParentCalling
                                                  ? "Log of your child's custom profile shares."
                                                  : "Log of your custom profile shares.",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color:
                                                      ColorValues.TEXT_HEADER,
                                                  fontFamily:
                                                      Constant.latoRegular)),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                        child: Image.asset(
                                      "assets/newDesignIcon/icon/arrow_left.png",
                                      height: 18.0,
                                    )),
                                  ],
                                ),
                              ),
                              onTap: () async {
                                onTapCustomProfile();
                              },
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                )),
        ));
  }
}
