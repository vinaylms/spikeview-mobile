import 'dart:async';
import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import '../main.dart';

class NewConnectedWidget extends StatefulWidget {
  @override
  State<NewConnectedWidget> createState() => _NewConnectedWidgetState();
}

class _NewConnectedWidgetState extends State<NewConnectedWidget>
    with AutomaticKeepAliveClientMixin {
  SharedPreferences prefs;
  String userIdPref, roleId, userProfilePath;
  TextEditingController edtController = TextEditingController();
  List<RequestedTagModel> searchList = List();
  bool isLoading = true, _isLoadMore = false;
  int skip = 0;
  ScrollController _scrollController = ScrollController();
  StreamSubscription<dynamic> _streamSubscription;
  SlidableController slidableCtrl = SlidableController();
  bool isChat_AccessControl = true;

  //--------------------------api Calling for tag------------------
  Future apiCallingForTag(String type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                Constant.ACCEPTED +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString() +
                "&name=" +
                edtController.text.trim() +
                "&limit=" +
                "10",
            "get");
        print('---> url = ${response.request.baseUrl}${response.request.path}');
        log("---> " + response.toString());
        isLoading = false;
        isLoadMore = false;
        setState(() {});
        if (type != "load") {
          searchList.clear();
        }
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<RequestedTagModel> tagListLocal = List();
              tagListLocal =
                  ParseJson.parseRequestedTagList(response.data['result']);
              if (tagListLocal != null && tagListLocal.isNotEmpty) {
                searchList.addAll(tagListLocal);
              }
              _setupList();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ConnectionWidget", context);
      isLoading = false;
      setState(() {});
      print("ERROR+++" + e.toString());
    }
  }

  Future<void> apiCallingForUnfriend(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId),
        "userId": int.parse(userIdPref),
      };
      print("map:-" + map.toString());

      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            searchList.removeAt(index);
            setState(() {});
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "ConnectionWidget", context);
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    try {
      isChat_AccessControl =
      prefs.getString(UserPreference.ACCESS_CONTROL_CHAT).toLowerCase() ==
          "disable"
          ? false
          : true;
    } catch (e) {
      isChat_AccessControl = true;
    }

    ProfileBloc.connectedController.stream.listen((map) {
      try {
        if (map != null) {
          searchList.clear();
          skip = 0;
          List<RequestedTagModel> tagListLocal = List();
          tagListLocal = ParseJson.parseRequestedTagList(map['Accepted']);
          if (tagListLocal != null && tagListLocal.isNotEmpty) {
            searchList.addAll(tagListLocal);
          }
          _setupList();
        }
      } catch (e) {
        print("stream+++" + e.toString());
        crashlytics_bloc.recordCrashlyticsError(e, "ConnectionWidget", context);
      }
    });
    bloc.fetchConnected(userIdPref, context, prefs, false, "0");
  }

  void _setupList() {
    if (searchList.isNotEmpty) {
      for (RequestedTagModel model in searchList) {
        if (model.partnerId == "1") {
          RequestedTagModel local = model;
          searchList.remove(model);
          searchList.insert(0, local);
        }
      }
      setState(() {});
    }
  }

  @override
  void initState() {
    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
      if (Constant.CONNECTIONS_PROFILE == value) {
        skip = 0;
        isLoading = true;
        setState(() {});
        apiCallingForTag("");
      }
    });

    getSharedPreferences();
    isLoading = true;
    setState(() {});
    apiCallingForTag("");
    _scrollController.addListener(() {
      if (!isLoading) {
        if (_scrollController.position.pixels ==
            _scrollController.position.maxScrollExtent) {
          skip = skip + 1;
          isLoadMore = true;
          apiCallingForTag("load");
        }
      }
    });
    super.initState();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Widget getMoreDropDown() {
    return PopupMenuButton<String>(
      offset: const Offset(0.0, 60.0),
      child: PaddingWrap.paddingfromLTRB(5.0, 0.0, 0.0, 0.0, Container()),
      itemBuilder: (BuildContext context) => <PopupMenuItem<String>>[
        PopupMenuItem(
          child: Padding(
              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              child: Text(
                "Reach out to spikeview with questions or requests.",
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: 16.0,
                    color: Colors.black),
              )),
          value: "0",
        ),
      ],
    );
  }


  Widget getListview(RequestedTagModel requestedTagModel, index) {
    return Slidable(
      controller: slidableCtrl,
      actionPane: SlidableDrawerActionPane(),
      actionExtentRatio: 0.18,
      closeOnScroll: true,
      child: Padding(
          padding: EdgeInsets.fromLTRB(20, index==0?6:16, 20, 16),
          child: Row(
            children: <Widget>[
              Expanded(
                child:  ProfileImageView(
                  imagePath:Constant.IMAGE_PATH_SMALL +
                      ParseJson.getSmallImage(
                          requestedTagModel.patner.profilePicture),
                  placeHolderImage: requestedTagModel.partnerRoleId == "4"
                      ? "assets/profile/partner_img.png"
                      : 'assets/profile/user_on_user.png',
                  height: 48.0,
                  width: 48.0,
                  onTap: () async{
                    if (requestedTagModel.patner.userId == userIdPref) {
                    } else {
                      Util.onTapImageTile(
                          tapedUserRole: requestedTagModel.partnerRoleId,
                          partnerUserId: requestedTagModel.patner.userId,
                          context: context);
                    }
                  },
                ),
                flex: 0,
              ),
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    10.0,
                    0.0,
                    0.0,
                    0.0,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Expanded(
                              child: InkWell(
                                child: BaseText(
                                  text: requestedTagModel.patner.lastName ==
                                              null ||
                                          requestedTagModel.patner.lastName ==
                                              "null" ||
                                          requestedTagModel.patner.lastName ==
                                              ""
                                      ? requestedTagModel.patner.firstName
                                      : requestedTagModel.patner.firstName +
                                          " " +
                                          requestedTagModel.patner.lastName,
                                  textColor:
                                      ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  maxLines: 1,
                                  textAlign: TextAlign.start,
                                ),
                                onTap: () {
                                  if (requestedTagModel.patner.userId ==
                                      userIdPref) {
                                  } else {
                                    // Util.onTapImageTile(
                                    //     tapedUserRole: requestedTagModel
                                    //         .partnerRoleId,
                                    //     partnerUserId: requestedTagModel
                                    //         .patner.userId,
                                    //     context: context);
                                    if (requestedTagModel.patner.isActive ==
                                        "true") {
                                      Friends model = Friends(
                                        connectId: int.parse(
                                            requestedTagModel.connectId),
                                        userId: int.parse(prefs
                                            .getString(UserPreference.USER_ID)),
                                        firstName:
                                            requestedTagModel.patner.firstName,
                                        lastName:
                                            requestedTagModel.patner.lastName,
                                        profilePicture: requestedTagModel
                                            .patner.profilePicture,
                                        partnerId: int.parse(
                                            requestedTagModel.partnerId),
                                        partnerFirstName:
                                            requestedTagModel.patner.firstName,
                                        partnerLastName:
                                            requestedTagModel.patner.lastName,
                                        partnerRoleId: int.parse(
                                            requestedTagModel.partnerRoleId),
                                        partnerProfilePicture: requestedTagModel
                                            .patner.profilePicture,
                                        dateTime: DateTime.now()
                                            .millisecondsSinceEpoch,
                                        creationTime: requestedTagModel
                                                        .patner.creationTime !=
                                                    null &&
                                                requestedTagModel
                                                        .patner.creationTime !=
                                                    "null" &&
                                                requestedTagModel
                                                        .patner.creationTime !=
                                                    ""
                                            ? int.parse(requestedTagModel
                                                .patner.creationTime)
                                            : 0,
                                        isActive: true,
                                        online: 1,
                                        lastMessage: "",
                                        unreadMessages: 0,
                                        lastTime: 0,
                                        lastSeen: 0,
                                        textSentBy: int.parse(prefs
                                            .getString(UserPreference.USER_ID)),
                                        badge: requestedTagModel.patner.badge,
                                        badgeImage:
                                            requestedTagModel.patner.badgeImage,
                                        gamificationPoints: requestedTagModel
                                            .patner.gamificationPoints,
                                      );
    if (isChat_AccessControl||requestedTagModel.partnerId=='1') {
      Navigator.of(context).push(
          MaterialPageRoute(
              builder: (BuildContext context) =>
                  ChatRoomWidget(
                      model, "", "")));
    }else{
      ToastWrap.showToastForAccessDenied(
          MessageConstant.FEATURE_DIABLED,
          context);
    }
                                    } else {
                                      ToastWrap.showToast(
                                          MessageConstant
                                              .CONNECTION_INACTIVE_ERROR,
                                          context);
                                    }
                                  }
                                },
                              ),
                              flex: 0,
                            ),
                            Expanded(
                              child:
                                  //requestedTagModel.patner.roleId == "1" ?
                                  requestedTagModel.partnerRoleId == "1"
                                      ? Util.getStudentBadge12New(
                                          requestedTagModel.patner.badge,
                                          requestedTagModel.patner.badgeImage)
                                      : Container(),
                              flex: 0,
                            )
                          ],
                        ),
                        requestedTagModel.patner.tagline == null ||
                                requestedTagModel.patner.tagline == "null" ||
                                requestedTagModel.patner.tagline == ""
                            ? Container(
                                height: 0.0,
                              )
                            : Padding(
                                padding:
                                    const EdgeInsets.only(top: 4.0, bottom: 5),
                                child: Row(
                                  children: <Widget>[
                                    Flexible(
                                        child: TextViewWrap.textView(
                                      requestedTagModel.patner.tagline ==
                                                  null ||
                                              requestedTagModel
                                                      .patner.tagline ==
                                                  "null" ||
                                              requestedTagModel
                                                      .patner.tagline ==
                                                  ""
                                          ? ""
                                          : requestedTagModel.patner.tagline,
                                      TextAlign.start,
                                      ColorValues.labelColor,
                                      14.0,
                                      FontWeight.normal,
                                    )),
                                  ],
                                ),
                              ),
                      ],
                    )),
                flex: 1,
              ),
              Expanded(
                child: Row(
                  children: <Widget>[
                    // InkWell(
                    //   child: Padding(
                    //       padding:
                    //           EdgeInsets.fromLTRB(10.0, 4.0, 10.0, 0.0),
                    //       child: Container(
                    //           height: 33.0,
                    //           width: 30.0,
                    //           child: Image.asset(
                    //             'assets/newDesignIcon/connections/chat.png',
                    //           ))),
                    //   onTap: () {
                    //     print(
                    //         "SSS Chat press ${requestedTagModel.patner.creationTime}");
                    //     print(
                    //         " SSS Chat press ${requestedTagModel.patner.badgeImage}");
                    //     print(
                    //         "SSS Chat press ${requestedTagModel.patner.gamificationPoints}");
                    //     print(
                    //         "SSS Chat press ${requestedTagModel.partnerRoleId}");
                    //     if (requestedTagModel.patner.isActive ==
                    //         "true") {
                    //       Friends model = Friends(
                    //         connectId:
                    //             int.parse(requestedTagModel.connectId),
                    //         userId: int.parse(prefs
                    //             .getString(UserPreference.USER_ID)),
                    //         firstName:
                    //             requestedTagModel.patner.firstName,
                    //         lastName: requestedTagModel.patner.lastName,
                    //         profilePicture:
                    //             requestedTagModel.patner.profilePicture,
                    //         partnerId:
                    //             int.parse(requestedTagModel.partnerId),
                    //         partnerFirstName:
                    //             requestedTagModel.patner.firstName,
                    //         partnerLastName:
                    //             requestedTagModel.patner.lastName,
                    //         partnerRoleId: int.parse(
                    //             requestedTagModel.partnerRoleId),
                    //         partnerProfilePicture:
                    //             requestedTagModel.patner.profilePicture,
                    //         dateTime:
                    //             DateTime.now().millisecondsSinceEpoch,
                    //         creationTime:
                    //             requestedTagModel.patner.creationTime !=
                    //                         null &&
                    //                     requestedTagModel
                    //                             .patner.creationTime !=
                    //                         "null" &&
                    //                     requestedTagModel
                    //                             .patner.creationTime !=
                    //                         ""
                    //                 ? int.parse(requestedTagModel
                    //                     .patner.creationTime)
                    //                 : 0,
                    //         isActive: true,
                    //         online: 1,
                    //         lastMessage: "",
                    //         unreadMessages: 0,
                    //         lastTime: 0,
                    //         lastSeen: 0,
                    //         textSentBy: int.parse(prefs
                    //             .getString(UserPreference.USER_ID)),
                    //         badge: requestedTagModel.patner.badge,
                    //         badgeImage:
                    //             requestedTagModel.patner.badgeImage,
                    //         gamificationPoints: requestedTagModel
                    //             .patner.gamificationPoints,
                    //       );

                    //       Navigator.of(context).push(MaterialPageRoute(
                    //           builder: (BuildContext context) =>
                    //               ChatRoomWidget(model, "", "")));
                    //     } else {
                    //       ToastWrap.showToast(
                    //           MessageConstant.CONNECTION_INACTIVE_ERROR,
                    //           context);
                    //     }
                    //   },
                    // ),
                    // requestedTagModel.patner.userId == "1"
                    //     ? Expanded(
                    //         child: Padding(
                    //             padding: EdgeInsets.fromLTRB(
                    //                 7.0, 0.0, 0.0, 0.0),
                    //             child: getMoreDropDown()),
                    //         flex: 0,
                    //       )
                    //     :  Container(
                    //             height: 0.0,
                    //           )
                    // : InkWell(
                    //     child: Padding(
                    //         padding: EdgeInsets.fromLTRB(
                    //             10.0, 0.0, 0.0, 0.0),
                    //         child: Container(
                    //             height: 30.0,
                    //             width: 30.0,
                    //             child: Image.asset(
                    //               'assets/newDesignIcon/connections/cancel.png',
                    //             ))),
                    //     onTap: () {
                    //       String name = requestedTagModel
                    //                       .patner.lastName ==
                    //                   null ||
                    //               requestedTagModel
                    //                       .patner.lastName ==
                    //                   "null" ||
                    //               requestedTagModel
                    //                       .patner.lastName ==
                    //                   ""
                    //           ? requestedTagModel
                    //               .patner.firstName
                    //           : requestedTagModel
                    //                   .patner.firstName +
                    //               " " +
                    //               requestedTagModel
                    //                   .patner.lastName;

                    //       educationRemoveConfromationDialog(
                    //           requestedTagModel.connectId,
                    //           name,
                    //           index);
                    //     },
                    //   )
                  ],
                ),
                flex: 0,
              ),
            ],
          )),
      secondaryActions: <Widget>[
        requestedTagModel.patner.userId == "1"
            ? SlideAction(
                child: Text("Info",
                    style: TextStyle(
                        color: ColorValues.WHITE,
                        fontSize: 14.0,
                        fontFamily: Constant.latoRegular)),
                // color: ColorValues.Delete_lable_color,
                decoration: BoxDecoration(color: ColorValues.BLUE_COLOR),
                onTap: () {
                  showInfo();
                },
              )
            : SlideAction(
                child: Text("Delete",
                    style: TextStyle(
                        color: ColorValues.WHITE,
                        fontSize: 14.0,
                        fontFamily: Constant.latoRegular)),
                // color: ColorValues.Delete_lable_color,
                decoration:
                    BoxDecoration(color: ColorValues.Delete_lable_color),

                onTap: () {
                  String name = requestedTagModel.patner.lastName == null ||
                          requestedTagModel.patner.lastName == "null" ||
                          requestedTagModel.patner.lastName == ""
                      ? requestedTagModel.patner.firstName
                      : requestedTagModel.patner.firstName +
                          " " +
                          requestedTagModel.patner.lastName;

                  educationRemoveConfromationDialog(
                      requestedTagModel.connectId, name, index);
                },
              ),
      ],
    );
  }

  Future<Null> _refreshPageHere() async {
    skip = 0;
    isLoading = true;
    setState(() {});
    apiCallingForTag("");
  }

  Timer _timer;

  void _onSearch() {
    if(edtController.text.trim().isNotEmpty) {
      if (_timer?.isActive ?? false) {
        _timer?.cancel();
      }
      _timer = Timer(Duration(seconds: 1), () {
        skip = 0;
        isLoading = true;
        setState(() {});
        apiCallingForTag('');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark);

    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
          child: SizedBox(
            height: 40,
            child: TextField(
              textAlign: TextAlign.left,
              controller: edtController,
              onChanged: (value) {
                _onSearch();
              },
              decoration: InputDecoration(
                filled: true,
                fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                hintText: "Search connections",
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontFamily: Constant.latoRegular,
                    color: ColorValues.hintColor),
                contentPadding: EdgeInsets.fromLTRB(15.0, 10.0, 20.0, 10.0),
                suffixIcon: IconButton(
                  onPressed: () {
                    /* if (edtController.text.trim() != "") {
                      apiCallingForTag("");
                    }*/
                  },
                  icon: Image.asset(
                    "assets/newDesignIcon/connections/new_search.png",
                    height: 20,
                    width: 20,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                  borderSide: BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(10.0),
                  ),
                  borderSide: BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                ),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    borderSide:
                        new BorderSide(color: ColorValues.BORDER_COLOR_NEW)),
              ),
            ),
          ),
        ),
        Expanded(
          child: isLoading
              ? const SizedBox.shrink()
              : searchList.length > 0
                  ? RefreshIndicator(
                      onRefresh: _refreshPageHere,
                      displacement: 0.0,
                      child: SingleChildScrollView(
                        controller: _scrollController,
                        padding: EdgeInsets.only(bottom: 10),
                        child: ListView.builder(
                          itemCount: searchList.length,
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder:
                              ( context,  position) {
                            return Column(
                              children: [
                                getListview(
                                    searchList[position], position),
                                _divider(),
                              ],
                            );
                          },
                        ),
                      ),
                    )
                  : Center(
                      child: edtController.text.trim().isNotEmpty
                          ? Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  "assets/newDesignIcon/icon/no_user_found.png",
                                  height: 111.0,
                                ),
                                const SizedBox(height: 10),
                                BaseText(
                                  text: 'No user found',
                                  textColor: ColorValues.HEADING_COLOR_CHAT_1,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 18,
                                  textAlign: TextAlign.center,
                                  maxLines: 1,
                                ),
                              ],
                            )
                          : Column(
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    80.0,
                                    0.0,
                                    0.0,
                                    Image.asset(
                                      "assets/newDesignIcon/connection_blank.png",
                                      width: 77.0,
                                      height: 77.0,
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                    40.0,
                                    25.0,
                                    40.0,
                                    5.0,
                                    TextViewWrap.textView(
                                        "No connection request yet",
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        16.0,
                                        FontWeight.normal)),
                                PaddingWrap.paddingfromLTRB(
                                    40.0,
                                    10.0,
                                    40.0,
                                    5.0,
                                    TextViewWrap.textViewMultiLine(
                                        "Connect with friends to motivate and inspire each other . Get social and get better",
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal,
                                        3)),
                              ],
                            ),
                    ),
          flex: 1,
        ),
      ],
    );
  }

  Widget _divider() {
    return const Padding(
      padding: EdgeInsets.fromLTRB(20, 1, 20, 0),
      child: Divider(
        thickness: 1,
        height: 0,
        color: Color(0xffE5EBF0),
      ),
    );
  }

  void educationRemoveConfromationDialog(id, name, index) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            msg: 'Are you sure you want to delete?',
            negativeText: 'Cancel',
            positiveText: 'Delete',
            isSucessPopup: false,
            positiveTextColor:ColorValues
                .circle4,
            onNegativeTap: () {
            },
            onPositiveTap: (){
              apiCallingForUnfriend(
                  id, index);
            },
          );
        });


  }

  void showInfo() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            headingText: 'Reach out to spikeview with questions or requests.',
            negativeText: 'OK',

            isSucessPopup: true,
            msg: null,
          );
        });
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;

  get isLoadMore => _isLoadMore;

  set isLoadMore(value) {
    _isLoadMore = value;
    setState(() {});
  }
}
