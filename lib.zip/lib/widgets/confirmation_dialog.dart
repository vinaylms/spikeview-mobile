import 'package:flutter/material.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';

class ConfirmationDialog extends StatelessWidget {
  final String msg;
  final String positiveText;
  final String negativeText;
  final String headingText;
  final Color positiveTextColor;
  final Color headingTextColor;
  final VoidCallback onPositiveTap;
  final VoidCallback onNegativeTap;
  final Widget child;
  final bool isSucessPopup;
  final bool isThreeStepPopup;
  final TextStyle msgTextStyle;

  const ConfirmationDialog({
    @required this.msg,
    this.positiveText,
    this.headingText,
    this.negativeText,
    this.positiveTextColor,
    this.onPositiveTap,
    this.onNegativeTap,
    this.child,
    this.isSucessPopup,
    this.isThreeStepPopup,
    this.msgTextStyle,
    this.headingTextColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
      child: isThreeStepPopup != null && isThreeStepPopup
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      headingText == null
                          ? const SizedBox()
                          : Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: BaseText(
                                text: headingText,
                                textAlign: TextAlign.center,
                                textColor:headingTextColor ??  const Color(0xff27275A),
                                fontSize: 16,
                                lineHeight: 1.5,
                                fontFamily: Constant.latoMedium,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                      msg == null
                          ? const SizedBox()
                          : Padding(
                              padding: const EdgeInsets.only(bottom: 0.0),
                              child: BaseText(
                                text: msg,
                                style: msgTextStyle ??
                                    TextStyle(
                                      color: const Color(0xff666B9A),
                                      fontSize: 14,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w400,
                                    ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                      const SizedBox(height: 15),
                      Divider(
                        height: 0,
                        thickness: 1,
                        color: const Color(0xffE8E8E8),
                      ),
                      InkWell(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: BaseText(
                            text: positiveText ?? "Remove",
                            textAlign: TextAlign.center,
                            textColor:
                                positiveTextColor ?? const Color(0xffEB5757),
                            fontSize: 16,
                            fontFamily: Constant.latoRegular,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        onTap: () {
                          Navigator.pop(context);
                          if (onPositiveTap != null) {
                            onPositiveTap();
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                InkWell(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    alignment: Alignment.center,
                    child: BaseText(
                      text: negativeText ?? "Cancel",
                      textAlign: TextAlign.center,
                      textColor: Color(0xff27275A),
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: Constant.latoRegular,
                    ),
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    if (onNegativeTap != null) {
                      onNegativeTap();
                    }
                  },
                ),
              ],
            )
          : isSucessPopup == null || isSucessPopup == false
              ? Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                      ),
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          child ??
                              BaseText(
                                text: msg,
                                textAlign: TextAlign.center,
                                lineHeight: 1.5,
                                style: msgTextStyle ??
                                    TextStyle(
                                      color: const Color(0xff27275A),
                                      fontSize: 16,

                                      fontFamily: Constant.latoRegular,
                                      // fontWeight: FontWeight.w600,
                                    ),
                              ),
                          const SizedBox(height: 15),
                          Divider(
                            height: 0,
                            thickness: 1,
                            color: const Color(0xffE8E8E8),
                          ),
                          InkWell(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 12),
                              child: BaseText(
                                text: positiveText ?? "Remove",
                                textAlign: TextAlign.center,
                                textColor: positiveTextColor ??
                                    const Color(0xffEB5757),
                                fontSize: 16,
                                fontFamily: Constant.latoRegular,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            onTap: () {
                              Navigator.pop(context);
                              if (onPositiveTap != null) {
                                onPositiveTap();
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    InkWell(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: BaseText(
                          text: negativeText ?? "Cancel",
                          textAlign: TextAlign.center,
                          textColor: Color(0xff27275A),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          fontFamily: Constant.latoRegular,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        if (onNegativeTap != null) {
                          onNegativeTap();
                        }
                      },
                    ),
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.all(15),
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                      ),
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          headingText == null
                              ? const SizedBox.shrink()
                              : Padding(
                                  padding: const EdgeInsets.only(bottom: 9),
                                  child: BaseText(
                                    text: headingText,
                                    textAlign: TextAlign.center,
                                    textColor: headingTextColor ?? const Color(0xff27275A),
                                    fontSize: 16,
                                    fontFamily: Constant.latoMedium,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                          msg == null
                              ? const SizedBox.shrink()
                              : BaseText(
                                text: msg,
                                style: msgTextStyle ??
                                    TextStyle(
                                      color: const Color(0xff666B9A),
                                      fontSize: 14,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w400,
                                    ),
                                textAlign: TextAlign.center,
                              ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    InkWell(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: BaseText(
                          text: negativeText ?? "Cancel",
                          textAlign: TextAlign.center,
                          textColor: const Color(0xff27275A),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          fontFamily: Constant.latoRegular,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        if (onNegativeTap != null) {
                          onNegativeTap();
                        }
                      },
                    ),
                  ],
                ),
    );
  }
}
