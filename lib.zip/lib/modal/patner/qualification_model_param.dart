class QualificationModelParam {
  bool isOther;
  String name;
  int qualificationId;

  QualificationModelParam({this.name, this.qualificationId,this.isOther});
  
  static Map<String, dynamic> toMap(QualificationModelParam categoryObject) {
    Map<String, dynamic> categoryMap = Map();
    categoryMap['name'] = categoryObject.name;
    categoryMap['qualificationId'] = categoryObject.qualificationId;
    categoryMap['isOther'] = categoryObject.isOther;
    return categoryMap;
  }

  static List<Map<String, dynamic>> mapList(List<QualificationModelParam> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "name": category.name,
              "qualificationId": category.qualificationId,
              "isOther": category.isOther,
            })
        .toList();
    return listOfCategory;
  }


  String toMapString() {
    String data = "";

    data = data + this.name;

    return data;
  }
}
