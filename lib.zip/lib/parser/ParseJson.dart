import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';

//import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:spike_view_project/Connection/RefferalModel.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/modal/BadgeDataModel.dart';
import 'package:spike_view_project/modal/BadgeListModel.dart';
import 'package:spike_view_project/modal/IntroDuctioVideoModel.dart';
import 'package:spike_view_project/modal/LocationData.dart';
import 'package:spike_view_project/modal/ResumeModel.dart';
import 'package:spike_view_project/modal/SkillBarModel.dart';
import 'package:spike_view_project/modal/TestDataModel.dart';
import 'package:spike_view_project/modal/TestScoreModel.dart';
import 'package:spike_view_project/modal/patner/CategoryFormModel.dart';
import 'package:spike_view_project/modal/patner/category_model.dart';
import 'package:spike_view_project/modal/patner/designation_model_param.dart';
import 'package:spike_view_project/modal/patner/qualification_model_param.dart';
import 'package:spike_view_project/modal/patner/schedule_model_param.dart';
import 'package:spike_view_project/modal/patner/subject_model_param.dart';
import 'package:spike_view_project/modal/patner/user_image_model_param.dart';
import 'package:spike_view_project/patnerFlow/opportunity/Service.dart';

import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/chat/modal/ConnectionListModel.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/group/model/GroupModel.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompanyProfileModel.dart';
import 'package:spike_view_project/modal/CompetencyMasterDataModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/ConnectionNotificationModel.dart';
import 'package:spike_view_project/modal/DashBoardDetailModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/OpportunityModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'dart:async';
import 'package:spike_view_project/patnerFlow/opportunity/Service.dart';
import 'dart:io';
import 'dart:ui';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'dart:convert';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/ProfileShareLogModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/modal/ShareProfileModel.dart';
import 'package:spike_view_project/modal/SpiderChartModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/modal/patner/CompanyModel.dart';
import 'package:spike_view_project/modal/patner/OpportunityModel.dart';
import 'package:spike_view_project/modal/patner/age_between.dart';
import 'package:spike_view_project/modal/patner/offer_model.dart';
import 'package:spike_view_project/modal/patner/user_signup_model.dart';
import 'package:spike_view_project/notification/model/NotificationModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/item.dart';
import 'package:spike_view_project/socialLink/model/SelectedSocialLinkModel.dart';

class ParseJson {
  static String getMediumImage(image) {
    if (image == null || image == "" || image == "null") {
      return "";
    } else {
      /*  image = image.replaceAll(
          image.substring(image.lastIndexOf("/") + 1, image.length),
          "m-" + image.substring(image.lastIndexOf("/") + 1, image.length));

         print("imagepath======="+image);*/
      // https://spikeviewmediastorage.blob.core.windows.net/spikeview-media-production-thumbnails/sv_2/feeds/m-image_02143fc388674d9ab9cd4bb355182308.jpg
      return image;
    }
  }

  static String getSmallImage(image) {
    if (image == null || image == "" || image == "null") {
      return "";
    } else {
      /*image = image.replaceAll(
          image.substring(image.lastIndexOf("/") + 1, image.length),
          "s-" + image.substring(image.lastIndexOf("/") + 1, image.length));
      print("imagepath======="+image);*/
      return image;
    }
  }

  static CompanyModel parseCompanyInfo(data) {
    try {
      String companyId = data[0]["companyId"].toString();
      String userId = data[0]["userId"].toString();
      String roleId = data[0]["roleId"].toString();
      String name = data[0]["name"].toString();
      String address = data[0]["address"].toString();
      String phone = data[0]["phone"].toString();
      String about = data[0]["about"].toString();
      String profilePicture = data[0]["profilePicture"].toString();
      String coverPicture = data[0]["coverPicture"].toString();
      String partnerStatus = data[0]["partnerStatus"].toString();
      String declineReason = data[0]["declineReason"].toString();

      List<OfferModel> offers = List();

      for (int i = 0; i < data[0]["offer"].length; i++) {
        String offerId = data[0]["offer"][i]['offerId'].toString();
        String name = data[0]["offer"][i]['name'].toString();
        /*String isSelectedS = data[0]["offer"][i]['isSelected'].toString();

        bool isSelected=true;
        if(isSelectedS == "false")
          isSelected = false;

        offers.add(new OfferModel(offerId: int.parse(offerId), name: name,isSelected: isSelected));*/
        offers.add(new OfferModel(offerId: int.parse(offerId), name: name));
      }
      /*  if (profilePicture != "") {
      strNetworkImage = profilePicture;
    }*/

      return CompanyModel(
          profilePicture,
          coverPicture,
          companyId,
          userId,
          roleId,
          name,
          address,
          phone,
          about,
          offers,
          partnerStatus,
          declineReason);
    } catch (e) {
      e.toString();
    }
  }

  static List<UserPostModal> parseFeedForReport(map, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();

    try {
      String dateTime2 = "0";
      bool isLike = map['isLiked'];
      int likesCount = map['likesCount'];
      if(likesCount==null){
        likesCount=0;
      }
      bool isCommented = false;
      String _id = map['_id'].toString();
      String feedId = map['feedId'].toString();
      bool isLiked = map['isLiked'];
      String postedGroupId = map['groupId'].toString();
      String postedGroupName = map['groupName'].toString();
      String postedBy = map['postedBy'].toString();
      String dateTime = map['dateTime'].toString();
      String schoolCode = map['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      String visibility = map['visibility'].toString();
      String firstName = map['firstName'].toString();
      String lastName = map['lastName'].toString();
      String email = map['email'].toString();
      String roleId = map['roleId'].toString();
      String feedStatus = map['feedStatus'].toString();
      print("FeeddStatus++++++" + feedStatus.toString());
      String profilePicture = map['profilePicture'].toString();
//postOwnerRoleId ,roleId
      // profilePicture = getSmallImage(profilePicture);

      String badgeImage = map['badgeImage'].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = map['badge'].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification = map['gamificationPoints'].toString();
      int gamificationPoints;
      if (gamification == "null" || gamification == "") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      if (gamificationPoints == null) {
        gamificationPoints = 0;
      }

      String postOwnerBadgeImage = map['postOwnerBadgeImage'].toString();
      if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
        postOwnerBadgeImage = "";
      }
      String postOwnerBadge = map['postOwnerBadge'].toString();
      if (postOwnerBadge == "null" || postOwnerBadge == "") {
        postOwnerBadge = "";
      }
      String postOwnerGamification =
          map['postOwnerGamificationPoints'].toString();
      int postOwnerGamificationPoints;
      if (postOwnerGamification == "null" || postOwnerGamification == "") {
        postOwnerGamificationPoints = 0;
      } else {
        postOwnerGamificationPoints = int.parse(postOwnerGamification);
      }
      if (postOwnerGamificationPoints == null) {
        postOwnerGamificationPoints = 0;
      }

      String title = map['title'].toString();
      String tagline = map['tagline'].toString();
      String shareText = map['shareText'].toString();
      String shareTime = map['shareTime'].toString();
      String lastActivityTime = map['lastActivityTime'].toString();
      String lastActivityType = map['lastActivityType'].toString();

      String postOwner = map['postOwner'].toString();
      if (postOwner == '0') {
        postOwner = 'null';
      }
      String postOwnerRoleId = map['postOwnerRoleId'].toString();
      String isReported = map['isReported'].toString();
      bool isOpportunity = map['isOpportunity'];

      String postOwnerFirstName = map['postOwnerFirstName'].toString();
      String postOwnerLastName = map['postOwnerLastName'].toString();
      bool postOwnerDeleted = false;
      try {
        postOwnerDeleted =
            map['postOwnerDeleted'] == null ? false : map['postOwnerDeleted'];
      } catch (e) {
        postOwnerDeleted = false;
      }
      String postOwnerTitle = map['postOwnerTitle'].toString();
      String postOwnerProfilePicture =
          map['postOwnerProfilePicture'].toString();
      List<String> reasonList = List<String>();
      String reasonText = "";
      try {
        var reasonModel = map['report'];

        var reasonMap = reasonModel['reasonType'];
        reasonText = reasonModel['reason'].toString();
        if (reasonMap != null) {
          for (int i = 0; i < reasonMap.length; i++) {
            String reason = reasonMap[i].toString();
            if (reason != "") reasonList.add(reason);
          }
        }
        print("report+++" + reasonList.length.toString());
      } catch (e) {
        print("report+++" + e.toString());
      }
      //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
      DateTime currentDate = DateTime.now();
      if (dateTime != "null") {
        int d = int.tryParse(dateTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        print("firstName++" + firstName.toString());
        print("long++" + d.toString());

        dateTime = getTimeValue(date, currentDate);
        dateTime2 = getMinutes(date, currentDate);
      }
      if (shareTime != "null") {
        int d = int.tryParse(shareTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        shareTime = getTimeValue(date, currentDate);
      }

      var imageMap = map['post']['images'];
      var assetMap = map['post']['assets'];
      String text = map['post']['text'].toString();
      String media = map['post']['media'].toString();
      List<String> imageList = List<String>();
      if (imageMap != null) {
        for (int i = 0; i < imageMap.length; i++) {
          String image = imageMap[i];
          // image = getMediumImage(image);
          if (image != "") imageList.add(image);
        }
      }
      List<AssetIV> assetList = List<AssetIV>();
      if (assetMap != null) {
        for (int i = 0; i < assetMap.length; i++) {
          String image = assetMap[i]["url"];
          String type = assetMap[i]["type"];
          // image = getMediumImage(image);
          if (image != "") assetList.add(AssetIV(file: image, type: type));
        }
      }

      String _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage;

      try {
        _metaUrl = map['post']['metaData']['url'];
        _metaSource = map['post']['metaData']['source'];
        _metaHeight = map['post']['metaData']['height'];
        _metaWidth = map['post']['metaData']['width'];
        _metaTitle = map['post']['metaData']['title'];
        _metaDescription = map['post']['metaData']['description'];
        _metaImage = map['post']['metaData']['image'];
      } catch (e) {
        _metaUrl = "";
        _metaSource = "";
        _metaHeight = "";
        _metaWidth = "";
        _metaTitle = "";
        _metaDescription = "";
        _metaImage = "";
      }

      PostData postData = PostData(
          imageList,
          assetList,
          text,
          media,
          _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage);
      print("sss commetns 5");
      List<CommentData> commentList = List();
      var commentMap = map['comments'];
      if (commentMap != null) {
        for (int j = (commentMap.length - 1); j >= 0; j--) {
          String commentId = commentMap[j]['_id'].toString();
          String comment = commentMap[j]['comment'].toString();
          String commentedBy = commentMap[j]['commentedBy'].toString();
          String dateTime = commentMap[j]['dateTime'].toString();
          String profilePicture = commentMap[j]['profilePicture'].toString();
          String name = commentMap[j]['name'].toString();
          String title = ""; //commentMap[j]['title'].toString();
          String roleId = ""; //commentMap[j]['commentedByRole'].toString();
          String userId = ""; //commentMap[j]['userId'].toString();
          var likesMap = []; //commentMap[j]['likes'];

          String badgeImage = commentMap[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = commentMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification =
              ""; //commentMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          DateTime currentDate = DateTime.now();
          if (dateTime != "null") {
            int d = int.tryParse(dateTime);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            dateTime = getTimeValue(date, currentDate);
          }
          //  profilePicture = getSmallImage(profilePicture);

          List<Likes> likesList = List();
          bool isCommentLike = false;
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();

            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['commentRoleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();

            String profilePicture = likesMap[k]['profilePicture'].toString();
            // profilePicture = getSmallImage(profilePicture);
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            if (userId == userIdPref && roleId == userRoleID) {
              isCommentLike = true;
            }
          }
          commentList.add(new CommentData(
              commentId,
              comment,
              commentedBy,
              dateTime,
              profilePicture,
              name,
              title,
              userId,
              likesList,
              isCommentLike,
              roleId,
              badge,
              gamificationPoints,
              badgeImage,
              true));
          if (commentedBy == userIdPref && roleId == userRoleID) {
            isCommented = true;
          }
        }
      }

      List<Likes> likesList = List();
      var likesMap = map['likes'];
      if (likesMap != null) {
        for (int k = 0; k < likesMap.length; k++) {
          String userId = likesMap[k]['userId'].toString();
          String name = likesMap[k]['name'].toString();
          String status = likesMap[k]['status'].toString();
          String roleId = likesMap[k]['roleId'].toString();
          String statusValue = likesMap[k]['statusValue'].toString();
          String profilePicture = likesMap[k]['profilePicture'].toString();
          String title = likesMap[k]['title'].toString();

          String badgeImage = likesMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = likesMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = likesMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          likesList.add(new Likes(userId, name, profilePicture, title, status,
              statusValue, roleId, badge, gamificationPoints, badgeImage));
          // if (userId == userIdPref && roleId == userRoleID) {
          //   isLike = true;
          // }
        }
      }
      List<Tags> tagList = List();
      try {
        var tagMap = map['tags'];

        for (int k = 0; k < tagMap.length; k++) {
          String userId = tagMap[k]['userId'].toString();
          String name = tagMap[k]['name'].toString();
          String profilePicture = tagMap[k]['profilePicture'].toString();
          String title = tagMap[k]['title'].toString();
          String roleId = tagMap[k]['roleId'].toString();
          String badgeImage = tagMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = tagMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = tagMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          tagList.add(new Tags(userId, name, profilePicture, title, roleId,
              badge, gamificationPoints, badgeImage));
        }
      } catch (e) {}

      //------------------- Apurva added Group list start-------------------

      List<Groups> groupList = List();
      try {
        var groupMap = map['groups'];

        for (int k = 0; k < groupMap.length; k++) {
          String groupId = groupMap[k]['groupId'].toString();
          String groupName = groupMap[k]['groupName'].toString();
          String groupImage = groupMap[k]['groupImage'].toString();

          groupList.add(new Groups(groupId, groupName, groupImage));
        }
      } catch (e) {}

      //------------------- Apurva added Group list end-------------------

      var scopeMap = map['scope'];

      List<ScopeModel> scopeList = List<ScopeModel>();
      if (scopeMap != null) {
        for (int k = 0; k < scopeMap.length; k++) {
          String userId = scopeMap[k]['userId'].toString();
          String roleId = scopeMap[k]['roleId'].toString();
          scopeList.add(ScopeModel(userId, roleId));
        }
      }
      String opportunityCretedUserName = map['firstName'].toString() +
          " " +
          map['lastName'].toString().replaceAll("null", "");

      String opportunityCretedUserImage = map['profilePicture'].toString();
      OpportunityModelForFeed opportunityModelForFeed;
      int differenceDay = 0;
      print("isOpportunity+++++" + isOpportunity.toString());
      if (isOpportunity) {
        var postOpportunity = map["postOpportunity"];
        String opportunityId = postOpportunity[0]["opportunityId"].toString();
        String userId = postOpportunity[0]["userId"].toString();
        String roleId = postOpportunity[0]["roleId"].toString();
        String jobTitle = postOpportunity[0]["jobTitle"].toString();
        String timeZone = postOpportunity[0]["timeZone"].toString();
        String jobType = postOpportunity[0]["jobType"].toString();
        String schoolCode = postOpportunity[0]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String jobLocation = postOpportunity[0]["jobLocation"].toString();
        String project = postOpportunity[0]["project"].toString();
        String duration = postOpportunity[0]["duration"].toString();
        String status = postOpportunity[0]["status"].toString();
        String fromDate = postOpportunity[0]["fromDate"].toString();
        String toDate = postOpportunity[0]["toDate"].toString();
        String groupId = postOpportunity[0]["groupId"].toString();
        String targetAudience = postOpportunity[0]["targetAudience"].toString();
        String title = postOpportunity[0]["title"].toString();
        String gender = postOpportunity[0]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = postOpportunity[0]["companyId"].toString();
        String offerId = postOpportunity[0]["offerId"].toString();
        String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
        String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
        String expiresOn = postOpportunity[0]["expiresOn"].toString();
        String coverPicture = postOpportunity[0]["coverPicture"].toString();
        String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
        String companyName = postOpportunity[0]["companyName"].toString();
        String profilePicture = postOpportunity[0]["profilePicture"].toString();
        String category = postOpportunity[0]["category"].toString();
        //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
        String name = postOpportunity[0]["name"].toString();
        String declineReason = postOpportunity[0]["declineReason"].toString();
        String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
        String url, groupIdAction, callingNumber, formId, linkUrlPosition;
        bool groupIsPublic = true;
        String actionType =
            postOpportunity[0]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          url = postOpportunity[0]['callToAction'][0]['url'].toString();
          linkUrlPosition =
              postOpportunity[0]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction =
              postOpportunity[0]['callToAction'][0]['groupId'].toString();
          groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
          print("groupIsPublic+++++" + groupIsPublic.toString());
          if (groupIsPublic == null) {
            groupIsPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber =
              postOpportunity[0]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        print("shubh+++" + "action" + actionType);

        List<Address> locationList = List<Address>();
        var locationMap = postOpportunity[0]['location'];
        if (locationMap != null) {
          for (int i = 0; i < locationMap.length; i++) {
            String zipcode = locationMap[i]['zipcode'].toString();
            String city = locationMap[i]['city'].toString();
            String country = locationMap[i]['country'].toString();
            String state = locationMap[i]['state'].toString();
            String name = locationMap[i]['name'].toString();
            String target = locationMap[i]['target'].toString();
            locationList
                .add(Address(name, "", city, state, country, zipcode, target));
          }
        }

        List<AgeModel> ageList = List<AgeModel>();
        var ageMao = postOpportunity[0]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          String to = ageMao[k]['to'].toString();
          String from = ageMao[k]['from'].toString();
          //  file= getMediumImage(file);

          ageList.add(new AgeModel(to, from));
        }

        List<IntrestModel> interestTypeList = List<IntrestModel>();
        try {
          var interestTypeModel = postOpportunity[0]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
            //  file= getMediumImage(file);

            interestTypeList.add(new IntrestModel(id, name));
          }
        } catch (e) {}

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = postOpportunity[0]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        if (expiresOn != "null") {
          int d = int.tryParse(expiresOn);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          differenceDay = currentDate.difference(date).inDays;
          print("Difference between++++" + differenceDay.toString());
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        var userImageData = postOpportunity[0]['userImage']; //
        try {
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
        String fees = postOpportunity[0]["fees"].toString();
        String description = postOpportunity[0]["description"].toString();
        String bio = postOpportunity[0]["bio"].toString();
        //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
        //String projectArea = postOpportunity[0]["projectArea"].toString();
        String qualification = postOpportunity[0]["qualification"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        var sceduleData = postOpportunity[0]['schedule']; //
        try {
          if (sceduleData != null) {
            for (int k = 0; k < sceduleData.length; k++) {
              String day = sceduleData[k]['day'].toString();
              var hours = sceduleData[k]['hours'];
              //  file= getMediumImage(file);
              //HoursData hoursData;
              List<HoursData> hoursList = List();
              for (var item in hours) {
                hoursList.add(new HoursData(
                    timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
              }
              scheduleModelParam
                  .add(new ScheduleModelParam(day: day, hours: hoursList));
            }
          }
        } catch (e) {}

        List<String> otherCategoryList = List<String>();
        var otherCategoryMap = postOpportunity[0]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();

            otherCategoryList.add(name);
          }
        }

        List<String> otherCareerList = List<String>();
        var otherCareerMap = postOpportunity[0]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();

            otherCareerList.add(name);
          }
        }
        List<String> otherSubjectList = List<String>();
        var otherSubjectMap = postOpportunity[0]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();

            otherSubjectList.add(name);
          }
        }

        List<MainCategory> designationModelParam = List<MainCategory>();
        var designationData = postOpportunity[0]['category']; //
        try {
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new MainCategory(
                  name: name, categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}

        List<SubCategory> subjectModelParam = List<SubCategory>();
        var subjectData = postOpportunity[0]['subjects']; //
        try {
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(
                  SubCategory(name: name, subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}

        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        var qualificationData = postOpportunity[0]['qualification']; //
        if (qualificationData != null) {
          try {
            for (int k = 0; k < qualificationData.length; k++) {
              String name = qualificationData[k]['name'].toString();
              String isOtherS = qualificationData[k]['isOther'].toString();
              String qualificationId =
                  qualificationData[k]['qualificationId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              qualificationModelParam.add(new QualificationModelParam(
                  name: name,
                  isOther: isOther,
                  qualificationId: int.parse(qualificationId)));
            }
          } catch (e) {}
        }

        opportunityModelForFeed = OpportunityModelForFeed(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            expiresOn,
            coverPicture,
            companyName,
            profilePicture,
            locationList,
            interestTypeList,
            ageList,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            actionType,
            url,
            groupIdAction,
            callingNumber,
            formId,
            linkUrlPosition,
            groupIsPublic,
            studentJoinId,
            fees,
            description,
            bio,
            "",
            //menteeSupport,
            "",
            //advisorSupportOffered,
            "",
            //projectArea,
            userImageModelParam,
            qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            category,
            name,
            "",
            //supportedOffer,
            opportunityCretedUserName,
            opportunityCretedUserImage,
            otherSubjectList,
            otherCategoryList,
            otherCareerList,
            timeZone,
            declineReason,
            partnerStatus,
            schoolCode);
      }

      if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
        print("difference day++++" + differenceDay.toString());
        userPostList.add(new UserPostModal(
            _id,
            feedId,
            postedBy,
            isLiked,
            dateTime,
            visibility,
            firstName,
            lastName,
            email,
            profilePicture,
            title,
            tagline,
            shareText,
            shareTime,
            postOwner,
            postOwnerFirstName,
            postOwnerLastName,
            postOwnerTitle,
            postOwnerProfilePicture,
            isLike,
            isCommented,
            postData,
            commentList,
            likesList,
            tagList,
            groupList,
            scopeList,
            false,
            TextEditingController(text: ""),
            lastActivityTime,
            lastActivityType,
            false,
            false,
            false,
            false,
            isReported,
            isOpportunity,
            postOwnerRoleId,
            roleId,
            postOwnerDeleted,
            opportunityModelForFeed,
            WebLinksModel("", "", "", ""),
            postedGroupName,
            postedGroupId,
            badge,
            gamificationPoints,
            likesCount,
            badgeImage,
            postOwnerBadge,
            postOwnerGamificationPoints,
            postOwnerBadgeImage,
            dateTime2,
            feedStatus,
            schoolCode,
            reasonList: reasonList,
            reasonText: reasonText));
      }
    } catch (e) {
      print("HomeError+++++" + e.toString());
      e.toString();
    }

    return userPostList;
  }

  static CompanyProfileModel parseCompanyInfoDataForLogin(data) {
    print('inside parseCompanyInfoData()');
    try {
      if (data != null) {
        String companyId = data["companyId"].toString();
        String userId = data["userId"].toString();
        String roleId = data["roleId"].toString();
        String name = data["name"].toString();
        String address = data["address"].toString();
        String zipCode = data["zipCode"].toString();
        String gender = data["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String phone = data["phone"].toString();
        String about = data["about"].toString();
        String profilePicture = data["profilePicture"].toString();
        String coverPicture = data["coverPicture"].toString();
        String email = data["email"].toString();
        String firstName = data["firstName"].toString();
        String dob = data["dob"].toString();
        String lastName = data["lastName"].toString();
        String mobileNo = data["mobileNo"].toString();
        String url = data["url"].toString();
        String city = data["city"].toString();
        String state = data["state"].toString();
        String country = data["country"].toString();
        String countryCode = data["countryCode"].toString();
        String partnerStatus = data[0]["partnerStatus"].toString();
        String declineReason = data[0]["declineReason"].toString();
        bool isActive = data[0]["isActive"];
        List<OfferModel> offers = List();

        List<Assest> assestList = List<Assest>();
        List<CategoryModel> categoryModel = List<CategoryModel>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = data["asset"];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        if (data["offer"] != null) {
          for (int i = 0; i < data["offer"].length; i++) {
            String offerId = data["offer"][i]['offerId'].toString();
            String name = data["offer"][i]['name'].toString();

            offers.add(new OfferModel(offerId: int.parse(offerId), name: name));
          }
        }

        if (data["businessCategory"] != null) {
          for (int i = 0; i < data["businessCategory"].length; i++) {
            print(
                'inside parsing name $i::: ${data["businessCategory"][i]['businessCategoryId'].toString()}');
            print(
                'inside parsing name $i::: ${data["businessCategory"][i]['name'].toString()}');
            print(
                'inside parsing name $i::: ${data["businessCategory"][i]['isOther'].toString()}');
            String businessCategoryId =
                data["businessCategory"][i]['businessCategoryId'].toString();
            String name = data["businessCategory"][i]['name'].toString();
            String isOtherS = data["businessCategory"][i]['isOther'].toString();
            bool isOther = false;
            if (isOtherS == 'true') isOther = true;
            print(
                'inside parsing name $i::: ${data["businessCategory"][i]['name'].toString()}');
            categoryModel.add(new CategoryModel(
                businessCategoryId: int.parse(businessCategoryId),
                name: name,
                isOther: isOther));
            print('inside parsing name------------------ $i::: ${isOther}');
          }
        }

        return CompanyProfileModel(
            firstName,
            lastName,
            mobileNo,
            companyId,
            userId,
            roleId,
            name,
            address,
            phone,
            url,
            about,
            profilePicture,
            coverPicture,
            offers,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            email,
            dob,
            zipCode,
            gender,
            city,
            state,
            country,
            countryCode,
            categoryModel,
            isActive,
            partnerStatus,
            declineReason);
      }
    } catch (e) {
      e.toString();
    }
  }

  static OpportunityModelForFeed parseOpportunityDetailData(
      map, userIdPref, userRoleID) {
    OpportunityModelForFeed opportunityModelForFeed;
    for (int i = 0; i < map.length; i++) {
      try {
        String dateTime = map[i]['dateTime'].toString();
        String opportunityCretedUserName = map[i]['firstName'].toString() +
            " " +
            map[i]['lastName'].toString().replaceAll("null", "");

        String opportunityCretedUserImage = map[i]['profilePicture'].toString();
        String firstName = map[i]['firstName'].toString();
        bool isOpportunity = map[i]['isOpportunity'];
        bool isLike = map[i]['isLiked'];
        int likesCount = map[i]['likesCount'];
        bool isCommented = false;
        DateTime currentDate = DateTime.now();

        var imageMap = map[i]['post']['images'];
        var assetMap = map[i]['post']['assets'];
        String text = map[i]['post']['text'];
        String media = map[i]['post']['media'];
        List<String> imageList = List<String>();
        if (imageMap != null) {
          for (int i = 0; i < imageMap.length; i++) {
            String image = imageMap[i];
// image = getMediumImage(image);
            if (image != "") imageList.add(image);
          }
        }
        List<AssetIV> assetList = List<AssetIV>();
        if (assetMap != null) {
          for (int i = 0; i < assetMap.length; i++) {
            String image = assetMap[i]["url"];
            String type = assetMap[i]["type"];
            // image = getMediumImage(image);
            if (image != "") assetList.add(AssetIV(file: image, type: type));
          }
        }

        String _metaUrl,
            _metaSource,
            _metaHeight,
            _metaWidth,
            _metaTitle,
            _metaDescription,
            _metaImage;

        try {
          _metaUrl = map[i]['post']['metaData']['url'];
          _metaSource = map[i]['post']['metaData']['source'];
          _metaHeight = map[i]['post']['metaData']['height'];
          _metaWidth = map[i]['post']['metaData']['width'];
          _metaTitle = map[i]['post']['metaData']['title'];
          _metaDescription = map[i]['post']['metaData']['description'];
          _metaImage = map[i]['post']['metaData']['image'];
        } catch (e) {
          _metaUrl = "";
          _metaSource = "";
          _metaHeight = "";
          _metaWidth = "";
          _metaTitle = "";
          _metaDescription = "";
          _metaImage = "";
        }

        print("* Meta Changes * " + _metaTitle);
        PostData postData = PostData(
            imageList,
            assetList,
            text,
            media,
            _metaUrl,
            _metaSource,
            _metaHeight,
            _metaWidth,
            _metaTitle,
            _metaDescription,
            _metaImage);
        print("sss commetns 4");
        List<CommentData> commentList = List();
        var commentMap = map[i]['comments'];
        if (commentMap != null) {
          for (int j = (commentMap.length - 1); j >= 0; j--) {
            String commentId = commentMap[j]['commentId'].toString();
            String comment = commentMap[j]['comment'].toString();
            String commentedBy = commentMap[j]['commentedBy'].toString();
            String dateTime = commentMap[j]['dateTime'].toString();
            String profilePicture = commentMap[j]['profilePicture'].toString();
            String name = commentMap[j]['name'].toString();
            String title = commentMap[j]['title'].toString();
            String roleId = commentMap[j]['commentRoleId'].toString();
            String userId = commentMap[j]['userId'].toString();
            var likesMap = commentMap[j]['likes'];

            String badgeImage = commentMap[j]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = commentMap[j]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification =
                commentMap[j]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            DateTime currentDate = DateTime.now();
            if (dateTime != "null") {
              int d = int.tryParse(dateTime);
              DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

              dateTime = getTimeValue(date, currentDate);

/*final differenceDay = currentDate.difference(date).inDays;
final differenceHours = currentDate.difference(date).inHours;
final differenceMinutes = currentDate.difference(date).inMinutes;
final differenceSeconds = currentDate.difference(date).inSeconds;

if (differenceDay != 0) {
if (differenceDay == 1) {
dateTime = "$differenceDay Day ";
} else {
dateTime = "$differenceDay Days ";
}
} else if (differenceHours != 0) {
if (differenceHours == 1) {
dateTime = "$differenceHours Hour ";
} else {
dateTime = "$differenceHours Hours ";
}
} else if (differenceMinutes != 0) {
if (differenceMinutes == 1) {
dateTime = "$differenceMinutes Minute ";
} else {
dateTime = "$differenceMinutes Minutes ";
}
} else {
dateTime = "few seconds ";
}*/
            }
// profilePicture = getSmallImage(profilePicture);

            List<Likes> likesList = List();
            bool isCommentLike = false;
            for (int k = 0; k < likesMap.length; k++) {
              String userId = likesMap[k]['userId'].toString();
              String name = likesMap[k]['name'].toString();

              String status = likesMap[k]['status'].toString();
              String roleId = likesMap[k]['roleId'].toString();
              String statusValue = likesMap[k]['statusValue'].toString();

              String profilePicture = likesMap[k]['profilePicture'].toString();
// profilePicture = getSmallImage(profilePicture);
              String title = likesMap[k]['title'].toString();

              String badgeImage = likesMap[k]['badgeImage'].toString();
              if (badgeImage == "null" || badgeImage == "") {
                badgeImage = "";
              }
              String badge = likesMap[k]['badge'].toString();
              if (badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  likesMap[k]['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == "null" || gamification == "") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }
              if (gamificationPoints == null) {
                gamificationPoints = 0;
              }

              likesList.add(new Likes(
                  userId,
                  name,
                  profilePicture,
                  title,
                  status,
                  statusValue,
                  roleId,
                  badge,
                  gamificationPoints,
                  badgeImage));
              if (userId == userIdPref && roleId == userRoleID) {
                isCommentLike = true;
              }
            }
            commentList.add(new CommentData(
                commentId,
                comment,
                commentedBy,
                dateTime,
                profilePicture,
                name,
                title,
                userId,
                likesList,
                isCommentLike,
                roleId,
                badge,
                gamificationPoints,
                badgeImage,
                true));
            if (commentedBy == userIdPref && roleId == userRoleID) {
              isCommented = true;
            }
          }
        }

        List<Likes> likesList = List();
        var likesMap = map[i]['likes'];
        if (likesMap != null) {
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();
            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['roleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();
            String profilePicture = likesMap[k]['profilePicture'].toString();
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            // if (userId == userIdPref && roleId == userRoleID) {
            //   isLike = true;
            // }
          }
        }
        List<Tags> tagList = List();
        try {
          var tagMap = map[i]['tags'];

          for (int k = 0; k < tagMap.length; k++) {
            String userId = tagMap[k]['userId'].toString();
            String name = tagMap[k]['name'].toString();
            String profilePicture = tagMap[k]['profilePicture'].toString();
            String title = tagMap[k]['title'].toString();
            String roleId = tagMap[k]['roleId'].toString();

            String badgeImage = tagMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = tagMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = tagMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            tagList.add(new Tags(userId, name, profilePicture, title, roleId,
                badge, gamificationPoints, badgeImage));
          }
        } catch (e) {}

        var scopeMap = map[i]['scope'];

        List<String> scopeList = List<String>();
        if (scopeMap != null) {
          for (int k = 0; k < scopeMap.length; k++) {
            String id = scopeMap[k].toString();
            if (id != "") scopeList.add(id);
          }
        }

//OpportunityModelForFeed opportunityModelForFeed;
        int differenceDay = 0;
        String partnerStatus = map[i]["partnerStatus"].toString();
        print("isOpportunity+++++" + isOpportunity.toString());
        if (isOpportunity) {
          var postOpportunity = map[i]["postOpportunity"];
          String opportunityId = postOpportunity[0]["opportunityId"].toString();
          String userId = postOpportunity[0]["userId"].toString();
          String roleId = postOpportunity[0]["roleId"].toString();
          String jobTitle = postOpportunity[0]["jobTitle"].toString();
          String timeZone = postOpportunity[0]["timeZone"].toString();
          String jobType = postOpportunity[0]["jobType"].toString();
          String schoolCode = postOpportunity[0]['schoolCode'].toString();
          if (schoolCode == "null" || schoolCode == "") {
            schoolCode = "";
          }
          String jobLocation = postOpportunity[0]["jobLocation"].toString();
          String project = postOpportunity[0]["project"].toString();
          String duration = postOpportunity[0]["duration"].toString();
          String status = postOpportunity[0]["status"].toString();
          String fromDate = postOpportunity[0]["fromDate"].toString();
          String toDate = postOpportunity[0]["toDate"].toString();

          String groupId = postOpportunity[0]["groupId"].toString();
          String targetAudience =
              postOpportunity[0]["targetAudience"].toString();
          String title = postOpportunity[0]["title"].toString();
          String gender = postOpportunity[0]["gender"].toString();
          if (gender == "Non-binary" || gender == "NonBinary") {
            gender = "Non-Binary";
          }
          String companyId = postOpportunity[0]["companyId"].toString();
          String offerId = postOpportunity[0]["offerId"].toString();
          String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
          String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
          String expiresOn = postOpportunity[0]["expiresOn"].toString();
          String coverPicture = postOpportunity[0]["coverPicture"].toString();
          String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
          String companyName = postOpportunity[0]["companyName"].toString();
          String profilePicture =
              postOpportunity[0]["profilePicture"].toString();
          String category = postOpportunity[0]["oppCategory"].toString();
          //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
          String name = postOpportunity[0]["name"].toString();
          String url, groupIdAction, callingNumber, formId, linkUrlPosition;
          bool groupIsPublic = true;
          String actionType =
              postOpportunity[0]['callToAction'][0]['id'].toString();
          if (actionType == Constant.LINK_URL) {
            url = postOpportunity[0]['callToAction'][0]['url'].toString();
            linkUrlPosition =
                postOpportunity[0]['callToAction'][0]['position'].toString();
            print("action+++" + url);
          } else if (actionType == Constant.JOIN_GROUP) {
            groupIdAction =
                postOpportunity[0]['callToAction'][0]['groupId'].toString();
            groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
            print("groupIsPublic+++++" + groupIsPublic.toString());
            if (groupIsPublic == null) {
              groupIsPublic = true;
            }
            print("action+++jpoinGroup+++" + groupIdAction);
          } else if (actionType == Constant.CALL_NOW) {
            callingNumber =
                postOpportunity[0]['callToAction'][0]['number'].toString();
            print("action+++" + callingNumber);
          } else if (actionType == Constant.INQUIRE_NOW) {
            formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
            print("action+++" + formId);
          }

          print("shubh+++" + "action" + actionType);

          List<Address> locationList = List<Address>();
          var locationMap = postOpportunity[0]['location'];
          if (locationMap != null) {
            for (int i = 0; i < locationMap.length; i++) {
              String zipcode = locationMap[i]['zipcode'].toString();
              String city = locationMap[i]['city'].toString();
              String country = locationMap[i]['country'].toString();
              String state = locationMap[i]['state'].toString();
              String name = locationMap[i]['name'].toString();
              String target = locationMap[i]['target'].toString();
              locationList.add(
                  Address(name, "", city, state, country, zipcode, target));
            }
          }

          List<AgeModel> ageList = List<AgeModel>();
          var ageMao = postOpportunity[0]['age'];
          if (ageMao != null) {
            for (int k = 0; k < ageMao.length; k++) {
              String to = ageMao[k]['to'].toString();
              String from = ageMao[k]['from'].toString();
// file= getMediumImage(file);

              ageList.add(new AgeModel(to, from));
            }
          }
          List<IntrestModel> interestTypeList = List<IntrestModel>();
          try {
            var interestTypeModel = postOpportunity[0]['interestType'];
            if (interestTypeModel != null) {
              for (int k = 0; k < interestTypeModel.length; k++) {
                String id = interestTypeModel[k]['id'].toString();
                String name = interestTypeModel[k]['name'].toString();
// file= getMediumImage(file);

                interestTypeList.add(new IntrestModel(id, name));
              }
            }
          } catch (e) {}

          List<Assest> assestList = List<Assest>();
          List<Assest> assestVideoAndImage = List<Assest>();
          List<Assest> videoList = List<Assest>();
          List<Assest> docList = List<Assest>();
          List<Assest> googleLinkList = List<Assest>();
          List<Assest> mediaList = List<Assest>();

          var asetMap = postOpportunity[0]['asset'];
          if (asetMap != null) {
            for (int k = 0; k < asetMap.length; k++) {
              String type = asetMap[k]['type'].toString();
              String tag = asetMap[k]['tag'].toString();
              String file = asetMap[k]['file'].toString();
              String label = asetMap[k]['label'].toString();
// file= getMediumImage(file);

              assestList.add(new Assest(type, tag, file, label, false));
              print("assestListtype::::" + type);
              if (type == "image") {
                mediaList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "video") {
                videoList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "doc") {
                docList.add(new Assest(type, tag, file, label, false));
              } else if (type == "google") {
                googleLinkList.add(new Assest(type, tag, file, label, false));
              }
            }
          }

          if (expiresOn != "null") {
            int d = int.tryParse(expiresOn);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            differenceDay = currentDate.difference(date).inDays;
            print("Difference between++++" + differenceDay.toString());
          }

          List<UserImageModelParam> userImageModelParam =
              List<UserImageModelParam>();
          var userImageData = postOpportunity[0]['userImage']; //
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }

          List<String> otherCategoryList = List<String>();
          var otherCategoryMap = postOpportunity[0]['otherCategory'];
          if (otherCategoryMap != null) {
            for (int i = 0; i < otherCategoryMap.length; i++) {
              String name = otherCategoryMap[i]['name'].toString();

              otherCategoryList.add(name);
            }
          }

          List<String> otherCareerList = List<String>();
          var otherCareerMap = postOpportunity[0]['otherCareer'];
          if (otherCareerMap != null) {
            for (int i = 0; i < otherCareerMap.length; i++) {
              String name = otherCareerMap[i]['name'].toString();

              otherCareerList.add(name);
            }
          }
          List<String> otherSubjectList = List<String>();
          var otherSubjectMap = postOpportunity[0]['otherSubject'];
          if (otherSubjectMap != null) {
            for (int i = 0; i < otherSubjectMap.length; i++) {
              String name = otherSubjectMap[i]['name'].toString();

              otherSubjectList.add(name);
            }
          }

          //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
          String fees = postOpportunity[0]["fees"].toString();
          String declineReason = postOpportunity[0]["declineReason"].toString();
          String description = postOpportunity[0]["description"].toString();
          String bio = postOpportunity[0]["bio"].toString();
          //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
          //String projectArea = postOpportunity[0]["projectArea"].toString();
          String qualification = postOpportunity[0]["qualification"].toString();

          List<ScheduleModelParam> scheduleModelParam =
              List<ScheduleModelParam>();
          var sceduleData = postOpportunity[0]['schedule']; //
          try {
            if (sceduleData != null) {
              for (int k = 0; k < sceduleData.length; k++) {
                String day = sceduleData[k]['day'].toString();
                var hours = sceduleData[k]['hours'];
                //  file= getMediumImage(file);
                //HoursData hoursData;
                List<HoursData> hoursList = List();
                for (var item in hours) {
                  hoursList.add(new HoursData(
                      timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
                }
                scheduleModelParam
                    .add(new ScheduleModelParam(day: day, hours: hoursList));
              }
            }
          } catch (e) {}

          List<MainCategory> designationModelParam = List<MainCategory>();
          var designationData = postOpportunity[0]['category']; //
          try {
            if (designationData != null) {
              for (int k = 0; k < designationData.length; k++) {
                String name = designationData[k]['name'].toString();
                String isOtherS = designationData[k]['isOther'].toString();
                String categoryId = designationData[k]['categoryId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                designationModelParam.add(new MainCategory(
                    name: name, categoryId: int.parse(categoryId)));
              }
            }
          } catch (e) {}

          List<SubCategory> subjectModelParam = List<SubCategory>();
          var subjectData = postOpportunity[0]['subjects']; //
          try {
            if (subjectData != null) {
              for (int k = 0; k < subjectData.length; k++) {
                String name = subjectData[k]['name'].toString();
                String isOtherS = subjectData[k]['isOther'].toString();
                String subjectId = subjectData[k]['subjectId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                subjectModelParam.add(new SubCategory(
                    name: name, subjectId: int.parse(subjectId)));
              }
            }
          } catch (e) {}

          List<QualificationModelParam> qualificationModelParam =
              List<QualificationModelParam>();
          var qualificationData = postOpportunity[0]['qualification']; //
          try {
            if (qualificationData != null) {
              for (int k = 0; k < qualificationData.length; k++) {
                String name = qualificationData[k]['name'].toString();
                String isOtherS = qualificationData[k]['isOther'].toString();
                String qualificationId =
                    qualificationData[k]['qualificationId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                qualificationModelParam.add(new QualificationModelParam(
                    name: name,
                    isOther: isOther,
                    qualificationId: int.parse(qualificationId)));
              }
            }
          } catch (e) {}
          opportunityModelForFeed = OpportunityModelForFeed(
              opportunityId,
              userId,
              roleId,
              jobTitle,
              jobType,
              jobLocation,
              project,
              duration,
              status,
              fromDate,
              toDate,
              groupId,
              targetAudience,
              title,
              gender,
              companyId,
              offerId,
              serviceTitle,
              serviceDesc,
              expiresOn,
              coverPicture,
              companyName,
              profilePicture,
              locationList,
              interestTypeList,
              ageList,
              assestList,
              assestVideoAndImage,
              videoList,
              docList,
              mediaList,
              googleLinkList,
              actionType,
              url,
              groupIdAction,
              callingNumber,
              formId,
              linkUrlPosition,
              groupIsPublic,
              studentJoinId,
              fees,
              description,
              bio,
              "",
              //menteeSupport,
              "",
              //advisorSupportOffered,
              "",
              //projectArea,
              userImageModelParam,
              qualification,
              qualificationModelParam,
              designationModelParam,
              subjectModelParam,
              scheduleModelParam,
              category,
              name,
              "",
              //supportedOffer,
              opportunityCretedUserName,
              opportunityCretedUserImage,
              otherSubjectList,
              otherCategoryList,
              otherCareerList,
              timeZone,
              declineReason,
              partnerStatus,
              schoolCode);
        }
      } catch (e) {
        e.toString();
      }
    }
    print('opportunity inside parsing:::::: $opportunityModelForFeed');
    return opportunityModelForFeed;
  }

  static CompanyProfileModel parseCompanyInfoData(data) {
    print('inside parseCompanyInfoData()');
    try {
      if (data != null) {
        print('data[0]["businessCategory"]:: ${data[0]["businessCategory"]}');

        String companyId = data[0]["companyId"].toString();
        String userId = data[0]["userId"].toString();
        String roleId = data[0]["roleId"].toString();
        String name = data[0]["name"].toString();
        String address = data[0]["address"].toString();
        String zipCode = data[0]["zipCode"].toString();
        String gender = data[0]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String phone = data[0]["phone"].toString();
        String about = data[0]["about"].toString();
        String profilePicture = data[0]["profilePicture"].toString();
        String coverPicture = data[0]["coverPicture"].toString();
        String email = data[0]["email"].toString();
        String firstName = data[0]["firstName"].toString();
        String dob = data[0]["dob"].toString();
        String lastName = data[0]["lastName"].toString();
        String mobileNo = data[0]["mobileNo"].toString();
        String url = data[0]["url"].toString();
        String city = data[0]["city"].toString();
        String state = data[0]["state"].toString();
        String country = data[0]["country"].toString();
        String countryCode = data[0]["countryCode"].toString();
        String partnerStatus = data[0]["partnerStatus"].toString();
        String declineReason = data[0]["declineReason"].toString();
        bool isActive = data[0]["isActive"];
        List<OfferModel> offers = List();

        List<Assest> assestList = List<Assest>();
        List<CategoryModel> categoryModel = List<CategoryModel>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();
        try {
          var asetMap = data[0]["asset"];
          if (asetMap != null) {
            for (int k = 0; k < asetMap.length; k++) {
              String type = asetMap[k]['type'].toString();
              String tag = asetMap[k]['tag'].toString();
              String file = asetMap[k]['file'].toString();
              String label = asetMap[k]['label'].toString();
// file= getMediumImage(file);

              assestList.add(new Assest(type, tag, file, label, false));

              if (type == "image") {
                mediaList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "video") {
                videoList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "doc") {
                docList.add(new Assest(type, tag, file, label, false));
              } else if (type == "google") {
                googleLinkList.add(new Assest(type, tag, file, label, false));
              }
            }
          }
        } catch (e) {
          print("erroror11++++" + e.toString());
        }
        try {
          if (data[0]["offer"] != null) {
            for (int i = 0; i < data[0]["offer"].length; i++) {
              String offerId = data[0]["offer"][i]['offerId'].toString();
              String name = data[0]["offer"][i]['name'].toString();

              offers
                  .add(new OfferModel(offerId: int.parse(offerId), name: name));
            }
          }
        } catch (e) {
          print("erroror22++++" + e.toString());
        }
        try {
          if (data[0]["businessCategory"] != null) {
            for (int i = 0; i < data[0]["businessCategory"].length; i++) {
              print(
                  'inside parsing name $i::: ${data[0]["businessCategory"][i]['businessCategoryId'].toString()}');
              print(
                  'inside parsing name $i::: ${data[0]["businessCategory"][i]['name'].toString()}');
              print(
                  'inside parsing name $i::: ${data[0]["businessCategory"][i]['isOther'].toString()}');
              String businessCategoryId = data[0]["businessCategory"][i]
                      ['businessCategoryId']
                  .toString();
              String name = data[0]["businessCategory"][i]['name'].toString();
              String isOtherS =
                  data[0]["businessCategory"][i]['isOther'].toString();
              bool isOther = false;
              if (isOtherS == 'true') isOther = true;
              print(
                  'inside parsing name $i::: ${data[0]["businessCategory"][i]['name'].toString()}');
              categoryModel.add(new CategoryModel(
                  businessCategoryId: businessCategoryId == "null"
                      ? 0
                      : int.parse(businessCategoryId),
                  name: name,
                  isOther: isOther));
              print('inside parsing name------------------ $i::: ${isOther}');
            }
          }
        } catch (e) {}

        return CompanyProfileModel(
            firstName,
            lastName,
            mobileNo,
            companyId,
            userId,
            roleId,
            name,
            address,
            phone,
            url,
            about,
            profilePicture,
            coverPicture,
            offers,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            email,
            dob,
            zipCode,
            gender,
            city,
            state,
            country,
            countryCode,
            categoryModel,
            isActive,
            partnerStatus,
            declineReason);
      }
    } catch (e) {
      print("erroror++++" + e.toString());
      e.toString();
    }
  }

  static ProfileInfoModal parseMapUserProfile(data) {
    //data=response.data['result']
    try {
      ProfileInfoModal profileInfoModal;
      String groupId = "";
      String groupName = "";
      String groupImage = "";
      String userId = data[ProfileInfoResponse.USER_ID].toString();
      try {
        groupId = data['groupId'].toString();
        groupName = data['groupName'].toString();
        groupImage = data['groupImage'].toString();
      } catch (e) {}
      String firstName = data[ProfileInfoResponse.FIRSTNAME].toString();
      String lastName = data[ProfileInfoResponse.LASTNAME].toString();
      String email = data[ProfileInfoResponse.EMAIL].toString();
      String mobileNo = data[ProfileInfoResponse.MOBILE].toString();
      String profilePicture =
          data[ProfileInfoResponse.PROFILE_PICTURE].toString();
      //   profilePicture= getMediumImage(profilePicture);
      String roleId = data[ProfileInfoResponse.ROLE_ID].toString();
      String isActive = data[ProfileInfoResponse.IS_ACTIVE].toString();
      String isHide = data[ProfileInfoResponse.IS_HIDE].toString();
      bool isExistingUser = data['isExistingUser'];
      bool isCollegeAdded = data['isCollegeAdded'];
      bool isPhoneVerified = data['isPhoneVerified'];
      if (isPhoneVerified == null) {
        isPhoneVerified = false;
      }

      bool isEmailVerified = data['isEmailVerified'];
      if (isEmailVerified == null) {
        isEmailVerified = false;
      }
      bool profileCreatedByParent = data['profileCreatedByParent'];
      if (profileCreatedByParent == null) {
        profileCreatedByParent = false;
      }

      if (isExistingUser == null) {
        isExistingUser = false;
      }
      if (isCollegeAdded == null) {
        isCollegeAdded = false;
      }
      String publicUrl = data["publicUrl"].toString().trim();
      bool isPublicUrlActive = data["isPublicUrlActive"];
      bool isPublicProfileGlobalyActive = data["isPublicProfileGlobalyActive"];
      print("+++++++++++++++1");
      if (isActive == null || isActive == "null") {
        isActive = "false";
      }

      if (isPublicProfileGlobalyActive == null ||
          isPublicProfileGlobalyActive == "null") {
        isPublicProfileGlobalyActive = false;
      }
      if (isPublicUrlActive == null || isPublicUrlActive == "null") {
        isPublicUrlActive = false;
      }
      if (isHide == null || isHide == "null") {
        isHide = "false";
      }

      bool referralPopup = data[ProfileInfoResponse.IS_REFRREL];
      if (referralPopup == null || referralPopup == "null") {
        referralPopup = false;
      }

      print("+++++++++++++++2");

      bool userLoginFirstTime = data['userLoginFirstTime'];
      if (userLoginFirstTime == null) {
        userLoginFirstTime = false;
      }

      String requireParentApproval =
          data[ProfileInfoResponse.REQUIRE_PARENT_APPROVEL].toString();
      String ccToParents = data[ProfileInfoResponse.CC_TO_PARENTS].toString();
      String creationTime = data['creationTime'].toString();
      String countryCode = data['countryCode'].toString();
      String lastAccess = data[ProfileInfoResponse.LAST_ACCESS].toString();
      String stage = data['stage'].toString();
      print("+++++++++++++++3");
      String isPasswordChanged =
          data[ProfileInfoResponse.IS_PASSWORD_CHANGED].toString();
      String organizationId =
          data[ProfileInfoResponse.ORGANIZATION_ID].toString();
      String gender = data[ProfileInfoResponse.GENDER].toString();
      if (gender == "Non-binary" || gender == "NonBinary") {
        gender = "Non-Binary";
      }
      String dob = data[ProfileInfoResponse.DOB].toString();

      String schoolCode = data['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      print("+++++++++++++++4");
      String zipCode = data['zipCode'].toString();
      String genderAtBirth =
          data[ProfileInfoResponse.GENDER_AT_BIRTH].toString();
      if (genderAtBirth == "Non-binary" || genderAtBirth == "NonBinary") {
        genderAtBirth = "Non-Binary";
      }
      String usCitizenOrPR =
          data[ProfileInfoResponse.US_CITIZEN_OR_PR].toString();

      var addressMap = data['address'];
      print("+++++++++++++++41");
      Address addressModal = Address("", "", "", "", "", "", "");
      try {
        if (addressMap != null) {
          String street1 = addressMap['street1'].toString();
          String street2 = addressMap['street2'].toString();
          String city = addressMap['city'].toString();
          String state = addressMap['state'].toString();
          String country = addressMap['country'].toString();
          String zip = addressMap['zip'].toString();
          String target = addressMap['target'].toString();
          addressModal =
              Address(street1, street2, city, state, country, zip, target);
        } else {
          String country = data['country'].toString();
          String state = data['state'].toString();
          String city = data['city'].toString();
          String target = data['target'].toString();
          addressModal = Address("", "", city, state, country, zipCode, target);
        }
      } catch (e) {}
      var companyMap = data['company'];

      Company company = Company('', '', false);
      if (companyMap != null) {
        company = Company(companyMap['name'].toString(),
            companyMap['partnerStatus'].toString(), companyMap['isActive']);
      }
      print("+++++++++++++++5");
      String summary = data[ProfileInfoResponse.SUMMARY].toString();
      String secondaryEmail = data['secondaryEmail'].toString();
      String coverImage = data[ProfileInfoResponse.COVER_IMAGE].toString();
      //   coverImage= getMediumImage(coverImage);
      String tagline = data[ProfileInfoResponse.TAGLINE].toString();
      String title = data[ProfileInfoResponse.TITLE].toString();
      String tempPassword = data[ProfileInfoResponse.TEMP_PASSWORD].toString();
      String isArchived = data[ProfileInfoResponse.IS_ARCHIVED].toString();
      print("+++++++++++++++6");
      List<ParentModal> parentList = List();
      try {
        for (int i = 0; i < data[ProfileInfoResponse.PARENTS].length; i++) {
          print("map" + data[ProfileInfoResponse.PARENTS][i].toString());
          String email = data[ProfileInfoResponse.PARENTS][i]
                  [ProfileInfoResponse.EMAIL]
              .toString();
          String userId = data[ProfileInfoResponse.PARENTS][i]
                  [ProfileInfoResponse.USER_ID]
              .toString();
          String firstName =
              data[ProfileInfoResponse.PARENTS][i]['firstName'].toString();
          String lastName =
              data[ProfileInfoResponse.PARENTS][i]['lastName'].toString();
          String zipCode =
              data[ProfileInfoResponse.PARENTS][i]['zipCode'].toString();
          String gender =
              data[ProfileInfoResponse.PARENTS][i]['gender'].toString();
          if (gender == "Non-binary" || gender == "NonBinary") {
            gender = "Non-Binary";
          }
          String dob = data[ProfileInfoResponse.PARENTS][i]['dob'].toString();
          String country =
              data[ProfileInfoResponse.PARENTS][i]['country'].toString();
          String state =
              data[ProfileInfoResponse.PARENTS][i]['state'].toString();
          String city = data[ProfileInfoResponse.PARENTS][i]['city'].toString();
          parentList.add(new ParentModal(email, userId, firstName, lastName,
              zipCode, gender, dob, country, state, city));
        }
      } catch (e) {
        print("Error+++parentList+++" + e.toString());
      }
      print("+++++++++++++++7");
      List<SocialLinkData> socialLinkList = List();
      try {
        var socalLinkMap = data['socialLinks'];
        if (socalLinkMap != null && socalLinkMap.length > 0) {
          for (int i = 0; i < socalLinkMap.length; i++) {
            String image = socalLinkMap[i]['image'].toString();
            String socialName = socalLinkMap[i]['socialName'].toString();
            String socialUrl = socalLinkMap[i]['socialUrl'].toString();
            int socialId = socalLinkMap[i]['socialId'];

            socialLinkList.add(new SocialLinkData(
                image: image,
                socialName: socialName,
                socialUrl: socialUrl,
                socialId: socialId));
          }
        }
      } catch (e) {
        print("Error+++socialLinkList+++" + e.toString());
      }
      print("+++++++++++++++8");
      String referCode = data['referCode'].toString();
      String badgeImage = data['badgeImage'].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = data['badge'].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification = data['gamificationPoints'].toString();
      int gamificationPoints;
      try {
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }
      } catch (e) {
        print('err+++gamificationPoints++++++++$e');
      }

      /*  if (profilePicture != "") {
      strNetworkImage = profilePicture;
    }*/
      print("+++++++++++++++9");
      var introVideo = data['introVideo'] != null
          ? IntroVideo.fromJson(data['introVideo'])
          : null;
      var resume =
          data['resume'] != null && data['resume'].toString().isNotEmpty
              ? ResumeModel.fromJson(data['resume'])
              : null;
      profileInfoModal = ProfileInfoModal(
          userId,
          firstName,
          lastName,
          email,
          mobileNo,
          profilePicture,
          roleId,
          isActive,
          requireParentApproval,
          ccToParents,
          lastAccess,
          isPasswordChanged,
          organizationId,
          gender,
          dob,
          genderAtBirth,
          usCitizenOrPR,
          addressModal,
          summary,
          coverImage,
          tagline,
          title,
          tempPassword,
          isArchived,
          parentList,
          false,
          groupId,
          groupName,
          groupImage,
          "",
          "",
          zipCode,
          isHide,
          referralPopup,
          userLoginFirstTime,
          stage,
          creationTime,
          badge,
          gamificationPoints,
          badgeImage,
          referCode,
          socialLinkList,
          publicUrl,
          isPublicUrlActive,
          isPublicProfileGlobalyActive,
          introVideo,
          company,
          isExistingUser,
          isCollegeAdded,
          resume,
          schoolCode,
          secondaryEmail,
          countryCode,
          isPhoneVerified,
          isEmailVerified,
          profileCreatedByParent: profileCreatedByParent);

      return profileInfoModal;
    } catch (e) {
      print("erorr+++recommendation++++" + e.toString());
    }
  }

  static List<String> parseMedia(map) {
    List<String> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String image = map[k]['image'].toString();

        tagList.add(image);
      }
      return tagList;
    } catch (e) {}
    return tagList;
  }

  static List<LikeDetailModel> parseLikeList(map) {
    List<LikeDetailModel> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        print("sss  like 1 ${map[k]}");
        String _id = map[k]['_id'].toString();
        String likedBy = map[k]['likedBy'].toString();
        String likedByRole = map[k]['likedByRole'].toString();
        String createdAt = map[k]['createdAt'].toString();
        String profilePicture = map[k]['profilePicture'].toString();
        String firstName = map[k]['firstName'].toString();
        String lastName = map[k]['lastName'].toString();
        String statusValue = map[k]['statusValue'].toString();
        String status = map[k]['status'].toString();
        tagList.add(new LikeDetailModel(_id, likedBy, likedByRole, createdAt,
            profilePicture, firstName, lastName, statusValue, status));
      }
      return tagList;
    } catch (e) {}
    return tagList;
  }

  static List<CommentDetailModel> parseCommentList(map) {
    List<CommentDetailModel> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String _id = map[k]['_id'].toString();
        String comment = map[k]['comment'].toString();
        String commentedBy = map[k]['commentedBy'].toString();
        String commentedByRole = map[k]['commentedByRole'].toString();
        String createdAt = map[k]['createdAt'].toString();
        String profilePicture = map[k]['profilePicture'].toString();
        String firstName = map[k]['firstName'].toString();
        String lastName = map[k]['lastName'].toString();
        DateTime currentDate = DateTime.now();
        if (createdAt != "null") {
          int d = int.tryParse(createdAt);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          createdAt = getTimeValue(date, currentDate);
        }

        tagList.add(CommentDetailModel(
          _id,
          comment,
          commentedBy,
          commentedByRole,
          createdAt,
          profilePicture,
          firstName,
          lastName,
          badge: map[k]['badge'].toString(),
          badgeImage: map[k]['badgeImage'].toString(),
        ));
      }
      return tagList;
    } catch (e) {}
    return tagList;
  }

  static List<PeopleYouMayKnow> parsePeopleMayYouKnow(map) {
    List<PeopleYouMayKnow> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String userId = map[k]['userId'].toString();
        String firstName = map[k]['firstName'].toString();
        String lastName = map[k]['lastName'].toString();
        String email = map[k]['email'].toString();
        String tagline = map[k]['tagline'].toString();
        String mobileNo = map[k]['mobileNo'].toString();
        String roleId = map[k]['roleId'].toString();
        String profilePicture = map[k]['profilePicture'].toString();

        print("tagline value" + tagline);
        bool isActive = map[k]['isActive'];

        String badgeImage = map[k]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map[k]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = map[k]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        tagList.add(new PeopleYouMayKnow(
            userId,
            firstName,
            lastName,
            email,
            tagline,
            mobileNo,
            profilePicture,
            isActive,
            roleId,
            badge,
            gamificationPoints,
            badgeImage));
      }
    } catch (e) {}
    return tagList;
  }

  static List<GroupInfoModel> parseGroupList(map, useridPref) {
    List<GroupInfoModel> friendList = List<GroupInfoModel>();

    for (int i = 0; i < map.length; i++) {
      String groupId = "";
      String groupName = "";
      String groupImage = "";
      String type = "",
          creationDate = "",
          createdBy = "",
          isActive = "",
          aboutGroup = "",
          otherInfo = "";
      String userId = map[i][ProfileInfoResponse.USER_ID].toString();
      try {
        groupId = map[i]['groupId'].toString();
        groupName = map[i]['groupName'].toString();
        groupImage = map[i]['groupImage'].toString();
      } catch (e) {
        groupId = "";
        groupName = "";
        groupImage = "";
      }

      type = map[i]['type'].toString();
      creationDate = map[i]['creationDate'].toString();
      createdBy = map[i]['createdBy'].toString();
      isActive = map[i]['isActive'].toString();
      aboutGroup = map[i]['aboutGroup'].toString();
      otherInfo = map[i]['otherInfo'].toString();

      if (userId != useridPref) {
        friendList.add(new GroupInfoModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage));
      }
    }
    return friendList;
  }

  static List<UserPostModal> parseFeedForBoat(map, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();

    try {
      String dateTime2 = "0";
      bool isLike = map['isLiked'];
      int likesCount = map['likesCount'];
      bool isCommented = false;
      String _id = map['_id'].toString();
      String feedId = map['feedId'].toString();
      bool isLiked = map['isLiked'];
      String postedGroupId = map['groupId'].toString();
      String postedGroupName = map['groupName'].toString();
      String postedBy = map['postedBy'].toString();
      String dateTime = map['dateTime'].toString();
      String visibility = map['visibility'].toString();
      String firstName = map['firstName'].toString();
      String lastName = map['lastName'].toString();
      String email = map['email'].toString();
      String roleId = map['roleId'].toString();
      String feedStatus = map['feedStatus'].toString();
      print("FeeddStatus++++++" + feedStatus.toString());
      String profilePicture = map['profilePicture'].toString();
//postOwnerRoleId ,roleId
      // profilePicture = getSmallImage(profilePicture);

      String badgeImage = map['badgeImage'].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = map['badge'].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification = map['gamificationPoints'].toString();
      int gamificationPoints;
      if (gamification == "null" || gamification == "") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      if (gamificationPoints == null) {
        gamificationPoints = 0;
      }

      String postOwnerBadgeImage = map['postOwnerBadgeImage'].toString();
      if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
        postOwnerBadgeImage = "";
      }
      String postOwnerBadge = map['postOwnerBadge'].toString();
      if (postOwnerBadge == "null" || postOwnerBadge == "") {
        postOwnerBadge = "";
      }
      String postOwnerGamification =
          map['postOwnerGamificationPoints'].toString();
      int postOwnerGamificationPoints;
      if (postOwnerGamification == "null" || postOwnerGamification == "") {
        postOwnerGamificationPoints = 0;
      } else {
        postOwnerGamificationPoints = int.parse(postOwnerGamification);
      }
      if (postOwnerGamificationPoints == null) {
        postOwnerGamificationPoints = 0;
      }

      String title = map['title'].toString();
      String tagline = map['tagline'].toString();
      String shareText = map['shareText'].toString();
      String shareTime = map['shareTime'].toString();
      String lastActivityTime = map['lastActivityTime'].toString();
      String lastActivityType = map['lastActivityType'].toString();

      String postOwner = map['postOwner'].toString();
      if (postOwner == '0') {
        postOwner = 'null';
      }
      String postOwnerRoleId = map['postOwnerRoleId'].toString();
      String isReported = map['isReported'].toString();
      bool isOpportunity = map['isOpportunity'];

      String postOwnerFirstName = map['postOwnerFirstName'].toString();
      String postOwnerLastName = map['postOwnerLastName'].toString();
      String schoolCode = map['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      bool postOwnerDeleted = false;
      try {
        postOwnerDeleted =
            map['postOwnerDeleted'] == null ? false : map['postOwnerDeleted'];
      } catch (e) {
        postOwnerDeleted = false;
      }
      String postOwnerTitle = map['postOwnerTitle'].toString();
      String postOwnerProfilePicture =
          map['postOwnerProfilePicture'].toString();
      //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
      DateTime currentDate = DateTime.now();
      if (dateTime != "null") {
        int d = int.tryParse(dateTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        print("firstName++" + firstName.toString());
        print("long++" + d.toString());

        dateTime = getTimeValue(date, currentDate);
        dateTime2 = getMinutes(date, currentDate);

        /*var differenceDay = currentDate.difference(date).inDays;
          final differenceHours = currentDate.difference(date).inHours;
          final differenceMinutes = currentDate.difference(date).inMinutes;
          final differenceSeconds = currentDate.difference(date).inSeconds;
          if (differenceDay != 0) {
            if (differenceDay == 1) {
              dateTime = "$differenceDay Day ";
            } else {
              dateTime = "$differenceDay Days ";
            }
          } else if (differenceHours != 0) {
            if (differenceHours == 1) {
              dateTime = "$differenceHours Hour ";
            } else {
              dateTime = "$differenceHours Hours ";
            }
          } else if (differenceMinutes != 0) {
            if (differenceMinutes == 1) {
              dateTime = "$differenceMinutes Minute ";
            } else {
              dateTime = "$differenceMinutes Minutes ";
            }
          } else {
            dateTime = "few seconds ";
          }*/
      }
      if (shareTime != "null") {
        int d = int.tryParse(shareTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        shareTime = getTimeValue(date, currentDate);

        /*final differenceDay = currentDate.difference(date).inDays;
          final differenceHours = currentDate.difference(date).inHours;
          final differenceMinutes = currentDate.difference(date).inMinutes;
          final differenceSeconds = currentDate.difference(date).inSeconds;
          if (differenceDay != 0) {
            if (differenceDay == 1) {
              shareTime = "$differenceDay Day ";
            } else {
              shareTime = "$differenceDay Days ";
            }
          } else if (differenceHours != 0) {
            if (differenceHours == 1) {
              shareTime = "$differenceHours Hour ";
            } else {
              shareTime = "$differenceHours Hours ";
            }
          } else if (differenceMinutes != 0) {
            if (differenceMinutes == 1) {
              shareTime = "$differenceMinutes Minute ";
            } else {
              shareTime = "$differenceMinutes Minutes ";
            }
          } else {
            shareTime = "few seconds ";
          }*/
      }

      var imageMap = map['post']['images'];
      var assetMap = map['post']['assets'];
      String text = map['post']['text'].toString();
      String media = map['post']['media'].toString();
      List<String> imageList = List<String>();
      if (imageMap != null) {
        for (int i = 0; i < imageMap.length; i++) {
          String image = imageMap[i];
          // image = getMediumImage(image);
          if (image != "") imageList.add(image);
        }
      }
      List<AssetIV> assetList = List<AssetIV>();
      if (assetMap != null) {
        for (int i = 0; i < assetMap.length; i++) {
          String image = assetMap[i]["url"];
          String type = assetMap[i]["type"];
          // image = getMediumImage(image);
          if (image != "") assetList.add(AssetIV(file: image, type: type));
        }
      }

      String _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage;

      try {
        _metaUrl = map['post']['metaData']['url'];
        _metaSource = map['post']['metaData']['source'];
        _metaHeight = map['post']['metaData']['height'];
        _metaWidth = map['post']['metaData']['width'];
        _metaTitle = map['post']['metaData']['title'];
        _metaDescription = map['post']['metaData']['description'];
        _metaImage = map['post']['metaData']['image'];
      } catch (e) {
        _metaUrl = "";
        _metaSource = "";
        _metaHeight = "";
        _metaWidth = "";
        _metaTitle = "";
        _metaDescription = "";
        _metaImage = "";
      }

      PostData postData = PostData(
          imageList,
          assetList,
          text,
          media,
          _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage);
      print("sss commetns 6");
      List<CommentData> commentList = List();
      var commentMap = map['comments'];
      if (commentMap != null) {
        for (int j = (commentMap.length - 1); j >= 0; j--) {
          String commentId = commentMap[j]['_id'].toString();
          String comment = commentMap[j]['comment'].toString();
          String commentedBy = commentMap[j]['commentedBy'].toString();
          String dateTime = commentMap[j]['dateTime'].toString();
          String profilePicture = commentMap[j]['profilePicture'].toString();
          String name = commentMap[j]['name'].toString();
          String title = ""; //commentMap[j]['title'].toString();
          String roleId = ""; //commentMap[j]['commentedByRole'].toString();
          String userId = ""; //commentMap[j]['userId'].toString();
          var likesMap = []; //commentMap[j]['likes'];

          String badgeImage = commentMap[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = commentMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification =
              ""; //commentMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          DateTime currentDate = DateTime.now();
          if (dateTime != "null") {
            int d = int.tryParse(dateTime);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            dateTime = getTimeValue(date, currentDate);

            /*final differenceDay = currentDate.difference(date).inDays;
              final differenceHours = currentDate.difference(date).inHours;
              final differenceMinutes = currentDate.difference(date).inMinutes;
              final differenceSeconds = currentDate.difference(date).inSeconds;

              if (differenceDay != 0) {
                if (differenceDay == 1) {
                  dateTime = "$differenceDay Day ";
                } else {
                  dateTime = "$differenceDay Days ";
                }
              } else if (differenceHours != 0) {
                if (differenceHours == 1) {
                  dateTime = "$differenceHours Hour ";
                } else {
                  dateTime = "$differenceHours Hours ";
                }
              } else if (differenceMinutes != 0) {
                if (differenceMinutes == 1) {
                  dateTime = "$differenceMinutes Minute ";
                } else {
                  dateTime = "$differenceMinutes Minutes ";
                }
              } else {
                dateTime = "few seconds ";
              }*/
          }
          //  profilePicture = getSmallImage(profilePicture);

          List<Likes> likesList = List();
          bool isCommentLike = false;
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();

            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['commentRoleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();

            String profilePicture = likesMap[k]['profilePicture'].toString();
            // profilePicture = getSmallImage(profilePicture);
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            if (userId == userIdPref && roleId == userRoleID) {
              isCommentLike = true;
            }
          }
          commentList.add(new CommentData(
              commentId,
              comment,
              commentedBy,
              dateTime,
              profilePicture,
              name,
              title,
              userId,
              likesList,
              isCommentLike,
              roleId,
              badge,
              gamificationPoints,
              badgeImage,
              true));
          if (commentedBy == userIdPref && roleId == userRoleID) {
            isCommented = true;
          }
        }
      }

      List<Likes> likesList = List();
      var likesMap = map['likes'];
      if (likesMap != null) {
        for (int k = 0; k < likesMap.length; k++) {
          String userId = likesMap[k]['userId'].toString();
          String name = likesMap[k]['name'].toString();
          String status = likesMap[k]['status'].toString();
          String roleId = likesMap[k]['roleId'].toString();
          String statusValue = likesMap[k]['statusValue'].toString();
          String profilePicture = likesMap[k]['profilePicture'].toString();
          String title = likesMap[k]['title'].toString();

          String badgeImage = likesMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = likesMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = likesMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          likesList.add(new Likes(userId, name, profilePicture, title, status,
              statusValue, roleId, badge, gamificationPoints, badgeImage));
          // if (userId == userIdPref && roleId == userRoleID) {
          //   isLike = true;
          // }
        }
      }
      List<Tags> tagList = List();
      try {
        var tagMap = map['tags'];

        for (int k = 0; k < tagMap.length; k++) {
          String userId = tagMap[k]['userId'].toString();
          String name = tagMap[k]['name'].toString();
          String profilePicture = tagMap[k]['profilePicture'].toString();
          String title = tagMap[k]['title'].toString();
          String roleId = tagMap[k]['roleId'].toString();
          String badgeImage = tagMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = tagMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = tagMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          tagList.add(new Tags(userId, name, profilePicture, title, roleId,
              badge, gamificationPoints, badgeImage));
        }
      } catch (e) {}

      //------------------- Apurva added Group list start-------------------

      List<Groups> groupList = List();
      try {
        var groupMap = map['groups'];

        for (int k = 0; k < groupMap.length; k++) {
          String groupId = groupMap[k]['groupId'].toString();
          String groupName = groupMap[k]['groupName'].toString();
          String groupImage = groupMap[k]['groupImage'].toString();

          groupList.add(new Groups(groupId, groupName, groupImage));
        }
      } catch (e) {}
      //------------------- Apurva added Group list end-------------------

      var scopeMap = map['scope'];

      List<ScopeModel> scopeList = List<ScopeModel>();
      if (scopeMap != null) {
        for (int k = 0; k < scopeMap.length; k++) {
          String userId = scopeMap[k]['userId'].toString();
          String roleId = scopeMap[k]['roleId'].toString();
          scopeList.add(ScopeModel(userId, roleId));
        }
      }
      String opportunityCretedUserName = map['firstName'].toString() +
          " " +
          map['lastName'].toString().replaceAll("null", "");

      String opportunityCretedUserImage = map['profilePicture'].toString();
      OpportunityModelForFeed opportunityModelForFeed;
      int differenceDay = 0;
      print("isOpportunity+++++" + isOpportunity.toString());
      if (isOpportunity) {
        var postOpportunity = map["postOpportunity"];
        String opportunityId = postOpportunity[0]["opportunityId"].toString();
        String userId = postOpportunity[0]["userId"].toString();
        String roleId = postOpportunity[0]["roleId"].toString();
        String jobTitle = postOpportunity[0]["jobTitle"].toString();
        String timeZone = postOpportunity[0]["timeZone"].toString();
        String jobType = postOpportunity[0]["jobType"].toString();
        String schoolCode = postOpportunity[0]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String jobLocation = postOpportunity[0]["jobLocation"].toString();
        String project = postOpportunity[0]["project"].toString();
        String duration = postOpportunity[0]["duration"].toString();
        String status = postOpportunity[0]["status"].toString();
        String fromDate = postOpportunity[0]["fromDate"].toString();
        String toDate = postOpportunity[0]["toDate"].toString();
        String groupId = postOpportunity[0]["groupId"].toString();
        String targetAudience = postOpportunity[0]["targetAudience"].toString();
        String title = postOpportunity[0]["title"].toString();
        String gender = postOpportunity[0]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = postOpportunity[0]["companyId"].toString();
        String offerId = postOpportunity[0]["offerId"].toString();
        String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
        String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
        String expiresOn = postOpportunity[0]["expiresOn"].toString();
        String coverPicture = postOpportunity[0]["coverPicture"].toString();
        String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
        String companyName = postOpportunity[0]["companyName"].toString();
        String profilePicture = postOpportunity[0]["profilePicture"].toString();
        String category = postOpportunity[0]["category"].toString();
        //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
        String name = postOpportunity[0]["name"].toString();
        String declineReason = postOpportunity[0]["declineReason"].toString();
        String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
        String url, groupIdAction, callingNumber, formId, linkUrlPosition;
        bool groupIsPublic = true;
        String actionType =
            postOpportunity[0]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          url = postOpportunity[0]['callToAction'][0]['url'].toString();
          linkUrlPosition =
              postOpportunity[0]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction =
              postOpportunity[0]['callToAction'][0]['groupId'].toString();
          groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
          print("groupIsPublic+++++" + groupIsPublic.toString());
          if (groupIsPublic == null) {
            groupIsPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber =
              postOpportunity[0]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        print("shubh+++" + "action" + actionType);

        List<Address> locationList = List<Address>();
        var locationMap = postOpportunity[0]['location'];
        if (locationMap != null) {
          for (int i = 0; i < locationMap.length; i++) {
            String zipcode = locationMap[i]['zipcode'].toString();
            String city = locationMap[i]['city'].toString();
            String country = locationMap[i]['country'].toString();
            String state = locationMap[i]['state'].toString();
            String name = locationMap[i]['name'].toString();
            String target = locationMap[i]['target'].toString();
            locationList
                .add(Address(name, "", city, state, country, zipcode, target));
          }
        }

        List<AgeModel> ageList = List<AgeModel>();
        var ageMao = postOpportunity[0]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          String to = ageMao[k]['to'].toString();
          String from = ageMao[k]['from'].toString();
          //  file= getMediumImage(file);

          ageList.add(new AgeModel(to, from));
        }

        List<IntrestModel> interestTypeList = List<IntrestModel>();
        try {
          var interestTypeModel = postOpportunity[0]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
            //  file= getMediumImage(file);

            interestTypeList.add(new IntrestModel(id, name));
          }
        } catch (e) {}

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = postOpportunity[0]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        if (expiresOn != "null") {
          int d = int.tryParse(expiresOn);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          differenceDay = currentDate.difference(date).inDays;
          print("Difference between++++" + differenceDay.toString());
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        var userImageData = postOpportunity[0]['userImage']; //
        try {
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
        String fees = postOpportunity[0]["fees"].toString();
        String description = postOpportunity[0]["description"].toString();
        String bio = postOpportunity[0]["bio"].toString();
        //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
        //String projectArea = postOpportunity[0]["projectArea"].toString();
        String qualification = postOpportunity[0]["qualification"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        var sceduleData = postOpportunity[0]['schedule']; //
        try {
          if (sceduleData != null) {
            for (int k = 0; k < sceduleData.length; k++) {
              String day = sceduleData[k]['day'].toString();
              var hours = sceduleData[k]['hours'];
              //  file= getMediumImage(file);
              //HoursData hoursData;
              List<HoursData> hoursList = List();
              for (var item in hours) {
                hoursList.add(new HoursData(
                    timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
              }
              scheduleModelParam
                  .add(new ScheduleModelParam(day: day, hours: hoursList));
            }
          }
        } catch (e) {}

        List<String> otherCategoryList = List<String>();
        var otherCategoryMap = postOpportunity[0]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();

            otherCategoryList.add(name);
          }
        }

        List<String> otherCareerList = List<String>();
        var otherCareerMap = postOpportunity[0]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();

            otherCareerList.add(name);
          }
        }
        List<String> otherSubjectList = List<String>();
        var otherSubjectMap = postOpportunity[0]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();

            otherSubjectList.add(name);
          }
        }

        List<MainCategory> designationModelParam = List<MainCategory>();
        var designationData = postOpportunity[0]['category']; //
        try {
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new MainCategory(
                  name: name, categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}

        List<SubCategory> subjectModelParam = List<SubCategory>();
        var subjectData = postOpportunity[0]['subjects']; //
        try {
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(
                  SubCategory(name: name, subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}

        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        var qualificationData = postOpportunity[0]['qualification']; //
        if (qualificationData != null) {
          try {
            for (int k = 0; k < qualificationData.length; k++) {
              String name = qualificationData[k]['name'].toString();
              String isOtherS = qualificationData[k]['isOther'].toString();
              String qualificationId =
                  qualificationData[k]['qualificationId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              qualificationModelParam.add(new QualificationModelParam(
                  name: name,
                  isOther: isOther,
                  qualificationId: int.parse(qualificationId)));
            }
          } catch (e) {}
        }

        opportunityModelForFeed = OpportunityModelForFeed(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            expiresOn,
            coverPicture,
            companyName,
            profilePicture,
            locationList,
            interestTypeList,
            ageList,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            actionType,
            url,
            groupIdAction,
            callingNumber,
            formId,
            linkUrlPosition,
            groupIsPublic,
            studentJoinId,
            fees,
            description,
            bio,
            "",
            //menteeSupport,
            "",
            //advisorSupportOffered,
            "",
            //projectArea,
            userImageModelParam,
            qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            category,
            name,
            "",
            //supportedOffer,
            opportunityCretedUserName,
            opportunityCretedUserImage,
            otherSubjectList,
            otherCategoryList,
            otherCareerList,
            timeZone,
            declineReason,
            partnerStatus,
            schoolCode);
      }

      if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
        print("difference day++++" + differenceDay.toString());
        userPostList.add(new UserPostModal(
            _id,
            feedId,
            postedBy,
            isLiked,
            dateTime,
            visibility,
            firstName,
            lastName,
            email,
            profilePicture,
            title,
            tagline,
            shareText,
            shareTime,
            postOwner,
            postOwnerFirstName,
            postOwnerLastName,
            postOwnerTitle,
            postOwnerProfilePicture,
            isLike,
            isCommented,
            postData,
            commentList,
            likesList,
            tagList,
            groupList,
            scopeList,
            false,
            TextEditingController(text: ""),
            lastActivityTime,
            lastActivityType,
            false,
            false,
            false,
            false,
            isReported,
            isOpportunity,
            postOwnerRoleId,
            roleId,
            postOwnerDeleted,
            opportunityModelForFeed,
            WebLinksModel("", "", "", ""),
            postedGroupName,
            postedGroupId,
            badge,
            gamificationPoints,
            likesCount,
            badgeImage,
            postOwnerBadge,
            postOwnerGamificationPoints,
            postOwnerBadgeImage,
            dateTime2,
            feedStatus,
            schoolCode));
      }
    } catch (e) {
      print("HomeError+++++" + e.toString());
      e.toString();
    }

    return userPostList;
  }

  static List<UserPostModal> parseHome(map, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();

    try {
      bool isLike = map['isLiked'];
      int likesCount = map['likesCount'];
      bool isCommented = false;
      String _id = map['_id'].toString();
      String feedId = map['feedId'].toString();
      bool isLiked = map['isLiked'];
      String postedGroupId = map['groupId'].toString();
      String postedGroupName = map['groupName'].toString();
      String postedBy = map['postedBy'].toString();
      String dateTime = map['dateTime'].toString();
      String schoolCode = map['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      String visibility = map['visibility'].toString();
      String firstName = map['firstName'].toString();
      String lastName = map['lastName'].toString();
      String email = map['email'].toString();
      String roleId = map['roleId'].toString();
      String profilePicture = map['profilePicture'].toString();
      String feedStatus = map['feedStatus'].toString();
//postOwnerRoleId ,roleId
      // profilePicture = getSmallImage(profilePicture);

      String badgeImage = map['badgeImage'].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = map['badge'].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification = map['gamificationPoints'].toString();
      int gamificationPoints;
      if (gamification == "null" || gamification == "") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      if (gamificationPoints == null) {
        gamificationPoints = 0;
      }

      String postOwnerBadgeImage = map['postOwnerBadgeImage'].toString();
      if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
        postOwnerBadgeImage = "";
      }
      String postOwnerBadge = map['postOwnerBadge'].toString();
      if (postOwnerBadge == "null" || postOwnerBadge == "") {
        postOwnerBadge = "";
      }
      String postOwnerGamification =
          map['postOwnerGamificationPoints'].toString();
      int postOwnerGamificationPoints;
      if (postOwnerGamification == "null" || postOwnerGamification == "") {
        postOwnerGamificationPoints = 0;
      } else {
        postOwnerGamificationPoints = int.parse(postOwnerGamification);
      }
      if (postOwnerGamificationPoints == null) {
        postOwnerGamificationPoints = 0;
      }

      String title = map['title'].toString();
      String tagline = map['tagline'].toString();
      String shareText = map['shareText'].toString();
      String shareTime = map['shareTime'].toString();
      String lastActivityTime = map['lastActivityTime'].toString();
      String lastActivityType = map['lastActivityType'].toString();

      String postOwner = map['postOwner'].toString();
      if (postOwner == '0') {
        postOwner = 'null';
      }
      String postOwnerRoleId = map['postOwnerRoleId'].toString();
      String isReported = map['isReported'].toString();
      bool isOpportunity = map['isOpportunity'];

      String postOwnerFirstName = map['postOwnerFirstName'].toString();
      String postOwnerLastName = map['postOwnerLastName'].toString();
      bool postOwnerDeleted = false;
      try {
        postOwnerDeleted =
            map['postOwnerDeleted'] == null ? false : map['postOwnerDeleted'];
      } catch (e) {
        postOwnerDeleted = false;
      }
      String postOwnerTitle = map['postOwnerTitle'].toString();
      String postOwnerProfilePicture =
          map['postOwnerProfilePicture'].toString();
      //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
      DateTime currentDate = DateTime.now();
      if (dateTime != "null") {
        int d = int.tryParse(dateTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        print("firstName++" + firstName.toString());
        print("long++" + d.toString());

        dateTime = getTimeValue(date, currentDate);

        /*var differenceDay = currentDate.difference(date).inDays;
          final differenceHours = currentDate.difference(date).inHours;
          final differenceMinutes = currentDate.difference(date).inMinutes;
          final differenceSeconds = currentDate.difference(date).inSeconds;
          if (differenceDay != 0) {
            if (differenceDay == 1) {
              dateTime = "$differenceDay Day ";
            } else {
              dateTime = "$differenceDay Days ";
            }
          } else if (differenceHours != 0) {
            if (differenceHours == 1) {
              dateTime = "$differenceHours Hour ";
            } else {
              dateTime = "$differenceHours Hours ";
            }
          } else if (differenceMinutes != 0) {
            if (differenceMinutes == 1) {
              dateTime = "$differenceMinutes Minute ";
            } else {
              dateTime = "$differenceMinutes Minutes ";
            }
          } else {
            dateTime = "few seconds ";
          }*/
      }
      if (shareTime != "null") {
        int d = int.tryParse(shareTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        shareTime = getTimeValue(date, currentDate);

        /*final differenceDay = currentDate.difference(date).inDays;
          final differenceHours = currentDate.difference(date).inHours;
          final differenceMinutes = currentDate.difference(date).inMinutes;
          final differenceSeconds = currentDate.difference(date).inSeconds;
          if (differenceDay != 0) {
            if (differenceDay == 1) {
              shareTime = "$differenceDay Day ";
            } else {
              shareTime = "$differenceDay Days ";
            }
          } else if (differenceHours != 0) {
            if (differenceHours == 1) {
              shareTime = "$differenceHours Hour ";
            } else {
              shareTime = "$differenceHours Hours ";
            }
          } else if (differenceMinutes != 0) {
            if (differenceMinutes == 1) {
              shareTime = "$differenceMinutes Minute ";
            } else {
              shareTime = "$differenceMinutes Minutes ";
            }
          } else {
            shareTime = "few seconds ";
          }*/
      }

      var imageMap = map['post']['images'];
      var assetMap = map['post']['assets'];
      String text = map['post']['text'].toString();
      String media = map['post']['media'].toString();
      List<String> imageList = List<String>();
      if (imageMap != null) {
        for (int i = 0; i < imageMap.length; i++) {
          String image = imageMap[i];
          // image = getMediumImage(image);
          if (image != "") imageList.add(image);
        }
      }
      List<AssetIV> assetList = List<AssetIV>();

      if (assetMap != null) {
        for (int i = 0; i < assetMap.length; i++) {
          String image = assetMap[i]["url"];
          String type = assetMap[i]["type"];
          // image = getMediumImage(image);
          if (image != "") assetList.add(AssetIV(file: image, type: type));
        }
      }

      String _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage;

      try {
        _metaUrl = map['post']['metaData']['url'];
        _metaSource = map['post']['metaData']['source'];
        _metaHeight = map['post']['metaData']['height'];
        _metaWidth = map['post']['metaData']['width'];
        _metaTitle = map['post']['metaData']['title'];
        _metaDescription = map['post']['metaData']['description'];
        _metaImage = map['post']['metaData']['image'];
      } catch (e) {
        _metaUrl = "";
        _metaSource = "";
        _metaHeight = "";
        _metaWidth = "";
        _metaTitle = "";
        _metaDescription = "";
        _metaImage = "";
      }

      PostData postData = PostData(
          imageList,
          assetList,
          text,
          media,
          _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage);
      print("sss commetns 7");
      List<CommentData> commentList = List();
      var commentMap = map['comments'];
      if (commentMap != null) {
        for (int j = (commentMap.length - 1); j >= 0; j--) {
          String commentId = commentMap[j]['_id'].toString();
          String comment = commentMap[j]['comment'].toString();
          String commentedBy = commentMap[j]['commentedBy'].toString();
          String dateTime = commentMap[j]['dateTime'].toString();
          String profilePicture = commentMap[j]['profilePicture'].toString();
          String name = commentMap[j]['name'].toString();
          String title = ""; //commentMap[j]['title'].toString();
          String roleId = ""; //commentMap[j]['commentedByRole'].toString();
          String userId = ""; //commentMap[j]['userId'].toString();
          var likesMap = []; //commentMap[j]['likes'];

          String badgeImage = commentMap[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = commentMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification =
              ""; //commentMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          DateTime currentDate = DateTime.now();
          if (dateTime != "null") {
            int d = int.tryParse(dateTime);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            dateTime = getTimeValue(date, currentDate);

            /*final differenceDay = currentDate.difference(date).inDays;
              final differenceHours = currentDate.difference(date).inHours;
              final differenceMinutes = currentDate.difference(date).inMinutes;
              final differenceSeconds = currentDate.difference(date).inSeconds;

              if (differenceDay != 0) {
                if (differenceDay == 1) {
                  dateTime = "$differenceDay Day ";
                } else {
                  dateTime = "$differenceDay Days ";
                }
              } else if (differenceHours != 0) {
                if (differenceHours == 1) {
                  dateTime = "$differenceHours Hour ";
                } else {
                  dateTime = "$differenceHours Hours ";
                }
              } else if (differenceMinutes != 0) {
                if (differenceMinutes == 1) {
                  dateTime = "$differenceMinutes Minute ";
                } else {
                  dateTime = "$differenceMinutes Minutes ";
                }
              } else {
                dateTime = "few seconds ";
              }*/
          }
          //  profilePicture = getSmallImage(profilePicture);

          List<Likes> likesList = List();
          bool isCommentLike = false;
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();

            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['commentRoleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();

            String profilePicture = likesMap[k]['profilePicture'].toString();
            // profilePicture = getSmallImage(profilePicture);
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            if (userId == userIdPref && roleId == userRoleID) {
              isCommentLike = true;
            }
          }
          commentList.add(new CommentData(
              commentId,
              comment,
              commentedBy,
              dateTime,
              profilePicture,
              name,
              title,
              userId,
              likesList,
              isCommentLike,
              roleId,
              badge,
              gamificationPoints,
              badgeImage,
              true));
          if (commentedBy == userIdPref && roleId == userRoleID) {
            isCommented = true;
          }
        }
      }

      List<Likes> likesList = List();
      var likesMap = map['likes'];
      if (likesMap != null) {
        for (int k = 0; k < likesMap.length; k++) {
          String userId = likesMap[k]['userId'].toString();
          String name = likesMap[k]['name'].toString();
          String status = likesMap[k]['status'].toString();
          String roleId = likesMap[k]['roleId'].toString();
          String statusValue = likesMap[k]['statusValue'].toString();
          String profilePicture = likesMap[k]['profilePicture'].toString();
          String title = likesMap[k]['title'].toString();

          String badgeImage = likesMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = likesMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = likesMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          likesList.add(new Likes(userId, name, profilePicture, title, status,
              statusValue, roleId, badge, gamificationPoints, badgeImage));
          // if (userId == userIdPref && roleId == userRoleID) {
          //   isLike = true;
          // }
        }
      }
      List<Tags> tagList = List();
      try {
        var tagMap = map['tags'];

        for (int k = 0; k < tagMap.length; k++) {
          String userId = tagMap[k]['userId'].toString();
          String name = tagMap[k]['name'].toString();
          String profilePicture = tagMap[k]['profilePicture'].toString();
          String title = tagMap[k]['title'].toString();
          String roleId = tagMap[k]['roleId'].toString();
          String badgeImage = tagMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = tagMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = tagMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          tagList.add(new Tags(userId, name, profilePicture, title, roleId,
              badge, gamificationPoints, badgeImage));
        }
      } catch (e) {}

      //------------------- Apurva added Group list start-------------------

      List<Groups> groupList = List();
      try {
        var groupMap = map['groups'];

        for (int k = 0; k < groupMap.length; k++) {
          String groupId = groupMap[k]['groupId'].toString();
          String groupName = groupMap[k]['groupName'].toString();
          String groupImage = groupMap[k]['groupImage'].toString();

          groupList.add(new Groups(groupId, groupName, groupImage));
        }
      } catch (e) {}
      //------------------- Apurva added Group list end-------------------

      var scopeMap = map['scope'];

      List<ScopeModel> scopeList = List<ScopeModel>();
      if (scopeMap != null) {
        for (int k = 0; k < scopeMap.length; k++) {
          String userId = scopeMap[k]['userId'].toString();
          String roleId = scopeMap[k]['roleId'].toString();
          scopeList.add(ScopeModel(userId, roleId));
        }
      }
      String opportunityCretedUserName = map['firstName'].toString() +
          " " +
          map['lastName'].toString().replaceAll("null", "");

      String opportunityCretedUserImage = map['profilePicture'].toString();
      OpportunityModelForFeed opportunityModelForFeed;
      int differenceDay = 0;
      print("isOpportunity+++++" + isOpportunity.toString());
      if (isOpportunity) {
        var postOpportunity = map["postOpportunity"];
        String opportunityId = postOpportunity[0]["opportunityId"].toString();
        String userId = postOpportunity[0]["userId"].toString();
        String roleId = postOpportunity[0]["roleId"].toString();
        String jobTitle = postOpportunity[0]["jobTitle"].toString();
        String schoolCode = postOpportunity[0]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String timeZone = postOpportunity[0]["timeZone"].toString();
        String jobType = postOpportunity[0]["jobType"].toString();
        String jobLocation = postOpportunity[0]["jobLocation"].toString();
        String project = postOpportunity[0]["project"].toString();
        String duration = postOpportunity[0]["duration"].toString();
        String status = postOpportunity[0]["status"].toString();
        String fromDate = postOpportunity[0]["fromDate"].toString();
        String toDate = postOpportunity[0]["toDate"].toString();
        String groupId = postOpportunity[0]["groupId"].toString();
        String targetAudience = postOpportunity[0]["targetAudience"].toString();
        String title = postOpportunity[0]["title"].toString();
        String gender = postOpportunity[0]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = postOpportunity[0]["companyId"].toString();
        String offerId = postOpportunity[0]["offerId"].toString();
        String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
        String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
        String expiresOn = postOpportunity[0]["expiresOn"].toString();
        String coverPicture = postOpportunity[0]["coverPicture"].toString();
        String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
        String companyName = postOpportunity[0]["companyName"].toString();
        String profilePicture = postOpportunity[0]["profilePicture"].toString();
        String category = postOpportunity[0]["category"].toString();
        //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
        String name = postOpportunity[0]["name"].toString();
        String declineReason = postOpportunity[0]["declineReason"].toString();
        String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
        String url, groupIdAction, callingNumber, formId, linkUrlPosition;
        bool groupIsPublic = true;
        String actionType =
            postOpportunity[0]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          url = postOpportunity[0]['callToAction'][0]['url'].toString();
          linkUrlPosition =
              postOpportunity[0]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction =
              postOpportunity[0]['callToAction'][0]['groupId'].toString();
          groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
          print("groupIsPublic+++++" + groupIsPublic.toString());
          if (groupIsPublic == null) {
            groupIsPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber =
              postOpportunity[0]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        print("shubh+++" + "action" + actionType);

        List<Address> locationList = List<Address>();
        var locationMap = postOpportunity[0]['location'];
        if (locationMap != null) {
          for (int i = 0; i < locationMap.length; i++) {
            String zipcode = locationMap[i]['zipcode'].toString();
            String city = locationMap[i]['city'].toString();
            String country = locationMap[i]['country'].toString();
            String state = locationMap[i]['state'].toString();
            String name = locationMap[i]['name'].toString();
            String target = locationMap[i]['target'].toString();
            locationList
                .add(Address(name, "", city, state, country, zipcode, target));
          }
        }

        List<AgeModel> ageList = List<AgeModel>();
        var ageMao = postOpportunity[0]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          String to = ageMao[k]['to'].toString();
          String from = ageMao[k]['from'].toString();
          //  file= getMediumImage(file);

          ageList.add(new AgeModel(to, from));
        }

        List<IntrestModel> interestTypeList = List<IntrestModel>();
        try {
          var interestTypeModel = postOpportunity[0]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
            //  file= getMediumImage(file);

            interestTypeList.add(new IntrestModel(id, name));
          }
        } catch (e) {}

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = postOpportunity[0]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        if (expiresOn != "null") {
          int d = int.tryParse(expiresOn);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          differenceDay = currentDate.difference(date).inDays;
          print("Difference between++++" + differenceDay.toString());
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        var userImageData = postOpportunity[0]['userImage']; //
        try {
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
        String fees = postOpportunity[0]["fees"].toString();
        String description = postOpportunity[0]["description"].toString();
        String bio = postOpportunity[0]["bio"].toString();
        //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
        //String projectArea = postOpportunity[0]["projectArea"].toString();
        String qualification = postOpportunity[0]["qualification"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        var sceduleData = postOpportunity[0]['schedule']; //
        try {
          if (sceduleData != null) {
            for (int k = 0; k < sceduleData.length; k++) {
              String day = sceduleData[k]['day'].toString();
              var hours = sceduleData[k]['hours'];
              //  file= getMediumImage(file);
              //HoursData hoursData;
              List<HoursData> hoursList = List();
              for (var item in hours) {
                hoursList.add(new HoursData(
                    timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
              }
              scheduleModelParam
                  .add(new ScheduleModelParam(day: day, hours: hoursList));
            }
          }
        } catch (e) {}

        List<String> otherCategoryList = List<String>();
        var otherCategoryMap = postOpportunity[0]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();

            otherCategoryList.add(name);
          }
        }

        List<String> otherCareerList = List<String>();
        var otherCareerMap = postOpportunity[0]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();

            otherCareerList.add(name);
          }
        }
        List<String> otherSubjectList = List<String>();
        var otherSubjectMap = postOpportunity[0]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();

            otherSubjectList.add(name);
          }
        }

        List<MainCategory> designationModelParam = List<MainCategory>();
        var designationData = postOpportunity[0]['category']; //
        try {
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new MainCategory(
                  name: name, categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}

        List<SubCategory> subjectModelParam = List<SubCategory>();
        var subjectData = postOpportunity[0]['subjects']; //
        try {
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(
                  SubCategory(name: name, subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}

        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        var qualificationData = postOpportunity[0]['qualification']; //
        if (qualificationData != null) {
          try {
            for (int k = 0; k < qualificationData.length; k++) {
              String name = qualificationData[k]['name'].toString();
              String isOtherS = qualificationData[k]['isOther'].toString();
              String qualificationId =
                  qualificationData[k]['qualificationId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              qualificationModelParam.add(new QualificationModelParam(
                  name: name,
                  isOther: isOther,
                  qualificationId: int.parse(qualificationId)));
            }
          } catch (e) {}
        }

        opportunityModelForFeed = OpportunityModelForFeed(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            expiresOn,
            coverPicture,
            companyName,
            profilePicture,
            locationList,
            interestTypeList,
            ageList,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            actionType,
            url,
            groupIdAction,
            callingNumber,
            formId,
            linkUrlPosition,
            groupIsPublic,
            studentJoinId,
            fees,
            description,
            bio,
            "",
            //menteeSupport,
            "",
            //advisorSupportOffered,
            "",
            //projectArea,
            userImageModelParam,
            qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            category,
            name,
            "",
            //supportedOffer,
            opportunityCretedUserName,
            opportunityCretedUserImage,
            otherSubjectList,
            otherCategoryList,
            otherCareerList,
            timeZone,
            declineReason,
            partnerStatus,
            schoolCode);
      }

      if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
        print("difference day++++" + differenceDay.toString());
        userPostList.add(new UserPostModal(
            _id,
            feedId,
            postedBy,
            isLiked,
            dateTime,
            visibility,
            firstName,
            lastName,
            email,
            profilePicture,
            title,
            tagline,
            shareText,
            shareTime,
            postOwner,
            postOwnerFirstName,
            postOwnerLastName,
            postOwnerTitle,
            postOwnerProfilePicture,
            isLike,
            isCommented,
            postData,
            commentList,
            likesList,
            tagList,
            groupList,
            scopeList,
            false,
            TextEditingController(text: ""),
            lastActivityTime,
            lastActivityType,
            false,
            false,
            false,
            false,
            isReported,
            isOpportunity,
            postOwnerRoleId,
            roleId,
            postOwnerDeleted,
            opportunityModelForFeed,
            WebLinksModel("", "", "", ""),
            postedGroupName,
            postedGroupId,
            badge,
            gamificationPoints,
            likesCount,
            badge,
            postOwnerBadge,
            postOwnerGamificationPoints,
            postOwnerBadgeImage,
            "0",
            feedStatus,
            schoolCode));
      }
    } catch (e) {
      print("HomeError+++++" + e.toString());
      e.toString();
    }

    return userPostList;
  }

  static List<UserPostModal> parseFeedData(data, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();
    for (int i = 0; i < data.length; i++) {
      try {
        var map = jsonDecode(data[i]['data'].replaceAll("_s_", "\""));

        bool isLike = map['isLiked'];
        int likesCount = map['likesCount'];
        bool isCommented = false;
        String _id = map['_id'].toString();
        String feedId = map['feedId'].toString();
        bool isLiked = map['isLiked'];
        String postedGroupId = map['groupId'].toString();
        String postedGroupName = map['groupName'].toString();
        String postedBy = map['postedBy'].toString();
        String dateTime = map['dateTime'].toString();
        String visibility = map['visibility'].toString();
        String schoolCode = map['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String firstName = map['firstName'].toString();
        String lastName = map['lastName'].toString();
        String email = map['email'].toString();
        String roleId = map['roleId'].toString();
        String profilePicture = map['profilePicture'].toString();
        String feedStatus = map['feedStatus'].toString();

        String badgeImage = map['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = map['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        String title = map['title'].toString();
        String tagline = map['tagline'].toString();
        String shareText;
        try {
          shareText = map['shareText'].replaceAll('\\n', '\n');
        } catch (e) {
          shareText = "";
        }
        String shareTime = map['shareTime'].toString();
        String lastActivityTime = map['lastActivityTime'].toString();
        String lastActivityType = map['lastActivityType'].toString();

        String postOwner = map['postOwner'].toString();
        if (postOwner == '0') {
          postOwner = 'null';
        }
        String postOwnerRoleId = map['postOwnerRoleId'].toString();
        String isReported = map['isReported'].toString();
        bool isOpportunity = map['isOpportunity'];

        String postOwnerFirstName = map['postOwnerFirstName'].toString();
        String postOwnerLastName = map['postOwnerLastName'].toString();

        String postOwnerBadgeImage = map['postOwnerBadgeImage'].toString();
        if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
          postOwnerBadgeImage = "";
        }
        String postOwnerBadge = map['postOwnerBadge'].toString();
        if (postOwnerBadge == "null" || postOwnerBadge == "") {
          postOwnerBadge = "";
        }
        String postOwnerGamification =
            map['postOwnerGamificationPoints'].toString();
        int postOwnerGamificationPoints;
        if (postOwnerGamification == "null" || postOwnerGamification == "") {
          postOwnerGamificationPoints = 0;
        } else {
          postOwnerGamificationPoints = int.parse(postOwnerGamification);
        }
        if (postOwnerGamificationPoints == null) {
          postOwnerGamificationPoints = 0;
        }

        bool postOwnerDeleted = false;
        try {
          postOwnerDeleted =
              map['postOwnerDeleted'] == null ? false : map['postOwnerDeleted'];
        } catch (e) {
          postOwnerDeleted = false;
        }
        String postOwnerTitle = map['postOwnerTitle'].toString();
        String postOwnerProfilePicture =
            map['postOwnerProfilePicture'].toString();
        //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
        DateTime currentDate = DateTime.now();
        if (dateTime != "null") {
          int d = int.tryParse(dateTime);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          print("firstName++" + firstName.toString());
          print("long++" + d.toString());

          dateTime = getTimeValue(date, currentDate);
        }
        if (shareTime != "null") {
          int d = int.tryParse(shareTime);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          shareTime = getTimeValue(date, currentDate);
        }

        var imageMap = map['post']['images'];
        String text;
        try {
          text = map['post']['text'].replaceAll('\\n', '\n');
        } catch (e) {
          text = "";
        }
        String media = map['post']['media'].toString();
        List<String> imageList = List<String>();
        List<AssetIV> assetList = List<AssetIV>();
        if (imageMap != null) {
          for (int i = 0; i < imageMap.length; i++) {
            String image = imageMap[i];
            // image = getMediumImage(image);
            if (image != "") imageList.add(image);
          }
        }
        var assetMap = map['post']['assets'];
        if (assetMap != null) {
          for (int i = 0; i < assetMap.length; i++) {
            String image = assetMap[i]["url"];
            String type = assetMap[i]["type"];
            // image = getMediumImage(image);
            if (image != "") assetList.add(AssetIV(file: image, type: type));
          }
        }

        String _metaUrl,
            _metaSource,
            _metaHeight,
            _metaWidth,
            _metaTitle,
            _metaDescription,
            _metaImage;

        try {
          _metaUrl = map['post']['metaData']['url'];
          _metaSource = map['post']['metaData']['source'];
          _metaHeight = map['post']['metaData']['height'];
          _metaWidth = map['post']['metaData']['width'];
          _metaTitle = map['post']['metaData']['title'];
          _metaDescription = map['post']['metaData']['description'];
          _metaImage = map['post']['metaData']['image'];
        } catch (e) {
          _metaUrl = "";
          _metaSource = "";
          _metaHeight = "";
          _metaWidth = "";
          _metaTitle = "";
          _metaDescription = "";
          _metaImage = "";
        }
        print("postData text" + text);
        PostData postData = PostData(
            imageList,
            assetList,
            text,
            media,
            _metaUrl,
            _metaSource,
            _metaHeight,
            _metaWidth,
            _metaTitle,
            _metaDescription,
            _metaImage);
        print("sss commetns 8");
        List<CommentData> commentList = List();
        var commentMap = map['comments'];
        if (commentMap != null) {
          for (int j = (commentMap.length - 1); j >= 0; j--) {
            String commentId = commentMap[j]['_id'].toString();
            String comment = commentMap[j]['comment'].toString();
            String commentedBy = commentMap[j]['commentedBy'].toString();
            String dateTime = commentMap[j]['dateTime'].toString();
            String profilePicture = commentMap[j]['profilePicture'].toString();
            String name = commentMap[j]['name'].toString();
            String title = ""; //commentMap[j]['title'].toString();
            String roleId = ""; //commentMap[j]['commentedByRole'].toString();
            String userId = ""; //commentMap[j]['userId'].toString();
            var likesMap = []; //commentMap[j]['likes'];

            String badgeImage = commentMap[j]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = commentMap[j]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = ""; //
            //commentMap[j]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            try {
              DateTime currentDate = DateTime.now();
              if (dateTime != "null") {
                int d = int.tryParse(dateTime);
                DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

                dateTime = getTimeValue(date, currentDate);

                /*final differenceDay = currentDate.difference(date).inDays;
              final differenceHours = currentDate.difference(date).inHours;
              final differenceMinutes = currentDate.difference(date).inMinutes;
              final differenceSeconds = currentDate.difference(date).inSeconds;

              if (differenceDay != 0) {
                if (differenceDay == 1) {
                  dateTime = "$differenceDay Day ";
                } else {
                  dateTime = "$differenceDay Days ";
                }
              } else if (differenceHours != 0) {
                if (differenceHours == 1) {
                  dateTime = "$differenceHours Hour ";
                } else {
                  dateTime = "$differenceHours Hours ";
                }
              } else if (differenceMinutes != 0) {
                if (differenceMinutes == 1) {
                  dateTime = "$differenceMinutes Minute ";
                } else {
                  dateTime = "$differenceMinutes Minutes ";
                }
              } else {
                dateTime = "few seconds ";
              }*/
              }
            } catch (e) {}
            //  profilePicture = getSmallImage(profilePicture);

            List<Likes> likesList = List();
            bool isCommentLike = false;
            for (int k = 0; k < likesMap.length; k++) {
              String userId = likesMap[k]['userId'].toString();
              String name = likesMap[k]['name'].toString();

              String status = likesMap[k]['status'].toString();
              String roleId = likesMap[k]['commentRoleId'].toString();
              String statusValue = likesMap[k]['statusValue'].toString();

              String profilePicture = likesMap[k]['profilePicture'].toString();
              // profilePicture = getSmallImage(profilePicture);
              String title = likesMap[k]['title'].toString();

              String badgeImage = likesMap[k]['badgeImage'].toString();
              if (badgeImage == "null" || badgeImage == "") {
                badgeImage = "";
              }
              String badge = likesMap[k]['badge'].toString();
              if (badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  likesMap[k]['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == "null" || gamification == "") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }
              if (gamificationPoints == null) {
                gamificationPoints = 0;
              }

              likesList.add(new Likes(
                  userId,
                  name,
                  profilePicture,
                  title,
                  status,
                  statusValue,
                  roleId,
                  badge,
                  gamificationPoints,
                  badgeImage));
              if (userId == userIdPref && roleId == userRoleID) {
                isCommentLike = true;
              }
            }
            commentList.add(new CommentData(
                commentId,
                comment,
                commentedBy,
                dateTime,
                profilePicture,
                name,
                title,
                userId,
                likesList,
                isCommentLike,
                roleId,
                badge,
                gamificationPoints,
                badgeImage,
                true));
            if (commentedBy == userIdPref && roleId == userRoleID) {
              isCommented = true;
            }
          }
        }

        List<Likes> likesList = List();
        var likesMap = map['likes'];
        if (likesMap != null) {
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();
            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['roleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();
            String profilePicture = likesMap[k]['profilePicture'].toString();
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            // if (userId == userIdPref && roleId == userRoleID) {
            //   isLike = true;
            // }
          }
        }
        List<Tags> tagList = List();
        try {
          var tagMap = map['tags'];

          for (int k = 0; k < tagMap.length; k++) {
            String userId = tagMap[k]['userId'].toString();
            String name = tagMap[k]['name'].toString();
            String profilePicture = tagMap[k]['profilePicture'].toString();
            String title = tagMap[k]['title'].toString();
            String roleId = tagMap[k]['roleId'].toString();
            String badgeImage = tagMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = tagMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = tagMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            tagList.add(new Tags(userId, name, profilePicture, title, roleId,
                badge, gamificationPoints, badgeImage));
          }
        } catch (e) {}

        //------------------- Apurva added Group list start-------------------

        List<Groups> groupList = List();
        try {
          var groupMap = map['groups'];

          for (int k = 0; k < groupMap.length; k++) {
            String groupId = groupMap[k]['groupId'].toString();
            String groupName = groupMap[k]['groupName'].toString();
            String groupImage = groupMap[k]['groupImage'].toString();

            groupList.add(new Groups(groupId, groupName, groupImage));
          }
        } catch (e) {}
        //------------------- Apurva added Group list end-------------------

        var scopeMap = map['scope'];

        List<ScopeModel> scopeList = List<ScopeModel>();
        if (scopeMap != null) {
          for (int k = 0; k < scopeMap.length; k++) {
            String userId = scopeMap[k]['userId'].toString();
            String roleId = scopeMap[k]['roleId'].toString();
            scopeList.add(ScopeModel(userId, roleId));
          }
        }
        String opportunityCretedUserName = map['firstName'].toString() +
            " " +
            map['lastName'].toString().replaceAll("null", "");

        String opportunityCretedUserImage = map['profilePicture'].toString();
        OpportunityModelForFeed opportunityModelForFeed;
        int differenceDay = 0;
        print("isOpportunity+++++" + isOpportunity.toString());
        if (isOpportunity) {
          var postOpportunity = map["postOpportunity"];
          String opportunityId = postOpportunity[0]["opportunityId"].toString();
          String userId = postOpportunity[0]["userId"].toString();
          String roleId = postOpportunity[0]["roleId"].toString();
          String schoolCode = postOpportunity[0]['schoolCode'].toString();
          if (schoolCode == "null" || schoolCode == "") {
            schoolCode = "";
          }
          String jobTitle = postOpportunity[0]["jobTitle"].toString();
          String timeZone = postOpportunity[0]["timeZone"].toString();
          String jobType = postOpportunity[0]["jobType"].toString();
          String jobLocation = postOpportunity[0]["jobLocation"].toString();
          String project = postOpportunity[0]["project"].toString();
          String duration = postOpportunity[0]["duration"].toString();
          String status = postOpportunity[0]["status"].toString();
          String fromDate = postOpportunity[0]["fromDate"].toString();
          String toDate = postOpportunity[0]["toDate"].toString();
          String groupId = postOpportunity[0]["groupId"].toString();
          String targetAudience =
              postOpportunity[0]["targetAudience"].toString();
          String title = postOpportunity[0]["title"].toString();
          String gender = postOpportunity[0]["gender"].toString();
          if (gender == "Non-binary" || gender == "NonBinary") {
            gender = "Non-Binary";
          }
          String companyId = postOpportunity[0]["companyId"].toString();
          String offerId = postOpportunity[0]["offerId"].toString();
          String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
          String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
          String expiresOn = postOpportunity[0]["expiresOn"].toString();
          String coverPicture = postOpportunity[0]["coverPicture"].toString();
          String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
          String companyName = postOpportunity[0]["companyName"].toString();
          String profilePicture =
              postOpportunity[0]["profilePicture"].toString();
          String category = postOpportunity[0]["category"].toString();
          //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
          String name = postOpportunity[0]["name"].toString();
          String declineReason = postOpportunity[0]["declineReason"].toString();
          String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
          String url, groupIdAction, callingNumber, formId, linkUrlPosition;
          bool groupIsPublic = true;
          String actionType =
              postOpportunity[0]['callToAction'][0]['id'].toString();
          if (actionType == Constant.LINK_URL) {
            url = postOpportunity[0]['callToAction'][0]['url'].toString();
            linkUrlPosition =
                postOpportunity[0]['callToAction'][0]['position'].toString();
            print("action+++" + url);
          } else if (actionType == Constant.JOIN_GROUP) {
            groupIdAction =
                postOpportunity[0]['callToAction'][0]['groupId'].toString();
            groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
            print("groupIsPublic+++++" + groupIsPublic.toString());
            if (groupIsPublic == null) {
              groupIsPublic = true;
            }
            print("action+++jpoinGroup+++" + groupIdAction);
          } else if (actionType == Constant.CALL_NOW) {
            callingNumber =
                postOpportunity[0]['callToAction'][0]['number'].toString();
            print("action+++" + callingNumber);
          } else if (actionType == Constant.INQUIRE_NOW) {
            formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
            print("action+++" + formId);
          }

          print("shubh+++" + "action" + actionType);

          List<Address> locationList = List<Address>();
          var locationMap = postOpportunity[0]['location'];
          if (locationMap != null) {
            for (int i = 0; i < locationMap.length; i++) {
              String zipcode = locationMap[i]['zipcode'].toString();
              String city = locationMap[i]['city'].toString();
              String country = locationMap[i]['country'].toString();
              String state = locationMap[i]['state'].toString();
              String name = locationMap[i]['name'].toString();
              String target = locationMap[i]['target'].toString();
              locationList.add(
                  Address(name, "", city, state, country, zipcode, target));
            }
          }

          List<AgeModel> ageList = List<AgeModel>();
          var ageMao = postOpportunity[0]['age'];
          for (int k = 0; k < ageMao.length; k++) {
            String to = ageMao[k]['to'].toString();
            String from = ageMao[k]['from'].toString();
            //  file= getMediumImage(file);

            ageList.add(new AgeModel(to, from));
          }

          List<IntrestModel> interestTypeList = List<IntrestModel>();
          try {
            var interestTypeModel = postOpportunity[0]['interestType'];
            for (int k = 0; k < interestTypeModel.length; k++) {
              String id = interestTypeModel[k]['id'].toString();
              String name = interestTypeModel[k]['name'].toString();
              //  file= getMediumImage(file);

              interestTypeList.add(new IntrestModel(id, name));
            }
          } catch (e) {}

          List<Assest> assestList = List<Assest>();
          List<Assest> assestVideoAndImage = List<Assest>();
          List<Assest> videoList = List<Assest>();
          List<Assest> docList = List<Assest>();
          List<Assest> googleLinkList = List<Assest>();
          List<Assest> mediaList = List<Assest>();

          var asetMap = postOpportunity[0]['asset'];
          if (asetMap != null) {
            for (int k = 0; k < asetMap.length; k++) {
              String type = asetMap[k]['type'].toString();
              String tag = asetMap[k]['tag'].toString();
              String file = asetMap[k]['file'].toString();
              String label = asetMap[k]['label'].toString();
              //  file= getMediumImage(file);

              assestList.add(new Assest(type, tag, file, label, false));

              if (type == "image") {
                mediaList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "video") {
                videoList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "doc") {
                docList.add(new Assest(type, tag, file, label, false));
              } else if (type == "google") {
                googleLinkList.add(new Assest(type, tag, file, label, false));
              }
            }
          }

          if (expiresOn != "null") {
            int d = int.tryParse(expiresOn);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            differenceDay = currentDate.difference(date).inDays;
            print("Difference between++++" + differenceDay.toString());
          }

          List<UserImageModelParam> userImageModelParam =
              List<UserImageModelParam>();
          var userImageData = postOpportunity[0]['userImage']; //
          try {
            if (userImageData != null) {
              for (int k = 0; k < userImageData.length; k++) {
                String file = userImageData[k]['file'].toString();
                userImageModelParam.add(new UserImageModelParam(file: file));
              }
            }
          } catch (e) {}

          //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
          String fees = postOpportunity[0]["fees"].toString();
          String description = postOpportunity[0]["description"].toString();
          String bio = postOpportunity[0]["bio"].toString();
          //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
          //String projectArea = postOpportunity[0]["projectArea"].toString();
          String qualification = postOpportunity[0]["qualification"].toString();

          List<ScheduleModelParam> scheduleModelParam =
              List<ScheduleModelParam>();
          var sceduleData = postOpportunity[0]['schedule']; //
          try {
            if (sceduleData != null) {
              for (int k = 0; k < sceduleData.length; k++) {
                String day = sceduleData[k]['day'].toString();
                var hours = sceduleData[k]['hours'];
                //  file= getMediumImage(file);
                //HoursData hoursData;
                List<HoursData> hoursList = List();
                for (var item in hours) {
                  hoursList.add(new HoursData(
                      timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
                }
                scheduleModelParam
                    .add(new ScheduleModelParam(day: day, hours: hoursList));
              }
            }
          } catch (e) {}

          List<String> otherCategoryList = List<String>();
          var otherCategoryMap = postOpportunity[0]['otherCategory'];
          if (otherCategoryMap != null) {
            for (int i = 0; i < otherCategoryMap.length; i++) {
              String name = otherCategoryMap[i]['name'].toString();

              otherCategoryList.add(name);
            }
          }

          List<String> otherCareerList = List<String>();
          var otherCareerMap = postOpportunity[0]['otherCareer'];
          if (otherCareerMap != null) {
            for (int i = 0; i < otherCareerMap.length; i++) {
              String name = otherCareerMap[i]['name'].toString();

              otherCareerList.add(name);
            }
          }
          List<String> otherSubjectList = List<String>();
          var otherSubjectMap = postOpportunity[0]['otherSubject'];
          if (otherSubjectMap != null) {
            for (int i = 0; i < otherSubjectMap.length; i++) {
              String name = otherSubjectMap[i]['name'].toString();

              otherSubjectList.add(name);
            }
          }

          List<MainCategory> designationModelParam = List<MainCategory>();
          var designationData = postOpportunity[0]['category']; //
          try {
            if (designationData != null) {
              for (int k = 0; k < designationData.length; k++) {
                String name = designationData[k]['name'].toString();
                String isOtherS = designationData[k]['isOther'].toString();
                String categoryId = designationData[k]['categoryId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                designationModelParam.add(new MainCategory(
                    name: name, categoryId: int.parse(categoryId)));
              }
            }
          } catch (e) {}

          List<SubCategory> subjectModelParam = List<SubCategory>();
          var subjectData = postOpportunity[0]['subjects']; //
          try {
            if (subjectData != null) {
              for (int k = 0; k < subjectData.length; k++) {
                String name = subjectData[k]['name'].toString();
                String isOtherS = subjectData[k]['isOther'].toString();
                String subjectId = subjectData[k]['subjectId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                subjectModelParam.add(new SubCategory(
                    name: name, subjectId: int.parse(subjectId)));
              }
            }
          } catch (e) {}

          List<QualificationModelParam> qualificationModelParam =
              List<QualificationModelParam>();
          var qualificationData = postOpportunity[0]['qualification']; //
          if (qualificationData != null) {
            try {
              for (int k = 0; k < qualificationData.length; k++) {
                String name = qualificationData[k]['name'].toString();
                String isOtherS = qualificationData[k]['isOther'].toString();
                String qualificationId =
                    qualificationData[k]['qualificationId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                qualificationModelParam.add(new QualificationModelParam(
                    name: name,
                    isOther: isOther,
                    qualificationId: int.parse(qualificationId)));
              }
            } catch (e) {}
          }

          opportunityModelForFeed = OpportunityModelForFeed(
              opportunityId,
              userId,
              roleId,
              jobTitle,
              jobType,
              jobLocation,
              project,
              duration,
              status,
              fromDate,
              toDate,
              groupId,
              targetAudience,
              title,
              gender,
              companyId,
              offerId,
              serviceTitle,
              serviceDesc,
              expiresOn,
              coverPicture,
              companyName,
              profilePicture,
              locationList,
              interestTypeList,
              ageList,
              assestList,
              assestVideoAndImage,
              videoList,
              docList,
              mediaList,
              googleLinkList,
              actionType,
              url,
              groupIdAction,
              callingNumber,
              formId,
              linkUrlPosition,
              groupIsPublic,
              studentJoinId,
              fees,
              description,
              bio,
              "",
              //menteeSupport,
              "",
              //advisorSupportOffered,
              "",
              //projectArea,
              userImageModelParam,
              qualification,
              qualificationModelParam,
              designationModelParam,
              subjectModelParam,
              scheduleModelParam,
              category,
              name,
              "",
              //supportedOffer,
              opportunityCretedUserName,
              opportunityCretedUserImage,
              otherSubjectList,
              otherCategoryList,
              otherCareerList,
              timeZone,
              declineReason,
              partnerStatus,
              schoolCode);
        }

        if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
          print("difference day++++" + differenceDay.toString());
          userPostList.add(new UserPostModal(
              _id,
              feedId,
              postedBy,
              isLiked,
              dateTime,
              visibility,
              firstName,
              lastName,
              email,
              profilePicture,
              title,
              tagline,
              shareText,
              shareTime,
              postOwner,
              postOwnerFirstName,
              postOwnerLastName,
              postOwnerTitle,
              postOwnerProfilePicture,
              isLike,
              isCommented,
              postData,
              commentList,
              likesList,
              tagList,
              groupList,
              scopeList,
              false,
              TextEditingController(text: ""),
              lastActivityTime,
              lastActivityType,
              false,
              false,
              false,
              false,
              isReported,
              isOpportunity,
              postOwnerRoleId,
              roleId,
              postOwnerDeleted,
              opportunityModelForFeed,
              WebLinksModel("", "", "", ""),
              postedGroupName,
              postedGroupId,
              badge,
              gamificationPoints,
              likesCount,
              badgeImage,
              postOwnerBadge,
              postOwnerGamificationPoints,
              postOwnerBadgeImage,
              "0",
              feedStatus,
              schoolCode));
        }
      } catch (e) {
        print("HomeError+++++" + e.toString());
        e.toString();
      }
    }

    return userPostList;
  }

  static List<UserPostModal> parseHomeModel(map, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();
    for (int i = 0; i < map.length; i++) {
      log("post+++"+map[i].toString());
      // try {
      /*  DbHelper().insertTodo(map[i]['feedId'].toString(),
            jsonEncode("{_s__id_s_:_s_61c5c31df1543a6ffadff631_s_,_s_opportunityId_s_:0,_s_feedId_s_:10606,_s_groupId_s_:0,_s_post_s_:{_s_text_s_:_s_The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English._s_,_s_images_s_:[_s_sv_4376/image/1640350477882iZZdi.jpg_s_],_s_media_s_:_s__s_},_s_postedBy_s_:4376,_s_dateTime_s_:1640350492162,_s_visibility_s_:_s_Community_s_,_s_feedStatus_s_:_s_Active_s_,_s_comments_s_:[],_s_likes_s_:[],_s_tags_s_:[],_s_scope_s_:[],_s_firstName_s_:_s_LMS_s_,_s_lastName_s_:_s__s_,_s_roleId_s_:4,_s_email_s_:_s_SEpunv9Xa+44aCAJyG09go1julx64I5GBPE2Ickr+IY=_s_,_s_profilePicture_s_:_s__s_,_s_postOwnerRoleId_s_:0,_s_shareTime_s_:0,_s_lastActivityTime_s_:1640350492162,_s_lastActivityType_s_:_s_CreateFeed_s_,_s_postOpportunity_s_:[{}],_s_gamificationPoints_s_:0,_s_badge_s_:_s__s_,_s_groupIds_s_:[],_s_badgeImage_s_:_s__s_,_s_isReported_s_:false,_s_isHide_s_:false,_s_isOpportunity_s_:false,_s_groups_s_:[]}"));
    */
      try {
        DbHelper().insertTodo(map[i]['feedId'].toString(),
            jsonEncode(jsonEncode(map[i]).replaceAll("\"", "_s_").toString()));
      } catch (e) {
        print("error=======" + e.toString());
      }

      bool isLike = map[i]['isLiked'];
      int likesCount = map[i]['likesCount'];
      bool isCommented = false;
      String _id = map[i]['_id'].toString();
      String feedId = map[i]['feedId'].toString();
      bool isLiked = map[i]['isLiked'];
      String postedGroupId = map[i]['groupId'].toString();
      String postedGroupName = map[i]['groupName'].toString();
      String postedBy = map[i]['postedBy'].toString();
      String dateTime = map[i]['dateTime'].toString();
      String visibility = map[i]['visibility'].toString();
      String firstName = map[i]['firstName'].toString();
      String lastName = map[i]['lastName'].toString();
      String email = map[i]['email'].toString();
      String roleId = map[i]['roleId'].toString();
      String profilePicture = map[i]['profilePicture'].toString();
      String feedStatus = map[i]['feedStatus'].toString();
      String schoolCode = map[i]['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      String badgeImage = map[i]['badgeImage'].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = map[i]['badge'].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification = map[i]['gamificationPoints'].toString();
      int gamificationPoints;
      if (gamification == "null" || gamification == "") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      if (gamificationPoints == null) {
        gamificationPoints = 0;
      }

//postOwnerRoleId ,roleId
      // profilePicture = getSmallImage(profilePicture);

      String title = map[i]['title'].toString();
      String tagline = map[i]['tagline'].toString();
      String shareText = map[i]['shareText'].toString();
      String shareTime = map[i]['shareTime'].toString();
      String lastActivityTime = map[i]['lastActivityTime'].toString();
      String lastActivityType = map[i]['lastActivityType'].toString();

      String postOwner = map[i]['postOwner'].toString();
      if (postOwner == '0') {
        postOwner = 'null';
      }
      String postOwnerRoleId = map[i]['postOwnerRoleId'].toString();
      String isReported = map[i]['isReported'].toString();
      bool isOpportunity = map[i]['isOpportunity'];

      String postOwnerFirstName = map[i]['postOwnerFirstName'].toString();
      String postOwnerLastName = map[i]['postOwnerLastName'].toString();

      String postOwnerBadgeImage = map[i]['postOwnerBadgeImage'].toString();
      if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
        postOwnerBadgeImage = "";
      }
      String postOwnerBadge = map[i]['postOwnerBadge'].toString();
      if (postOwnerBadge == "null" || postOwnerBadge == "") {
        postOwnerBadge = "";
      }
      String postOwnerGamification =
          map[i]['postOwnerGamificationPoints'].toString();
      int postOwnerGamificationPoints;
      if (postOwnerGamification == "null" || postOwnerGamification == "") {
        postOwnerGamificationPoints = 0;
      } else {
        postOwnerGamificationPoints = int.parse(postOwnerGamification);
      }
      if (postOwnerGamificationPoints == null) {
        postOwnerGamificationPoints = 0;
      }

      bool postOwnerDeleted = false;
      try {
        postOwnerDeleted = map[i]['postOwnerDeleted'] == null
            ? false
            : map[i]['postOwnerDeleted'];
      } catch (e) {
        postOwnerDeleted = false;
      }
      String postOwnerTitle = map[i]['postOwnerTitle'].toString();
      String postOwnerProfilePicture =
          map[i]['postOwnerProfilePicture'].toString();
      //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
      DateTime currentDate = DateTime.now();
      if (dateTime != "null") {
        int d = int.tryParse(dateTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        print("firstName++" + firstName.toString());
        print("long++" + d.toString());

        dateTime = getTimeValue(date, currentDate);
      }
      if (shareTime != "null") {
        int d = int.tryParse(shareTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        shareTime = getTimeValue(date, currentDate);
      }

      var imageMap = map[i]['post']['images'];
      var assetMap = map[i]['post']['assets'];
      String text = map[i]['post']['text'].toString();
      String media = map[i]['post']['media'].toString();
      List<String> imageList = List<String>();
      if (imageMap != null) {
        for (int i = 0; i < imageMap.length; i++) {
          String image = imageMap[i];
          // image = getMediumImage(image);
          if (image != "") imageList.add(image);
        }
      }
      List<AssetIV> assetList = List<AssetIV>();

      if (assetMap != null) {
        for (int i = 0; i < assetMap.length; i++) {
          String image = assetMap[i]["url"];
          String type = assetMap[i]["type"];
          // image = getMediumImage(image);
          if (image != "") assetList.add(AssetIV(file: image, type: type));
        }
      }

      String _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage;

      try {
        _metaUrl = map[i]['post']['metaData']['url'];
        _metaSource = map[i]['post']['metaData']['source'];
        _metaHeight = map[i]['post']['metaData']['height'];
        _metaWidth = map[i]['post']['metaData']['width'];
        _metaTitle = map[i]['post']['metaData']['title'];
        _metaDescription = map[i]['post']['metaData']['description'];
        _metaImage = map[i]['post']['metaData']['image'];
      } catch (e) {
        _metaUrl = "";
        _metaSource = "";
        _metaHeight = "";
        _metaWidth = "";
        _metaTitle = "";
        _metaDescription = "";
        _metaImage = "";
      }

      PostData postData = PostData(
          imageList,
          assetList,
          text,
          media,
          _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage);
      print("sss commetns 1");
      List<CommentData> commentList = List();
      var commentMap = map[i]['comments'];
      if (commentMap != null) {
        for (int j = (commentMap.length - 1); j >= 0; j--) {
          print("sss commetns 1 ${commentMap[j]['_id']}");
          String commentId = commentMap[j]['_id'].toString();
          String comment = commentMap[j]['comment'].toString();
          String commentedBy = commentMap[j]['commentedBy'].toString();
          String dateTime = commentMap[j]['dateTime'].toString();
          String profilePicture = commentMap[j]['profilePicture'].toString();
          String name = commentMap[j]['name'].toString();
          String title = ""; //commentMap[j]['title'].toString();
          String roleId = ""; //commentMap[j]['commentedByRole'].toString();
          String userId = ""; //commentMap[j]['userId'].toString();
          var likesMap = []; //commentMap[j]['likes'];

          String badgeImage = commentMap[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = commentMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification =
              ""; //commentMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          DateTime currentDate = DateTime.now();
          if (dateTime != "null") {
            int d = int.tryParse(dateTime);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            dateTime = getTimeValue(date, currentDate);
          }

          List<Likes> likesList = List();
          bool isCommentLike = false;
          if (likesMap != null) {
            for (int k = 0; k < likesMap.length; k++) {
              String userId = likesMap[k]['userId'].toString();
              String name = likesMap[k]['name'].toString();

              String status = likesMap[k]['status'].toString();
              String roleId = likesMap[k]['commentRoleId'].toString();
              String statusValue = likesMap[k]['statusValue'].toString();

              String profilePicture = likesMap[k]['profilePicture'].toString();
              // profilePicture = getSmallImage(profilePicture);
              String title = likesMap[k]['title'].toString();

              String badgeImage = likesMap[k]['badgeImage'].toString();
              if (badgeImage == "null" || badgeImage == "") {
                badgeImage = "";
              }
              String badge = likesMap[k]['badge'].toString();
              if (badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  likesMap[k]['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == "null" || gamification == "") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }
              if (gamificationPoints == null) {
                gamificationPoints = 0;
              }

              likesList.add(new Likes(
                  userId,
                  name,
                  profilePicture,
                  title,
                  status,
                  statusValue,
                  roleId,
                  badge,
                  gamificationPoints,
                  badgeImage));
              if (userId == userIdPref && roleId == userRoleID) {
                isCommentLike = true;
              }
            }
            commentList.add(new CommentData(
                commentId,
                comment,
                commentedBy,
                dateTime,
                profilePicture,
                name,
                title,
                userId,
                likesList,
                isCommentLike,
                roleId,
                badge,
                gamificationPoints,
                badgeImage,
                true));

            print("sss commetns 1 ${commentList.length}");
            if (commentedBy == userIdPref && roleId == userRoleID) {
              isCommented = true;
            }
          }
        }
      }

      List<Likes> likesList = List();
      var likesMap = map[i]['likes'];
      if (likesMap != null) {
        for (int k = 0; k < likesMap.length; k++) {
          String userId = likesMap[k]['userId'].toString();
          String name = likesMap[k]['name'].toString();
          String status = likesMap[k]['status'].toString();
          String roleId = likesMap[k]['roleId'].toString();
          String statusValue = likesMap[k]['statusValue'].toString();
          String profilePicture = likesMap[k]['profilePicture'].toString();
          String title = likesMap[k]['title'].toString();

          String badgeImage = likesMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = likesMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = likesMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          likesList.add(new Likes(userId, name, profilePicture, title, status,
              statusValue, roleId, badge, gamificationPoints, badgeImage));
          // if (userId == userIdPref && roleId == userRoleID) {
          //   isLike = true;
          // }
        }
      }

      List<Tags> tagList = List();
      try {
        var tagMap = map[i]['tags'];
        if (tagMap != null) {
          for (int k = 0; k < tagMap.length; k++) {
            String userId = tagMap[k]['userId'].toString();
            String name = tagMap[k]['name'].toString();
            String profilePicture = tagMap[k]['profilePicture'].toString();
            String title = tagMap[k]['title'].toString();
            String roleId = tagMap[k]['roleId'].toString();
            String badgeImage = tagMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = tagMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = tagMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            tagList.add(new Tags(userId, name, profilePicture, title, roleId,
                badge, gamificationPoints, badgeImage));
          }
        }
      } catch (e) {}

      //------------------- Apurva added Group list start-------------------

      List<Groups> groupList = List();
      try {
        var groupMap = map[i]['groups'];
        if (groupMap != null) {
          for (int k = 0; k < groupMap.length; k++) {
            String groupId = groupMap[k]['groupId'].toString();
            String groupName = groupMap[k]['groupName'].toString();
            String groupImage = groupMap[k]['groupImage'].toString();

            groupList.add(new Groups(groupId, groupName, groupImage));
          }
        }
      } catch (e) {}
      //------------------- Apurva added Group list end-------------------

      var scopeMap = map[i]['scope'];

      List<ScopeModel> scopeList = List<ScopeModel>();
      try {
        if (scopeMap != null) {
          for (int k = 0; k < scopeMap.length; k++) {
            String userId = scopeMap[k]['userId'].toString();
            String roleId = scopeMap[k]['roleId'].toString();
            scopeList.add(ScopeModel(userId, roleId));
          }
        }
      } catch (e) {}
      String opportunityCretedUserName = map[i]['firstName'].toString() +
          " " +
          map[i]['lastName'].toString().replaceAll("null", "");

      String opportunityCretedUserImage = map[i]['profilePicture'].toString();
      OpportunityModelForFeed opportunityModelForFeed;
      int differenceDay = 0;
      print("isOpportunity+++++" + isOpportunity.toString());
      if (isOpportunity) {
        var postOpportunity = map[i]["postOpportunity"];
        String opportunityId = postOpportunity[0]["opportunityId"].toString();
        String userId = postOpportunity[0]["userId"].toString();
        String roleId = postOpportunity[0]["roleId"].toString();
        String jobTitle = postOpportunity[0]["jobTitle"].toString();
        String timeZone = postOpportunity[0]["timeZone"].toString();
        String jobType = postOpportunity[0]["jobType"].toString();
        String schoolCode = postOpportunity[0]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String jobLocation = postOpportunity[0]["jobLocation"].toString();
        String project = postOpportunity[0]["project"].toString();
        String duration = postOpportunity[0]["duration"].toString();
        String status = postOpportunity[0]["status"].toString();
        String fromDate = postOpportunity[0]["fromDate"].toString();
        String toDate = postOpportunity[0]["toDate"].toString();
        String groupId = postOpportunity[0]["groupId"].toString();
        String targetAudience = postOpportunity[0]["targetAudience"].toString();
        String title = postOpportunity[0]["title"].toString();
        String gender = postOpportunity[0]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = postOpportunity[0]["companyId"].toString();
        String offerId = postOpportunity[0]["offerId"].toString();
        String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
        String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
        String expiresOn = postOpportunity[0]["expiresOn"].toString();
        String coverPicture = postOpportunity[0]["coverPicture"].toString();
        String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
        String companyName = postOpportunity[0]["companyName"].toString();
        String profilePicture = postOpportunity[0]["profilePicture"].toString();
        String category = postOpportunity[0]["category"].toString();
        //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
        String name = postOpportunity[0]["name"].toString();
        String declineReason = postOpportunity[0]["declineReason"].toString();
        String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
        String url, groupIdAction, callingNumber, formId, linkUrlPosition;
        bool groupIsPublic = true;
        String actionType =
            postOpportunity[0]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          url = postOpportunity[0]['callToAction'][0]['url'].toString();
          linkUrlPosition =
              postOpportunity[0]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction =
              postOpportunity[0]['callToAction'][0]['groupId'].toString();
          groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
          print("groupIsPublic+++++" + groupIsPublic.toString());
          if (groupIsPublic == null) {
            groupIsPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber =
              postOpportunity[0]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        print("shubh+++" + "action" + actionType);

        List<Address> locationList = List<Address>();
        try {
          var locationMap = postOpportunity[0]['location'];
          if (locationMap != null) {
            for (int i = 0; i < locationMap.length; i++) {
              String zipcode = locationMap[i]['zipcode'].toString();
              String city = locationMap[i]['city'].toString();
              String country = locationMap[i]['country'].toString();
              String state = locationMap[i]['state'].toString();
              String name = locationMap[i]['name'].toString();
              String target = locationMap[i]['target'].toString();
              locationList.add(
                  Address(name, "", city, state, country, zipcode, target));
            }
          }
        } catch (e) {}

        List<AgeModel> ageList = List<AgeModel>();
        try {
          var ageMao = postOpportunity[0]['age'];
          if (ageMao != null) {
            for (int k = 0; k < ageMao.length; k++) {
              String to = ageMao[k]['to'].toString();
              String from = ageMao[k]['from'].toString();
              //  file= getMediumImage(file);

              ageList.add(new AgeModel(to, from));
            }
          }
        } catch (e) {}
        List<IntrestModel> interestTypeList = List<IntrestModel>();
        try {
          var interestTypeModel = postOpportunity[0]['interestType'];
          if (interestTypeModel != null) {
            for (int k = 0; k < interestTypeModel.length; k++) {
              String id = interestTypeModel[k]['id'].toString();
              String name = interestTypeModel[k]['name'].toString();
              //  file= getMediumImage(file);

              interestTypeList.add(new IntrestModel(id, name));
            }
          }
        } catch (e) {}

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = postOpportunity[0]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        if (expiresOn != "null") {
          int d = int.tryParse(expiresOn);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          differenceDay = currentDate.difference(date).inDays;
          print("Difference between++++" + differenceDay.toString());
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        var userImageData = postOpportunity[0]['userImage']; //
        try {
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
        String fees = postOpportunity[0]["fees"].toString();
        String description = postOpportunity[0]["description"].toString();
        String bio = postOpportunity[0]["bio"].toString();
        //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
        //String projectArea = postOpportunity[0]["projectArea"].toString();
        String qualification = postOpportunity[0]["qualification"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        var sceduleData = postOpportunity[0]['schedule']; //
        try {
          if (sceduleData != null) {
            for (int k = 0; k < sceduleData.length; k++) {
              String day = sceduleData[k]['day'].toString();
              var hours = sceduleData[k]['hours'];
              //  file= getMediumImage(file);
              //HoursData hoursData;
              List<HoursData> hoursList = List();
              for (var item in hours) {
                hoursList.add(new HoursData(
                    timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
              }
              scheduleModelParam
                  .add(new ScheduleModelParam(day: day, hours: hoursList));
            }
          }
        } catch (e) {}

        List<String> otherCategoryList = List<String>();
        var otherCategoryMap = postOpportunity[0]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();

            otherCategoryList.add(name);
          }
        }

        List<String> otherCareerList = List<String>();
        var otherCareerMap = postOpportunity[0]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();

            otherCareerList.add(name);
          }
        }
        List<String> otherSubjectList = List<String>();
        var otherSubjectMap = postOpportunity[0]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();

            otherSubjectList.add(name);
          }
        }

        List<MainCategory> designationModelParam = List<MainCategory>();
        var designationData = postOpportunity[0]['category']; //
        try {
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new MainCategory(
                  name: name, categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}

        List<SubCategory> subjectModelParam = List<SubCategory>();
        var subjectData = postOpportunity[0]['subjects']; //
        try {
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(
                  new SubCategory(name: name, subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}

        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        var qualificationData = postOpportunity[0]['qualification']; //
        if (qualificationData != null) {
          try {
            for (int k = 0; k < qualificationData.length; k++) {
              String name = qualificationData[k]['name'].toString();
              String isOtherS = qualificationData[k]['isOther'].toString();
              String qualificationId =
                  qualificationData[k]['qualificationId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              qualificationModelParam.add(new QualificationModelParam(
                  name: name,
                  isOther: isOther,
                  qualificationId: int.parse(qualificationId)));
            }
          } catch (e) {}
        }

        opportunityModelForFeed = OpportunityModelForFeed(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            expiresOn,
            coverPicture,
            companyName,
            profilePicture,
            locationList,
            interestTypeList,
            ageList,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            actionType,
            url,
            groupIdAction,
            callingNumber,
            formId,
            linkUrlPosition,
            groupIsPublic,
            studentJoinId,
            fees,
            description,
            bio,
            "",
            //menteeSupport,
            "",
            //advisorSupportOffered,
            "",
            //projectArea,
            userImageModelParam,
            qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            category,
            name,
            "",
            //supportedOffer,
            opportunityCretedUserName,
            opportunityCretedUserImage,
            otherSubjectList,
            otherCategoryList,
            otherCareerList,
            timeZone,
            declineReason,
            partnerStatus,
            schoolCode);
      }

      if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
        print("difference day++++" + differenceDay.toString());
        userPostList.add(new UserPostModal(
            _id,
            feedId,
            postedBy,
            isLiked,
            dateTime,
            visibility,
            firstName,
            lastName,
            email,
            profilePicture,
            title,
            tagline,
            shareText,
            shareTime,
            postOwner,
            postOwnerFirstName,
            postOwnerLastName,
            postOwnerTitle,
            postOwnerProfilePicture,
            isLike,
            isCommented,
            postData,
            commentList,
            likesList,
            tagList,
            groupList,
            scopeList,
            false,
            TextEditingController(text: ""),
            lastActivityTime,
            lastActivityType,
            false,
            false,
            false,
            false,
            isReported,
            isOpportunity,
            postOwnerRoleId,
            roleId,
            postOwnerDeleted,
            opportunityModelForFeed,
            WebLinksModel("", "", "", ""),
            postedGroupName,
            postedGroupId,
            badge,
            gamificationPoints,
            likesCount,
            badgeImage,
            postOwnerBadge,
            postOwnerGamificationPoints,
            postOwnerBadgeImage,
            "0",
            feedStatus,
            schoolCode));
      }
      /* } catch (e) {
        print("HomeError+++++" + e.toString());
        e.toString();
      }*/
    }

    return userPostList;
  }

  static List<UserPostModal> parseHomeDataLoadMore(
      map, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();
    for (int i = 0; i < map.length; i++) {
      //  try {
      /*  DbHelper().insertTodo(map[i]['feedId'].toString(),
            jsonEncode("{_s__id_s_:_s_61c5c31df1543a6ffadff631_s_,_s_opportunityId_s_:0,_s_feedId_s_:10606,_s_groupId_s_:0,_s_post_s_:{_s_text_s_:_s_The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English._s_,_s_images_s_:[_s_sv_4376/image/1640350477882iZZdi.jpg_s_],_s_media_s_:_s__s_},_s_postedBy_s_:4376,_s_dateTime_s_:1640350492162,_s_visibility_s_:_s_Community_s_,_s_feedStatus_s_:_s_Active_s_,_s_comments_s_:[],_s_likes_s_:[],_s_tags_s_:[],_s_scope_s_:[],_s_firstName_s_:_s_LMS_s_,_s_lastName_s_:_s__s_,_s_roleId_s_:4,_s_email_s_:_s_SEpunv9Xa+44aCAJyG09go1julx64I5GBPE2Ickr+IY=_s_,_s_profilePicture_s_:_s__s_,_s_postOwnerRoleId_s_:0,_s_shareTime_s_:0,_s_lastActivityTime_s_:1640350492162,_s_lastActivityType_s_:_s_CreateFeed_s_,_s_postOpportunity_s_:[{}],_s_gamificationPoints_s_:0,_s_badge_s_:_s__s_,_s_groupIds_s_:[],_s_badgeImage_s_:_s__s_,_s_isReported_s_:false,_s_isHide_s_:false,_s_isOpportunity_s_:false,_s_groups_s_:[]}"));
    */
      DbHelper().insertTodo(map[i]['feedId'].toString(),
          jsonEncode(jsonEncode(map[i]).replaceAll("\"", "_s_").toString()));

      bool isLike = map[i]['isLiked'];
      int likesCount = map[i]['likesCount'];
      bool isCommented = false;
      String _id = map[i]['_id'].toString();
      String feedId = map[i]['feedId'].toString();
      bool isLiked = map[i]['isLiked'];
      String postedGroupId = map[i]['groupId'].toString();
      String postedGroupName = map[i]['groupName'].toString();
      String postedBy = map[i]['postedBy'].toString();
      String dateTime = map[i]['dateTime'].toString();
      String visibility = map[i]['visibility'].toString();
      String firstName = map[i]['firstName'].toString();
      String lastName = map[i]['lastName'].toString();
      String email = map[i]['email'].toString();
      String roleId = map[i]['roleId'].toString();
      String profilePicture = map[i]['profilePicture'].toString();
      String feedStatus = map[i]['feedStatus'].toString();
      String schoolCode = map[i]['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      String badgeImage = map[i]['badgeImage'].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = map[i]['badge'].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification = map[i]['gamificationPoints'].toString();
      int gamificationPoints;
      if (gamification == "null" || gamification == "") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      if (gamificationPoints == null) {
        gamificationPoints = 0;
      }

      String title = map[i]['title'].toString();
      String tagline = map[i]['tagline'].toString();
      String shareText = map[i]['shareText'].toString();
      String shareTime = map[i]['shareTime'].toString();
      String lastActivityTime = map[i]['lastActivityTime'].toString();
      String lastActivityType = map[i]['lastActivityType'].toString();

      String postOwner = map[i]['postOwner'].toString();
      if (postOwner == '0') {
        postOwner = 'null';
      }
      String postOwnerRoleId = map[i]['postOwnerRoleId'].toString();
      String isReported = map[i]['isReported'].toString();
      bool isOpportunity = map[i]['isOpportunity'];

      String postOwnerFirstName = map[i]['postOwnerFirstName'].toString();
      String postOwnerLastName = map[i]['postOwnerLastName'].toString();

      String postOwnerBadgeImage = map[i]['postOwnerBadgeImage'].toString();
      if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
        postOwnerBadgeImage = "";
      }
      String postOwnerBadge = map[i]['postOwnerBadge'].toString();
      if (postOwnerBadge == "null" || postOwnerBadge == "") {
        postOwnerBadge = "";
      }
      String postOwnerGamification =
          map[i]['postOwnerGamificationPoints'].toString();
      int postOwnerGamificationPoints;
      if (postOwnerGamification == "null" || postOwnerGamification == "") {
        postOwnerGamificationPoints = 0;
      } else {
        postOwnerGamificationPoints = int.parse(postOwnerGamification);
      }
      if (postOwnerGamificationPoints == null) {
        postOwnerGamificationPoints = 0;
      }

      bool postOwnerDeleted = false;
      try {
        postOwnerDeleted = map[i]['postOwnerDeleted'] == null
            ? false
            : map[i]['postOwnerDeleted'];
      } catch (e) {
        postOwnerDeleted = false;
      }
      String postOwnerTitle = map[i]['postOwnerTitle'].toString();
      String postOwnerProfilePicture =
          map[i]['postOwnerProfilePicture'].toString();
      //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
      DateTime currentDate = DateTime.now();
      if (dateTime != "null") {
        int d = int.tryParse(dateTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        print("firstName++" + firstName.toString());
        print("long++" + d.toString());

        dateTime = getTimeValue(date, currentDate);
      }
      if (shareTime != "null") {
        int d = int.tryParse(shareTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        shareTime = getTimeValue(date, currentDate);
      }

      var imageMap = map[i]['post']['images'];
      var assetMap = map[i]['post']['assets'];
      String text = map[i]['post']['text'].toString();
      String media = map[i]['post']['media'].toString();
      List<String> imageList = List<String>();
      if (imageMap != null) {
        for (int i = 0; i < imageMap.length; i++) {
          String image = imageMap[i];
          // image = getMediumImage(image);
          if (image != "") imageList.add(image);
        }
      }
      List<AssetIV> assetList = List<AssetIV>();
      if (assetMap != null) {
        for (int i = 0; i < assetMap.length; i++) {
          String image = assetMap[i]["url"];
          String type = assetMap[i]["type"];
          // image = getMediumImage(image);
          if (image != "") assetList.add(AssetIV(file: image, type: type));
        }
      }

      String _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage;

      try {
        _metaUrl = map[i]['post']['metaData']['url'];
        _metaSource = map[i]['post']['metaData']['source'];
        _metaHeight = map[i]['post']['metaData']['height'];
        _metaWidth = map[i]['post']['metaData']['width'];
        _metaTitle = map[i]['post']['metaData']['title'];
        _metaDescription = map[i]['post']['metaData']['description'];
        _metaImage = map[i]['post']['metaData']['image'];
      } catch (e) {
        _metaUrl = "";
        _metaSource = "";
        _metaHeight = "";
        _metaWidth = "";
        _metaTitle = "";
        _metaDescription = "";
        _metaImage = "";
      }

      PostData postData = PostData(
          imageList,
          assetList,
          text,
          media,
          _metaUrl,
          _metaSource,
          _metaHeight,
          _metaWidth,
          _metaTitle,
          _metaDescription,
          _metaImage);
      print("sss commetns 2");
      List<CommentData> commentList = List();
      var commentMap = map[i]['comments'];
      if (commentMap != null) {
        for (int j = (commentMap.length - 1); j >= 0; j--) {
          print("sss commetns 2 ${commentMap[j]['_id']}");
          String commentId = commentMap[j]['_id'].toString();
          String comment = commentMap[j]['comment'].toString();
          String commentedBy = commentMap[j]['commentedBy'].toString();
          String dateTime = commentMap[j]['dateTime'].toString();
          String profilePicture = commentMap[j]['profilePicture'].toString();
          String name = commentMap[j]['name'].toString();
          String title = ""; //commentMap[j]['title'].toString();
          String roleId = ""; // commentMap[j]['commentedByRole'].toString();
          String userId = ""; //commentMap[j]['userId'].toString();
          var likesMap = []; //commentMap[j]['likes'];

          String badgeImage = commentMap[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = commentMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = ""; //
          // commentMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          DateTime currentDate = DateTime.now();
          if (dateTime != "null") {
            int d = int.tryParse(dateTime);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            dateTime = getTimeValue(date, currentDate);
          }
          //  profilePicture = getSmallImage(profilePicture);

          List<Likes> likesList = List();
          bool isCommentLike = false;
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();

            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['commentRoleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();

            String profilePicture = likesMap[k]['profilePicture'].toString();
            // profilePicture = getSmallImage(profilePicture);
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            if (userId == userIdPref && roleId == userRoleID) {
              isCommentLike = true;
            }
          }
          commentList.add(new CommentData(
              commentId,
              comment,
              commentedBy,
              dateTime,
              profilePicture,
              name,
              title,
              userId,
              likesList,
              isCommentLike,
              roleId,
              badge,
              gamificationPoints,
              badgeImage,
              true));
          if (commentedBy == userIdPref && roleId == userRoleID) {
            isCommented = true;
          }
        }
      }

      List<Likes> likesList = List();
      var likesMap = map[i]['likes'];
      if (likesMap != null) {
        for (int k = 0; k < likesMap.length; k++) {
          String userId = likesMap[k]['userId'].toString();
          String name = likesMap[k]['name'].toString();
          String status = likesMap[k]['status'].toString();
          String roleId = likesMap[k]['roleId'].toString();
          String statusValue = likesMap[k]['statusValue'].toString();
          String profilePicture = likesMap[k]['profilePicture'].toString();
          String title = likesMap[k]['title'].toString();

          String badgeImage = likesMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = likesMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = likesMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          likesList.add(new Likes(userId, name, profilePicture, title, status,
              statusValue, roleId, badge, gamificationPoints, badgeImage));
          // if (userId == userIdPref && roleId == userRoleID) {
          //   isLike = true;
          // }
        }
      }
      List<Tags> tagList = List();
      try {
        var tagMap = map[i]['tags'];

        for (int k = 0; k < tagMap.length; k++) {
          String userId = tagMap[k]['userId'].toString();
          String name = tagMap[k]['name'].toString();
          String profilePicture = tagMap[k]['profilePicture'].toString();
          String title = tagMap[k]['title'].toString();
          String roleId = tagMap[k]['roleId'].toString();
          String badgeImage = tagMap[k]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = tagMap[k]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = tagMap[k]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          tagList.add(new Tags(userId, name, profilePicture, title, roleId,
              badge, gamificationPoints, badgeImage));
        }
      } catch (e) {}

      //------------------- Apurva added Group list start-------------------

      List<Groups> groupList = List();
      try {
        var groupMap = map[i]['groups'];

        for (int k = 0; k < groupMap.length; k++) {
          String groupId = groupMap[k]['groupId'].toString();
          String groupName = groupMap[k]['groupName'].toString();
          String groupImage = groupMap[k]['groupImage'].toString();

          groupList.add(new Groups(groupId, groupName, groupImage));
        }
      } catch (e) {}
      //------------------- Apurva added Group list end-------------------

      var scopeMap = map[i]['scope'];

      List<ScopeModel> scopeList = List<ScopeModel>();
      if (scopeMap != null) {
        for (int k = 0; k < scopeMap.length; k++) {
          String userId = scopeMap[k]['userId'].toString();
          String roleId = scopeMap[k]['roleId'].toString();
          scopeList.add(ScopeModel(userId, roleId));
        }
      }
      String opportunityCretedUserName = map[i]['firstName'].toString() +
          " " +
          map[i]['lastName'].toString().replaceAll("null", "");

      String opportunityCretedUserImage = map[i]['profilePicture'].toString();
      OpportunityModelForFeed opportunityModelForFeed;
      int differenceDay = 0;
      print("isOpportunity+++++" + isOpportunity.toString());
      if (isOpportunity) {
        var postOpportunity = map[i]["postOpportunity"];
        String opportunityId = postOpportunity[0]["opportunityId"].toString();
        String userId = postOpportunity[0]["userId"].toString();
        String roleId = postOpportunity[0]["roleId"].toString();
        String jobTitle = postOpportunity[0]["jobTitle"].toString();
        String timeZone = postOpportunity[0]["timeZone"].toString();
        String jobType = postOpportunity[0]["jobType"].toString();
        String schoolCode = postOpportunity[0]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String jobLocation = postOpportunity[0]["jobLocation"].toString();
        String project = postOpportunity[0]["project"].toString();
        String duration = postOpportunity[0]["duration"].toString();
        String status = postOpportunity[0]["status"].toString();
        String fromDate = postOpportunity[0]["fromDate"].toString();
        String toDate = postOpportunity[0]["toDate"].toString();
        String groupId = postOpportunity[0]["groupId"].toString();
        String targetAudience = postOpportunity[0]["targetAudience"].toString();
        String title = postOpportunity[0]["title"].toString();
        String gender = postOpportunity[0]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = postOpportunity[0]["companyId"].toString();
        String offerId = postOpportunity[0]["offerId"].toString();
        String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
        String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
        String expiresOn = postOpportunity[0]["expiresOn"].toString();
        String coverPicture = postOpportunity[0]["coverPicture"].toString();
        String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
        String companyName = postOpportunity[0]["companyName"].toString();
        String profilePicture = postOpportunity[0]["profilePicture"].toString();
        String category = postOpportunity[0]["category"].toString();
        //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
        String name = postOpportunity[0]["name"].toString();
        String declineReason = postOpportunity[0]["declineReason"].toString();
        String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
        String url, groupIdAction, callingNumber, formId, linkUrlPosition;
        bool groupIsPublic = true;
        String actionType =
            postOpportunity[0]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          url = postOpportunity[0]['callToAction'][0]['url'].toString();
          linkUrlPosition =
              postOpportunity[0]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction =
              postOpportunity[0]['callToAction'][0]['groupId'].toString();
          groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
          print("groupIsPublic+++++" + groupIsPublic.toString());
          if (groupIsPublic == null) {
            groupIsPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber =
              postOpportunity[0]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        print("shubh+++" + "action" + actionType);

        List<Address> locationList = List<Address>();
        var locationMap = postOpportunity[0]['location'];
        if (locationMap != null) {
          for (int i = 0; i < locationMap.length; i++) {
            String zipcode = locationMap[i]['zipcode'].toString();
            String city = locationMap[i]['city'].toString();
            String country = locationMap[i]['country'].toString();
            String state = locationMap[i]['state'].toString();
            String name = locationMap[i]['name'].toString();
            String target = locationMap[i]['target'].toString();
            locationList
                .add(Address(name, "", city, state, country, zipcode, target));
          }
        }

        List<AgeModel> ageList = List<AgeModel>();
        var ageMao = postOpportunity[0]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          String to = ageMao[k]['to'].toString();
          String from = ageMao[k]['from'].toString();
          //  file= getMediumImage(file);

          ageList.add(new AgeModel(to, from));
        }

        List<IntrestModel> interestTypeList = List<IntrestModel>();
        try {
          var interestTypeModel = postOpportunity[0]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
            //  file= getMediumImage(file);

            interestTypeList.add(new IntrestModel(id, name));
          }
        } catch (e) {}

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = postOpportunity[0]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        if (expiresOn != "null") {
          int d = int.tryParse(expiresOn);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          differenceDay = currentDate.difference(date).inDays;
          print("Difference between++++" + differenceDay.toString());
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        var userImageData = postOpportunity[0]['userImage']; //
        try {
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
        String fees = postOpportunity[0]["fees"].toString();
        String description = postOpportunity[0]["description"].toString();
        String bio = postOpportunity[0]["bio"].toString();
        //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
        //String projectArea = postOpportunity[0]["projectArea"].toString();
        String qualification = postOpportunity[0]["qualification"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        var sceduleData = postOpportunity[0]['schedule']; //
        try {
          if (sceduleData != null) {
            for (int k = 0; k < sceduleData.length; k++) {
              String day = sceduleData[k]['day'].toString();
              var hours = sceduleData[k]['hours'];
              //  file= getMediumImage(file);
              //HoursData hoursData;
              List<HoursData> hoursList = List();
              for (var item in hours) {
                hoursList.add(new HoursData(
                    timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
              }
              scheduleModelParam
                  .add(new ScheduleModelParam(day: day, hours: hoursList));
            }
          }
        } catch (e) {}

        List<String> otherCategoryList = List<String>();
        var otherCategoryMap = postOpportunity[0]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();

            otherCategoryList.add(name);
          }
        }

        List<String> otherCareerList = List<String>();
        var otherCareerMap = postOpportunity[0]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();

            otherCareerList.add(name);
          }
        }
        List<String> otherSubjectList = List<String>();
        var otherSubjectMap = postOpportunity[0]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();

            otherSubjectList.add(name);
          }
        }

        List<MainCategory> designationModelParam = List<MainCategory>();
        var designationData = postOpportunity[0]['category']; //
        try {
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new MainCategory(
                  name: name, categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}

        List<SubCategory> subjectModelParam = List<SubCategory>();
        var subjectData = postOpportunity[0]['subjects']; //
        try {
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(
                  new SubCategory(name: name, subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}

        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        var qualificationData = postOpportunity[0]['qualification']; //
        if (qualificationData != null) {
          try {
            for (int k = 0; k < qualificationData.length; k++) {
              String name = qualificationData[k]['name'].toString();
              String isOtherS = qualificationData[k]['isOther'].toString();
              String qualificationId =
                  qualificationData[k]['qualificationId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              qualificationModelParam.add(new QualificationModelParam(
                  name: name,
                  isOther: isOther,
                  qualificationId: int.parse(qualificationId)));
            }
          } catch (e) {}
        }

        opportunityModelForFeed = OpportunityModelForFeed(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            expiresOn,
            coverPicture,
            companyName,
            profilePicture,
            locationList,
            interestTypeList,
            ageList,
            assestList,
            assestVideoAndImage,
            videoList,
            docList,
            mediaList,
            googleLinkList,
            actionType,
            url,
            groupIdAction,
            callingNumber,
            formId,
            linkUrlPosition,
            groupIsPublic,
            studentJoinId,
            fees,
            description,
            bio,
            "",
            //menteeSupport,
            "",
            //advisorSupportOffered,
            "",
            //projectArea,
            userImageModelParam,
            qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            category,
            name,
            "",
            //supportedOffer,
            opportunityCretedUserName,
            opportunityCretedUserImage,
            otherSubjectList,
            otherCategoryList,
            otherCareerList,
            timeZone,
            declineReason,
            partnerStatus,
            schoolCode);
      }

      if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
        print("difference day++++" + differenceDay.toString());
        userPostList.add(new UserPostModal(
            _id,
            feedId,
            postedBy,
            isLiked,
            dateTime,
            visibility,
            firstName,
            lastName,
            email,
            profilePicture,
            title,
            tagline,
            shareText,
            shareTime,
            postOwner,
            postOwnerFirstName,
            postOwnerLastName,
            postOwnerTitle,
            postOwnerProfilePicture,
            isLike,
            isCommented,
            postData,
            commentList,
            likesList,
            tagList,
            groupList,
            scopeList,
            false,
            TextEditingController(text: ""),
            lastActivityTime,
            lastActivityType,
            false,
            false,
            false,
            false,
            isReported,
            isOpportunity,
            postOwnerRoleId,
            roleId,
            postOwnerDeleted,
            opportunityModelForFeed,
            WebLinksModel("", "", "", ""),
            postedGroupName,
            postedGroupId,
            badge,
            gamificationPoints,
            likesCount,
            badgeImage,
            postOwnerBadge,
            postOwnerGamificationPoints,
            postOwnerBadgeImage,
            "0",
            feedStatus,
            schoolCode));
      }
      /* } catch (e) {
        print("HomeError+++++" + e.toString());
        e.toString();
      }*/
    }

    return userPostList;
  }

  static List<UserPostModal> parseHomeData(map, userIdPref, userRoleID) {
    List<UserPostModal> userPostList = List<UserPostModal>();
    for (int i = 0; i < map.length; i++) {
      try {
        bool isLike = map[i]['isLiked'];
        int likesCount = map[i]['likesCount'];
        bool isCommented = false;
        String _id = map[i]['_id'].toString();
        String feedId = map[i]['feedId'].toString();
        bool isLiked = map[i]['isLiked'];
        String postedGroupId = map[i]['groupId'].toString();
        String postedGroupName = map[i]['groupName'].toString();
        String postedBy = map[i]['postedBy'].toString();
        String dateTime = map[i]['dateTime'].toString();
        String visibility = map[i]['visibility'].toString();
        String firstName = map[i]['firstName'].toString();
        String lastName = map[i]['lastName'].toString();
        String email = map[i]['email'].toString();
        String roleId = map[i]['roleId'].toString();
        String profilePicture = map[i]['profilePicture'].toString();
        String feedStatus = map[i]['feedStatus'].toString();

        String badgeImage = map[i]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map[i]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = map[i]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

//postOwnerRoleId ,roleId
        // profilePicture = getSmallImage(profilePicture);

        String title = map[i]['title'].toString();
        String tagline = map[i]['tagline'].toString();
        String shareText = map[i]['shareText'].toString();
        String shareTime = map[i]['shareTime'].toString();
        String lastActivityTime = map[i]['lastActivityTime'].toString();
        String lastActivityType = map[i]['lastActivityType'].toString();
        String schoolCode = map[i]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String postOwner = map[i]['postOwner'].toString();
        if (postOwner == '0') {
          postOwner = 'null';
        }
        String postOwnerRoleId = map[i]['postOwnerRoleId'].toString();
        String isReported = map[i]['isReported'].toString();
        bool isOpportunity = map[i]['isOpportunity'];

        String postOwnerFirstName = map[i]['postOwnerFirstName'].toString();
        String postOwnerLastName = map[i]['postOwnerLastName'].toString();

        String postOwnerBadgeImage = map[i]['postOwnerBadgeImage'].toString();
        if (postOwnerBadgeImage == "null" || postOwnerBadgeImage == "") {
          postOwnerBadgeImage = "";
        }
        String postOwnerBadge = map[i]['postOwnerBadge'].toString();
        if (postOwnerBadge == "null" || postOwnerBadge == "") {
          postOwnerBadge = "";
        }
        String postOwnerGamification =
            map[i]['postOwnerGamificationPoints'].toString();
        int postOwnerGamificationPoints;
        if (postOwnerGamification == "null" || postOwnerGamification == "") {
          postOwnerGamificationPoints = 0;
        } else {
          postOwnerGamificationPoints = int.parse(postOwnerGamification);
        }
        if (postOwnerGamificationPoints == null) {
          postOwnerGamificationPoints = 0;
        }

        bool postOwnerDeleted = false;
        try {
          postOwnerDeleted = map[i]['postOwnerDeleted'] == null
              ? false
              : map[i]['postOwnerDeleted'];
        } catch (e) {
          postOwnerDeleted = false;
        }
        String postOwnerTitle = map[i]['postOwnerTitle'].toString();
        String postOwnerProfilePicture =
            map[i]['postOwnerProfilePicture'].toString();
        //   postOwnerProfilePicture = getSmallImage(postOwnerProfilePicture);
        DateTime currentDate = DateTime.now();
        if (dateTime != "null") {
          int d = int.tryParse(dateTime);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          print("firstName++" + firstName.toString());
          print("long++" + d.toString());

          dateTime = getTimeValue(date, currentDate);

          /*var differenceDay = currentDate.difference(date).inDays;
          final differenceHours = currentDate.difference(date).inHours;
          final differenceMinutes = currentDate.difference(date).inMinutes;
          final differenceSeconds = currentDate.difference(date).inSeconds;
          if (differenceDay != 0) {
            if (differenceDay == 1) {
              dateTime = "$differenceDay Day ";
            } else {
              dateTime = "$differenceDay Days ";
            }
          } else if (differenceHours != 0) {
            if (differenceHours == 1) {
              dateTime = "$differenceHours Hour ";
            } else {
              dateTime = "$differenceHours Hours ";
            }
          } else if (differenceMinutes != 0) {
            if (differenceMinutes == 1) {
              dateTime = "$differenceMinutes Minute ";
            } else {
              dateTime = "$differenceMinutes Minutes ";
            }
          } else {
            dateTime = "few seconds ";
          }*/
        }
        if (shareTime != "null") {
          int d = int.tryParse(shareTime);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

          shareTime = getTimeValue(date, currentDate);

          /*final differenceDay = currentDate.difference(date).inDays;
          final differenceHours = currentDate.difference(date).inHours;
          final differenceMinutes = currentDate.difference(date).inMinutes;
          final differenceSeconds = currentDate.difference(date).inSeconds;
          if (differenceDay != 0) {
            if (differenceDay == 1) {
              shareTime = "$differenceDay Day ";
            } else {
              shareTime = "$differenceDay Days ";
            }
          } else if (differenceHours != 0) {
            if (differenceHours == 1) {
              shareTime = "$differenceHours Hour ";
            } else {
              shareTime = "$differenceHours Hours ";
            }
          } else if (differenceMinutes != 0) {
            if (differenceMinutes == 1) {
              shareTime = "$differenceMinutes Minute ";
            } else {
              shareTime = "$differenceMinutes Minutes ";
            }
          } else {
            shareTime = "few seconds ";
          }*/
        }

        var imageMap = map[i]['post']['images'];
        var assetMap = map[i]['post']['assets'];
        String text = map[i]['post']['text'].toString();
        String media = map[i]['post']['media'].toString();
        List<String> imageList = List<String>();
        if (imageMap != null) {
          for (int i = 0; i < imageMap.length; i++) {
            String image = imageMap[i];
            // image = getMediumImage(image);
            if (image != "") imageList.add(image);
          }
        }
        List<AssetIV> assetList = List<AssetIV>();

        if (assetMap != null) {
          for (int i = 0; i < assetMap.length; i++) {
            String image = assetMap[i]["url"];
            String type = assetMap[i]["type"];
            // image = getMediumImage(image);
            if (image != "") assetList.add(AssetIV(file: image, type: type));
          }
        }

        String _metaUrl,
            _metaSource,
            _metaHeight,
            _metaWidth,
            _metaTitle,
            _metaDescription,
            _metaImage;

        try {
          _metaUrl = map[i]['post']['metaData']['url'];
          _metaSource = map[i]['post']['metaData']['source'];
          _metaHeight = map[i]['post']['metaData']['height'];
          _metaWidth = map[i]['post']['metaData']['width'];
          _metaTitle = map[i]['post']['metaData']['title'];
          _metaDescription = map[i]['post']['metaData']['description'];
          _metaImage = map[i]['post']['metaData']['image'];
        } catch (e) {
          _metaUrl = "";
          _metaSource = "";
          _metaHeight = "";
          _metaWidth = "";
          _metaTitle = "";
          _metaDescription = "";
          _metaImage = "";
        }

        PostData postData = PostData(
            imageList,
            assetList,
            text,
            media,
            _metaUrl,
            _metaSource,
            _metaHeight,
            _metaWidth,
            _metaTitle,
            _metaDescription,
            _metaImage);
        print("sss commetns 3");
        List<CommentData> commentList = List();
        var commentMap = map[i]['comments'];
        if (commentMap != null) {
          for (int j = (commentMap.length - 1); j >= 0; j--) {
            String commentId = commentMap[j]['_id'].toString();
            String comment = commentMap[j]['comment'].toString();
            String commentedBy = commentMap[j]['commentedBy'].toString();
            String dateTime = commentMap[j]['dateTime'].toString();
            String profilePicture = commentMap[j]['profilePicture'].toString();
            String name = commentMap[j]['name'].toString();
            String title = ""; //commentMap[j]['title'].toString();
            String roleId = ""; //commentMap[j]['commentedByRole'].toString();
            String userId = ""; //commentMap[j]['userId'].toString();
            var likesMap = []; //commentMap[j]['likes'];

            String badgeImage = commentMap[j]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = commentMap[j]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = ""; //
            // commentMap[j]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            DateTime currentDate = DateTime.now();
            if (dateTime != "null") {
              int d = int.tryParse(dateTime);
              DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

              dateTime = getTimeValue(date, currentDate);

              /*final differenceDay = currentDate.difference(date).inDays;
              final differenceHours = currentDate.difference(date).inHours;
              final differenceMinutes = currentDate.difference(date).inMinutes;
              final differenceSeconds = currentDate.difference(date).inSeconds;

              if (differenceDay != 0) {
                if (differenceDay == 1) {
                  dateTime = "$differenceDay Day ";
                } else {
                  dateTime = "$differenceDay Days ";
                }
              } else if (differenceHours != 0) {
                if (differenceHours == 1) {
                  dateTime = "$differenceHours Hour ";
                } else {
                  dateTime = "$differenceHours Hours ";
                }
              } else if (differenceMinutes != 0) {
                if (differenceMinutes == 1) {
                  dateTime = "$differenceMinutes Minute ";
                } else {
                  dateTime = "$differenceMinutes Minutes ";
                }
              } else {
                dateTime = "few seconds ";
              }*/
            }
            //  profilePicture = getSmallImage(profilePicture);

            List<Likes> likesList = List();
            bool isCommentLike = false;
            for (int k = 0; k < likesMap.length; k++) {
              String userId = likesMap[k]['userId'].toString();
              String name = likesMap[k]['name'].toString();

              String status = likesMap[k]['status'].toString();
              String roleId = likesMap[k]['commentRoleId'].toString();
              String statusValue = likesMap[k]['statusValue'].toString();

              String profilePicture = likesMap[k]['profilePicture'].toString();
              // profilePicture = getSmallImage(profilePicture);
              String title = likesMap[k]['title'].toString();

              String badgeImage = likesMap[k]['badgeImage'].toString();
              if (badgeImage == "null" || badgeImage == "") {
                badgeImage = "";
              }
              String badge = likesMap[k]['badge'].toString();
              if (badge == "null" || badge == "") {
                badge = "";
              }
              String gamification =
                  likesMap[k]['gamificationPoints'].toString();
              int gamificationPoints;
              if (gamification == "null" || gamification == "") {
                gamificationPoints = 0;
              } else {
                gamificationPoints = int.parse(gamification);
              }
              if (gamificationPoints == null) {
                gamificationPoints = 0;
              }

              likesList.add(new Likes(
                  userId,
                  name,
                  profilePicture,
                  title,
                  status,
                  statusValue,
                  roleId,
                  badge,
                  gamificationPoints,
                  badgeImage));
              if (userId == userIdPref && roleId == userRoleID) {
                isCommentLike = true;
              }
            }
            commentList.add(new CommentData(
                commentId,
                comment,
                commentedBy,
                dateTime,
                profilePicture,
                name,
                title,
                userId,
                likesList,
                isCommentLike,
                roleId,
                badge,
                gamificationPoints,
                badgeImage,
                true));
            if (commentedBy == userIdPref && roleId == userRoleID) {
              isCommented = true;
            }
          }
        }

        List<Likes> likesList = List();
        var likesMap = map[i]['likes'];
        if (likesMap != null) {
          for (int k = 0; k < likesMap.length; k++) {
            String userId = likesMap[k]['userId'].toString();
            String name = likesMap[k]['name'].toString();
            String status = likesMap[k]['status'].toString();
            String roleId = likesMap[k]['roleId'].toString();
            String statusValue = likesMap[k]['statusValue'].toString();
            String profilePicture = likesMap[k]['profilePicture'].toString();
            String title = likesMap[k]['title'].toString();

            String badgeImage = likesMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = likesMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = likesMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            likesList.add(new Likes(userId, name, profilePicture, title, status,
                statusValue, roleId, badge, gamificationPoints, badgeImage));
            // if (userId == userIdPref && roleId == userRoleID) {
            //   isLike = true;
            // }
          }
        }
        List<Tags> tagList = List();
        try {
          var tagMap = map[i]['tags'];

          for (int k = 0; k < tagMap.length; k++) {
            String userId = tagMap[k]['userId'].toString();
            String name = tagMap[k]['name'].toString();
            String profilePicture = tagMap[k]['profilePicture'].toString();
            String title = tagMap[k]['title'].toString();
            String roleId = tagMap[k]['roleId'].toString();
            String badgeImage = tagMap[k]['badgeImage'].toString();
            if (badgeImage == "null" || badgeImage == "") {
              badgeImage = "";
            }
            String badge = tagMap[k]['badge'].toString();
            if (badge == "null" || badge == "") {
              badge = "";
            }
            String gamification = tagMap[k]['gamificationPoints'].toString();
            int gamificationPoints;
            if (gamification == "null" || gamification == "") {
              gamificationPoints = 0;
            } else {
              gamificationPoints = int.parse(gamification);
            }
            if (gamificationPoints == null) {
              gamificationPoints = 0;
            }

            tagList.add(new Tags(userId, name, profilePicture, title, roleId,
                badge, gamificationPoints, badgeImage));
          }
        } catch (e) {}

        //------------------- Apurva added Group list start-------------------

        List<Groups> groupList = List();
        try {
          var groupMap = map[i]['groups'];

          for (int k = 0; k < groupMap.length; k++) {
            String groupId = groupMap[k]['groupId'].toString();
            String groupName = groupMap[k]['groupName'].toString();
            String groupImage = groupMap[k]['groupImage'].toString();

            groupList.add(new Groups(groupId, groupName, groupImage));
          }
        } catch (e) {}
        //------------------- Apurva added Group list end-------------------

        var scopeMap = map[i]['scope'];

        List<ScopeModel> scopeList = List<ScopeModel>();
        if (scopeMap != null) {
          for (int k = 0; k < scopeMap.length; k++) {
            String userId = scopeMap[k]['userId'].toString();
            String roleId = scopeMap[k]['roleId'].toString();
            scopeList.add(ScopeModel(userId, roleId));
          }
        }
        String opportunityCretedUserName = map[i]['firstName'].toString() +
            " " +
            map[i]['lastName'].toString().replaceAll("null", "");

        String opportunityCretedUserImage = map[i]['profilePicture'].toString();
        OpportunityModelForFeed opportunityModelForFeed;
        int differenceDay = 0;
        print("isOpportunity+++++" + isOpportunity.toString());
        if (isOpportunity) {
          var postOpportunity = map[i]["postOpportunity"];
          String opportunityId = postOpportunity[0]["opportunityId"].toString();
          String userId = postOpportunity[0]["userId"].toString();
          String roleId = postOpportunity[0]["roleId"].toString();
          String jobTitle = postOpportunity[0]["jobTitle"].toString();
          String schoolCode = postOpportunity[0]['schoolCode'].toString();
          if (schoolCode == "null" || schoolCode == "") {
            schoolCode = "";
          }
          String timeZone = postOpportunity[0]["timeZone"].toString();
          String jobType = postOpportunity[0]["jobType"].toString();
          String jobLocation = postOpportunity[0]["jobLocation"].toString();
          String project = postOpportunity[0]["project"].toString();
          String duration = postOpportunity[0]["duration"].toString();
          String status = postOpportunity[0]["status"].toString();
          String fromDate = postOpportunity[0]["fromDate"].toString();
          String toDate = postOpportunity[0]["toDate"].toString();
          String groupId = postOpportunity[0]["groupId"].toString();
          String targetAudience =
              postOpportunity[0]["targetAudience"].toString();
          String title = postOpportunity[0]["title"].toString();
          String gender = postOpportunity[0]["gender"].toString();
          if (gender == "Non-binary" || gender == "NonBinary") {
            gender = "Non-Binary";
          }
          String companyId = postOpportunity[0]["companyId"].toString();
          String offerId = postOpportunity[0]["offerId"].toString();
          String serviceTitle = postOpportunity[0]["serviceTitle"].toString();
          String serviceDesc = postOpportunity[0]["serviceDesc"].toString();
          String expiresOn = postOpportunity[0]["expiresOn"].toString();
          String coverPicture = postOpportunity[0]["coverPicture"].toString();
          String studentJoinId = postOpportunity[0]["studentJoinId"].toString();
          String companyName = postOpportunity[0]["companyName"].toString();
          String profilePicture =
              postOpportunity[0]["profilePicture"].toString();
          String category = postOpportunity[0]["category"].toString();
          //String supportedOffer = postOpportunity[0]["supportedOffer"].toString();
          String name = postOpportunity[0]["name"].toString();
          String declineReason = postOpportunity[0]["declineReason"].toString();
          String partnerStatus = postOpportunity[0]["partnerStatus"].toString();
          String url, groupIdAction, callingNumber, formId, linkUrlPosition;
          bool groupIsPublic = true;
          String actionType =
              postOpportunity[0]['callToAction'][0]['id'].toString();
          if (actionType == Constant.LINK_URL) {
            url = postOpportunity[0]['callToAction'][0]['url'].toString();
            linkUrlPosition =
                postOpportunity[0]['callToAction'][0]['position'].toString();
            print("action+++" + url);
          } else if (actionType == Constant.JOIN_GROUP) {
            groupIdAction =
                postOpportunity[0]['callToAction'][0]['groupId'].toString();
            groupIsPublic = postOpportunity[0]['callToAction'][0]['isPublic'];
            print("groupIsPublic+++++" + groupIsPublic.toString());
            if (groupIsPublic == null) {
              groupIsPublic = true;
            }
            print("action+++jpoinGroup+++" + groupIdAction);
          } else if (actionType == Constant.CALL_NOW) {
            callingNumber =
                postOpportunity[0]['callToAction'][0]['number'].toString();
            print("action+++" + callingNumber);
          } else if (actionType == Constant.INQUIRE_NOW) {
            formId = postOpportunity[0]['callToAction'][0]['formId'].toString();
            print("action+++" + formId);
          }

          print("shubh+++" + "action" + actionType);

          List<Address> locationList = List<Address>();
          var locationMap = postOpportunity[0]['location'];
          if (locationMap != null) {
            for (int i = 0; i < locationMap.length; i++) {
              String zipcode = locationMap[i]['zipcode'].toString();
              String city = locationMap[i]['city'].toString();
              String country = locationMap[i]['country'].toString();
              String state = locationMap[i]['state'].toString();
              String name = locationMap[i]['name'].toString();
              String target = locationMap[i]['target'].toString();
              locationList.add(
                  Address(name, "", city, state, country, zipcode, target));
            }
          }

          List<AgeModel> ageList = List<AgeModel>();
          var ageMao = postOpportunity[0]['age'];
          for (int k = 0; k < ageMao.length; k++) {
            String to = ageMao[k]['to'].toString();
            String from = ageMao[k]['from'].toString();
            //  file= getMediumImage(file);

            ageList.add(new AgeModel(to, from));
          }

          List<IntrestModel> interestTypeList = List<IntrestModel>();
          try {
            var interestTypeModel = postOpportunity[0]['interestType'];
            for (int k = 0; k < interestTypeModel.length; k++) {
              String id = interestTypeModel[k]['id'].toString();
              String name = interestTypeModel[k]['name'].toString();
              //  file= getMediumImage(file);

              interestTypeList.add(new IntrestModel(id, name));
            }
          } catch (e) {}

          List<Assest> assestList = List<Assest>();
          List<Assest> assestVideoAndImage = List<Assest>();
          List<Assest> videoList = List<Assest>();
          List<Assest> docList = List<Assest>();
          List<Assest> googleLinkList = List<Assest>();
          List<Assest> mediaList = List<Assest>();

          var asetMap = postOpportunity[0]['asset'];
          if (asetMap != null) {
            for (int k = 0; k < asetMap.length; k++) {
              String type = asetMap[k]['type'].toString();
              String tag = asetMap[k]['tag'].toString();
              String file = asetMap[k]['file'].toString();
              String label = asetMap[k]['label'].toString();
              //  file= getMediumImage(file);

              assestList.add(new Assest(type, tag, file, label, false));

              if (type == "image") {
                mediaList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "video") {
                videoList.add(new Assest(type, tag, file, label, false));
                assestVideoAndImage
                    .add(new Assest(type, tag, file, label, false));
              } else if (type == "doc") {
                docList.add(new Assest(type, tag, file, label, false));
              } else if (type == "google") {
                googleLinkList.add(new Assest(type, tag, file, label, false));
              }
            }
          }

          if (expiresOn != "null") {
            int d = int.tryParse(expiresOn);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

            differenceDay = currentDate.difference(date).inDays;
            print("Difference between++++" + differenceDay.toString());
          }

          List<UserImageModelParam> userImageModelParam =
              List<UserImageModelParam>();
          var userImageData = postOpportunity[0]['userImage']; //
          try {
            if (userImageData != null) {
              for (int k = 0; k < userImageData.length; k++) {
                String file = userImageData[k]['file'].toString();
                userImageModelParam.add(new UserImageModelParam(file: file));
              }
            }
          } catch (e) {}

          //String menteeSupport = postOpportunity[0]["supportedOffer"].toString();
          String fees = postOpportunity[0]["fees"].toString();
          String description = postOpportunity[0]["description"].toString();
          String bio = postOpportunity[0]["bio"].toString();
          //String advisorSupportOffered = postOpportunity[0]["supportedOffer"].toString();
          //String projectArea = postOpportunity[0]["projectArea"].toString();
          String qualification = postOpportunity[0]["qualification"].toString();

          List<ScheduleModelParam> scheduleModelParam =
              List<ScheduleModelParam>();
          var sceduleData = postOpportunity[0]['schedule']; //
          try {
            if (sceduleData != null) {
              for (int k = 0; k < sceduleData.length; k++) {
                String day = sceduleData[k]['day'].toString();
                var hours = sceduleData[k]['hours'];
                //  file= getMediumImage(file);
                //HoursData hoursData;
                List<HoursData> hoursList = List();
                for (var item in hours) {
                  hoursList.add(new HoursData(
                      timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
                }
                scheduleModelParam
                    .add(new ScheduleModelParam(day: day, hours: hoursList));
              }
            }
          } catch (e) {}

          List<String> otherCategoryList = List<String>();
          var otherCategoryMap = postOpportunity[0]['otherCategory'];
          if (otherCategoryMap != null) {
            for (int i = 0; i < otherCategoryMap.length; i++) {
              String name = otherCategoryMap[i]['name'].toString();

              otherCategoryList.add(name);
            }
          }

          List<String> otherCareerList = List<String>();
          var otherCareerMap = postOpportunity[0]['otherCareer'];
          if (otherCareerMap != null) {
            for (int i = 0; i < otherCareerMap.length; i++) {
              String name = otherCareerMap[i]['name'].toString();

              otherCareerList.add(name);
            }
          }
          List<String> otherSubjectList = List<String>();
          var otherSubjectMap = postOpportunity[0]['otherSubject'];
          if (otherSubjectMap != null) {
            for (int i = 0; i < otherSubjectMap.length; i++) {
              String name = otherSubjectMap[i]['name'].toString();

              otherSubjectList.add(name);
            }
          }

          List<MainCategory> designationModelParam = List<MainCategory>();
          var designationData = postOpportunity[0]['category']; //
          try {
            if (designationData != null) {
              for (int k = 0; k < designationData.length; k++) {
                String name = designationData[k]['name'].toString();
                String isOtherS = designationData[k]['isOther'].toString();
                String categoryId = designationData[k]['categoryId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                designationModelParam.add(new MainCategory(
                    name: name, categoryId: int.parse(categoryId)));
              }
            }
          } catch (e) {}

          List<SubCategory> subjectModelParam = List<SubCategory>();
          var subjectData = postOpportunity[0]['subjects']; //
          try {
            if (subjectData != null) {
              for (int k = 0; k < subjectData.length; k++) {
                String name = subjectData[k]['name'].toString();
                String isOtherS = subjectData[k]['isOther'].toString();
                String subjectId = subjectData[k]['subjectId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                subjectModelParam.add(new SubCategory(
                    name: name, subjectId: int.parse(subjectId)));
              }
            }
          } catch (e) {}

          List<QualificationModelParam> qualificationModelParam =
              List<QualificationModelParam>();
          var qualificationData = postOpportunity[0]['qualification']; //
          if (qualificationData != null) {
            try {
              for (int k = 0; k < qualificationData.length; k++) {
                String name = qualificationData[k]['name'].toString();
                String isOtherS = qualificationData[k]['isOther'].toString();
                String qualificationId =
                    qualificationData[k]['qualificationId'].toString();

                bool isOther = true;
                if (isOtherS == 'false') isOther = false;

                qualificationModelParam.add(new QualificationModelParam(
                    name: name,
                    isOther: isOther,
                    qualificationId: int.parse(qualificationId)));
              }
            } catch (e) {}
          }

          opportunityModelForFeed = OpportunityModelForFeed(
              opportunityId,
              userId,
              roleId,
              jobTitle,
              jobType,
              jobLocation,
              project,
              duration,
              status,
              fromDate,
              toDate,
              groupId,
              targetAudience,
              title,
              gender,
              companyId,
              offerId,
              serviceTitle,
              serviceDesc,
              expiresOn,
              coverPicture,
              companyName,
              profilePicture,
              locationList,
              interestTypeList,
              ageList,
              assestList,
              assestVideoAndImage,
              videoList,
              docList,
              mediaList,
              googleLinkList,
              actionType,
              url,
              groupIdAction,
              callingNumber,
              formId,
              linkUrlPosition,
              groupIsPublic,
              studentJoinId,
              fees,
              description,
              bio,
              "",
              //menteeSupport,
              "",
              //advisorSupportOffered,
              "",
              //projectArea,
              userImageModelParam,
              qualification,
              qualificationModelParam,
              designationModelParam,
              subjectModelParam,
              scheduleModelParam,
              category,
              name,
              "",
              //supportedOffer,
              opportunityCretedUserName,
              opportunityCretedUserImage,
              otherSubjectList,
              otherCategoryList,
              otherCareerList,
              timeZone,
              declineReason,
              partnerStatus,
              schoolCode);
        }

        if ((isOpportunity && differenceDay <= 0) || (!isOpportunity)) {
          print("difference day++++" + differenceDay.toString());
          userPostList.add(new UserPostModal(
              _id,
              feedId,
              postedBy,
              isLiked,
              dateTime,
              visibility,
              firstName,
              lastName,
              email,
              profilePicture,
              title,
              tagline,
              shareText,
              shareTime,
              postOwner,
              postOwnerFirstName,
              postOwnerLastName,
              postOwnerTitle,
              postOwnerProfilePicture,
              isLike,
              isCommented,
              postData,
              commentList,
              likesList,
              tagList,
              groupList,
              scopeList,
              false,
              TextEditingController(text: ""),
              lastActivityTime,
              lastActivityType,
              false,
              false,
              false,
              false,
              isReported,
              isOpportunity,
              postOwnerRoleId,
              roleId,
              postOwnerDeleted,
              opportunityModelForFeed,
              WebLinksModel("", "", "", ""),
              postedGroupName,
              postedGroupId,
              badge,
              gamificationPoints,
              likesCount,
              badgeImage,
              postOwnerBadge,
              postOwnerGamificationPoints,
              postOwnerBadgeImage,
              "0",
              feedStatus,
              schoolCode));
        }
      } catch (e) {
        print("HomeError+++++" + e.toString());
        e.toString();
      }
    }

    return userPostList;
  }

  static List<ProfileEducationModal> parseMapEducation(map) {
    List<ProfileEducationModal> userEducationList =
        List<ProfileEducationModal>();
    for (int i = 0; i < map.length; i++) {
      try {
        String educationId =
            map[i][ProfileEducationConstant.EDUCATION_ID].toString();
        String organizationId =
            map[i][ProfileEducationConstant.ORGANIZATION_ID].toString();
        String userId = map[i][ProfileEducationConstant.USER_ID].toString();
        String institute =
            map[i][ProfileEducationConstant.INSTITUTE].toString();
        String city = map[i][ProfileEducationConstant.CITY].toString();
        String logo = map[i][ProfileEducationConstant.LOGO].toString();
        //logo= getMediumImage(logo);

        String fromGrade =
            map[i][ProfileEducationConstant.FROM_GRADE].toString();
        String toGrade = map[i][ProfileEducationConstant.TO_GRADE].toString();
        String fromYear = map[i][ProfileEducationConstant.FROM_YEAR].toString();
        String toYear = map[i][ProfileEducationConstant.TO_YEAR].toString();
        String description =
            map[i][ProfileEducationConstant.DESCRIPTION].toString();
        String isActive = map[i][ProfileEducationConstant.IS_ACTIVE].toString();

        userEducationList.add(new ProfileEducationModal(
            educationId,
            organizationId,
            userId,
            institute,
            city,
            logo,
            fromGrade,
            toGrade,
            fromYear,
            toYear,
            description,
            isActive));
      } catch (e) {
        e.toString();
      }
    }

    return userEducationList;
  }

  static List<NarrativeModel> parseMapNarrative(map, isEditable) {
    List<NarrativeModel> narrativeList = List<NarrativeModel>();
    for (int i = 0; i < map.length; i++) {
      try {
        List<Recomdation> recommendationtList = List<Recomdation>();
        List<Achivment> achivmentList = List<Achivment>();
        List<String> badgelistAll = List<String>();
        List<String> trophyListAll = List<String>();
        List<String> certificateListAll = List<String>();
        String _id = map[i]['_id'].toString();
        String name = map[i]['name'].toString();
        String level1 = map[i]['level1'].toString();
        bool isLevel2CompOther = false;
        try {
          isLevel2CompOther = map[i]['isLevel2CompOther'];
          if (isLevel2CompOther == null) {
            isLevel2CompOther = false;
          }
        } catch (e) {}
        String orderBy = map[i]['orderBy'].toString();

        var achivementMap = map[i]['achievement'];
        double minimumImportanceValue = 0.0;
        try {
          for (int j = 0; j < achivementMap.length; j++) {
            List<String> badgeList = List();
            List<String> trophyList = List();
            List<String> certificateList = List();
            List<String> mediaList = List();

            String _id = achivementMap[j]['_id'].toString();
            String achievementId = achivementMap[j]['achievementId'].toString();
            String competencyTypeId =
                achivementMap[j]['competencyTypeId'].toString();
            String level2Competency =
                achivementMap[j]['level2Competency'].toString();
            String level3Competency =
                achivementMap[j]['level3Competency'].toString();
            String focusArea = achivementMap[j]['focusArea'].toString();
            String userId = achivementMap[j]['userId'].toString();
            String title = achivementMap[j]['title'].toString();
            String hoursWorkedPerWeek =
                achivementMap[j]['hoursWorkedPerWeek'].toString();
            String description = achivementMap[j]['description'].toString();
            String personalReflection =
                achivementMap[j]['personalReflection'].toString();
            String height = achivementMap[j]['height'].toString();
            String weight = achivementMap[j]['weight'].toString();
            String fromDate = achivementMap[j]['fromDate'].toString();
            String toDate = achivementMap[j]['toDate'].toString();
            String isActive = achivementMap[j]['isActive'].toString();
            String importance = achivementMap[j]['importance'].toString();

            List<Assest> assestList = List<Assest>();
            List<Assest> fileList = List<Assest>();
            List<Assest> mediaAndVideoList = List<Assest>();
            List<PortFolioAssest> portFolioAssestList = List<PortFolioAssest>();
            var asetMap = achivementMap[j]['asset'];
            if (asetMap != null) {
              for (int k = 0; k < asetMap.length; k++) {
                String type = asetMap[k]['type'].toString();
                String tag = asetMap[k]['tag'].toString();
                String file = asetMap[k]['file'].toString();
                //  file= getMediumImage(file);

                assestList.add(new Assest(type, tag, file, "", false));
                if (achivementMap[j]['type'].toString() == "portfolio") {
                  String statistics = asetMap[k]['statistics'].toString();
                  String description = asetMap[k]['description'].toString();
                  String label = asetMap[k]['label'].toString();
                  var fileData = asetMap[k]['file'];
                  List<FileDataModel> fileDataList = List();
                  for (int n = 0; n < fileData.length; n++) {
                    String type1 = fileData[n]['type'].toString();
                    String filePath1 = fileData[n]['file'].toString();
                    if (type == "image" || type == "video") {
                      fileList.add(new Assest(type1, "", filePath1, "", false));
                    }
                    fileDataList
                        .add(FileDataModel(type: type1, filePath: filePath1));
                  }
                  portFolioAssestList.add(new PortFolioAssest(
                      type, tag, fileDataList, statistics, description, label));
                }
                if (tag == "certificates") {
                  certificateList.add(file);
                } else if (tag == "badges") {
                  badgeList.add(file);
                } else if (tag == "trophy") {
                  trophyList.add(file);
                  //badgeList.add(file);
                } else {
                  mediaAndVideoList.add(new Assest(type, tag, file, "", false));
                  mediaList.add(file);
                }
              }
            }
            List<Skill> skillList = List<Skill>();
            String allSkill = "";
            var skillMap = achivementMap[j]['skills'];
            if (skillMap != null) {
              for (int l = 0; l < skillMap.length; l++) {
                String label = skillMap[l]['label'].toString();
                String skillId = skillMap[l]['skillId'].toString();
                skillList.add(new Skill(label, skillId, l));
                if (l == 0) {
                  allSkill = label;
                } else {
                  allSkill = allSkill + " , " + label;
                }
              }
            }

            String guidePromptRecommendation =
                achivementMap[j]['guide']['promptRecommendation'].toString();

            String coachFirstName =
                achivementMap[j]['guide']['firstName'].toString();

            String coachLastName =
                achivementMap[j]['guide']['lastName'].toString();

            String coachemail = achivementMap[j]['guide']['email'].toString();

            String recommendationTitle =
                achivementMap[j]['guide']['title'].toString();

            String recommenderTitle =
                achivementMap[j]['guide']['recommenderTitle'].toString();
            String recommenderRequest =
                achivementMap[j]['guide']['request'].toString();
            if (recommenderTitle == null) {
              recommenderTitle = "";
            }

            if (recommendationTitle == null) {
              recommendationTitle = "";
            }

            print("recommendationTitle++++" + recommendationTitle);
            print("recommenderRequest++++" + recommenderRequest);

            var storiesMap = achivementMap[j]['stories'];

            List<String> storiesList = List<String>();

            for (int i = 0; i < storiesMap.length; i++) {
              String storie = storiesMap[i];
              if (storie != "") storiesList.add(storie);
            }
            badgelistAll.addAll(badgeList);
            trophyListAll.addAll(trophyList);
            certificateListAll.addAll(certificateList);
            if (importance == "null") importance = "0";

            if (j == 0) {
              minimumImportanceValue = double.parse(importance);
            } else {
              if (minimumImportanceValue > int.parse(importance))
                minimumImportanceValue = double.parse(importance);
            }
            List<Likes2> likeList = List<Likes2>();
            List<String> all_bage_certificate_trophy = List();
            all_bage_certificate_trophy.addAll(certificateList);
            all_bage_certificate_trophy.addAll(badgeList);
            all_bage_certificate_trophy.addAll(trophyList);

            //========================PortFolio key changes====================
            String createdTimestamp, parentId;
            String personalStatement,
                city,
                state,
                age,
                type,
                userImage,
                level2Icon;
            List<Stats> statsList = List();
            List<Team> teamList = List();
            List<ExternalLinks> externalLinksList = List();

            createdTimestamp = achivementMap[j]['createdTimestamp'].toString();
            parentId = achivementMap[j]['parentId'].toString();
            personalStatement =
                achivementMap[j]['personalStatement'].toString();
            city = achivementMap[j]['city'].toString();
            state = achivementMap[j]['state'].toString();
            age = achivementMap[j]['age'].toString();
            type = achivementMap[j]['type'].toString();
            userImage = achivementMap[j]['userImage'].toString();
            level2Icon = achivementMap[j]['level2Icon'].toString();

            var statsMap = achivementMap[j]['stats'];
            if (statsMap != null) {
              for (int l = 0; l < statsMap.length; l++) {
                String value = statsMap[l]['value'].toString();
                String label = statsMap[l]['label'].toString();
                String playingPosition =
                    statsMap[l]['playingPosition'].toString();
                statsList.add(new Stats(value, label, playingPosition));
              }
            }

            var teamMap = achivementMap[j]['team'];
            if (teamMap != null) {
              for (int l = 0; l < teamMap.length; l++) {
                String teamType = teamMap[l]['teamType'].toString();
                List<TeamData> teamDataList = List();
                var teamDataMap = teamMap[l]['teams'];
                for (int m = 0; m < teamDataMap.length; m++) {
                  String coachCountryCode =
                      teamDataMap[m]['coachCountryCode'].toString();
                  String coachPhoneNo =
                      teamDataMap[m]['coachPhoneNo'].toString();
                  String coachEmail = teamDataMap[m]['coachEmail'].toString();
                  String coachName = teamDataMap[m]['coachName'].toString();
                  String jersey = teamDataMap[m]['jersey'].toString();
                  String state = teamDataMap[m]['state'].toString();
                  String city = teamDataMap[m]['city'].toString();
                  String teamName = teamDataMap[m]['teamName'].toString();
                  String orgName = teamDataMap[m]['orgName'].toString();
                  String coachPhoneCode =
                      teamDataMap[m]['coachPhoneCode'].toString();

                  teamDataList.add(TeamData(
                      coachCountryCode,
                      coachPhoneCode,
                      coachPhoneNo,
                      coachEmail,
                      coachName,
                      jersey,
                      state,
                      city,
                      teamName,
                      orgName,
                      teamType));
                }
                teamList.add(Team(teamType, teamDataList));
              }
            }

            var externalLinksMap = achivementMap[j]['external_links'];
            if (externalLinksMap != null) {
              for (int l = 0; l < externalLinksMap.length; l++) {
                String description =
                    externalLinksMap[l]['description'].toString();
                String url = externalLinksMap[l]['url'].toString();
                String label = externalLinksMap[l]['label'].toString();

                externalLinksList
                    .add(new ExternalLinks(description, url, label));
              }
            }
            RecommendationsDataNar _mRecommendationsData;
            _mRecommendationsData = achivementMap[j]['recommendations'] != null
                ? RecommendationsDataNar.fromJson(
                    achivementMap[j]['recommendations'])
                : null;
            achivmentList.add(new Achivment(
                _id,
                achievementId,
                competencyTypeId,
                level2Competency,
                level3Competency,
                userId,
                title,
                description,
                fromDate,
                toDate,
                isActive,
                importance,
                allSkill,
                guidePromptRecommendation,
                storiesList,
                likeList,
                skillList,
                assestList,
                certificateList,
                badgeList,
                trophyList,
                mediaList,
                coachFirstName,
                coachLastName,
                coachemail,
                recommendationTitle,
                recommenderTitle,
                false,
                all_bage_certificate_trophy,
                recommenderRequest,
                hoursWorkedPerWeek,
                height,
                weight,
                createdTimestamp,
                parentId,
                personalStatement,
                city,
                state,
                age,
                type,
                userImage,
                statsList,
                teamList,
                externalLinksList,
                portFolioAssestList,
                mediaAndVideoList,
                level2Icon,
                _mRecommendationsData,
                fileList,
                focusArea,
                personalReflection,
                false,
                false));
          }
        } catch (e) {
          print("data+++" + e.toString());
          e.toString();
        }
        var recomdenationMap = map[i]['recommendation'];
        for (int j = 0; j < recomdenationMap.length; j++) {
          List<String> badgeList = List();
          List<String> trophyList = List();
          List<String> mediaList = List();
          List<String> certificateList = List();
          String _id = recomdenationMap[j]['_id'].toString();
          String recommendationId =
              recomdenationMap[j]['recommendationId'].toString();

          String isReminderEnable =
              recomdenationMap[j]['isReminderEnable'].toString();
          String type = recomdenationMap[j]['type'].toString();
          String recomendedRoleId = recomdenationMap[j]['roleId'].toString();
          String recommenderFile =
              recomdenationMap[j]['recommenderFile'].toString();
          String recommenderFileName =
              recomdenationMap[j]['recommenderFileName'].toString();
          String isLevel3Other =
              recomdenationMap[j]['isLevel3Other'].toString();
          if (recommenderFileName == "null") {
            recommenderFileName = "";
          }
          String userId = recomdenationMap[j]['userId'].toString();
          String recommenderId =
              recomdenationMap[j]['recommenderId'].toString();
          String competencyTypeId =
              recomdenationMap[j]['competencyTypeId'].toString();
          String level3Competency =
              recomdenationMap[j]['level3Competency'].toString();
          String focusArea = recomdenationMap[j]['focusArea'].toString();
          if (focusArea == "null") {
            focusArea = level3Competency;
          }

          String level2Competency =
              recomdenationMap[j]['level2Competency'].toString();
          String title = recomdenationMap[j]['title'].toString();
          String request = recomdenationMap[j]['request'].toString();
          String recommendation =
              recomdenationMap[j]['recommendation'].toString();
          String stage = recomdenationMap[j]['stage'].toString();
          String interactionStartDate =
              recomdenationMap[j]['interactionStartDate'].toString();
          String interactionEndDate =
              recomdenationMap[j]['interactionEndDate'].toString();

          String isActiveRecomendation =
              recomdenationMap[j]['isActive'].toString();

          String reminderDay = recomdenationMap[j]['reminderDay'].toString();
          String requestedDate =
              recomdenationMap[j]['requestedDate'].toString();
          String repliedDate = recomdenationMap[j]['repliedDate'].toString();
          if (requestedDate == null) {
            requestedDate = interactionStartDate;
          }
          if (repliedDate == null) {
            repliedDate = interactionStartDate;
          }

          List<Assest> assestList = List<Assest>();
          List<Assest> mediaVideoList = List<Assest>();

          var asetMap = recomdenationMap[j]['asset'];
          for (int k = 0; k < asetMap.length; k++) {
            if (asetMap[k] != null) {
              String type = asetMap[k]['type'].toString();
              String tag = asetMap[k]['tag'].toString();
              String file; //= asetMap[k]['file'].toString();

              file = asetMap[k]['file'].toString();
              try {
                if (type == "null" || type == "") {
                  var fileList = asetMap[k]['file'];
                  for (int l = 0; l < fileList.length; l++) {
                    file = fileList[l]['file'].toString();
                    type = fileList[l]['type'].toString();
                    mediaVideoList.add(new Assest(type, tag, file, "", false));
                  }
                } else {
                  mediaVideoList.add(new Assest(type, tag, file, "", false));
                }
              } catch (e) {}
              //file= getMediumImage(file);

              if (tag == "certificates") {
                certificateList.add(file);
              } else if (tag == "badges") {
                badgeList.add(file);
              } else if (tag == "trophy") {
                trophyList.add(file);
                //badgeList.add(file);
              } else {
                assestList.add(new Assest(type, tag, file, "", false));
                mediaList.add(file);
              }
            }
          }
          List<Skill> skillList = List<Skill>();

          var skillMap = recomdenationMap[j]['skills'];
          for (int l = 0; l < skillMap.length; l++) {
            String label = skillMap[l]['label'].toString();
            String skillId = skillMap[l]['skillId'].toString();
            skillList.add(new Skill(label, skillId, l));
          }
          String __v = recomdenationMap[j]['__v'].toString();

          String _id1 = recomdenationMap[j]['recommender']['_id'].toString();
          String userId1 =
              recomdenationMap[j]['recommender']['userId'].toString();
          String firstName =
              recomdenationMap[j]['recommender']['firstName'].toString();
          String lastName =
              recomdenationMap[j]['recommender']['lastName'].toString();
          String email = recomdenationMap[j]['recommender']['email'].toString();
          String password =
              recomdenationMap[j]['recommender']['password'].toString();
          String salt = recomdenationMap[j]['recommender']['salt'].toString();
          String mobileNo =
              recomdenationMap[j]['recommender']['mobileNo'].toString();
          String roleId =
              recomdenationMap[j]['recommender']['roleId'].toString();
          String isActive =
              recomdenationMap[j]['recommender']['isActive'].toString();
          String isPasswordChanged = recomdenationMap[j]['recommender']
                  ['isPasswordChanged']
              .toString();
          String organizationId =
              recomdenationMap[j]['recommender']['organizationId'].toString();
          String dob = recomdenationMap[j]['recommender']['dob'].toString();
          String title1 =
              recomdenationMap[j]['recommender']['title'].toString();
          String tempPassword =
              recomdenationMap[j]['recommender']['tempPassword'].toString();
          String isArchived =
              recomdenationMap[j]['recommender']['isArchived'].toString();
          String __v1 =
              recomdenationMap[j]['recommender']['isArchived'].toString();
          String profilePicture =
              recomdenationMap[j]['recommender']['profilePicture'].toString();
          List<Likes2> likeList = List<Likes2>();
          Recommender recommender = Recommender(
              _id1,
              userId1,
              firstName,
              lastName,
              email,
              password,
              salt,
              mobileNo,
              roleId,
              isActive,
              isPasswordChanged,
              organizationId,
              dob,
              title1,
              tempPassword,
              isArchived,
              profilePicture,
              __v1);

          User user = User("", "", "", "", "", "", "", "");
          if (recomdenationMap[j]['user'] != null) {
            String firstNameUser =
                recomdenationMap[j]['user']['firstName'].toString();
            String lastNameUser =
                recomdenationMap[j]['user']['lastName'].toString();
            String emailUser = recomdenationMap[j]['user']['email'].toString();
            String profilePictureUser =
                recomdenationMap[j]['user']['profilePicture'].toString();

            String tagline = recomdenationMap[j]['user']['tagline'].toString();
            String titleUser = recomdenationMap[j]['user']['title'].toString();
            String userId = recomdenationMap[j]['user']['userId'].toString();
            String roleId = recomdenationMap[j]['user']['roleId'].toString();
            user = User(firstNameUser, lastNameUser, profilePictureUser,
                emailUser, tagline, titleUser, userId, roleId);
          }
          if (isEditable) {
            recommendationtList.add(new Recomdation(
                _id,
                recommendationId,
                userId,
                recommenderId,
                isReminderEnable,
                type,
                recomendedRoleId,
                competencyTypeId,
                level3Competency,
                level2Competency,
                title,
                request,
                recommendation,
                stage,
                interactionStartDate,
                interactionEndDate,
                requestedDate,
                reminderDay,
                repliedDate,
                isActiveRecomendation,
                __v,
                likeList,
                skillList,
                assestList,
                certificateList,
                badgeList,
                recommender,
                user,
                false,
                trophyList,
                mediaList,
                recommenderFile,
                recommenderFileName,
                mediaVideoList,
                isLevel3Other,
                focusArea));
          } else {
            if (stage == "Added") {
              recommendationtList.add(new Recomdation(
                  _id,
                  recommendationId,
                  userId,
                  recommenderId,
                  isReminderEnable,
                  type,
                  recomendedRoleId,
                  competencyTypeId,
                  level3Competency,
                  level2Competency,
                  title,
                  request,
                  recommendation,
                  stage,
                  interactionStartDate,
                  interactionEndDate,
                  requestedDate,
                  reminderDay,
                  repliedDate,
                  __v,
                  isActiveRecomendation,
                  likeList,
                  skillList,
                  assestList,
                  certificateList,
                  badgeList,
                  recommender,
                  user,
                  false,
                  trophyList,
                  mediaList,
                  recommenderFile,
                  recommenderFileName,
                  mediaVideoList,
                  isLevel3Other,
                  focusArea));
            }
          }
        }
        bool isVisible = true;

        //    if (i == 0) isVisible = true;
        if (achivmentList.length != 0) {
          narrativeList.add(new NarrativeModel(
              _id,
              name,
              level1,
              orderBy,
              achivmentList,
              recommendationtList,
              badgelistAll,
              trophyListAll,
              certificateListAll,
              isVisible,
              minimumImportanceValue,
              minimumImportanceValue,
              false,
              isLevel2CompOther));
        }
      } catch (e) {
        print("Accdattaa+++" + e.toString());
        e.toString();
      }
    }

    return narrativeList;
  }

  static List<NarrativeModel> parseMapNarrativeForOusideAccomplishment(
      map, isEditable) {
    List<NarrativeModel> narrativeList = List<NarrativeModel>();
    for (int i = 0; i < map.length; i++) {
      try {
        List<Recomdation> recommendationtList = List<Recomdation>();
        List<Achivment> achivmentList = List<Achivment>();
        List<String> badgelistAll = List<String>();
        List<String> trophyListAll = List<String>();
        List<String> certificateListAll = List<String>();
        String _id = map[i]['_id'].toString();
        String name = map[i]['name'].toString();
        String level1 = map[i]['level1'].toString();
        bool isLevel2CompOther = false;
        try {
          isLevel2CompOther = map[i]['isLevel2CompOther'];
          if (isLevel2CompOther == null) {
            isLevel2CompOther = false;
          }
        } catch (e) {}
        String orderBy = map[i]['orderBy'].toString();

        var achivementMap = map[i]['achievement'];
        double minimumImportanceValue = 0.0;
        try {
          for (int j = 0; j < achivementMap.length; j++) {
            List<String> badgeList = List();
            List<String> trophyList = List();
            List<String> certificateList = List();
            List<String> mediaList = List();

            String _id = achivementMap[j]['_id'].toString();
            String achievementId = achivementMap[j]['achievementId'].toString();
            String competencyTypeId =
                achivementMap[j]['competencyTypeId'].toString();
            String level2Competency =
                achivementMap[j]['level2Competency'].toString();
            String level3Competency =
                achivementMap[j]['level3Competency'].toString();
            String focusArea = achivementMap[j]['focusArea'].toString();
            String userId = achivementMap[j]['userId'].toString();
            String title = achivementMap[j]['title'].toString();
            String hoursWorkedPerWeek =
                achivementMap[j]['hoursWorkedPerWeek'].toString();
            String description = achivementMap[j]['description'].toString();
            String personalReflection =
                achivementMap[j]['personalReflection'].toString();
            String height = achivementMap[j]['height'].toString();
            String weight = achivementMap[j]['weight'].toString();
            String fromDate = achivementMap[j]['fromDate'].toString();
            String toDate = achivementMap[j]['toDate'].toString();
            String isActive = achivementMap[j]['isActive'].toString();
            String importance = achivementMap[j]['importance'].toString();

            List<Assest> assestList = List<Assest>();
            List<Assest> fileList = List<Assest>();
            List<Assest> mediaAndVideoList = List<Assest>();
            List<PortFolioAssest> portFolioAssestList = List<PortFolioAssest>();
            var asetMap = achivementMap[j]['asset'];
            if (asetMap != null) {
              for (int k = 0; k < asetMap.length; k++) {
                String type = asetMap[k]['type'].toString();
                String tag = asetMap[k]['tag'].toString();
                String file = asetMap[k]['file'].toString();
                //  file= getMediumImage(file);

                assestList.add(new Assest(type, tag, file, "", false));
                if (achivementMap[j]['type'].toString() == "portfolio") {
                  String statistics = asetMap[k]['statistics'].toString();
                  String description = asetMap[k]['description'].toString();
                  String label = asetMap[k]['label'].toString();
                  var fileData = asetMap[k]['file'];
                  List<FileDataModel> fileDataList = List();
                  for (int n = 0; n < fileData.length; n++) {
                    String type1 = fileData[n]['type'].toString();
                    String filePath1 = fileData[n]['file'].toString();
                    if (type == "image" || type == "video") {
                      fileList.add(new Assest(type1, "", filePath1, "", false));
                    }
                    fileDataList
                        .add(FileDataModel(type: type1, filePath: filePath1));
                  }
                  portFolioAssestList.add(new PortFolioAssest(
                      type, tag, fileDataList, statistics, description, label));
                }
                if (tag == "certificates") {
                  certificateList.add(file);
                } else if (tag == "badges") {
                  badgeList.add(file);
                } else if (tag == "trophy") {
                  trophyList.add(file);
                  //badgeList.add(file);
                } else {
                  mediaAndVideoList.add(new Assest(type, tag, file, "", false));
                  mediaList.add(file);
                }
              }
            }
            List<Skill> skillList = List<Skill>();
            String allSkill = "";
            var skillMap = achivementMap[j]['skills'];
            if (skillMap != null) {
              for (int l = 0; l < skillMap.length; l++) {
                String label = skillMap[l]['label'].toString();
                String skillId = skillMap[l]['skillId'].toString();
                skillList.add(new Skill(label, skillId, l));
                if (l == 0) {
                  allSkill = label;
                } else {
                  allSkill = allSkill + " , " + label;
                }
              }
            }

            String guidePromptRecommendation =
                achivementMap[j]['guide']['promptRecommendation'].toString();

            String coachFirstName =
                achivementMap[j]['guide']['firstName'].toString();

            String coachLastName =
                achivementMap[j]['guide']['lastName'].toString();

            String coachemail = achivementMap[j]['guide']['email'].toString();

            String recommendationTitle =
                achivementMap[j]['guide']['title'].toString();

            String recommenderTitle =
                achivementMap[j]['guide']['recommenderTitle'].toString();
            String recommenderRequest =
                achivementMap[j]['guide']['request'].toString();
            if (recommenderTitle == null) {
              recommenderTitle = "";
            }

            if (recommendationTitle == null) {
              recommendationTitle = "";
            }

            print("recommendationTitle++++" + recommendationTitle);
            print("recommenderRequest++++" + recommenderRequest);

            var storiesMap = achivementMap[j]['stories'];

            List<String> storiesList = List<String>();

            for (int i = 0; i < storiesMap.length; i++) {
              String storie = storiesMap[i];
              if (storie != "") storiesList.add(storie);
            }
            badgelistAll.addAll(badgeList);
            trophyListAll.addAll(trophyList);
            certificateListAll.addAll(certificateList);
            if (importance == "null") importance = "0";

            if (j == 0) {
              minimumImportanceValue = double.parse(importance);
            } else {
              if (minimumImportanceValue > int.parse(importance))
                minimumImportanceValue = double.parse(importance);
            }
            List<Likes2> likeList = List<Likes2>();
            List<String> all_bage_certificate_trophy = List();
            all_bage_certificate_trophy.addAll(certificateList);
            all_bage_certificate_trophy.addAll(badgeList);
            all_bage_certificate_trophy.addAll(trophyList);

            //========================PortFolio key changes====================
            String createdTimestamp, parentId;
            String personalStatement,
                city,
                state,
                age,
                type,
                userImage,
                level2Icon;
            List<Stats> statsList = List();
            List<Team> teamList = List();
            List<ExternalLinks> externalLinksList = List();

            createdTimestamp = achivementMap[j]['createdTimestamp'].toString();
            parentId = achivementMap[j]['parentId'].toString();
            personalStatement =
                achivementMap[j]['personalStatement'].toString();
            city = achivementMap[j]['city'].toString();
            state = achivementMap[j]['state'].toString();
            age = achivementMap[j]['age'].toString();
            type = achivementMap[j]['type'].toString();
            userImage = achivementMap[j]['userImage'].toString();
            level2Icon = achivementMap[j]['level2Icon'].toString();

            var statsMap = achivementMap[j]['stats'];
            if (statsMap != null) {
              for (int l = 0; l < statsMap.length; l++) {
                String value = statsMap[l]['value'].toString();
                String label = statsMap[l]['label'].toString();
                String playingPosition =
                    statsMap[l]['playingPosition'].toString();
                statsList.add(new Stats(value, label, playingPosition));
              }
            }

            var teamMap = achivementMap[j]['team'];
            if (teamMap != null) {
              for (int l = 0; l < teamMap.length; l++) {
                String teamType = teamMap[l]['teamType'].toString();
                List<TeamData> teamDataList = List();
                var teamDataMap = teamMap[l]['teams'];
                for (int m = 0; m < teamDataMap.length; m++) {
                  String coachCountryCode =
                      teamDataMap[m]['coachCountryCode'].toString();
                  String coachPhoneNo =
                      teamDataMap[m]['coachPhoneNo'].toString();
                  String coachEmail = teamDataMap[m]['coachEmail'].toString();
                  String coachName = teamDataMap[m]['coachName'].toString();
                  String jersey = teamDataMap[m]['jersey'].toString();
                  String state = teamDataMap[m]['state'].toString();
                  String city = teamDataMap[m]['city'].toString();
                  String teamName = teamDataMap[m]['teamName'].toString();
                  String orgName = teamDataMap[m]['orgName'].toString();
                  String coachPhoneCode =
                      teamDataMap[m]['coachPhoneCode'].toString();

                  teamDataList.add(TeamData(
                      coachCountryCode,
                      coachPhoneCode,
                      coachPhoneNo,
                      coachEmail,
                      coachName,
                      jersey,
                      state,
                      city,
                      teamName,
                      orgName,
                      teamType));
                }
                teamList.add(Team(teamType, teamDataList));
              }
            }

            var externalLinksMap = achivementMap[j]['external_links'];
            if (externalLinksMap != null) {
              for (int l = 0; l < externalLinksMap.length; l++) {
                String description =
                    externalLinksMap[l]['description'].toString();
                String url = externalLinksMap[l]['url'].toString();
                String label = externalLinksMap[l]['label'].toString();

                externalLinksList
                    .add(new ExternalLinks(description, url, label));
              }
            }
            RecommendationsDataNar _mRecommendationsData;
            _mRecommendationsData = achivementMap[j]['recommendations'] != null
                ? RecommendationsDataNar.fromJson(
                    achivementMap[j]['recommendations'])
                : null;
            if (type != "portfolio")
              achivmentList.add(new Achivment(
                  _id,
                  achievementId,
                  competencyTypeId,
                  level2Competency,
                  level3Competency,
                  userId,
                  title,
                  description,
                  fromDate,
                  toDate,
                  isActive,
                  importance,
                  allSkill,
                  guidePromptRecommendation,
                  storiesList,
                  likeList,
                  skillList,
                  assestList,
                  certificateList,
                  badgeList,
                  trophyList,
                  mediaList,
                  coachFirstName,
                  coachLastName,
                  coachemail,
                  recommendationTitle,
                  recommenderTitle,
                  false,
                  all_bage_certificate_trophy,
                  recommenderRequest,
                  hoursWorkedPerWeek,
                  height,
                  weight,
                  createdTimestamp,
                  parentId,
                  personalStatement,
                  city,
                  state,
                  age,
                  type,
                  userImage,
                  statsList,
                  teamList,
                  externalLinksList,
                  portFolioAssestList,
                  mediaAndVideoList,
                  level2Icon,
                  _mRecommendationsData,
                  fileList,
                  focusArea,
                  personalReflection,
                  false,
                  false));
          }
        } catch (e) {
          print("data+++" + e.toString());
          e.toString();
        }
        var recomdenationMap = map[i]['recommendation'];
        for (int j = 0; j < recomdenationMap.length; j++) {
          List<String> badgeList = List();
          List<String> trophyList = List();
          List<String> mediaList = List();
          List<String> certificateList = List();
          String _id = recomdenationMap[j]['_id'].toString();
          String recommendationId =
              recomdenationMap[j]['recommendationId'].toString();

          String isReminderEnable =
              recomdenationMap[j]['isReminderEnable'].toString();
          String type = recomdenationMap[j]['type'].toString();
          String recomendedRoleId = recomdenationMap[j]['roleId'].toString();
          String recommenderFile =
              recomdenationMap[j]['recommenderFile'].toString();
          String recommenderFileName =
              recomdenationMap[j]['recommenderFileName'].toString();
          String isLevel3Other =
              recomdenationMap[j]['isLevel3Other'].toString();
          if (recommenderFileName == "null") {
            recommenderFileName = "";
          }
          String userId = recomdenationMap[j]['userId'].toString();
          String recommenderId =
              recomdenationMap[j]['recommenderId'].toString();
          String competencyTypeId =
              recomdenationMap[j]['competencyTypeId'].toString();
          String level3Competency =
              recomdenationMap[j]['level3Competency'].toString();
          String focusArea = recomdenationMap[j]['focusArea'].toString();
          if (focusArea == "null") {
            focusArea = level3Competency;
          }

          String level2Competency =
              recomdenationMap[j]['level2Competency'].toString();
          String title = recomdenationMap[j]['title'].toString();
          String request = recomdenationMap[j]['request'].toString();
          String recommendation =
              recomdenationMap[j]['recommendation'].toString();
          String stage = recomdenationMap[j]['stage'].toString();
          String interactionStartDate =
              recomdenationMap[j]['interactionStartDate'].toString();
          String interactionEndDate =
              recomdenationMap[j]['interactionEndDate'].toString();

          String isActiveRecomendation =
              recomdenationMap[j]['isActive'].toString();

          String reminderDay = recomdenationMap[j]['reminderDay'].toString();
          String requestedDate =
              recomdenationMap[j]['requestedDate'].toString();
          String repliedDate = recomdenationMap[j]['repliedDate'].toString();
          if (requestedDate == null) {
            requestedDate = interactionStartDate;
          }
          if (repliedDate == null) {
            repliedDate = interactionStartDate;
          }

          List<Assest> assestList = List<Assest>();
          List<Assest> mediaVideoList = List<Assest>();

          var asetMap = recomdenationMap[j]['asset'];
          for (int k = 0; k < asetMap.length; k++) {
            if (asetMap[k] != null) {
              String type = asetMap[k]['type'].toString();
              String tag = asetMap[k]['tag'].toString();
              String file; //= asetMap[k]['file'].toString();

              file = asetMap[k]['file'].toString();
              try {
                if (type == "null" || type == "") {
                  var fileList = asetMap[k]['file'];
                  for (int l = 0; l < fileList.length; l++) {
                    file = fileList[l]['file'].toString();
                    type = fileList[l]['type'].toString();
                    mediaVideoList.add(new Assest(type, tag, file, "", false));
                  }
                } else {
                  mediaVideoList.add(new Assest(type, tag, file, "", false));
                }
              } catch (e) {}
              //file= getMediumImage(file);

              if (tag == "certificates") {
                certificateList.add(file);
              } else if (tag == "badges") {
                badgeList.add(file);
              } else if (tag == "trophy") {
                trophyList.add(file);
                //badgeList.add(file);
              } else {
                assestList.add(new Assest(type, tag, file, "", false));
                mediaList.add(file);
              }
            }
          }
          List<Skill> skillList = List<Skill>();

          var skillMap = recomdenationMap[j]['skills'];
          for (int l = 0; l < skillMap.length; l++) {
            String label = skillMap[l]['label'].toString();
            String skillId = skillMap[l]['skillId'].toString();
            skillList.add(new Skill(label, skillId, l));
          }
          String __v = recomdenationMap[j]['__v'].toString();

          String _id1 = recomdenationMap[j]['recommender']['_id'].toString();
          String userId1 =
              recomdenationMap[j]['recommender']['userId'].toString();

          String firstName =
              recomdenationMap[j]['recommender']['firstName'].toString();

          String lastName =
              recomdenationMap[j]['recommender']['lastName'].toString();
          String email = recomdenationMap[j]['recommender']['email'].toString();
          String password =
              recomdenationMap[j]['recommender']['password'].toString();
          String salt = recomdenationMap[j]['recommender']['salt'].toString();
          String mobileNo =
              recomdenationMap[j]['recommender']['mobileNo'].toString();
          String roleId =
              recomdenationMap[j]['recommender']['roleId'].toString();
          String isActive =
              recomdenationMap[j]['recommender']['isActive'].toString();
          String isPasswordChanged = recomdenationMap[j]['recommender']
                  ['isPasswordChanged']
              .toString();
          String organizationId =
              recomdenationMap[j]['recommender']['organizationId'].toString();
          String dob = recomdenationMap[j]['recommender']['dob'].toString();
          String title1 =
              recomdenationMap[j]['recommender']['title'].toString();
          String tempPassword =
              recomdenationMap[j]['recommender']['tempPassword'].toString();
          String isArchived =
              recomdenationMap[j]['recommender']['isArchived'].toString();
          String __v1 =
              recomdenationMap[j]['recommender']['isArchived'].toString();
          String profilePicture =
              recomdenationMap[j]['recommender']['profilePicture'].toString();
          List<Likes2> likeList = List<Likes2>();
          Recommender recommender = Recommender(
              _id1,
              userId1,
              firstName,
              lastName,
              email,
              password,
              salt,
              mobileNo,
              roleId,
              isActive,
              isPasswordChanged,
              organizationId,
              dob,
              title1,
              tempPassword,
              isArchived,
              profilePicture,
              __v1);

          User user = User("", "", "", "", "", "", "", "");
          if (recomdenationMap[j]['user'] != null) {
            String firstNameUser =
                recomdenationMap[j]['user']['firstName'].toString();
            String lastNameUser =
                recomdenationMap[j]['user']['lastName'].toString();
            String emailUser = recomdenationMap[j]['user']['email'].toString();
            String profilePictureUser =
                recomdenationMap[j]['user']['profilePicture'].toString();

            String tagline = recomdenationMap[j]['user']['tagline'].toString();
            String titleUser = recomdenationMap[j]['user']['title'].toString();
            String userId = recomdenationMap[j]['user']['userId'].toString();
            String roleId = recomdenationMap[j]['user']['roleId'].toString();

            user = User(firstNameUser, lastNameUser, profilePictureUser,
                emailUser, tagline, titleUser, userId, roleId);
          }
          if (isEditable) {
            recommendationtList.add(new Recomdation(
                _id,
                recommendationId,
                userId,
                recommenderId,
                isReminderEnable,
                type,
                recomendedRoleId,
                competencyTypeId,
                level3Competency,
                level2Competency,
                title,
                request,
                recommendation,
                stage,
                interactionStartDate,
                interactionEndDate,
                requestedDate,
                reminderDay,
                repliedDate,
                isActiveRecomendation,
                __v,
                likeList,
                skillList,
                assestList,
                certificateList,
                badgeList,
                recommender,
                user,
                false,
                trophyList,
                mediaList,
                recommenderFile,
                recommenderFileName,
                mediaVideoList,
                isLevel3Other,
                focusArea));
          } else {
            if (stage == "Added") {
              recommendationtList.add(new Recomdation(
                  _id,
                  recommendationId,
                  userId,
                  recommenderId,
                  isReminderEnable,
                  type,
                  recomendedRoleId,
                  competencyTypeId,
                  level3Competency,
                  level2Competency,
                  title,
                  request,
                  recommendation,
                  stage,
                  interactionStartDate,
                  interactionEndDate,
                  requestedDate,
                  reminderDay,
                  repliedDate,
                  __v,
                  isActiveRecomendation,
                  likeList,
                  skillList,
                  assestList,
                  certificateList,
                  badgeList,
                  recommender,
                  user,
                  false,
                  trophyList,
                  mediaList,
                  recommenderFile,
                  recommenderFileName,
                  mediaVideoList,
                  isLevel3Other,
                  focusArea));
            }
          }
        }
        bool isVisible = true;

        //    if (i == 0) isVisible = true;
        if (achivmentList.length != 0) {
          narrativeList.add(new NarrativeModel(
              _id,
              name,
              level1,
              orderBy,
              achivmentList,
              recommendationtList,
              badgelistAll,
              trophyListAll,
              certificateListAll,
              isVisible,
              minimumImportanceValue,
              minimumImportanceValue,
              false,
              isLevel2CompOther));
        }
      } catch (e) {
        print("Accdattaa+++" + e.toString());
        e.toString();
      }
    }

    return narrativeList;
  }

  static List<Recomdation> parseMapRecommdation(recomdenationMap, isEditable) {
    List<Recomdation> recommendationtList = List<Recomdation>();

    try {
      for (int j = 0; j < recomdenationMap.length; j++) {
        print("recomdenationMap......=============" + j.toString());
        try {
          List<String> badgeList = List();
          List<String> certificateList = List();
          List<String> trophyList = List();
          List<String> mediaList = List();
          String _id = recomdenationMap[j]['_id'].toString();
          String recommendationId =
              recomdenationMap[j]['recommendationId'].toString();
          String type = recomdenationMap[j]['type'].toString();
          String isReminderEnable =
              recomdenationMap[j]['isReminderEnable'].toString();
          String recomendedRoleId = recomdenationMap[j]['roleId'].toString();
          String recommenderFile =
              recomdenationMap[j]['recommenderFile'].toString();
          String recommenderFileName =
              recomdenationMap[j]['recommenderFileName'].toString();
          if (recommenderFileName == "null") {
            recommenderFileName = "";
          }
          String userId = recomdenationMap[j]['userId'].toString();
          String isLevel3Other =
              recomdenationMap[j]['isLevel3Other'].toString();
          String recommenderId =
              recomdenationMap[j]['recommenderId'].toString();
          String competencyTypeId =
              recomdenationMap[j]['competencyTypeId'].toString();
          String level3Competency =
              recomdenationMap[j]['level3Competency'].toString();
          String focusArea = recomdenationMap[j]['focusArea'].toString();
          if (focusArea == "null") {
            focusArea = level3Competency;
          }
          String level2Competency =
              recomdenationMap[j]['level2Competency'].toString();
          String title = recomdenationMap[j]['title'].toString();
          String request = recomdenationMap[j]['request'].toString();
          String recommendation =
              recomdenationMap[j]['recommendation'].toString();
          String recommenderTitle =
              recomdenationMap[j]['recommenderTitle'].toString();

          String stage = recomdenationMap[j]['stage'].toString();
          String interactionStartDate =
              recomdenationMap[j]['interactionStartDate'].toString();
          String interactionEndDate =
              recomdenationMap[j]['interactionEndDate'].toString();

          String requestedDate =
              recomdenationMap[j]['requestedDate'].toString();
          String reminderDay = recomdenationMap[j]['reminderDay'].toString();

          String isActiveRecomendation =
              recomdenationMap[j]['isActive'].toString();
          String repliedDate = recomdenationMap[j]['repliedDate'].toString();
          if (requestedDate == null) {
            requestedDate = interactionStartDate;
          }
          if (repliedDate == null) {
            repliedDate = interactionStartDate;
          }
          List<Assest> assestList = List<Assest>();
          List<Assest> mediaVideoList = List<Assest>();

          var asetMap = recomdenationMap[j]['asset'];
          if (asetMap != null) {
            for (int k = 0; k < asetMap.length; k++) {
              if (asetMap[k] != null) {
                String type = asetMap[k]['type'].toString();
                String tag = asetMap[k]['tag'].toString();
                String file = asetMap[k]['file'].toString();
                //  file= getMediumImage(file);

                assestList.add(new Assest(type, tag, file, "", false));

                try {
                  if (tag == "null" || tag == "") {
                    var fileList = asetMap[k]['file'];
                    for (int l = 0; l < fileList.length; l++) {
                      file = fileList[l]['file'].toString();
                      type = fileList[l]['type'].toString();
                      mediaVideoList
                          .add(new Assest(type, tag, file, "", false));
                    }
                  } else {
                    mediaVideoList.add(new Assest(type, tag, file, "", false));
                  }
                } catch (e) {}

                if (tag == "certificates") {
                  certificateList.add(file);
                } else if (tag == "badges") {
                  badgeList.add(file);
                } else if (tag == "trophy") {
                  trophyList.add(file);
                  //badgeList.add(file);
                } else {
                  mediaList.add(file);
                }
              }
            }
          }
          List<Skill> skillList = List<Skill>();

          var skillMap = recomdenationMap[j]['skills'];
          if (skillMap != null) {
            for (int l = 0; l < skillMap.length; l++) {
              String label = skillMap[l]['label'].toString();
              String skillId = skillMap[l]['skillId'].toString();
              skillList.add(new Skill(label, skillId, l));
            }
          }

          String _id1 = "",
              userId1 = "",
              firstName = "",
              lastName = "",
              email = "",
              password = "",
              salt = "",
              mobileNo = "",
              roleId = "",
              isActive = "",
              isPasswordChanged = "",
              organizationId = "",
              dob = "",
              tempPassword = "",
              isArchived = "",
              __v1 = "",
              profilePicture = "";
          String __v = recomdenationMap[j]['__v'].toString();
          try {
            _id1 = recomdenationMap[j]['recommender'][0]['_id'].toString();
            userId1 =
                recomdenationMap[j]['recommender'][0]['userId'].toString();
            firstName =
                recomdenationMap[j]['recommender'][0]['firstName'].toString();
            lastName =
                recomdenationMap[j]['recommender'][0]['lastName'].toString();
            email = recomdenationMap[j]['recommender'][0]['email'].toString();
            password =
                recomdenationMap[j]['recommender'][0]['password'].toString();
            salt = recomdenationMap[j]['recommender'][0]['salt'].toString();
            mobileNo =
                recomdenationMap[j]['recommender'][0]['mobileNo'].toString();
            roleId = recomdenationMap[j]['recommender'][0]['roleId'].toString();
            isActive =
                recomdenationMap[j]['recommender'][0]['isActive'].toString();
            isPasswordChanged = recomdenationMap[j]['recommender'][0]
                    ['isPasswordChanged']
                .toString();
            organizationId = recomdenationMap[j]['recommender'][0]
                    ['organizationId']
                .toString();
            dob = recomdenationMap[j]['recommender'][0]['dob'].toString();

//user defined recommender title

            //recomdenationMap[j]['recommender']['title'].toString();
            tempPassword = recomdenationMap[j]['recommender'][0]['tempPassword']
                .toString();
            isArchived =
                recomdenationMap[j]['recommender'][0]['isArchived'].toString();
            __v1 =
                recomdenationMap[j]['recommender'][0]['isArchived'].toString();
            profilePicture = recomdenationMap[j]['recommender'][0]
                    ['profilePicture']
                .toString();
          } catch (e) {}

          String title1 = recommenderTitle;
          Recommender recommender = Recommender(
              "",
              userId1,
              firstName,
              lastName,
              email,
              password,
              salt,
              mobileNo,
              roleId,
              isActive,
              isPasswordChanged,
              organizationId,
              dob,
              title1,
              tempPassword,
              isArchived,
              profilePicture,
              __v1);

          User user = User("", "", "", "", "", "", "", "");
          if (recomdenationMap[j]['user'] != null) {
            String firstNameUser =
                recomdenationMap[j]['user']['firstName'].toString();
            String lastNameUser =
                recomdenationMap[j]['user']['lastName'].toString();
            String emailUser = recomdenationMap[j]['user']['email'].toString();
            String profilePictureUser =
                recomdenationMap[j]['user']['profilePicture'].toString();

            String tagline = recomdenationMap[j]['user']['tagline'].toString();
            String titleUser = recomdenationMap[j]['user']['title'].toString();
            String userId = recomdenationMap[j]['user']['userId'].toString();
            String roleId = recomdenationMap[j]['user']['roleId'].toString();
            user = User(firstNameUser, lastNameUser, profilePictureUser,
                emailUser, tagline, titleUser, userId, roleId);
          }

          if (isEditable) {
            recommendationtList.add(new Recomdation(
                _id,
                recommendationId,
                userId,
                recommenderId,
                isReminderEnable,
                type,
                recomendedRoleId,
                competencyTypeId,
                level3Competency,
                level2Competency,
                title,
                request,
                recommendation,
                stage,
                interactionStartDate,
                interactionEndDate,
                requestedDate,
                reminderDay,
                repliedDate,
                isActiveRecomendation,
                __v,
                null,
                skillList,
                assestList,
                certificateList,
                badgeList,
                recommender,
                user,
                false,
                trophyList,
                mediaList,
                recommenderFile,
                recommenderFileName,
                mediaVideoList,
                isLevel3Other,
                focusArea));
          } else {
            if (stage == "Added") {
              recommendationtList.add(new Recomdation(
                  _id,
                  recommendationId,
                  userId,
                  recommenderId,
                  isReminderEnable,
                  type,
                  recomendedRoleId,
                  competencyTypeId,
                  level3Competency,
                  level2Competency,
                  title,
                  request,
                  recommendation,
                  stage,
                  interactionStartDate,
                  interactionEndDate,
                  requestedDate,
                  reminderDay,
                  repliedDate,
                  isActiveRecomendation,
                  __v,
                  null,
                  skillList,
                  assestList,
                  certificateList,
                  badgeList,
                  recommender,
                  user,
                  false,
                  trophyList,
                  mediaList,
                  recommenderFile,
                  recommenderFileName,
                  mediaVideoList,
                  isLevel3Other,
                  focusArea));
            }
          }
        } catch (e) {}
      }
      return recommendationtList;
    } catch (e) {
      print("recommendation++++++++" + e.toString());
      return recommendationtList;
    }
  }

  static List<Recomdation> parseShareProfileRecomendatioAdded(
      recomdenationMap) {
    List<Recomdation> recommendationtList = List<Recomdation>();

    try {
      for (int j = 0; j < recomdenationMap.length; j++) {
        List<String> badgeList = List();
        List<String> mediaList = List();
        List<String> trophyList = List();
        List<String> certificateList = List();

        String _id = recomdenationMap[j]['_id'].toString();

        String recommendationId =
            recomdenationMap[j]['recommendationId'].toString();

        String recommenderFile =
            recomdenationMap[j]['recommenderFile'].toString();

        String recommenderFileName =
            recomdenationMap[j]['recommenderFileName'].toString();
        if (recommenderFileName == "null") {
          recommenderFileName = "";
        }
        String userId = recomdenationMap[j]['userId'].toString();
        String isReminderEnable =
            recomdenationMap[j]['isReminderEnable'].toString();
        String type = recomdenationMap[j]['type'].toString();
        String recomendedRoleId = recomdenationMap[j]['roleId'].toString();
        String isLevel3Other = recomdenationMap[j]['isLevel3Other'].toString();
        String recommenderId = recomdenationMap[j]['recommenderId'].toString();
        String competencyTypeId =
            recomdenationMap[j]['competencyTypeId'].toString();

        String level3Competency =
            recomdenationMap[j]['level3Competency'].toString();
        String focusArea = recomdenationMap[j]['level3Competency'].toString();
        if (focusArea == "null") {
          focusArea = level3Competency;
        }
        String level2Competency =
            recomdenationMap[j]['level2Competency'].toString();
        String title = recomdenationMap[j]['title'].toString();
        String request = recomdenationMap[j]['request'].toString();
        String recommendation =
            recomdenationMap[j]['recommendation'].toString();
        String stage = recomdenationMap[j]['stage'].toString();

        String interactionStartDate =
            recomdenationMap[j]['interactionStartDate'].toString();
        String interactionEndDate =
            recomdenationMap[j]['interactionEndDate'].toString();
        String requestedDate = recomdenationMap[j]['requestedDate'].toString();
        String reminderDay = recomdenationMap[j]['reminderDay'].toString();

        String repliedDate = recomdenationMap[j]['repliedDate'].toString();
        String isActiveRecomendation =
            recomdenationMap[j]['isActive'].toString();

        if (requestedDate == null) {
          requestedDate = interactionStartDate;
        }
        if (repliedDate == null) {
          repliedDate = interactionStartDate;
        }
        List<Assest> assestList = List<Assest>();
        List<Assest> mediaVideoList = List<Assest>();

        var asetMap = recomdenationMap[j]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            //  file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, "", false));

            try {
              if (type == "null" || type == "") {
                var fileList = asetMap[k]['file'];
                for (int l = 0; l < fileList.length; l++) {
                  file = fileList[l]['file'].toString();
                  type = fileList[l]['type'].toString();
                  mediaVideoList.add(new Assest(type, tag, file, "", false));
                }
              } else {
                mediaVideoList.add(new Assest(type, tag, file, "", false));
              }
            } catch (e) {}
            if (tag == "certificates") {
              certificateList.add(file);
            } else if (tag == "badges") {
              badgeList.add(file);
            } else if (tag == "trophy") {
              trophyList.add(file);
              //badgeList.add(file);
            } else {
              mediaList.add(file);
            }
          }
        }
        List<Skill> skillList = List<Skill>();

        var skillMap = recomdenationMap[j]['skills'];
        if (skillMap != null) {
          for (int l = 0; l < skillMap.length; l++) {
            String label = skillMap[l]['label'].toString();
            String skillId = skillMap[l]['skillId'].toString();
            // var sklid = int.tryParse(skillMap[l]['skillId'].toString()) ?? 0;
            //String skillId = sklid.toString();

            skillList.add(new Skill(label, skillId, l));
          }
        }
        String __v = recomdenationMap[j]['__v'].toString();

        String _id1 = recomdenationMap[j]['recommender']['_id'].toString();
        String userId1 =
            recomdenationMap[j]['recommender']['userId'].toString();
        String firstName =
            recomdenationMap[j]['recommender']['firstName'].toString();
        String lastName =
            recomdenationMap[j]['recommender']['lastName'].toString();
        String email = recomdenationMap[j]['recommender']['email'].toString();
        String password =
            recomdenationMap[j]['recommender']['password'].toString();
        String salt = recomdenationMap[j]['recommender']['salt'].toString();
        String mobileNo =
            recomdenationMap[j]['recommender']['mobileNo'].toString();
        String roleId = recomdenationMap[j]['recommender']['roleId'].toString();
        String isActive =
            recomdenationMap[j]['recommender']['isActive'].toString();
        String isPasswordChanged =
            recomdenationMap[j]['recommender']['isPasswordChanged'].toString();
        String organizationId =
            recomdenationMap[j]['recommender']['organizationId'].toString();
        String dob = recomdenationMap[j]['recommender']['dob'].toString();
        String title1 = recomdenationMap[j]['recommender']['title'].toString();
        String tempPassword =
            recomdenationMap[j]['recommender']['tempPassword'].toString();
        String isArchived =
            recomdenationMap[j]['recommender']['isArchived'].toString();
        String __v1 =
            recomdenationMap[j]['recommender']['isArchived'].toString();
        String profilePicture =
            recomdenationMap[j]['recommender']['profilePicture'].toString();

        if (stage == "Added") {
          Recommender recommender = Recommender(
              _id1,
              userId1,
              firstName,
              lastName,
              email,
              password,
              salt,
              mobileNo,
              roleId,
              isActive,
              isPasswordChanged,
              organizationId,
              dob,
              title1,
              tempPassword,
              isArchived,
              profilePicture,
              __v1);
          User user = User("", "", "", "", "", "", "", "");
          if (recomdenationMap[j]['user'] != null) {
            String firstNameUser =
                recomdenationMap[j]['user']['firstName'].toString();
            String lastNameUser =
                recomdenationMap[j]['user']['lastName'].toString();
            String emailUser = recomdenationMap[j]['user']['email'].toString();
            String profilePictureUser =
                recomdenationMap[j]['user']['profilePicture'].toString();

            String tagline = recomdenationMap[j]['user']['tagline'].toString();

            String titleUser = recomdenationMap[j]['user']['title'].toString();
            String userId = recomdenationMap[j]['user']['userId'].toString();
            String roleId = recomdenationMap[j]['user']['roleId'].toString();
            user = User(firstNameUser, lastNameUser, profilePictureUser,
                emailUser, tagline, titleUser, userId, roleId);
          }
          recommendationtList.add(new Recomdation(
              _id,
              recommendationId,
              userId,
              recommenderId,
              isReminderEnable,
              type,
              recomendedRoleId,
              competencyTypeId,
              level3Competency,
              level2Competency,
              title,
              request,
              recommendation,
              stage,
              interactionStartDate,
              interactionEndDate,
              requestedDate,
              reminderDay,
              repliedDate,
              isActiveRecomendation,
              __v,
              null,
              skillList,
              assestList,
              certificateList,
              badgeList,
              recommender,
              user,
              false,
              trophyList,
              mediaList,
              recommenderFile,
              recommenderFileName,
              mediaVideoList,
              isLevel3Other,
              focusArea));
        }
      }
      return recommendationtList;
    } catch (e) {
      return recommendationtList;
    }
  }

  //shubham
  static List<Recomdation> parseShareMapRecommdation(recomdenationMap) {
    List<Recomdation> recommendationtList = List<Recomdation>();

    try {
      for (int j = 0; j < recomdenationMap.length; j++) {
        List<String> badgeList = List();
        List<String> mediaList = List();
        List<String> trophyList = List();
        List<String> certificateList = List();
        String _id = "";

        String recommendationId =
            recomdenationMap[j]['recommendationId'].toString();
        String recommenderFile =
            recomdenationMap[j]['recommenderFile'].toString();
        String recommenderFileName =
            recomdenationMap[j]['recommenderFileName'].toString();

        if (recommenderFileName == "null") {
          recommenderFileName = "";
        }

        String userId = recomdenationMap[j]['userId'].toString();
        String isReminderEnable =
            recomdenationMap[j]['isReminderEnable'].toString();
        String type = recomdenationMap[j]['type'].toString();
        String recomendedRoleId = recomdenationMap[j]['roleId'].toString();
        String recommenderRoleId =
            recomdenationMap[j]['recommenderRoleId'].toString();
        String isLevel3Other = recomdenationMap[j]['isLevel3Other'].toString();
        String recommenderId = recomdenationMap[j]['recommenderId'].toString();
        String competencyTypeId =
            recomdenationMap[j]['competencyTypeId'].toString();
        String level3Competency =
            recomdenationMap[j]['level3Competency'].toString();
        String focusArea = recomdenationMap[j]['level3Competency'].toString();

        if (focusArea == "null") {
          focusArea = level3Competency;
        }

        String level2Competency =
            recomdenationMap[j]['level2Competency'].toString();
        String title = recomdenationMap[j]['title'].toString();
        String request = recomdenationMap[j]['request'].toString();
        String recommendation =
            recomdenationMap[j]['recommendation'].toString();
        String stage = "";
        try {
          stage = recomdenationMap[j]['stage'].toString();
        } catch (e) {
          stage = "";
        }
        String interactionStartDate =
            recomdenationMap[j]['interactionStartDate'].toString();
        String interactionEndDate =
            recomdenationMap[j]['interactionEndDate'].toString();

        String requestedDate = recomdenationMap[j]['requestedDate'].toString();
        String reminderDay = recomdenationMap[j]['reminderDay'].toString();

        String repliedDate = recomdenationMap[j]['repliedDate'].toString();
        String isActiveRecomendation =
            recomdenationMap[j]['isActive'].toString();
        if (requestedDate == null) {
          requestedDate = interactionStartDate;
        }

        if (repliedDate == null) {
          repliedDate = interactionStartDate;
        }

        List<Assest> assestList = List<Assest>();
        List<Assest> mediaVideoList = List<Assest>();

        var assetList = recomdenationMap[j]['asset'];

        for (int k = 0; k < assetList.length; k++) {
          if (assetList[k] != null) {
            if (assetList[k] is String) {
              // Handle the case where asset is a string
              String file = assetList[k];
              String type =
                  ""; // You may set type and tag to empty strings or handle them differently
              String tag = "";

              print("asset is a string: $file");

              file = getMediumImage(file);

              assestList.add(new Assest(type, tag, file, "", false));

              // Handle tag-specific lists here if needed (e.g., certificateList, badgeList, trophyList, mediaList)
            } else if (assetList[k] is Map<String, dynamic>) {
              // Handle the case where asset is a complex structure
              String type = assetList[k]['type'].toString();
              String tag = assetList[k]['tag'].toString();
              String file = assetList[k]['file'].toString();

              print("asset type is $type");
              print("asset tag is $tag");
              print("asset file is $file");

              file = getMediumImage(file);

              assestList.add(new Assest(type, tag, file, "", false));

              try {
                if (type == "null" || type == "") {
                  var fileList = assetList[k]['file'];
                  for (int l = 0; l < fileList.length; l++) {
                    file = fileList[l]['file'].toString();
                    type = fileList[l]['type'].toString();
                    mediaVideoList.add(new Assest(type, tag, file, "", false));
                  }
                } else {
                  mediaVideoList.add(new Assest(type, tag, file, "", false));
                }
              } catch (e) {}

              // Handle tag-specific lists here if needed (e.g., certificateList, badgeList, trophyList, mediaList)
            }
          }
        }
        List<Skill> skillList = List<Skill>();

        var skillMap = recomdenationMap[j]['skills'];
        for (int l = 0; l < skillMap.length; l++) {
          String label = skillMap[l]['label'].toString();
          String skillId = skillMap[l]['skillId'].toString();
          //  String skillId = "${skillMap[l]['skillId']}";

          skillList.add(new Skill(label, skillId, l));
        }
        User user = User("", "", "", "", "", "", "", "");
        if (recomdenationMap[j]['user'] != null) {
          String firstNameUser =
              recomdenationMap[j]['user']['firstName'].toString();
          String lastNameUser =
              recomdenationMap[j]['user']['lastName'].toString();
          String emailUser = recomdenationMap[j]['user']['email'].toString();
          String profilePictureUser =
              recomdenationMap[j]['user']['profilePicture'].toString();

          String tagline = recomdenationMap[j]['user']['tagline'].toString();
          String titleUser = recomdenationMap[j]['user']['title'].toString();
          String userId = recomdenationMap[j]['user']['userId'].toString();
          String roleId = recomdenationMap[j]['user']['roleId'].toString();
          user = User(firstNameUser, lastNameUser, profilePictureUser,
              emailUser, tagline, titleUser, userId, roleId);
        }

        recommendationtList.add(new Recomdation(
            _id,
            recommendationId,
            userId,
            recommenderId,
            isReminderEnable,
            type,
            recomendedRoleId,
            competencyTypeId,
            level3Competency,
            level2Competency,
            title,
            request,
            recommendation,
            stage,
            interactionStartDate,
            interactionEndDate,
            requestedDate,
            reminderDay,
            repliedDate,
            isActiveRecomendation,
            "",
            null,
            skillList,
            assestList,
            certificateList,
            badgeList,
            null,
            user,
            false,
            trophyList,
            mediaList,
            recommenderFile,
            recommenderFileName,
            mediaVideoList,
            isLevel3Other,
            focusArea,
            recommenderRoleId: recommenderRoleId));
      }
      return recommendationtList;
    } catch (e) {
      print("recomndation parser ${e.toString()}");
      return recommendationtList;
    }
  }

  static List<OrganizationModal> parseMapOrganization(organizationMap, sType) {
    List<OrganizationModal> organizationLst = List<OrganizationModal>();

    try {
      for (int j = 0; j < organizationMap.length; j++) {
        String organizationId = '';
        if (sType == 'school') {
          organizationId = organizationMap[j]['schoolId'].toString();
        } else {
          organizationId = organizationMap[j]['organizationId'].toString();
        }

        String name = organizationMap[j]['name'].toString();
        String description = organizationMap[j]['description'].toString();
        String type = organizationMap[j]['type'].toString();
        String logo = organizationMap[j]['logo'].toString();
        String schoolCode = organizationMap[j]['schoolCode'].toString();
        String city = organizationMap[j]['city'].toString();
        String state = organizationMap[j]['state'].toString();
        String address = organizationMap[j]['address'].toString();

        if (organizationId == null || organizationId == 'null') {
          organizationId = '';
        }

        organizationLst.add(new OrganizationModal(organizationId, name,
            description, type, logo, schoolCode, city, state, address));
      }
    } catch (e) {}
    return organizationLst;
  }

  static List<AchievementImportanceModal> parseMapLevelList(map) {
    List<AchievementImportanceModal> achievementImportanceList =
        List<AchievementImportanceModal>();

    try {
      for (int j = 0; j < map.length; j++) {
        String importanceId = map[j]['importanceId'].toString();
        String title = map[j]['title'].toString();
        String description = map[j]['description'].toString();

        achievementImportanceList
            .add(AchievementImportanceModal(importanceId, title, description));
      }
    } catch (e) {
      e.toString();
    }
    return achievementImportanceList;
  }

  static List<AcvhievmentSkillModel> parseMapSkillList(map) {
    List<AcvhievmentSkillModel> achievementImportanceList =
        List<AcvhievmentSkillModel>();
    achievementImportanceList
        .add(new AcvhievmentSkillModel("0", "Select All", "dfvfv"));
    try {
      for (int j = 0; j < map.length; j++) {
        String skillId = map[j]['skillId'].toString();
        String title = map[j]['title'].toString();
        String description = map[j]['description'].toString();

        achievementImportanceList
            .add(new AcvhievmentSkillModel(skillId, title, description));
      }
    } catch (e) {}
    return achievementImportanceList;
  }

  static List<CompetencyModel> parseMapCompetency(competencyMap) {
    List<CompetencyModel> listCompetency = List();
    try {
      for (int j = 0; j < competencyMap.length; j++) {
        List<Level2Competencies> level2Competencylist = List();
        String level1 = competencyMap[j]['level1'].toString();
        var level2 = competencyMap[j]['level2'];
        for (int k = 0; k < level2.length; k++) {
          try {
            String name = level2[k]['name'].toString();
            String competencyTypeId = level2[k]['competencyTypeId'].toString();
            var level3 = level2[k]['level3'];
            List<Level3Competencies> level3Competencylist = List();
            if (level3 != null) {
              for (int l = 0; l < level3.length; l++) {
                String name = level3[l]['name'].toString();
                String key = level3[l]['key'].toString();
                level3Competencylist.add(new Level3Competencies(name, key));
              }
            }
            level2Competencylist.add(new Level2Competencies(
                name, competencyTypeId, false, level3Competencylist));
          } catch (e) {
            print("errorrr+++" + e.toString());
          }
        }
        listCompetency
            .add(CompetencyModel(level1, level2Competencylist, false, false));
      }
    } catch (e) {}
    return listCompetency;
  }

  static List<CompetencyModel> parseMapCompetency2(competencyMap) {
    List<CompetencyModel> listCompetency = List();
    try {
      for (int j = 0; j < competencyMap.length; j++) {
        List<Level2Competencies> level2Competencylist = List();
        String level1 = competencyMap[j]['level1'].toString();
        var level2 = competencyMap[j]['level2'];
        for (int k = 0; k < level2.length; k++) {
          try {
            String name = level2[k]['name'].toString();
            String competencyTypeId = level2[k]['competencyTypeId'].toString();
            var level3 = level2[k]['level3'];
            List<Level3Competencies> level3Competencylist = List();
            if (level3 != null) {
              for (int l = 0; l < level3.length; l++) {
                String name = level3[l]['name'].toString();
                String key = level3[l]['key'].toString();
                level3Competencylist.add(new Level3Competencies(name, key));
              }
            }
            level2Competencylist.add(new Level2Competencies(
                name, competencyTypeId, false, level3Competencylist));
          } catch (e) {
            print("errorrr+++" + e.toString());
          }
        }
        listCompetency
            .add(CompetencyModel(level1, level2Competencylist, false, false));
      }
    } catch (e) {}
    return listCompetency;
  }

  static Map<String, List<Level3Competencies>> parseMapMasterCompetency(
      competencyMap) {
    Map<String, List<Level3Competencies>> listCompetency = Map();
    try {
      for (int j = 0; j < competencyMap.length; j++) {
        String level2 = competencyMap[j]['level2'];

        var level3 = competencyMap[j]['level3'];
        List<Level3Competencies> level3Competencylist = List();
        for (int l = 0; l < level3.length; l++) {
          String name = level3[l]['name'].toString();
          String key = level3[l]['key'].toString();
          level3Competencylist.add(new Level3Competencies(name, key));
        }

        listCompetency.putIfAbsent(level2, () => level3Competencylist);
      }

      // listCompetency.add(new CompetencyMasterDataModel(level2, level3Competencylist));
      //}
    } catch (e) {}
    return listCompetency;
  }

  static List<DashBoardDetailModel> parseDasboardDataModel(competencyMap) {
    List<DashBoardDetailModel> dataList = List();
    try {
      for (int j = 0; j < competencyMap.length; j++) {
        String actedBy = competencyMap[j]['actedBy'].toString();
        String profileImage = competencyMap[j]['profileImage'].toString();
        String actedOn = competencyMap[j]['actedOn'].toString();
        String actedUserId = competencyMap[j]['actedUserId'].toString();
        String message1 = competencyMap[j]['message1'].toString();
        String message2 = competencyMap[j]['message2'].toString();

        String badgeImage = competencyMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = competencyMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = competencyMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        if (message1 == "null") message1 = "";
        if (message2 == "null") message2 = "";
        if (actedOn == "null") actedOn = "";
        print("dataList=====" + profileImage);
        String actedRoleId = competencyMap[j]['actedRoleId'].toString();

        dataList.add(new DashBoardDetailModel(
            actedBy,
            profileImage,
            actedOn,
            actedUserId,
            message1,
            message2,
            actedRoleId,
            badge,
            gamificationPoints,
            badgeImage));
      }

      // listCompetency.add(new CompetencyMasterDataModel(level2, level3Competencylist));
      //}
    } catch (e) {}
    return dataList;
  }

  static List<StudentDataModel> parseMapStudentByParent(competencyMap) {
    List<StudentDataModel> listStudent = List();
    try {
      for (int j = 0; j < competencyMap.length; j++) {
        print("Map=====" + competencyMap[j].toString());
        String userId = competencyMap[j]['userId'].toString();
        String firstName = competencyMap[j]['firstName'].toString();
        String lastName = competencyMap[j]['lastName'].toString();
        String email = competencyMap[j]['email'].toString();
        String mobileNo = competencyMap[j]['mobileNo'].toString();
        String stage = competencyMap[j]['stage'].toString();
        String profilePicture = competencyMap[j]['profilePicture'].toString();
        // profilePicture= getMediumImage(profilePicture);

        //try{
        String badgeImage = competencyMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = competencyMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = competencyMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }
        /*}catch(e){

        }*/

        String roleId = competencyMap[j]['roleId'].toString();
        String isActive = competencyMap[j]['isActive'].toString();
        String isHide = competencyMap[j]['isHide'].toString();
        if (isHide == null || isHide == "null") {
          isHide = "false";
        }
        String requireParentApproval =
            competencyMap[j]['requireParentApproval'].toString();
        String ccToParents = competencyMap[j]['ccToParents'].toString();
        String lastAccess = competencyMap[j]['lastAccess'].toString();
        String isPasswordChanged =
            competencyMap[j]['isPasswordChanged'].toString();
        String organizationId = competencyMap[j]['organizationId'].toString();
        String gender = competencyMap[j]['gender'].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String dob = competencyMap[j]['dob'].toString();
        String genderAtBirth = competencyMap[j]['genderAtBirth'].toString();
        if (genderAtBirth == "Non-binary" || genderAtBirth == "NonBinary") {
          genderAtBirth = "Non-Binary";
        }
        String usCitizenOrPR = competencyMap[j]['usCitizenOrPR'].toString();
        String summary = competencyMap[j]['summary'].toString();
        String coverImage = competencyMap[j]['coverImage'].toString();
        String tagline = competencyMap[j]['tagline'].toString();
        String title = competencyMap[j]['title'].toString();
        String tempPassword = competencyMap[j]['tempPassword'].toString();
        String isArchived = competencyMap[j]['isArchived'].toString();
        String isAchievement = competencyMap[j]['isAchievement'].toString();
        String isEducation = competencyMap[j]['isEducation'].toString();
        String isWizard = competencyMap[j]['isWizard'].toString();
        if (isWizard == null || isWizard == "null") {
          isWizard = "false";
        }
        /*  String isWizardCompleted = "";
        try {
          String isWizardCompleted =
              competencyMap[j]['isWizardCompleted'].toString();
          if (isWizardCompleted == "" || isWizardCompleted == null) {
            isWizardCompleted = "false";
          }
        } catch (e) {
          isWizardCompleted = "false";
        }
        if (isWizardCompleted == null) {
          isWizardCompleted = "false";
        }
        print("shubh" + isWizardCompleted+"test");*/
        var parentMap = competencyMap[j]['parents'];
        List<Parents> parentList = List();
        for (int k = 0; k < parentMap.length; k++) {
          String email = parentMap[k]['email'].toString();
          String userId = parentMap[k]['userId'].toString();
          String firstName = parentMap[k]['firstName'].toString();
          String lastName = parentMap[k]['lastName'].toString();
          String profilePicture = parentMap[k]['profilePicture'].toString();
          parentList
              .add(Parents(email, userId, profilePicture, firstName, lastName));
        }
        var activityMap = competencyMap[j]['activity'];
        List<ActivityLog> activityLog = List();

        for (int k = 0; k < activityMap.length; k++) {
          String categoryId = activityMap[k]['categoryId'].toString();
          String title = activityMap[k]['title'].toString();
          String count = activityMap[k]['count'].toString();
          String image = activityMap[k]['image'].toString();

          activityLog.add(new ActivityLog(categoryId, title, count, image));
        }

        var addressMap = competencyMap[j]['address'];
        Address addressModal = null;
        if (addressMap != null) {
          String street1 = addressMap['street1'].toString();
          String street2 = addressMap['street2'].toString();
          String city = addressMap['city'].toString();
          String state = addressMap['state'].toString();
          String country = addressMap['country'].toString();
          String zip = addressMap['zip'].toString();
          String target = addressMap['target'].toString();
          addressModal =
              Address(street1, street2, city, state, country, zip, target);
        }
        bool isCoomunitySetting = false;
        bool isLeaderboardDisplay = false;
        try {
          isLeaderboardDisplay = competencyMap[j]["isLeaderboardDisplay"];
        } catch (e) {}
        try {
          var communityPostSubscription =
              competencyMap[j]["communityPostSubscription"];
          if (communityPostSubscription != null &&
              communityPostSubscription.length > 0) {
            for (int i = 0; i < communityPostSubscription.length; i++) {
              if (communityPostSubscription[i]["roleId"].toString() == "1") {
                print("Community+++++++" +
                    communityPostSubscription[i]["isSubscribed"].toString());
                isCoomunitySetting =
                    communityPostSubscription[i]["isSubscribed"];
              }
            }
          }
        } catch (e) {}

        listStudent.add(new StudentDataModel(
            userId,
            firstName,
            lastName,
            email,
            mobileNo,
            profilePicture,
            roleId,
            isActive,
            requireParentApproval,
            ccToParents,
            lastAccess,
            isPasswordChanged,
            organizationId,
            gender,
            dob,
            genderAtBirth,
            usCitizenOrPR,
            summary,
            coverImage,
            tagline,
            title,
            tempPassword,
            isArchived,
            parentList,
            addressModal,
            isAchievement,
            isEducation,
            isWizard,
            activityLog,
            isHide,
            stage,
            isCoomunitySetting,
            isLeaderboardDisplay,
            badge,
            gamificationPoints,
            badgeImage));
      }
    } catch (e) {
      e.toString();
    }
    return listStudent;
  }

  static List<TagModel> parseTagList(map) {
    List<TagModel> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String profilePicture = map[k]['partner']['profilePicture'].toString();
        String userId = map[k]['partner']['userId'].toString();
        String firstName = map[k]['partner']['firstName'].toString();
        String lastName = map[k]['partner']['lastName'].toString();
        String email = map[k]['partner']['email'].toString();
        String roleId = map[k]['partnerRoleId'].toString();
        String isActive = map[k]['partner']['isActive'].toString();
        print("partner role++   " + map[k].toString());
        print("partner role partner++   " + map[k]['partner'].toString());

        String badgeImage = map[k]['partner']['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map[k]['partner']['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            map[k]['partner']['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        if (userId != "1" && isActive == "true") {
          tagList.add(new TagModel(
              userId,
              firstName,
              lastName,
              email,
              profilePicture,
              false,
              roleId,
              badge,
              gamificationPoints,
              badgeImage));
        }
      }

      //}
    } catch (e) {}
    return tagList;
  }

  static List<RequestedTagModel> parseRequestedTagList(map) {
    List<RequestedTagModel> tagList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String _id = map[k]['_id'].toString();
        String connectId = map[k]['connectId'].toString();
        String userId = map[k]['userId'].toString();
        String userRoleId = map[k]['userRoleId'].toString();
        String partnerId = map[k]['partnerId'].toString();
        String partnerRoleId = map[k]['partnerRoleId'].toString();
        String dateTime = map[k]['dateTime'].toString();
        String status = map[k]['status'].toString();

        String userIsActive = map[k]['user']['isActive'].toString();
        String user_Id = map[k]['user']['userId'].toString();
        String user_firstName = map[k]['user']['firstName'].toString();
        String user_lastName = map[k]['user']['lastName'].toString();

        String userBadgeImage = map[k]['user']['badgeImage'].toString();
        if (userBadgeImage == "null" || userBadgeImage == "") {
          userBadgeImage = "";
        }
        String userBadge = map[k]['user']['badge'].toString();
        if (userBadge == "null" || userBadge == "") {
          userBadge = "";
        }
        String userGamification =
            map[k]['user']['gamificationPoints'].toString();
        int userGamificationPoints;
        if (userGamification == "null" || userGamification == "") {
          userGamificationPoints = 0;
        } else {
          userGamificationPoints = int.parse(userGamification);
        }
        if (userGamificationPoints == null) {
          userGamificationPoints = 0;
        }

        String user_email = map[k]['user']['email'].toString();
        String user_profilePicture =
            map[k]['user']['profilePicture'].toString();
        String user_dob = map[k]['user']['dob'].toString();
        String user_roleId = map[k]['user']['roleId'].toString();
        String user_tagline = map[k]['user']['tagline'].toString();

        UserData userData = UserData(
            user_Id,
            user_firstName,
            user_lastName,
            user_email,
            user_profilePicture,
            userIsActive,
            user_dob,
            user_roleId,
            user_tagline,
            userBadge,
            userGamificationPoints,
            userBadgeImage);

        String id = map[k]['partner']['id'].toString();
        String userId2 = map[k]['partner']['userId'].toString();
        String firstName = map[k]['partner']['firstName'].toString();
        String lastName = map[k]['partner']['lastName'].toString();
        String email = map[k]['partner']['email'].toString();
        String password = map[k]['partner']['password'].toString();
        String salt = map[k]['partner']['salt'].toString();
        String mobileNo = map[k]['partner']['mobileNo'].toString();
        String roleId = map[k]['partner']['roleId'].toString();
        String isActive = map[k]['partner']['isActive'].toString();
        String isPasswordChanged =
            map[k]['partner']['isPasswordChanged'].toString();
        String organizationId = map[k]['partner']['organizationId'].toString();
        String dob = map[k]['partner']['dob'].toString();
        String isArchived = map[k]['partner']['isArchived'].toString();
        String profilePicture = map[k]['partner']['profilePicture'].toString();
        String requireParentApproval =
            map[k]['partner']['requireParentApproval'].toString();
        String ccToParents = map[k]['partner']['ccToParents'].toString();
        String lastAccess = map[k]['partner']['lastAccess'].toString();
        String gender = map[k]['partner']['gender'].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String genderAtBirth = map[k]['partner']['genderAtBirth'].toString();
        if (genderAtBirth == "Non-binary" || genderAtBirth == "NonBinary") {
          genderAtBirth = "Non-Binary";
        }
        String usCitizenOrPR = map[k]['partner']['usCitizenOrPR'].toString();
        String address = map[k]['partner']['address'].toString();
        String summary = map[k]['partner']['summary'].toString();
        String coverImage = map[k]['partner']['coverImage'].toString();
        String tagline = map[k]['partner']['tagline'].toString();
        String title = map[k]['partner']['title'].toString();
        String creationTime = map[k]['partner']['creationTime'].toString();
        String tempPassword = map[k]['partner']['tempPassword'].toString();

        String badgeImage = map[k]['partner']['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map[k]['partner']['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            map[k]['partner']['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        print("data+++" + firstName + "  " + roleId);

        Patner patner = Patner(
            id,
            userId2,
            firstName,
            lastName,
            email,
            password,
            salt,
            mobileNo,
            roleId,
            isActive,
            isPasswordChanged,
            organizationId,
            dob,
            isArchived,
            profilePicture,
            requireParentApproval,
            ccToParents,
            lastAccess,
            gender,
            genderAtBirth,
            usCitizenOrPR,
            address,
            summary,
            coverImage,
            tagline,
            title,
            tempPassword,
            "",
            creationTime,
            badge,
            gamificationPoints,
            badgeImage);
        if (userId2 == "1") {
          tagList.insert(
              0,
              RequestedTagModel(
                  _id,
                  connectId,
                  userId,
                  userRoleId,
                  partnerId,
                  partnerRoleId,
                  dateTime,
                  status,
                  userIsActive,
                  patner,
                  userData));
        } else {
          tagList.add(new RequestedTagModel(
              _id,
              connectId,
              userId,
              userRoleId,
              partnerId,
              partnerRoleId,
              dateTime,
              status,
              userIsActive,
              patner,
              userData));
        }
      }
    } catch (e) {}
    return tagList;
  }

  static List<RefferalModel> parseRefferal(map) {
    List<RefferalModel> referList = List();
    try {
      for (int k = 0; k < map.length; k++) {
        String referralId = map[k]['referralId'].toString();
        String referralType = map[k]['referralType'].toString();
        String referredByID = map[k]['referredByID'].toString();
        String referredByRoleId = map[k]['referredByRoleId'].toString();
        String referredTo = map[k]['referredTo'].toString();
        String referralStatus = map[k]['referralStatus'].toString();
        String userId = map[k]['userId'].toString();
        String dateTime = map[k]['dateTime'].toString();
        String updateDateTime = map[k]['updateDateTime'].toString();
        String referredById = map[k]['referredById'].toString();
        String updateDate = map[k]['updateDate'].toString();
        referList.add(new RefferalModel(
            referralId,
            referralType,
            referredByID,
            referredByRoleId,
            referredTo,
            referralStatus,
            userId,
            dateTime,
            updateDateTime,
            referredById,
            updateDate));
      }
    } catch (e) {}
    return referList;
  }

  static List<OpportunityModelForFeed> parseOpportunity(map, useridPref) {
    List<OpportunityModelForFeed> opportunityList =
        List<OpportunityModelForFeed>();

    for (int i = 0; i < map.length; i++) {
      try {
        String opportunityId = map[i]["opportunityId"].toString();
        String userId = map[i]["userId"].toString();
        String roleId = map[i]["roleId"].toString();
        String jobTitle = map[i]["jobTitle"].toString();
        String timeZone = map[i]["timeZone"].toString();
        String jobType = map[i]["jobType"].toString();
        String schoolCode = map[i]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String jobLocation = map[i]["jobLocation"].toString();
        String project = map[i]["project"].toString();
        String duration = map[i]["duration"].toString();
        String status = map[i]["status"].toString();
        String fromDate = map[i]["fromDate"].toString();
        String toDate = map[i]["toDate"].toString();
        String groupId = map[i]["groupId"].toString();
        String targetAudience = map[i]["targetAudience"].toString();
        String title = map[i]["title"].toString();
        String gender = map[i]["gender"].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = map[i]["companyId"].toString();
        String offerId = map[i]["offerId"].toString();
        String serviceTitle = map[i]["serviceTitle"].toString();
        String serviceDesc = map[i]["serviceDesc"].toString();
        String expiresOn = map[i]["expiresOn"].toString();
        String coverPicture = map[i]["coverPicture"].toString();
        String studentJoinId = map[i]["studentJoinId"].toString();
        String companyName = map[i]["companyName"].toString();
        String profilePicture = map[i]["profilePicture"].toString();
        String category = map[i]["category"].toString();
        //String supportedOffer = map[i]["supportedOffer"].toString();
        String name = map[i]["name"].toString();
        String declineReason = map[i]["declineReason"].toString();
        String partnerStatus = map[i]["partnerStatus"].toString();
        String url, groupIdAction, callingNumber, formId, linkUrlPosition;
        bool groupIsPublic = true;
        String actionType = map[i]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          url = map[i]['callToAction'][0]['url'].toString();
          linkUrlPosition = map[i]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction = map[i]['callToAction'][0]['groupId'].toString();
          groupIsPublic = map[i]['callToAction'][0]['isPublic'];
          print("groupIsPublic+++++" + groupIsPublic.toString());
          if (groupIsPublic == null) {
            groupIsPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber = map[i]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = map[i]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        print("shubh+++" + "action" + actionType);

        List<Address> locationList = List<Address>();
        var locationMap = map[i]['location'];
        if (locationMap != null) {
          for (int i = 0; i < locationMap.length; i++) {
            String zipcode = locationMap[i]['zipcode'].toString();
            String city = locationMap[i]['city'].toString();
            String country = locationMap[i]['country'].toString();
            String state = locationMap[i]['state'].toString();
            String name = locationMap[i]['name'].toString();
            String target = locationMap[i]['target'].toString();
            locationList
                .add(Address(name, "", city, state, country, zipcode, target));
          }
        }

        List<AgeModel> ageList = List<AgeModel>();
        var ageMao = map[i]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          String to = ageMao[k]['to'].toString();
          String from = ageMao[k]['from'].toString();
// file= getMediumImage(file);

          ageList.add(new AgeModel(to, from));
        }

        List<IntrestModel> interestTypeList = List<IntrestModel>();
        try {
          var interestTypeModel = map[i]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
// file= getMediumImage(file);

            interestTypeList.add(new IntrestModel(id, name));
          }
        } catch (e) {}

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = map[i]['asset'];
        if (asetMap != null) {
          for (int k = 0; k < asetMap.length; k++) {
            String type = asetMap[k]['type'].toString();
            String tag = asetMap[k]['tag'].toString();
            String file = asetMap[k]['file'].toString();
            String label = asetMap[k]['label'].toString();
// file= getMediumImage(file);

            assestList.add(new Assest(type, tag, file, label, false));

            if (type == "image") {
              mediaList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "video") {
              videoList.add(new Assest(type, tag, file, label, false));
              assestVideoAndImage
                  .add(new Assest(type, tag, file, label, false));
            } else if (type == "doc") {
              docList.add(new Assest(type, tag, file, label, false));
            } else if (type == "google") {
              googleLinkList.add(new Assest(type, tag, file, label, false));
            }
          }
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        var userImageData = map[i]['userImage']; //
        try {
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = map[i]["supportedOffer"].toString();
        String fees = map[i]["fees"].toString();
        String description = map[i]["description"].toString();
        String bio = map[i]["bio"].toString();
        //String advisorSupportOffered = map[i]["supportedOffer"].toString();
        //String projectArea = map[i]["projectArea"].toString();
        //String qualification = map[i]["qualification"].toString();

        List<String> otherCategoryList = List<String>();
        var otherCategoryMap = map[i]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();

            otherCategoryList.add(name);
          }
        }

        List<String> otherCareerList = List<String>();
        var otherCareerMap = map[i]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();

            otherCareerList.add(name);
          }
        }
        List<String> otherSubjectList = List<String>();
        var otherSubjectMap = map[i]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();

            otherSubjectList.add(name);
          }
        }

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        try {
          var sceduleData = map[i]['schedule']; //

          try {
            if (sceduleData != null) {
              for (int k = 0; k < sceduleData.length; k++) {
                String day = sceduleData[k]['day'].toString();
                var hours = sceduleData[k]['hours'];
                //  file= getMediumImage(file);
                //HoursData hoursData;
                List<HoursData> hoursList = List();
                for (var item in hours) {
                  hoursList.add(new HoursData(
                      timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
                }
                scheduleModelParam
                    .add(new ScheduleModelParam(day: day, hours: hoursList));
              }
            }
          } catch (e) {}
        } catch (e) {}

        List<MainCategory> designationModelParam = List<MainCategory>();
        var designationData = map[i]['category']; //
        try {
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new MainCategory(
                  name: name, categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}

        List<SubCategory> subjectModelParam = List<SubCategory>();
        var subjectData = map[i]['subjects']; //
        try {
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(
                  SubCategory(name: name, subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}

        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        try {
          var qualificationData = map[i]['qualification']; //
          for (int k = 0; k < qualificationData.length; k++) {
            String name = qualificationData[k]['name'].toString();
            String isOtherS = qualificationData[k]['isOther'].toString();
            String qualificationId =
                qualificationData[k]['qualificationId'].toString();

            bool isOther = true;
            if (isOtherS == 'false') isOther = false;

            qualificationModelParam.add(new QualificationModelParam(
                name: name,
                isOther: isOther,
                qualificationId: int.parse(qualificationId)));
          }
        } catch (e) {}

        OpportunityModelForFeed opportunityModelForFeed =
            OpportunityModelForFeed(
                opportunityId,
                userId,
                roleId,
                jobTitle,
                jobType,
                jobLocation,
                project,
                duration,
                status,
                fromDate,
                toDate,
                groupId,
                targetAudience,
                title,
                gender,
                companyId,
                offerId,
                serviceTitle,
                serviceDesc,
                expiresOn,
                coverPicture,
                companyName,
                profilePicture,
                locationList,
                interestTypeList,
                ageList,
                assestList,
                assestVideoAndImage,
                videoList,
                docList,
                mediaList,
                googleLinkList,
                actionType,
                url,
                groupIdAction,
                callingNumber,
                formId,
                linkUrlPosition,
                groupIsPublic,
                studentJoinId,
                fees,
                description,
                bio,
                "",
                //menteeSupport,
                "",
                //advisorSupportOffered,
                "",
                //projectArea,
                userImageModelParam,
                "",
                //qualification,
                qualificationModelParam,
                designationModelParam,
                subjectModelParam,
                scheduleModelParam,
                category,
                name,
                "",
                //supportedOffer,
                "",
                "",
                otherSubjectList,
                otherCategoryList,
                otherCareerList,
                timeZone,
                declineReason,
                partnerStatus,
                schoolCode);
        opportunityList.add(opportunityModelForFeed);
      } catch (e) {
        print("eroor+++++" + e.toString());
      }
    }
    return opportunityList;
  }

  static List<ProfileInfoModal> parseUserFriendList(map, useridPref) {
    List<ProfileInfoModal> friendList = List<ProfileInfoModal>();

    for (int i = 0; i < map.length; i++) {
      String groupId = "";
      String groupName = "";
      String groupImage = "";
      String userId = map[i][ProfileInfoResponse.USER_ID].toString();
      try {
        groupId = map[i]['groupId'].toString();
        groupName = map[i]['groupName'].toString();
        groupImage = map[i]['groupImage'].toString();
      } catch (e) {
        groupId = "";
        groupName = "";
        groupImage = "";
      }

      String referCode = map[i][ProfileInfoResponse.referCode].toString();
      String badgeImage = map[i][ProfileInfoResponse.BADGE_IMAGE].toString();
      if (badgeImage == "null" || badgeImage == "") {
        badgeImage = "";
      }
      String badge = map[i][ProfileInfoResponse.BADGE].toString();
      if (badge == "null" || badge == "") {
        badge = "";
      }
      String gamification =
          map[i][ProfileInfoResponse.GAMIFICATION_POINTS].toString();
      int gamificationPoints;
      if (gamification == "null" || gamification == "") {
        gamificationPoints = 0;
      } else {
        gamificationPoints = int.parse(gamification);
      }
      if (gamificationPoints == null) {
        gamificationPoints = 0;
      }

      String firstName = map[i][ProfileInfoResponse.FIRSTNAME].toString();
      bool isExistingUser = map[i]['isExistingUser'];
      bool isCollegeAdded = map[i]['isCollegeAdded'];

      if (isExistingUser == null) {
        isExistingUser = false;
      }
      if (isCollegeAdded == null) {
        isCollegeAdded = false;
      }
      String status = map[i][ProfileInfoResponse.STATUS].toString();
      String statusVal = map[i][ProfileInfoResponse.STATUS_VAL].toString();

      String lastName = map[i][ProfileInfoResponse.LASTNAME].toString();
      String email = map[i][ProfileInfoResponse.EMAIL].toString();
      String stage = map[i]['stage'].toString();
      String mobileNo = map[i][ProfileInfoResponse.MOBILE].toString();
      String profilePicture =
          map[i][ProfileInfoResponse.PROFILE_PICTURE].toString();
// profilePicture= getMediumImage(profilePicture);
      String roleId = map[i][ProfileInfoResponse.ROLE_ID].toString();
      String isActive = map[i][ProfileInfoResponse.IS_ACTIVE].toString();
      String isHide = map[i][ProfileInfoResponse.IS_HIDE].toString();
      if (isHide == null || isHide == "null") {
        isHide = "false";
      }

      bool referralPopup = map[i][ProfileInfoResponse.IS_REFRREL];
      if (referralPopup == null || referralPopup == "null") {
        referralPopup = false;
      }
      bool userLoginFirstTime = map[i]['userLoginFirstTime'];
      if (userLoginFirstTime == null) {
        userLoginFirstTime = false;
      }
      String requireParentApproval =
          ""; // map[i][ProfileInfoResponse.REQUIRE_PARENT_APPROVEL].toString();
      String ccToParents =
          ""; // map[i][ProfileInfoResponse.CC_TO_PARENTS].toString();
      String lastAccess =
          ""; // map[i][ProfileInfoResponse.LAST_ACCESS].toString();
      String isPasswordChanged =
          ""; // map[i][ProfileInfoResponse.IS_PASSWORD_CHANGED].toString();
      String organizationId =
          ""; // map[i][ProfileInfoResponse.ORGANIZATION_ID].toString();
      String gender = map[i][ProfileInfoResponse.GENDER].toString();
      if (gender == "Non-binary" || gender == "NonBinary") {
        gender = "Non-Binary";
      }
      String dob = map[i][ProfileInfoResponse.DOB].toString();
      String secondaryEmail = map[i]['secondaryEmail'].toString();
      String schoolCode = map[i]['schoolCode'].toString();
      if (schoolCode == "null" || schoolCode == "") {
        schoolCode = "";
      }
      String zipCode = map[i]['zipCode'].toString();
      String genderAtBirth =
          ""; // map[i][ProfileInfoResponse.GENDER_AT_BIRTH].toString();
      String usCitizenOrPR =
          ""; // map[i][ProfileInfoResponse.US_CITIZEN_OR_PR].toString();

// var addressMap = map[i]['address'];
      Address addressModal = Address("", "", "", "", "", "", "");
/* if (addressMap != null) {
String street1 = addressMap['street1'].toString();
String street2 = addressMap['street2'].toString();
String city = addressMap['city'].toString();
String state = addressMap['state'].toString();
String country = addressMap['country'].toString();
String zip = addressMap['zip'].toString();
addressModal =  Address(street1, street2, city, state, country, zip);
}*/

      String summary = ""; // map[i][ProfileInfoResponse.SUMMARY].toString();
      String coverImage =
          ""; // map[i][ProfileInfoResponse.COVER_IMAGE].toString();
// coverImage= getMediumImage(coverImage);
      String tagline = map[i][ProfileInfoResponse.TAGLINE].toString();
      String title = ""; // map[i][ProfileInfoResponse.TITLE].toString();
      String tempPassword =
          ""; // map[i][ProfileInfoResponse.TEMP_PASSWORD].toString();
      String isArchived =
          ""; // map[i][ProfileInfoResponse.IS_ARCHIVED].toString();
      List<ParentModal> parentList = List();

/* for (int j = 0; j < map[i][ProfileInfoResponse.PARENTS].length; j++) {
String email = map[i][ProfileInfoResponse.PARENTS][j]
[ProfileInfoResponse.EMAIL]
.toString();
String userId = map[i][ProfileInfoResponse.PARENTS][j]
[ProfileInfoResponse.USER_ID]
.toString();
parentList.add(new ParentModal(email, userId));
}*/
/* if (profilePicture != "") {
strNetworkImage = profilePicture;
}*/

      var companyMap = map[i]['company'];
      Company company = Company('', '', false);
      if (companyMap != null) {
        company = Company(companyMap['name'].toString(),
            companyMap['partnerStatus'].toString(), companyMap['isActive']);
      }
      if (isActive == null || isActive == "null") {
        isActive = "false";
      }
      List<SocialLinkData> socialLinkList = List();
      var introVideo = map[i]['introVideo'] != null
          ? IntroVideo.fromJson(map[i]['introVideo'])
          : null;
      if (userId != useridPref) {
        friendList.add(new ProfileInfoModal(
            userId,
            firstName,
            lastName,
            email,
            mobileNo,
            profilePicture,
            roleId,
            isActive,
            requireParentApproval,
            ccToParents,
            lastAccess,
            isPasswordChanged,
            organizationId,
            gender,
            dob,
            genderAtBirth,
            usCitizenOrPR,
            addressModal,
            summary,
            coverImage,
            tagline,
            title,
            tempPassword,
            isArchived,
            parentList,
            false,
            groupId,
            groupName,
            groupImage,
            status,
            statusVal,
            zipCode,
            isHide,
            referralPopup,
            userLoginFirstTime,
            stage,
            "0",
            badge,
            gamificationPoints,
            badgeImage,
            referCode,
            socialLinkList,
            "",
            true,
            false,
            introVideo,
            company,
            isExistingUser,
            isCollegeAdded,
            null,
            schoolCode,
            secondaryEmail,
            "",
            true,
            true));
      }
    }
    return friendList;
  }

  static List<ProfileShareModel> parseMapShareLog(map) {
    List<ProfileShareModel> profileLogList = List<ProfileShareModel>();

    try {
      for (int j = 0; j < map.length; j++) {
        String _id = map[j]['_id'].toString();
        String sharedId = map[j]['sharedId'].toString();
        String sharedType = map[j]['sharedType'].toString();
        String profileOwner = map[j]['profileOwner'].toString();
        String profileOwnerRole = map[j]['profileOwnerRole'].toString();
        String shareTime = map[j]['shareTime'].toString();
        String isActive = map[j]['isActive'].toString();
        String isViewed = map[j]['isViewed'].toString();
        String shareTo = map[j]['shareTo'].toString();
        String shareToFirstName = map[j]['shareToFirstName'].toString();
        String shareToLastName = map[j]['shareToLastName'].toString();
        String shareToEmail = map[j]['shareToEmail'].toString();
        String roleId = map[j]['roleId'].toString();
        String shareToprofilePicture =
            map[j]['shareToprofilePicture'].toString();

        String badgeImage = map[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = map[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        if (shareTime != "" && shareTime != "null") {
          int d = int.tryParse(shareTime);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat('MMM dd, yyyy');

          shareTime = f.format(
              DateTime.fromMillisecondsSinceEpoch(int.tryParse(shareTime)));
        }

        print("shareId++++" + sharedId);
        if (shareToFirstName != "null") {
          profileLogList.add(new ProfileShareModel(
              _id,
              sharedId,
              sharedType,
              profileOwner,
              shareTime,
              isActive,
              isViewed,
              shareTo,
              shareToFirstName,
              shareToLastName,
              shareToEmail,
              shareToprofilePicture,
              roleId,
              profileOwnerRole,
              badge,
              gamificationPoints,
              badgeImage));
        }
      }
      return profileLogList;
    } catch (e) {
      return profileLogList;
    }
  }

  static GroupListModel parseGroupData3(map, userIdPref, roleIdUser) {
    var acceptedListMap = map['Accepted'];
    var requestedListMap = map['Reuested'];
    var invitationListMap = map['Invited'];
    var childInvitationListMap = map['parentInvited'];

    List<GroupModel> groupList = List<GroupModel>();
    List<GroupModel> groupRequestList = List<GroupModel>();
    List<GroupModel> groupInvitationList = List<GroupModel>();
    List<InvitationModel> childInvitationList = List<InvitationModel>();

    try {
      for (int j = 0; j < acceptedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = acceptedListMap[j]['groupId'].toString();
        String groupName = acceptedListMap[j]['groupName'].toString();
        String type = acceptedListMap[j]['type'].toString();
        String creationDate = acceptedListMap[j]['creationDate'].toString();
        String createdBy = acceptedListMap[j]['createdBy'].toString();
        String roleId = acceptedListMap[j]['roleId'].toString();
        String isActive = acceptedListMap[j]['isActive'].toString();
        String aboutGroup = acceptedListMap[j]['aboutGroup'].toString();
        String otherInfo = acceptedListMap[j]['otherInfo'].toString();
        String groupImage = acceptedListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = acceptedListMap[j]['members'];
        List<MemberModel> memberList = List();
        for (int k = 0; k < memberMap.length; k++) {
          String status = memberMap[k]["status"].toString();
          String isAdmin = memberMap[k]["isAdmin"].toString();
          String userId = memberMap[k]["userId"].toString();
          String roleId = memberMap[k]["roleId"].toString();
          if (status == "Accepted") acceptCount++;

          print("isAdmin===" + isAdmin + "  " + userId);
          if (userIdPref == userId && roleId == roleIdUser) {
            currentStatus = status;

            if (isAdmin == "true")
              isAdminFlag = true;
            else
              isAdminFlag = false;
          }

          memberList.add(new MemberModel(status, isAdmin, userId));
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = acceptedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = acceptedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            acceptedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        if (isAdminFlag) {
          groupList.add(new GroupModel(
              groupId,
              groupName,
              type,
              creationDate,
              createdBy,
              isActive,
              aboutGroup,
              otherInfo,
              groupImage,
              memberList,
              isAdminFlag,
              false,
              currentStatus,
              acceptCount.toString(),
              "",
              "",
              badge,
              gamificationPoints,
              badgeImage,
              roleId));
        }
      }
    } catch (e) {}

    return GroupListModel(
        groupList, groupRequestList, groupInvitationList, childInvitationList);
  }

  static GroupListModel parseGroupDataForExternalShare(
      map, userIdPref, roleIdUser) {
    var acceptedListMap = map['Accepted'];
    var requestedListMap = map['Reuested'];
    var invitationListMap = map['Invited'];
    var childInvitationListMap = map['parentInvited'];

    List<GroupModel> groupList = List<GroupModel>();
    List<GroupModel> groupRequestList = List<GroupModel>();
    List<GroupModel> groupInvitationList = List<GroupModel>();
    List<InvitationModel> childInvitationList = List<InvitationModel>();

    try {
      for (int j = 0; j < acceptedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = acceptedListMap[j]['groupId'].toString();
        String groupName = acceptedListMap[j]['groupName'].toString();
        String type = acceptedListMap[j]['type'].toString();
        String creationDate = acceptedListMap[j]['creationDate'].toString();
        String createdBy = acceptedListMap[j]['createdBy'].toString();
        String roleId = acceptedListMap[j]['roleId'].toString();
        String isActive = acceptedListMap[j]['isActive'].toString();
        String aboutGroup = acceptedListMap[j]['aboutGroup'].toString();
        String otherInfo = acceptedListMap[j]['otherInfo'].toString();
        String groupImage = acceptedListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = acceptedListMap[j]['members'];
        List<MemberModel> memberList = List();
        for (int k = 0; k < memberMap.length; k++) {
          String status = memberMap[k]["status"].toString();
          String isAdmin = memberMap[k]["isAdmin"].toString();
          String userId = memberMap[k]["userId"].toString();
          String roleId = memberMap[k]["roleId"].toString();
          if (status == "Accepted") acceptCount++;

          print("isAdmin===" + isAdmin + "  " + userId);
          if (userIdPref == userId && roleId == roleIdUser) {
            currentStatus = status;

            if (isAdmin == "true")
              isAdminFlag = true;
            else
              isAdminFlag = false;
          }

          memberList.add(new MemberModel(status, isAdmin, userId));
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = acceptedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = acceptedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            acceptedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        //if (isAdminFlag) {
        groupList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            "",
            "",
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
        // }
      }
    } catch (e) {}

    return GroupListModel(
        groupList, groupRequestList, groupInvitationList, childInvitationList);
  }

  static List<GroupModel> parseGroupDiscover(
      acceptedListMap, userIdPref, roleIdUser) {
    try {
      List<GroupModel> groupList = List<GroupModel>();
      for (int j = 0; j < acceptedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = acceptedListMap[j]['groupId'].toString();
        String groupName = acceptedListMap[j]['groupName'].toString();
        String type = acceptedListMap[j]['type'].toString();
        String creationDate = acceptedListMap[j]['creationDate'].toString();
        String createdBy = acceptedListMap[j]['createdBy'].toString();
        String roleId = acceptedListMap[j]['roleId'].toString();
        //  String isActive = acceptedListMap[j]['isActive'].toString();
        String isActive = "false";
        String aboutGroup = acceptedListMap[j]['aboutGroup'].toString();
        String otherInfo = acceptedListMap[j]['otherInfo'].toString();
        String studentName = acceptedListMap[j]['studentName'].toString();
        String studentUserId = acceptedListMap[j]['studentUserId'].toString();
        String groupImage = acceptedListMap[j]['groupImage'].toString();
        if (userIdPref == createdBy && roleId == roleIdUser) {
          isAdminFlag = true;
        }
        int acceptCount = 0;
        List<MemberModel> memberList = List();

        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = acceptedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = acceptedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            acceptedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        groupList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            studentName,
            studentUserId,
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
      }

      return groupList;
    } catch (e) {
      e.toString();
    }
  }

  static GroupListModel parseGroupDataAdminFlagChanges(
      map, userIdPref, roleIdUser, String _mgroupId) {
    var acceptedListMap = map['Accepted'];
    var requestedListMap = map['Reuested'];
    var invitationListMap = map['Invited'];
    var childInvitationListMap = map['parentInvited'];

    List<GroupModel> groupList = List<GroupModel>();
    List<GroupModel> groupRequestList = List<GroupModel>();
    List<GroupModel> groupInvitationList = List<GroupModel>();
    List<InvitationModel> childInvitationList = List<InvitationModel>();

    try {
      for (int j = 0; j < acceptedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = acceptedListMap[j]['groupId'].toString();
        String groupName = acceptedListMap[j]['groupName'].toString();
        String type = acceptedListMap[j]['type'].toString();
        String creationDate = acceptedListMap[j]['creationDate'].toString();
        String createdBy = acceptedListMap[j]['createdBy'].toString();
        String roleId = acceptedListMap[j]['roleId'].toString();
        String isActive = acceptedListMap[j]['isActive'].toString();
        String aboutGroup = acceptedListMap[j]['aboutGroup'].toString();
        String otherInfo = acceptedListMap[j]['otherInfo'].toString();
        String groupImage = acceptedListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = acceptedListMap[j]['members'];
        List<MemberModel> memberList = List();
        if (memberMap != null) {
          for (int k = 0; k < memberMap.length; k++) {
            String status = memberMap[k]["status"].toString();
            String isAdmin = memberMap[k]["isAdmin"].toString();
            String userId = memberMap[k]["userId"].toString();
            String roleId = memberMap[k]["roleId"].toString();
            if (status == "Accepted") acceptCount++;

            print("isAdmin===" + isAdmin + "  " + userId);
            if (userIdPref == userId && roleId == roleIdUser) {
              currentStatus = status;

              if (isAdmin == "true")
                isAdminFlag = true;
              else
                isAdminFlag = false;
            }

            memberList.add(new MemberModel(status, isAdmin, userId));
          }
        }

        if (userIdPref == createdBy && roleId == roleIdUser) {
          currentStatus = "Accepted";
          isAdminFlag = true;
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = acceptedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = acceptedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            acceptedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }
        if (_mgroupId != groupId) {
          groupList.add(new GroupModel(
              groupId,
              groupName,
              type,
              creationDate,
              createdBy,
              isActive,
              aboutGroup,
              otherInfo,
              groupImage,
              memberList,
              isAdminFlag,
              false,
              currentStatus,
              acceptCount.toString(),
              "",
              "",
              badge,
              gamificationPoints,
              badgeImage,
              roleId));
        }
      }
    } catch (e) {}

    try {
      for (int j = 0; j < requestedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = requestedListMap[j]['groupId'].toString();
        String groupName = requestedListMap[j]['groupName'].toString();
        String type = requestedListMap[j]['type'].toString();
        String creationDate = requestedListMap[j]['creationDate'].toString();
        String createdBy = requestedListMap[j]['createdBy'].toString();
        String roleId = requestedListMap[j]['roleId'].toString();
        String isActive = requestedListMap[j]['isActive'].toString();
        String aboutGroup = requestedListMap[j]['aboutGroup'].toString();
        String otherInfo = requestedListMap[j]['otherInfo'].toString();
        String groupImage = requestedListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = requestedListMap[j]['members'];
        List<MemberModel> memberList = List();
        if (memberMap != null) {
          for (int k = 0; k < memberMap.length; k++) {
            String status = memberMap[k]["status"].toString();
            String isAdmin = memberMap[k]["isAdmin"].toString();
            String userId = memberMap[k]["userId"].toString();
            String roleId = memberMap[k]["roleId"].toString();
            if (status == "Accepted") acceptCount++;

            print("isAdmin===" + isAdmin + "  " + userId);
            if (userIdPref == userId && roleId == roleIdUser) {
              currentStatus = status;

              if (isAdmin == "true")
                isAdminFlag = true;
              else
                isAdminFlag = false;
            }

            memberList.add(new MemberModel(status, isAdmin, userId));
          }
        }

        if (userIdPref == createdBy && roleId == roleIdUser) {
          currentStatus = "Requested";
          isAdminFlag = true;
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = requestedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = requestedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            requestedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }
        groupRequestList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            "",
            "",
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
      }
    } catch (e) {}

    try {
      for (int j = 0; j < invitationListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = invitationListMap[j]['groupId'].toString();
        String groupName = invitationListMap[j]['groupName'].toString();
        String type = invitationListMap[j]['type'].toString();
        String creationDate = invitationListMap[j]['creationDate'].toString();
        String createdBy = invitationListMap[j]['createdBy'].toString();
        String roleId = invitationListMap[j]['roleId'].toString();
        String isActive = invitationListMap[j]['isActive'].toString();
        String aboutGroup = invitationListMap[j]['aboutGroup'].toString();
        String otherInfo = invitationListMap[j]['otherInfo'].toString();
        String groupImage = invitationListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = invitationListMap[j]['members'];
        List<MemberModel> memberList = List();
        if (memberMap != null) {
          for (int k = 0; k < memberMap.length; k++) {
            String status = memberMap[k]["status"].toString();
            String isAdmin = memberMap[k]["isAdmin"].toString();
            String userId = memberMap[k]["userId"].toString();
            String roleId = memberMap[k]["roleId"].toString();
            if (status == "Accepted") acceptCount++;

            print("isAdmin===" + isAdmin + "  " + userId);
            if (userIdPref == userId && roleId == roleIdUser) {
              currentStatus = status;

              if (isAdmin == "true")
                isAdminFlag = true;
              else
                isAdminFlag = false;
            }

            memberList.add(new MemberModel(status, isAdmin, userId));
          }
        }

        if (userIdPref == createdBy && roleId == roleIdUser) {
          currentStatus = "Invited";
          isAdminFlag = true;
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = invitationListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = invitationListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            invitationListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        groupInvitationList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            "",
            "",
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
      }
    } catch (e) {}

    try {
      print("map+++" + childInvitationListMap[0].toString());
      for (int k = 0; k < childInvitationListMap.length; k++) {
        List<GroupModel> invitationList = List();
        String studentName = "", studentUserId = "";
        studentName = childInvitationListMap[k]["studentName"].toString();
        studentUserId = childInvitationListMap[k]["studentUserId"].toString();

        //inivitation badge
        String badgeImageStud =
            childInvitationListMap[k]['badgeImage'].toString();
        if (badgeImageStud == "null" || badgeImageStud == "") {
          badgeImageStud = "";
        }
        String badgeStud = childInvitationListMap[k]['badge'].toString();
        if (badgeStud == "null" || badgeStud == "") {
          badgeStud = "";
        }
        String gamificationStud =
            childInvitationListMap[k]['gamificationPoints'].toString();
        int gamificationPointsStud;
        if (gamificationStud == "null" || gamificationStud == "") {
          gamificationPointsStud = 0;
        } else {
          gamificationPointsStud = int.parse(gamificationStud);
        }
        if (gamificationPointsStud == null) {
          gamificationPointsStud = 0;
        }

        var subList = childInvitationListMap[k]['requests'];
        for (int j = 0; j < subList.length; j++) {
          bool isAdminFlag = false;
          String currentStatus = "";
          String groupId = subList[j]['groupId'].toString();
          String groupName = subList[j]['groupName'].toString();
          String type = subList[j]['type'].toString();
          String creationDate = subList[j]['creationDate'].toString();
          String createdBy = subList[j]['createdBy'].toString();
          String roleId = subList[j]['roleId'].toString();
          String isActive = subList[j]['isActive'].toString();
          String aboutGroup = subList[j]['aboutGroup'].toString();
          String otherInfo = subList[j]['otherInfo'].toString();
          String groupImage = subList[j]['groupImage'].toString();
          int acceptCount = 0;
          var memberMap = subList[j]['members'];
          List<MemberModel> memberList = List();
          for (int k = 0; k < memberMap.length; k++) {
            String status = memberMap[k]["status"].toString();
            String isAdmin = memberMap[k]["isAdmin"].toString();
            String userId = memberMap[k]["userId"].toString();
            if (status == "Accepted") acceptCount++;

            if (userIdPref == userId) {
              currentStatus = status;

              if (isAdmin == "true")
                isAdminFlag = true;
              else
                isAdminFlag = false;
            }

            memberList.add(new MemberModel(status, isAdmin, userId));
          }
          print("Accept count" + acceptCount.toString());
          if (creationDate != "" && creationDate != "null") {
            int d = int.tryParse(creationDate);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
            //  final f =  DateFormat('yyyy-MM-dd hh:mm');
            final f = DateFormat.yMMMMd("en_US");
            creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
                int.tryParse(creationDate)));
          }

          String badgeImage = subList[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = subList[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = subList[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          invitationList.add(new GroupModel(
              groupId,
              groupName,
              type,
              creationDate,
              createdBy,
              isActive,
              aboutGroup,
              otherInfo,
              groupImage,
              memberList,
              isAdminFlag,
              false,
              currentStatus,
              acceptCount.toString(),
              studentName,
              studentUserId,
              badge,
              gamificationPoints,
              badgeImage,
              roleId));
        }

        childInvitationList.add(new InvitationModel(studentUserId, studentName,
            invitationList, badgeStud, gamificationPointsStud, badgeImageStud));
      }
    } catch (e) {}

    return GroupListModel(
        groupList, groupRequestList, groupInvitationList, childInvitationList);
  }

  static GroupListModel parseGroupData2(
      map, userIdPref, roleIdUser, String _mgroupId) {
    var acceptedListMap = map['Accepted'];
    var requestedListMap = map['Reuested'];
    var invitationListMap = map['Invited'];
    var childInvitationListMap = map['parentInvited'];

    List<GroupModel> groupList = List<GroupModel>();
    List<GroupModel> groupRequestList = List<GroupModel>();
    List<GroupModel> groupInvitationList = List<GroupModel>();
    List<InvitationModel> childInvitationList = List<InvitationModel>();

    try {
      for (int j = 0; j < acceptedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = acceptedListMap[j]['groupId'].toString();
        String groupName = acceptedListMap[j]['groupName'].toString();
        String type = acceptedListMap[j]['type'].toString();
        String creationDate = acceptedListMap[j]['creationDate'].toString();
        String createdBy = acceptedListMap[j]['createdBy'].toString();
        String roleId = acceptedListMap[j]['roleId'].toString();
        String isActive = acceptedListMap[j]['isActive'].toString();
        String aboutGroup = acceptedListMap[j]['aboutGroup'].toString();
        String otherInfo = acceptedListMap[j]['otherInfo'].toString();
        String groupImage = acceptedListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = acceptedListMap[j]['members'];
        List<MemberModel> memberList = List();
        for (int k = 0; k < memberMap.length; k++) {
          String status = memberMap[k]["status"].toString();
          String isAdmin = memberMap[k]["isAdmin"].toString();
          String userId = memberMap[k]["userId"].toString();
          String roleId = memberMap[k]["roleId"].toString();
          if (status == "Accepted") acceptCount++;

          print("isAdmin===" + isAdmin + "  " + userId);
          if (userIdPref == userId && roleId == roleIdUser) {
            currentStatus = status;

            if (isAdmin == "true")
              isAdminFlag = true;
            else
              isAdminFlag = false;
          }

          memberList.add(new MemberModel(status, isAdmin, userId));
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = acceptedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = acceptedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            acceptedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }
        if (_mgroupId != groupId) {
          groupList.add(new GroupModel(
              groupId,
              groupName,
              type,
              creationDate,
              createdBy,
              isActive,
              aboutGroup,
              otherInfo,
              groupImage,
              memberList,
              isAdminFlag,
              false,
              currentStatus,
              acceptCount.toString(),
              "",
              "",
              badge,
              gamificationPoints,
              badgeImage,
              roleId));
        }
      }
    } catch (e) {}

    try {
      for (int j = 0; j < requestedListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = requestedListMap[j]['groupId'].toString();
        String groupName = requestedListMap[j]['groupName'].toString();
        String type = requestedListMap[j]['type'].toString();
        String creationDate = requestedListMap[j]['creationDate'].toString();
        String createdBy = requestedListMap[j]['createdBy'].toString();
        String roleId = requestedListMap[j]['roleId'].toString();
        String isActive = requestedListMap[j]['isActive'].toString();
        String aboutGroup = requestedListMap[j]['aboutGroup'].toString();
        String otherInfo = requestedListMap[j]['otherInfo'].toString();
        String groupImage = requestedListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = requestedListMap[j]['members'];
        List<MemberModel> memberList = List();
        for (int k = 0; k < memberMap.length; k++) {
          String status = memberMap[k]["status"].toString();
          String isAdmin = memberMap[k]["isAdmin"].toString();
          String userId = memberMap[k]["userId"].toString();
          if (status == "Accepted") acceptCount++;

          if (userIdPref == userId) {
            currentStatus = status;
            if (isAdmin == "true")
              isAdminFlag = true;
            else
              isAdminFlag = false;
          }

          memberList.add(new MemberModel(status, isAdmin, userId));
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = requestedListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = requestedListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            requestedListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }
        groupRequestList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            "",
            "",
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
      }
    } catch (e) {}

    try {
      for (int j = 0; j < invitationListMap.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = invitationListMap[j]['groupId'].toString();
        String groupName = invitationListMap[j]['groupName'].toString();
        String type = invitationListMap[j]['type'].toString();
        String creationDate = invitationListMap[j]['creationDate'].toString();
        String createdBy = invitationListMap[j]['createdBy'].toString();
        String roleId = invitationListMap[j]['roleId'].toString();
        String isActive = invitationListMap[j]['isActive'].toString();
        String aboutGroup = invitationListMap[j]['aboutGroup'].toString();
        String otherInfo = invitationListMap[j]['otherInfo'].toString();
        String groupImage = invitationListMap[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = invitationListMap[j]['members'];
        List<MemberModel> memberList = List();
        for (int k = 0; k < memberMap.length; k++) {
          String status = memberMap[k]["status"].toString();
          String isAdmin = memberMap[k]["isAdmin"].toString();
          String userId = memberMap[k]["userId"].toString();
          if (status == "Accepted") acceptCount++;

          if (userIdPref == userId) {
            currentStatus = status;
            if (isAdmin == "true")
              isAdminFlag = true;
            else
              isAdminFlag = false;
          }

          memberList.add(new MemberModel(status, isAdmin, userId));
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f = DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));
        }

        String badgeImage = invitationListMap[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = invitationListMap[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification =
            invitationListMap[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        groupInvitationList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            "",
            "",
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
      }
    } catch (e) {}

    try {
      print("map+++" + childInvitationListMap[0].toString());
      for (int k = 0; k < childInvitationListMap.length; k++) {
        List<GroupModel> invitationList = List();
        String studentName = "", studentUserId = "";
        studentName = childInvitationListMap[k]["studentName"].toString();
        studentUserId = childInvitationListMap[k]["studentUserId"].toString();

        //inivitation badge
        String badgeImageStud =
            childInvitationListMap[k]['badgeImage'].toString();
        if (badgeImageStud == "null" || badgeImageStud == "") {
          badgeImageStud = "";
        }
        String badgeStud = childInvitationListMap[k]['badge'].toString();
        if (badgeStud == "null" || badgeStud == "") {
          badgeStud = "";
        }
        String gamificationStud =
            childInvitationListMap[k]['gamificationPoints'].toString();
        int gamificationPointsStud;
        if (gamificationStud == "null" || gamificationStud == "") {
          gamificationPointsStud = 0;
        } else {
          gamificationPointsStud = int.parse(gamificationStud);
        }
        if (gamificationPointsStud == null) {
          gamificationPointsStud = 0;
        }

        var subList = childInvitationListMap[k]['requests'];
        for (int j = 0; j < subList.length; j++) {
          bool isAdminFlag = false;
          String currentStatus = "";
          String groupId = subList[j]['groupId'].toString();
          String groupName = subList[j]['groupName'].toString();
          String type = subList[j]['type'].toString();
          String creationDate = subList[j]['creationDate'].toString();
          String createdBy = subList[j]['createdBy'].toString();
          String roleId = subList[j]['roleId'].toString();
          String isActive = subList[j]['isActive'].toString();
          String aboutGroup = subList[j]['aboutGroup'].toString();
          String otherInfo = subList[j]['otherInfo'].toString();
          String groupImage = subList[j]['groupImage'].toString();
          int acceptCount = 0;
          var memberMap = subList[j]['members'];
          List<MemberModel> memberList = List();
          for (int k = 0; k < memberMap.length; k++) {
            String status = memberMap[k]["status"].toString();
            String isAdmin = memberMap[k]["isAdmin"].toString();
            String userId = memberMap[k]["userId"].toString();
            if (status == "Accepted") acceptCount++;

            if (userIdPref == userId) {
              currentStatus = status;

              if (isAdmin == "true")
                isAdminFlag = true;
              else
                isAdminFlag = false;
            }

            memberList.add(new MemberModel(status, isAdmin, userId));
          }
          print("Accept count" + acceptCount.toString());
          if (creationDate != "" && creationDate != "null") {
            int d = int.tryParse(creationDate);
            DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
            //  final f =  DateFormat('yyyy-MM-dd hh:mm');
            final f = DateFormat.yMMMMd("en_US");
            creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
                int.tryParse(creationDate)));
          }

          String badgeImage = subList[j]['badgeImage'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = subList[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = subList[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          invitationList.add(new GroupModel(
              groupId,
              groupName,
              type,
              creationDate,
              createdBy,
              isActive,
              aboutGroup,
              otherInfo,
              groupImage,
              memberList,
              isAdminFlag,
              false,
              currentStatus,
              acceptCount.toString(),
              studentName,
              studentUserId,
              badge,
              gamificationPoints,
              badgeImage,
              roleId));
        }

        childInvitationList.add(new InvitationModel(studentUserId, studentName,
            invitationList, badgeStud, gamificationPointsStud, badgeImageStud));
      }
    } catch (e) {}

    return GroupListModel(
        groupList, groupRequestList, groupInvitationList, childInvitationList);
  }

  static List<GroupModel> parseGroupData(map, userIdPref) {
    List<GroupModel> groupList = List<GroupModel>();

    try {
      for (int j = 0; j < map.length; j++) {
        bool isAdminFlag = false;
        String currentStatus = "";
        String groupId = map[j]['groupId'].toString();
        String groupName = map[j]['groupName'].toString();
        String type = map[j]['type'].toString();
        String creationDate = map[j]['creationDate'].toString();
        String createdBy = map[j]['createdBy'].toString();
        String roleId = map[j]['roleId'].toString();
        String isActive = map[j]['isActive'].toString();
        String aboutGroup = map[j]['aboutGroup'].toString();
        String otherInfo = map[j]['otherInfo'].toString();
        String groupImage = map[j]['groupImage'].toString();
        int acceptCount = 0;
        var memberMap = map[j]['members'];
        List<MemberModel> memberList = List();
        for (int k = 0; k < memberMap.length; k++) {
          String status = memberMap[k]["status"].toString();
          String isAdmin = memberMap[k]["isAdmin"].toString();
          String userId = memberMap[k]["userId"].toString();
          if (status == "Accepted") acceptCount++;

          if (userIdPref == userId) {
            currentStatus = status;
            if (isAdmin == "true")
              isAdminFlag = true;
            else
              isAdminFlag = false;
          }

          memberList.add(new MemberModel(status, isAdmin, userId));
        }
        print("Accept count" + acceptCount.toString());
        if (creationDate != "" && creationDate != "null") {
          int d = int.tryParse(creationDate);
          /*   DateTime date =  DateTime.fromMillisecondsSinceEpoch(d);
          //  final f =  DateFormat('yyyy-MM-dd hh:mm');
          final f =  DateFormat.yMMMMd("en_US");
          creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
              int.tryParse(creationDate)));*/

          var now = DateTime.fromMillisecondsSinceEpoch(d);
          var formatter = DateFormat('MMM dd, yyyy');
          creationDate = formatter.format(now);
        }

        String badgeImage = map[j]['badgeImage'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = map[j]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = map[j]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        groupList.add(new GroupModel(
            groupId,
            groupName,
            type,
            creationDate,
            createdBy,
            isActive,
            aboutGroup,
            otherInfo,
            groupImage,
            memberList,
            isAdminFlag,
            false,
            currentStatus,
            acceptCount.toString(),
            "",
            "",
            badge,
            gamificationPoints,
            badgeImage,
            roleId));
      }
      return groupList;
    } catch (e) {
      return groupList;
    }
  }

  static List<GroupDetailModel> parseGroupDetailMap2(map, userIdPref) {
    List<GroupDetailModel> groupList = List<GroupDetailModel>();

    try {
      String adminName = "";
      bool isAdminFlag = false;
      String currentStatus = "";
      String _id = map['_id'].toString();
      String groupId = map['groupId'].toString();
      String groupName = map['groupName'].toString();
      String type = map['type'].toString();
      String creationDate = map['creationDate'].toString();
      String createdBy = map['createdBy'].toString();
      String isActive = map['isActive'].toString();
      String aboutGroup = map['aboutGroup'].toString();
      String otherInfo = map['otherInfo'].toString();
      String groupImage = map['groupImage'].toString();
      bool isOpportunityAdded = map['isOpportunityAdded'];
      if (isOpportunityAdded == null) {
        isOpportunityAdded = false;
      }
      var memberMap = map['members'];
      List<MemberModelDetail> memberList = List();
      List<MemberModelDetail> requestedList = List();
      List<MemberModelDetail> invitedList = List();
      List<MemberModelDetail> allMembersList = List();
      List<MemberModelDetail> memberList2 = List();
      for (int k = 0; k < memberMap.length; k++) {
        String status = memberMap[k]["status"].toString();
        String isAdmin = memberMap[k]["isAdmin"].toString();
        String userId = memberMap[k]["userId"].toString();
        String roleId = memberMap[k]["roleId"].toString();
        String firstName = memberMap[k]["firstName"].toString();
        String lastName = memberMap[k]["lastName"].toString();
        String profilePicture = memberMap[k]["profilePicture"].toString();
        String email = memberMap[k]["email"].toString();
        String tagline = memberMap[k]["tagline"].toString();
        String title = memberMap[k]["title"].toString();
        String isActive = memberMap[k]["isActive"].toString();
        String connectionStatus = memberMap[k]["connectionStatus"].toString();

        String badgeImage = memberMap[k]['badgeImage'].toString();
        String schoolCode = memberMap[k]['schoolCode'].toString();
        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }
        String badge = memberMap[k]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = memberMap[k]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" || gamification == "") {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        if (gamificationPoints == null) {
          gamificationPoints = 0;
        }

        if (userIdPref == userId) {
          currentStatus = status;
          if (isAdmin == "true") isAdminFlag = true;
        }

        if (isAdmin == "true") adminName = firstName + " " + lastName;
        if (userId == userIdPref) {
        } else {
          if (status == "Accepted") {
            memberList.add(new MemberModelDetail(
                status,
                isAdmin,
                userId,
                roleId,
                firstName,
                lastName,
                profilePicture,
                email,
                tagline,
                false,
                connectionStatus,
                title,
                isActive,
                badge,
                gamificationPoints,
                badgeImage,
                schoolCode));
          }
        }

        if (status == "Requested") {
          requestedList.add(new MemberModelDetail(
              status,
              isAdmin,
              userId,
              roleId,
              firstName,
              lastName,
              profilePicture,
              email,
              tagline,
              false,
              connectionStatus,
              title,
              isActive,
              badge,
              gamificationPoints,
              badgeImage,
              schoolCode));
        }
        if (status == "Invited") {
          invitedList.add(new MemberModelDetail(
              status,
              isAdmin,
              userId,
              roleId,
              firstName,
              lastName,
              profilePicture,
              email,
              tagline,
              false,
              connectionStatus,
              title,
              isActive,
              badge,
              gamificationPoints,
              badgeImage,
              schoolCode));
        }

        allMembersList.add(new MemberModelDetail(
            status,
            isAdmin,
            userId,
            roleId,
            firstName,
            lastName,
            profilePicture,
            email,
            tagline,
            false,
            connectionStatus,
            title,
            isActive,
            badge,
            gamificationPoints,
            badgeImage,
            schoolCode));
      }

      if (creationDate != "" && creationDate != "null") {
        int d = int.tryParse(creationDate);
        /*      DateTime date =  DateTime.fromMillisecondsSinceEpoch(d);
        //  final f =  DateFormat('yyyy-MM-dd hh:mm');
        final f =  DateFormat.yMMMMd("en_US");
        creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
            int.tryParse(creationDate)));*/

        var now = DateTime.fromMillisecondsSinceEpoch(d);
        var formatter = DateFormat('MMM dd, yyyy');
        creationDate = formatter.format(now);
      }

      groupList.add(new GroupDetailModel(
          _id,
          groupId,
          groupName,
          type,
          creationDate,
          createdBy,
          isActive,
          aboutGroup,
          otherInfo,
          groupImage,
          memberList,
          isAdminFlag,
          currentStatus,
          adminName,
          requestedList,
          invitedList,
          isOpportunityAdded,
          allMembersList,
          ""));

      return groupList;
    } catch (e) {
      return groupList;
    }
  }

  static List<GroupDetailModel> parseGroupDetailMap(
      map, userIdPref, userRoleId) {
    List<GroupDetailModel> groupList = List<GroupDetailModel>();
    print("userid +++{$userIdPref}+++{$userRoleId}");
    try {
      String adminName = "";
      String adminRoleId = '1';
      bool isAdminFlag = false;
      String currentStatus = "";
      String _id = map['_id'].toString();
      String groupId = map['groupId'].toString();
      String groupName = map['groupName'].toString();
      String type = map['type'].toString();
      String creationDate = map['creationDate'].toString();
      String createdBy = map['createdBy'].toString();
      String isActive = map['isActive'].toString();
      String aboutGroup = map['aboutGroup'].toString();
      String otherInfo = map['otherInfo'].toString();
      String groupImage = map['groupImage'].toString();
      bool isOpportunityAdded = map['isOpportunityAdded'];
      if (isOpportunityAdded == null) {
        isOpportunityAdded = false;
      }
      var memberMap = map['members'];
      List<MemberModelDetail> memberList = List();
      List<MemberModelDetail> requestedList = List();
      List<MemberModelDetail> invitedList = List();
      List<MemberModelDetail> memberList2 = List();
      List<MemberModelDetail> allMembersList = List();

      for (int k = 0; k < memberMap.length; k++) {
        print("memberss++++" + memberMap[k].toString());
        String status = memberMap[k]["status"].toString();
        String isAdmin = memberMap[k]["isAdmin"].toString();
        String userId = memberMap[k]["userId"].toString();
        String roleId = memberMap[k]["roleId"].toString();
        String firstName = memberMap[k]["firstName"].toString();
        String lastName = memberMap[k]["lastName"].toString();
        String profilePicture = memberMap[k]["profilePicture"].toString();
        String email = memberMap[k]["email"].toString();
        String tagline = memberMap[k]["tagline"].toString();
        String title = memberMap[k]["title"].toString();
        String isActive = memberMap[k]["isActive"].toString();
        String connectionStatus = memberMap[k]["connectionStatus"].toString();
        print("useridat +++{$userId}+++{$roleId}");
        if (userIdPref == userId && userRoleId == roleId) {
          currentStatus = status;
          if (isAdmin == "true") isAdminFlag = true;
          /*  else  isAdminFlag = false;*/
        }
        /*else {
          if (isAdmin == "true") isAdminFlag = true;
        }*/

        if (isAdmin == "true") adminName = firstName + " " + lastName;
        if (isAdmin == "true") adminRoleId = roleId;

        String badgeImage = memberMap[k]['badgeImage'].toString();
        String schoolCode = memberMap[k]['schoolCode'].toString();
        if (badgeImage == "null" || badgeImage == "") {
          badgeImage = "";
        }

        if (schoolCode == "null" || schoolCode == "") {
          schoolCode = "";
        }
        String badge = memberMap[k]['badge'].toString();
        if (badge == "null" || badge == "") {
          badge = "";
        }
        String gamification = memberMap[k]['gamificationPoints'].toString();
        int gamificationPoints;
        if (gamification == "null" ||
            gamification == "" ||
            gamification == null) {
          gamificationPoints = 0;
        } else {
          gamificationPoints = int.parse(gamification);
        }
        /*if (gamificationPoints == null) {
          gamificationPoints = 0;
        }*/

        print(
            'Apurva group badge:: $badge, badgeImage:: $badgeImage, gamification:: $gamificationPoints');

        allMembersList.add(new MemberModelDetail(
            status,
            isAdmin,
            userId,
            roleId,
            firstName,
            lastName,
            profilePicture,
            email,
            tagline,
            false,
            connectionStatus,
            title,
            isActive,
            badge,
            gamificationPoints,
            badgeImage,
            schoolCode));

        memberList.add(new MemberModelDetail(
            status,
            isAdmin,
            userId,
            roleId,
            firstName,
            lastName,
            profilePicture,
            email,
            tagline,
            false,
            connectionStatus,
            title,
            isActive,
            badge,
            gamificationPoints,
            badgeImage,
            schoolCode));

        print("status for " + status);
        if (status == "Requested") {
          requestedList.add(new MemberModelDetail(
              status,
              isAdmin,
              userId,
              roleId,
              firstName,
              lastName,
              profilePicture,
              email,
              tagline,
              false,
              connectionStatus,
              title,
              isActive,
              badge,
              gamificationPoints,
              badgeImage,
              schoolCode));
        }
        if (status == "Invited") {
          invitedList.add(new MemberModelDetail(
              status,
              isAdmin,
              userId,
              roleId,
              firstName,
              lastName,
              profilePicture,
              email,
              tagline,
              false,
              connectionStatus,
              title,
              isActive,
              badge,
              gamificationPoints,
              badgeImage,
              schoolCode));
        }
      }

      /*if (isAdminFlag) {
      } else {*/
      for (int i = 0; i < memberList.length; i++) {
        if (memberList[i].status == "Accepted") {
          memberList2.add(memberList[i]);
        }
      }
      memberList.clear();
      memberList.addAll(memberList2);

      //}

      if (creationDate != "" && creationDate != "null") {
        int d = int.tryParse(creationDate);
        /*     DateTime date =  DateTime.fromMillisecondsSinceEpoch(d);
        //  final f =  DateFormat('yyyy-MM-dd hh:mm');
        final f =  DateFormat.yMMMMd("en_US");
        creationDate = f.format(new DateTime.fromMillisecondsSinceEpoch(
            int.tryParse(creationDate)));*/

        var now = DateTime.fromMillisecondsSinceEpoch(d);
        var formatter = DateFormat('MMM dd, yyyy');
        creationDate = formatter.format(now);
      }

      print("Currentstatus: -" + currentStatus);
      groupList.add(new GroupDetailModel(
          _id,
          groupId,
          groupName,
          type,
          creationDate,
          createdBy,
          isActive,
          aboutGroup,
          otherInfo,
          groupImage,
          memberList,
          isAdminFlag,
          currentStatus,
          adminName,
          requestedList,
          invitedList,
          isOpportunityAdded,
          allMembersList,
          adminRoleId));

      return groupList;
    } catch (e) {
      print('Catch error:: ${e.toString()}');
      return groupList;
    }
  }

  static List<Friends> parseBotData(map, userIdPref) {
    List<Friends> dataList = List();
    for (int i = 0; i < map.length; i++) {
      try {
        int userId, dateTime = 0, receiverId, connectId;
        String firstName,
            creationTime = "0",
            lastName,
            partnerFirstName,
            partnerLastName,
            partnerProfilePicture,
            lastMessage,
            textSentBy,
            partnerRoleId,
            isActive;
        int unreadMessageCount;
        String email = "", profilePicture = "";

        userId = map[i]["userId"];
        creationTime = map[i]["creationTime"].toString();
        if (creationTime == "null" || creationTime == "") {
          creationTime = "0";
        }
        partnerRoleId = map[i]["partnerRoleId"].toString();
        receiverId = map[i]["partnerId"];
        connectId = map[i]["connectId"];

        firstName = map[i]["firstName"];
        lastName = map[i]["lastName"];
        unreadMessageCount = map[i]["unreadMessages"];
        lastMessage = map[i]["lastMessage"];
        lastMessage =
            lastMessage.replaceAll("<a href=\"\">", "").replaceAll("</a>", " ");
        textSentBy = map[i]["textSentBy"].toString();
        try {
          isActive = map[i]["isActive"].toString();
          if (isActive == "null") isActive = "true";
        } catch (e) {
          isActive = "true";
        }

        if (map[i]["profilePicture"] != null)
          profilePicture = map[i]["profilePicture"];

        partnerFirstName = map[i]["partnerFirstName"];
        partnerLastName = map[i]["partnerLastName"];
        if (map[i]["partnerProfilePicture"] != null)
          partnerProfilePicture = map[i]["partnerProfilePicture"];

        print(userId);
        if (receiverId == 1) {
          dataList.insert(
              0,
              Friends(
                  connectId: connectId,
                  userId: userId,
                  firstName: firstName,
                  lastName: lastName,
                  profilePicture: profilePicture,
                  partnerId: receiverId,
                  partnerFirstName: partnerFirstName,
                  partnerLastName: partnerLastName,
                  partnerRoleId: int.parse(partnerRoleId),
                  partnerProfilePicture: partnerProfilePicture,
                  dateTime: dateTime,
                  creationTime: int.parse(creationTime),
                  isActive: true,
                  online: 1,
                  lastMessage: lastMessage == "" ||
                          lastMessage == null ||
                          lastMessage == "null"
                      ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
                      : lastMessage,
                  unreadMessages: 0,
                  lastTime: 0,
                  textSentBy: userId));
        } else {
          if (userIdPref == "1") {
            dataList.add(Friends(
                connectId: connectId,
                userId: userId,
                firstName: firstName,
                lastName: lastName,
                profilePicture: profilePicture,
                partnerId: receiverId,
                partnerFirstName: partnerFirstName,
                partnerLastName: partnerLastName,
                partnerRoleId: int.parse(partnerRoleId),
                partnerProfilePicture: partnerProfilePicture,
                dateTime: dateTime,
                creationTime: int.parse(creationTime),
                isActive: true,
                online: 1,
                lastMessage: lastMessage == null ||
                        lastMessage == "" ||
                        lastMessage == "null"
                    ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
                    : lastMessage,
                unreadMessages: 0,
                lastTime: 0,
                textSentBy: userId));
          } else {
            dataList.add(Friends(
                connectId: connectId,
                userId: userId,
                firstName: firstName,
                lastName: lastName,
                profilePicture: profilePicture,
                partnerId: receiverId,
                partnerFirstName: partnerFirstName,
                partnerLastName: partnerLastName,
                partnerRoleId: int.parse(partnerRoleId),
                partnerProfilePicture: partnerProfilePicture,
                dateTime: dateTime,
                creationTime: int.parse(creationTime),
                isActive: true,
                online: 1,
                lastMessage: lastMessage,
                unreadMessages: 0,
                lastTime: 0,
                textSentBy: userId));
          }
        }
      } catch (e) {
        e.toString();
      }
    }

    return dataList;
  }

/*  static List<ProfileInfoModal> parseUserFriendList(map) {
    List<ProfileInfoModal> friendList =  List<ProfileInfoModal>();
    for (int i = 0; i < map.length; i++) {
      String userId = map[i][ProfileInfoResponse.USER_ID].toString();
      String firstName = map[i][ProfileInfoResponse.FIRSTNAME].toString();
      String lastName = map[i][ProfileInfoResponse.LASTNAME].toString();
      String email = map[i][ProfileInfoResponse.EMAIL].toString();
      String mobileNo = map[i][ProfileInfoResponse.MOBILE].toString();
      String profilePicture =
      map[i][ProfileInfoResponse.PROFILE_PICTURE].toString();
      //   profilePicture= getMediumImage(profilePicture);
      String roleId = map[i][ProfileInfoResponse.ROLE_ID].toString();
      String isActive = map[i][ProfileInfoResponse.IS_ACTIVE].toString();
      String requireParentApproval =
      map[i][ProfileInfoResponse.REQUIRE_PARENT_APPROVEL].toString();
      String ccToParents = map[i][ProfileInfoResponse.CC_TO_PARENTS].toString();
      String lastAccess = map[i][ProfileInfoResponse.LAST_ACCESS].toString();
      String isPasswordChanged =
      map[i][ProfileInfoResponse.IS_PASSWORD_CHANGED].toString();
      String organizationId =
      map[i][ProfileInfoResponse.ORGANIZATION_ID].toString();
      String gender = map[i][ProfileInfoResponse.GENDER].toString();
      String dob = map[i][ProfileInfoResponse.DOB].toString();
      String genderAtBirth =
      map[i][ProfileInfoResponse.GENDER_AT_BIRTH].toString();
      String usCitizenOrPR =
      map[i][ProfileInfoResponse.US_CITIZEN_OR_PR].toString();

      var addressMap = map[i]['address'];
      Address addressModal =  Address("", "", "", "", "", "");
      if (addressMap != null) {
        String street1 = addressMap['street1'].toString();
        String street2 = addressMap['street2'].toString();
        String city = addressMap['city'].toString();
        String state = addressMap['state'].toString();
        String country = addressMap['country'].toString();
        String zip = addressMap['zip'].toString();
        addressModal =  Address(street1, street2, city, state, country, zip);
      }

      String summary = map[i][ProfileInfoResponse.SUMMARY].toString();
      String coverImage = map[i][ProfileInfoResponse.COVER_IMAGE].toString();
      //   coverImage= getMediumImage(coverImage);
      String tagline = map[i][ProfileInfoResponse.TAGLINE].toString();
      String title = map[i][ProfileInfoResponse.TITLE].toString();
      String tempPassword =
      map[i][ProfileInfoResponse.TEMP_PASSWORD].toString();
      String isArchived = map[i][ProfileInfoResponse.IS_ARCHIVED].toString();
      List<ParentModal> parentList =  List();

      for (int j = 0; j < map[i][ProfileInfoResponse.PARENTS].length; j++) {
        String email = map[i][ProfileInfoResponse.PARENTS][j]
        [ProfileInfoResponse.EMAIL]
            .toString();
        String userId = map[i][ProfileInfoResponse.PARENTS][j]
        [ProfileInfoResponse.USER_ID]
            .toString();
        parentList.add(new ParentModal(email, userId));
      }
      */ /*  if (profilePicture != "") {
      strNetworkImage = profilePicture;
    }*/ /*

      friendList.add(new ProfileInfoModal(
          userId,
          firstName,
          lastName,
          email,
          mobileNo,
          profilePicture,
          roleId,
          isActive,
          requireParentApproval,
          ccToParents,
          lastAccess,
          isPasswordChanged,
          organizationId,
          gender,
          dob,
          genderAtBirth,
          usCitizenOrPR,
          addressModal,
          summary,
          coverImage,
          tagline,
          title,
          tempPassword,
          isArchived,
          parentList));
    }
    return friendList;
  }*/
  static List<ConnectionListModel> parseChatData(map, userIdPref) {
    List<ConnectionListModel> dataList = List();
    for (int i = 0; i < map.length; i++) {
      int userId, dateTime = 0, receiverId, connectId;
      String firstName,
          creationTime,
          lastName,
          partnerFirstName,
          partnerLastName,
          partnerProfilePicture,
          lastMessage,
          textSentBy,
          partnerRoleId,
          isActive;
      int unreadMessageCount;
      String email = "", profilePicture = "";

      userId = map[i]["userId"];
      creationTime = map[i]["creationTime"].toString();
      partnerRoleId = map[i]["partnerRoleId"].toString();
      receiverId = map[i]["partnerId"];
      connectId = map[i]["connectId"];

      firstName = map[i]["firstName"];
      lastName = map[i]["lastName"];
      unreadMessageCount = map[i]["unreadMessages"];
      lastMessage = map[i]["lastMessage"];
      lastMessage =
          lastMessage.replaceAll("<a href=\"\">", "").replaceAll("</a>", " ");
      textSentBy = map[i]["textSentBy"].toString();
      try {
        isActive = map[i]["isActive"].toString();
        if (isActive == "null") isActive = "true";
      } catch (e) {
        isActive = "true";
      }

      if (map[i]["profilePicture"] != null)
        profilePicture = map[i]["profilePicture"];

      partnerFirstName = map[i]["partnerFirstName"];
      partnerLastName = map[i]["partnerLastName"];
      if (map[i]["partnerProfilePicture"] != null)
        partnerProfilePicture = map[i]["partnerProfilePicture"];

      print(userId);
      if (receiverId == 1) {
        dataList.insert(
            0,
            ConnectionListModel(
                userId.toString(),
                firstName,
                lastName,
                email,
                profilePicture,
                dateTime,
                receiverId.toString(),
                connectId.toString(),
                lastMessage == "" ||
                        lastMessage == null ||
                        lastMessage == "null"
                    ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
                    : lastMessage,
                unreadMessageCount.toString(),
                partnerFirstName,
                partnerLastName,
                partnerProfilePicture,
                true,
                textSentBy,
                isActive,
                false,
                partnerRoleId,
                creationTime));
      } else {
        if (userIdPref == "1") {
          dataList.add(ConnectionListModel(
              userId.toString(),
              firstName,
              lastName,
              email,
              profilePicture,
              dateTime,
              receiverId.toString(),
              connectId.toString(),
              lastMessage == "" || lastMessage == null || lastMessage == "null"
                  ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
                  : lastMessage,
              unreadMessageCount.toString(),
              partnerFirstName,
              partnerLastName,
              partnerProfilePicture,
              false,
              textSentBy,
              isActive,
              false,
              partnerRoleId,
              creationTime));
        } else {
          dataList.add(ConnectionListModel(
              userId.toString(),
              firstName,
              lastName,
              email,
              profilePicture,
              dateTime,
              receiverId.toString(),
              connectId.toString(),
              lastMessage,
              unreadMessageCount.toString(),
              partnerFirstName,
              partnerLastName,
              partnerProfilePicture,
              false,
              textSentBy,
              isActive,
              false,
              partnerRoleId,
              creationTime));
        }
      }
    }

    return dataList;
  }

  static List<Friends> parseChatList(map, userIdPref, userRoleID) {
    List<Friends> dataList = List();
    for (int i = 0; i < map.length; i++) {
      int connectId;
      int userId;
      String firstName;
      String lastName;
      String profilePicture;
      int partnerId;
      String partnerFirstName;
      String partnerLastName;
      int partnerRoleId;
      String partnerProfilePicture;
      int dateTime;
      int creationTime;
      bool isActive;
      int online;
      String lastMessage;
      int unreadMessages;
      int lastTime;
      int lastSeen;
      int textSentBy;
      bool isTyping = false;
      String badge;
      String badgeImage;
      int gamificationPoints;

      connectId = map[i]["connectId"];
      userId = map[i]["userId"];
      firstName = map[i]["firstName"].toString();
      lastName = map[i]["lastName"].toString();
      profilePicture = map[i]["profilePicture"].toString();
      partnerId = map[i]["partnerId"];
      partnerFirstName = map[i]["partnerFirstName"];
      partnerLastName = map[i]["partnerLastName"];
      partnerRoleId = map[i]["partnerRoleId"];
      partnerProfilePicture = map[i]["partnerProfilePicture"];
      dateTime = map[i]["dateTime"];
      creationTime = map[i]["creationTime"];
      isActive = map[i]["isActive"];
      online = map[i]["online"];
      lastMessage = map[i]["lastMessage"];
      unreadMessages = map[i]["unreadMessages"];
      lastTime = map[i]["lastTime"];
      lastSeen = map[i]["lastSeen"];
      textSentBy = map[i]["textSentBy"];
      badge = map[i]["badge"];
      gamificationPoints = map[i]["gamificationPoints"];
      badgeImage = map[i]["badgeImage"];

      print(userId);
      Friends(
          connectId: connectId,
          userId: userId,
          firstName: firstName,
          lastName: lastName,
          profilePicture: profilePicture,
          partnerId: partnerId,
          partnerFirstName: partnerFirstName,
          partnerLastName: partnerLastName,
          partnerRoleId: partnerRoleId,
          partnerProfilePicture: partnerProfilePicture,
          dateTime: dateTime,
          creationTime: creationTime,
          isActive: isActive,
          online: online,
          lastMessage: lastMessage,
          unreadMessages: unreadMessages,
          lastTime: lastTime,
          lastSeen: lastSeen,
          textSentBy: textSentBy,
          badge: badge,
          badgeImage: badgeImage,
          gamificationPoints: gamificationPoints);
    }

    return dataList;
  }

  static List<ConnectionListModel> parseChatShareData(map, shareRecieverId) {
    List<ConnectionListModel> dataList = List();
    for (int i = 0; i < map.length; i++) {
      print(map.length);
      int userId, dateTime = 0, receiverId, connectId;
      String firstName,
          lastName,
          creationTime,
          partnerRoleId,
          partnerFirstName,
          partnerLastName,
          partnerProfilePicture,
          lastMessage,
          textSentBy,
          isActive;
      int unreadMessageCount;
      String email = "", profilePicture = "";

      userId = map[i]["userId"];
      receiverId = map[i]["partnerId"];
      connectId = map[i]["connectId"];

      firstName = map[i]["firstName"];
      lastName = map[i]["lastName"];
      partnerRoleId = map[i]["partnerRoleId"].toString();
      creationTime = map[i]["creationTime"].toString();
      unreadMessageCount = map[i]["unreadMessages"];
      lastMessage = map[i]["lastMessage"];
      textSentBy = map[i]["textSentBy"].toString();
      try {
        isActive = map[i]["isActive"].toString();
        if (isActive == "null") isActive = "true";
      } catch (e) {
        isActive = "true";
      }
      if (map[i]["profilePicture"] != null)
        profilePicture = map[i]["profilePicture"];

      partnerFirstName = map[i]["partnerFirstName"];
      partnerLastName = map[i]["partnerLastName"];
      if (map[i]["partnerProfilePicture"] != null)
        partnerProfilePicture = map[i]["partnerProfilePicture"];

      print(userId);
      if (shareRecieverId != receiverId.toString()) {
        dataList.add(ConnectionListModel(
            userId.toString(),
            firstName,
            lastName,
            email,
            profilePicture,
            dateTime,
            receiverId.toString(),
            connectId.toString(),
            lastMessage,
            unreadMessageCount.toString(),
            partnerFirstName,
            partnerLastName,
            partnerProfilePicture,
            false,
            textSentBy,
            isActive,
            false,
            partnerRoleId,
            creationTime));
      }
    }

    return dataList;
  }

  static List<ConnectionListModel> parseChatDataMainPage(map, userIdPref) {
    List<ConnectionListModel> dataList = List();
    for (int i = 0; i < map.length; i++) {
      print("spike-----" + map[0].toString());
      int userId, dateTime = 0, receiverId, connectId;
      String firstName,
          partnerRoleId,
          lastName,
          partnerFirstName,
          partnerLastName,
          partnerProfilePicture,
          lastMessage,
          textSentBy,
          creationTime,
          isActive;
      int unreadMessageCount;
      String email = "", profilePicture = "";

      userId = map[i]["userId"];
      receiverId = map[i]["partnerId"];
      connectId = map[i]["connectId"];
      partnerRoleId = map[i]["partnerRoleId"].toString();
      creationTime = map[i]["creationTime"].toString();

      firstName = map[i]["firstName"];
      lastName = map[i]["lastName"];
      unreadMessageCount = map[i]["unreadMessages"];
      lastMessage = map[i]["lastMessage"];
      lastMessage =
          lastMessage.replaceAll("<a href=\"\">", "").replaceAll("</a>", " ");
      textSentBy = map[i]["textSentBy"].toString();
      try {
        isActive = map[i]["isActive"].toString();
        if (isActive == "null") isActive = "true";
      } catch (e) {
        isActive = "true";
      }
      if (map[i]["profilePicture"] != null)
        profilePicture = map[i]["profilePicture"];

      partnerFirstName = map[i]["partnerFirstName"];
      partnerLastName = map[i]["partnerLastName"];
      if (map[i]["partnerProfilePicture"] != null)
        partnerProfilePicture = map[i]["partnerProfilePicture"];

      print(userId);
      if (receiverId == 1) {
        dataList.insert(
            0,
            ConnectionListModel(
                userId.toString(),
                firstName,
                lastName,
                email,
                profilePicture,
                dateTime,
                receiverId.toString(),
                connectId.toString(),
                lastMessage == "" ||
                        lastMessage == null ||
                        lastMessage == "null"
                    ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
                    : lastMessage,
                unreadMessageCount.toString(),
                partnerFirstName,
                partnerLastName,
                partnerProfilePicture,
                true,
                textSentBy,
                isActive,
                false,
                partnerRoleId,
                creationTime));
      } else {
        if (userIdPref == "1") {
          dataList.add(ConnectionListModel(
              userId.toString(),
              firstName,
              lastName,
              email,
              profilePicture,
              dateTime,
              receiverId.toString(),
              connectId.toString(),
              lastMessage == "" || lastMessage == null || lastMessage == "null"
                  ? "Welcome to spikeview! Look around, invite your friends and let us know how we can help."
                  : lastMessage,
              unreadMessageCount.toString(),
              partnerFirstName,
              partnerLastName,
              partnerProfilePicture,
              false,
              textSentBy,
              isActive,
              false,
              partnerRoleId,
              creationTime));
        } else {
          dataList.add(ConnectionListModel(
              userId.toString(),
              firstName,
              lastName,
              email,
              profilePicture,
              dateTime,
              receiverId.toString(),
              connectId.toString(),
              lastMessage,
              unreadMessageCount.toString(),
              partnerFirstName,
              partnerLastName,
              partnerProfilePicture,
              false,
              textSentBy,
              isActive,
              false,
              partnerRoleId,
              creationTime));
        }
      }
    }

    print("spike===" + dataList.length.toString());
    return dataList;
  }

  static List<NotificationModel> parseNotification(map) {
    List<NotificationModel> dataList = List();
    for (int i = 0; i < map.length; i++) {
      print("notification++++" + map[i].toString());
      String notificationId = map[i]["notificationId"].toString();
      String userId = map[i]["userId"].toString();
      String actedBy = map[i]["actedBy"].toString();
      String actedRoleId = map[i]["actedRoleId"].toString();
      String postId = map[i]["postId"].toString();
      String profilePicture = map[i]["profilePicture"].toString();
      String text = map[i]["text"].toString();
      String dateTime = map[i]["dateTime"].toString();
      String isRead = map[i]["isRead"].toString();
      String textName = map[i]["textName"].toString();
      String textMessage = map[i]["textMessage"].toString();
      String roleId = map[i]["roleId"].toString();
      String type = map[i]["type"].toString();
      String values = map[i]["values"].toString();
      String actionValue = map[i]["actionValue"].toString();
      String appModule = map[i]["appModule"].toString();
      String linkType = map[i]["linkType"].toString();
      String buttonText = map[i]["buttonText"].toString();
      String buttonUrl = map[i]["buttonUrl"].toString();
      String requestId = map[i]["requestId"].toString();
      String reqActionStatus = map[i]["reqActionStatus"].toString().trim();
      String requestType = map[i]["requestType"].toString().trim();
      print("reqActionStatus++++" + reqActionStatus);
      DateTime currentDate = DateTime.now();
      if (dateTime != "null") {
        int d = int.tryParse(dateTime);
        DateTime date = DateTime.fromMillisecondsSinceEpoch(d);

        dateTime = getTimeValue(date, currentDate);

        /*final differenceDay = currentDate.difference(date).inDays;
        print("long   $d ++++" + differenceDay.toString());
        final differenceHours = currentDate.difference(date).inHours;
        final differenceMinutes = currentDate.difference(date).inMinutes;
        final differenceSeconds = currentDate.difference(date).inSeconds;
        if (differenceDay != 0) {
          if (differenceDay > 30) {
            dateTime = "a month ";
          } else {
            if (differenceDay == 1) {
              dateTime = "$differenceDay Day ";
            } else {
              dateTime = "$differenceDay Days ";
            }
          }
        } else if (differenceHours != 0) {
          if (differenceHours == 1) {
            dateTime = "$differenceHours Hour ";
          } else {
            dateTime = "$differenceHours Hours ";
          }
        } else if (differenceMinutes != 0) {
          if (differenceMinutes == 1) {
            dateTime = "$differenceMinutes Minute ";
          } else {
            dateTime = "$differenceMinutes Minutes ";
          }
        } else {
          dateTime = "few seconds ";
        }*/
      }

      dataList.add(new NotificationModel(
          notificationId,
          userId,
          actedBy,
          actedRoleId,
          postId,
          profilePicture,
          text,
          dateTime,
          isRead,
          textName,
          textMessage,
          roleId,
          type,
          values,
          actionValue,
          appModule,
          linkType,
          buttonText,
          buttonUrl,
          reqActionStatus,
          requestType,
          requestId));
    }

    return dataList;
  }

  static List<double> parseSpiderChart(map) {
    List<double> dataList = List();
    for (int i = 0; i < map.length; i++) {
      String _id = map[i]["_id"].toString();
      String importance = map[i]["importance"].toString();
      String name = map[i]["name"].toString();
      String importanceTitle = map[i]["importanceTitle"].toString();

      // dataList.add(new SpiderChartModel(_id, importance, name, importanceTitle));
      dataList.add(double.parse(importance));
    }

    return dataList;
  }

  static ShareProfileModal parseShareProfile(map) {
    try {
      String sharedId = map[0]['sharedId'].toString();
      String profileOwner = map[0]['profileOwner'].toString();
      String sharedView = map[0]['sharedView'].toString();
      String theme = map[0]['theme'].toString();
      String shareTo = map[0]['shareTo'].toString();
      String isActive = map[0]['isActive'].toString();
      String isViewed = map[0]['isViewed'].toString();

      var filter = map[0]['shareConfiguration'];
      List<FilterModel> dataList = List();
      for (int i = 0; i < filter.length; i++) {
        String importance = filter[i]["importance"].toString();
        String competencyTypeId = filter[i]["competencyTypeId"].toString();

        // dataList.add(new SpiderChartModel(_id, importance, name, importanceTitle));
        dataList.add(new FilterModel(importance, competencyTypeId));
      }
      return ShareProfileModal(sharedId, profileOwner, sharedView, theme,
          shareTo, isActive, isViewed, dataList);
    } catch (e) {
      return ShareProfileModal("", "", "", "", "", "", "", null);
    }
  }

  static ConnectionNotificationModel parseConnectionNotification(map) {
    try {
      String connectionCount = map[0]["connectionCount"].toString();
      String messagingCount = map[0]["messagingCount"].toString();
      String notificationCount = map[0]["notificationCount"].toString();
      String groupCount = map[0]["groupCount"].toString();

      return ConnectionNotificationModel(
          connectionCount, messagingCount, notificationCount, groupCount);
    } catch (e) {
      return ConnectionNotificationModel("", "", "", "");
    }
  }

/*  static List<OpportunityModel> parseOpportunityData(map) {
    List<OpportunityModel> narrativeList =  List<OpportunityModel>();
    for (int i = 0; i < map.length; i++) {
      try {
        String opportunityId = map[i]['opportunityId'].toString();
        String userId = map[i]['userId'].toString();
        String roleId = map[i]['roleId'].toString();
        String jobTitle = map[i]['jobTitle'].toString();
        String jobType = map[i]['jobType'].toString();
        String jobLocation = map[i]['jobLocation'].toString();
        String project = map[i]['project'].toString();
        String duration = map[i]['duration'].toString();
        String status = map[i]['status'].toString();
        String fromDate = map[i]['fromDate'].toString();
        String toDate = map[i]['toDate'].toString();
        String groupId = map[i]['groupId'].toString();
        String targetAudience = map[i]['targetAudience'].toString();
        String title = map[i]['title'].toString();
        String gender = map[i]['gender'].toString();
        String companyId = map[i]['companyId'].toString();
        String offerId = map[i]['offerId'].toString();
        String serviceTitle = map[i]['serviceTitle'].toString();
        String serviceDesc = map[i]['serviceDesc'].toString();
        String expiresOn = map[i]['expiresOn'].toString();
        String numberOfClick = map[i]['numberOfClick'].toString();
        String url = map[i]['url'].toString();

        List<Assest> assestList =  List<Assest>();
        List<Assest> assestVideoAndImage =  List<Assest>();
        List<Assest> videoList =  List<Assest>();
        List<Assest> docList =  List<Assest>();
        List<Assest> googleLinkList =  List<Assest>();
        List<Assest> mediaList =  List<Assest>();

        var asetMap = map[i]['asset'];
        for (int k = 0; k < asetMap.length; k++) {
          String type = asetMap[k]['type'].toString();
          String tag = asetMap[k]['tag'].toString();
          String file = asetMap[k]['file'].toString();
          //  file= getMediumImage(file);

          assestList.add(new Assest(type, tag, file, false));

          if (type == "image") {
            mediaList.add(new Assest(type, tag, file, false));
            assestVideoAndImage.add(new Assest(type, tag, file, false));
          } else if (type == "video") {
            videoList.add(new Assest(type, tag, file, false));
            assestVideoAndImage.add(new Assest(type, tag, file, false));
          } else if (type == "doc") {
            docList.add(new Assest(type, tag, file, false));
          } else if (type == "google") {
            googleLinkList.add(new Assest(type, tag, file, false));
          }
        }

        List<Address> locationList =  List<Address>();
        var locationMap = map[i]['location'];
        for (int i = 0; i < locationMap.length; i++) {
          String zipcode = locationMap[i]['zipcode'].toString();
          String city = locationMap[i]['city'].toString();
          String country = locationMap[i]['country'].toString();
          String state = locationMap[i]['state'].toString();
          String name = locationMap[i]['name'].toString();
          locationList
              .add(new Address(name, "", city, state, country, zipcode));
        }

        List<AgeBetween> ageList =  List<AgeBetween>();
        var ageMao = map[i]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          int to = ageMao[k]['to'];
          int from = ageMao[k]['from'];
          //  file= getMediumImage(file);

          ageList.add(new AgeBetween(toAge: to, fromAge: from));
        }

        List<IntrestModel> interestType =  List<IntrestModel>();
        try {
          var interestTypeModel = map[i]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
            //  file= getMediumImage(file);

            interestType.add(new IntrestModel(id, name));
          }
        } catch (e) {}
        String urlLinkForLearn,
            groupIdAction,
            callingNumber,
            formId,
            groupName,
            linkUrlPosition;
        bool isPublic;
        String actionType = map[i]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          urlLinkForLearn = map[i]['callToAction'][0]['url'].toString();
          linkUrlPosition = map[i]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction = map[i]['callToAction'][0]['groupId'].toString();
          groupName = map[i]['callToAction'][0]['groupName'].toString();
          isPublic = map[i]['callToAction'][0]['isPublic'];
          if (isPublic == null) {
            isPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber = map[i]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = map[i]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        narrativeList.add(new OpportunityModel(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            locationList,
            ageList,
            assestList,
            videoList,
            mediaList,
            docList,
            googleLinkList,
            assestVideoAndImage,
            interestType,
            expiresOn,
            numberOfClick,
            url,
            actionType,
            urlLinkForLearn,
            groupIdAction,
            callingNumber,
            formId,
            groupName,
            linkUrlPosition,
            isPublic));
      } catch (e) {
        print("Error++++++++" + e.toString());
        e.toString();
      }
    }

    return narrativeList;
  }*/

  static List<OpportunityModel> parseOpportunityData(map) {
    List<OpportunityModel> narrativeList = List<OpportunityModel>();
    for (int i = 0; i < map.length; i++) {
      try {
        String opportunityId = map[i]['opportunityId'].toString();
        String userId = map[i]['userId'].toString();
        String roleId = map[i]['roleId'].toString();
        String jobTitle = map[i]['jobTitle'].toString();
        String jobType = map[i]['jobType'].toString();
        String jobLocation = map[i]['jobLocation'].toString();
        String project = map[i]['project'].toString();
        String duration = map[i]['duration'].toString();
        String status = map[i]['status'].toString();
        String fromDate = map[i]['fromDate'].toString();
        String toDate = map[i]['toDate'].toString();
        String groupId = map[i]['groupId'].toString();
        String targetAudience = map[i]['targetAudience'].toString();
        String title = map[i]['title'].toString();
        String gender = map[i]['gender'].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = map[i]['companyId'].toString();
        String offerId = map[i]['offerId'].toString();
        String serviceTitle = map[i]['serviceTitle'].toString();
        String serviceDesc = map[i]['serviceDesc'].toString();
        String expiresOn = map[i]['expiresOn'].toString();
        String numberOfClick = map[i]['numberOfClick'].toString();
        String url = map[i]['url'].toString();

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = map[i]['asset'];

        for (int k = 0; k < asetMap.length; k++) {
          String type = asetMap[k]['type'].toString();
          String tag = asetMap[k]['tag'].toString();
          String file = asetMap[k]['file'].toString();
          String label = asetMap[k]['label'].toString();
// file= getMediumImage(file);

          assestList.add(new Assest(type, tag, file, label, false));

          if (type == "image") {
            mediaList.add(new Assest(type, tag, file, label, false));
            assestVideoAndImage.add(new Assest(type, tag, file, label, false));
          } else if (type == "video") {
            videoList.add(new Assest(type, tag, file, label, false));
            assestVideoAndImage.add(new Assest(type, tag, file, label, false));
          } else if (type == "doc") {
            docList.add(new Assest(type, tag, file, label, false));
          } else if (type == "google") {
            googleLinkList.add(new Assest(type, tag, file, label, false));
          }
        }

        List<Address> locationList = List<Address>();
        var locationMap = map[i]['location'];
        for (int i = 0; i < locationMap.length; i++) {
          String zipcode = locationMap[i]['zipcode'].toString();
          String city = locationMap[i]['city'].toString();
          String country = locationMap[i]['country'].toString();
          String state = locationMap[i]['state'].toString();
          String name = locationMap[i]['name'].toString();
          String target = locationMap[i]['target'].toString();

          locationList
              .add(Address(name, "", city, state, country, zipcode, target));
        }

        List<OtherCategory> otherCategoryList = List<OtherCategory>();
        var otherCategoryMap = map[i]['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();
            String categoryId = otherCategoryMap[i]['categoryId'].toString();
            String isOther = otherCategoryMap[i]['isOther'].toString();

            otherCategoryList.add(new OtherCategory(name, categoryId, isOther));
          }
        }

        List<OtherCategory> otherSubjectList = List<OtherCategory>();
        var otherSubjectMap = map[i]['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();
            String categoryId = otherSubjectMap[i]['categoryId'].toString();
            String isOther = otherSubjectMap[i]['isOther'].toString();

            otherSubjectList.add(new OtherCategory(name, categoryId, isOther));
          }
        }

        List<OtherCategory> otherCareerList = List<OtherCategory>();
        var otherCareerMap = map[i]['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();
            String categoryId = otherCareerMap[i]['categoryId'].toString();
            String isOther = otherCareerMap[i]['isOther'].toString();

            otherCareerList.add(new OtherCategory(name, categoryId, isOther));
          }
        }

        List<AgeBetween> ageList = List<AgeBetween>();
        var ageMao = map[i]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          int to = ageMao[k]['to'];
          int from = ageMao[k]['from'];
// file= getMediumImage(file);

          ageList.add(new AgeBetween(toAge: to, fromAge: from));
        }

        List<IntrestModel> interestType = List<IntrestModel>();
        try {
          var interestTypeModel = map[i]['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
// file= getMediumImage(file);

            interestType.add(new IntrestModel(id, name));
          }
        } catch (e) {}
        String urlLinkForLearn,
            groupIdAction,
            callingNumber,
            formId,
            groupName,
            linkUrlPosition;
        bool isPublic;
        String actionType = map[i]['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          urlLinkForLearn = map[i]['callToAction'][0]['url'].toString();
          linkUrlPosition = map[i]['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction = map[i]['callToAction'][0]['groupId'].toString();
          groupName = map[i]['callToAction'][0]['groupName'].toString();
          isPublic = map[i]['callToAction'][0]['isPublic'];
          if (isPublic == null) {
            isPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber = map[i]['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = map[i]['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        try {
          var userImageData = map[i]['userImage']; //
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = map[i]["supportedOffer"].toString();
        String fees = map[i]["fees"].toString();
        String description = map[i]["description"].toString();
        String bio = map[i]["bio"].toString();
        String timeZone = map[i]["timeZone"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        try {
          var sceduleData = map[i]['schedule']; //

          try {
            if (sceduleData != null) {
              for (int k = 0; k < sceduleData.length; k++) {
                String day = sceduleData[k]['day'].toString();
                var hours = sceduleData[k]['hours'];
                //  file= getMediumImage(file);
                //HoursData hoursData;
                List<HoursData> hoursList = List();
                for (var item in hours) {
                  hoursList.add(new HoursData(
                      timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
                }
                scheduleModelParam
                    .add(new ScheduleModelParam(day: day, hours: hoursList));
              }
            }
          } catch (e) {}
        } catch (e) {}
        List<DesignationModelParam> designationModelParam =
            List<DesignationModelParam>();
        try {
          var designationData = map[i]['category']; //
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new DesignationModelParam(
                  name: name,
                  isOther: isOther,
                  categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}
        List<SubjectModelParam> subjectModelParam = List<SubjectModelParam>();

        try {
          var subjectData = map[i]['subjects']; //
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(new SubjectModelParam(
                  name: name,
                  isOther: isOther,
                  subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}
        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        try {
          var qualificationData = map[i]['qualification']; //
          for (int k = 0; k < qualificationData.length; k++) {
            String name = qualificationData[k]['name'].toString();
            String isOtherS = qualificationData[k]['isOther'].toString();
            String qualificationId =
                qualificationData[k]['qualificationId'].toString();

            bool isOther = true;
            if (isOtherS == 'false') isOther = false;

            qualificationModelParam.add(new QualificationModelParam(
                name: name,
                isOther: isOther,
                qualificationId: int.parse(qualificationId)));
          }
        } catch (e) {}

        narrativeList.add(new OpportunityModel(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            locationList,
            ageList,
            assestList,
            videoList,
            mediaList,
            docList,
            googleLinkList,
            assestVideoAndImage,
            interestType,
            expiresOn,
            numberOfClick,
            url,
            actionType,
            urlLinkForLearn,
            groupIdAction,
            callingNumber,
            formId,
            groupName,
            linkUrlPosition,
            isPublic,
            fees,
            description,
            bio,
            "",
            //supportOffered,
//menteeSupport,
//advisorSupportOffered,
            "",
            //projectArea,
//userImage,
            userImageModelParam,

//qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            otherCategoryList,
            otherCareerList,
            otherSubjectList,
            timeZone
//category
            ));
      } catch (e) {
        print("Error++++++++" + e.toString());
        e.toString();
      }
    }

    return narrativeList;
  }

  static OpportunityModel parseOpportunityModel(map) {
    OpportunityModel _mOpportunityModel;
    for (int i = 0; i < map.length; i++) {
      try {
        var postOpportunity = map[i]["postOpportunity"][0];

        String opportunityId = postOpportunity['opportunityId'].toString();
        String userId = postOpportunity['userId'].toString();
        String roleId = postOpportunity['roleId'].toString();
        String jobTitle = postOpportunity['jobTitle'].toString();
        String jobType = postOpportunity['jobType'].toString();
        String jobLocation = postOpportunity['jobLocation'].toString();
        String project = postOpportunity['project'].toString();
        String duration = postOpportunity['duration'].toString();
        String status = postOpportunity['status'].toString();
        String fromDate = postOpportunity['fromDate'].toString();
        String toDate = postOpportunity['toDate'].toString();
        String groupId = postOpportunity['groupId'].toString();
        String targetAudience = postOpportunity['targetAudience'].toString();
        String title = postOpportunity['title'].toString();
        String gender = postOpportunity['gender'].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        String companyId = postOpportunity['companyId'].toString();
        String offerId = postOpportunity['offerId'].toString();
        String serviceTitle = postOpportunity['serviceTitle'].toString();
        String serviceDesc = postOpportunity['serviceDesc'].toString();
        String expiresOn = postOpportunity['expiresOn'].toString();
        String numberOfClick = postOpportunity['numberOfClick'].toString();
        String url = postOpportunity['url'].toString();

        List<Assest> assestList = List<Assest>();
        List<Assest> assestVideoAndImage = List<Assest>();
        List<Assest> videoList = List<Assest>();
        List<Assest> docList = List<Assest>();
        List<Assest> googleLinkList = List<Assest>();
        List<Assest> mediaList = List<Assest>();

        var asetMap = postOpportunity['asset'];

        for (int k = 0; k < asetMap.length; k++) {
          String type = asetMap[k]['type'].toString();
          String tag = asetMap[k]['tag'].toString();
          String file = asetMap[k]['file'].toString();
          String label = asetMap[k]['label'].toString();
// file= getMediumImage(file);

          assestList.add(new Assest(type, tag, file, label, false));

          if (type == "image") {
            mediaList.add(new Assest(type, tag, file, label, false));
            assestVideoAndImage.add(new Assest(type, tag, file, label, false));
          } else if (type == "video") {
            videoList.add(new Assest(type, tag, file, label, false));
            assestVideoAndImage.add(new Assest(type, tag, file, label, false));
          } else if (type == "doc") {
            docList.add(new Assest(type, tag, file, label, false));
          } else if (type == "google") {
            googleLinkList.add(new Assest(type, tag, file, label, false));
          }
        }

        List<Address> locationList = List<Address>();
        var locationMap = postOpportunity['location'];
        for (int i = 0; i < locationMap.length; i++) {
          String zipcode = locationMap[i]['zipcode'].toString();
          String city = locationMap[i]['city'].toString();
          String country = locationMap[i]['country'].toString();
          String state = locationMap[i]['state'].toString();
          String name = locationMap[i]['name'].toString();
          String target = locationMap[i]['target'].toString();
          locationList
              .add(Address(name, "", city, state, country, zipcode, target));
        }

        List<OtherCategory> otherCategoryList = List<OtherCategory>();
        var otherCategoryMap = postOpportunity['otherCategory'];
        if (otherCategoryMap != null) {
          for (int i = 0; i < otherCategoryMap.length; i++) {
            String name = otherCategoryMap[i]['name'].toString();
            String categoryId = otherCategoryMap[i]['categoryId'].toString();
            String isOther = otherCategoryMap[i]['isOther'].toString();

            otherCategoryList.add(new OtherCategory(name, categoryId, isOther));
          }
        }

        List<OtherCategory> otherSubjectList = List<OtherCategory>();
        var otherSubjectMap = postOpportunity['otherSubject'];
        if (otherSubjectMap != null) {
          for (int i = 0; i < otherSubjectMap.length; i++) {
            String name = otherSubjectMap[i]['name'].toString();
            String categoryId = otherSubjectMap[i]['categoryId'].toString();
            String isOther = otherSubjectMap[i]['isOther'].toString();

            otherSubjectList.add(new OtherCategory(name, categoryId, isOther));
          }
        }

        List<OtherCategory> otherCareerList = List<OtherCategory>();
        var otherCareerMap = postOpportunity['otherCareer'];
        if (otherCareerMap != null) {
          for (int i = 0; i < otherCareerMap.length; i++) {
            String name = otherCareerMap[i]['name'].toString();
            String categoryId = otherCareerMap[i]['categoryId'].toString();
            String isOther = otherCareerMap[i]['isOther'].toString();

            otherCareerList.add(new OtherCategory(name, categoryId, isOther));
          }
        }

        List<AgeBetween> ageList = List<AgeBetween>();
        var ageMao = postOpportunity['age'];
        for (int k = 0; k < ageMao.length; k++) {
          int to = ageMao[k]['to'];
          int from = ageMao[k]['from'];
// file= getMediumImage(file);

          ageList.add(new AgeBetween(toAge: to, fromAge: from));
        }

        List<IntrestModel> interestType = List<IntrestModel>();
        try {
          var interestTypeModel = postOpportunity['interestType'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
// file= getMediumImage(file);

            interestType.add(new IntrestModel(id, name));
          }
        } catch (e) {}
        String urlLinkForLearn,
            groupIdAction,
            callingNumber,
            formId,
            groupName,
            linkUrlPosition;
        bool isPublic;
        String actionType = postOpportunity['callToAction'][0]['id'].toString();
        if (actionType == Constant.LINK_URL) {
          urlLinkForLearn =
              postOpportunity['callToAction'][0]['url'].toString();
          linkUrlPosition =
              postOpportunity['callToAction'][0]['position'].toString();
          print("action+++" + url);
        } else if (actionType == Constant.JOIN_GROUP) {
          groupIdAction =
              postOpportunity['callToAction'][0]['groupId'].toString();
          groupName =
              postOpportunity['callToAction'][0]['groupName'].toString();
          isPublic = postOpportunity['callToAction'][0]['isPublic'];
          if (isPublic == null) {
            isPublic = true;
          }
          print("action+++jpoinGroup+++" + groupIdAction);
        } else if (actionType == Constant.CALL_NOW) {
          callingNumber =
              postOpportunity['callToAction'][0]['number'].toString();
          print("action+++" + callingNumber);
        } else if (actionType == Constant.INQUIRE_NOW) {
          formId = postOpportunity['callToAction'][0]['formId'].toString();
          print("action+++" + formId);
        }

        List<UserImageModelParam> userImageModelParam =
            List<UserImageModelParam>();
        try {
          var userImageData = postOpportunity['userImage']; //
          if (userImageData != null) {
            for (int k = 0; k < userImageData.length; k++) {
              String file = userImageData[k]['file'].toString();
              userImageModelParam.add(new UserImageModelParam(file: file));
            }
          }
        } catch (e) {}

        //String menteeSupport = postOpportunity["supportedOffer"].toString();
        String fees = postOpportunity["fees"].toString();
        String description = postOpportunity["description"].toString();
        String bio = postOpportunity["bio"].toString();
        String timeZone = postOpportunity["timeZone"].toString();

        List<ScheduleModelParam> scheduleModelParam =
            List<ScheduleModelParam>();
        try {
          var sceduleData = postOpportunity['schedule']; //

          try {
            if (sceduleData != null) {
              for (int k = 0; k < sceduleData.length; k++) {
                String day = sceduleData[k]['day'].toString();
                var hours = sceduleData[k]['hours'];
                //  file= getMediumImage(file);
                //HoursData hoursData;
                List<HoursData> hoursList = List();
                for (var item in hours) {
                  hoursList.add(new HoursData(
                      timeTo: item["timeTo"], timeFrom: item["timeFrom"]));
                }
                scheduleModelParam
                    .add(new ScheduleModelParam(day: day, hours: hoursList));
              }
            }
          } catch (e) {}
        } catch (e) {}
        List<DesignationModelParam> designationModelParam =
            List<DesignationModelParam>();
        try {
          var designationData = postOpportunity['category']; //
          if (designationData != null) {
            for (int k = 0; k < designationData.length; k++) {
              String name = designationData[k]['name'].toString();
              String isOtherS = designationData[k]['isOther'].toString();
              String categoryId = designationData[k]['categoryId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              designationModelParam.add(new DesignationModelParam(
                  name: name,
                  isOther: isOther,
                  categoryId: int.parse(categoryId)));
            }
          }
        } catch (e) {}
        List<SubjectModelParam> subjectModelParam = List<SubjectModelParam>();

        try {
          var subjectData = postOpportunity['subjects']; //
          if (subjectData != null) {
            for (int k = 0; k < subjectData.length; k++) {
              String name = subjectData[k]['name'].toString();
              String isOtherS = subjectData[k]['isOther'].toString();
              String subjectId = subjectData[k]['subjectId'].toString();

              bool isOther = true;
              if (isOtherS == 'false') isOther = false;

              subjectModelParam.add(new SubjectModelParam(
                  name: name,
                  isOther: isOther,
                  subjectId: int.parse(subjectId)));
            }
          }
        } catch (e) {}
        List<QualificationModelParam> qualificationModelParam =
            List<QualificationModelParam>();
        try {
          var qualificationData = postOpportunity['qualification']; //
          for (int k = 0; k < qualificationData.length; k++) {
            String name = qualificationData[k]['name'].toString();
            String isOtherS = qualificationData[k]['isOther'].toString();
            String qualificationId =
                qualificationData[k]['qualificationId'].toString();

            bool isOther = true;
            if (isOtherS == 'false') isOther = false;

            qualificationModelParam.add(new QualificationModelParam(
                name: name,
                isOther: isOther,
                qualificationId: int.parse(qualificationId)));
          }
        } catch (e) {}

        _mOpportunityModel = OpportunityModel(
            opportunityId,
            userId,
            roleId,
            jobTitle,
            jobType,
            jobLocation,
            project,
            duration,
            status,
            fromDate,
            toDate,
            groupId,
            targetAudience,
            title,
            gender,
            companyId,
            offerId,
            serviceTitle,
            serviceDesc,
            locationList,
            ageList,
            assestList,
            videoList,
            mediaList,
            docList,
            googleLinkList,
            assestVideoAndImage,
            interestType,
            expiresOn,
            numberOfClick,
            url,
            actionType,
            urlLinkForLearn,
            groupIdAction,
            callingNumber,
            formId,
            groupName,
            linkUrlPosition,
            isPublic,
            fees,
            description,
            bio,
            "",
            //supportOffered,
//menteeSupport,
//advisorSupportOffered,
            "",
            //projectArea,
//userImage,
            userImageModelParam,

//qualification,
            qualificationModelParam,
            designationModelParam,
            subjectModelParam,
            scheduleModelParam,
            otherCategoryList,
            otherCareerList,
            otherSubjectList,
            timeZone
//category
            );
      } catch (e) {
        print("Error++++++++" + e.toString());
        e.toString();
      }
    }

    return _mOpportunityModel;
  }

  static List<Service> serviceList(map) {
    List<Service> narrativeList = List<Service>();
    for (int i = 0; i < map.length; i++) {
      try {
        String title = map[i]['title'].toString();
        String cities = map[i]['cities'].toString();
        String gender = map[i]['gender'].toString();
        if (gender == "Non-binary" || gender == "NonBinary") {
          gender = "Non-Binary";
        }
        List<Address> locationList = List<Address>();
        var locationMap = map[i]['location'];
        for (int i = 0; i < locationMap.length; i++) {
          String zipcode = locationMap[i]['zipcode'].toString();
          String city = locationMap[i]['city'].toString();
          String country = locationMap[i]['country'].toString();
          String state = locationMap[i]['state'].toString();
          String name = locationMap[i]['name'].toString();
          String target = locationMap[i]['target'].toString();
          locationList
              .add(Address(name, "", city, state, country, zipcode, target));
        }

        List<AgeBetween> ageList = List<AgeBetween>();
        var ageMao = map[i]['age'];
        for (int k = 0; k < ageMao.length; k++) {
          int to = ageMao[k]['to'];
          int from = ageMao[k]['from'];
          //  file= getMediumImage(file);

          ageList.add(new AgeBetween(fromAge: from, toAge: to));
        }
        List<IntrestModel> interestType = List<IntrestModel>();
        try {
          var interestTypeModel = map[i]['interests'];
          for (int k = 0; k < interestTypeModel.length; k++) {
            String id = interestTypeModel[k]['id'].toString();
            String name = interestTypeModel[k]['name'].toString();
            //  file= getMediumImage(file);

            interestType.add(new IntrestModel(id, name));
          }
        } catch (e) {}

        narrativeList.add(Service(
            title, cities, gender, ageList, locationList, interestType));
      } catch (e) {
        e.toString();
      }
    }

    return narrativeList;
  }

  static Address addressParse(String address, String zipCode) {
    if (address != null && address != "") {
      List<String> addresList = address.split(",");
      try {
        List<String> zipDataList = addresList[1].trim().split(" ");

        return Address("", "", addresList[0].trim(), zipDataList[0].trim(),
            addresList[addresList.length - 1].trim(), zipCode.trim(), '');
      } catch (e) {
        return Address("", "", addresList[0].trim(), "",
            addresList[addresList.length - 1].trim(), zipCode.trim(), '');
      }
    }
  }

  static LocationData addressParse2(String address, String zipCode) {
    if (address != null && address != "") {
      List<String> addresList = address.split(",");
      try {
        List<String> zipDataList = addresList[1].trim().split(" ");

        return LocationData("", "", addresList[0].trim(), zipDataList[0].trim(),
            addresList[addresList.length - 1].trim(), zipCode.trim());
      } catch (e) {
        return LocationData("", "", addresList[0].trim(), "",
            addresList[addresList.length - 1].trim(), zipCode.trim());
      }
    }
  }

  static List<SkillBarModel> parseMapSkillListData(map) {
    List<SkillBarModel> skillList = List<SkillBarModel>();

    try {
      for (int j = 0; j < map.length; j++) {
        int skillId = map[j]['skillId'];
        String title = map[j]['title'].toString();
        String description = map[j]['description'].toString();
        double value;
        try {
          value = double.parse(map[j]['value'].toString());
        } catch (e) {
          print("Error++++" + map[j]['value'].toString());
          value = 1.0;
        }

        if (map[j]['value'].toString().length == 1) {
          value = value / 10;
        } else if (map[j]['value'].toString().length == 2) {
          double offset = value / 100;
          value = .9 + offset;
          if (value >= 1) {
            value = .95;
          }
        } else if (map[j]['value'].toString().length == 3) {
          double offset = value / 1000;
          value = .9 + offset;
          if (value >= 1) {
            value = .95;
          }
        }
        Color color = Color(0xff85D6F0);
        if (skillId == 1) {
          color = Color(0xff85D6F0);
        } else if (skillId == 2) {
          color = Color(0xffFD9D75);
        } else if (skillId == 3) {
          color = Color(0xffFD7575);
        } else if (skillId == 4) {
          color = Color(0xffFDC675);
        } else if (skillId == 5) {
          color = Color(0xff41BEC2);
        } else if (skillId == 6) {
          color = Color(0xff93DFE3);
        } else if (skillId == 7) {
          color = Color(0xffB06F49);
        } else if (skillId == 8) {
          color = Color(0xffAEE173);
        }

        skillList.add(new SkillBarModel(title, color, value, skillId));
      }
    } catch (e) {
      print("bar model+++Error+++" + e.toString());
    }
    return skillList;
  }

  static List<TestScoreModel> parseTestScoreData(map) {
    List<TestScoreModel> testScoreList = List<TestScoreModel>();
    for (int i = 0; i < map.length; i++) {
      try {
        int testId = map[i]['testId'];
        String testName = map[i]['name'].toString();
        bool isSubCategory = map[i]['isSubCategory'];
        if (isSubCategory == null) {
          isSubCategory = false;
        }
        var subjects = map[i]['subjects'];
        List<SebjectDetailModel> subjectList = List<SebjectDetailModel>();
        for (int j = 0; j < subjects.length; j++) {
          int testSubId = subjects[j]['testSubId'];
          int testId = subjects[j]['testId'];
          int minScore = subjects[j]['minScore'];
          int maxScore = subjects[j]['maxScore'];
          int sequence = subjects[j]['sequence'];

          String subjectName = subjects[j]['subject'].toString();
          bool isOptional = subjects[j]['isOptional'];
          if (isOptional == null) {
            isOptional = false;
          }
          subjectList.add(SebjectDetailModel(testSubId, testId, minScore,
              maxScore, sequence, subjectName, isOptional));
        }
        testScoreList
            .add(TestScoreModel(testName, testId, isSubCategory, subjectList));
      } catch (e) {
        e.toString();
      }
    }

    return testScoreList;
  }

  static List<MainScoreModel> parseTestList(map) {
    List<MainScoreModel> MainScoreList = List<MainScoreModel>();

    for (int j = 0; j < map.length; j++) {
      try {
        bool isSelected = false;
        if (j == 0) {
          isSelected = true;
        }

        var scoresList = map[j]['scores'];
        int testId = map[j]['testId'];

        String testName = map[j]['name'].toString();
        List<TestDataModel> testScoreList = List<TestDataModel>();
        for (int i = 0; i < scoresList.length; i++) {
          int testId = scoresList[i]['testId'];
          int userTestId = scoresList[i]['userTestId'];
          String testName = scoresList[i]['name'].toString();
          int dateTaken = scoresList[i]['dateTaken'];
          String creationDate = "";
          if (dateTaken != "" && dateTaken != "null") {
            var now = DateTime.fromMillisecondsSinceEpoch(dateTaken);
            var formatter = DateFormat('MMM dd, yyyy');
            creationDate = formatter.format(now);
          }
          List<String> docList = List<String>();
          var docUrl = scoresList[i]['docUrl'];

          if (docUrl != null) {
            for (int k = 0; k < docUrl.length; k++) {
              String url = docUrl[k].toString();
              if (url != "") docList.add(url);
            }
          }
          List<String> imageList = List<String>();
          var imageUrl = scoresList[i]['imageUrl'];

          if (imageUrl != null) {
            for (int k = 0; k < imageUrl.length; k++) {
              String url = imageUrl[k].toString();
              if (url != "") imageList.add(url);
            }
          }
          var subjects = scoresList[i]['subjects'];
          List<SubjectListModel> subjectListData = List<SubjectListModel>();

          for (int j = 0; j < subjects.length; j++) {
            String score = subjects[j]['score'].toString();
            if (score == null || score == "null") {
              score = "N/A";
            }
            int minScore = subjects[j]['minScore'];
            int maxScore = subjects[j]['maxScore'];
            int testSubId = subjects[j]['testSubId'];

            String subjectName = subjects[j]['subject'].toString();
            bool isOptional = subjects[j]['isOptional'];
            if (isOptional == null) {
              isOptional = false;
            }
            subjectListData.add(SubjectListModel(
                subjectName,
                score,
                minScore,
                maxScore,
                testSubId,
                TextEditingController(text: score == "N/A" ? "" : score),
                isOptional));
          }
          testScoreList.add(new TestDataModel(
              testName,
              testId,
              userTestId,
              creationDate,
              dateTaken,
              docList,
              subjectListData,
              imageList,
              dateTaken.toString()));
        }

        MainScoreList.add(
            MainScoreModel(testScoreList, testName, testId, isSelected));
      } catch (e) {
        print("error++++++++++" + e.toString());
        e.toString();
      }
    }

    return MainScoreList;
  }

  static List<Item> parseMapCountry(countryMap) {
    List<Item> listContry = List();
    try {
      for (int j = 0; j < countryMap.length; j++) {
        String id = countryMap[j]['id'].toString();
        String name = countryMap[j]['name'].toString();
        String sortname = countryMap[j]['sortname'].toString();
        String phonecode = countryMap[j]['phonecode'].toString();

        listContry.add(new Item(j, name, id, "", "", "", phonecode));
      }
    } catch (e) {}
    return listContry;
  }

  static List<BadgeDataModel> parseBadgeList(countryMap) {
    List<BadgeDataModel> badgeList = List();
    try {
      for (int j = 0; j < countryMap.length; j++) {
        int id = countryMap[j]['badgeId'];
        String name = countryMap[j]['name'].toString();
        String image = countryMap[j]['image'].toString();
        String status = countryMap[j]['status'].toString();
        int dateTaken = countryMap[j]['createdAt'];
        String creationDate = "";
        if (dateTaken != "" && dateTaken != "null") {
          var now = DateTime.fromMillisecondsSinceEpoch(dateTaken);
          var formatter = DateFormat('MMM dd, yyyy');
          creationDate = formatter.format(now);
        }

        badgeList
            .add(new BadgeDataModel(id, name, image, status, creationDate));
      }
    } catch (e) {}
    return badgeList;
  }

  static BadgeListModel parseBadgesData(map) {
    BadgeListModel badgeListModel;
    List<BadgeModel> requestedBadgeList = List();
    List<BadgeModel> collectionBadgeList = List();
    List<BadgeModel> presentBadgeList = List();
    List<BadgeModel> allBadgeList = List();
    try {
      var requestsMap = map['requests'];
      if (requestsMap != null) {
        for (int j = 0; j < requestsMap.length; j++) {
          int badgeId = requestsMap[j]['badgeId'];
          int badgeReqId = requestsMap[j]['badgeReqId'];
          String badgeName = requestsMap[j]['name'].toString();
          String message = requestsMap[j]['message'].toString();
          String badgeImage = requestsMap[j]['image'].toString();
          String status = requestsMap[j]['status'].toString();
          String userName = requestsMap[j]['userName'].toString();
          String userImage = requestsMap[j]['userImage'].toString();
          String userTagline = requestsMap[j]['userTagline'].toString();
          String companyName = requestsMap[j]['companyName'].toString();
          String type = requestsMap[j]['type'].toString();
          int dateTaken = requestsMap[j]['date'];
          int userId = requestsMap[j]['userId'];
          int userRoleId = requestsMap[j]['userRoleId'];
          String creationDate = "";
          if (dateTaken != "" && dateTaken != "null" && dateTaken != null) {
            var now = DateTime.fromMillisecondsSinceEpoch(dateTaken);
            var formatter = DateFormat('MMM dd, yyyy');
            creationDate = formatter.format(now);
          }
          String badgeImageGamification =
              requestsMap[j]['badgeImageGamification'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = requestsMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = requestsMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }
          if (companyName == "null" || companyName == "") {
            companyName = "";
          }

          if (creationDate == "null" || creationDate == "") {
            creationDate = "";
          }
          print("badgeImage++" + badgeImage.toString());
          requestedBadgeList.add(BadgeModel(
              badgeReqId,
              badgeId,
              message,
              badgeName,
              status,
              creationDate,
              badgeImage,
              userName,
              userImage,
              userTagline,
              companyName,
              userId,
              userRoleId,
              badge,
              gamificationPoints,
              badgeImageGamification,
              type));
        }
      }

      var collectionsMap = map['collections'];
      if (collectionsMap != null) {
        for (int j = 0; j < collectionsMap.length; j++) {
          int badgeId = collectionsMap[j]['badgeId'];
          int badgeReqId = collectionsMap[j]['badgeReqId'];
          String badgeName = collectionsMap[j]['name'].toString();
          String message = collectionsMap[j]['message'].toString();
          String badgeImage = collectionsMap[j]['image'].toString();
          String status = collectionsMap[j]['status'].toString();
          String userName = collectionsMap[j]['userName'].toString();
          String userImage = collectionsMap[j]['userImage'].toString();
          String userTagline = collectionsMap[j]['userTagline'].toString();
          String companyName = collectionsMap[j]['companyName'].toString();
          String type = collectionsMap[j]['type'].toString();
          int dateTaken = collectionsMap[j]['date'];
          int userId = collectionsMap[j]['userId'];
          int userRoleId = collectionsMap[j]['userRoleId'];
          String creationDate = "";
          if (dateTaken != "" && dateTaken != "null" && dateTaken != null) {
            var now = DateTime.fromMillisecondsSinceEpoch(dateTaken);
            var formatter = DateFormat('MMM dd, yyyy');
            creationDate = formatter.format(now);
          }

          String badgeImageGamification =
              collectionsMap[j]['badgeImageGamification'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          if (companyName == "null" || companyName == "") {
            companyName = "";
          }

          if (creationDate == "null" || creationDate == "") {
            creationDate = "";
          }
          String badge = collectionsMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification =
              collectionsMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          collectionBadgeList.add(BadgeModel(
              badgeReqId,
              badgeId,
              message,
              badgeName,
              status,
              creationDate,
              badgeImage,
              userName,
              userImage,
              userTagline,
              companyName,
              userId,
              userRoleId,
              badge,
              gamificationPoints,
              badgeImageGamification,
              type));
        }
      }

      var presentsMap = map['presents'];
      if (presentsMap != null) {
        for (int j = 0; j < presentsMap.length; j++) {
          int badgeId = presentsMap[j]['badgeId'];
          int badgeReqId = presentsMap[j]['badgeReqId'];
          String badgeName = presentsMap[j]['name'].toString();
          String message = presentsMap[j]['message'].toString();
          String badgeImage = presentsMap[j]['image'].toString();
          String status = presentsMap[j]['status'].toString();
          String userName = presentsMap[j]['userName'].toString();
          String userImage = presentsMap[j]['userImage'].toString();
          String userTagline = presentsMap[j]['userTagline'].toString();
          String companyName = presentsMap[j]['companyName'].toString();
          String type = presentsMap[j]['type'].toString();
          int dateTaken = presentsMap[j]['date'];
          int userId = presentsMap[j]['userId'];
          int userRoleId = presentsMap[j]['userRoleId'];
          String creationDate = "";
          if (dateTaken != "" && dateTaken != "null" && dateTaken != null) {
            var now = DateTime.fromMillisecondsSinceEpoch(dateTaken);
            var formatter = DateFormat('MMM dd, yyyy');
            creationDate = formatter.format(now);
          }
          if (companyName == "null" || companyName == "") {
            companyName = "";
          }

          if (creationDate == "null" || creationDate == "") {
            creationDate = "";
          }
          String badgeImageGamification =
              presentsMap[j]['badgeImageGamification'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = presentsMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification = presentsMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          presentBadgeList.add(BadgeModel(
              badgeReqId,
              badgeId,
              message,
              badgeName,
              status,
              creationDate,
              badgeImage,
              userName,
              userImage,
              userTagline,
              companyName,
              userId,
              userRoleId,
              badge,
              gamificationPoints,
              badgeImageGamification,
              type));
        }
      }

      var allBadgesMap = map['all'];
      if (allBadgesMap != null) {
        for (int j = 0; j < allBadgesMap.length; j++) {
          int badgeId = allBadgesMap[j]['badgeId'];
          int badgeReqId = allBadgesMap[j]['badgeReqId'];
          String badgeName = allBadgesMap[j]['name'].toString();
          String message = allBadgesMap[j]['message'].toString();
          String badgeImage = allBadgesMap[j]['image'].toString();
          String status = allBadgesMap[j]['status'].toString();
          String userName = allBadgesMap[j]['userName'].toString();
          String userImage = allBadgesMap[j]['userImage'].toString();
          String userTagline = allBadgesMap[j]['userTagline'].toString();
          String companyName = allBadgesMap[j]['companyName'].toString();
          String type = allBadgesMap[j]['type'].toString();
          int dateTaken = allBadgesMap[j]['date'];
          int userId = allBadgesMap[j]['userId'];
          int userRoleId = allBadgesMap[j]['userRoleId'];
          String creationDate = "";
          if (dateTaken != "" && dateTaken != "null" && dateTaken != null) {
            var now = DateTime.fromMillisecondsSinceEpoch(dateTaken);
            var formatter = DateFormat('MMM dd, yyyy');
            creationDate = formatter.format(now);
          }
          if (companyName == "null" || companyName == "") {
            companyName = "";
          }

          if (creationDate == "null" || creationDate == "") {
            creationDate = "";
          }
          String badgeImageGamification =
              allBadgesMap[j]['badgeImageGamification'].toString();
          if (badgeImage == "null" || badgeImage == "") {
            badgeImage = "";
          }
          String badge = allBadgesMap[j]['badge'].toString();
          if (badge == "null" || badge == "") {
            badge = "";
          }
          String gamification =
              allBadgesMap[j]['gamificationPoints'].toString();
          int gamificationPoints;
          if (gamification == "null" || gamification == "") {
            gamificationPoints = 0;
          } else {
            gamificationPoints = int.parse(gamification);
          }
          if (gamificationPoints == null) {
            gamificationPoints = 0;
          }

          allBadgeList.add(BadgeModel(
              badgeReqId,
              badgeId,
              message,
              badgeName,
              status,
              creationDate,
              badgeImage,
              userName,
              userImage,
              userTagline,
              companyName,
              userId,
              userRoleId,
              badge,
              gamificationPoints,
              badgeImageGamification,
              type));
        }
      }

      badgeListModel = BadgeListModel(requestedBadgeList, collectionBadgeList,
          presentBadgeList, allBadgeList);

      return badgeListModel;
    } catch (e) {}
    return badgeListModel;
  }

  static int getHours(DateTime date, DateTime currentDate) {
    int dateTime = 0;
    var seconds = currentDate.difference(date).inSeconds;
    print('difference between dates:: $seconds');

    var differenceYears = (seconds / 29030400).floor();
    var differenceMonths = (seconds / 2419200).floor();
    var differenceWeeks = (seconds / 604800).floor();
    var differenceDay = (seconds / 86400).floor();
    var differenceHours = (seconds / 3600).floor();
    var differenceMinutes = (seconds / 60).floor();
    var differenceSeconds = seconds;
    print(
        'differenceYears:: $differenceYears, differenceMonths:: $differenceMonths, differenceWeeks:: $differenceWeeks differenceDay:: $differenceDay, differenceHours:: $differenceHours, differenceMinutes:: $differenceMinutes, numseconds::: $seconds');

/*var differenceDay = currentDate.difference(date).inDays;
final differenceHours = currentDate.difference(date).inHours;
final differenceMinutes = currentDate.difference(date).inMinutes;
final differenceSeconds = currentDate.difference(date).inSeconds;*/

    return differenceHours;
  }

  static String getTimeValue(DateTime date, DateTime currentDate) {
    String dateTime = '';
    var seconds = currentDate.difference(date).inSeconds;
    print('difference between dates:: $seconds');

/*var numyears = (seconds / 31536000).floor();
var numdays = ((seconds % 31536000) / 86400).floor();
var numhours = (((seconds % 31536000) % 86400) / 3600).floor();
var numminutes = ((((seconds % 31536000) % 86400) % 3600) / 60).floor();
var numseconds = (((seconds % 31536000) % 86400) % 3600) % 60;
print('numyears:: $numyears, numdays:: $numdays, numhours:: $numhours, numminutes:: $numminutes, numseconds::: $numseconds');

int days = ((seconds/ (1000*60*60*24)) % 7).round();
int weeks = (seconds/ (1000*60*60*24*7)).round();
int months = weeks/30 as int;
int years = months/365 as int;
print('years:: $years, months:: $months, days:: $days');*/

/* Web code for calculation
var time_formats = [
[60, 'seconds', 1], // 60
[3600, 'Minutes', 60], // 60*60, 60
[86400, 'Hours', 3600], // 60*60*24, 60*60
[604800, 'Days', 86400], // 60*60*24*7, 60*60*24
[2419200, 'Weeks', 604800], // 60*60*24*7*4, 60*60*24*7
[29030400, 'Months', 2419200], // 60*60*24*7*4*12, 60*60*24*7*4
[2903040000, 'Years', 29030400], // 60*60*24*7*4*12*100, 60*60*24*7*4*12
];*/

    var differenceYears = (seconds / 29030400).floor();
    var differenceMonths = (seconds / 2419200).floor();
    var differenceWeeks = (seconds / 604800).floor();
    var differenceDay = (seconds / 86400).floor();
    var differenceHours = (seconds / 3600).floor();
    var differenceMinutes = (seconds / 60).floor();
    var differenceSeconds = seconds;
    print(
        'differenceYears:: $differenceYears, differenceMonths:: $differenceMonths, differenceWeeks:: $differenceWeeks differenceDay:: $differenceDay, differenceHours:: $differenceHours, differenceMinutes:: $differenceMinutes, numseconds::: $seconds');

/*var differenceDay = currentDate.difference(date).inDays;
final differenceHours = currentDate.difference(date).inHours;
final differenceMinutes = currentDate.difference(date).inMinutes;
final differenceSeconds = currentDate.difference(date).inSeconds;*/

    if (differenceYears > 0) {
      if (differenceYears == 1) {
        dateTime = "$differenceYears year ";
      } else {
        dateTime = "$differenceYears years ";
      }
    } else if (differenceMonths > 0) {
      if (differenceMonths == 1) {
        dateTime = "$differenceMonths month ";
      } else {
        dateTime = "$differenceMonths months ";
      }
    } else if (differenceDay > 0) {
      if (differenceDay == 1) {
        dateTime = "$differenceDay day ";
      } else {
        dateTime = "$differenceDay days ";
      }
    } else if (differenceHours > 0) {
      if (differenceHours == 1) {
        dateTime = "$differenceHours hour ";
      } else {
        dateTime = "$differenceHours hours ";
      }
    } else if (differenceMinutes > 0) {
      if (differenceMinutes == 1) {
        dateTime = "$differenceMinutes minute ";
      } else {
        dateTime = "$differenceMinutes minutes ";
      }
    } else {
      dateTime = "few seconds ";
    }
    return dateTime;
  }

  static String getMinutes(DateTime date, DateTime currentDate) {
    String dateTime = '';
    var seconds = currentDate.difference(date).inSeconds;
    print('difference between dates:: $seconds');

    var differenceYears = (seconds / 29030400).floor();
    var differenceMonths = (seconds / 2419200).floor();
    var differenceWeeks = (seconds / 604800).floor();
    var differenceDay = (seconds / 86400).floor();
    var differenceHours = (seconds / 3600).floor();
    var differenceMinutes = (seconds / 60).floor();
    var differenceSeconds = seconds;
    print(
        'differenceYears:: $differenceYears, differenceMonths:: $differenceMonths, differenceWeeks:: $differenceWeeks differenceDay:: $differenceDay, differenceHours:: $differenceHours, differenceMinutes:: $differenceMinutes, numseconds::: $seconds');

/*var differenceDay = currentDate.difference(date).inDays;
final differenceHours = currentDate.difference(date).inHours;
final differenceMinutes = currentDate.difference(date).inMinutes;
final differenceSeconds = currentDate.difference(date).inSeconds;*/

    dateTime = differenceMinutes.toString();
    if (dateTime == "") {
      dateTime = "0";
    }
    return dateTime;
  }

  static String getTimeValue2(DateTime date, DateTime currentDate) {
    String dateTime = '';
    var seconds = currentDate.difference(date).inSeconds;
    print('difference between dates:: $seconds');
    print('difference between dates:: $date');

    var differenceYears = (seconds / 29030400).floor();
    var differenceMonths = (seconds / 2419200).floor();
    var differenceWeeks = (seconds / 604800).floor();
    var differenceDay = (seconds / 86400).floor();
    var differenceHours = (seconds / 3600).floor();
    var differenceMinutes = (seconds / 60).floor();
    var differenceSeconds = seconds;
    print(
        'differenceYears:: $differenceYears, differenceMonths:: $differenceMonths, differenceWeeks:: $differenceWeeks differenceDay:: $differenceDay, differenceHours:: $differenceHours, differenceMinutes:: $differenceMinutes, numseconds::: $seconds');

    if (differenceYears > 0) {
      dateTime = "Not Available";
    } else if (differenceMonths > 0) {
      dateTime = "Not Available";
    } else if (differenceDay > 0) {
      dateTime = "Not Available";
    } else if (differenceHours > 0) {
      if (differenceHours == 1) {
        dateTime = "Last Seen : " + "$differenceHours Hour ";
      } else {
        dateTime = "Last Seen : " + "$differenceHours Hours ";
      }
    } else if (differenceMinutes > 0) {
      if (differenceMinutes == 1) {
        dateTime = "Last Seen : " + "$differenceMinutes Minute ";
      } else {
        dateTime = "Last Seen : " + "$differenceMinutes Minutes ";
      }
    } else {
      dateTime = "Last Seen : " + "few seconds ago";
    }

    return dateTime;
  }
}
