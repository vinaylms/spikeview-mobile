import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class EditGroupWidget extends StatefulWidget {
  GroupDetailModel groupDetailModel;
  String sasToken, containerName;

  EditGroupWidget(this.groupDetailModel, this.sasToken, this.containerName);

  @override
  EditGroupWidgetState createState() {
    return EditGroupWidgetState();
  }
}

class EditGroupWidgetState extends State<EditGroupWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, token;
  final _formKey = GlobalKey<FormState>();
  bool isChange = false;
  File imagePathCover;
  String strAzureCoverImageUploadPath = "", strPrefixPathforCoverPhoto = "";

  static const platform = const MethodChannel('samples.flutter.io/battery');
  String dob;
  int diffrenceInDob = 0;
  TextEditingController txtNameController,
      txtAboutController,
      txtOtherController;

  bool allFieldCompleted = false;

  checkAllFieldSubmitted() {
    try {
      if (txtNameController.text.length > 0 &&
          txtAboutController.text.length > 0) {
        allFieldCompleted = true;
        setState(() {});
      } else {
        allFieldCompleted = false;
        setState(() {});
      }
    } catch (e) {
      print('++++++++error' + e.toString());
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    dob = prefs.getString(UserPreference.DOB);

    if (dob != null && dob != 'null') {
      int millis = int.tryParse(dob);
      print('Apurva dob:: $dob, millis:: $millis');
      DateTime dobDate = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
      print(
          'Apurva dob:: $dob, millis:: $millis, dobDate:: $dobDate, diffrenceInDob:: $diffrenceInDob');
    }
    setState(() {});
    if (diffrenceInDob < 13) {
      if (widget.groupDetailModel.type == "public")
        isPrivate = false;
      else
        isPrivate = true;
    }
    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
  }

  String strGroupName, strAbout, strOtherInfo;
  bool isPrivate = false;

  //--------------------------Api Calling ------------------
  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        String type = "public";
        if (isPrivate) {
          type = "private";
        }

        if (isChange) {
          strAzureCoverImageUploadPath =
              strPrefixPathforCoverPhoto + strAzureCoverImageUploadPath;
        }
        print('dayya+++1' + strAzureCoverImageUploadPath);
        Map map = {
          "groupId": int.parse(widget.groupDetailModel.groupId),
          "groupName": strGroupName,
          "aboutGroup": strAbout,
          "otherInfo": strOtherInfo,
          "type": type,
          "roleId": int.parse(roleId),
          "groupImage": strAzureCoverImageUploadPath
        };
        print('map+++1' + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              Navigator.pop(context, "push");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditGroupWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.sasToken != "" && widget.containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": widget.sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditGroupWidget", context);
      return "";
    }
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePathCover = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 1.0,
      ratioY: 1.0,
    );
  }

  @override
  void initState() {
    getSharedPreferences();

    strAzureCoverImageUploadPath = widget.groupDetailModel.groupImage;

    if (strAzureCoverImageUploadPath == null) {
      strAzureCoverImageUploadPath = "";
    }
    txtNameController =
        TextEditingController(text: widget.groupDetailModel.groupName);

    txtAboutController = TextEditingController(
        text: widget.groupDetailModel.aboutGroup == 'null'
            ? ''
            : widget.groupDetailModel.aboutGroup);

    txtOtherController = TextEditingController(
        text: widget.groupDetailModel.otherInfo == 'null'
            ? ''
            : widget.groupDetailModel.otherInfo);

    if (widget.groupDetailModel.type == "public")
      isPrivate = false;
    else
      isPrivate = true;

    setState(() {});
    checkAllFieldSubmitted();
    super.initState();
  }

  Future getImageCover() async {
    imagePathCover = await UploadMedia(context).pickImageFromGallery();
    // imagePathCover = await ImagePicker.pickImage(source: ImageSource.gallery);
    if (imagePathCover != null) {
      String strPath = imagePathCover.toString().substring(
          imagePathCover.toString().lastIndexOf("/") + 1,
          imagePathCover.toString().length);

      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        if (imagePathCover != null) {
          await _cropImage(imagePathCover);
          isChange = true;
          strAzureCoverImageUploadPath = "";
          setState(() {});
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  Widget imageSelectionView() {
    return SizedBox(
      width: 113.0,
      height: 113.0,
      child: Container(
        width: 113.0,
        height: 113.0,
        child: InkWell(
            child: strAzureCoverImageUploadPath == "" ||
                    strAzureCoverImageUploadPath == "null"
                ? Stack(
                    children: <Widget>[
                      Positioned(
                        bottom: 5.0,
                        left: 0.0,
                        top: 0.0,
                        right: 0.0,
                        child: Image.asset(
                          "assets/newDesignIcon/group/default_circle_bg.png",
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0, left: 73),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                            child: Image.asset("assets/png/edit1.png"),
                            height: 24.0,
                            width: 24,
                          ),
                        ),
                      )
                    ],
                  )
                : Stack(
                    children: <Widget>[
                      Align(
                          alignment: Alignment.center,
                          child: SizedBox(
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(35.0),
                                child: Container(
                                    width: 113.0,
                                    height: 113.0,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(35),
                                        border: Border.all(
                                            color: Colors.white, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            blurRadius: 15,
                                            offset: Offset(2, 2),
                                            color: Color.fromRGBO(
                                                98, 175, 226, 0.09),
                                          )
                                        ]),
                                    child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                        child: FadeInImage.assetNetwork(
                                          fit: BoxFit.fill,
                                          placeholder:
                                              'assets/newDesignIcon/group/default_circle_bg.png',
                                          image: Constant.IMAGE_PATH +
                                              strAzureCoverImageUploadPath,
                                        )))),
                          )),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 2.0, left: 93),
                        child: Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                            child: Image.asset("assets/png/edit.png"),
                            height: 24.0,
                            width: 24,
                          ),
                        ),
                      )
                    ],
                  ),
            onTap: () async {
              var status = await Permission.photos.status;
              if (status.isGranted) {
                getImageCover();
              } else {
                checkPermissionPhoto(context);
              }
            }),
      ),
    );
  }

  Widget isImageSelectedView() {
    return SizedBox(
      width: 113.0,
      height: 113.0,
      child: Container(
        width: 113.0,
        height: 113.0,
        child: InkWell(
            child: Stack(
              children: <Widget>[
                Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      child: ClipRRect(
                          borderRadius: BorderRadius.circular(35.0),
                          child: Container(
                              width: 113.0,
                              height: 113.0,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(35),
                                  border:
                                      Border.all(color: Colors.white, width: 1),
                                  boxShadow: [
                                    BoxShadow(
                                      blurRadius: 15,
                                      offset: Offset(2, 2),
                                      color: Color.fromRGBO(98, 175, 226, 0.09),
                                    )
                                  ]),
                              child: Image.file(
                                imagePathCover,
                              ))),
                    )),
                Padding(
                  padding: const EdgeInsets.only(bottom: 2.0, left: 93),
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                      child: Image.asset("assets/png/edit.png"),
                      height: 24.0,
                      width: 24,
                    ),
                  ),
                )
              ],
            ),
            onTap: () async {
              var status = await Permission.photos.status;
              if (status.isGranted) {
                getImageCover();
              } else {
                checkPermissionPhoto(context);
              }
            }),
      ),
    );
  }

  void _checkValidation() async {
    final form = _formKey.currentState;
    form.save();
    if (form.validate()) {
      try {
        if (imagePathCover != null) {
          CustomProgressLoader.showLoader(context);

          Timer(const Duration(milliseconds: 400), () async {
            strAzureCoverImageUploadPath = await uploadImgOnAzure(
                imagePathCover
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim(),
                strPrefixPathforCoverPhoto);
            print('dayya+++' + strAzureCoverImageUploadPath);
            apiCalling();
          });

          // organizationApi();
        } else {
          CustomProgressLoader.showLoader(context);
          apiCalling();
        }
      } catch (e) {
        crashlytics_bloc.recordCrashlyticsError(e, "EditGroupWidget", context);
        CustomProgressLoader.cancelLoader(context);
      }
    } else {}
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    final groupName = CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      onType: (val) {
        checkAllFieldSubmitted();
      },
      controller: txtNameController,
      onSaved: (val) => strGroupName = val,
      maxLength: TextLength.GROUP_NAME_MAX_LENGTH,
      label: 'Group name',
      validation: (val) => val.trim().isEmpty
          ? MessageConstant.ENTER_GROUP_NAME_VAL
          : val.trim().length < 3
              ? MessageConstant.ENTER_MIN_3_CHAR_VAL
              : null,
    );

    final aboutGroupUi = CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      onType: (val) {
        checkAllFieldSubmitted();
      },
      onSaved: (val) => strAbout = val,
      maxLength: 500,
      controller: txtAboutController,
      minLines: 3,
      maxLines: 3,
      label: 'About group',
      counterTextValue: true,
      floatingBheaviour: true,
      validation: (val) => val.trim().isEmpty
          ? MessageConstant.ENTER_GROUP_MOTIVE_VAL
          : val.trim().length > 500
              ? MessageConstant.ENTER_GROUP_MOTIVE_VAL_MAximum
              : null,
    );

    final otherInfoUi = CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      onType: (val) {},
      onSaved: (val) => strOtherInfo = val.trim(),
      maxLength: 500,
      controller: txtOtherController,
      minLines: 3,
      maxLines: 3,
      counterTextValue: true,
      floatingBheaviour: true,
      label: 'Group rules',
    );

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
          return Future.value(false);
        },
        child: customAppbar(
            context,
            GestureDetector(
                onTap: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Edit group',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: ListView(
                        padding: EdgeInsets.all(0),
                        children: <Widget>[
                          Form(
                            key: _formKey,
                            child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0, right: 20, top: 0, bottom: 0),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      diffrenceInDob < 13
                                          ? Container(
                                              child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      3.0, 5.0, 10.0, 0.0),
                                                  child: Text(
                                                    MessageConstant
                                                        .UNDER_13_GROUP_MSG,
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            null,
                                                            FontType
                                                                .Regular), /*TextStyle(
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR,
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION)*/
                                                  )),
                                            )
                                          : Container(
                                              height: 0.0,
                                            ),
                                      Padding(
                                          padding:
                                              const EdgeInsets.only(top: 28.0),
                                          child: Center(
                                            child: SizedBox(
                                              width: 115,
                                              height: 115,
                                              child: InkWell(
                                                child: Stack(
                                                  children: <Widget>[
                                                    Container(
                                                        width: 113.0,
                                                        height: 113.0,
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        35),
                                                            border: Border.all(
                                                                color: Colors
                                                                    .white,
                                                                width: 2),
                                                            boxShadow: [
                                                              BoxShadow(
                                                                spreadRadius: 3,
                                                                blurRadius: 3,
                                                                offset: Offset(
                                                                    0, 2),
                                                                color: Color
                                                                    .fromRGBO(
                                                                        98,
                                                                        175,
                                                                        226,
                                                                        0.15),
                                                              )
                                                            ]),
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      35.0),
                                                          child: imagePathCover !=
                                                                  null
                                                              ? Image.file(
                                                                  imagePathCover,
                                                                  width: 113.0,
                                                                  height: 113.0,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                )
                                                              : Container(
                                                                  width: 113.0,
                                                                  height: 113.0,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              35),
                                                                      border: Border.all(
                                                                          color: Colors
                                                                              .white,
                                                                          width:
                                                                              1),
                                                                      boxShadow: [
                                                                        BoxShadow(
                                                                          spreadRadius:
                                                                              1,
                                                                          blurRadius:
                                                                              2,
                                                                          offset: Offset(
                                                                              0,
                                                                              2),
                                                                          color: Color.fromRGBO(
                                                                              98,
                                                                              175,
                                                                              226,
                                                                              0.15),
                                                                        )
                                                                      ]),
                                                                  child:
                                                                      ClipRRect(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            35.0),
                                                                    child: ClipRRect(
                                                                        borderRadius: BorderRadius.circular(15.0),
                                                                        child: FadeInImage.assetNetwork(
                                                                          fit: BoxFit
                                                                              .fill,
                                                                          placeholder:
                                                                              'assets/newDesignIcon/group/default_circle_bg.png',
                                                                          image:
                                                                              Constant.IMAGE_PATH + strAzureCoverImageUploadPath,
                                                                        )),
                                                                  )),
                                                        )),
                                                    Positioned(
                                                      bottom: 12.0,
                                                      right: 12.0,
                                                      child: Image.asset(
                                                        imagePathCover == null
                                                            ? "assets/png/edit1.png"
                                                            : 'assets/png/edit.png',
                                                        height: 24,
                                                        width: 24,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                onTap: () async {
                                                  var status = await Permission
                                                      .photos.status;
                                                  if (status.isGranted) {
                                                    getImageCover();
                                                  } else {
                                                    checkPermissionPhoto(
                                                        context);
                                                  }
                                                },
                                              ),
                                            ),
                                          )),

                                      /*
                                      Align(
                                          alignment: Alignment.center,
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              28.0,
                                              0.0,
                                              0.0,
                                              Container(
                                                  width: double.infinity,
                                                  child: imagePathCover == null
                                                      ? imageSelectionView()
                                                      : isImageSelectedView()))),*/
                                      diffrenceInDob < 13
                                          ? Container(
                                              height: 0.0,
                                            )
                                          : PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              28.0,
                                              0.0,
                                              0.0,
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Container(
                                                        //width: MediaQuery.of(context).size.width*0.45,
                                                        child: Text(
                                                          'Public group',
                                                          maxLines: 1,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                            color: !isPrivate
                                                                ? ColorValues
                                                                    .WHITE
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue,
                                                            fontSize: 16,
                                                            /*   fontWeight:
                                                                FontWeight.w600,*/
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoRegular,
                                                          ),
                                                        ),
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 9,
                                                                bottom: 9,
                                                                left: 9,
                                                                right: 9),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: !isPrivate
                                                              ? ColorValues
                                                                  .DARK_YELLOW
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .tabBg,
                                                          border: Border.all(
                                                              color: !isPrivate
                                                                  ? ColorValues
                                                                      .DARK_YELLOW
                                                                  : AppConstants
                                                                      .colorStyle
                                                                      .borderGenerateScript),
                                                          borderRadius:
                                                              const BorderRadius
                                                                      .only(
                                                                  topLeft: Radius
                                                                      .circular(
                                                                          10),
                                                                  bottomLeft: Radius
                                                                      .circular(
                                                                          10)),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        setState(() {
                                                          isPrivate = false;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Container(
                                                        //width: MediaQuery.of(context).size.width*0.45,
                                                        child: Text(
                                                          'Private group',
                                                          maxLines: 1,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                            color: isPrivate
                                                                ? ColorValues
                                                                    .WHITE
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue,
                                                            fontSize: 16,
                                                            /* fontWeight:
                                                                FontWeight.w600,*/
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoRegular,
                                                          ),
                                                        ),
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 9,
                                                                bottom: 9,
                                                                left: 9,
                                                                right: 9),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: isPrivate
                                                              ? ColorValues
                                                                  .DARK_YELLOW
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .tabBg,
                                                          border: Border.all(
                                                              color: AppConstants
                                                                  .colorStyle
                                                                  .borderGenerateScript),
                                                          borderRadius:
                                                              const BorderRadius
                                                                      .only(
                                                                  topRight: Radius
                                                                      .circular(
                                                                          10),
                                                                  bottomRight:
                                                                      Radius.circular(
                                                                          10)),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        setState(() {
                                                          isPrivate = true;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 24.0, 0.0, 0.0, groupName),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 20.0, 0.0, 0.0, aboutGroupUi),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 0.0, 0.0, 30.0, otherInfoUi),
                                    ])),
                          )
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                )), () {
          Navigator.pop(context);
        },
            isShowIcon: false,
            bottomNavigation: Stack(
              children: [
                PaddingWrap.paddingfromLTRB(
                    20.0,
                    20.0,
                    20.0,
                    20.0,
                    InkWell(
                      child: Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: AppConstants.colorStyle.lightBlue,
                            border: Border.all(
                                color: AppConstants.colorStyle.lightBlue),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Update",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.WHITE,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontSize: 18.0,
                                ),
                              ))),
                      onTap: () async {
                        _checkValidation();
                      },
                    )),
                allFieldCompleted
                    ? SizedBox(
                        height: 0,
                      )
                    : Container(
                        height: 75.0,
                        width: double.infinity,
                        color: Colors.white.withOpacity(0.75),
                      )
              ],
            )));

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                appBar: AppBar(
                  elevation: 0.0,
                  automaticallyImplyLeading: false,
                  titleSpacing: 2.0,
                  brightness: Brightness.light,
                  leading: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                        child: SizedBox(
                          height: 40.0,
                          width: 40.0,
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              5.0,
                              0.0,
                              3.0,
                              Center(
                                  child: Image.asset(
                                      "assets/newDesignIcon/navigation/back.png",
                                      height: 20.0,
                                      width: 10.0,
                                      fit: BoxFit.fitHeight))),
                        ),
                        onTap: () {
                          Navigator.pop(context);
                        },
                      )
                    ],
                  ),
                  actions: <Widget>[
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          5.0,
                          7.0,
                          8.0,
                          5.0,
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                MessageConstant.ABOUT_GROUP_UPDATE,
                                style: AppTextStyle.getDynamicStyleGroup(
                                    ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    16.0,
                                    FontType
                                        .Regular), /*TextStyle(
                                    fontSize: 16.0,
                                    fontFamily: Constant.customRegular,
                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR),*/
                              )
                            ],
                          )),
                      onTap: () {
                        _checkValidation();
                      },
                    )
                  ],
                  title: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        MessageConstant.ABOUT_GROUP_GROUP,
                        style: AppTextStyle.getDynamicStyleGroup(
                            ColorValues.HEADING_COLOR_EDUCATION,
                            18.0,
                            FontType
                                .Regular), /* TextStyle(
                            fontSize: 18.0,
                            fontFamily: Constant.customRegular,
                            color:
                                 ColorValues.HEADING_COLOR_EDUCATION),*/
                      )
                    ],
                  ),
                  backgroundColor: Colors.white,
                ),
                body: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 20, bottom: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Edit group',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),
                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: ListView(
                        children: <Widget>[
                          Form(
                            key: _formKey,
                            child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0, right: 20, top: 0, bottom: 0),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      diffrenceInDob < 13
                                          ? Container(
                                              child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      10.0, 10.0, 10.0, 0.0),
                                                  child: Text(
                                                    MessageConstant
                                                        .UNDER_13_GROUP_MSG,
                                                    style: AppTextStyle
                                                        .getDynamicStyleGroup(
                                                            ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            null,
                                                            FontType
                                                                .Regular), /*TextStyle(
                                                              fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR,
                                                              color:  ColorValues.HEADING_COLOR_EDUCATION)*/
                                                  )),
                                            )
                                          : Container(
                                              height: 0.0,
                                            ),
                                      Align(
                                          alignment: Alignment.center,
                                          child: PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              0.0,
                                              0.0,
                                              0.0,
                                              Container(
                                                  width: double.infinity,
                                                  child: imagePathCover == null
                                                      ? imageSelectionView()
                                                      : isImageSelectedView()))),
                                      diffrenceInDob < 13
                                          ? Container(
                                              height: 0.0,
                                            )
                                          : PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              25.0,
                                              0.0,
                                              0.0,
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Container(
                                                        //width: MediaQuery.of(context).size.width*0.45,
                                                        child: Text(
                                                          'Public',
                                                          maxLines: 1,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                            color: !isPrivate
                                                                ? ColorValues
                                                                    .WHITE
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoRegular,
                                                          ),
                                                        ),
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 9,
                                                                bottom: 9,
                                                                left: 9,
                                                                right: 9),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: !isPrivate
                                                              ? ColorValues
                                                                  .DARK_YELLOW
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .tabBg,
                                                          border: Border.all(
                                                              color: !isPrivate
                                                                  ? ColorValues
                                                                      .DARK_YELLOW
                                                                  : AppConstants
                                                                      .colorStyle
                                                                      .borderGenerateScript),
                                                          borderRadius:
                                                              const BorderRadius
                                                                      .only(
                                                                  topLeft: Radius
                                                                      .circular(
                                                                          10),
                                                                  bottomLeft: Radius
                                                                      .circular(
                                                                          10)),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        setState(() {
                                                          isPrivate = false;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Container(
                                                        //width: MediaQuery.of(context).size.width*0.45,
                                                        child: Text(
                                                          'Private',
                                                          maxLines: 1,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                            color: isPrivate
                                                                ? ColorValues
                                                                    .WHITE
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoRegular,
                                                          ),
                                                        ),
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 9,
                                                                bottom: 9,
                                                                left: 9,
                                                                right: 9),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: isPrivate
                                                              ? ColorValues
                                                                  .DARK_YELLOW
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .tabBg,
                                                          border: Border.all(
                                                              color: AppConstants
                                                                  .colorStyle
                                                                  .borderGenerateScript),
                                                          borderRadius:
                                                              const BorderRadius
                                                                      .only(
                                                                  topRight: Radius
                                                                      .circular(
                                                                          10),
                                                                  bottomRight:
                                                                      Radius.circular(
                                                                          10)),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        setState(() {
                                                          isPrivate = true;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 35.0, 0.0, 0.0, groupName),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 30.0, 0.0, 0.0, aboutGroupUi),
                                      /*   Padding(
                                        padding: const EdgeInsets.only(top:20.0),
                                        child: BaseText(
                                          text: 'Group rules',
                                          textColor: ColorValues.labelColor,
                                          fontFamily:
                                          AppConstants.stringConstant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                          textAlign: TextAlign.start,
                                          maxLines: 3,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top:3.0),
                                        child: Row(
                                          children: [
                                            Expanded(child:Padding(
                                                padding: const EdgeInsets.only(left:5.0,top: 3),
                                                child: Container(
                                                  decoration: new BoxDecoration(
                                                      color: Color(0xff3D4361),
                                                      borderRadius: new BorderRadius.all(Radius.circular(10)
                                                      )
                                                  ),
                                                  height: 8,width:8,)) ,flex: 0,),
                                            Expanded(child: Padding(
                                              padding: const EdgeInsets.only(left:7.0),
                                              child: BaseText(
                                                text: 'Growing the group towards its purpose.',
                                                textColor: ColorValues.TEXT_COLOR,
                                                fontFamily:
                                                AppConstants.stringConstant.latoRegular,
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                textAlign: TextAlign.start,
                                                maxLines: 3,
                                              ),
                                            ) ,flex: 1,),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top:3.0),
                                        child: Row(
                                          children: [
                                            Expanded(child:Padding(
                                                padding: const EdgeInsets.only(left:5.0,top: 3),
                                                child: Container(
                                                  decoration: new BoxDecoration(
                                                      color: Color(0xff3D4361),
                                                      borderRadius: new BorderRadius.all(Radius.circular(10)
                                                      )
                                                  ),
                                                  height: 8,width:8,)) ,flex: 0,),
                                            Expanded(child: Padding(
                                              padding: const EdgeInsets.only(left:7.0),
                                              child: BaseText(
                                                text: 'Keeping the group spam-free.',
                                                textColor: ColorValues.TEXT_COLOR,
                                                fontFamily:
                                                AppConstants.stringConstant.latoRegular,
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                textAlign: TextAlign.start,
                                                maxLines: 3,
                                              ),
                                            ) ,flex: 1,),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top:3.0),
                                        child: Row(
                                          children: [
                                            Expanded(child:Padding(
                                                padding: const EdgeInsets.only(left:5.0,top: 3),
                                                child: Container(
                                                  decoration: new BoxDecoration(
                                                      color: Color(0xff3D4361),
                                                      borderRadius: new BorderRadius.all(Radius.circular(10)
                                                      )
                                                  ),
                                                  height: 8,width:8,)) ,flex: 0,),
                                            Expanded(child: Padding(
                                              padding: const EdgeInsets.only(left:7.0),
                                              child: BaseText(
                                                text: 'Acquainting members with Dos and Don’ts.',
                                                textColor: ColorValues.TEXT_COLOR,
                                                fontFamily:
                                                AppConstants.stringConstant.latoRegular,
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                textAlign: TextAlign.start,
                                                maxLines: 3,
                                              ),
                                            ) ,flex: 1,),
                                          ],
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top:3.0),
                                        child: Row(
                                          children: [
                                            Expanded(child:Padding(
                                                padding: const EdgeInsets.only(left:5.0,top: 3),
                                                child: Container(
                                                  decoration: new BoxDecoration(
                                                      color: Color(0xff3D4361),
                                                      borderRadius: new BorderRadius.all(Radius.circular(10)
                                                      )
                                                  ),
                                                  height: 8,width:8,)) ,flex: 0,),
                                            Expanded(child: Padding(
                                              padding: const EdgeInsets.only(left:7.0),
                                              child: BaseText(
                                                text: 'Be Kind and Courteous.',
                                                textColor: ColorValues.TEXT_COLOR,
                                                fontFamily:
                                                AppConstants.stringConstant.latoRegular,
                                                fontWeight: FontWeight.w500,
                                                fontSize: 16,
                                                textAlign: TextAlign.start,
                                                maxLines: 3,
                                              ),
                                            ) ,flex: 1,),
                                          ],
                                        ),
                                      ),*/

                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 20.0, 0.0, 0.0, otherInfoUi),
                                    ])),
                          )
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                ))));
  }
}
