import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:thumbnails/thumbnails.dart';
import 'package:video_player/video_player.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

class VideoViewForIntro extends StatefulWidget {
  final String path;
  bool isPlay = false;
  bool isLoader = false;
  String feedId,thumbnailUrl;
  VideoViewForIntro(this.path, this.feedId,this.isLoader,this.thumbnailUrl);

  @override
  State createState() {
    return  VideoViewForIntroState();
  }
}

class VideoViewForIntroState extends State<VideoViewForIntro> {
  VoidCallback listener;
  bool isApiNeedToCall = true;
  VideoPlayerController controller;
  ChewieController _chewieController;
  static StreamController syncDoneController = StreamController.broadcast();
bool isplaying=false;


  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.network(widget.path.replaceAll(" ", "%20"));

    controller.setVolume(0.0);

    controller.pause();
    controller.initialize();
    controller.seekTo(Duration(seconds: 5));
    controller.addListener(() {
      if(controller.value.isPlaying||isplaying) {
        final bool isPlaying = controller.value.isPlaying;
        if (isPlaying) {
          isplaying=true;
        } else {
          isplaying=false;
          syncDoneController.add("sucess");
        }
      }
    });

  }

  @override
  void deactivate() {
    controller.setVolume(0.0);
    controller.removeListener(listener);
    //_chewieController.dispose();
    super.deactivate();
  }

  @override
  Widget build(BuildContext context) {
    Widget _loader(BuildContext context, String placeHolderImage) => Center(
        child: Container(
          child:  Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }

    final List<Widget> children = <Widget>[
       GestureDetector(
        child:  Container(
            color: Colors.black,
            child:  Stack(
              children: <Widget>[
                 Center(
                  child: controller.value.initialized
                      ? Chewie(
                    controller: ChewieController(
                      videoPlayerController: controller,
                      autoPlay: true,

                      allowFullScreen: false,
                      aspectRatio: controller.value.aspectRatio,
                      looping: false,
                      showControls: true,
                      // Try playing around with some of these other options:
                      placeholder: Container(
                        child:   CachedNetworkImage(
                          height: 200.0,

                          imageUrl: Constant
                              .IMAGE_PATH +
                             widget
                                  .thumbnailUrl,
                          fit: BoxFit.contain,
                          placeholder: (context,
                              url) =>
                              _loader(
                                  context, ""),
                          errorWidget: (context,
                              url, error) =>
                              _error(""),
                        ),
                        color: Colors.black,
                      ),
                    ),
                  )
                      :  Center(
                      child:  Container(
                        child:  CircularProgressIndicator(),
                      )),
                ),
              ],
            )),onTap: (){
        bool isPlaying = controller.value.isPlaying;
        if (isPlaying) {
        }else{
          syncDoneController.add("sucess");

        }
      },

      ),

    ];


    return  Stack(
      alignment: Alignment.bottomCenter,
      fit: StackFit.passthrough,
      children: children,
    );
  }
}
