import 'dart:async';
import 'dart:io';
import 'package:path/path.dart' as pat;
import 'package:spike_view_project/db/chat_model.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:convert';
import 'package:spike_view_project/modal/UserPostModel.dart';

class DbHelper {
  //podesavanje singltona 1/3
  static final DbHelper _dbHelper = DbHelper._internal();

  //table name
  String tblName = "Feed";
  String tblNameFriendList = "FriendList";

  //columns
  String feedId = "feedId";
  String data = "data";

  DbHelper._internal();

  //podesavanje singltona 3/3
  factory DbHelper() {
    return _dbHelper;
  }

  static Database _db;

  Future<Database> get db async {
    if (_db == null) {
      _db = await initializeDb();
    }
    return _db;
  }

  //za ovo koristimo 'dart:io';
  Future<Database> initializeDb() async {
    /*  Directory dir = await getApplicationDocumentsDirectory();
    String path = dir.path + "spikeview.db";*/

    var directory = await getDatabasesPath();
    print("directory path" + directory.toString());
    String path = pat.join(directory.toString(), "spikeviewdatabase.db");
    var dbTodos = await openDatabase(path, version: 1, onCreate: _createDb);
    return dbTodos;
  }

  void _createDb(Database db, int newVersion) async {
    await db
        .execute("CREATE TABLE $tblName($feedId TEXT PRIMARY KEY, $data TEXT)");

    await db.execute(
        'CREATE TABLE $tblNameFriendList (id INTEGER PRIMARY KEY, connectId INTEGER, userId INTEGER, firstName TEXT,'
        ' lastName TEXT, profilePicture TEXT, partnerId INTEGER,'
        ' partnerFirstName TEXT, partnerLastName TEXT,partnerRoleId INTEGER, partnerProfilePicture TEXT, dateTime INTEGER, '
        'creationTime INTEGER,'
        ' online INTEGER, isActive TEXT, lastMessage TEXT, unreadMessages INTEGER, lastTime INTEGER, '
        'lastSeen INTEGER, textSentBy INTEGER'
        ', badge TEXT'
        ', badgeImage TEXT'
        ', gamificationPoints INTEGER)');
  }

  Future<int> insertTodo(feed, desc) async {
    Database db = await this.db;
    var result = await db.rawInsert(
        'INSERT INTO $tblName ($feedId, $data) VALUES($feed,  $desc)');
    return result;
  }

  Future<int> numberOfItem() async {
    Database db = await this.db;
    var result = await db.rawQuery("SELECT COUNT(*) FROM $tblName");
    int count = Sqflite.firstIntValue(result);
    return count;
  }

  Future<List<UserPostModal>> getCount(userId, roelID) async {
    List<UserPostModal> userPostList = List<UserPostModal>();
    try {
      Database db = await this.db;
      var result = await db.rawQuery("SELECT * FROM $tblName");
      userPostList.addAll(ParseJson.parseFeedData(result, userId, roelID));
    } catch (e) {}
    return userPostList;
  }

  Future<int> updateFeedDataLikes(String id, List<Likes> model) async {
    Database db = await this.db;
    var result =
        await db.rawQuery("SELECT * FROM $tblName WHERE $feedId =  $id");
    var map = jsonDecode(result[0]['data'].replaceAll("_s_", "\""));
    try {
      map['post']['text'] = map['post']['text'].replaceAll('\\n', '\n');
    } catch (e) {}
    try {
      map['shareText'] = map['shareText'].replaceAll('\\n', '\n');
    } catch (e) {}
    map['likes'] = model.map((v) => v.toJson()).toList();
    String dataValue =
        jsonEncode(jsonEncode(map).replaceAll("\"", "_s_").toString());
    var result1 = await db.rawUpdate(
        'UPDATE $tblName SET $data = $dataValue WHERE $feedId = $id');
    return result1;
  }

  Future<int> updateFeedDataComments(String id, List<CommentData> model) async {
    Database db = await this.db;
    var result =
        await db.rawQuery("SELECT * FROM $tblName WHERE $feedId =  $id");
    var map = jsonDecode(result[0]['data'].replaceAll("_s_", "\""));
    try {
      map['post']['text'] = map['post']['text'].replaceAll('\\n', '\n');
    } catch (e) {}
    try {
      map['shareText'] = map['shareText'].replaceAll('\\n', '\n');
    } catch (e) {}
    map['comments'] = model.map((v) => v.toJson()).toList();
    String dataValue = jsonEncode(jsonEncode(map)
        .replaceAll('\\n', '\n')
        .replaceAll("\"", "_s_")
        .toString());
    var result1 = await db.rawUpdate(
        'UPDATE $tblName SET $data = $dataValue WHERE $feedId = $id');
    return result1;
  }

  Future<int> deleteitem(String id) async {
    try {
      Database db = await this.db;

      var result =
          await db.rawDelete("DELETE FROM $tblName WHERE $feedId =  $id");
      return result;
    } catch (e) {
      return 0;
    }
  }

  Future<int> deleteTable() async {
    Database db = await this.db;
    var result = await db.delete(tblName);
    print("delet table" + result.toString());
    return result;
  }

// ========================= Chat Data Base==================

  Future<Student> add(Student student) async {
    var dbClient = await db;
    student.id = await dbClient.insert(tblNameFriendList, student.toMap());
    return student;
  }

  Future<List<Student>> getChatListDB() async {
    var dbClient = await db;
    List<Map> maps = await dbClient.query(tblNameFriendList, columns: [
      'id',
      'connectId',
      'userId',
      'firstName',
      'lastName',
      'profilePicture',
      'partnerId',
      'partnerFirstName',
      'partnerLastName',
      'partnerRoleId',
      'partnerProfilePicture',
      'dateTime',
      'creationTime',
      'online',
      'isActive',
      'lastMessage',
      'unreadMessages',
      'lastTime',
      'lastSeen',
      'textSentBy',
      'badge',
      'badgeImage',
      'gamificationPoints'
    ]);
    List<Student> students = [];
    if (maps.length > 0) {
      for (int i = 0; i < maps.length; i++) {
        students.add(Student.fromMap(maps[i]));
      }
    }
    return students;
  }

  Future<int> delete(int id) async {
    var dbClient = await db;
    return await dbClient.delete(
      tblNameFriendList,
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> update(Student student) async {
    var dbClient = await db;
    return await dbClient.update(
      tblNameFriendList,
      student.toMap(),
      where: 'id = ?',
      whereArgs: [student.id],
    );
  }

  Future close() async {
    var dbClient = await db;
    dbClient.close();
  }

  Future<int> deleteChatTable() async {
    Database db = await this.db;
    //var result = db.delete('student');
    var result = await db.delete(tblNameFriendList);
    print("delet table" + result.toString());
    return result;
  }
}
