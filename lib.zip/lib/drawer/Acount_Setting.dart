import 'dart:async';

import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/drawer/ProfileVisibilitySetting.dart';
import 'package:spike_view_project/gateway/ChangePassword.dart';
import 'package:spike_view_project/gateway/partner_signup/partner_profile_view.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parentProfile/EditParentProfile.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/EditUserProfile.dart';
import 'package:spike_view_project/updateEmail/update_email.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';

class Account_Setting extends StatefulWidget {
  String userIdPref, role;

  Account_Setting(this.userIdPref, this.role);

  @override
  Account_SettingState createState() => Account_SettingState();
}

class Account_SettingState extends State<Account_Setting> {
  bool selectActiveButton1 = false;
  bool selectActiveButton2 = true;
  String isPerformChanges = "pop", userIdPref, roleId, dob = "0", isHide = "";
  int diffrenceInDob;
  SharedPreferences prefs;
  ProfileInfoModal profileInfoModal;
  bool isLoading = false;
  bool isCoomunitySetting = true;
  bool isPreLoginSetting = true;
  bool isFeed_AccessControl = true;
  bool isProfileVisibility = true;

  String partnerStatus = '';

  showSucessMsg(msg, context, duration, maxLine) {
    Timer _timer;

    _timer = Timer(Duration(milliseconds: duration), () async {
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isShowLaoder) CustomProgressLoader.showLoader(context);
        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");

        if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                if (mounted) {
                  try {
                    isPreLoginSetting =
                        response.data["result"]["isLeaderboardDisplay"];
                    var communityPostSubscription =
                        response.data["result"]["communityPostSubscription"];
                    if (communityPostSubscription != null &&
                        communityPostSubscription.length > 0) {
                      for (int i = 0;
                          i < communityPostSubscription.length;
                          i++) {
                        if (communityPostSubscription[i]["roleId"].toString() ==
                            roleId) {
                          isCoomunitySetting =
                              communityPostSubscription[i]["isSubscribed"];
                          setState(() {});
                        }
                      }
                    }
                  } catch (e) {
                    crashlytics_bloc.recordCrashlyticsError(
                        e, "Account_Setting", context);
                  }
                  setState(() {
                    isHide = profileInfoModal.isHide;
                    prefs.setString(
                        UserPreference.ISHide, profileInfoModal.isHide);
                    prefs.setString(
                        UserPreference.ISACTIVE, profileInfoModal.isActive);
                  });
                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "Account_Setting", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallingForCommunitySetting(value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "isSubscribed": value
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_COMMUNITY_SETTING, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isCoomunitySetting = value;
           // showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "Account_Setting", context);
      e.toString();
    }
  }

  Future apiCallingForPreLogin(value) async {
    try {
      Response response;

      Map map = {
        "userId": int.parse(userIdPref),
        "roleId": int.parse(roleId),
        "isLeaderboardDisplay": value
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_LEADERBOARD_SETTING, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isPreLoginSetting = value;
            showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "Account_Setting", context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    dob = prefs.getString(UserPreference.DOB);
    isHide = prefs.getString(UserPreference.ISHide);
    partnerStatus = prefs.getString(UserPreference.PARTNER_STATUS);
    print('AccountSettings partnerStatus:: $partnerStatus');

    bool isProfileShare =true;
    bool isProfileVisiblity =true;
    try {
      isProfileShare =
      prefs.getString(UserPreference.ACCESS_CONTROL_PROFILE_SHARE) == "true"
          ? true
          : false;
    }catch(e){

    }

    try{
      isProfileVisiblity =
      prefs.getString(UserPreference.ACCESS_CONTROL_PROFILE_VISIBILITY) == "enable"
          ? true
          : false;
    }catch(e){

    }
    if(!isProfileShare && !isProfileVisiblity){
      isProfileVisibility=false;
    }

    isFeed_AccessControl =
        prefs.getString(UserPreference.ACCESS_CONTROL_FEED_STATUS).toLowerCase() ==
            "true";




    setState(() {
      isLoading = true;
    });
    await profileApi(true);
    setState(() {
      isLoading = false;
      roleId;
    });
    setState(() {
      userIdPref;
      dob;
      isHide;
    });
  }

  Future apiCallingForUpdateStudentHideStatus(isHideBool) async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "isHide": isHideBool,
      };

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_PARENT_PERSONAL_UPDATEUSER_STATUS, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setString(UserPreference.ISHide, isHideBool);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "Account_Setting", context);
      e.toString();
    }
  }

  Future callApiToResndReview() async {
    try {
      Response response;

      Map map = {"userId": userIdPref, "roleId": 4};

      response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_RESEND_ACCOUNT_VERIFICATION, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            prefs.setString(UserPreference.PARTNER_STATUS, 'Pending');
            prefs.setBool(UserPreference.IS_PARTNER_ACTIVE, false);
            setState(() {
              partnerStatus = 'Pending';
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "Account_Setting", context);
      e.toString();
    }
  }

  @override
  void initState() {
    print("----- acccout ${widget.role}");
    getSharedPreferences();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    bool dobCheck(String time) {
      if (time != "null") {
        int millis = int.tryParse(time);
        DateTime now = DateTime.fromMillisecondsSinceEpoch(millis);
        diffrenceInDob = DateTime.now().year - now.year;
        if (diffrenceInDob < 13)
          return false;
        else
          return true;
      } else {
        return true;
      }
    }

    onTapProfilePage() async {
      String result;
      if (widget.role == "1") {
        result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => EditUserProfile("")));

        /* result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => UpdateUserProfile()));*/
      } else if (widget.role == "2") {
        result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => EditUserProfile("",roleId:'2')));
     /*   result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => EditParentProfile()));*/
      } else {
       /* result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) =>
                Company_Edit_Widget(widget.userIdPref)));*/
        result = await Navigator.of(context).push(
          new MaterialPageRoute(
            builder: (BuildContext context) => PartnerProfileView(
              signUpUsing: SignUpUsing.email,
              action: PartnerProfileAction.edit,
            ),
          ),
        );
      }

      if (result == "push") {
        bloc.personalInfoInstanceUpdateToNull();
        bloc.fetchPersonalInfo(userIdPref, context, prefs);
        isPerformChanges = "push";
      }
    }

    onTapChangePassword() async {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ChangePassword("setting", widget.role)),
      );
    }

    onTapChangeEmail() async {
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => UpdateEmail("", widget.role,
                isUnderThiteen: diffrenceInDob >= 13 ? false : true)),
      );
    }

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, isPerformChanges);
        },
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: IconButton(
                icon: Image.asset("assets/newDesignIcon/icon/back_icon.png",
                    height: 32.0, width: 32.0, fit: BoxFit.fill),
                onPressed: () {
                  Navigator.pop(context, isPerformChanges);
                }),
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),
          backgroundColor: Colors.white,
          body: isLoading
              ? Container(
                  height: 0.0,
                )
              : Container(
                  color: Colors.white,
                  child: Column(
                    children: <Widget>[
                      Container(
                        alignment: Alignment.topLeft,
                        padding: EdgeInsets.only(bottom: 10),
                        color: AppConstants.colorStyle.white,
                        child: PaddingWrap.paddingfromLTRB(
                            15.0,
                            3.0,
                            15.0,
                            10.0,
                            BaseText(
                              text: 'Account settings',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 1,
                            )),
                      ),
                      Expanded(
                        flex: 1,
                        child: ListView(
                          children: <Widget>[
                            InkWell(
                              child: Container(
                                margin: EdgeInsets.only(left: 15, right: 15),
                                padding: EdgeInsets.only(
                                    left: 15, right: 10, top: 12, bottom: 12),
                                decoration: BoxDecoration(
                                  color: ColorValues.SELECTION_BG,
                                  border: Border.all(
                                    color: ColorValues.SELECTION_BG,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          Text("Profile detail",
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily:
                                                      Constant.latoMedium)),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text("View full profile detail.",
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color:
                                                      ColorValues.TEXT_HEADER,
                                                  fontFamily:
                                                      Constant.latoRegular)),
                                        ],
                                      ),
                                    ),
                                    InkWell(
                                        child: Image.asset(
                                      "assets/newDesignIcon/icon/arrow_left.png",
                                      height: 20.0,
                                          width: 20,
                                    )),
                                  ],
                                ),
                              ),
                              onTap: () async {
                                onTapProfilePage();
                              },
                            ),
                            InkWell(
                                child: Container(
                                  margin: EdgeInsets.only(
                                      left: 15, right: 15, top: 15),
                                  padding: EdgeInsets.only(
                                      left: 15, right: 10, top: 12, bottom: 12),
                                  decoration: BoxDecoration(
                                    color: ColorValues.SELECTION_BG,
                                    border: Border.all(
                                      color: ColorValues.SELECTION_BG,
                                      width: 1.0,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Text("Change password",
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoMedium)),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                                "Change current password from here.",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    color:
                                                        ColorValues.TEXT_HEADER,
                                                    fontFamily:
                                                        Constant.latoRegular)),
                                          ],
                                        ),
                                      ),
                                      InkWell(
                                          child: Image.asset(
                                        "assets/newDesignIcon/icon/arrow_left.png",
                                            height: 20.0,
                                            width: 20,
                                      )),
                                    ],
                                  ),
                                ),
                                onTap: () async {
                                  onTapChangePassword();
                                }),
                            widget.role == "1" || widget.role == "2"
                                ? widget.role == "1"
                                    ? prefs?.getBool(UserPreference.IS_SCHOOL) ?? false
                                        ? SizedBox()
                                        : Column(
                                            children: <Widget>[
                                              InkWell(
                                                  child: Container(
                                                    margin: EdgeInsets.only(
                                                        left: 15,
                                                        right: 15,
                                                        top: 15),
                                                    padding: EdgeInsets.only(
                                                        left: 15,
                                                        right: 10,
                                                        top: 12,
                                                        bottom: 12),
                                                    decoration: BoxDecoration(
                                                      color: ColorValues
                                                          .SELECTION_BG,
                                                      border: Border.all(
                                                        color: ColorValues
                                                            .SELECTION_BG,
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                    ),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                  "Change email address",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      color: ColorValues
                                                                          .HEADING_COLOR_EDUCATION_1,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                      fontFamily:
                                                                          Constant
                                                                              .latoMedium)),
                                                              SizedBox(
                                                                height: 5,
                                                              ),
                                                              Text(
                                                                  "Change current email from here.",
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          12,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                      color: ColorValues
                                                                          .TEXT_HEADER,
                                                                      fontFamily:
                                                                          Constant
                                                                              .latoRegular)),
                                                            ],
                                                          ),
                                                        ),
                                                        InkWell(
                                                            child: Image.asset(
                                                          "assets/newDesignIcon/icon/arrow_left.png",
                                                              height: 20.0,
                                                              width: 20,
                                                        )),
                                                      ],
                                                    ),
                                                  ),
                                                  onTap: () async {
                                                    onTapChangeEmail();
                                                  }),
                                            ],
                                          )
                                    : Column(
                                        children: <Widget>[
                                          InkWell(
                                              child: Container(
                                                margin: EdgeInsets.only(
                                                    left: 15,
                                                    right: 15,
                                                    top: 15),
                                                padding: EdgeInsets.only(
                                                    left: 15,
                                                    right: 10,
                                                    top: 12,
                                                    bottom: 12),
                                                decoration: BoxDecoration(
                                                  color:
                                                      ColorValues.SELECTION_BG,
                                                  border: Border.all(
                                                    color: ColorValues
                                                        .SELECTION_BG,
                                                    width: 1.0,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                                child: Row(
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Text(
                                                              "Change email address",
                                                              style: TextStyle(
                                                                  fontSize: 14,
                                                                  color: ColorValues
                                                                      .HEADING_COLOR_EDUCATION_1,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontFamily:
                                                                      Constant
                                                                          .latoMedium)),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          Text(
                                                              "Change current email from here.",
                                                              style: TextStyle(
                                                                  fontSize: 12,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: ColorValues
                                                                      .TEXT_HEADER,
                                                                  fontFamily:
                                                                      Constant
                                                                          .latoRegular)),
                                                        ],
                                                      ),
                                                    ),
                                                    InkWell(
                                                        child: Image.asset(
                                                      "assets/newDesignIcon/icon/arrow_left.png",
                                                          height: 20.0,
                                                          width: 20,
                                                    )),
                                                  ],
                                                ),
                                              ),
                                              onTap: () async {
                                                onTapChangeEmail();
                                              }),
                                        ],
                                      )
                                : new Container(
                                    height: 0.0,
                                  ),
                            widget.role == "1" && profileInfoModal != null
                                ? isProfileVisibility?Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      InkWell(
                                        child: Container(
                                          margin: EdgeInsets.only(
                                              left: 15, right: 15, top: 15),
                                          padding: EdgeInsets.only(
                                              left: 15,
                                              right: 10,
                                              top: 12,
                                              bottom: 12),
                                          decoration: BoxDecoration(
                                            color: ColorValues.SELECTION_BG,
                                            border: Border.all(
                                              color: ColorValues.SELECTION_BG,
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: Row(
                                            children: <Widget>[
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text("Profile visibility",
                                                        style: TextStyle(
                                                            fontSize: 14,
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontFamily: Constant
                                                                .latoMedium)),
                                                    SizedBox(
                                                      height: 5,
                                                    ),
                                                    Text(
                                                        "Configure your profile visibility.",
                                                        style: TextStyle(
                                                            fontSize: 12,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            color: ColorValues
                                                                .TEXT_HEADER,
                                                            fontFamily: Constant
                                                                .latoRegular)),
                                                  ],
                                                ),
                                              ),
                                              InkWell(
                                                  child: Image.asset(
                                                "assets/newDesignIcon/icon/arrow_left.png",
                                                    height: 20.0,
                                                    width: 20,
                                              )),
                                            ],
                                          ),
                                        ),
                                        onTap: () async {
                                          String result = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ProfileVisibilitySetting(
                                                        userIdPref, false)),
                                          );
                                          if (result == "push") {
                                            Navigator.pop(context, "push");
                                          }
                                        },
                                      ),
                                    ],
                                  ):SizedBox()
                                : Container(
                                    height: 0.0,
                                  ),
                            !isLoading && dobCheck(dob) && widget.role == "1"
                                ? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: 15, right: 15, top: 15),
                                        padding: EdgeInsets.only(
                                            left: 15,
                                            right: 10,
                                            top: 12,
                                            bottom: 12),
                                        decoration: BoxDecoration(
                                          color: ColorValues.SELECTION_BG,
                                          border: Border.all(
                                            color: ColorValues.SELECTION_BG,
                                            width: 1.0,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                      "Make profile details visible to connections",
                                                      style: TextStyle(
                                                          fontSize: 14,
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoMedium)),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                      "When your account is hidden users won’t be able to see your profile.",
                                                      style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          color: ColorValues
                                                              .TEXT_HEADER,
                                                          fontFamily: Constant
                                                              .latoRegular)),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                                child: isHide == "false"
                                                    ? GestureDetector(
                                                        onHorizontalDragEnd:
                                                            (DragEndDetails
                                                                details) {
                                                          setState(() {
                                                            isHide = "true";
                                                          });
                                                          apiCallingForUpdateStudentHideStatus(
                                                              true);
                                                        },
                                                        onTap: () {
                                                          setState(() {
                                                            isHide = "true";
                                                          });
                                                          apiCallingForUpdateStudentHideStatus(
                                                              true);
                                                        },
                                                        child: Center(
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        20.0,
                                                                        0.0,
                                                                        5.0,
                                                                        0.0),
                                                                child:
                                                                    Image.asset(
                                                                  "assets/newDesignIcon/active_new.png",
                                                                  width: 30.0,
                                                                  height: 16.0,
                                                                ))))
                                                    : GestureDetector(
                                                        onHorizontalDragEnd:
                                                            (DragEndDetailsdetails) {
                                                          setState(() {
                                                            isHide = "false";
                                                          });
                                                          apiCallingForUpdateStudentHideStatus(
                                                              false);
                                                        },
                                                        onTap: () {
                                                          setState(() {
                                                            isHide = "false";
                                                          });
                                                          apiCallingForUpdateStudentHideStatus(
                                                              false);
                                                        },
                                                        child: Center(
                                                            child: Padding(
                                                                padding: EdgeInsets
                                                                    .fromLTRB(
                                                                        20.0,
                                                                        0.0,
                                                                        5.0,
                                                                        0.0),
                                                                child:
                                                                    Image.asset(
                                                                  "assets/newDesignIcon/inactive_new.png",
                                                                  width: 30.0,
                                                                  height: 16.0,
                                                                )))),
                                                flex: 0),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )
                                : Container(
                                    height: 0.0,
                                  ),
                            (!isLoading &&
                                        dobCheck(dob) &&
                                        widget.role == "1") ||
                                    widget.role != "1"
                                ? isFeed_AccessControl? Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: 15, right: 15, top: 15),
                                          padding: EdgeInsets.only(
                                              left: 15,
                                              right: 10,
                                              top: 12,
                                              bottom: 12),
                                          decoration: BoxDecoration(
                                            color: ColorValues.SELECTION_BG,
                                            border: Border.all(
                                              color: ColorValues.SELECTION_BG,
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: Row(
                                            children: <Widget>[
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text("Community post",
                                                        style: TextStyle(
                                                            fontSize: 14,
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION_1,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontFamily: Constant
                                                                .latoMedium)),
                                                    SizedBox(
                                                      height: 5,
                                                    ),
                                                    Text(
                                                        "Post visible to all spikeview members.",
                                                        style: TextStyle(
                                                            fontSize: 12,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            color: ColorValues
                                                                .TEXT_HEADER,
                                                            fontFamily: Constant
                                                                .latoRegular)),
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                  child: isCoomunitySetting
                                                      ? GestureDetector(
                                                          onHorizontalDragEnd:
                                                              (DragEndDetails
                                                                  details) {
                                                            apiCallingForCommunitySetting(
                                                                false);
                                                          },
                                                          onTap: () {
                                                            apiCallingForCommunitySetting(
                                                                false);
                                                          },
                                                          child: Center(
                                                              child: Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          20.0,
                                                                          0.0,
                                                                          5.0,
                                                                          0.0),
                                                                  child: Image
                                                                      .asset(
                                                                    "assets/newDesignIcon/active_new.png",
                                                                    width: 30.0,
                                                                    height:
                                                                        16.0,
                                                                  ))))
                                                      : GestureDetector(
                                                          onHorizontalDragEnd:
                                                              (DragEndDetails
                                                                  details) {
                                                            apiCallingForCommunitySetting(
                                                                true);
                                                          },
                                                          onTap: () {
                                                            apiCallingForCommunitySetting(
                                                                true);
                                                          },
                                                          child: Center(
                                                              child: Padding(
                                                                  padding: EdgeInsets
                                                                      .fromLTRB(
                                                                          20.0,
                                                                          0.0,
                                                                          5.0,
                                                                          0.0),
                                                                  child: Image
                                                                      .asset(
                                                                    "assets/newDesignIcon/inactive_new.png",
                                                                    width: 30.0,
                                                                    height:
                                                                        16.0,
                                                                  )))),
                                                  flex: 0),
                                            ],
                                          ),
                                        ),
                                      ]):SizedBox()
                                : const SizedBox.shrink(),
                          ],
                        ),
                      )
                    ],
                  )),
        ));
  }
}
