import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/TagModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

// Create a Form Widget
class AddTagWidget extends StatefulWidget {
  String title;
  List<TagModel> selectedUerTagLIst1;

  AddTagWidget(this.title, this.selectedUerTagLIst1);

  @override
  AddTagWidgetState createState() {
    return  AddTagWidgetState();
  }
}

class AddTagWidgetState extends State<AddTagWidget> {
  List<TagModel> tagList =  List();
  List<TagModel> selectedUerId =  List();

  var isButtonEnable=false;
  List<bool> selectedCheckedList =  List();
  List<TagModel> filteredRecored =  List();

  SharedPreferences prefs;
  BuildContext context;
  String userIdPref, roleId, userProfilePath;
  bool isApiCalled = false;

  // Variables for Search
  TextEditingController _textController = TextEditingController();

  //--------------------------api Calling for tag------------------
  Future apiCallingForTag() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_USER_CONNECTION_LIST +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        setState(() {
          isApiCalled = true;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              filteredRecored.clear();
              tagList =
                  ParseJson.parseTagList(response.data['result']['Accepted']);
              if (tagList != null) {
                setState(() {
                  tagList;
                  filteredRecored.addAll(tagList);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      setState(() {
        isApiCalled = true;
      });
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    await apiCallingForTag();
    if (widget.selectedUerTagLIst1 != null &&
        widget.selectedUerTagLIst1.length > 0) {
      for (int i = 0; i < widget.selectedUerTagLIst1.length; i++) {
        for (int j = 0; j < filteredRecored.length; j++) {
          if (filteredRecored[j].userId ==
              widget.selectedUerTagLIst1[i].userId) {
            filteredRecored[j].isSelected = true;
            selectedCheckedList.add(true);
            break;
          }
        }
      }
      isButtonEnable=true;
    }else{
      isButtonEnable=false;
    }
    setState(() {
      filteredRecored;
    });
  }

  @override
  void initState() {
    getSharedPreferences();
    // TODO: implement initState
    super.initState();
    // filteredRecored.addAll(tagList);
  }

  void updateSearchQuery(String newQuery) {
    filteredRecored.clear();
    if (newQuery.length > 0) {
      Set<TagModel> set = Set.from(tagList);
      set.forEach((element) => filterList(element, newQuery));
    }
    if (newQuery.isEmpty) {
      filteredRecored.addAll(tagList);
    }
    setState(() {});
  }

  //Filtering the list item with found match string.
  filterList(TagModel model, String searchQuery) {
    setState(() {
      if (model.firstName.toLowerCase().contains(searchQuery) ||
          model.firstName.contains(searchQuery) || model.lastName.toLowerCase().contains(searchQuery) ||
          model.lastName.contains(searchQuery)) {
        filteredRecored.add(model);
      }
    });
  }
  onTapOkBtn() {
    for (int i = 0; i < tagList.length; i++) {
      if (tagList[i].isSelected) selectedUerId.add(tagList[i]);
    }
    Navigator.pop(context, selectedUerId);
  }
  @override
  Widget build(BuildContext context) {
    this.context = context;
    Constant.applicationContext = context;


    // Build a Form widget using the _formKey we created above
    _buildChoiceList() {
      List<Widget> choices = List();
      filteredRecored.forEach((item) {
        if (item.isSelected) {
          choices.add(PaddingWrap.paddingAll(
              5.0,
              Container(
                decoration:  BoxDecoration(
                    border:  Border.all(
                        width: 1.0,
                        color:  ColorValues.GREY_TEXT_COLOR)),
                padding: const EdgeInsets.fromLTRB(
                  8.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                child: Wrap(
                  children: <Widget>[
                    Text(
                      item.firstName +
                          " " +
                          item.lastName +
                          (item.roleId == "1"
                              ? "(Student)"
                              : item.roleId == "2" ? "(Parent)" : "(Partner)"),
                      overflow: TextOverflow.ellipsis,
                      style:  TextStyle(
                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    ),
                    InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          5.0,
                          3.0,
                          0.0,
                          0.0,
                          Icon(
                            Icons.clear,
                            color: Colors.black,
                            size: 17.0,
                          )),
                      onTap: () {
                        setState(() {
                          item.isSelected = false;
                        });
                      },
                    )
                  ],
                ),
              )));
        }
      });
      return choices;
    }

    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  Scaffold(
            resizeToAvoidBottomInset: false,
            floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
            bottomNavigationBar:tagList.length == 0?Container(height:0): addButton(),
            backgroundColor:  ColorValues.WHITE,
            body:  Stack(
              children: [
                Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/generateScript/script_background.png"),
                          fit: BoxFit.fill)),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 40, left: 20, right: 20),
                  child: SizedBox(
                    height: 100,
                    width: double.infinity,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Image.asset(
                            "assets/generateScript/back.png",
                            height: 32.0,
                            width: 32.0,
                          ),
                        ),
                        const HelpButtonWidget(),
                      ],
                    ),
                  ),
                ),
                Stack(
                  children: <Widget>[
                    isApiCalled
                        ? tagList.length == 0
                        ? Positioned(
                    bottom: 0.0,
                    right: 0.0,
                    left: 0.0,
                    top: 0.0,
                    child:  Container(
                      margin: const EdgeInsets.only(top: 115),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Expanded(
                              child:  Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(30),
                                    topRight: Radius.circular(30),
                                  ),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Padding(
                                        padding: EdgeInsets.fromLTRB(15.0, 170.0, 0.0, 0.0),
                                        child: Container(
                                          width: 120.0,
                                          height: 111.0,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                                image: AssetImage(
                                                    'assets/newDesignIcon/connections/man_to_guide.png'),
                                                fit: BoxFit.cover),
                                          ),
                                        )),
                                    Center(
                                        child: Text(
                                          "No connections found",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                              fontSize: 18.0,
                                              fontFamily: Constant.latoRegular),
                                        )),
                                  ],
                                ),
                              ))
                        ],
                      ),
                    ))

            :  Positioned(
                        bottom: 0.0,
                        right: 0.0,
                        left: 0.0,
                        top: 0.0,
                        child:  Container(
                          margin: const EdgeInsets.only(top: 115),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              const SizedBox(height: 10),
                              Expanded(
                                  child:  Container(
                                    width: MediaQuery.of(context).size.width,
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(30),
                                        topRight: Radius.circular(30),
                                      ),
                                    ),
                                    child: ListView(
                                      children: <Widget>[
                                        /*Padding(
                                              padding: EdgeInsets.fromLTRB(
                                                  8.0, 15.0, 13.0, 0.0),
                                              child: Wrap(
                                                children: _buildChoiceList(),
                                              ),
                                            ),*/
                                        Padding(
                                          padding: const EdgeInsets.only(left: 22),
                                          child: Text(
                                            AppConstants.stringConstant.selectToTag,
                                            style:  AppConstants.txtStyle.heading28700LatoRegularDarkBlue,
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(20.0, 24.0, 20.0, 0.0),
                                          child:  Container(
                                              height: 45.0,
                                              decoration: BoxDecoration(
                                                color:AppConstants.colorStyle.tabBg,
                                                border: Border.all(color: AppConstants.colorStyle.btnBg),
                                                borderRadius: const BorderRadius.all(Radius.circular(10)),
                                              ),
                                              child:  Padding(
                                                padding: const EdgeInsets.only(left: 15),
                                                child: TextField(
                                                  cursorColor:
                                                  Constant.CURSOR_COLOR,
                                                  controller: _textController,
                                                  decoration: InputDecoration(
                                                      enabledBorder:
                                                      UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                          color:  Colors.transparent,),
                                                      ),
                                                      focusedBorder:
                                                      UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                          color:  Colors.transparent,),
                                                      ),
                                                      hintText: 'Search',
                                                      suffixIcon:
                                                      _textController.text
                                                          .length >
                                                          0
                                                          ? Padding(
                                                        padding:
                                                        EdgeInsets.all(
                                                            0.0),
                                                        child:
                                                        InkWell(
                                                          child: Icon(
                                                              Icons
                                                                  .cancel,
                                                              color:
                                                              Colors.black26),
                                                          onTap:
                                                              () {
                                                            setState(
                                                                    () {
                                                                  _textController.text =
                                                                  "";
                                                                  updateSearchQuery(
                                                                      "");
                                                                });
                                                          },
                                                        ),
                                                      )
                                                          : Padding(
                                                        padding: EdgeInsets.all(12.0),
                                                        child: Image.asset(
                                                          "assets/feed/search.png",
                                                        ),
                                                      )),
                                                  onChanged: updateSearchQuery,
                                                ),
                                              )),
                                        ),

                                        filteredRecored.length > 0
                                            ?  Column(
                                          children:  List.generate(
                                              filteredRecored.length,
                                                  (int position) {
                                                return  tagListItem(position);
                                              }),
                                        )
                                            : PaddingWrap.paddingfromLTRB(
                                            0.0,
                                            30.0,
                                            0.0,
                                            0.0,TextViewWrap.textViewMultiLine(
                                            "No Data Found.",
                                            TextAlign.center,
                                            ColorValues.GREY_TEXT_COLOR,
                                            16.0,
                                            FontWeight.normal,
                                            2)),

                                      ],
                                    ),
                                  ))
                            ],
                          ),
                        ))
                        :  Positioned(
                        bottom: 0.0,
                        right: 0.0,
                        left: 0.0,
                        top: 0.0,
                        child:  Container(
                          margin: const EdgeInsets.only(top: 115),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Expanded(
                                  child:  Container(
                                    width: MediaQuery.of(context).size.width,
                                    decoration: const BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(30),
                                        topRight: Radius.circular(30),
                                      ),
                                    ),

                                  ))
                            ],
                          ),
                        )),
                  ],
                ),
              ],
            )));

    // Create Chips View for Selected
  }
  Widget tagListItem(position){
    return Padding(
        padding:
        EdgeInsets.only(left: 22,top: 24,right: 22,bottom: 22),
        child:  Row(
          children: <Widget>[

            Expanded(
              child:
              Container(
                height: 48.0,
                width: 48.0,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: FadeInImage(
                    fit: BoxFit.cover,
                    placeholder: AssetImage('assets/profile/user_on_user.png',),
                    image: NetworkImage(Constant.IMAGE_PATH_SMALL + ParseJson.getSmallImage(filteredRecored[position].profilePicture)),
                  ),
                ),
              ),

              flex: 0,
            ),
            Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    11.0,
                    0.0,
                    0.0,
                    0.0,
                    TextViewWrap.textView(
                        filteredRecored[position].lastName == "" ||
                            filteredRecored[position].lastName ==
                                "null"
                            ? filteredRecored[position].firstName

                            : filteredRecored[position].firstName +
                            " " +
                            filteredRecored[position]
                                .lastName,
                        TextAlign
                            .start,
                        ColorValues.HEADING_COLOR_EDUCATION,
                        14.0,
                        FontWeight
                            .bold)),
                /*Row(
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        15.0,
                        0.0,
                        0.0,
                        TextViewWrap.textView(
                            filteredRecored[position].lastName == "" ||
                                filteredRecored[position].lastName ==
                                    "null"
                                ? filteredRecored[position].firstName

                                : filteredRecored[position].firstName +
                                " " +
                                filteredRecored[position]
                                    .lastName,
                            TextAlign
                                .start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            14.0,
                            FontWeight
                                .bold)),
                    filteredRecored[position].roleId == "1"
                        ?
                    PaddingWrap.paddingfromLTRB(
                      0.0,
                      15.0,
                      0.0,
                      0.0, Util.getStudentBadge12(
                        filteredRecored[position].badge,
                        filteredRecored[position].badgeImage),
                    ): Container(),
                  ],
                ),*/
                flex: 1),
            /*Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    5.0,
                    15.0,
                    0.0,
                    0.0,
                    TextViewWrap.textView(

                        (filteredRecored[position].roleId == "1"
                            ? "(Student)"
                            : filteredRecored[position].roleId == "2"
                            ? "(Parent)"
                            : "(Partner)"),
                        TextAlign
                            .start,
                        ColorValues.HEADING_COLOR_EDUCATION,
                        14.0,
                        FontWeight
                            .bold)),
                flex: 0),*/
            Expanded(
                child: SizedBox(
                    width:
                    30.0,
                    height:
                    30.0,
                    child:
                    Theme(
                      data:
                      ThemeData(
                        unselectedWidgetColor:
                        Colors.transparent,
                      ),
                      child:
                      InkWell(
                        child:  Padding(
                            padding:  EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 5.0),
                            child:  Row(
                              children: <Widget>[
                                filteredRecored[position].isSelected
                                    ?  Expanded(
                                    child:  Padding(
                                        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                        child:  Image.asset(
                                          "assets/feed/checkedBox.png",
                                          height: 20.0,
                                          width: 20.0,
                                        )),
                                    flex: 0)
                                    :  Expanded(
                                    child:  Padding(
                                        padding:  EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                        child:  Image.asset(
                                          "assets/feed/unCheckedBox.png",
                                          height: 20.0,
                                          width: 20.0,
                                        )),
                                    flex: 0),
                              ],
                            )),
                        onTap:
                            () {
                          bool value = filteredRecored[position].isSelected;

                          if (value) {
                            filteredRecored[position].isSelected = false;
                            selectedCheckedList.remove(true);
                          } else {
                            filteredRecored[position].isSelected = true;
                            selectedCheckedList.add(true);
                          }

                          setState(() {
                            filteredRecored[position].isSelected;
                            if(selectedCheckedList.length!=0){
                              isButtonEnable=true;
                            }else{
                              isButtonEnable=false;
                            }
                          });
                        },
                      ),
                    )),
                flex: 0),
          ],
        ));
  }
  addButton() {
    return Container(
        child: Padding(
            padding: EdgeInsets.only(top: 30.0),
            child: Container(
                margin: EdgeInsets.only(left: 20,right: 20,bottom: 20),
                height: 44.0,
                child: FlatButton(
                  onPressed: () {
                    onTapOkBtn();
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  color:isButtonEnable?AppConstants.colorStyle.lightBlue: AppConstants.colorStyle.lightBlueButtonDisableColor,
                  child: Row(
                    // Replace with a Row for horizontal icon + text
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('Add',
                          style: AppConstants
                              .txtStyle.heading18600LatoRegularWhite),
                    ],
                  ),
                ))));
  }
}
