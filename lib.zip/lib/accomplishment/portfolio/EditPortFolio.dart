import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/accomplishment/portfolio/VideoView.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/ClubTeamModel.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/LinkUrlDataModel.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModel.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/MediaDataModelNew.dart';
import 'package:spike_view_project/accomplishment/portfolio/model/StateModel.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/common/util/image_path.dart';
import 'package:spike_view_project/common/util/ui_helper.dart';
import 'package:spike_view_project/common/util/validation_checks.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/country_picker/Country.dart';
import 'package:spike_view_project/country_picker/CountryPicker.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/home/home.dart';
import 'package:spike_view_project/modal/AcvhievmentImportanceMOdal.dart';
import 'package:spike_view_project/modal/AcvhievmentSkillModel.dart';
import 'package:spike_view_project/modal/CompetencyMasterDataModel.dart';
import 'package:spike_view_project/modal/CompetencyModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:video_compress/video_compress.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

// Create a Form Widget
class EditPortFolio extends StatefulWidget {
  Achivment achivmentModel;
  String sasToken;
  String level1;
  String pageName, userId;

  EditPortFolio(this.achivmentModel, this.sasToken, this.level1, this.userId,
      {this.pageName});

  @override
  EditPortFolioState createState() {
    return EditPortFolioState(achivmentModel);
  }
}

class EditPortFolioState extends State<EditPortFolio> with BaseCommonWidget {
  EditPortFolioState(this.achivmentModel);

  bool isThirLevelField = true;

  Achivment achivmentModel;
  final _formKey = GlobalKey<FormState>();
  final _formKey2 = GlobalKey<FormState>();

  String strAchievement = "",
      strFromDate = "",
      strToDate = "",
      strName = "",
      strEmail = "",
      strTitle = "",
      strDeascription = "";
  TextEditingController fromDateController,
      toDateController,
      coachFirstNameController,
      recommendationTitleController,
      recommendationRequestController,
      recommenderTitleController,
      coachLastNameController,
      coachEmaiController;

  List<AchievementImportanceModal> levelList = List();
  List<AcvhievmentSkillModel> skillList = List();
  List<Skill> skillsSelectedList = List();
  List<Level3Competencies> level3Competencylist = List();
  SharedPreferences prefs;
  Level3Competencies competencySelected;
  bool isPresent = false;
  FocusNode workinHoursFocusNode = FocusNode();
  FocusNode weightFocusNode = FocusNode();
  String userIdPref,
      userEmail,
      dob,
      token,
      strCompetencyValue = "",
      strLevelValue = "",
      strWorkingHours = "",
      filterData = "",
      appliedFilter = "",
      strCoachLastName = "",
      strCoachFirstName = "",
      strRecommendationTitle = "",
      strRecommenderTitle = "",
      strRecommendationRequest = "",
      strCoachEmail = "",
      strCompetencyHint = "",
      strWeight = "",
      strHeight = "",
      strLevelHint = "",
      strAgeValue = "1",
      strFootValue = "1\'",
      strInchValue = "0\"";
  Map<int, bool> filterStatus = Map();
  File imagePath;
  AchievementImportanceModal levelSelected;
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "";
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  List<Assest> assestList = List();
  List<String> certificateList = List();

  //List<String> badgeList = List();
  // List<String> trophyList = List();
  List<Assest> badgeAndTrophyList = List();

  List<bool> assestListSelected = List();
  BuildContext context;
  TextEditingController titleController, descController, workingHourController;
  TextEditingController cityController = TextEditingController(text: "");
  TextEditingController stateController = TextEditingController(text: "");
  TextEditingController heightController = TextEditingController(text: "");
  TextEditingController bioController = TextEditingController(text: "");
  TextEditingController weightController = TextEditingController();
  TextEditingController ageController = TextEditingController(text: "");
  Map<String, List<Level3Competencies>> competencyList = Map();
  bool isMedaiDialog = false;
  bool isPromptfinal = false;
  bool isPrompt = false;
  ScrollController _controller = ScrollController();
  FocusNode _focus = FocusNode();
  String isPerformChnges = "pop";
  bool isShowMedia = true;
  DateTime startDate;
  final FocusNode teamNameFocus = FocusNode();
  final FocusNode teamNameFocus1 = FocusNode();
  int selectedIndexCover = 0;
  bool isPredefinedMediaSelected = false;
  List<String> imageList = List();
  String portfolioImagePath = "";
  int uploadMediaCount = 0;
  bool isThirdLevelOther = false;

  TextEditingController personalReflectionController =
      TextEditingController(text: "");
  String strpersonalReflection = '';

  Future apiCallMaster() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_MASTER_DATA, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              skillList.clear();
              competencyList.clear();
              prefs.setString(
                  "skill", json.encode(response.data['result']['skills']));
              prefs.setString(
                  "level", json.encode(response.data['result']['importance']));

              prefs.setString("competencies",
                  json.encode(response.data['result']['competencies']));

              levelList = ParseJson.parseMapLevelList(
                  response.data['result']['importance']);
              skillList = ParseJson.parseMapSkillList(
                  response.data['result']['skills']);

              competencyList = ParseJson.parseMapMasterCompetency(
                  response.data['result']['competencies']);

              if (competencyList.length > 0) {
                level3Competencylist.clear();
                setState(() {
                  competencyList;

                  level3Competencylist =
                      competencyList[achivmentModel.level2Competency];
                });
              }
              if (level3Competencylist == null) {
                level3Competencylist = List();
              }
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }

              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      e.toString();
    }
  }

  Future apiCallLevelList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_LEVEL_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              levelList.clear();
              prefs.setString("level", json.encode(response.data['result']));
              levelList = ParseJson.parseMapLevelList(response.data['result']);
              if (levelList.length > 0) {
                setState(() {
                  levelList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      e.toString();
    }
  }

  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      Response response = await ApiCalling().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": widget.sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      return "";
    }
  }

  //--------------------------Api Call for skills ------------------
  Future apiCallSkill() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_ACHIEVMENT_SKILLS, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              skillList.clear();
              prefs.setString("skill", json.encode(response.data['result']));
              skillList = ParseJson.parseMapSkillList(response.data['result']);
              if (skillList.length > 0) {
                for (int i = 0; i < skillList.length; i++) {
                  filterStatus[i] = false;
                }
                setState(() {
                  filterStatus;
                  skillList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      e.toString();
    }
  }

  scrollTop() async {
    Timer _timer = Timer(const Duration(milliseconds: 200), () async {
      _controller.jumpTo(_controller.position.minScrollExtent);
    });
  }

  scrollBottom() async {
    Timer _timer = Timer(const Duration(milliseconds: 200), () async {
      _controller.jumpTo(_controller.position.maxScrollExtent);
    });
  }

  //--------------------------Upload Acchievment Data ------------------

  bool validationCheck() {
    /* if(!isValidAge){
      return false;
    }
    else*/
    if (portfolioImagePath == "") {
      ToastWrap.showToast(MessageConstant.REQUIRED_IMAGE, context);
      return false;
    } else if (strCompetencyValue == "") {
      ToastWrap.showToast(MessageConstant.SELECT_COMPETENCY_VAL, context);
      return false;
    } else if (skillsSelectedList.length == 0) {
      ToastWrap.showToast(MessageConstant.SELECT_SKILLS_VAL, context);
      return false;
    } else if (strLevelValue == "") {
      ToastWrap.showToast(
          MessageConstant.SELECT_ACHIEVEMENT_LEVEL_VAL, context);
      return false;
    } else if (strFromDate == "") {
      ToastWrap.showToast(MessageConstant.SELECT_FROM_DATE_VAL, context);
      return false;
    } else if (strToDate == "" && (!isPresent)) {
      ToastWrap.showToast(MessageConstant.SELECT_TO_DATE_VAL, context);
      return false;
    }

    return true;
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    _timer = Timer(const Duration(milliseconds: 3000), () async {
      Navigator.pop(context);
      Navigator.pop(context, "push");
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //assestList.removeAt(0);
        CustomProgressLoader.showLoader(context);

        if (linkUrlListData.length == 1 &&
            linkUrlListData[0].urlController.text.trim() == '') {
          //linkUrlListData[0].urlController.text.trim() == '';
          linkUrlListData.clear();
          print('linkUrlListData len::: ${linkUrlListData.length}');
        }
        Map map;
        map = {
          "achievementId": achivmentModel.achievementId,
          "competencyTypeId": achivmentModel.competencyTypeId,
          "level2Competency": achivmentModel.level2Competency,
          "userId": widget.pageName == null || widget.pageName == ""
              ? userIdPref
              : prefs.getString(UserPreference.PARENT_WIZARD_USERID),
          "userImage": portfolioImagePath,
          "level3Competency": strCompetencyValue,
          "focusArea": thirdLevelController.text,
          "importance": strLevelValue,
          "skills": skillsSelectedList.map((item) => item.toJson()).toList(),
          "title": titleController.text,
          "fromDate": strFromDate,
          "toDate": strToDate,
          "type": "portfolio",
          "personalStatement": descController.text,
          "description": bioController.text,
          "personalReflection": personalReflectionController.text.trim(),
          "city": cityController.text,
          "state": stateController.text,
          "height": heightController.text,
          "weight": weightController.text,
          "age": ageController.text,
          "asset": mediaListData.map((item) => item.toJson()).toList(),
          "team": [
            {
              "teamType": clubTeamList.length > 0 ? "Club Team" : "",
              "teams": clubTeamList.map((item) => item.toJson()).toList()
            },
            {
              "teamType":
                  highSchoolTeamList.length > 0 ? "High School Team" : "",
              "teams": highSchoolTeamList.map((item) => item.toJson()).toList()
            },
            {
              "teamType": collegeTeamList.length > 0 ? "College Team" : "",
              "teams": collegeTeamList.map((item) => item.toJson()).toList()
            },
            {
              "teamType": otherTeamList.length > 0 ? "Others" : "",
              "teams": otherTeamList.map((item) => item.toJson()).toList()
            }
          ],
          "external_links":
              linkUrlListData.map((item) => item.toJson()).toList(),
          "stats": stateListData.map((item) => item.toJson()).toList(),
          "guide": {
            "promptRecommendation": isPrompt,
            "firstName": strCoachFirstName,
            "lastName": strCoachLastName,
            "email": strCoachEmail,
            "title": strRecommenderTitle,
            "recommenderTitle": strRecommendationTitle,
           // "title": strRecommendationTitle,
        //    "recommenderTitle": strRecommenderTitle,
            "request": strRecommendationRequest,
          },
          "isActive": "true",
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              showSucessMsg(msg, context);
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.userId;
    dob = prefs.getString(UserPreference.DOB);
    userEmail = prefs.getString(UserPreference.EMAIL);
    token = prefs.getString(UserPreference.USER_TOKEN);

    if (dob != "" || dob != null) {
      startDate = DateTime.fromMillisecondsSinceEpoch(int.parse(dob));
    } else {
      startDate = DateTime.now();
    }
    try {
      for (PortFolioAssest _mPortFolioAssest
          in achivmentModel.portFolioAssestList) {
        List<FileDataModel> fileData = List<FileDataModel>();
        fileData.add(new FileDataModel(
            filePath: "",
            type: "",
            thumbnailFile: null,
            imagePath: null,
            linkController: TextEditingController()));
        fileData.addAll(_mPortFolioAssest.file);
        mediaListData.add(MediaDataModelNew(
            TextEditingController(text: _mPortFolioAssest.label),
            TextEditingController(text: _mPortFolioAssest.statistics),
            TextEditingController(text: _mPortFolioAssest.description),
            type: _mPortFolioAssest.type,
            fileDataModelList: fileData,
            isSelectMedia: true));
      }
      setState(() {});
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
    }

    try {
      if (prefs.getString("competencies") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("competencies"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          competencyList.clear();
          competencyList = ParseJson.parseMapMasterCompetency(data);
          if (competencyList.length > 0) {
            level3Competencylist.clear();
            setState(() {
              competencyList;

              level3Competencylist =
                  competencyList[achivmentModel.level2Competency];
            });
          }
        }
      }
      if (level3Competencylist == null) {
        level3Competencylist = List();
      }
      strCompetencyHint = achivmentModel.level3Competency == null
          ? ""
          : achivmentModel.level3Competency;
      /*  for (int i = 0; i < level3Competencylist.length; i++) {
        if (level3Competencylist[i].key == strCompetencyValue) {
          strCompetencyHint = level3Competencylist[i].name;
          break;
        }
      }
*/
      if (prefs.getString("level") == null) {
        await apiCallMaster();
      } else {
        final data = json.decode(prefs.getString("level"));
        if (data == null || data.length == 0) {
          await apiCallMaster();
        } else {
          levelList.clear();
          levelList = ParseJson.parseMapLevelList(data);
          if (levelList.length > 0) {
            setState(() {
              levelList;
            });
          }
        }
      }

      if (prefs.getString("skill") == null) {
        await apiCallMaster();
      } else {
        final skill = json.decode(prefs.getString("skill"));
        if (skill == null || skill.length == 0) {
          await apiCallMaster();
        } else {
          skillList.clear();
          skillList = ParseJson.parseMapSkillList(skill);
          if (skillList.length > 0) {
            for (int i = 0; i < skillList.length; i++) {
              filterStatus[i] = false;
            }
            setState(() {
              filterStatus;
              skillList;
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      e.toString();
    }
    // await callApiForSaas();

    for (int i = 0; i < levelList.length; i++) {
      if (levelList[i].importanceId == strLevelValue) {
        strLevelHint = levelList[i].title;
        setState(() {
          strLevelHint;
        });
        break;
      }
    }

    for (int i = 0; i < skillList.length; i++) {
      for (int j = 0; j < achivmentModel.skillList.length; j++) {
        if (skillList[i].title == achivmentModel.skillList[j].label) {
          filterStatus[i] = true;
          if (appliedFilter == "") {
            appliedFilter = skillList[i].title;
          } else {
            appliedFilter = appliedFilter + "," + skillList[i].title;
          }
        }
      }
    }
    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
  }

  DateTime fromDate, toDate;

  void _onFocusChange() {
    debugPrint("Focus: " + _focus.hasFocus.toString());
  }

  bool isOtherCategory = false;
  TextEditingController otherCategory;
  TextEditingController thirdLevelController = TextEditingController(text: "");

  static TextStyle styleForHeight = TextStyle(
      color: ColorValues.HEADING_COLOR_EDUCATION,
      fontSize: 18.0,
      fontFamily: Constant.TYPE_CUSTOMREGULAR);
  bool isValidHeight = true;
  bool isValidAge = true;
  List<int> yearList = List();
  final List<String> footList = [
    "1\'",
    "2\'",
    "3\'",
    "4\'",
    "5\'",
    "6\'",
    "7\'",
    "8\'",
    "9\'",
    "10\'",
  ].toList();

  final List<String> inchList = [
    "0\"",
    "1\"",
    "2\"",
    "3\"",
    "4\"",
    "5\"",
    "6\"",
    "7\"",
    "8\"",
    "9\"",
    "10\"",
    "11\"",
    "12\"",
  ].toList();

  List<LinkUrlDataModel> linkUrlListData = List();
  List<MediaDataModelNew> mediaListData = List();
  List<StateModel> stateListData = List();
  List<ClubTeamModel> clubTeamList = List();
  List<ClubTeamModel> highSchoolTeamList = List();
  List<ClubTeamModel> collegeTeamList = List();
  List<ClubTeamModel> otherTeamList = List();
  bool isClubTeam = false;
  bool isHighSchoolTeam = false;
  bool isCollegeTeam = false;
  bool isOtherTeam = false;
  UploadMedia uploadMedia;

  bool isShiftBelow = true;
  FocusNode _focusDescription = FocusNode();

  void _onFocusChangeDesc() {
    setState(() {
      if (!_focusDescription.hasFocus && descController.text == '')
        isShiftBelow = true;
      else
        isShiftBelow = false;
    });
  }

  @override
  void initState() {
    for (int i = 1; i < 100; i++) {
      yearList.add(i);
    }

    if (achivmentModel.level2Competency == "Others") {
      setState(() {
        achivmentModel.level2Competency = "Other";
      });
    }
    if (achivmentModel.level2Competency == "Other" ||
        achivmentModel.level2Competency == "General") {
      isOtherCategory = true;
      strCompetencyValue = achivmentModel.level3Competency;
      otherCategory = TextEditingController(text: strCompetencyValue);
      thirdLevelController = TextEditingController(
          text: achivmentModel.focusArea == "null"
              ? ""
              : achivmentModel.focusArea);
    }
    if (achivmentModel.level3Competency == "Other") {
      thirdLevelController = TextEditingController(
          text: achivmentModel.focusArea == "null"
              ? ""
              : achivmentModel.focusArea);
      isThirdLevelOther = true;
    }
    //check for where old data is present

    _focus.addListener(_onFocusChange);
    _focusDescription.addListener(_onFocusChangeDesc);
    getSharedPreferences();
    uploadMedia = UploadMedia(context);
    uploadMediaCount = achivmentModel.fileList.length;
    titleController = TextEditingController(text: achivmentModel.title);
    workingHourController = TextEditingController(
        text: achivmentModel.hoursWorkedPerWeek == "null" ||
                achivmentModel.hoursWorkedPerWeek == ""
            ? ""
            : achivmentModel.hoursWorkedPerWeek);

    if (achivmentModel.personalReflection != null &&
        achivmentModel.personalReflection != 'null' &&
        achivmentModel.personalReflection != '')
      personalReflectionController =
          TextEditingController(text: achivmentModel.personalReflection);

    print(
        "Inside edit port personalReflection:: ${personalReflectionController.text}");

    descController =
        TextEditingController(text: achivmentModel.personalStatement);
    if (achivmentModel.personalStatement.toString() != "null" &&
        achivmentModel.personalStatement.toString() != "") {
      isShiftBelow = false;
    }
    bioController.text = achivmentModel.description == null ||
            achivmentModel.description == "null" ||
            achivmentModel.description == ""
        ? ""
        : achivmentModel.description;

    cityController = TextEditingController(text: achivmentModel.city);
    stateController = TextEditingController(text: achivmentModel.state);
    heightController = TextEditingController(text: achivmentModel.sheight);
    weightController = TextEditingController(text: achivmentModel.sweight);
    ageController = TextEditingController(
        text: achivmentModel.age == null || achivmentModel.age == "null"
            ? ""
            : achivmentModel.age);
    portfolioImagePath = achivmentModel.userImage;

    for (ExternalLinks _mLinkUrlDataModel in achivmentModel.externalLinksList) {
      linkUrlListData.add(LinkUrlDataModel(
        TextEditingController(text: _mLinkUrlDataModel.label),
        TextEditingController(text: _mLinkUrlDataModel.url),
        TextEditingController(text: _mLinkUrlDataModel.description),
      ));
    }

    for (Stats _mStateModel in achivmentModel.statsList) {
      stateListData.add(StateModel(
          position: "",
          lable: "",
          value: "",
          positionController:
              TextEditingController(text: _mStateModel.playingPosition),
          lableController: TextEditingController(text: _mStateModel.label),
          valueController: TextEditingController(text: _mStateModel.value)));
    }
    if (stateListData.length == 0) {
      stateListData.add(StateModel(
          position: "",
          lable: "",
          value: "",
          positionController: TextEditingController(),
          lableController: TextEditingController(),
          valueController: TextEditingController()));
    }
    for (Team _mTeam in achivmentModel.teamList) {
      for (TeamData _mTeamData in _mTeam.teamDataList) {
        if (_mTeam.teamType.toLowerCase().contains("club")) {
          isClubTeam = true;
          clubTeamList.add(ClubTeamModel(
            TextEditingController(text: _mTeamData.orgName),
            TextEditingController(text: _mTeamData.teamName),
            TextEditingController(text: _mTeamData.city),
            TextEditingController(text: _mTeamData.state),
            TextEditingController(text: _mTeamData.jersey),
            TextEditingController(text: _mTeamData.coachName),
            TextEditingController(text: _mTeamData.coachEmail),
            TextEditingController(text: _mTeamData.coachPhoneNo),
            selectedCountryCode: _mTeamData.coachCountryCode,
            selectedcoachPhoneCode: _mTeamData.coachPhoneCode,
          ));
        } else if (_mTeam.teamType.toLowerCase().contains("college")) {
          isCollegeTeam = true;
          collegeTeamList.add(ClubTeamModel(
            TextEditingController(text: _mTeamData.orgName),
            TextEditingController(text: _mTeamData.teamName),
            TextEditingController(text: _mTeamData.city),
            TextEditingController(text: _mTeamData.state),
            TextEditingController(text: _mTeamData.jersey),
            TextEditingController(text: _mTeamData.coachName),
            TextEditingController(text: _mTeamData.coachEmail),
            TextEditingController(text: _mTeamData.coachPhoneNo),
            selectedCountryCode: _mTeamData.coachCountryCode,
            selectedcoachPhoneCode: _mTeamData.coachPhoneCode,
          ));
        } else if (_mTeam.teamType.toLowerCase().contains("school")) {
          isHighSchoolTeam = true;
          highSchoolTeamList.add(ClubTeamModel(
            TextEditingController(text: _mTeamData.orgName),
            TextEditingController(text: _mTeamData.teamName),
            TextEditingController(text: _mTeamData.city),
            TextEditingController(text: _mTeamData.state),
            TextEditingController(text: _mTeamData.jersey),
            TextEditingController(text: _mTeamData.coachName),
            TextEditingController(text: _mTeamData.coachEmail),
            TextEditingController(text: _mTeamData.coachPhoneNo),
            selectedCountryCode: _mTeamData.coachCountryCode,
            selectedcoachPhoneCode: _mTeamData.coachPhoneCode,
          ));
        } else if (_mTeam.teamType.toLowerCase().contains("other")) {
          isOtherTeam = true;
          otherTeamList.add(ClubTeamModel(
            TextEditingController(text: _mTeamData.orgName),
            TextEditingController(text: _mTeamData.teamName),
            TextEditingController(text: _mTeamData.city),
            TextEditingController(text: _mTeamData.state),
            TextEditingController(text: _mTeamData.jersey),
            TextEditingController(text: _mTeamData.coachName),
            TextEditingController(text: _mTeamData.coachEmail),
            TextEditingController(text: _mTeamData.coachPhoneNo),
            selectedCountryCode: _mTeamData.coachCountryCode,
            selectedcoachPhoneCode: _mTeamData.coachPhoneCode,
          ));
        }
      }
    }

    if (achivmentModel.guidePromptRecommendation == "true") {
      isPrompt = true;
      isPromptfinal = true;
    } else {
      isPrompt = false;
      isPromptfinal = false;
    }

    setState(() {
      isPrompt;
    });

    if (achivmentModel.coachFirstName == null ||
        achivmentModel.coachFirstName == "null") {
      strCoachFirstName = "";
      coachFirstNameController = TextEditingController(text: "");
    } else {
      strCoachFirstName = achivmentModel.coachFirstName;
      coachFirstNameController =
          TextEditingController(text: achivmentModel.coachFirstName);
    }

    if (achivmentModel.recommenderTitle == null ||
        achivmentModel.recommenderTitle == "null") {
      strRecommendationTitle = "";
      recommendationTitleController = TextEditingController(text: "");
    } else {
      strRecommendationTitle = achivmentModel.recommenderTitle;
      recommendationTitleController =
          TextEditingController(text: achivmentModel.recommenderTitle);
    }

    if (achivmentModel.recommendationTitle == null ||
        achivmentModel.recommendationTitle == "null") {
      strRecommenderTitle = "";
      recommenderTitleController = TextEditingController(text: "");
    } else {
      strRecommenderTitle = achivmentModel.recommendationTitle;
      recommenderTitleController =
          TextEditingController(text: achivmentModel.recommendationTitle);
    }

    if (achivmentModel.recommenderRequest == null ||
        achivmentModel.recommenderRequest == "null") {
      strRecommendationRequest = "";
      recommendationRequestController = TextEditingController(text: "");
    } else {
      strRecommendationRequest = achivmentModel.recommenderRequest;
      recommendationRequestController =
          TextEditingController(text: achivmentModel.recommenderRequest);
    }

    if (achivmentModel.coachLastName == null ||
        achivmentModel.coachLastName == "null") {
      strCoachLastName = "";
      coachLastNameController = TextEditingController(text: "");
    } else {
      strCoachLastName = achivmentModel.coachLastName;
      coachLastNameController =
          TextEditingController(text: achivmentModel.coachLastName);
    }

    if (achivmentModel.coachEmail == null ||
        achivmentModel.coachEmail == "null") {
      strCoachEmail = "";
      coachEmaiController = TextEditingController(text: "");
    } else {
      strCoachEmail = achivmentModel.coachEmail;
      coachEmaiController =
          TextEditingController(text: achivmentModel.coachEmail);
    }

    strCompetencyValue = achivmentModel.level3Competency == null
        ? ""
        : achivmentModel.level3Competency;
    strLevelValue = achivmentModel.importance;

    if (achivmentModel.fromDate == null ||
        achivmentModel.fromDate == "" ||
        achivmentModel.fromDate == "null") {
      strFromDate = "";
      fromDateController = TextEditingController(text: "");

      strToDate = "";
      toDateController = TextEditingController(text: "");
    } else {
      if (achivmentModel.fromDate != null &&
          achivmentModel.fromDate != "" &&
          achivmentModel.fromDate != "null") {
        DateTime date = DateTime.fromMillisecondsSinceEpoch(
            int.tryParse(achivmentModel.fromDate));
        fromDate = date;
        /* fromDateController =  TextEditingController(
          text:  DateFormat("dd-MM-yyyy").format(date));*/
        /*   fromDateController =  TextEditingController(
            text:  DateFormat("MM-dd-yyyy").format(date));*/

        fromDateController = TextEditingController(text: Util.getDate(date));
        strFromDate = achivmentModel.fromDate;
      } else {
        strFromDate = "";
      }

      if (achivmentModel.toDate != null &&
          achivmentModel.toDate != "" &&
          achivmentModel.toDate != "null") {
        DateTime date = DateTime.fromMillisecondsSinceEpoch(
            int.tryParse(achivmentModel.toDate));
        toDate = date;

        /* toDateController =  TextEditingController(
            text:  DateFormat("MM-dd-yyyy").format(date));*/

        toDateController = TextEditingController(text: Util.getDate(date));
        strToDate = achivmentModel.toDate;
      } else {
        // toDate =  DateTime.now();
        strToDate = "";
        toDateController = TextEditingController(text: "");
        isPresent = true;
      }
    }

    assestList.addAll(achivmentModel.assestList);

    skillsSelectedList.addAll(achivmentModel.skillList);

    if (achivmentModel.mediaList.length == 0 &&
        achivmentModel.certificateList.length == 0 &&
        achivmentModel.badgeList.length == 0 &&
        achivmentModel.trophyList == 0) {
      isShowMedia = false;
    }

    certificateList.addAll(achivmentModel.certificateList);
    certificateList.add("");

    // badgeList.addAll(achivmentModel.badgeList);
    // badgeList.add("");

    for (var file in achivmentModel.badgeList) {
      badgeAndTrophyList.add(new Assest("image", "badges", file, "", false));
    }

    for (var file in achivmentModel.trophyList) {
      badgeAndTrophyList.add(new Assest("image", "badges", file, "", false));
    }

    badgeAndTrophyList.add(new Assest("image", "badges", "", "", false));
    // trophyList.addAll(achivmentModel.trophyList);
    // trophyList.add("");
    // TODO: implement initState
    super.initState();
  }

  //--------------------------Api Calling for delete achevement ------------------
  Future apiCallingForDeleteAchievment(achievementId) async {
    try {
      CustomProgressLoader.showLoader(context);
      Map map = {
        "achievementId": achievementId,
      };

      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_ADD_ACHEVMENT, map);
      CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            Navigator.pop(context, "push");
          } else {
            ToastWrap.showToast(msg, context);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    this.context = context;
    void infoDialog() {
      FocusScope.of(context).requestFocus(new FocusNode());
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: widget.level1 == "Arts" ? 260 : 270,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        Container(
                                          height: widget.level1 == "Arts"
                                              ? 210
                                              : 220,
                                          padding: const EdgeInsets.fromLTRB(
                                              8.0, 15, 8, 0),
                                          width: double.infinity,
                                          color: Colors.white,
                                          child: ListView(children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      0.0, 0, 0, 13),
                                              child: Image.asset(
                                                'assets/profile/parent/info.png',
                                                height: 22.0,
                                                width: 22.0,
                                              ),
                                            ),
                                            Container(
                                                child: RichText(
                                              maxLines: 15,
                                              textAlign: TextAlign.center,
                                              text: TextSpan(
                                                text: widget.level1 == "Arts"
                                                    ? "Write a general introduction to your work. It should open with the work's basic ideas in an overview of two or three sentences or a short paragraph. The second paragraph should go into detail about how these issues or ideas are presented in the work."
                                                    : "This tells your story so share things like why you are passionate about the sport, how long you have been playing, who inspires you, any personality traits that makes you an awesome athlete and a great fit for any team. Goal is to WOW the reader to continue to review your portfolio.",
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              ),
                                            ))
                                          ]),
                                        ),
                                      ),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Close",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 20.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final dropdownMenuCompetency = level3Competencylist
        .map((Level3Competencies item) => DropdownMenuItem<Level3Competencies>(
            value: item,
            child: Text(
              item.name,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    final dropdownMenuLevel = levelList
        .map((AchievementImportanceModal item) =>
            DropdownMenuItem<AchievementImportanceModal>(
                value: item,
                child: Text(
                  item.title,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                )))
        .toList();

    void confromationDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child: Container(
                                  height: 195.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                            Container(
                                              height: 145.0,
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                    Text(
                                                      "Are you sure you want to remove this Accomplishment?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily: Constant
                                                              .TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                "Remove",
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                apiCallingForDeleteAchievment(
                                                    achivmentModel
                                                        .achievementId);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    //---------------------------------Skill Core Logic nd ui -----------------------
    void iterateFilters(key, value) {
      print('-------------$key:$value'); //string interpolation in action
      if (value) {
        if (key != 0) {
          if (filterData == "") {
            filterData = (key).toString();
            appliedFilter = skillList[key].title;

            skillsSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          } else {
            filterData = filterData + "," + (key).toString();
            appliedFilter = appliedFilter + "," + skillList[key].title;
            skillsSelectedList
                .add(Skill(skillList[key].title, skillList[key].skillId, key));
          }
        }
      }
    }

    _buildChoiceList() {
      List<Widget> choices = List();
      skillsSelectedList.forEach((item) {
        choices.add(Container(
            padding: const EdgeInsets.all(3.0),
            child: Row(
              children: <Widget>[
                Flexible(
                  child: Text(
                    item.label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION,
                        fontSize: 16.0,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  ),
                  flex: 1,
                ),
                Expanded(
                  child: InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        3.0,
                        0.0,
                        0.0,
                        Icon(
                          Icons.cancel,
                          color: ColorValues.BG_CIRCLE_COLOR,
                          size: 17.0,
                        )),
                    onTap: () {
                      setState(() {
                        skillsSelectedList.remove(item);
                        filterStatus[item.index] = false;
                        filterStatus[0] = false;
                      });
                      filterData = "";
                      appliedFilter = "";
                      skillsSelectedList.clear();
                      filterStatus.forEach(iterateFilters);
                    },
                  ),
                  flex: 0,
                ),
              ],
            )));
      });
      return choices;
    }

    void onApplyClick() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      filterStatus.forEach(iterateFilters);
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());
        appliedFilter;
      });
      Navigator.pop(context);
    }

    void onCancelTap() {
      filterData = "";
      appliedFilter = "";
      skillsSelectedList.clear();
      for (int i = 0; i < filterStatus.length; i++) {
        filterStatus[i] = false;
      }
      setState(() {
        FocusScope.of(context).requestFocus(new FocusNode());
        appliedFilter;
      });
      Navigator.pop(context);
    }

    void selectSkillDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.black38,
                  body: Center(
                      child: PaddingWrap.paddingAll(
                          10.0,
                          ListView(children: <Widget>[
                            Container(
                                padding: EdgeInsets.all(0.0),
                                color: Colors.white,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      color: Color(0XFFEDEDED),
                                      child: PaddingWrap.paddingfromLTRB(
                                          19.0,
                                          10.0,
                                          10.0,
                                          10.0,
                                          Text(
                                            "Each experience leads to skill building. So, select every skill you feel you built or exercised "
                                            "with this experience. Demonstrate why this experience was so enriching for you.",
                                            textAlign: TextAlign.start,
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION,
                                                fontFamily: Constant
                                                    .TYPE_CUSTOMREGULAR),
                                          )),
                                    ),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        20.0,
                                        10.0,
                                        10.0,
                                        Text(
                                          "Select all your skills from the list below:",
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR),
                                        )),
                                    PaddingWrap.paddingfromLTRB(
                                        19.0,
                                        0.0,
                                        10.0,
                                        10.0,
                                        ListView.builder(
                                            // itemCount: myData.lenght(),
                                            shrinkWrap: true,
                                            itemCount: skillList.length,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              if ((skillList.length - 1) ==
                                                  index) {
                                                return Column(
                                                  children: <Widget>[
                                                    InkWell(
                                                      child: Padding(
                                                          padding: EdgeInsets
                                                              .fromLTRB(
                                                                  0.0,
                                                                  8.0,
                                                                  0.0,
                                                                  8.0),
                                                          child: Row(
                                                            children: <Widget>[
                                                              filterStatus[
                                                                      index]
                                                                  ? Expanded(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child: Image.asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0)
                                                                  : Expanded(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                          child: Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                      flex: 0),
                                                              Expanded(
                                                                  child: Text(
                                                                skillList[index]
                                                                    .title,
                                                                maxLines: 3,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color: ColorValues
                                                                        .HEADING_COLOR_EDUCATION,
                                                                    fontFamily:
                                                                        Constant
                                                                            .TYPE_CUSTOMREGULAR),
                                                              )),
                                                            ],
                                                          )),
                                                      onTap: () {
                                                        bool value =
                                                            filterStatus[index];

                                                        if (index == 0) {
                                                          for (int i = 0;
                                                              i <
                                                                  filterStatus
                                                                      .length;
                                                              i++) {
                                                            if (value)
                                                              filterStatus[i] =
                                                                  false;
                                                            else
                                                              filterStatus[i] =
                                                                  true;
                                                          }
                                                        } else {
                                                          // filterStatus[0] = false; // Set All false
                                                          if (filterStatus[
                                                              index]) {
                                                            filterStatus[
                                                                index] = false;
                                                          } else {
                                                            filterStatus[
                                                                index] = true;
                                                          }
                                                        }

                                                        // Refresh the All Check
                                                        int count = 0;
                                                        for (int i = 1;
                                                            i <
                                                                filterStatus
                                                                    .length;
                                                            i++) {
                                                          if (!filterStatus[i])
                                                            count++;
                                                        }

                                                        if (count > 0) {
                                                          filterStatus[0] =
                                                              false;
                                                        } else {
                                                          filterStatus[0] =
                                                              true;
                                                        }

                                                        setState(() {
                                                          filterStatus;
                                                        });
                                                        Navigator.pop(context);
                                                        selectSkillDialog();
                                                      },
                                                    ),
                                                    Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            15.0,
                                                            20.0,
                                                            0.0,
                                                            20.0,
                                                            InkWell(
                                                              child: Text(
                                                                'Cancel',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR),
                                                              ),
                                                              onTap: () {
                                                                onCancelTap();
                                                              },
                                                            ),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            0.0,
                                                            20.0,
                                                            20.0,
                                                            20.0,
                                                            InkWell(
                                                              child: Text(
                                                                '',
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16.0,
                                                                    color: ColorValues
                                                                        .GREY_TEXT_COLOR),
                                                              ),
                                                            ),
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        Expanded(
                                                          child: PaddingWrap
                                                              .paddingfromLTRB(
                                                            10.0,
                                                            20.0,
                                                            30.0,
                                                            20.0,
                                                            InkWell(
                                                                child: Text(
                                                                  'Done',
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                          16.0,
                                                                      color: ColorValues
                                                                          .BLUE_COLOR_BOTTOMBAR),
                                                                ),
                                                                onTap: () {
                                                                  print("filterData..." +
                                                                      filterData
                                                                          .toString());
                                                                  print("appliedFilter..." +
                                                                      appliedFilter
                                                                          .toString());
                                                                  print("skillsSelectedList..." +
                                                                      skillsSelectedList
                                                                          .toString());
                                                                  print("filterStatus..." +
                                                                      filterStatus
                                                                          .toString());
                                                                  bool
                                                                      checkFilterSrarus =
                                                                      false;
                                                                  for (int i =
                                                                          0;
                                                                      i <
                                                                          filterStatus
                                                                              .length;
                                                                      i++) {
                                                                    if (filterStatus[
                                                                            i] ==
                                                                        true) {
                                                                      checkFilterSrarus =
                                                                          true;
                                                                    }
                                                                    if (i ==
                                                                        8) {
                                                                      if (checkFilterSrarus) {
                                                                        onApplyClick();
                                                                      } else {
                                                                        ToastWrap.showToast(
                                                                            'Please select atleast one skill',
                                                                            context);
                                                                      }
                                                                    }
                                                                  }
                                                                }),
                                                          ),
                                                          flex: 0,
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                );
                                              } else {
                                                return InkWell(
                                                  child: Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              0.0,
                                                              8.0,
                                                              0.0,
                                                              8.0),
                                                      child: Row(
                                                        children: <Widget>[
                                                          filterStatus[index]
                                                              ? Expanded(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              8.0,
                                                                              5.0),
                                                                          child: Image
                                                                              .asset(
                                                                            "assets/newDesignIcon/navigation/check.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0)
                                                              : Expanded(
                                                                  child:
                                                                      Padding(
                                                                          padding: EdgeInsets.fromLTRB(
                                                                              0.0,
                                                                              5.0,
                                                                              8.0,
                                                                              5.0),
                                                                          child:
                                                                              Image.asset(
                                                                            "assets/newDesignIcon/navigation/uncheck.png",
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          )),
                                                                  flex: 0),
                                                          Expanded(
                                                              child: Text(
                                                            skillList[index]
                                                                .title,
                                                            maxLines: 3,
                                                            style: TextStyle(
                                                                fontSize: 14.0,
                                                                color: ColorValues
                                                                    .HEADING_COLOR_EDUCATION,
                                                                fontWeight: skillList[index]
                                                                            .title ==
                                                                        "Select All"
                                                                    ? FontWeight
                                                                        .bold
                                                                    : FontWeight
                                                                        .normal,
                                                                fontFamily: Constant
                                                                    .TYPE_CUSTOMREGULAR),
                                                          )),
                                                        ],
                                                      )),
                                                  onTap: () {
                                                    bool value =
                                                        filterStatus[index];
                                                    if (index == 0) {
                                                      for (int i = 0;
                                                          i <
                                                              filterStatus
                                                                  .length;
                                                          i++) {
                                                        if (value)
                                                          filterStatus[i] =
                                                              false;
                                                        else
                                                          filterStatus[i] =
                                                              true;
                                                      }
                                                    } else {
                                                      filterStatus[0] = false;
                                                      if (filterStatus[index]) {
                                                        filterStatus[index] =
                                                            false;
                                                      } else {
                                                        filterStatus[index] =
                                                            true;
                                                      }
                                                    }

                                                    // Refresh the All Check
                                                    int count = 0;
                                                    for (int i = 1;
                                                        i < filterStatus.length;
                                                        i++) {
                                                      if (!filterStatus[i])
                                                        count++;
                                                    }

                                                    if (count > 0) {
                                                      filterStatus[0] = false;
                                                    } else {
                                                      filterStatus[0] = true;
                                                    }

                                                    setState(() {
                                                      filterStatus;
                                                    });
                                                    Navigator.pop(context);
                                                    selectSkillDialog();
                                                  },
                                                );
                                              }
                                            }))
                                  ],
                                ))
                          ]))))));
    }

//======================================================================================

    //------------------------Image Sewlection ---------------------------
    Future<Null> _cropImage(File imageFile) async {
      imagePath = await ImageCropper.cropImage(
        sourcePath: imageFile.path,
        ratioX: 1.6,
        ratioY: 0.9,
      );
    }

    final competencyDropDownUi = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<Level3Competencies>(
                hint: Text(
                  strCompetencyHint,
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: competencySelected,
                items: dropdownMenuCompetency,
                onChanged: (Level3Competencies item) {
                  if (item.name == "Other") {
                    isOtherCategory = true;
                    isThirdLevelOther = true;
                  } else {
                    isThirdLevelOther = false;
                    isOtherCategory = false;
                    thirdLevelController.text = "";
                  }
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    competencySelected = item;
                    strCompetencyValue = item.name;
                  });
                })));

    final competencyDropLevel = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<AchievementImportanceModal>(
                hint: Text(
                  strLevelHint,
                  style: TextStyle(
                      fontSize: 16.0,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ),
                value: levelSelected,
                items: dropdownMenuLevel,
                onChanged: (AchievementImportanceModal level) {
                  setState(() {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    levelSelected = level;
                    strLevelValue = level.importanceId;
                  });
                })));

    final titleUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          maxLength: 200,
          focusNode: _focus,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          controller: titleController,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR)*/
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              "Title",
              widget.level1 == "Arts"
                  ? 'My Arts Portfolio'
                  : widget.level1 == "Sports" ? "My Baseball Portfolio" : ""),
          /*InputDecoration(
            counterText: "",
            labelText: "Title",
            errorStyle: Util.errorTextStyle,
            hintText: widget.level1 == "Arts"
                ? 'My Arts Portfolio'
                : widget.level1 == "Sports"
                    ? "My Baseball Portfolio"
                    : "",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
        ));

    getEditCategoryTextField(isEnabled, label) {
      return Container(
          padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 5.0),
          child: TextFormField(
            keyboardType: TextInputType.text,
            style: TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
            //autofocus: true,
            //enabled: isEnabled,
            maxLength: isEnabled
                ? TextLength.OTHER_MAX_LENGTH
                : TextLength.OTHER_COMPETENCY_MAX_LENGTH,

            textCapitalization: TextCapitalization.sentences,
            cursorColor: Constant.CURSOR_COLOR,
            controller: isEnabled ? otherCategory : thirdLevelController,
            decoration:
                BaseCommonWidget.textFormFieldDecorationAchievment(label, ""),
            /*InputDecoration(
              contentPadding: const EdgeInsets.fromLTRB(
                0.0,
                5.0,
                5.0,
                5.0,
              ),
              labelText: label,
              errorStyle: Util.errorTextStyle,
              counterText: "",
              //hintText: isEnabled ? "" : strCompetencyValue,
              labelStyle:
                   TextStyle(color:  ColorValues.GREY_TEXT_COLOR),
              fillColor: Colors.transparent,
              enabledBorder: UnderlineInputBorder(
                borderSide:
                    BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
              ),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0)),
            ),*/
            validator: (val) =>
                val.trim().isEmpty ? MessageConstant.ENTER_TITLE_VAL : null,
          ));
    }

    editCategoryDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                // Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              top: 53.0,
                              child: Container(
                                  height: 155.0,
                                  //  color: Colors.transparent,
                                  decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    image: DecorationImage(
                                      image: AssetImage("assets/container.png"),
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                  child: Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          12.0,
                                          10.0,
                                          11.0,
                                          0.0,
                                          Container(
                                              height: 155.0,
                                              padding: EdgeInsets.fromLTRB(
                                                  13.0, 0, 13, 0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Form(
                                                  key: _formKey2,
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: <Widget>[
                                                        getEditCategoryTextField(
                                                            true,
                                                            "Enter display title"),
                                                        InkWell(
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 6.0,
                                                                    bottom:
                                                                        6.0),
                                                            child: Container(
                                                                width: 80.0,
                                                                height: 30.0,
                                                                color: ColorValues
                                                                    .BLUE_COLOR_BOTTOMBAR,
                                                                child: Center(
                                                                  child: Text(
                                                                    "ADD",
                                                                    textAlign:
                                                                        TextAlign
                                                                            .center,
                                                                    style: TextStyle(
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                            12.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  ),
                                                                )),
                                                          ),
                                                          onTap: () {
                                                            final form1 =
                                                                _formKey2
                                                                    .currentState;

                                                            form1.save();
                                                            if (form1
                                                                .validate()) {
                                                              Navigator.pop(
                                                                  context);
                                                              setState(() {
                                                                strCompetencyValue =
                                                                    otherCategory
                                                                        .text;
                                                              });
                                                            }
                                                          },
                                                        )
                                                      ])))),
                                    ],
                                  ))),
                        ],
                      )))));
    }

    /*   editCategoryDialog() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 30.0,
                              child:  Container(
                                  height: 125.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          0.0,
                                          13.0,
                                          0.0,
                                           Container(
                                              height: 85.0,
                                              padding:  EdgeInsets.fromLTRB(
                                                  10.0, 0, 10, 0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child: Form(
                                                  key: _formKey2,
                                                  child:  Column(
                                                      children: <Widget>[
                                                        getEditCategoryTextField(
                                                            true,
                                                            achivmentModel
                                                                        .level2Competency ==
                                                                    "General"
                                                                ? "Change General To:"
                                                                : "Change Other To:")
                                                      ])))),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.of(context,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Save",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                final form1 =
                                                    _formKey2.currentState;

                                                form1.save();
                                                if (form1.validate()) {
                                                  Navigator.pop(context);
                                                  setState(() {
                                                    strCompetencyValue =
                                                        otherCategory.text;
                                                  });
                                                }
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }*/

    final recommenderTitle = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: recommenderTitleController,
          enabled: (!isPromptfinal),
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /* TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              "Title", "eg.Science Teacher"),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelText: "Title",
            errorStyle: Util.errorTextStyle,
            hintText: "eg.Science Teacher",
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => isPromptfinal
              ? null
              : val.trim().isEmpty
                  ? isPrompt ? MessageConstant.ENTER_TITLE_VAL : null
                  : null,
          onSaved: (val) => strRecommenderTitle = val.trim(),
        ));

    final recommendationRequest = Padding(
        padding: const EdgeInsets.fromLTRB(0.0, 15, 0, 0),
        child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(0),
              border: Border.all(
                color: Color(0xFFFDEDEDE),
                style: BorderStyle.solid,
                width: 1.0,
              ),
            ),
            padding: EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 0.0),
            child: TextFormField(
              keyboardType: TextInputType.multiline,
              cursorColor: Constant.CURSOR_COLOR,
              maxLength: TextLength.RECOMMENDATION_REQUEST_MSG_LENGTH,
              controller: recommendationRequestController,
              enabled: (!isPromptfinal),
              textCapitalization: TextCapitalization.sentences,
              maxLines: 3,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
                  "Recommendation request",
                  "Hi Coach, What a great soccer season. Can you please take a few min to recommend me on my soccer, leadership, and team building skills."),
              /*InputDecoration(
                floatingLabelBehavior: FloatingLabelBehavior.always,
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                hintText:
                    "",
                counterText: "",
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                labelText: "Recommendation Request",
                errorStyle: Util.errorTextStyle,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 10.0),
                fillColor: Colors.transparent,
              ),*/
              validator: (val) => (isPromptfinal)
                  ? null
                  : val.trim().isEmpty
                      ? isPrompt ? MessageConstant.ENTER_REQUEST_VAL : null
                      : null,
              onSaved: (val) => strRecommendationRequest = val.trim(),
            )));

    final recommendationTitle = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          enabled: (!isPromptfinal),
          autofocus: isPromptfinal ? false : true,
          cursorColor: Constant.CURSOR_COLOR,
          controller: recommendationTitleController,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              "Recommendation Title", ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelText: "Recommendation Title",
            errorStyle: Util.errorTextStyle,
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt ? MessageConstant.ENTER_RECOMMENDATION_TITLE_VAL : null
              : null,
          onSaved: (val) => strRecommendationTitle = val.trim(),
        ));

    final coachFirstName = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        0.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.text,
          controller: coachFirstNameController,
          cursorColor: Constant.CURSOR_COLOR,
          enabled: (!isPromptfinal),
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
          /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAchievment(
              MessageConstant.ADD_ACCOMPLISHMENT_FIRST_NAME,
              MessageConstant.ADD_ACCOMPLISHMENT_FIRST_NAME),
          /*InputDecoration(
            labelText: "First Name",
            errorStyle: Util.errorTextStyle,
            hintText: "First Name",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_FIRST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_FIRST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachFirstName = val.trim(),
        )));
    final coachLastName = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        0.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.text,
          cursorColor: Constant.CURSOR_COLOR,
          enabled: (!isPromptfinal),
          controller: coachLastNameController,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
          /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              MessageConstant.ADD_ACCOMPLISHMENT_LAST_NAME,
              MessageConstant.ADD_ACCOMPLISHMENT_LAST_NAME),
          /*InputDecoration(
            labelText: "Last Name",
            errorStyle: Util.errorTextStyle,
            hintText: "Last Name",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_LAST_NAME_VAL
                      : !ValidationWidget.isName(val)
                          ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                          : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_LAST_NAME_VAL
                  : !ValidationWidget.isName(val)
                      ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL
                      : null,
          onSaved: (val) => strCoachLastName = val.trim(),
        )));

    final coachEmail = PaddingWrap.paddingfromLTRB(
        0.0,
        10.0,
        0.0,
        16.0,
        Container(
            child: TextFormField(
          keyboardType: TextInputType.emailAddress,
          controller: coachEmaiController,
          cursorColor: Constant.CURSOR_COLOR,
          enabled: (!isPromptfinal),
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
          /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              MessageConstant.ADD_ACCOMPLISHMENT_EMAIL, "abc@xyz.com"),
          /*InputDecoration(
            labelText: "Email",
            errorStyle: Util.errorTextStyle,
            hintText: "abc@xyz.com",
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) => val.trim().isEmpty
              ? isPrompt
                  ? val.trim().length == 0
                      ? MessageConstant.ENTER_EMAIL_VAL
                      : val.toString().toLowerCase() == userEmail.toLowerCase()
                          ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
                          : !ValidationWidget.isEmail(val)
                              ? MessageConstant.VALID_EMAIL_VAL
                              : null
                  : null
              : val.trim().length == 0
                  ? MessageConstant.ENTER_EMAIL_VAL
                  : val.toString().toLowerCase() == userEmail.toLowerCase()
                      ? MessageConstant.SELF_RECOMMENDATION_NOT_GOOD_IDEA
                      : !ValidationWidget.isEmail(val)
                          ? MessageConstant.VALID_EMAIL_VAL
                          : null,
          onSaved: (val) => strCoachEmail = val.trim(),
        )));

    final bioUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: bioController,
          maxLength: 1000,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              MessageConstant.ADD_ACCOMPLISHMENT_BIO, ""),
          /* InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "Bio",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
        ));

    final descriptrionUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: Stack(
          children: <Widget>[
            TextFormField(
              keyboardType: TextInputType.text,
              controller: descController,
              maxLength: 1000,
              cursorColor: Constant.CURSOR_COLOR,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              decoration:
                  BaseCommonWidget.textFormFieldDecorationAccomplishment(
                      widget.level1 == "Arts"
                          ? "Artist Statement"
                          : "Personal Statement",
                      widget.level1 == "Arts"
                          ? MessageConstant.ADD_ACCOMPLISHMENT_I_AM_A_POSSIONATE
                          : MessageConstant
                              .ADD_ACCOMPLISHMENT_AS_VERSATILE_STUDENT),
              /*InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  0.0,
                  5.0,
                ),
                counterText: "",
                labelText: widget.level1 == "Arts"
                    ? "Artist Statement"
                    : "Personal Statement",
                errorStyle: Util.errorTextStyle,
                hintMaxLines: isShiftBelow ? 1 : 4,
                hintText: widget.level1 == "Arts"
                    ? "I am a passionate artist focused on pottery. I have 5 years of experience, but pottery is where I stand out. Statement: In my art, I like to capture the beauty in mundane objects and places. Different mediums allow me to..."
                    : "As a versatile student-athlete, I bring unique skills to any competitive baseball team. I strive to be an impact player, always looking at how to help my team win.",
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 10),
                fillColor: Colors.transparent,
              ),*/
              validator: (val) =>
                  /*widget.level1 == "Arts"
                  ? null
                  :*/
                  val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
              onSaved: (val) => strDeascription = val.trim(),
              focusNode: _focusDescription,
            ),
            Positioned(
              /*top: isShiftBelow ? 16.0 : 4.0,
              right: 4.0,*/
              top: isShiftBelow ? 16.0 : 4.0,
              // left: widget.level1 == "Arts" ?  isShiftBelow ? 125 : 115 : isShiftBelow ? 145 : 135,
              left: widget.level1 == MessageConstant.ADD_ACCOMPLISHMENT_ARTS
                  ? isShiftBelow ? 135 : 105
                  : isShiftBelow ? 160 : 125,
              child: widget.level1 !=
                          MessageConstant.ADD_ACCOMPLISHMENT_SPORTS &&
                      widget.level1 != MessageConstant.ADD_ACCOMPLISHMENT_ARTS
                  ? Container(
                      height: 0.0,
                      width: 0.0,
                    )
                  : InkWell(
                      child: Image.asset(
                        'assets/profile/parent/info.png',
                        height: 12.0,
                        width: 12.0,
                      ),
                      onTap: () {
                        FocusScope.of(context).requestFocus(new FocusNode());
                        infoDialog();
                      },
                    ),
            ),
          ],
        ));

    final cityUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: cityController,
          maxLength: 50,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              MessageConstant.ADD_ACCOMPLISHMENT_CITY, ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "City",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
        ));

    final stateUi = Container(
        padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: stateController,
          maxLength: 50,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,*/
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              MessageConstant.ADD_ACCOMPLISHMENT_STATE, ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "State",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),*/
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,
        ));

    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Future<Null> selectFromDate(BuildContext context) async {
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: fromDate == null ? DateTime.now() : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () => print("----- onClose -----"),
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime != null) {
            fromDate = dateTime;
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime);
            print(date);
            setState(() {
              fromDate;
              strFromDate = (dateTime.millisecondsSinceEpoch).toString();
              fromDateController = TextEditingController(text: date);
              toDateController = TextEditingController(text: "");
              strToDate = "";
            });
          }
        },
      );
    }

    final fromDateUi = InkWell(
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            child: TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /* TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              controller: fromDateController,
              decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
                  MessageConstant.ADD_ACCOMPLISHMENT_DATE_FROM,
                  ""), /*InputDecoration(
                border: InputBorder.none,
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                labelText: MessageConstant.ADD_ACCOMPLISHMENT_DATE_FROM,
                errorStyle: Util.errorTextStyle,
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),*/
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());

            selectFromDate(context);
          });
        });

    Future<Null> selectToDate(BuildContext context) async {
      DateTime dateTime2;
      DatePicker.showDatePicker(
        context,
        pickerTheme: DateTimePickerTheme(
          showTitle: true,
          confirm: Text('Done', style: TextStyle()),
          cancel: Text('Cancel', style: TextStyle()),
        ),
        minDateTime: startDate,
        pickerMode: DateTimePickerMode.date,
        maxDateTime: DateTime.now(),
        initialDateTime: toDateController == null || toDateController.text == ""
            ? fromDate
            : toDate != null ? toDate : fromDate,
        dateFormat: 'MMM-dd-yyyy',
        locale: DateTimePickerLocale.en_us,
        onClose: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
          });
          if (dateTime2 != null) {
            // String date =  DateFormat("MM-dd-yyyy").format(picked);
            String date = Util.getDate(dateTime2);
            String date2 = DateFormat("yyyy-MM-dd").format(dateTime2);
            print(date);

            var differenceStartDate = dateTime2.difference(fromDate);
            if (differenceStartDate.inDays >= 0) {
              setState(() {
                isPresent = false;
                toDate = dateTime2;
                strToDate = (dateTime2.millisecondsSinceEpoch).toString();
                toDateController = TextEditingController(text: date);
              });
            } else {
              ToastWrap.showToast(
                  MessageConstant.ENTER_CORRECT_DATE_RANGE_VAL, context);
            }
          }
        },
        onCancel: () => print('onCancel'),
        onChange: (dateTime, List<int> index) {
          print("onchange" + dateTime.toString());
        },
        onConfirm: (dateTime, List<int> index) {
          print("onconform" + dateTime.toString());
          dateTime2 = dateTime;
        },
      );
    }

    final toDateUi = InkWell(
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            child: TextField(
              keyboardType: TextInputType.text,
              enabled: false,
              style: AppTextStyle.getDynamicStyleAddPortfolia(
                  ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontType.Regular),
              /*TextStyle(
                  color:  ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
              controller: toDateController,
              decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
                  MessageConstant.ADD_ACCOMPLISHMENT_DATE_TO,
                  ""), /*InputDecoration(
                border: InputBorder.none,
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                labelText: MessageConstant.ADD_ACCOMPLISHMENT_DATE_TO,
                errorStyle: Util.errorTextStyle,
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
              ),*/
            )),
        onTap: () {
          setState(() {
            FocusScope.of(context).requestFocus(new FocusNode());
            if (fromDate != null) {
              selectToDate(context);
            } else {
              ToastWrap.showToast(
                  MessageConstant.SELECT_FROM_DATE_VAL, context);
            }
          });
        });

    showHeight() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 38.0,
                              child: Container(
                                  height: 190.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 0, 13, 0),
                                        child: Container(
                                          color: Colors.white,
                                          height: 155.0,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  color: Colors.white,
                                                  height: 40.0,
                                                  child: Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          13.0, 8, 0, 0),
                                                      child: Text(
                                                        MessageConstant
                                                            .ADD_ACCOMPLISHMENT_HEIGHT,
                                                        style: AppTextStyle
                                                            .getDynamicStyleAddPortfolia(
                                                                ColorValues
                                                                    .GREY_TEXT_COLOR,
                                                                18.0,
                                                                FontType
                                                                    .Regular) /*TextStyle(
                                                            color:  ColorValues.GREY_TEXT_COLOR,
                                                            fontSize: 18.0,
                                                            fontFamily:Constant.TYPE_CUSTOMREGULAR)*/
                                                        ,
                                                      ))),
                                              Container(
                                                color: ColorValues.GREY__COLOR,
                                                height: 0.3,
                                              ),
                                              Container(
                                                  height: 113.0,
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                                Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strFootValue =
                                                                    footList[
                                                                        value];
                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:
                                                                List.generate(
                                                                    footList
                                                                        .length,
                                                                    (int
                                                                        index) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                child: Text(
                                                                  footList[
                                                                      index],
                                                                  style:
                                                                      styleForHeight,
                                                                ),
                                                              );
                                                            })),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: CupertinoPicker(
                                                            backgroundColor:
                                                                Colors.white,
                                                            onSelectedItemChanged:
                                                                (value) {
                                                              setState(() {
                                                                //selectedValue = value;
                                                                strInchValue =
                                                                    inchList[
                                                                        value];
                                                              });
                                                            },
                                                            itemExtent: 40.0,
                                                            children:
                                                                List.generate(
                                                                    inchList
                                                                        .length,
                                                                    (int
                                                                        index) {
                                                              return Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .fromLTRB(
                                                                        0.0,
                                                                        4,
                                                                        0,
                                                                        0),
                                                                child: Text(
                                                                  inchList[
                                                                      index],
                                                                  style:
                                                                      styleForHeight,
                                                                ),
                                                              );
                                                            })),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  )),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleAddPortfolia(
                                                        ColorValues
                                                            .GREY_TEXT_COLOR,
                                                        16.0,
                                                        FontType
                                                            .Regular), /* TextStyle(
                                                        color:  ColorValues.GREY_TEXT_COLOR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR),*/
                                              )),
                                              onTap: () {
                                                Navigator.of(context,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant
                                                    .ADD_ACCOMPLISHMENT_SAVE,
                                                textAlign: TextAlign.center,
                                                style: AppTextStyle
                                                    .getDynamicStyleAddPortfolia(
                                                        ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        16.0,
                                                        FontType
                                                            .Regular) /*TextStyle(
                                                        color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                        fontSize: 16.0,
                                                        fontFamily:Constant.TYPE_CUSTOMREGULAR)*/
                                                ,
                                              )),
                                              onTap: () {
                                                isValidHeight = true;

                                                heightController.text =
                                                    strFootValue + strInchValue;
                                                Navigator.pop(context);
                                                setState(() {});
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    ageSelection() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) => WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child: SafeArea(
                  child: Scaffold(
                      backgroundColor: Colors.black38,
                      body: Stack(
                        children: <Widget>[
                          Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 38.0,
                              child: Container(
                                  height: 190.0,
                                  color: Colors.transparent,
                                  child: Stack(
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 0, 13, 0),
                                        child: Container(
                                          color: Colors.white,
                                          height: 155.0,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  color: Colors.white,
                                                  height: 40.0,
                                                  child: Padding(
                                                      padding: const EdgeInsets
                                                              .fromLTRB(
                                                          13.0, 8, 0, 0),
                                                      child: Text(
                                                        MessageConstant
                                                            .ADD_ACCOMPLISHMENT_AGE,
                                                        style: TextStyle(
                                                            color: ColorValues
                                                                .GREY_TEXT_COLOR,
                                                            fontSize: 18.0,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR),
                                                      ))),
                                              Container(
                                                color: ColorValues.GREY__COLOR,
                                                height: 0.3,
                                              ),
                                              Container(
                                                  height: 113.0,
                                                  child: CupertinoPicker(
                                                      backgroundColor:
                                                          Colors.white,
                                                      onSelectedItemChanged:
                                                          (value) {
                                                        setState(() {
                                                          //selectedValue = value;
                                                          strAgeValue =
                                                              yearList[value]
                                                                  .toString();
                                                          print(
                                                              "CupertinoPicker Value+++++" +
                                                                  footList[
                                                                      value]);
                                                        });
                                                      },
                                                      itemExtent: 40.0,
                                                      children: List.generate(
                                                          yearList.length,
                                                          (int index) {
                                                        return Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .fromLTRB(
                                                                  0.0, 4, 0, 0),
                                                          child: Text(
                                                            yearList[index]
                                                                .toString(),
                                                            style:
                                                                styleForHeight,
                                                          ),
                                                        );
                                                      }))),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ))),
                          Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                  Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child: Row(
                                        children: <Widget>[
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant.CANCEL,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.of(context,
                                                        rootNavigator: true)
                                                    .pop('dialog');
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                          Expanded(
                                            child: InkWell(
                                              child: Container(
                                                  child: Text(
                                                MessageConstant
                                                    .ADD_ACCOMPLISHMENT_SAVE,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                isValidAge = true;
                                                ageController.text =
                                                    strAgeValue;
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final heightUi = InkWell(
        onTap: () {
          FocusScope.of(context).unfocus();
          showHeight();
        },
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 10.0, 0.0),
            margin: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.text,
              controller: heightController,
              maxLength: 10,
              cursorColor: Constant.CURSOR_COLOR,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              enabled: (!isValidHeight),
              onTap: () {
                showHeight();
              },
              decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
                  MessageConstant.ADD_ACCOMPLISHMENT_HEIGHT,
                  MessageConstant
                      .ADD_ACCOMPLISHMENT_HEIGHT), /*InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  5.0,
                  5.0,
                ),
                counterText: "",
                labelText: "Height",
                errorStyle: Util.errorTextStyle,
                errorText:
                    (!isValidHeight) ? MessageConstant.FIELD_REQUIRED : null,
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                      color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                        color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 14.0),
                hintText: "Height",
                suffixIcon:  Icon(Icons.arrow_drop_down),
                hintStyle:  TextStyle(
                    color:  ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 13),
                fillColor: Colors.transparent,
              ),*/
            )));
    final weightUi = Container(
        padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.number,
          controller: weightController,
          maxLength: 10,
          focusNode: weightFocusNode,
          cursorColor: Constant.CURSOR_COLOR,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration: BaseCommonWidget.textFormFieldDecorationAccomplishment(
              "Weight (in pounds)", ""),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            labelText: "Weight (in pounds)",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 14.0),
            hintText: "",
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),*/
          /*       validator: (val) =>
          val.trim().isEmpty ? MessageConstant.FIELD_REQUIRED : null,*/
          onSaved: (val) => strWeight = val.trim(),
        ));

    final ageSelectionUi = InkWell(
        onTap: () {
          FocusScope.of(context).unfocus();
          ageSelection();
        },
        child: Container(
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            margin: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.text,
              controller: ageController,
              maxLength: 10,
              cursorColor: Constant.CURSOR_COLOR,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              textCapitalization: TextCapitalization.sentences,
              maxLines: null,
              enabled: (!isValidAge),
              onTap: () {
                ageSelection();
              },
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.fromLTRB(
                  0.0,
                  5.0,
                  0.0,
                  5.0,
                ),
                counterText: "",
                labelText: "Age",
                errorStyle: Util.errorTextStyle,
                errorText:
                    (!isValidAge) ? MessageConstant.FIELD_REQUIRED : null,
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                    borderSide:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0)),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 14.0),
                hintText: "",
                suffixIcon: Icon(Icons.arrow_drop_down),
                hintStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                    fontSize: 13),
                fillColor: Colors.transparent,
              ),
            )));

    ontapApply(type) async {
      if (imagePath != null) {
        strAzureImageUploadPath = await uploadImgOnAzure(
            imagePath
                .toString()
                .replaceAll("File: ", "")
                .replaceAll("'", "")
                .trim(),
            strPrefixPathforPhoto);
        setState(() {
          strAzureImageUploadPath;
        });
        CustomProgressLoader.cancelLoader(context);
        if ((strAzureImageUploadPath != "" &&
                strAzureImageUploadPath != "false") &&
            type == "portfolio") {
          portfolioImagePath = strPrefixPathforPhoto + strAzureImageUploadPath;
          setState(() {
            portfolioImagePath;
          });
        } else if (strAzureImageUploadPath != "" &&
            strAzureImageUploadPath != "false") {
          selectedImageType = "media";
          strAzureImageUploadPath = "";
          imagePath = null;
          setState(() {
            isMedaiDialog = false;
            selectedImageType;
            strAzureImageUploadPath;
            imagePath;
          });
        }
      }
    }

    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();

   //   imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null && imagePath != "") {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          await _cropImage(imagePath);
          if (imagePath != null) {
            /*setState(() {
            isMedaiDialog = true;
          });
          addMediaDialog();*/
            setState(() {
              imagePath;
            });

            CustomProgressLoader.showLoader(context);
            Timer _timer = Timer(const Duration(milliseconds: 400), () {
              ontapApply(type);
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    InkWell isImageSelectedView() {
      return InkWell(
        child: Container(
          width: 90.0,
          height: 90.0,
          child: Stack(
            children: <Widget>[
              Center(
                  child: Container(
                child: portfolioImagePath == ""
                    ? Image.asset(
                        "assets/profile/user_on_user.png",
                      )
                    : ClipOval(
                        child: CachedNetworkImage(
                        imageUrl: Constant.IMAGE_PATH + portfolioImagePath,
                        fit: BoxFit.cover,
                        placeholder: (context, url) =>
                            _loader(context, "assets/profile/user_on_user.png"),
                        errorWidget: (context, url, error) =>
                            _error("assets/profile/user_on_user.png"),
                      )),
                width: 85.0,
                height: 85.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              )),
              Align(
                  alignment: Alignment.bottomRight,
                  child: Container(
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                    child: Image.asset("assets/newDesignIcon/edit_img.png"),
                    height: 32.0,
                    width: 32.0,
                  ))
            ],
          ),
        ),
        onTap: () async {
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getImage("portfolio");
          } else {
            checkPermissionPhoto(context);
          }
        },
      );
    }
//==========================Grid View horizontal for Selected Images====================================

    // Build a Form widget using the _formKey we created above
    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: GestureDetector(
            onTap: () {
              // FocusScope.of(context).requestFocus(new FocusNode());
            },
            child: Scaffold(
                backgroundColor: Colors.white,
                appBar: AppBar(
                  brightness: Brightness.light,
                  automaticallyImplyLeading: false,
                  titleSpacing: 0.0,
                  elevation: 0.0,
                  title: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        child: InkWell(
                          child: CustomViews.getBackButton(),
                          onTap: () {
                            Navigator.pop(context, isPerformChnges);
                          },
                        ),
                        flex: 0,
                      ),
                      Expanded(
                        child:
                            /* isOtherCategory
                            ?  InkWell(
                                onTap: () {
                                  editCategoryDialog();
                                },
                                child:  Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                     Text(
                                      strCompetencyValue,
                                      textAlign: TextAlign.center,
                                      style:  TextStyle(
                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                          fontSize: 18.0,
                                          fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                    ),
                                    Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            5.0, 0, 7, 1),
                                        child:  Image.asset(
                                          "assets/newDesignIcon/userprofile/edit_grey.png",
                                          height: 16.0,
                                          width: 17.0,
                                        ))
                                  ],
                                ),
                              )
                            :*/
                            Text(
                          achivmentModel.level2Competency == "Other" ||
                                  achivmentModel.level2Competency == "General"
                              ? strCompetencyValue
                              : achivmentModel.level2Competency,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION,
                              fontSize: 18.0,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR),
                        ),
                        flex: 1,
                      )
                    ],
                  ),
                  actions: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              20.0,
                              0.0,
                              TextViewWrap.textView(
                                  MessageConstant.ADD_ACCOMPLISHMENT_SAVE,
                                  TextAlign.start,
                                  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                  16.0,
                                  FontWeight.normal)),
                          onTap: () {
                            FocusScope.of(context).unfocus();
                            if (isThirdLevelOther &&
                                thirdLevelController.text.length > 0) {
                              setState(() {
                                isThirLevelField = true;
                              });
                            } else {
                              setState(() {
                                isThirLevelField = false;
                              });
                            }
                            final form = _formKey.currentState;
                            if (titleController.text == "" ||
                                descController.text == "" ||
                                strCompetencyValue == "" ||
                                appliedFilter == "" ||
                                strLevelValue == "") {
                              scrollTop();
                            } else {
                              if (strCoachFirstName != "" ||
                                  strCoachLastName != "" ||
                                  strCoachEmail != "") {
                                scrollBottom();
                              }
                            }

                            setState(() {
                              /*  if (heightController.text == "") {
                                isValidHeight = false;
                              } else {
                                isValidHeight = true;
                              }*/
                              /* if (ageController.text == "") {
                                isValidAge = false;
                              } else {
                                isValidAge = true;
                              }*/
                            });
                            int count = 0;
                            mediaListData.map((v) {
                              if (v.fileDataModelList.length == 1) {
                                v.isSelectMedia = false;
                              }
                              if (!v.isSelectMedia) {
                                count++;
                              }
                            }).toList();

                            form.save();
                            if (form.validate()) {
                              if (validationCheck()) {
                                if (isThirdLevelOther &&
                                    thirdLevelController.text.length == 0) {
                                  return;
                                }
                                if (count == 0) {
                                  apiCalling();
                                }
                              }
                            } else {
                              ToastWrap.showToast(
                                  MessageConstant
                                      .ENTER_VALUE_PORTFOLIO_FIELD_VAL,
                                  context);
                            }
                          },
                        )
                      ],
                    )
                  ],
                  backgroundColor: Colors.white,
                ),
                body: Theme(
                    data: ThemeData(hintColor: Colors.grey[300]),
                    child: Stack(
                      children: <Widget>[
                        Positioned(
                            top: 0.0,
                            left: 0.0,
                            right: 0.0,
                            bottom: 0.0,
                            child: FormKeyboardActions(
                                nextFocus: false,
                                keyboardActionsPlatform:
                                    KeyboardActionsPlatform.IOS,
                                //optional
                                keyboardBarColor: Colors.grey[200],
                                //optional
                                actions: [
                                  KeyboardAction(
                                    focusNode: workinHoursFocusNode,
                                  ),
                                  KeyboardAction(
                                    focusNode: weightFocusNode,
                                  ),
                                ],
                                child: Column(
                                  children: <Widget>[
                                    CustomViews.getSepratorLine(),
                                    Expanded(
                                        child: ListView(
                                      controller: _controller,
                                      children: <Widget>[
                                        Form(
                                            key: _formKey,
                                            child: Column(
                                              children: <Widget>[
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Container(
                                                        color:
                                                            Color(0XFFFAFAFA),
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                12.0,
                                                                12.0,
                                                                12.0,
                                                                10.0,
                                                                Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      Row(
                                                                        children: [
                                                                          Expanded(
                                                                            child:
                                                                                Padding(
                                                                              padding: const EdgeInsets.fromLTRB(13.0, 0, 0, 0),
                                                                              child: isImageSelectedView(),
                                                                            ),
                                                                            flex:
                                                                                0,
                                                                          ),
                                                                          Expanded(
                                                                            child:
                                                                                Padding(
                                                                              padding: const EdgeInsets.fromLTRB(13.0, 0, 13, 0),
                                                                              child: Text(MessageConstant.ADD_PHOTO, style: TextStyle(fontSize: 12.0, color: ColorValues.GREY__COLOR, fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                                                                            ),
                                                                            flex:
                                                                                1,
                                                                          )
                                                                        ],
                                                                      ),
                                                                      Container(
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(0),
                                                                          color:
                                                                              Colors.white,
                                                                          border:
                                                                              Border.all(
                                                                            color:
                                                                                Color(0xFFFDEDEDE),
                                                                            style:
                                                                                BorderStyle.solid,
                                                                            width:
                                                                                1.0,
                                                                          ),
                                                                        ),
                                                                        child: PaddingWrap.paddingfromLTRB(
                                                                            14.0,
                                                                            0.0,
                                                                            5.0,
                                                                            10.0,
                                                                            Row(
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: <Widget>[
                                                                                Expanded(
                                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                                      0.0,
                                                                                      17.0,
                                                                                      15.0,
                                                                                      0.0,
                                                                                      Image.asset(
                                                                                        "assets/newDesignIcon/achievment/title.png",
                                                                                        width: 30.0,
                                                                                        height: 30.0,
                                                                                      )),
                                                                                  flex: 0,
                                                                                ),
                                                                                Expanded(
                                                                                  child: Column(
                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    children: <Widget>[
                                                                                      Padding(
                                                                                        padding: const EdgeInsets.fromLTRB(0.0, 13, 0, 3),
                                                                                        child: Text(
                                                                                          MessageConstant.ADD_ACCOMPLISHMENT_ABOUT_PORTFOLIO,
                                                                                          style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                        ),
                                                                                      ),
                                                                                      Text(
                                                                                        widget.level1 == "Arts" ? "Create an immersive, detailed art portfolio to showcase your talents. The more you can add the better." : "Let your talent shine. Create you detailed sports portfolio here. ",
                                                                                        style: TextStyle(color: ColorValues.GREY__COLOR, fontSize: 12.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                      ),
                                                                                      titleUi,
                                                                                      widget.level1 == "Arts"
                                                                                          ? bioUi
                                                                                          : Container(
                                                                                              height: 0.0,
                                                                                            ),
                                                                                      descriptrionUi,
                                                                                      cityUi,
                                                                                      stateUi
                                                                                    ],
                                                                                  ),
                                                                                  flex: 1,
                                                                                )
                                                                              ],
                                                                            )),
                                                                      ),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  children: <Widget>[
                                                                                    Expanded(
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          15.0,
                                                                                          15.0,
                                                                                          0.0,
                                                                                          Image.asset(
                                                                                            "assets/newDesignIcon/achievment/competency.png",
                                                                                            width: 30.0,
                                                                                            height: 30.0,
                                                                                          )),
                                                                                      flex: 0,
                                                                                    ),
                                                                                    Expanded(
                                                                                      child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: <Widget>[
                                                                                          isThirdLevelOther
                                                                                              ? Column(
                                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                  children: [
                                                                                                    PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel("Focus Area", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                                    competencyDropDownUi,
                                                                                                  ],
                                                                                                )
                                                                                              : Container(height: 0.0),
                                                                                          isThirdLevelOther
                                                                                              ? Padding(
                                                                                                  padding: const EdgeInsets.only(top: 15.0),
                                                                                                  child: Column(
                                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                                    children: [
                                                                                                      PaddingWrap.paddingfromLTRB(0.0, 0.0, 0.0, 5.0, getTextLabel("Other, please specify", 14.0, ColorValues.TEXT_LIGHT_GREY, FontWeight.normal)),
                                                                                                      Container(
                                                                                                          width: double.infinity,
                                                                                                          height: 30.0,
                                                                                                          decoration: BoxDecoration(border: Border.all(color: ColorValues.GREY__COLOR_DIVIDER)),
                                                                                                          padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                                                                          margin: EdgeInsets.all(0.0),
                                                                                                          child: TextFormField(
                                                                                                            keyboardType: TextInputType.text,
                                                                                                            controller: thirdLevelController,
                                                                                                            maxLength: 25,
                                                                                                            cursorColor: Constant.CURSOR_COLOR,
                                                                                                            style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                            textCapitalization: TextCapitalization.sentences,
                                                                                                            decoration: InputDecoration(
                                                                                                              counterText: "",
                                                                                                              disabledBorder: InputBorder.none,
                                                                                                              focusedBorder: InputBorder.none,
                                                                                                              enabledBorder: InputBorder.none,
                                                                                                              isDense: true,
                                                                                                              // Added this
                                                                                                              contentPadding: EdgeInsets.only(left: 5.0, top: 1.0, bottom: 0.0),
                                                                                                              floatingLabelBehavior: FloatingLabelBehavior.always,
                                                                                                            ),
                                                                                                          )),
                                                                                                      isThirLevelField
                                                                                                          ? Container(
                                                                                                              height: 0.0,
                                                                                                            )
                                                                                                          : PaddingWrap.paddingfromLTRB(
                                                                                                              0.0,
                                                                                                              5.0,
                                                                                                              0.0,
                                                                                                              0.0,
                                                                                                              Text(
                                                                                                                MessageConstant.THIRD_LEVEL_REQUIRED,
                                                                                                                style: TextStyle(color: ColorValues.ERROR_COLOR, fontSize: 12.0),
                                                                                                              ))
                                                                                                    ],
                                                                                                  ),
                                                                                                )
                                                                                              : isOtherCategory
                                                                                                  ? getEditCategoryTextField(false, isThirdLevelOther ? "Enter display title" : "Focus Area")
                                                                                                  : Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: [
                                                                                                        PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel("Focus Area", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                                        competencyDropDownUi,
                                                                                                      ],
                                                                                                    ),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              20.0,
                                                                                              0.0,
                                                                                              5.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: InkWell(
                                                                                                        child: TextViewWrap.textView(skillsSelectedList.length == 0 ? "Add Skills" : "Skills", TextAlign.start, skillsSelectedList.length == 0 ? ColorValues.BLUE_COLOR_BOTTOMBAR : ColorValues.GREY_TEXT_COLOR, skillsSelectedList.length == 0 ? 16.0 : 13.0, FontWeight.normal),
                                                                                                        onTap: () {
                                                                                                          if (skillsSelectedList.length == 0) selectSkillDialog();
                                                                                                        }),
                                                                                                    flex: 1,
                                                                                                  )
                                                                                                ],
                                                                                              )),
                                                                                          Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: <Widget>[
                                                                                              Expanded(
                                                                                                child: Wrap(
                                                                                                  children: _buildChoiceList(),
                                                                                                ),
                                                                                                flex: 1,
                                                                                              ),
                                                                                              Expanded(
                                                                                                child: skillsSelectedList.length == 0
                                                                                                    ? Container(
                                                                                                        height: 0.0,
                                                                                                      )
                                                                                                    : InkWell(
                                                                                                        child: Container(
                                                                                                            height: 20.0,
                                                                                                            width: 40.0,
                                                                                                            child: Icon(
                                                                                                              Icons.add,
                                                                                                              color: Colors.black,
                                                                                                              size: 20.0,
                                                                                                            )),
                                                                                                        onTap: () {
                                                                                                          selectSkillDialog();
                                                                                                        },
                                                                                                      ),
                                                                                                flex: 0,
                                                                                              )
                                                                                            ],
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                      flex: 1,
                                                                                    )
                                                                                  ],
                                                                                )),
                                                                          )),
                                                                      PaddingWrap.paddingfromLTRB(
                                                                          0.0,
                                                                          10.0,
                                                                          0.0,
                                                                          0.0,
                                                                          Container(
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              borderRadius: BorderRadius.circular(0),
                                                                              color: Colors.white,
                                                                              border: Border.all(
                                                                                color: Color(0xFFFDEDEDE),
                                                                                style: BorderStyle.solid,
                                                                                width: 1.0,
                                                                              ),
                                                                            ),
                                                                            child: PaddingWrap.paddingfromLTRB(
                                                                                14.0,
                                                                                10.0,
                                                                                5.0,
                                                                                10.0,
                                                                                Row(
                                                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                  children: <Widget>[
                                                                                    Expanded(
                                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                                          0.0,
                                                                                          15.0,
                                                                                          15.0,
                                                                                          0.0,
                                                                                          Image.asset(
                                                                                            "assets/newDesignIcon/achievment/achiewvement_level.png",
                                                                                            width: 30.0,
                                                                                            height: 30.0,
                                                                                          )),
                                                                                      flex: 0,
                                                                                    ),
                                                                                    Expanded(
                                                                                      child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: <Widget>[
                                                                                          /*skillUi,*/
                                                                                          PaddingWrap.paddingfromLTRB(0.0, 10.0, 0.0, 0.0, getTextLabel("Achievement Level", 12.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal)),
                                                                                          competencyDropLevel,
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              10.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[fromDateUi],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Container(),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[toDateUi],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                ],
                                                                                              )),
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              8.0,
                                                                                              0.0,
                                                                                              8.0,
                                                                                              Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                                                mainAxisAlignment: MainAxisAlignment.end,
                                                                                                children: <Widget>[
                                                                                                  Expanded(
                                                                                                    child: Column(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Container(),
                                                                                                    flex: 1,
                                                                                                  ),
                                                                                                  Expanded(
                                                                                                    child: Row(
                                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                                      children: <Widget>[
                                                                                                        Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Image.asset(
                                                                                                              isPresent ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                                              width: 25.0,
                                                                                                              height: 25.0,
                                                                                                            ),
                                                                                                            onTap: () {
                                                                                                              if (isPresent)
                                                                                                                isPresent = false;
                                                                                                              else
                                                                                                                isPresent = true;
                                                                                                              setState(() {
                                                                                                                isPresent;

                                                                                                                toDate = null;
                                                                                                                strToDate = "";
                                                                                                                toDateController = TextEditingController(text: "");
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0,
                                                                                                        ),
                                                                                                        Expanded(
                                                                                                          child: Container(
                                                                                                            padding: EdgeInsets.fromLTRB(5.0, 3.0, 0.0, 0.0),
                                                                                                            child: Container(child: TextViewWrap.textView("Ongoing   ", TextAlign.start, ColorValues.HEADING_COLOR_EDUCATION, 16.0, FontWeight.normal)),
                                                                                                          ),
                                                                                                          flex: 0,
                                                                                                        )
                                                                                                      ],
                                                                                                    ),
                                                                                                    flex: 6,
                                                                                                  )
                                                                                                ],
                                                                                              )),
                                                                                        ],
                                                                                      ),
                                                                                      flex: 1,
                                                                                    )
                                                                                  ],
                                                                                )),
                                                                          )),
                                                                      widget.level1 ==
                                                                              "Arts"
                                                                          ? Container(
                                                                              height: 0.0)
                                                                          : PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              10.0,
                                                                              0.0,
                                                                              0.0,
                                                                              Container(
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(0),
                                                                                  color: Colors.white,
                                                                                  border: Border.all(
                                                                                    color: Color(0xFFFDEDEDE),
                                                                                    style: BorderStyle.solid,
                                                                                    width: 1.0,
                                                                                  ),
                                                                                ),
                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                    14.0,
                                                                                    0.0,
                                                                                    5.0,
                                                                                    10.0,
                                                                                    Row(
                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                      children: <Widget>[
                                                                                        Expanded(
                                                                                          child: PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              17.0,
                                                                                              15.0,
                                                                                              0.0,
                                                                                              Image.asset(
                                                                                                "assets/portfolio/trainer.png",
                                                                                                width: 30.0,
                                                                                                height: 30.0,
                                                                                              )),
                                                                                          flex: 0,
                                                                                        ),
                                                                                        Expanded(
                                                                                          child: Column(
                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: <Widget>[
                                                                                              Padding(
                                                                                                padding: const EdgeInsets.fromLTRB(0.0, 13, 0, 3),
                                                                                                child: Text(
                                                                                                  MessageConstant.ADD_ACCOMPLISHMENT_ATHLETIC_INFORMATION,
                                                                                                  style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                ),
                                                                                              ),
                                                                                              Text(
                                                                                                MessageConstant.ADD_ACCOMPLISHMENT_SHARE_YOUR_ATHLETIC,
                                                                                                style: TextStyle(color: ColorValues.GREY__COLOR, fontSize: 12.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                              ),
                                                                                              PaddingWrap.paddingfromLTRB(
                                                                                                  0.0,
                                                                                                  10.0,
                                                                                                  0.0,
                                                                                                  0.0,
                                                                                                  Row(
                                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                                    children: <Widget>[
                                                                                                      Expanded(
                                                                                                        child: Column(
                                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                                          children: <Widget>[heightUi],
                                                                                                        ),
                                                                                                        flex: 1,
                                                                                                      ),
                                                                                                      Expanded(
                                                                                                        child: Column(
                                                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                                          children: <Widget>[weightUi],
                                                                                                        ),
                                                                                                        flex: 1,
                                                                                                      ),
                                                                                                    ],
                                                                                                  )),
                                                                                              ageSelectionUi,
                                                                                              stateWidget()
                                                                                            ],
                                                                                          ),
                                                                                          flex: 1,
                                                                                        )
                                                                                      ],
                                                                                    )),
                                                                              )),
                                                                      widget.level1 ==
                                                                              "Arts"
                                                                          ? Container(
                                                                              height: 0.0)
                                                                          : PaddingWrap.paddingfromLTRB(
                                                                              0.0,
                                                                              10.0,
                                                                              0.0,
                                                                              0.0,
                                                                              Container(
                                                                                decoration: BoxDecoration(
                                                                                  borderRadius: BorderRadius.circular(0),
                                                                                  color: Colors.white,
                                                                                  border: Border.all(
                                                                                    color: Color(0xFFFDEDEDE),
                                                                                    style: BorderStyle.solid,
                                                                                    width: 1.0,
                                                                                  ),
                                                                                ),
                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                    14.0,
                                                                                    0.0,
                                                                                    5.0,
                                                                                    10.0,
                                                                                    Row(
                                                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                      children: <Widget>[
                                                                                        Expanded(
                                                                                          child: PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              17.0,
                                                                                              15.0,
                                                                                              0.0,
                                                                                              Image.asset(
                                                                                                "assets/portfolio/team.png",
                                                                                                width: 30.0,
                                                                                                height: 30.0,
                                                                                              )),
                                                                                          flex: 0,
                                                                                        ),
                                                                                        Expanded(
                                                                                          child: Column(
                                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: <Widget>[
                                                                                              Padding(
                                                                                                padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 3),
                                                                                                child: Text(
                                                                                                  MessageConstant.ADD_ACCOMPLISHMENT_SELECT_TEAM,
                                                                                                  style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                ),
                                                                                              ),
                                                                                              Padding(
                                                                                                  padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 15),
                                                                                                  child: Text(
                                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_ADD_DETAILLS_ABOUT_TEAM,
                                                                                                    style: TextStyle(color: ColorValues.GREY__COLOR, fontSize: 12.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                  )),
                                                                                              Row(
                                                                                                children: <Widget>[
                                                                                                  isClubTeam
                                                                                                      ? Expanded(
                                                                                                          child: InkWell(
                                                                                                              onTap: () {
                                                                                                                setState(() {
                                                                                                                  isClubTeam = false;
                                                                                                                  clubTeamList.clear();
                                                                                                                });
                                                                                                              },
                                                                                                              child: Padding(
                                                                                                                  padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                  child: Image.asset(
                                                                                                                    "assets/newDesignIcon/navigation/check.png",
                                                                                                                    height: 20.0,
                                                                                                                    width: 20.0,
                                                                                                                  ))),
                                                                                                          flex: 0)
                                                                                                      : Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Padding(
                                                                                                                padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                child: Image.asset(
                                                                                                                  "assets/newDesignIcon/navigation/uncheck.png",
                                                                                                                  height: 20.0,
                                                                                                                  width: 20.0,
                                                                                                                )),
                                                                                                            onTap: () {
                                                                                                              setState(() {
                                                                                                                isClubTeam = true;
                                                                                                                clubTeamList.add(ClubTeamModel(
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                ));
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0),
                                                                                                  Expanded(
                                                                                                      child: Text(
                                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_CLUB_TEAM,
                                                                                                    maxLines: 1,
                                                                                                    style: TextStyle(fontSize: 16.0, color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                                                                  )),
                                                                                                ],
                                                                                              ),
                                                                                              Container(
                                                                                                height: 7.0,
                                                                                              ),
                                                                                              clubTeamWidget(),
                                                                                              Row(
                                                                                                children: <Widget>[
                                                                                                  isHighSchoolTeam
                                                                                                      ? Expanded(
                                                                                                          child: InkWell(
                                                                                                              onTap: () {
                                                                                                                setState(() {
                                                                                                                  isHighSchoolTeam = false;
                                                                                                                  highSchoolTeamList.clear();
                                                                                                                });
                                                                                                              },
                                                                                                              child: Padding(
                                                                                                                  padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                  child: Image.asset(
                                                                                                                    "assets/newDesignIcon/navigation/check.png",
                                                                                                                    height: 20.0,
                                                                                                                    width: 20.0,
                                                                                                                  ))),
                                                                                                          flex: 0)
                                                                                                      : Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Padding(
                                                                                                                padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                child: Image.asset(
                                                                                                                  "assets/newDesignIcon/navigation/uncheck.png",
                                                                                                                  height: 20.0,
                                                                                                                  width: 20.0,
                                                                                                                )),
                                                                                                            onTap: () {
                                                                                                              setState(() {
                                                                                                                isHighSchoolTeam = true;
                                                                                                                highSchoolTeamList.add(ClubTeamModel(
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                ));
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0),
                                                                                                  Expanded(
                                                                                                      child: Text(
                                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_HIGH_SCHOOL_TEAM,
                                                                                                    maxLines: 1,
                                                                                                    style: TextStyle(fontSize: 16.0, color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                                                                  )),
                                                                                                ],
                                                                                              ),
                                                                                              Container(
                                                                                                height: 7.0,
                                                                                              ),
                                                                                              highSchoolTeamWidget(),
                                                                                              Row(
                                                                                                children: <Widget>[
                                                                                                  isCollegeTeam
                                                                                                      ? Expanded(
                                                                                                          child: InkWell(
                                                                                                              onTap: () {
                                                                                                                setState(() {
                                                                                                                  isCollegeTeam = false;
                                                                                                                  collegeTeamList.clear();
                                                                                                                });
                                                                                                              },
                                                                                                              child: Padding(
                                                                                                                  padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                  child: Image.asset(
                                                                                                                    "assets/newDesignIcon/navigation/check.png",
                                                                                                                    height: 20.0,
                                                                                                                    width: 20.0,
                                                                                                                  ))),
                                                                                                          flex: 0)
                                                                                                      : Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Padding(
                                                                                                                padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                child: Image.asset(
                                                                                                                  "assets/newDesignIcon/navigation/uncheck.png",
                                                                                                                  height: 20.0,
                                                                                                                  width: 20.0,
                                                                                                                )),
                                                                                                            onTap: () {
                                                                                                              setState(() {
                                                                                                                isCollegeTeam = true;

                                                                                                                collegeTeamList.add(ClubTeamModel(
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                ));
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0),
                                                                                                  Expanded(
                                                                                                      child: Text(
                                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_COLLEGE_TEAM,
                                                                                                    maxLines: 1,
                                                                                                    style: TextStyle(fontSize: 16.0, color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                                                                  )),
                                                                                                ],
                                                                                              ),
                                                                                              Container(
                                                                                                height: 7.0,
                                                                                              ),
                                                                                              collegeTeamWidget(),
                                                                                              Row(
                                                                                                children: <Widget>[
                                                                                                  isOtherTeam
                                                                                                      ? Expanded(
                                                                                                          child: InkWell(
                                                                                                              onTap: () {
                                                                                                                setState(() {
                                                                                                                  isOtherTeam = false;
                                                                                                                  otherTeamList.clear();
                                                                                                                });
                                                                                                              },
                                                                                                              child: Padding(
                                                                                                                  padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                  child: Image.asset(
                                                                                                                    "assets/newDesignIcon/navigation/check.png",
                                                                                                                    height: 20.0,
                                                                                                                    width: 20.0,
                                                                                                                  ))),
                                                                                                          flex: 0)
                                                                                                      : Expanded(
                                                                                                          child: InkWell(
                                                                                                            child: Padding(
                                                                                                                padding: EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                                                                                                child: Image.asset(
                                                                                                                  "assets/newDesignIcon/navigation/uncheck.png",
                                                                                                                  height: 20.0,
                                                                                                                  width: 20.0,
                                                                                                                )),
                                                                                                            onTap: () {
                                                                                                              setState(() {
                                                                                                                isOtherTeam = true;

                                                                                                                otherTeamList.add(ClubTeamModel(
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                  TextEditingController(text: ""),
                                                                                                                ));
                                                                                                              });
                                                                                                            },
                                                                                                          ),
                                                                                                          flex: 0),
                                                                                                  Expanded(
                                                                                                      child: Text(
                                                                                                    "Other Team(s)",
                                                                                                    maxLines: 1,
                                                                                                    style: TextStyle(fontSize: 16.0, color: ColorValues.HEADING_COLOR_EDUCATION, fontFamily: Constant.TYPE_CUSTOMBOLD),
                                                                                                  )),
                                                                                                ],
                                                                                              ),
                                                                                              Container(
                                                                                                height: 7.0,
                                                                                              ),
                                                                                              otherTeamWidget()
                                                                                            ],
                                                                                          ),
                                                                                          flex: 1,
                                                                                        )
                                                                                      ],
                                                                                    )),
                                                                              )),
                                                                      UIHelper
                                                                          .verticalGapBetweenBox,
                                                                      mediaWidget(),
                                                                      UIHelper
                                                                          .verticalGapBetweenBox,
                                                                      externalLinkWidget(),
                                                                      UIHelper
                                                                          .verticalGapBetweenBox,
                                                                      personalReflectionWidget(),
                                                                    ]))),
                                                    Container(
                                                        color:
                                                            Color(0XFFFAFAFA),
                                                        child: PaddingWrap
                                                            .paddingfromLTRB(
                                                                0.0,
                                                                7.0,
                                                                0.0,
                                                                10.0,
                                                                Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: <
                                                                        Widget>[
                                                                      isPromptfinal
                                                                          ? PaddingWrap.paddingfromLTRB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              10.0,
                                                                              Row(
                                                                                children: <Widget>[
                                                                                  PaddingWrap.paddingAll(
                                                                                      0.0,
                                                                                      InkWell(
                                                                                        child: Image.asset(
                                                                                          "assets/newDesignIcon/login/check.png",
                                                                                          width: 25.0,
                                                                                          height: 25.0,
                                                                                        ),
                                                                                        onTap: () {},
                                                                                      )),
                                                                                  Text(
                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_ASK_RECOMMENDATION,
                                                                                    style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                  ),
                                                                                ],
                                                                              ))
                                                                          : PaddingWrap.paddingfromLTRB(
                                                                              16.0,
                                                                              0.0,
                                                                              16.0,
                                                                              10.0,
                                                                              Row(
                                                                                children: <Widget>[
                                                                                  PaddingWrap.paddingAll(
                                                                                      0.0,
                                                                                      PaddingWrap.paddingAll(
                                                                                          0.0,
                                                                                          InkWell(
                                                                                            child: Image.asset(
                                                                                              isPrompt ? "assets/newDesignIcon/login/check.png" : "assets/newDesignIcon/login/uncheck.png",
                                                                                              width: 25.0,
                                                                                              height: 25.0,
                                                                                            ),
                                                                                            onTap: () {
                                                                                              if (prefs.getString(UserPreference.ISACTIVE) == "true") {
                                                                                                if (isPrompt)
                                                                                                  isPrompt = false;
                                                                                                else
                                                                                                  isPrompt = true;
                                                                                                setState(() {
                                                                                                  isPrompt;
                                                                                                });
                                                                                              } else {
                                                                                                ToastWrap.showToast(MessageConstant.PENDING_PROFILE_ACTIVATION_BY_PARENT_ERROR, context);
                                                                                              }
                                                                                            },
                                                                                          ))),
                                                                                  Text(
                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_ASK_RECOMMENDATION,
                                                                                    style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 16.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                  ),
                                                                                ],
                                                                              )),
                                                                      isPrompt
                                                                          ? Card(
                                                                              elevation: 0.0,
                                                                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0.0)),
                                                                              child: Container(
                                                                                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: ColorValues.LIGHT_GREY_TEXT_COLOR, width: 1.0), top: BorderSide(color: ColorValues.LIGHT_GREY_TEXT_COLOR, width: 1.0))),
                                                                                  child: PaddingWrap.paddingfromLTRB(
                                                                                      16.0,
                                                                                      0.0,
                                                                                      16.0,
                                                                                      0.0,
                                                                                      Column(
                                                                                        children: <Widget>[
                                                                                          recommendationTitle,
                                                                                          recommendationRequest,
                                                                                          PaddingWrap.paddingfromLTRB(
                                                                                              0.0,
                                                                                              15.0,
                                                                                              0.0,
                                                                                              0.0,
                                                                                              Container(
                                                                                                  padding: EdgeInsets.all(5.0),
                                                                                                  color: Color(0XFFE9E9E9),
                                                                                                  width: double.infinity,
                                                                                                  child: Text(
                                                                                                    MessageConstant.ADD_ACCOMPLISHMENT_RECOMMENDER_DETAILS,
                                                                                                    style: TextStyle(color: ColorValues.HEADING_COLOR_EDUCATION, fontSize: 12.0, fontFamily: Constant.TYPE_CUSTOMREGULAR),
                                                                                                  ))),
                                                                                          recommenderTitle,
                                                                                          coachFirstName,
                                                                                          coachLastName,
                                                                                          coachEmail,
                                                                                        ],
                                                                                      ))))
                                                                          : Container(
                                                                              height: 0.0,
                                                                            )
                                                                    ]))),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Container(
                                                            width:
                                                                double.infinity,
                                                            child: InkWell(
                                                                child: PaddingWrap
                                                                    .paddingfromLTRB(
                                                                        20.0,
                                                                        16.0,
                                                                        16.0,
                                                                        50.0,
                                                                        InkWell(
                                                                          child: TextViewWrap.textView(
                                                                              "Delete Portfolio",
                                                                              TextAlign.start,
                                                                              ColorValues.RED,
                                                                              16.0,
                                                                              FontWeight.normal),
                                                                          onTap:
                                                                              () {
                                                                            confromationDialog();
                                                                          },
                                                                        )))),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ))
                                      ],
                                    ))
                                  ],
                                ))),
                      ],
                    )))));
  }

  uploadMediaServer(index, filePath, imagePath, type) async {
    strAzureImageUploadPath = await uploadImgOnAzure(
        filePath.toString().replaceAll("File: ", "").replaceAll("'", "").trim(),
        strPrefixPathforPhoto);
    setState(() {
      strAzureImageUploadPath;
    });
    final thumbnailFile = await uploadMedia.getVideoThumbnailFromUrl(filePath);
    CustomProgressLoader.cancelLoader(context);
    uploadMediaCount++;
    mediaListData[index].fileDataModelList.add(new FileDataModel(
        type: type,
        filePath: strPrefixPathforPhoto + strAzureImageUploadPath,
        thumbnailFile: thumbnailFile,
        imagePath: imagePath));
    setState(() {});
  }

  Future getImage(int index, type, context) async {
    imagePath = null;
    if (type == "video") {
      imagePath = await uploadMedia.pickVideoFromGallery();
    } else {
      imagePath = await UploadMedia(context).pickImageFromGallery();

    //  imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
    }
    if (imagePath != null && imagePath != "") {
      String strPath = imagePath
          .toString()
          .replaceAll("File: ", "")
          .replaceAll("'", "")
          .trim();
      print("imagepath shubh" + strPath);
      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        try {
          CustomProgressLoader.showLoader(context);
          if (type == "video") {
            /* File file =
          await uploadMedia.compresssData(new File(strPath), true, type);
          imagePath = file;*/
            File file =
                await uploadMedia.compresssData(new File(strPath), true, type);
            strPath = file.path;

            mediaListData[index].type = "video";
            mediaListData[index].isSelectMedia = true;
          } else if (type == "image") {
            File file = await uploadMedia.compressImage(new File(strPath));
            imagePath = file;
            mediaListData[index].type = "image";
            mediaListData[index].isSelectMedia = true;
          }
          // strPath = imagePath
          //     .toString()
          //     .replaceAll("File: ", "")
          //     .replaceAll("'", "")
          //     .trim();
          if (imagePath != null) {
            /*setState(() {
          isMedaiDialog = true;
        });
        addMediaDialog();*/
            setState(() {
              imagePath;
            });
            Timer _timer = Timer(const Duration(milliseconds: 400), () {
              uploadMediaServer(index, strPath, imagePath, type);
            });
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "EditPortFolio", context);
          CustomProgressLoader.cancelLoader(context);
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  externalLinkWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          14.0,
          10.0,
          5.0,
          10.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/story_new/link_url.png",
                      width: 30.0,
                      height: 30.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        TextViewWrap.textView(
                            MessageConstant.ADD_ACCOMPLISHMENT_EXERNAL_LINKS,
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            MessageConstant
                                .ADD_ACCOMPLISHMENT_UPLOAD_PRESS_COVERAGE,
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    UIHelper.verticalGapBetweenBox,

                    //////////////////////////////////
                    Container(
                      child: ListView.builder(
                        itemCount: linkUrlListData.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                            child: Container(
                              //color: ColorValues.BLUE_COLOR,
                              //padding: EdgeInsets.only(top: 10,),

                              margin:
                                  EdgeInsets.only(top: 0, bottom: 0, right: 0),
                              child: Stack(
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 5, 0),
                                    child: Container(
                                      color: ColorValues.SELECTION_GRAY,
                                      margin: EdgeInsets.only(top: 0, right: 0),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            13.0, 5, 13, 5),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Expanded(
                                              child: Column(
                                                children: <Widget>[
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: 0,
                                                      top: 0,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .labelController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              MessageConstant
                                                                  .ADD_ACCOMPLISHMENT_TITLE),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (val) => linkUrlListData[
                                                                          index]
                                                                      .labelController
                                                                      .text ==
                                                                  "" &&
                                                              linkUrlListData[
                                                                          index]
                                                                      .urlController
                                                                      .text ==
                                                                  ""
                                                          ? null
                                                          : val.trim().isEmpty
                                                              ? MessageConstant
                                                                  .FIELD_REQUIRED
                                                              : null,
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .urlController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              'URL'),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      validator: (value) {
                                                        return linkUrlListData[
                                                                            index]
                                                                        .labelController
                                                                        .text ==
                                                                    "" &&
                                                                linkUrlListData[
                                                                            index]
                                                                        .urlController
                                                                        .text ==
                                                                    ""
                                                            ? null
                                                            : ValidationChecks
                                                                .validateWebUrlPortFolio(
                                                                    value);
                                                      },
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      bottom: UIHelper
                                                          .screenPadding,
                                                      top: 5,
                                                    ),
                                                    child: TextFormField(
                                                      controller:
                                                          linkUrlListData[index]
                                                              .descController,
                                                      //controller: timeFrom,
                                                      //controller: timeFromController,
                                                      //enabled: false,
                                                      decoration:
                                                          textFormFieldDecorationWithLabel(
                                                              MessageConstant
                                                                  .ADD_ACCOMPLISHMENT_DESCRIPTION),
                                                      style:
                                                          textFormFieldValueStyle(),
                                                      onFieldSubmitted:
                                                          (term) {},
                                                      /*validator: (value) {
                                    return ValidationChecks
                                        .validateDescription(value);
                                },*/
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    right: 0.0,
                                    top: 0.0,
                                    child: InkWell(
                                      child: index > 0
                                          ? Container(
                                              padding: EdgeInsets.all(0),
                                              child: Image.asset(
                                                ImagePath.ICON_CLEAR,
                                                height: 24.18,
                                                width: 17,
                                              ),
                                            )
                                          : Container(
                                              height: 24.18,
                                              width: 17,
                                            ),
                                      onTap: () {
                                        if (linkUrlListData.length > 1) {
                                          print(
                                              'link Index is =======>  $index');
                                          linkUrlListData.removeAt(index);
                                        }
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    ////////////////////////////
                    InkWell(
                      child: Padding(
                        padding:
                            EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
                        child: Text(
                          '+ Add More Link'.toUpperCase(),
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.accentColor, 14, FontType.Regular),
                        ),
                      ),
                      onTap: () {
                        if (linkUrlListData.length > 0) {
                          if (linkUrlListData[linkUrlListData.length - 1]
                                      .urlController
                                      .text !=
                                  "" &&
                              linkUrlListData[linkUrlListData.length - 1]
                                      .labelController
                                      .text !=
                                  "") {
                            setState(() {
                              linkUrlListData.add(LinkUrlDataModel(
                                TextEditingController(text: ""),
                                TextEditingController(text: ""),
                                TextEditingController(text: ""),
                              ));
                            });
                          }
                        } else {
                          setState(() {
                            linkUrlListData.add(LinkUrlDataModel(
                              TextEditingController(text: ""),
                              TextEditingController(text: ""),
                              TextEditingController(text: ""),
                            ));
                          });
                        }
                      },
                    ),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  void conformationDialog(index, model) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    MessageConstant.REMOVE_NAME,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.CANCEL,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              MessageConstant.REMOVE,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              uploadMediaCount--;
                                              Navigator.pop(context);
                                              mediaListData[index]
                                                  .fileDataModelList
                                                  .remove(model);
                                              setState(() {
                                                if (mediaListData[index]
                                                        .fileDataModelList
                                                        .length ==
                                                    1) {
                                                  mediaListData[index].type =
                                                      "";
                                                }
                                                mediaListData[index]
                                                    .fileDataModelList;
                                              });
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  getImageAndVideoFile(index, type) {
    return Container(
      child: GridView.count(
          primary: false,
          shrinkWrap: true,
          padding: const EdgeInsets.all(0.0),
          crossAxisSpacing: 10.0,
          childAspectRatio: 1.50,
          scrollDirection: Axis.vertical,
          crossAxisCount: 3,
          children: List.generate(mediaListData[index].fileDataModelList.length,
              (int index1) {
            return mediaListData[index].fileDataModelList[index1].filePath == ""
                ? Stack(children: <Widget>[
                    InkWell(
                      child: Container(
                          height: 54.0,
                          width: 80.0,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: ColorValues.LIGHT_GREY_TEXT_COLOR)),
                          child: Image.asset(
                            "assets/portfolio/add_white.png",
                            height: 25.0,
                            width: 25.0,
                          )),
                      onTap: () async {
                        if (mediaListData[index].type == "video" &&
                            mediaListData[index].fileDataModelList.length ==
                                2) {
                          ToastWrap.showToast(
                              MessageConstant.MAXIMUM_1_VIDEO_UPLOADED_VAL,
                              context);
                        } else {
                          if (uploadMediaCount <
                              TextLength.PORTFOLIO_FILE_MAX_LENGTH) {
                            var status = await Permission.photos.status;
                            if (status.isGranted) {
                              getImage(index, type, context);
                            } else {
                              checkPermissionPhoto(context);
                            }
                          } else {
                            ToastWrap.showToast(
                                MessageConstant.MAXIMUM_100_IMAGE_UPLOADED_VAL,
                                context);
                          }
                        }
                      },
                    )
                  ])
                : Container(
                    child: Stack(
                    children: <Widget>[
                      type == "image"
                          ? FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: 'assets/aerial/default_img.png',
                              image: Constant.IMAGE_PATH +
                                  mediaListData[index]
                                      .fileDataModelList[index1]
                                      .filePath,
                              height: 54.0,
                              width: 80.0,
                            )
                          : mediaListData[index].type == "video"
                              ? mediaListData[index]
                                          .fileDataModelList[0]
                                          .thumbnailFile ==
                                      null
                                  ? Container(
                                      height: 54.0,
                                      width: 80.0,
                                      decoration: rectangleDecoration(),
                                      margin:
                                          EdgeInsets.only(left: 0, right: 0),
                                      child: VideoPlayPause(
                                        mediaListData[index]
                                            .fileDataModelList[index1]
                                            .filePath,
                                        "",
                                        false,
                                      ),
                                    )
                                  : Container(
                                      height: 54.0,
                                      width: 80.0,
                                      decoration: rectangleDecoration(),
                                      margin:
                                          EdgeInsets.only(left: 0, right: 0),
                                      child: Image.file(
                                        mediaListData[index]
                                            .fileDataModelList[index1]
                                            .thumbnailFile,
                                        fit: BoxFit.contain,
                                      ),
                                    )
                              : Container(
                                  height: 0.0,
                                ),
                      Container(
                        height: 54.0,
                        width: 80.0,
                        color: Color(0XFFC0C0C0).withOpacity(.4),
                      ),
                      Container(
                          height: 54.0,
                          width: 80.0,
                          child: Center(
                              child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              InkWell(
                                  child: PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      0.0,
                                      0.0,
                                      0.0,
                                      Image.asset(
                                        "assets/newDesignIcon/achievment/remove.png",
                                        width: 35.0,
                                        height: 35.0,
                                      )),
                                  onTap: () {
                                    conformationDialog(
                                        index,
                                        mediaListData[index]
                                            .fileDataModelList[index1]);
                                  })
                            ],
                          ))),
                    ],
                  ));
          })),
    );
  }

  mediaWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          14.0,
          10.0,
          5.0,
          10.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/portfolio/media.png",
                      width: 30.0,
                      height: 30.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        TextViewWrap.textView(
                            "Upload Media",
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            MessageConstant.MEDIA_TEXT_PORTFOLIO,
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    UIHelper.verticalGapBetweenBox,

                    //////////////////////////////////
                    ListView.builder(
                      itemCount: mediaListData.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
                          child: Container(
                            //color: ColorValues.BLUE_COLOR,
                            //padding: EdgeInsets.only(top: 10,),

                            margin:
                                EdgeInsets.only(top: 0, bottom: 0, right: 0),
                            child: Stack(
                              children: <Widget>[
                                Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        0.0, 10, 5, 0),
                                    child: Container(
                                        color: ColorValues.SELECTION_GRAY,
                                        margin:
                                            EdgeInsets.only(top: 0, right: 0),
                                        child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                13.0, 5, 13, 5),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                mediaListData[index].type ==
                                                            "video" ||
                                                        mediaListData[index]
                                                                .type ==
                                                            "link"
                                                    ? Container(
                                                        height: 0.0,
                                                      )
                                                    : Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  12.0,
                                                                  0.0,
                                                                  10.0,
                                                                  Text(
                                                                    "Photos",
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .GREY_TEXT_COLOR,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                          getImageAndVideoFile(
                                                              index, "image"),
                                                        ],
                                                      ),
                                                mediaListData[index].type ==
                                                            "image" ||
                                                        mediaListData[index]
                                                                .type ==
                                                            "link"
                                                    ? Container(
                                                        height: 0.0,
                                                      )
                                                    : Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          PaddingWrap
                                                              .paddingfromLTRB(
                                                                  0.0,
                                                                  12.0,
                                                                  0.0,
                                                                  10.0,
                                                                  Text(
                                                                    "Video",
                                                                    style: TextStyle(
                                                                        color: ColorValues
                                                                            .GREY_TEXT_COLOR,
                                                                        fontSize:
                                                                            14.0,
                                                                        fontFamily:
                                                                            Constant.TYPE_CUSTOMREGULAR),
                                                                  )),
                                                          mediaListData[index]
                                                                      .type ==
                                                                  "video"
                                                              ? Stack(
                                                                  children: <
                                                                      Widget>[
                                                                    mediaListData[index].fileDataModelList.length ==
                                                                            1
                                                                        ? Image
                                                                            .asset(
                                                                            'assets/aerial/default_img.png',
                                                                            height:
                                                                                54.0,
                                                                            width:
                                                                                80.0,
                                                                          )
                                                                        : mediaListData[index].fileDataModelList[0].thumbnailFile ==
                                                                                null
                                                                            ? Container(
                                                                                height: 54.0,
                                                                                width: 80.0,
                                                                                decoration: rectangleDecoration(),
                                                                                margin: EdgeInsets.only(left: 0, right: 0),
                                                                                child: VideoPlayPause(
                                                                                  mediaListData[index].fileDataModelList[1].filePath,
                                                                                  "",
                                                                                  false,
                                                                                ),
                                                                              )
                                                                            : Container(
                                                                                height: 54.0,
                                                                                width: 80.0,
                                                                                decoration: rectangleDecoration(),
                                                                                margin: EdgeInsets.only(left: 0, right: 0),
                                                                                child: Image.file(
                                                                                  mediaListData[index].fileDataModelList[1].thumbnailFile,
                                                                                  fit: BoxFit.contain,
                                                                                ),
                                                                              ),
                                                                    Container(
                                                                      height:
                                                                          54.0,
                                                                      width:
                                                                          80.0,
                                                                      color: Color(
                                                                              0XFFC0C0C0)
                                                                          .withOpacity(
                                                                              .4),
                                                                    ),
                                                                    Container(
                                                                        height:
                                                                            54.0,
                                                                        width:
                                                                            80.0,
                                                                        child: Center(
                                                                            child: Row(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.center,
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.center,
                                                                          children: <
                                                                              Widget>[
                                                                            InkWell(
                                                                                child: PaddingWrap.paddingfromLTRB(
                                                                                    0.0,
                                                                                    0.0,
                                                                                    0.0,
                                                                                    0.0,
                                                                                    Image.asset(
                                                                                      "assets/newDesignIcon/achievment/remove.png",
                                                                                      width: 35.0,
                                                                                      height: 35.0,
                                                                                    )),
                                                                                onTap: () {
                                                                                  conformationDialog(index, mediaListData[index].fileDataModelList[1]);
                                                                                })
                                                                          ],
                                                                        ))),
                                                                  ],
                                                                )
                                                              : getImageAndVideoFile(
                                                                  index,
                                                                  "video"),
                                                        ],
                                                      ),
                                                mediaListData[index].type ==
                                                            "video" ||
                                                        mediaListData[index]
                                                                .type ==
                                                            "image" ||
                                                        mediaListData[index]
                                                                .type ==
                                                            "link"
                                                    ? Container(
                                                        height: 0.0,
                                                      )
                                                    : Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                            PaddingWrap
                                                                .paddingfromLTRB(
                                                                    0.0,
                                                                    12.0,
                                                                    0.0,
                                                                    10.0,
                                                                    Text(
                                                                      "Paste Link URL",
                                                                      style: TextStyle(
                                                                          color: ColorValues
                                                                              .GREY_TEXT_COLOR,
                                                                          fontSize:
                                                                              14.0,
                                                                          fontFamily:
                                                                              Constant.TYPE_CUSTOMREGULAR),
                                                                    )),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      0.0,
                                                                      0,
                                                                      13,
                                                                      13),
                                                              child: Container(
                                                                decoration: BoxDecoration(
                                                                    color: Colors
                                                                        .white,
                                                                    border: Border.all(
                                                                        color: ColorValues
                                                                            .BORDER_COLOR,
                                                                        width:
                                                                            0.5)),
                                                                child: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          5.0,
                                                                          0.0,
                                                                          0.0,
                                                                          0.0,
                                                                          TextFormField(
                                                                            maxLines:
                                                                                2,
                                                                            minLines:
                                                                                1,
                                                                            maxLength:
                                                                                200,
                                                                            keyboardType:
                                                                                TextInputType.text,
                                                                            style:
                                                                                TextStyle(fontFamily: Constant.customRegular),
                                                                            decoration:
                                                                                InputDecoration(
                                                                              hintText: "",
                                                                              hintStyle: TextStyle(color: ColorValues.GREY_TEXT_COLOR, fontSize: 14.0, fontFamily: Constant.customRegular),
                                                                              counterText: "",
                                                                              errorStyle: TextStyle(fontFamily: Constant.customRegular),
                                                                              labelStyle: TextStyle(fontFamily: Constant.customRegular),
                                                                              border: InputBorder.none,
                                                                            ),
                                                                            controller:
                                                                                mediaListData[0].fileDataModelList[0].linkController,
                                                                          )),
                                                                      flex: 1,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets.fromLTRB(
                                                                            0.0,
                                                                            0,
                                                                            0,
                                                                            0),
                                                                        child:
                                                                            Container(
                                                                          width:
                                                                              1.0,
                                                                          height:
                                                                              35.0,
                                                                          color:
                                                                              ColorValues.BORDER_COLOR,
                                                                        ),
                                                                      ),
                                                                      flex: 0,
                                                                    ),
                                                                    Expanded(
                                                                      child: PaddingWrap.paddingfromLTRB(
                                                                          12.0,
                                                                          0.0,
                                                                          12.0,
                                                                          0.0,
                                                                          InkWell(
                                                                            onTap:
                                                                                () {
                                                                              String data = ValidationChecks.validateWebUrlPortFolio(mediaListData[0].fileDataModelList[0].linkController.text);
                                                                              if (data == null) {
                                                                                mediaListData[index].type = "link";
                                                                                mediaListData[index].isSelectMedia = true;
                                                                                mediaListData[index].fileDataModelList.add(new FileDataModel(type: "link", filePath: mediaListData[0].fileDataModelList[0].linkController.text, thumbnailFile: null, imagePath: null));
                                                                                mediaListData[0].fileDataModelList[0].linkController.text = "";
                                                                                setState(() {});
                                                                              } else {
                                                                                ToastWrap.showToast(data, context);
                                                                              }
                                                                            },
                                                                            child: TextViewWrap.textViewMultiLine(
                                                                                "ADD",
                                                                                TextAlign.start,
                                                                                ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                                                14.0,
                                                                                FontWeight.normal,
                                                                                1),
                                                                          )),
                                                                      flex: 0,
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          ]),
                                                mediaListData[index].type ==
                                                        "link"
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                0.0,
                                                                15,
                                                                13,
                                                                13),
                                                        child: Container(
                                                            decoration: BoxDecoration(
                                                                color:
                                                                    Colors
                                                                        .white,
                                                                border: Border.all(
                                                                    color: ColorValues
                                                                        .BORDER_COLOR,
                                                                    width:
                                                                        0.5)),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      20.0,
                                                                      8,
                                                                      20,
                                                                      8),
                                                              child: Row(
                                                                children: [
                                                                  Expanded(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          const EdgeInsets.fromLTRB(
                                                                              0,
                                                                              0,
                                                                              10,
                                                                              0),
                                                                      child:
                                                                          Text(
                                                                        mediaListData[index]
                                                                            .fileDataModelList[1]
                                                                            .filePath,
                                                                        maxLines:
                                                                            1,
                                                                        overflow:
                                                                            TextOverflow.ellipsis,
                                                                        style: TextStyle(
                                                                            color: ColorValues
                                                                                .HEADING_COLOR_EDUCATION,
                                                                            fontSize:
                                                                                14.0,
                                                                            fontFamily:
                                                                                Constant.TYPE_CUSTOMREGULAR),
                                                                      ),
                                                                    ),
                                                                    flex: mediaListData[index].fileDataModelList[1].filePath.length <
                                                                            25
                                                                        ? 0
                                                                        : 1,
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        InkWell(
                                                                      child:
                                                                          Container(
                                                                        padding:
                                                                            EdgeInsets.all(0),
                                                                        child: Image
                                                                            .asset(
                                                                          ImagePath
                                                                              .ICON_CLEAR,
                                                                          height:
                                                                              24.18,
                                                                          width:
                                                                              17,
                                                                        ),
                                                                      ),
                                                                      onTap:
                                                                          () {
                                                                        mediaListData[index]
                                                                            .fileDataModelList
                                                                            .removeLast();
                                                                        mediaListData[index].type =
                                                                            "";
                                                                        mediaListData[index].isSelectMedia =
                                                                            true;

                                                                        setState(
                                                                            () {});
                                                                      },
                                                                    ),
                                                                    flex: 0,
                                                                  ),
                                                                ],
                                                              ),
                                                            )))
                                                    : Container(height: 0),
                                                mediaListData[index]
                                                        .isSelectMedia
                                                    ? Container(
                                                        height: 0.0,
                                                      )
                                                    : Text(
                                                        "At least one media is required.",
                                                        textAlign:
                                                            TextAlign.start,
                                                        style: TextStyle(
                                                            color: Palette
                                                                .redColor,
                                                            fontSize: 14,
                                                            fontFamily: Constant
                                                                .TYPE_CUSTOMREGULAR),
                                                      ),
                                                mediaListData[index]
                                                            .isSelectMedia &&
                                                        mediaListData[index]
                                                                .type !=
                                                            null &&
                                                        mediaListData[index]
                                                                .type !=
                                                            ""
                                                    ? Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                              top: 5,
                                                            ),
                                                            child:
                                                                TextFormField(
                                                              controller:
                                                                  mediaListData[
                                                                          index]
                                                                      .labelController,
                                                              //controller: timeFrom,
                                                              //controller: timeFromController,
                                                              //enabled: false,
                                                              decoration:
                                                                  textFormFieldDecorationWithLabel(
                                                                      'Title',
                                                                      hintText:
                                                                          ""),
                                                              style:
                                                                  textFormFieldValueStyle(),
                                                              onFieldSubmitted:
                                                                  (term) {},
                                                              validator: (val) => val
                                                                      .trim()
                                                                      .isEmpty
                                                                  ? MessageConstant
                                                                      .FIELD_REQUIRED
                                                                  : null,
                                                              maxLength: 200,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                              top: 5,
                                                            ),
                                                            child:
                                                                TextFormField(
                                                              controller:
                                                                  mediaListData[
                                                                          index]
                                                                      .descController,
                                                              decoration: textFormFieldDecorationWithLabel(
                                                                  MessageConstant
                                                                      .ADD_ACCOMPLISHMENT_DESCRIPTION,
                                                                  hintText: widget
                                                                              .level1 ==
                                                                          MessageConstant
                                                                              .ADD_ACCOMPLISHMENT_ARTS
                                                                      ? MessageConstant
                                                                          .ADD_ACCOMPLISHMENT_IN_DETAILS_DESCRIBE_ART
                                                                      : MessageConstant
                                                                          .ADD_ACCOMPLISHMENT_IN_DETAILS_DESCRIBE_SPORTS),
                                                              style:
                                                                  textFormFieldValueStyle(),
                                                              onFieldSubmitted:
                                                                  (term) {},
                                                              validator: (val) => val
                                                                      .trim()
                                                                      .isEmpty
                                                                  ? MessageConstant
                                                                      .FIELD_REQUIRED
                                                                  : null,
                                                              maxLength: 1000,
                                                            ),
                                                          ),
                                                          widget.level1 ==
                                                                  "Arts"
                                                              ? Container(
                                                                  height: 0.0,
                                                                )
                                                              : Padding(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .only(
                                                                    bottom: UIHelper
                                                                        .screenPadding,
                                                                    top: 5,
                                                                  ),
                                                                  child:
                                                                      TextFormField(
                                                                    controller:
                                                                        mediaListData[index]
                                                                            .statisticsController,
                                                                    maxLength:
                                                                        200,
                                                                    decoration:
                                                                        textFormFieldDecorationWithLabel(
                                                                            'Statistics'),
                                                                    style:
                                                                        textFormFieldValueStyle(),
                                                                    onFieldSubmitted:
                                                                        (term) {},
                                                                  ),
                                                                ),
                                                        ],
                                                      )
                                                    : Container(
                                                        height: 0.0,
                                                      )
                                              ],
                                            )))),
                                Positioned(
                                  right: 0.0,
                                  top: 0.0,
                                  child: InkWell(
                                    child: index > 0
                                        ? Container(
                                            padding: EdgeInsets.all(0),
                                            child: Image.asset(
                                              ImagePath.ICON_CLEAR,
                                              height: 24.18,
                                              width: 17,
                                            ),
                                          )
                                        : Container(
                                            height: 24.18,
                                            width: 17,
                                          ),
                                    onTap: () {
                                      mediaListData.removeAt(index);

                                      setState(() {});
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                    ////////////////////////////
                    InkWell(
                      child: Padding(
                        padding:
                            EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
                        child: Text(
                          '+ ADD MORE MEDIA'.toUpperCase(),
                          style: AppTextStyle.getDynamicFontStyle(
                              Palette.accentColor, 14, FontType.Regular),
                        ),
                      ),
                      onTap: () {
                        final form = _formKey.currentState;

                        form.save();
                        form.validate();
                        int count = 0;
                        mediaListData.map((v) {
                          if (v.fileDataModelList.length == 1) {
                            v.isSelectMedia = false;
                          }
                          if (!v.isSelectMedia) {
                            count++;
                          }
                        }).toList();

                        if (count == 0 &&
                            mediaListData[mediaListData.length - 1]
                                    .labelController
                                    .text !=
                                "" &&
                            mediaListData[mediaListData.length - 1]
                                    .descController
                                    .text !=
                                "") {
                          setState(() {
                            MediaDataModelNew _mMediaDataModelNew =
                                MediaDataModelNew(
                                    TextEditingController(text: ""),
                                    TextEditingController(text: ""),
                                    TextEditingController(text: ""),
                                    isSelectMedia: true,
                                    fileDataModelList: List<FileDataModel>());
                            _mMediaDataModelNew.fileDataModelList.add(
                                FileDataModel(
                                    filePath: "",
                                    type: "",
                                    thumbnailFile: null,
                                    imagePath: null,
                                    linkController: TextEditingController()));

                            mediaListData.add(_mMediaDataModelNew);
                          });
                        } else {
                          setState(() {});
                        }
                      },
                    ),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  stateWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        PaddingWrap.paddingfromLTRB(
            0.0,
            10.0,
            0.0,
            0.0,
            TextViewWrap.textViewMultiLine(
                "Add all your playing position(s) with statistics",
                TextAlign.start,
                ColorValues.GREY_TEXT_COLOR,
                14.0,
                FontWeight.normal,
                4)),

        //////////////////////////////////
        ListView.builder(
          itemCount: stateListData.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 10),
              child: Container(
                //color: ColorValues.BLUE_COLOR,
                //padding: EdgeInsets.only(top: 10,),

                margin: EdgeInsets.only(top: 0, bottom: 0, right: 0),
                child: Stack(
                  children: <Widget>[
                    Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 10, 5, 0),
                        child: Container(
                            color: ColorValues.SELECTION_GRAY,
                            margin: EdgeInsets.only(top: 0, right: 0),
                            child: Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(13.0, 5, 13, 5),
                                child: Column(
                                  children: <Widget>[
                                    Padding(
                                      padding: EdgeInsets.only(
                                        bottom: UIHelper.screenPadding,
                                        top: 5,
                                      ),
                                      child: TextFormField(
                                        controller: stateListData[index]
                                            .positionController,
                                        //controller: timeFrom,
                                        //controller: timeFromController,
                                        //enabled: false,
                                        decoration:
                                            textFormFieldDecorationWithLabelStats(
                                                'Playing Position',
                                                hintText: "Pitcher"),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (val) => stateListData[index]
                                                        .positionController
                                                        .text ==
                                                    "" &&
                                                stateListData[index]
                                                        .lableController
                                                        .text ==
                                                    "" &&
                                                stateListData[index]
                                                        .valueController
                                                        .text ==
                                                    ""
                                            ? null
                                            : val.trim().isEmpty
                                                ? MessageConstant.FIELD_REQUIRED
                                                : null,
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  bottom:
                                                      UIHelper.screenPadding,
                                                  top: 5,
                                                  right: 2),
                                              child: TextFormField(
                                                controller: stateListData[index]
                                                    .lableController,
                                                //controller: timeFrom,
                                                //controller: timeFromController,
                                                //enabled: false,
                                                decoration:
                                                    textFormFieldDecorationWithLabelStats(
                                                        ' Statistics Label'),
                                                style:
                                                    textFormFieldValueStyle(),
                                                onFieldSubmitted: (term) {},
                                                validator: (val) =>
                                                    /*stateListData[index]
                                                    .positionController
                                                    .text ==
                                                    "" &&*/
                                                    stateListData[index]
                                                                    .lableController
                                                                    .text ==
                                                                "" &&
                                                            stateListData[index]
                                                                    .valueController
                                                                    .text ==
                                                                ""
                                                        ? null
                                                        : val.trim().isEmpty
                                                            ? MessageConstant
                                                                .FIELD_REQUIRED
                                                            : null,
                                              ),
                                            ),
                                            flex: 1),
                                        Expanded(
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  bottom:
                                                      UIHelper.screenPadding,
                                                  top: 5,
                                                  left: 2),
                                              child: TextFormField(
                                                controller: stateListData[index]
                                                    .valueController,
                                                //controller: timeFrom,
                                                //controller: timeFromController,
                                                //enabled: false,
                                                decoration:
                                                    textFormFieldDecorationWithLabelStats(
                                                        'Statistics Value'),
                                                style:
                                                    textFormFieldValueStyle(),
                                                onFieldSubmitted: (term) {},
                                                validator: (val) =>
                                                    /* stateListData[index]
                                                    .positionController
                                                    .text ==
                                                    "" &&*/
                                                    stateListData[index]
                                                                    .lableController
                                                                    .text ==
                                                                "" &&
                                                            stateListData[index]
                                                                    .valueController
                                                                    .text ==
                                                                ""
                                                        ? null
                                                        : val.trim().isEmpty
                                                            ? MessageConstant
                                                                .FIELD_REQUIRED
                                                            : null,
                                              ),
                                            ),
                                            flex: 1),
                                      ],
                                    ),
                                  ],
                                )))),
                    Positioned(
                      right: 0.0,
                      top: 0.0,
                      child: InkWell(
                        child: index > 0
                            ? Container(
                                padding: EdgeInsets.all(0),
                                child: Image.asset(
                                  ImagePath.ICON_CLEAR,
                                  height: 24.18,
                                  width: 17,
                                ),
                              )
                            : Container(
                                height: 24.18,
                                width: 17,
                              ),
                        onTap: () {
                          if (stateListData.length > 1) {
                            print('link Index is =======>  $index');
                            stateListData.removeAt(index);
                          }
                          setState(() {});
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),

        InkWell(
          child: Padding(
            padding: EdgeInsets.only(top: 5, bottom: 5, right: 12.0),
            child: Text(
              '+ ADD MORE POSITION(s)'.toUpperCase(),
              style: AppTextStyle.getDynamicFontStyle(
                  Palette.accentColor, 14, FontType.Regular),
            ),
          ),
          onTap: () {
            setState(() {
              stateListData.add(StateModel(
                  position: "",
                  lable: "",
                  value: "",
                  positionController: TextEditingController(),
                  lableController: TextEditingController(),
                  valueController: TextEditingController()));
            });
          },
        ),
      ],
    );
  }

  clubTeamWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: clubTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'Club Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  clubTeamList.removeAt(index);
                                  if (clubTeamList.length == 0) {
                                    isClubTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].clubNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Club Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].teamController,
                            focusNode: teamNameFocus,
                            onChanged: (text) {
                              teamNameFocus.requestFocus();
                            },
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Team Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('City'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].stateController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('State'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                                textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: clubTeamList[index].coachNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                    ? MessageConstant
                                        .COACH_NAME_CONTAIN_ALPHABET_VAL
                                    : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                clubTeamList[index].coachEmailController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                    ? MessageConstant.VALID_EMAIL_VAL
                                    : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    clubTeamList[index].selectedCountryCode =
                                        country.dialingCode;
                                    clubTeamList[index].selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode:
                                    clubTeamList[index].selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: clubTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                            textFormFieldDecorationWithLabel(
                                                'Coach Phone Number'),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isClubTeam
            ? Container(
                height: 0.0,
              )
            : InkWell(
                child: Padding(
                  padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
                  child: Text(
                    '+ ADD MORE CLUB TEAM'.toUpperCase(),
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 14, FontType.Regular),
                  ),
                ),
                onTap: () {
                  setState(() {
                    clubTeamList.add(ClubTeamModel(
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                    ));
                  });
                },
              ),
      ],
    );
  }

  highSchoolTeamWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: highSchoolTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'High School Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  highSchoolTeamList.removeAt(index);
                                  if (highSchoolTeamList.length == 0) {
                                    isHighSchoolTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].clubNameController,
                            decoration:
                                textFormFieldDecorationWithLabel('High School'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].teamController,
                            focusNode: teamNameFocus1,
                            onChanged: (text) {
                              teamNameFocus1.requestFocus();
                            },
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Team Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('City'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].stateController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('State'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                                textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].coachNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                    ? MessageConstant
                                        .COACH_NAME_CONTAIN_ALPHABET_VAL
                                    : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                highSchoolTeamList[index].coachEmailController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                    ? MessageConstant.VALID_EMAIL_VAL
                                    : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    highSchoolTeamList[index]
                                            .selectedCountryCode =
                                        country.dialingCode;
                                    highSchoolTeamList[index]
                                            .selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode: highSchoolTeamList[index]
                                    .selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: highSchoolTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                            textFormFieldDecorationWithLabel(
                                                'Coach Phone Number'),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isHighSchoolTeam
            ? Container(
                height: 0.0,
              )
            : InkWell(
                child: Padding(
                  padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
                  child: Text(
                    '+ ADD MORE HIGH SCHOOL TEAM'.toUpperCase(),
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 14, FontType.Regular),
                  ),
                ),
                onTap: () {
                  setState(() {
                    highSchoolTeamList.add(ClubTeamModel(
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                    ));
                  });
                },
              ),
      ],
    );
  }

  collegeTeamWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: collegeTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'College Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  collegeTeamList.removeAt(index);
                                  if (collegeTeamList.length == 0) {
                                    isCollegeTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                collegeTeamList[index].clubNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_COLLEGE),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].teamController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_TEAM_NAME),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_CITY),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].stateController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_STATE),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: collegeTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                                textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                collegeTeamList[index].coachNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Coach Name'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                    ? MessageConstant
                                        .COACH_NAME_CONTAIN_ALPHABET_VAL
                                    : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                collegeTeamList[index].coachEmailController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Coach Email'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                    ? MessageConstant.VALID_EMAIL_VAL
                                    : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    collegeTeamList[index].selectedCountryCode =
                                        country.dialingCode;
                                    collegeTeamList[index]
                                            .selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode:
                                    collegeTeamList[index].selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: collegeTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                            textFormFieldDecorationWithLabel(
                                                MessageConstant
                                                    .ADD_ACCOMPLISHMENT_COACH_PHONE_NUMBER),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isCollegeTeam
            ? Container(
                height: 0.0,
              )
            : InkWell(
                child: Padding(
                  padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
                  child: Text(
                    '+ ADD MORE COLLEGE TEAM'.toUpperCase(),
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 14, FontType.Regular),
                  ),
                ),
                onTap: () {
                  setState(() {
                    collegeTeamList.add(ClubTeamModel(
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                    ));
                  });
                },
              ),
      ],
    );
  }

  otherTeamWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        //////////////////////////////////
        ListView.builder(
          itemCount: otherTeamList.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              padding: EdgeInsets.only(top: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.only(right: 13.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                'Other Team ${index + 1}',
                                style: AppTextStyle.getDynamicFontStyle(
                                    Palette.primaryTextColor,
                                    16,
                                    FontType.Regular),
                              ),
                              UIHelper.horizontalGapBetweenBox,
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.all(0),
                                  child: Image.asset(
                                    ImagePath.ICON_CLEAR,
                                    height: 24.18,
                                    width: 17,
                                  ),
                                ),
                                onTap: () {
                                  print('link Index is =======>  $index');
                                  otherTeamList.removeAt(index);
                                  if (otherTeamList.length == 0) {
                                    isOtherTeam = false;
                                  }
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].clubNameController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration:
                                textFormFieldDecorationWithLabel('Other'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].teamController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_TEAM_NAME),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].cityController,
                            //controller: timeFrom,
                            //controller: timeFromController,
                            //enabled: false,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_CITY),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].stateController,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_STATE),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller: otherTeamList[index].jerseyController,
                            keyboardType: TextInputType.number,
                            decoration:
                                textFormFieldDecorationWithLabel('Jersey#'),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().isEmpty
                                ? MessageConstant.FIELD_REQUIRED
                                : null,
                            maxLength: 200,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                otherTeamList[index].coachNameController,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_COACH_NAME),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isName(val.trim())
                                    ? MessageConstant
                                        .COACH_NAME_CONTAIN_ALPHABET_VAL
                                    : null,
                            maxLength: 40,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            bottom: UIHelper.screenPadding,
                            top: 5,
                          ),
                          child: TextFormField(
                            controller:
                                otherTeamList[index].coachEmailController,
                            decoration: textFormFieldDecorationWithLabel(
                                MessageConstant.ADD_ACCOMPLISHMENT_COACH_EMAIL),
                            style: textFormFieldValueStyle(),
                            onFieldSubmitted: (term) {},
                            validator: (val) => val.trim().length == 0
                                ? MessageConstant.FIELD_REQUIRED
                                : !ValidationChecks.isEmail(val)
                                    ? MessageConstant.VALID_EMAIL_VAL
                                    : null,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            right: UIHelper.screenPadding,
                            top: 5,
                            /* bottom: UIHelper.screenPadding */
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              CountryCodePicker(
                                dense: false,
                                showFlag: true,
                                //displays flag, true by default
                                showDialingCode: true,
                                //displays dialing code, false by default
                                showName: false,
                                //displays country name, true by default
                                onChanged: (CountryCode country) {
                                  setState(() {
                                    otherTeamList[index].selectedCountryCode =
                                        country.dialingCode;
                                    otherTeamList[index]
                                            .selectedcoachPhoneCode =
                                        country.isoCode;
                                  });
                                },
                                selectedCountryCode:
                                    otherTeamList[index].selectedCountryCode,
                              ),
                              SizedBox(
                                width: 12,
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 2.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      TextFormField(
                                        controller: otherTeamList[index]
                                            .coachPhoneNumberController,
                                        keyboardType: TextInputType.number,
                                        decoration:
                                            textFormFieldDecorationWithLabel(
                                                MessageConstant
                                                    .ADD_ACCOMPLISHMENT_COACH_PHONE_NUMBER),
                                        style: textFormFieldValueStyle(),
                                        onFieldSubmitted: (term) {},
                                        validator: (value) {
                                          return ValidationChecks
                                              .validatePhonePortFolio(value);
                                        },
                                        maxLength: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        ////////////////////////////
        !isOtherTeam
            ? Container(
                height: 0.0,
              )
            : InkWell(
                child: Padding(
                  padding: EdgeInsets.only(top: 5, bottom: 20, right: 12.0),
                  child: Text(
                    '+ ADD MORE OTHER TEAM'.toUpperCase(),
                    style: AppTextStyle.getDynamicFontStyle(
                        Palette.accentColor, 14, FontType.Regular),
                  ),
                ),
                onTap: () {
                  setState(() {
                    otherTeamList.add(ClubTeamModel(
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                      TextEditingController(text: ""),
                    ));
                  });
                },
              ),
      ],
    );
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  personalReflectionWidget() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0),
        color: Colors.white,
        border: Border.all(
          color: Color(0xFFFDEDEDE),
          style: BorderStyle.solid,
          width: 1.0,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
          17.0,
          0.0,
          5.0,
          20.0,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    0.0,
                    17.0,
                    15.0,
                    0.0,
                    Image.asset(
                      "assets/newDesignIcon/ad_new/personal_rel.png",
                      width: 25.0,
                      height: 25.0,
                    )),
                flex: 0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        6.0,
                        TextViewWrap.textView(
                            MessageConstant
                                .ADD_ACCOMPLISHMENT_PERSONAL_REFLECTION,
                            TextAlign.start,
                            ColorValues.HEADING_COLOR_EDUCATION,
                            16.0,
                            FontWeight.normal)),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLine(
                            MessageConstant.ADD_ACCOMPLISHMENT_ADD_SOME_NOTES,
                            TextAlign.start,
                            ColorValues.GREY_TEXT_COLOR,
                            14.0,
                            FontWeight.normal,
                            4)),
                    //UIHelper.verticalGapBetweenBox,
                    personalReflectionUi(),
                    PaddingWrap.paddingfromLTRB(
                        0.0,
                        5.0,
                        0.0,
                        0.0,
                        TextViewWrap.textViewMultiLineItalic(
                            MessageConstant
                                .ADD_ACCOMPLISHMENT_NOTE_PERSONAL_REFLECTION,
                            TextAlign.start,
                            ColorValues.ORANGE_TEXT_COLOR,
                            10.0,
                            FontWeight.normal,
                            4)),
                  ],
                ),
                flex: 1,
              )
            ],
          )),
    );
  }

  personalReflectionUi() {
    return Container(
        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child: TextFormField(
          keyboardType: TextInputType.text,
          controller: personalReflectionController,
          maxLength: TextLength.PERSONAL_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style: AppTextStyle.getDynamicStyleAddPortfolia(
              ColorValues.HEADING_COLOR_EDUCATION, null, FontType.Regular),
          /*TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),*/
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:
              BaseCommonWidget.textFormFieldDecorationAchievment("", ''),
          /*InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",
            floatingLabelBehavior: FloatingLabelBehavior.never,
            //labelText: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is best.",
            errorStyle: Util.errorTextStyle,
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            //  hintText: "Include things like what makes this experience so unique, what you might want to highlight in a college app. or in a job interview etc.",
            hintStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                //fontSize: 16
                fontSize: 13),
            fillColor: Colors.transparent,
          ),*/
          /*validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_Personal_Reflection_VAL : null,*/
          onSaved: (val) => strpersonalReflection = val.trim(),
        ));
  }
}
