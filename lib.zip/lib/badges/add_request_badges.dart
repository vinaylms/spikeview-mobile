import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart';

import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/FullImageView.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_multiline_text_form.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/constant/style.dart';
import 'package:spike_view_project/modal/badges/BadgeModel.dart';
import 'package:spike_view_project/modal/badges/IssuerModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:spike_view_project/widgets/list_image_view.dart';

class ManageBadges extends StatefulWidget {
  String dob, userId;

  ManageBadges(this.dob, this.userId);

  @override
  State<ManageBadges> createState() => _ManageBadgesState();
}

class _ManageBadgesState extends State<ManageBadges> {
  static const platform = const MethodChannel('samples.flutter.io/battery');
  TextEditingController searchController = TextEditingController();
  TextEditingController issuerTitlController = TextEditingController();
  TextEditingController issuerController = TextEditingController();
  TextEditingController issuerNameController = TextEditingController();
  TextEditingController issuerEmailController = TextEditingController();
  TextEditingController messageController = TextEditingController();

  final issuerMessage = FocusNode();

  String searchText = "";
  String groupValue = 'Request';
  BadgeData dropdownValue;
  final badgeTitle = FocusNode();
  final issuerName = FocusNode();
  final issuerEmail = FocusNode();
  bool _showText = true;
  List<BadgeData> spinnerItems = [];
  List<IssuerData> localSearchItemsList = [];
  IssuerData selectedIssuer;
  IssuerData partnerData;
  File image;
  File issuerImage;
  DateTime pickedDate;
  int strDateOfBirth = 0;
  String _searchText = "", previousText = "", errorMsg = "";
  bool _IsSearching = false;
  bool isShowError = false;
  bool isShowErrorRequested = false;
  bool isApiCalling = false;
  bool isSelected = false;
  Timer _timer;
  DateTime startDate;
  String dob, strDate;
  DateTime selectedDate = DateTime.now();
  String sasToken, containerName;
  bool selectedLength = false;
  String strFromDate;
  TextEditingController dateController = TextEditingController();
  String selectedImageType = "media",
      strPrefixPathforPhoto,
      strAzureImageUploadPath = "",
      strAzureImageUploadPathIssuer = "";
  int selectedIdx =
      -1; // Initialize to -1 to indicate no item is selected initially.

  Future apiCallingForFrindList2(s) async {
    try {
      if (s.length >= 1) {
        ///ui/search/searchUsersForGroupByEmail
        isSelected = false;
        previousText = searchController.text;
        Response response = await ApiCalling2().apiCall(context,
            'ui/partners?skip=0&name=' + searchController.text.trim(), "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              localSearchItemsList.clear();
              IssuerModel model = IssuerModel.fromJson(response.data);
              if (model.result.length > 0) {
                localSearchItemsList.addAll(model.result);
              }
              if (localSearchItemsList.length > 0) {
                setState(() {});
              }
            }
          }
        }
        isApiCalling = false;
        setState(() {});
      }

      isApiCalling = false;
      setState(() {});
    } catch (e) {
      isApiCalling = false;
      setState(() {});
    }
  }

  void hideKeyboard() {
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  void _startTimer() {
    Future.delayed(Duration(seconds: 10), () {
      setState(() {
        _showText = false;
      });
    });
  }

  Future apiCallBadge(userId) async {
    try {
      Response response =
          await ApiCalling().apiCall(context, 'ui/badges/$userId', "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            spinnerItems.clear();
            BadgeModel model = BadgeModel.fromJson(response.data);
            if (model.result.length > 0) {
              spinnerItems.addAll(model.result);
            }
            if (spinnerItems.length > 0) {
              setState(() {});
            }
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      e.toString();
    }
  }


  void showSucessDialog(name) {

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            headingText: 'Your badge request has been sent to “$name”. We will notify you once you receive the badge',
            negativeText: 'OK',
            isSucessPopup: true,
            positiveTextColor:AppConstants.colorStyle.lightBlue,
            onNegativeTap: () {
              Navigator.pop(context, "push");
            },

          );
        });


  }

  Future apiCallingSelf() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Map map;
        if (groupValue == 'Add') {
          map = {
            "requestedBy": widget.userId,
            "type": "self",
            "badgeImage": strPrefixPathforPhoto + strAzureImageUploadPath,
            "badgeName": issuerTitlController.text,
            "partnerEmail": issuerEmailController.text,
            "partnerName": issuerNameController.text,
            "issueDate": strFromDate,
            "status": "accepted",
            "message": "",
            "issuerLogo": strAzureImageUploadPathIssuer == ''
                ? ''
                : strPrefixPathforPhoto + strAzureImageUploadPathIssuer
          };
        } else {
          map = {
            "badgeId": dropdownValue.badgeId,
            "partnerId": selectedIssuer.userId,
            "requestedBy": widget.userId,
            "requestedByRole": 1,
            "message": messageController.text.trim(),
            "type": "request"
          };
        }
        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, 'ui/requestBadges', map);
        CustomProgressLoader.cancelLoader(context);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            FocusScope.of(context).unfocus();
            if (status == "Success") {
              if (groupValue == 'Add'){
                Navigator.pop(context, "push");

              }else {
                showSucessDialog(selectedIssuer.firstName);
              }

            } else {
              try {
                partnerData = IssuerData.fromJson(response.data['result'][0]);
                if (partnerData != null) {
                  isShowError = true;
                  errorMsg = msg;
                  setState(() {
                    FocusScope.of(context).unfocus();
                    isShowButton = false;

                  });
                } else {
                  if (groupValue == 'Add') {
                  } else {
                    _startTimer();
                    isShowErrorRequested = true;

                    _showText = true;
                    errorMsg = msg;
                  }
                }
                setState(() {

                });
              } catch (e) {
                if (groupValue == 'Add') {
                } else {
                  _startTimer();
                  _showText = true;
                  isShowErrorRequested = true;
                  errorMsg = msg;

                  setState(() {

                  });

                }
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      CustomProgressLoader.cancelLoader(context);
    }
    FocusScope.of(context).unfocus();
  }

  void conformationDialog(String type) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: 'Are you sure you want to remove?',
          onPositiveTap: () {
            if (type == "badge") {
              image = null;
              strAzureImageUploadPath = "";
            } else {
              issuerImage = null;
              strAzureImageUploadPathIssuer = "";
            }
            onLoad();
            setState(() {});
          },
        );
      },
    );
  }

  @override
  void initState() {
    callApiForSaas();
    strPrefixPathforPhoto = Constant.CONTAINER_PREFIX +
        widget.userId +
        "/" +
        Constant.CONTAINER_MEDIA +
        "/";
    if (widget.dob != null && widget.dob != "" && widget.dob != "null") {
      startDate = DateTime.fromMillisecondsSinceEpoch(int.parse(widget.dob));
    } else {
      startDate = DateTime.now();
    }
    messageController =
        TextEditingController(text: groupValue != "null" ? groupValue : "");
    setState(() {});

    messageController.addListener(() {
      setState(() {});
    });
    super.initState();
  }

  Future<void> selectFromDate(BuildContext context) async {
    DateTime picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: startDate,
      //DateTime(1900),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        String date = Util.getDate(selectedDate);
        // dateController.text = date; // You need to implement the formatDate function.
        strFromDate = (picked.millisecondsSinceEpoch).toString();
        issuerController = TextEditingController(text: date);
      });
    }
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });
          print("uploadImgOnAzure - ${Constant.IMAGE_PATH + result}");
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "AddAchievmentWidget", context);
      return "";
    }
  }

  ontapApply(type) async {
    if (image != null) {
      strAzureImageUploadPath = await uploadImgOnAzure(
          image.toString().replaceAll("File: ", "").replaceAll("'", "").trim(),
          strPrefixPathforPhoto);
      onLoad();
      setState(() {});
      cancelLoaderAfterDelay(context, Duration(seconds: 8));
      if (strAzureImageUploadPath != "" && strAzureImageUploadPath != "false") {
        onLoad();
        setState(() {});
      }
    }
  }

  Future<void> cancelLoaderAfterDelay(
      BuildContext context, Duration delay) async {
    await Future.delayed(delay);
    CustomProgressLoader.cancelLoader(context);
  }

  ontapApply2(type) async {
    if (issuerImage != null) {
      strAzureImageUploadPathIssuer = await uploadImgOnAzure(
          issuerImage
              .toString()
              .replaceAll("File: ", "")
              .replaceAll("'", "")
              .trim(),
          strPrefixPathforPhoto);
      setState(() {});
      CustomProgressLoader.cancelLoader(context);
      if (strAzureImageUploadPathIssuer != "" &&
          strAzureImageUploadPathIssuer != "false") {
        onLoad();
        setState(() {});
      }
    }
  }

  Future getImage(type) async {
    image = await ImagePicker.pickImage(source: ImageSource.gallery);
    if (image != null && image != "") {
      String strPath = image.toString().substring(
          image.toString().lastIndexOf("/") + 1, image.toString().length);
      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        //  await _cropImage(imagePath);
        if (image != null) {
          setState(() {});
          onLoad();
          CustomProgressLoader.showLoader(context);
          Timer(const Duration(milliseconds: 400), () {
            ontapApply(type);
          });
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  Future getImageIssuer(type) async {
    issuerImage = await ImagePicker.pickImage(source: ImageSource.gallery);
    if (issuerImage != null && issuerImage != "") {
      String strPath = issuerImage.toString().substring(
          issuerImage.toString().lastIndexOf("/") + 1,
          issuerImage.toString().length);

      if (strPath.toString().contains(".") &&
          (!strPath.toString().contains(".gif"))) {
        //  await _cropImage(imagePath);
        if (issuerImage != null) {
          setState(() {});
          CustomProgressLoader.showLoader(context);
          Timer(const Duration(milliseconds: 400), () {
            ontapApply2(type);
            onLoad();
          });
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
      }
    }
  }

  bool isShowButton = false;

  void onLoad() {
    if (groupValue == 'Add') {
      if (strAzureImageUploadPath != '' &&
          issuerEmailController.text.length > 0 &&
          issuerNameController.text.length > 0 &&
          strFromDate.length > 0 &&
          issuerTitlController.text.length > 0) {
        if (ValidationWidget.isEmail(issuerEmailController.text.trim())) {
          isShowButton = true;
        } else {
          isShowButton = false;
        }
      } else {
        isShowButton = false;
      }
    } else {
      if (dropdownValue != null &&
          selectedIssuer != null &&
          messageController.text.trim().length > 0) {
        isShowButton = true;
      } else {
        isShowButton = false;
      }
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
          ),
          child: Container(
            color: Colors.white,
            child: SingleChildScrollView(
              child: Container(
                  child: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          const EdgeInsets.only(left: 0.0, right: 0, top: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              BaseText(
                                text: MessageConstant.BADGE,
                                textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w700,
                                fontSize: 28,
                                maxLines: 1,
                              ),
                              const HelpButtonWidget(),
                            ],
                          ),
                          const SizedBox(height: 5),
                          Align(
                              alignment: Alignment.topLeft,
                              child: BaseText(
                                text:'Request badge',
                                textColor: AppConstants.colorStyle.lightPurple,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                maxLines: 2,
                              )),
                        ],
                      ),
                    ),
                    flex: 0,
                  ),
                  PaddingWrap.paddingfromLTRB(
                      0.0,
                      25.0,
                      0.0,
                      0.0,
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              child: Container(
                                //width: MediaQuery.of(context).size.width*0.45,
                                child: Text(
                                  'Request',
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: groupValue == 'Request'
                                        ? ColorValues.WHITE
                                        : AppConstants.colorStyle.darkBlue,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                  ),
                                ),
                                padding: EdgeInsets.only(
                                    top: 9, bottom: 9, left: 9, right: 9),
                                decoration: BoxDecoration(
                                  color: groupValue == 'Request'
                                      ? ColorValues.DARK_YELLOW
                                      : AppConstants.colorStyle.tabBg,
                                  border: Border.all(
                                      color: groupValue == 'Request'
                                          ? ColorValues.DARK_YELLOW
                                          : AppConstants
                                              .colorStyle.borderGenerateScript),
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(10),
                                      bottomLeft: Radius.circular(10)),
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  isShowButton = false;
                                  groupValue = 'Request';
                                  selectedIdx = -1;

                                  if (issuerTitlController != null) {
                                    issuerTitlController.text = "";
                                  }

                                  image = null;
                                  strAzureImageUploadPath = "";
                                  issuerImage = null;
                                  strAzureImageUploadPathIssuer = "";

                                  if (issuerController != null) {
                                    issuerController.text = "";
                                  }
                                  if (issuerNameController != null) {
                                    issuerNameController.text = "";
                                  }
                                  isShowError = false;
                                  if (issuerEmailController != null) {
                                    issuerEmailController.text = "";
                                  }
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              child: Container(
                                //width: MediaQuery.of(context).size.width*0.45,
                                child: Text(
                                  'Add',
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: groupValue == 'Add'
                                        ? ColorValues.WHITE
                                        : AppConstants.colorStyle.darkBlue,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                  ),
                                ),
                                padding: EdgeInsets.only(
                                    top: 9, bottom: 9, left: 9, right: 9),
                                decoration: BoxDecoration(
                                  color: groupValue == 'Add'
                                      ? ColorValues.DARK_YELLOW
                                      : AppConstants.colorStyle.tabBg,
                                  border: Border.all(
                                      color: AppConstants
                                          .colorStyle.borderGenerateScript),
                                  borderRadius: const BorderRadius.only(
                                      topRight: Radius.circular(10),
                                      bottomRight: Radius.circular(10)),
                                ),
                              ),
                              onTap: () {
                                setState(() {
                                  selectedIdx = -1;
                                  isShowButton = false;
                                  groupValue = 'Add';
                                  isShowError = false;
                                  if (searchController.text != null) {
                                    searchController.text = "";
                                  }
                                  localSearchItemsList.clear();
                                  if (messageController.text != null) {
                                    messageController.text = "";
                                  }
                                  isSelected = false;
                                  dropdownValue = null;
                                });
                                setState(() {
                                  localSearchItemsList.clear();
                                  calFilter("");
                                });
                              },
                            ),
                          ),
                        ],
                      )),
                  const SizedBox(height: 20),
                  groupValue == 'Request'
                      ? requestBadge(context)
                      : groupValue == 'Add'
                          ? addBadge(context)
                          : emptyBadge(context)
                ],
              )),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Container(
          // height: 44,
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  flex: 33,
                  child: _negativeButton(title: 'Cancel'),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 63,
                  child: _positiveButton(
                      isButtonEnable: true,
                      title: groupValue == 'Request' ? 'Send' : 'Add'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _negativeButton({@required String title}) {
    return InkWell(
      onTap: () {
        // _unfocused();
        Navigator.pop(context, "pop");
      },
      child: Container(
        height: 44,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ColorValues.WHITE,
          border: Border.all(color: Color(0xffB2BDDB)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: AppConstants.colorStyle.lightPurple,
            fontFamily: AppConstants.stringConstant.latoMedium,
            fontSize: 18,
          ),
        ),
      ),
    );
  }

  Widget _positiveButton({
    @required bool isButtonEnable,
    @required String title,
  }) {
    return ElevatedButton(
      onPressed: () {
        if (isShowButton) {
          if (groupValue == 'Request') {
            if (!searchController.text.isEmpty) {
              if (dropdownValue != null) {
                if (!messageController.text.trim().isEmpty) {
                  apiCallingSelf();
                } else {
                  ToastWrap.showToast("Please enter message", context);
                }
              } else {
                ToastWrap.showToast("Please select Badge", context);
              }
            } else {
              ToastWrap.showToast("Please select Issuer ", context);
            }
          } else if (groupValue == 'Add') {
            if (!issuerTitlController.text.isEmpty) {
              if (image != null) {
                if (!issuerController.text.isEmpty) {
                  if (!issuerNameController.text.isEmpty) {
                    if (!issuerEmailController.text.isEmpty) {
                      apiCallingSelf();
                    } else {
                      ToastWrap.showToast("Please enter issuer email", context);
                    }
                  } else {
                    ToastWrap.showToast("Please enter issuer name", context);
                  }
                } else {
                  ToastWrap.showToast("Please select issue date", context);
                }
              } else {
                ToastWrap.showToast("Please select Badge image", context);
              }
            } else {
              ToastWrap.showToast("Please enter title", context);
            }
          }
        }
      },
      style: ElevatedButton.styleFrom(
        elevation: 0,
        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        padding: EdgeInsets.symmetric(vertical: 11),
        primary: isShowButton
            ? ColorValues.BLUE_COLOR_BOTTOMBAR
            : ColorValues.BLUE_COLOR_BOTTOMBAR.withOpacity(.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: Text(
        title,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontWeight: FontWeight.w600,
          color: ColorValues.WHITE,
          fontFamily: AppConstants.stringConstant.latoRegular,
          fontSize: 18,
        ),
      ),
    );
  }

  Widget emptyBadge(BuildContext context) {
    return Container(
      color: const Color(0xffFFFFFF),
      margin: const EdgeInsets.only(top: 20),
      child: Column(
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height -
                MediaQuery.of(context).size.height / 2,
          )
        ],
      ),
    );
  }

  Widget requestBadge(BuildContext context) {
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomFormField(
                controller: searchController,
                // focusNode: fNameNode,
                textInputType: TextInputType.text,
                // readOnly: widget.action == RecommendationAction.edit,
                onType: (value) {
                  setState(() {
                    searchText = value;
                    calFilter(value);
                  });
                },
                suffixWidget: Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Container(
                    width: 15, // Set the desired width
                    height: 15, // Set the desired height
                    child: Padding(
                      padding: const EdgeInsets.only(top: 5, right: 3, left: 3),
                      child: Image.asset(
                        'assets/feed/search.png',
                      ),
                    ),
                  ),
                ),
                label: "Search issuer",
                hint: "Search issuer",
                alignLabelWithHint: true,
                // validation: (val) => val.trim().length == 0
                //     ? MessageConstant.ENTER_FIRST_NAME_VAL
                //     : !ValidationWidget.isName(val)
                //     ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL
                //     : null,
              ),

              // TextFormField(
              //   cursorColor: ColorValues.HEADING_COLOR_EDUCATION_2,
              //
              //   style: TextStyle(
              //       color: ColorValues.HEADING_COLOR_EDUCATION_1,
              //       fontWeight: FontWeight.w500,
              //       fontFamily: Constant.latoRegular,
              //       fontSize: 18),
              //   decoration: InputDecoration(
              //     labelText: "Search Issuer",
              //     filled: true,
              //     fillColor: Colors.white,
              //     counterText: '',
              //     labelStyle: TextStyle(
              //         color: ColorValues.labelColor,
              //         fontWeight: FontWeight.w500,
              //         fontFamily: Constant.latoRegular,
              //         fontSize: 14),
              //     suffixIconConstraints:
              //         BoxConstraints(minHeight: 20, minWidth: 20),
              //     suffixIcon: Padding(
              //       padding: const EdgeInsets.only(top: 7),
              //       child: Image.asset(
              //         'assets/feed/search.png',
              //         fit: BoxFit.cover,
              //         width: 20,
              //         height: 20, // Replace with the actual path to your image
              //         // color: Color(0xff888888),
              //       ),
              //     ),
              //
              //     // prefixIcon: selectedIssuer == null
              //     //     ? null
              //     //     : Padding(
              //     //         padding: const EdgeInsets.all(10.0),
              //     //         child: Container(
              //     //             width: 20.0,
              //     //             height: 20.0,
              //     //             child: ClipRRect(
              //     //               borderRadius: BorderRadius.circular(100),
              //     //               child: FadeInImage.assetNetwork(
              //     //                 fit: BoxFit.cover,
              //     //                 placeholder: "assets/profile/partner_img.png",
              //     //                 image: Constant.IMAGE_PATH +
              //     //                     ParseJson.getMediumImage(
              //     //                         selectedIssuer.profilePicture),
              //     //               ),
              //     //             )),
              //     //       ),
              //     hintText: "Search Issuer",
              //     hintStyle: TextStyle(
              //         color: ColorValues.HEADING_COLOR_EDUCATION_1,
              //         fontWeight: FontWeight.w500,
              //         fontFamily: Constant.latoRegular,
              //         fontSize: 14),
              //     contentPadding: const EdgeInsets.symmetric(vertical: 0),
              //     focusedBorder: const UnderlineInputBorder(
              //         borderSide: BorderSide(color: Color(0xffC3CBF0))),
              //     enabledBorder: const UnderlineInputBorder(
              //         borderSide: BorderSide(color: Color(0xffC3CBF0))),
              //   ),
              //   controller: searchController,
              //   onChanged: (value) {
              //     setState(() {
              //       searchText = value;
              //       calFilter(value);
              //     });
              //   },
              // ),
              !isSelected &&
                      searchController.text.length > 1 &&
                      !isApiCalling &&
                      (localSearchItemsList == null ||
                          localSearchItemsList.length == 0)
                  ? Card(
                      shape: RoundedRectangleBorder(
                          side: const BorderSide(
                              color: Color(0xFFD1D1D1), width: 1.0),
                          borderRadius: BorderRadius.circular(0.7)),
                      color: const Color(0xFFFFFFFF),
                      child: Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(
                            top: 10, bottom: 10, left: 15, right: 15),
                        child: Text('No data found',
                            textAlign: TextAlign.start,
                            maxLines: 5,
                            style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 14.0,
                                fontFamily: Constant.latoSemibold)),
                      ),
                    )
                  : SizedBox(
                      height: 0,
                    ),
              localSearchItemsList != null && localSearchItemsList.isNotEmpty
                  // List search item
                  ? Container(
                      height: localSearchItemsList.length == 0
                          ? 0.0
                          : localSearchItemsList.length == 1
                              ? 90.0
                              : localSearchItemsList.length == 2
                                  ? 125.0
                                  : localSearchItemsList.length == 3
                                      ? 220.0
                                      : 300.0,
                      transform: Matrix4.translationValues(0.0, -7.0, 0.0),
                      child: Card(
                        // shape: RoundedRectangleBorder(
                        //     side: const BorderSide(
                        //         color: Color(0xFFD1D1D1), width: 1.0),
                        //     borderRadius: BorderRadius.circular(0.7)),
                        color: const Color(0xFFFFFFFF),
                        elevation: 3,
                        child: Container(
                          margin: const EdgeInsets.only(
                              top: 15, left: 10, right: 10, bottom: 10),
                          child: MediaQuery.removePadding(
                            removeTop: true,
                            context: context,
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: localSearchItemsList.length,
                              itemBuilder: (BuildContext context, int index) {
                                return searchItemTile(context, index);
                              },
                            ),
                          ),
                        ),
                      ),
                    )
                  : const SizedBox(),
              // select badges

              selectedIssuer != null
                  ? Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Stack(
                            children: <Widget>[
                              Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      margin: const EdgeInsets.only(top: 40),
                                      child: Text(
                                          'Select from available badges',
                                          maxLines: 1,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color: ColorValues.labelColor,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily:
                                                  Constant.latoRegular)),
                                    ),
                                    Container(
                                      padding: const EdgeInsets.only(top: 12),
                                      child: GridView.builder(
                                        itemCount: spinnerItems.length,
                                        physics: NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        gridDelegate:
                                            SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 2,
                                          childAspectRatio: (220.0 / 60.0),
                                          crossAxisSpacing: 10.0,
                                          mainAxisSpacing: 10.0,
                                        ),
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Container(
                                            decoration: BoxDecoration(
                                              color: selectedIdx == index
                                                  ? AppConstants.colorStyle
                                                      .btn_selected_color
                                                  : AppConstants
                                                      .colorStyle.tabBg,
                                              border: Border.all(
                                                color: selectedIdx == index
                                                    ? AppConstants.colorStyle
                                                        .btn_selected_color
                                                    : AppConstants
                                                        .colorStyle.tabBg,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: InkWell(
                                              child: Row(
                                                //  crossAxisAlignment: CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 5),
                                                    child: Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8),
                                                        color: Colors.white,
                                                        // border: Border(
                                                        //   bottom: BorderSide(
                                                        //     color: Color(0xffE2E9FD), // Change this color to your desired border color
                                                        //     width: 1.0, // Adjust this value for the border height
                                                        //   ),
                                                        // ),
                                                      ),
                                                      width: 35.0,
                                                      height: 35.0,
                                                      padding: EdgeInsets.only(
                                                        left: 3,
                                                        right: 3,
                                                        top: 3,
                                                        bottom: 3,
                                                      ),
                                                      child: Container(
                                                        width: 32.0,
                                                        height: 33.0,
                                                        child: ClipRRect(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(1),
                                                          child: FadeInImage
                                                              .assetNetwork(
                                                            fit: BoxFit.contain,
                                                            placeholder:
                                                                "assets/profile/partner_img.png",
                                                            image: Constant
                                                                    .IMAGE_PATH +
                                                                ParseJson.getMediumImage(
                                                                    spinnerItems[
                                                                            index]
                                                                        .image),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  PaddingWrap.paddingfromLTRB(
                                                    10.0,
                                                    5.0,
                                                    5.0,
                                                    8.0,
                                                    BaseText(
                                                      text: spinnerItems[index]
                                                          .name,
                                                      textColor:
                                                          selectedIdx == index
                                                              ? AppConstants
                                                                  .colorStyle
                                                                  .white
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .lightBlue,
                                                      fontFamily: AppConstants
                                                          .stringConstant
                                                          .latoMedium,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      fontSize: 14,
                                                      maxLines: 1,
                                                    ),
                                                  ),
                                                  Spacer()
                                                ],
                                              ),
                                              onTap: () {
                                                setState(() {
                                                  dropdownValue =
                                                      spinnerItems[index];
                                                  print(
                                                      "dropdownValie - ${dropdownValue}");
                                                  // _focusNode.unfocus(); // You can uncomment this if needed.
                                                });

                                                if (selectedIdx == index) {
                                                  // The same item is tapped again, so deselect it.
                                                  setState(() {
                                                    //selectedIdx = -1; // Reset to -1 to indicate no selection.
                                                  });
                                                } else {
                                                  // A different item is tapped, so deselect the previous selection and select the new one.
                                                  setState(() {
                                                    selectedIdx = index;
                                                  });
                                                }
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                    ),

/*
    SizedBox(
    width: MediaQuery.of(context).size.width,
    child: DropdownButton<BadgeData>(
    hint: Text('Select Badges',
    style: TxtStyle.nunito_14_400Grey),
    value: dropdownValue,
    isExpanded: true,
    icon: const Icon(Icons.arrow_drop_down),
    dropdownColor: Colors.white,
    focusColor: Colors.white,
    iconSize: 30,
    style: TxtStyle.nunito_14_400Black,
    underline: Container(
    width: MediaQuery.of(context).size.width,
    height: 1,
    color: const Color(0xffDEDEDE),
    ),
    onChanged: (BadgeData newValue) {
    setState(() {
    dropdownValue = newValue;
    });
    onload();
    },
    items: spinnerItems
        .map<DropdownMenuItem<BadgeData>>(
    (BadgeData value) {
    return DropdownMenuItem<BadgeData>(
    value: value,
    child: Row(
    crossAxisAlignment:
    CrossAxisAlignment.center,
    mainAxisAlignment:
    MainAxisAlignment.start,
    children: [
    const SizedBox(width: 10),
    Center(
    child: Container(
    width: 25.0,
    height: 25.0,
    child: ClipRRect(
    borderRadius:
    BorderRadius.circular(
    100),
    child: FadeInImage
        .assetNetwork(
    fit: BoxFit.contain,
    placeholder:
    "assets/profile/user_on_user.png",
    image: Constant
        .IMAGE_PATH +
    ParseJson
        .getMediumImage(
    value.image),
    ),
    ))
    ),
    const SizedBox(width: 5),
    Text(value.name,
    style:
    TxtStyle.nunito_14_400Black),
    ],
    ),
    );
    }).toList(),
    ),
    ),

 */
                                  ],
                                ),
                              ),
                              selectedIssuer == null
                                  ? Positioned(
                                      left: 0,
                                      right: 0,
                                      top: 0,
                                      bottom: 0,
                                      child: Container(
                                        color: Colors.white60,
                                      ),
                                    )
                                  : Container(
                                      height: 0,
                                    )
                            ],
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          selectedIdx != -1
                              ? Stack(
                                  children: [
                                    Column(
                                      children: [
                                        Container(
                                          margin: const EdgeInsets.only(
                                              top: 10, bottom: 0),
                                          child: Text(
                                              'Send a message to the badge issuer. Be specific with your request.',
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  color: ColorValues.labelColor,
                                                  fontSize: 14.0,
                                                  fontFamily:
                                                      Constant.latoRegular)),
                                        ),


                                        Container(
                                          //alignment: Alignment.topLeft,
                                          margin: const EdgeInsets.only(
                                              top: 5, bottom: 0),

                                          width: double.infinity,
                                          //MediaQuery.of(context).size.width,
                                          height: 120,

                                          child: CustomMultilineTextForm(
                                            maxLines: 5,
                                           // maxLength: 2000,
                                            focusNode:  issuerMessage,
                                            controller: messageController,
                                            // focusNode: detailNode,
                                            textAlign: TextAlign.start,
                                            hint:
                                                'I participated in your program in the spring of 2020 and was a leader of the team. Please issue a leader badge so I can add to my profile.',
                                            label: '',
                                          //  errorText:isShowErrorRequested?errorMsg:null ,
                                            alignLabelWithHint: true,
                                            textInputAction:
                                                TextInputAction.done,
                                            textInputType:
                                                TextInputType.multiline,
                                            validation: (value) {
                                              if (value
                                                  .toString()
                                                  .trim()
                                                  .isEmpty) {
                                                return 'Please add text';
                                              }
                                              return null;
                                            },
                                            onSaved: (val) {
                                              onLoad();

                                            },
                                            onType: (val) {
                                              onLoad();
                                            },
                                          ),

                                        ),
                                       // Padding(
                                       //    padding:
                                       //        const EdgeInsets.only(bottom: 2),
                                       //    child: Container(
                                       //      height: 1,
                                       //      color: ColorValues.BORDER_COLOR_NEW,
                                       //    ),
                                       //  ),
                                        Row(
                                          children: [
                                            _showText
                                                ? isShowErrorRequested
                                                    ? Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 5.0),
                                                        child: Container(
                                                          // height: 15,
                                                          child: RichText(
                                                            textAlign:
                                                                TextAlign.start,
                                                            text: TextSpan(
                                                              text:
                                                                  "Error: ${errorMsg}",
                                                              style: TxtStyle
                                                                  .nunito_12_red,
                                                              children: <
                                                                  TextSpan>[],
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    : SizedBox()
                                                : SizedBox(),
                                            Spacer(),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  right: 0.0,
                                                  bottom: 0,
                                                  top: 5),
                                              child: Align(
                                                alignment:
                                                    Alignment.centerRight,
                                                child: TextViewWrap.textViewSingleLine(
                                                    messageController.text
                                                            .trim()
                                                            .length
                                                            .toString() +
                                                        '/' +
                                                        TextLength
                                                            .COMMENT_MAX_LENGTH
                                                            .toString(),
                                                    TextAlign.center,
                                                    ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                    12.0,
                                                    FontWeight.normal),
                                              ),
                                            ),
                                          ],
                                        ),

                                      ],
                                    ),
                                    dropdownValue == null
                                        ? Positioned(
                                            left: 0,
                                            right: 0,
                                            top: 0,
                                            bottom: 0,
                                            child: Container(
                                              color: Colors.white60,
                                            ),
                                          )
                                        : Container(
                                            height: 0,
                                          )
                                  ],
                                )
                              : SizedBox(),
                        ],
                      ),
                    )
                  : SizedBox(),
            ],
          ),
        )
      ],
    );
  }

  Widget addBadge(BuildContext context) {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.only(top: 6),
          child: Text(
              'Did you receive a badge in an email or on another platform? Upload it here.',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: ColorValues.labelColor,
                  fontSize: 16.0,
                  fontWeight: FontWeight.w400,
                  fontFamily: Constant.latoRegular)),
        ),
        Column(
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomFormField(
                          controller: issuerTitlController,
                          // focusNode: addEmailNode,
                          alignLabelWithHint: true,
                          textInputType: TextInputType.emailAddress,
                          label: 'Badge title',
                          //hint: MessageConstant.ADD_RECOMMENDATION_EMAIL,
                          onType: (e) {
                            onLoad();
                          },
                        ),
                      ],
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.only(top: 25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomFormField(
                          controller: issuerController,
                          //focusNode: addEmailNode,
                          readOnly: true,

                          alignLabelWithHint: true,
                          textInputType: TextInputType.text,
                          label: 'Issue date',
                          // hint: MessageConstant.ADD_RECOMMENDATION_EMAIL,

                          onClick: () {
                            setState(() {
                              selectFromDate(context);
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Text(
                        //   'Issuer Name',
                        //   textAlign: TextAlign.start,
                        //   style: TxtStyle.nunito_14_400Grey,
                        // ),

                        CustomFormField(
                          controller: issuerNameController,
                          // focusNode: addEmailNode,
                          alignLabelWithHint: true,
                          textInputType: TextInputType.text,
                          label: 'Issuer name',
                          onType: (e) {
                            onLoad();
                          },
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 25),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CustomFormField(
                          controller: issuerEmailController,
                          // focusNode: addEmailNode,
                          alignLabelWithHint: true,
                          textInputType: TextInputType.emailAddress,
                          label: 'Issuer email',
                          onType: (e) {
                            onLoad();
                          },
                          //hint: MessageConstant.ADD_RECOMMENDATION_EMAIL,
                          // validation: (val) => val.trim().length == 0
                          //     ? MessageConstant.ENTER_EMAIL_VAL
                          //     : !ValidationWidget.isEmail(val)
                          //     ? MessageConstant.VALID_EMAIL_VAL
                          //     : null,
                        ),
                        isShowError
                            ? Padding(
                                padding: const EdgeInsets.only(top: 10.0),
                                child: RichText(
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: errorMsg + " Click ",
                                    style: TxtStyle.nunito_12_red,
                                    /*defining default style is optional */
                                    children: <TextSpan>[
                                      TextSpan(
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {
                                              isShowButton = false;
                                              groupValue = 'Request';

                                              if (issuerTitlController !=
                                                  null) {
                                                issuerTitlController.text = "";
                                              }

                                              image = null;
                                              strAzureImageUploadPath = "";
                                              issuerImage = null;
                                              strAzureImageUploadPathIssuer =
                                                  "";

                                              if (issuerController != null) {
                                                issuerController.text = "";
                                              }
                                              if (issuerNameController !=
                                                  null) {
                                                issuerNameController.text = "";
                                              }
                                              if (issuerEmailController !=
                                                  null) {
                                                issuerEmailController.text = "";
                                              }

                                              isSelected = true;
                                              apiCallBadge(partnerData.userId);
                                              selectedIssuer = partnerData;
                                              searchController.text =
                                                  partnerData.firstName;
                                              searchController.selection =
                                                  TextSelection.collapsed(
                                                      offset: searchController
                                                          .text.length);
                                              FocusManager.instance.primaryFocus
                                                  ?.unfocus();
                                              localSearchItemsList.clear();

                                              setState(() {});
                                            },
                                          text: ' here ',
                                          style: TxtStyle.nunito_12_500Blue),
                                      TextSpan(
                                          text: ' to send request.',
                                          style: TxtStyle.nunito_12_red),
                                    ],
                                  ),
                                ),
                              )
                            : SizedBox(),
                      ],
                    ),
                  ),

                  const SizedBox(height: 45),

                  ///Issuer upload logo view  - New UI -------
                  SizedBox(
                    width: double.maxFinite,
                    height: 110,
                    child: InkWell(
                      onTap: () {
                        ///  issuerImage = await ImagePickerUtility.getImageFromGallery();
                        getImageIssuer('');
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        overflow: Overflow.visible,
                        children: [
                          Positioned(
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 14,
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 14),
                              child: issuerImage != null
                                  ? Row(
                                      children: [
                                        ListImageView(
                                          imageUrl: '',
                                          onRemoveTap: () {
                                            conformationDialog('');
                                          },
                                          imageFile: issuerImage,
                                        ),
                                      ],
                                    )
                                  : Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const SizedBox(height: 18),
                                        Image.asset(
                                          "assets/recommendation/ic_camera.png",
                                          height: 26,
                                          width: 25,
                                        ),
                                        const SizedBox(height: 5),
                                        Text(
                                          'Add issuer logo (optional)',
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: AppConstants.txtStyle
                                              .heading14400LatoItalicLightPurple,
                                        ),
                                      ],
                                    ),
                              decoration: BoxDecoration(
                                color: AppConstants.colorStyle.tabBg,
                                border: Border.all(
                                  color: AppConstants
                                      .colorStyle.borderGenerateScript,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(7),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            child: Image.asset(
                              "assets/generateScript/plus_icon.png",
                              height: 28,
                              width: 28,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 45),
                  SizedBox(
                    width: double.maxFinite,
                    height: 110,
                    child: InkWell(
                      onTap: () {
                        if (image == null) {
                          //for badge image -
                          getImage('');
                        }

                        ///  image = await ImagePickerUtility.getImageFromGallery();
                      },
                      child: Stack(
                        alignment: Alignment.center,
                        overflow: Overflow.visible,
                        children: [
                          Positioned(
                            left: 0,
                            right: 0,
                            top: 0,
                            bottom: 14,
                            child: Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 14),
                              width: MediaQuery.of(context).size.width,
                              child: image != null
                                  ? Row(
                                      children: [
                                        ListImageView(
                                          imageUrl: '',
                                          onRemoveTap: () {
                                            conformationDialog('badge');
                                          },
                                          imageFile: image,
                                        ),
                                      ],
                                    )
                                  : Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const SizedBox(height: 18),
                                        Image.asset(
                                          "assets/recommendation/ic_camera.png",
                                          height: 26,
                                          width: 25,
                                        ),
                                        const SizedBox(height: 5),
                                        Text(
                                          'Your uploaded badge image will appear here',
                                          maxLines: 1,
                                          textAlign: TextAlign.center,
                                          style: AppConstants.txtStyle
                                              .heading14400LatoItalicLightPurple,
                                        ),
                                      ],
                                    ),
                              decoration: BoxDecoration(
                                color: AppConstants.colorStyle.tabBg,
                                border: Border.all(
                                  color: AppConstants
                                      .colorStyle.borderGenerateScript,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(7),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 0,
                            child: Image.asset(
                              "assets/generateScript/plus_icon.png",
                              height: 28,
                              width: 28,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  ///Badge Image view  - old -------
                  /*
                  Container(
                    margin: const EdgeInsets.only(top: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                            padding:
                            const EdgeInsets.only(bottom: 0.0, top: 10),
                            child: Text(
                              'Upload Badge Image',
                              textAlign: TextAlign.start,
                              style: TxtStyle.nunito_14_400Grey,
                            )),
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 2, left: 1.0, bottom: 10.0),
                          child: TextViewWrap.textViewMultiLine(
                              MessageConstant.ADD_RECOMMENDATION_SELECT_MEDIA,
                              TextAlign.start,
                              ColorValues.search_error_text,
                              10.0,
                              FontWeight.normal,
                              1),
                        ),
                        const SizedBox(height: 5),
                        GestureDetector(
                          onTap: () async {
                            ///  image = await ImagePickerUtility.getImageFromGallery();
                            getImage('');
                          },
                          child: image != null
                              ? Container(
                              width: 56,
                              height: 56,
                              child: Stack(
                                children: <Widget>[
                                  Container(
                                      padding: const EdgeInsets.all(5.0),
                                      width: 56,
                                      height: 56,
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color:
                                              const Color(0xffE9F0FB))),
                                      child: Image.file(image,
                                          width: 30,
                                          height: 30,
                                          fit: BoxFit.cover)),
                                  Container(
                                    height: 56.0,
                                    width: 56.0,
                                    color:
                                    Color(0XFFC0C0C0).withOpacity(.1),
                                  ),
                                  Container(
                                      height: 56.0,
                                      width: 56.0,
                                      child: Center(
                                          child: Row(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                            MainAxisAlignment.center,
                                            children: <Widget>[
                                              InkWell(
                                                  child: PaddingWrap
                                                      .paddingfromLTRB(
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      Image.asset(
                                                        "assets/newDesignIcon/achievment/remove.png",
                                                        width: 35.0,
                                                        height: 35.0,
                                                      )),
                                                  onTap: () {
                                                    conformationDialog('badge');
                                                  })
                                            ],
                                          ))),
                                ],
                              ))
                              : Image.asset(
                            'assets/badges/upload.png',
                            height: 56,
                            width: 56,
                          ),
                        ),
                      ],
                    ),
                  ),

                   */

                  ///Issuer upload logo view  - old UI-------
                  /*
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Upload Issuer Logo (optional)',
                          textAlign: TextAlign.start,
                          style: TxtStyle.nunito_14_400Grey,
                        ),
                        /*
                          RichText(
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              text: 'Upload Issuer Logo ',
                              style: TxtStyle.nunito_14_400Grey,
                              */ /*defining default style is optional */ /*
                              children: <TextSpan>[
                                TextSpan(
                                    text: '(optional)',
                                    style: TxtStyle.nunito_italic_14_400Grey),
                              ],
                            ),
                          ),*/
                        Padding(
                          padding: const EdgeInsets.only(
                              top: 3, left: 1.0, bottom: 0.0),
                          child: TextViewWrap.textViewMultiLine(
                              MessageConstant.ADD_RECOMMENDATION_SELECT_MEDIA,
                              TextAlign.start,
                              ColorValues.search_error_text,
                              10.0,
                              FontWeight.normal,
                              1),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: GestureDetector(
                            onTap: () async {
                              ///  issuerImage = await ImagePickerUtility.getImageFromGallery();
                              getImageIssuer('');
                            },
                            child: issuerImage != null
                                ? Container(
                                    width: 56,
                                    height: 56,
                                    child: Stack(
                                      children: <Widget>[
                                        Container(
                                            padding: const EdgeInsets.all(5.0),
                                            width: 56,
                                            height: 56,
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: const Color(
                                                        0xffE9F0FB))),
                                            child: Image.file(issuerImage,
                                                width: 30,
                                                height: 30,
                                                fit: BoxFit.cover)),
                                        Container(
                                          height: 56.0,
                                          width: 56.0,
                                          color:
                                              Color(0XFFC0C0C0).withOpacity(.4),
                                        ),
                                        Container(
                                            height: 56.0,
                                            width: 56.0,
                                            child: Center(
                                                child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: <Widget>[
                                                InkWell(
                                                    child: PaddingWrap
                                                        .paddingfromLTRB(
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            0.0,
                                                            Image.asset(
                                                              "assets/newDesignIcon/achievment/remove.png",
                                                              width: 35.0,
                                                              height: 35.0,
                                                            )),
                                                    onTap: () {
                                                      conformationDialog('');
                                                    })
                                              ],
                                            ))),
                                      ],
                                    ))
                                : Image.asset(
                                    'assets/badges/upload.png',
                                    height: 56,
                                    width: 56,
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),

                   */
                ],
              ),
            )
          ],
        ),
      ],
    );
  }

  showSuccessPopup() {
    showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      builder: (BuildContext context) {
        return Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 15.0, bottom: 0.0),
                child: Image.asset(
                  "assets/recommendation/green_tick_circle.png",
                  height: 70.0,
                  width: 69.0,
                ),
              ),
              SizedBox(height: 10.0),
              Text(
                'Success',
                textAlign: TextAlign.center,
                maxLines: 3,
                style: TextStyle(
                    fontSize: 20.0,
                    color: ColorValues.BUTTON_GREEN_DARK,
                    fontWeight: FontWeight.w700),
              ),
              SizedBox(height: 10.0),
              Text(
                groupValue == 'Request'
                    ? 'Your badge request has been sent. We\nwill notify you when you receive the\nbadge.'
                    : 'Your badge is now available\non your profile.',
                textAlign: TextAlign.center,
                maxLines: 3,
                style:
                    TextStyle(fontSize: 16.0, color: ColorValues.RADIO_BLACK),
              ),
              Padding(
                  padding: EdgeInsets.only(
                      left: 20.0, top: 20.0, right: 20.0, bottom: 15.0),
                  child: InkWell(
                    child: Container(
                        height: 40.0,
                        width: 60.0,
                        color: ColorValues.BLUE_COLOR,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              MessageConstant.OK,
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                fontSize: 20.0,
                              ),
                            )
                          ],
                        )),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pop(context, "push");
                    },
                  ))
            ],
          ),
        );
      },
    );
  }

  void calFilter(String enteredKeyword) {
    isApiCalling = false;
    setState(() {
      isApiCalling;
    });
    if (searchController.text.isEmpty) {
      isApiCalling = false;
      localSearchItemsList.clear();
      setState(() {
        spinnerItems.clear();
        dropdownValue = null;
        selectedIdx = -1;
        isApiCalling;
        selectedIssuer = null;
        localSearchItemsList;
        _IsSearching = false;
        _searchText = "";
        messageController.text = "";
      });
    } else {
      if (searchController.text.trim().length > 1) {
        //  if (previousText != _searchSpieViewUser.text) {
        if (_timer != null) {
          print("data++++++timer cancel");
          _timer.cancel();
        }
        isApiCalling = true;
        setState(() {});
        _timer = Timer(const Duration(milliseconds: 1000), () {
          print("data++++++apiCall");
          previousText = searchController.text;

          setState(() {
            selectedIssuer = null;
            selectedIdx = -1;
            localSearchItemsList.clear();
            messageController.text = "";
            isApiCalling;
            spinnerItems.clear();
            dropdownValue = null;
          });
          apiCallingForFrindList2(searchController.text.trim());
          setState(() {
            _IsSearching = true;
            _searchText = searchController.text;
          });
        });
        //  }
      } else {
        isApiCalling = false;
        setState(() {
          isApiCalling;
        });
      }
    }
    setState(() {});
  }

  Widget searchItemTile(BuildContext context, int index) {
    return Column(
      children: <Widget>[
        Container(
          height: 57,
          margin: const EdgeInsets.only(top: 4, bottom: 4),
          decoration: BoxDecoration(
              color: Color(0xffF6F7FC),
              border: Border.all(
                color: const Color(0xffE2E9FD),
              ),
              borderRadius: BorderRadius.circular(10)),
          child: GestureDetector(
            onTap: () {
              setState(() {
                isSelected = true;
                apiCallBadge(localSearchItemsList[index].userId);
                selectedIssuer = localSearchItemsList[index];
                searchController.text = localSearchItemsList[index].firstName;
                searchController.selection = TextSelection.collapsed(
                    offset: searchController.text.length);
                FocusManager.instance.primaryFocus?.unfocus();
                localSearchItemsList.clear();
              });
              onLoad();
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Center(
                    child: Container(
                        child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: ClipOval(
                            child: FadeInImage.assetNetwork(
                              fit: BoxFit.cover,
                              placeholder: "assets/profile/partner_img.png",
                              image: Constant.IMAGE_PATH +
                                  ParseJson.getMediumImage(
                                    localSearchItemsList[index].profilePicture,
                                  ),
                              width: 35,
                              height: 35,
                            ),
                          ),
                        ),
                      ),
                    )),
                  ),
                  flex: 0,
                ),
                Expanded(
                  child: PaddingWrap.paddingfromLTRB(
                      10.0,
                      0.0,
                      0.0,
                      0.0,
                      Text(localSearchItemsList[index].firstName,
                          textAlign: TextAlign.start,
                          maxLines: 5,
                          style: TextStyle(
                            color: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontSize: 16.0,
                            fontFamily: Constant.latoMedium,
                          ))),
                  flex: 1,
                ),
              ],
            ),
          ),
        ),
        index == localSearchItemsList.length - 1
            ? SizedBox(
                height: 0,
              )
            : Padding(
                padding: const EdgeInsets.only(top: 4.0, bottom: 4),
                child: Container(
                  height: 0.2,
                  color: Color(0xffD1D1D1),
                ),
              )
      ],
    );
  }
}
