import 'RequestResult.dart';

class SelfBadgeModel {
  String status;
  List<Result> result;

  SelfBadgeModel({this.status, this.result});

  SelfBadgeModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['result'] != null) {
      result = <Result>[];
      json['result'].forEach((v) {
        result.add(new Result.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.result != null) {
      data['result'] = this.result.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Result {
  String sId;
  int partnerRoleId;
  String type;
  bool isReminderEnable;
  bool isSecondaryEmail;
  int badgeReqId;
  int partnerId;
  int requestedBy;
  String message;
  String status;
  int date;
  String badgeImage;
  String badgeName;
  String issuerLogo;
  int issueDate;
  int iV;
  User user;
  User partner;
  String companyName;
  String profilePicture;

  Result(
      {this.sId,
        this.partnerRoleId,
        this.type,
        this.isReminderEnable,
        this.isSecondaryEmail,
        this.badgeReqId,
        this.partnerId,
        this.requestedBy,
        this.message,
        this.status,
        this.date,
        this.badgeImage,
        this.badgeName,
        this.issuerLogo,
        this.issueDate,
        this.iV,
        this.user,
        this.partner,
        this.companyName,
        this.profilePicture});

  Result.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    partnerRoleId = json['partnerRoleId'];
    type = json['type'];
    isReminderEnable = json['isReminderEnable'];
    isSecondaryEmail = json['isSecondaryEmail'];
    badgeReqId = json['badgeReqId'];
    partnerId = json['partnerId'];
    requestedBy = json['requestedBy'];
    message = json['message'];
    status = json['status'];
    date = json['date'];
    badgeImage = json['badgeImage'];
    badgeName = json['badgeName'];
    issuerLogo = json['issuerLogo'];
    issueDate = json['issueDate'];
    iV = json['__v'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
    partner =
    json['partner'] != null ? new User.fromJson(json['partner']) : null;
    companyName = json['companyName'];
    profilePicture = json['profilePicture'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['partnerRoleId'] = this.partnerRoleId;
    data['type'] = this.type;
    data['isReminderEnable'] = this.isReminderEnable;
    data['isSecondaryEmail'] = this.isSecondaryEmail;
    data['badgeReqId'] = this.badgeReqId;
    data['partnerId'] = this.partnerId;
    data['requestedBy'] = this.requestedBy;
    data['message'] = this.message;
    data['status'] = this.status;
    data['date'] = this.date;
    data['badgeImage'] = this.badgeImage;
    data['badgeName'] = this.badgeName;
    data['issuerLogo'] = this.issuerLogo;
    data['issueDate'] = this.issueDate;
    data['__v'] = this.iV;
    if (this.user != null) {
      data['user'] = this.user.toJson();
    }
    if (this.partner != null) {
      data['partner'] = this.partner.toJson();
    }
    data['companyName'] = this.companyName;
    data['profilePicture'] = this.profilePicture;
    return data;
  }
}

class User {
  String sId;
  String firstName;
  String lastName;
  int userId;
  String email;
  String profilePicture;
  int roleId;
  String  tagline;

  User(
      {this.sId,
        this.firstName,
        this.lastName,
        this.userId,
        this.email,
        this.profilePicture,
        this.roleId,
        this.tagline});

  User.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    userId = json['userId'];
    email = json['email'];
    profilePicture = json['profilePicture'];
    roleId = json['roleId'];
    tagline = json['tagline'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['firstName'] = this.firstName;
    data['lastName'] = this.lastName;
    data['userId'] = this.userId;
    data['email'] = this.email;
    data['profilePicture'] = this.profilePicture;
    data['roleId'] = this.roleId;
    data['tagline'] = this.tagline;
    return data;
  }
}