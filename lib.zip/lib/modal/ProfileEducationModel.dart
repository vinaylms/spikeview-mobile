import 'dart:io';

class ProfileEducationModal {
String educationId,organizationId,userId,institute,city,logo,fromGrade,toGrade,fromYear,toYear,description,isActive;
bool isBlurr = false;
ProfileEducationModal(this.educationId, this.organizationId, this.userId,
    this.institute, this.city, this.logo, this.fromGrade, this.toGrade,
    this.fromYear, this.toYear, this.description, this.isActive);


}


