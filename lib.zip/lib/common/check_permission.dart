import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/values/ColorValues.dart';

Future<void> checkStoragePermissionStorage(BuildContext context) async {

  showDialog(
      context: context,
      builder: (
          BuildContext context) =>
          CupertinoAlertDialog(
            title: Text(
                'Please allow access'),
            content:  RichText(
              maxLines: 2,
              textAlign: TextAlign.center,
              text: TextSpan(
                text: '',
                style:  TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16.0, fontWeight: FontWeight.bold,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                children: <TextSpan>[

                  TextSpan(
                      text: 'This app needs access storage on your device',

                      style:  TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR ,fontSize: 15.0,fontWeight: FontWeight.normal
                      )),

                ],
              ),
            ),
            actions: <
                Widget>[
              CupertinoDialogAction(
                child: Text(
                    'Deny'),
                onPressed: () =>
                    Navigator
                        .of(
                        context)
                        .pop(),
              ),
              CupertinoDialogAction(
                  child: Text(
                      'Settings'),
                  onPressed: ()  {
                    Navigator
                        .of(
                        context)
                        .pop();
                    openAppSettings();
                  }
              ),
            ],
          ));
}

Future<void> checkPermissionPhoto(BuildContext context) async {
  showDialog(
      context: context,
      builder: (
          BuildContext context) =>
          CupertinoAlertDialog(
             title: Text(
                'Please allow access'),
            content:  RichText(
              maxLines: 2,
              textAlign: TextAlign.center,
              text: TextSpan(
                text: '',
                style:  TextStyle(
                    color: ColorValues.HEADING_COLOR_EDUCATION,
                    fontSize: 16.0, fontWeight: FontWeight.bold,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                children: <TextSpan>[

                  TextSpan(
                      text: 'This app needs access to photos and camera roll',

                      style:  TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION,
                       fontFamily: Constant.TYPE_CUSTOMREGULAR ,fontSize: 15.0,fontWeight: FontWeight.normal
                      )),

                ],
              ),
            ),
            actions: <
                Widget>[
              CupertinoDialogAction(
                child: Text(
                    'Deny'),
                onPressed: () =>
                    Navigator
                        .of(
                        context)
                        .pop(),
              ),
              CupertinoDialogAction(
                child: Text(
                    'Settings'),
                onPressed: ()  {
                  Navigator
                      .of(
                      context)
                      .pop();
                  openAppSettings();
                }
              ),
            ],
          ));
}
