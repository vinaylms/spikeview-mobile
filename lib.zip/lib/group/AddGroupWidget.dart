import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/CustomFormField.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/group/InviteMember.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import 'GroupDetailWidget.dart';

// Create a Form Widget
class AddGroupWidget extends StatefulWidget {
  String sasToken, containerName;
  String pageName;

  AddGroupWidget(this.sasToken, this.containerName, this.pageName);

  @override
  AddGroupWidgetState createState() {
    return AddGroupWidgetState(sasToken, containerName);
  }
}

class AddGroupWidgetState extends State<AddGroupWidget> {
  SharedPreferences prefs;
  String userIdPref, roleId, token;
  final _formKey = GlobalKey<FormState>();
  File imagePathCover;
  String strAzureCoverImageUploadPath = "", strPrefixPathforCoverPhoto = "";
  String dob;
  int diffrenceInDob = 0;
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  static StreamController syncDoneController = StreamController.broadcast();

  AddGroupWidgetState(this.sasToken, this.containerName);

  Future callApiForSaas(isShowLoader) async {
    try {
      Response response = await ApiCalling2().apiCall(
        context,
        Constant.ENDPOINT_SAS,
        "post",
      );
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            sasToken = response.data['result']['sasToken'];
            containerName = response.data['result']['container'];
            if (containerName != null && containerName != "")
              Constant.CONTAINER_NAME = containerName;
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupBaseWidget", context);
      e.toString();
    }
  }

  TextEditingController groupNameController = TextEditingController(text: ""),
      aboutController = TextEditingController();
  bool allFieldCompleted=false;
  checkAllFieldSubmitted() {
    try {

      if (
      groupNameController.text.length > 0 &&
          aboutController.text.length > 0 ) {
        allFieldCompleted = true;
        setState(() {});
      } else {
        allFieldCompleted = false;
        setState(() {});
      }
    } catch (e) {
      print('++++++++error' + e.toString());
    }
  }


  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    dob = prefs.getString(UserPreference.DOB);
    int millis = int.tryParse(dob);
    DateTime dobDate = DateTime.fromMillisecondsSinceEpoch(millis);
    diffrenceInDob = Util.currentAge(dobDate, 13);
    setState(() {
      diffrenceInDob;
    });
    if (diffrenceInDob < 13) {
      isPrivate = true;
    }
    if (widget.sasToken == null || widget.sasToken == '') {
      callApiForSaas(false);
    }

    strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_FEED +
        "/";
  }

  String strGroupName, strAbout, strOtherInfo;
  bool isPrivate = false;

  void dialog(groupId) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_)
        {
          return ConfirmationDialog(
            //  headingText: 'Leave group',
            headingText: 'Now you can invite users to join your group.',
            negativeText: 'Invite later',
            positiveText: 'Invite now',
            isThreeStepPopup:true,
            positiveTextColor:AppConstants
                .colorStyle.lightBlue,
            onNegativeTap: () {
              Navigator.pop(context, "push");
            },
            onPositiveTap: (){
              List<MemberModelDetail>
              allMembersList = List();
              strAzureCoverImageUploadPath = "";
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                      builder:
                          (BuildContext context) =>
                          InviteMember(
                              groupId,
                              "add",
                              allMembersList)));
            },
          );
        });



/*
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 20.0,
                            left: 20.0,
                            bottom: 72.0,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              width: double.infinity,
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    top: 15.0, bottom: 15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15.0, right: 15),
                                        child: BaseText(
                                          text: 'Group created successfully',
                                          textColor:
                                              AppConstants.colorStyle.darkBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoMedium,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 16,
                                          textAlign: TextAlign.start,
                                          maxLines: 1,
                                        )),
                                    SizedBox(
                                      height: 7,
                                    ),
                                    Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15.0, right: 15),
                                        child: BaseText(
                                          text:
                                              'Now you can invite users to join your group.',
                                          textColor: AppConstants
                                              .colorStyle.lightPurple,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w400,
                                          fontSize: 14,
                                          textAlign: TextAlign.center,
                                          maxLines: 3,
                                        )),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 15.0, bottom: 15),
                                      child: Container(
                                        height: 1,
                                        color: AppConstants.colorStyle.btnBg,
                                      ),
                                    ),
                                    InkWell(
                                        onTap: () {
                                          List<MemberModelDetail>
                                              allMembersList = List();
                                          Navigator.pop(context);
                                          strAzureCoverImageUploadPath = "";
                                          Navigator.of(context).pushReplacement(
                                              MaterialPageRoute(
                                                  builder:
                                                      (BuildContext context) =>
                                                          InviteMember(
                                                              groupId,
                                                              "add",
                                                              allMembersList)));
                                        },
                                        child: BaseText(
                                          text: 'Invite now',
                                          textColor:
                                              AppConstants.colorStyle.lightBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          textAlign: TextAlign.start,
                                          maxLines: 1,
                                        )),
                                    *//*  Padding(
                                      padding: const EdgeInsets.only(
                                          top: 15.0, bottom: 15),
                                      child: Container(
                                        height: 1,
                                        color: AppConstants.colorStyle.btnBg,
                                      ),
                                    ),
                                    InkWell(
                                        onTap: () {
                                          Navigator.pop(context);
                                          Navigator.pop(context, "push");
                                        },
                                        child: BaseText(
                                          text: 'Invite later',
                                          textColor:
                                              AppConstants.colorStyle.lightBlue,
                                          fontFamily: AppConstants
                                              .stringConstant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          textAlign: TextAlign.start,
                                          maxLines: 1,
                                        )),*//*
                                  ],
                                ),
                              ),
                            )),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                20.0,
                                0.0,
                                20.0,
                                0.0,
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Center(
                                                    child: BaseText(
                                              text: 'Invite later',
                                              textColor: AppConstants
                                                  .colorStyle.darkBlue,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                              fontWeight: FontWeight.w500,
                                              fontSize: 16,
                                              textAlign: TextAlign.start,
                                              maxLines: 1,
                                            ))),
                                            onTap: () {
                                              Navigator.pop(context);
                                              Navigator.pop(context, "push");
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));*/
  }

  //--------------------------Api Calling ------------------
  Future apiCalling() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        String type = "public";
        if (isPrivate) type = "private";

        Map map = {
          "groupName": strGroupName,
          "type": type,
          "creationDate": DateTime.now().millisecondsSinceEpoch,
          "createdBy": int.parse(userIdPref),
          "isActive": true,
          "roleId": int.parse(roleId),
          "members": [
            {
              "userId": int.parse(userIdPref),
              "isAdmin": true,
              "status": "Accepted",
              "roleId": int.parse(roleId),
            }
          ],
          "aboutGroup": strAbout,
          "otherInfo": strOtherInfo,
          "groupImage": imagePathCover == null
              ? ""
              : strPrefixPathforCoverPhoto + strAzureCoverImageUploadPath
        };

        print("map++++" + map.toString());
        response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_ADD_GROUP, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              String groupId = response.data['groupId'].toString();
              syncDoneController.add("");
              // ToastWrap.showToast(msg);
              if (widget.pageName == "") {
                /*   Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                        builder: (BuildContext context) =>
                            GroupDetailWidget(groupId, "", "", "", "")));*/

                dialog(groupId);
              } else {
                Navigator.pop(context, {
                  'id': groupId,
                  'name': strGroupName,
                  'isPublic': !isPrivate
                });
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddGroupWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    getSharedPreferences();

    // TODO: implement initState
    super.initState();
  }

  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddGroupWidget", context);
      return "";
    }
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePathCover = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 1.0,
      ratioY: 1.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above
    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    Future getImageCover() async {
      imagePathCover = await UploadMedia(context).pickImageFromGallery();
      //   imagePathCover = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePathCover != null) {
        String strPath = imagePathCover.toString().substring(
            imagePathCover.toString().lastIndexOf("/") + 1,
            imagePathCover.toString().length);

        print("imagepath shubh" + strPath);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          print("img   :-" +
              imagePathCover
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim());
          if (imagePathCover != null) {
            await _cropImage(imagePathCover);

            setState(() {
              imagePathCover;
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    Widget imageSelectionView() {
      return SizedBox(
        width: 113.0,
        height: 113.0,
        child: Container(
          width: 113.0,
          height: 113.0,
          child: InkWell(
              child: Stack(
                children: <Widget>[



                  Positioned(
                    bottom: 5.0,

                    top: 0.0,

                    child:   Container(
                        width: 113.0,
                        height: 113.0,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(35),
                            border: Border.all(
                                color: Colors.white,
                                width: 2),
                            boxShadow: [
                              BoxShadow(
                                spreadRadius: 3,
                                blurRadius: 3,
                                offset: Offset(0, 2),
                                color: Color.fromRGBO(98, 175, 226, 0.15),
                              )
                            ]
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(35.0),
                          child:Image.asset(
                            "assets/newDesignIcon/group/default_circle_bg.png",
                          ),
                        )),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0, left: 73),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                        child: Image.asset("assets/png/edit1.png"),
                        height: 24.0,
                        width: 24,
                      ),
                    ),
                  )
                ],
              ),
              onTap: () async {
                var status = await Permission.photos.status;
                if (status.isGranted) {
                  getImageCover();
                } else {
                  checkPermissionPhoto(context);
                }
              }),
        ),
      );
    }

    Widget isImageSelectedView() {
      return SizedBox(
        width: 113.0,
        height: 113.0,
        child: Container(
          width: 113.0,
          height: 113.0,
          child: InkWell(
              child: Stack(
                children: <Widget>[
                  Align(
                      alignment: Alignment.center,
                      child: SizedBox(
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(35.0),
                            child: Container(
                                width: 113.0,
                                height: 113.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(35),
                                    border: Border.all(
                                        color: Colors.white, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 15,
                                        offset: Offset(2, 2),
                                        color:
                                            Color.fromRGBO(98, 175, 226, 0.09),
                                      )
                                    ]),
                                child: Image.file(
                                  imagePathCover,
                                ))),
                      )),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 2.0, left: 93),
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                        child: Image.asset("assets/png/edit.png"),
                        height: 24.0,
                        width: 24,
                      ),
                    ),
                  )
                ],
              ),
              onTap: () async {
                var status = await Permission.photos.status;
                if (status.isGranted) {
                  getImageCover();
                } else {
                  checkPermissionPhoto(context);
                }
              }),
        ),
      );

      return Container(
        width: 120.0,
        height: 120.0,
        child: InkWell(
            child: Stack(
              children: <Widget>[
                Positioned(
                  bottom: 5.0,
                  left: 0.0,
                  top: 0.0,
                  right: 0.0,
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(15.0),
                      child: Image.file(
                        imagePathCover,
                        fit: BoxFit.fill,
                      )),
                ),
                Positioned(
                    bottom: 12.0,
                    right: 12.0,
                    child: InkWell(
                      child: Container(
                        //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                        child: Image.asset("assets/png/edit.png"),
                        height: 24.0,
                        width: 24,
                      ),
                    ))
              ],
            ),
            onTap: () async {
              var status = await Permission.photos.status;
              if (status.isGranted) {
                getImageCover();
              } else {
                checkPermissionPhoto(context);
              }
            }),
      );

      return InkWell(
        child: ClipRRect(
            borderRadius: BorderRadius.circular(15.0),
            child: Center(
                child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
              ),
              width: 95,
              height: 95,
              child: ClipRRect(
                  borderRadius: BorderRadius.circular(15.0),
                  child: Image.file(
                    imagePathCover,
                    fit: BoxFit.fill,
                  )),
              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
            ))),
        onTap: () async {
          var status = await Permission.photos.status;
          if (status.isGranted) {
            getImageCover();
          } else {
            checkPermissionPhoto(context);
          }
        },
      );
    }

    final groupName = CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      controller: groupNameController,
      onType: (val) {
        checkAllFieldSubmitted();

      },
      onSaved: (val) => strGroupName = val,
      maxLength: TextLength.GROUP_NAME_MAX_LENGTH,
      label: 'Group name',
      validation: (val) => val.trim().isEmpty
          ? MessageConstant.ENTER_GROUP_NAME_VAL
          : val.trim().length < 3
              ? MessageConstant.ENTER_MIN_3_CHAR_VAL
              : null,
    );

    final aboutGroupUi = CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      onType: (val) {
        checkAllFieldSubmitted();
      },
      controller: aboutController,

      onSaved: (val) => strAbout = val,
      maxLength: 500,
      label: 'About group',
      minLines: 3,
      counterTextValue: true,
      maxLines: 3,
      validation: (val) =>
          val.trim().isEmpty ? MessageConstant.ENTER_GROUP_MOTIVE_VAL : null,
    );

    final otherInfoUi = CustomFormField(
      autovalidateMode: AutovalidateMode.disabled,
      textInputType: TextInputType.text,
      onType: (val) {},
      onSaved: (val) => strOtherInfo = val.trim(),
      maxLength: 500,
      minLines: 3,
      maxLines: 3,
      counterTextValue: true,
      label: 'Group rules',
    );

    void _checkValidation() async {
      final form = _formKey.currentState;
      form.save();
      if (form.validate()) {
        try {
          if (imagePathCover != null) {
            CustomProgressLoader.showLoader(context);

            Timer _timer = Timer(const Duration(milliseconds: 400), () async {
              strAzureCoverImageUploadPath = await uploadImgOnAzure(
                  imagePathCover
                      .toString()
                      .replaceAll("File: ", "")
                      .replaceAll("'", "")
                      .trim(),
                  strPrefixPathforCoverPhoto);
              apiCalling();
            });

            // organizationApi();
          } else {
            CustomProgressLoader.showLoader(context);
            apiCalling();
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e, "AddGroupWidget", context);
          CustomProgressLoader.cancelLoader(context);
        }
      } else {
        print("Failure 00");
      }
    }

    final submitButton = Padding(
        padding: EdgeInsets.only(left: 0.0, top: 30.0, right: 0.0, bottom: 0.0),
        child: Container(
            height: 50.0,
            child: FlatButton(
              onPressed: _checkValidation,
              color: ColorValues.BLUE_COLOR,
              child: Row(
                // Replace with a Row for horizontal icon + text
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    MessageConstant.ABOUT_GROUP_SAVE,
                    style: AppTextStyle.getDynamicStyleGroup(
                        ColorValues.WHITE,
                        null,
                        FontType
                            .Bold), /*TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMBOLD, color: Colors.white)*/
                  ),
                ],
              ),
            )));

    final cancelButton = Padding(
        padding: EdgeInsets.only(left: 5.0, top: 30.0, right: 0.0, bottom: 0.0),
        child: Container(
            height: 50.0,
            child: FlatButton(
              onPressed: () {},
              color: Colors.red,
              child: Row(
                // Replace with a Row for horizontal icon + text
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    MessageConstant.ABOUT_GROUP_DELETE,
                    style: AppTextStyle.getDynamicStyleGroup(
                        ColorValues.WHITE,
                        null,
                        FontType
                            .Bold), /*TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMBOLD, color: Colors.white)*/
                  ),
                ],
              ),
            )));

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child: customAppbar(
            context,
            GestureDetector(
                onTap: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20, top: 24, bottom: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            BaseText(
                              text: 'Create group',
                              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily:
                                  AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w700,
                              fontSize: 28,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            ),

                            SizedBox(
                              height: 5,
                            ),
                            diffrenceInDob < 13
                                ? BaseText(
                              text:
                              MessageConstant
                                  .UNDER_13_GROUP_MSG,
                              textColor: AppConstants.colorStyle.lightPurple,
                              fontFamily: AppConstants.stringConstant.latoMedium,
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              textAlign: TextAlign.start,
                              maxLines: 3,
                            )
                                : SizedBox(),



                          ],
                        ),
                      ),
                      flex: 0,
                    ),
                    Expanded(
                      child: ListView(
                        padding: EdgeInsets.all(0),
                        children: <Widget>[
                          Form(
                            key: _formKey,
                            child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 20.0, right: 20, top: 0, bottom: 0),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[


        Padding(
            padding: const EdgeInsets.only(top:28.0),
            child:  Center(
                                        child: SizedBox(
                                          width: 115,
                                          height: 115,
                                          child: InkWell(
                                            child: Stack(
                                              children: <Widget>[

                                                Container(
                                                    width: 113.0,
                                                    height: 113.0,
                                                    decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(35),
                                                        border: Border.all(
                                                            color: Colors.white,
                                                            width: 1),
                                                        boxShadow: [
                                                          BoxShadow(
                                                            spreadRadius: 1,
                                                            blurRadius: 2,
                                                            offset: Offset(0, 2),
                                                            color: Color.fromRGBO(98, 175, 226, 0.15),
                                                          )
                                                        ]
                                                    ),
                                                    child: ClipRRect(
                                                      borderRadius: BorderRadius.circular(35.0),
                                                      child:imagePathCover != null
                                                          ? Image.file(
                                                        imagePathCover,
                                                        width: 113.0,
                                                        height: 113.0,
                                                        fit: BoxFit.cover,
                                                      )
                                                          : Container(
                                                          width: 113.0,
                                                          height: 113.0,
                                                          decoration: BoxDecoration(
                                                              borderRadius: BorderRadius.circular(35),
                                                              border: Border.all(
                                                                  color: Colors.white,
                                                                  width: 2),
                                                              boxShadow: [
                                                                BoxShadow(
                                                                  spreadRadius: 3,
                                                                  blurRadius: 3,
                                                                  offset: Offset(0, 2),
                                                                  color: Color.fromRGBO(98, 175, 226, 0.15),
                                                                )
                                                              ]
                                                          ),
                                                          child: ClipRRect(
                                                            borderRadius: BorderRadius.circular(35.0),
                                                            child:Image.asset(
                                                              "assets/newDesignIcon/group/default_circle_bg.png",
                                                            ),
                                                          )),
                                                    )),




                                                Positioned(
                                                  bottom: 12.0,
                                                  right: 12.0,
                                                  child: Image.asset(
                                                    imagePathCover == null
                                                        ?  "assets/png/edit1.png":'assets/png/edit.png',
                                                    height: 24,
                                                    width: 24,
                                                  ),
                                                )
                                              ],
                                            ),
                                            onTap: () async{
                                              var status = await Permission.photos.status;
                                              if (status.isGranted) {
                                                getImageCover();
                                              } else {
                                                checkPermissionPhoto(context);
                                              }
                                            },
                                          ),
                                        ),
                                      )),

                                     /* Padding(
                                        padding: const EdgeInsets.only(top:28.0),
                                        child: Center(
                                          child: Container(
                                              width: double.infinity,
                                              child: imagePathCover == null
                                                  ? imageSelectionView()
                                                  : isImageSelectedView()),
                                        ),
                                      ),*/
                                      diffrenceInDob < 13
                                          ? Container(
                                              height: 0.0,
                                            )
                                          : PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              28.0,
                                              0.0,
                                              0.0,
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Container(
                                                        //width: MediaQuery.of(context).size.width*0.45,
                                                        child: Text(
                                                          'Public group',
                                                          maxLines: 1,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                            color: !isPrivate
                                                                ? ColorValues
                                                                    .WHITE
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue,
                                                            fontSize: 16,
                                                           /* fontWeight:
                                                                FontWeight.w600,*/
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoRegular,
                                                          ),
                                                        ),
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 9,
                                                                bottom: 9,
                                                                left: 9,
                                                                right: 9),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: !isPrivate
                                                              ? ColorValues
                                                                  .DARK_YELLOW
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .tabBg,
                                                          border: Border.all(
                                                              color: !isPrivate
                                                                  ? ColorValues
                                                                      .DARK_YELLOW
                                                                  : AppConstants
                                                                      .colorStyle
                                                                      .borderGenerateScript),
                                                          borderRadius:
                                                              const BorderRadius
                                                                      .only(
                                                                  topLeft: Radius
                                                                      .circular(
                                                                          10),
                                                                  bottomLeft: Radius
                                                                      .circular(
                                                                          10)),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        setState(() {
                                                          isPrivate = false;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                  Expanded(
                                                    child: InkWell(
                                                      child: Container(
                                                        //width: MediaQuery.of(context).size.width*0.45,
                                                        child: Text(
                                                          'Private group',
                                                          maxLines: 1,
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: TextStyle(
                                                            color: isPrivate
                                                                ? ColorValues
                                                                    .WHITE
                                                                : AppConstants
                                                                    .colorStyle
                                                                    .darkBlue,
                                                            fontSize: 16,
                                                            /*fontWeight:
                                                                FontWeight.w600,*/
                                                            fontFamily: AppConstants
                                                                .stringConstant
                                                                .latoRegular,
                                                          ),
                                                        ),
                                                        padding:
                                                            EdgeInsets.only(
                                                                top: 9,
                                                                bottom: 9,
                                                                left: 9,
                                                                right: 9),
                                                        decoration:
                                                            BoxDecoration(
                                                          color: isPrivate
                                                              ? ColorValues
                                                                  .DARK_YELLOW
                                                              : AppConstants
                                                                  .colorStyle
                                                                  .tabBg,
                                                          border: Border.all(
                                                              color: AppConstants
                                                                  .colorStyle
                                                                  .borderGenerateScript),
                                                          borderRadius:
                                                              const BorderRadius
                                                                      .only(
                                                                  topRight: Radius
                                                                      .circular(
                                                                          10),
                                                                  bottomRight:
                                                                      Radius.circular(
                                                                          10)),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        setState(() {
                                                          isPrivate = true;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 24.0, 0.0, 0.0, groupName),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 20.0, 0.0, 0.0, aboutGroupUi),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0, 0.0, 0.0, 30.0, otherInfoUi),
                                    ])),
                          )
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                )), () {
          Navigator.pop(context);
        },
            isShowIcon: false,
            bottomNavigation: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: AppConstants.colorStyle.white,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0x75CCDCF7),
                        blurRadius: 13,
                        spreadRadius: 13,
                      )
                    ],
                  ),
                  child: PaddingWrap.paddingfromLTRB(
                    20.0,
                    20.0,
                    20.0,
                    20.0,
                    InkWell(
                      child: Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: AppConstants.colorStyle.lightBlue,
                            border: Border.all(
                                color: AppConstants.colorStyle.lightBlue),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Create",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.WHITE,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontSize: 18.0,
                                ),
                              ))),
                      onTap: () async {
                        _checkValidation();
                      },
                    ),
                  ),
                ),

                allFieldCompleted
                    ? SizedBox(
                  height: 0,
                )
                    : Container(
                  height: 75.0,
                  width: double.infinity,
                  color: Colors.white.withOpacity(0.75),
                )
              ],
            )));
  }
}
