class DesignationModelParam {
  bool isOther;
  String name;
  int categoryId;

  DesignationModelParam({this.name, this.categoryId, this.isOther});

  static Map<String, dynamic> toMap(DesignationModelParam categoryObject) {
    Map<String, dynamic> categoryMap = Map();
    categoryMap['name'] = categoryObject.name;
    categoryMap['categoryId'] = categoryObject.categoryId;
    categoryMap['isOther'] = categoryObject.isOther;
    return categoryMap;
  }

  String toMapString() {
    String data = "";

    data = data + this.name;

    return data;
  }

  static List<Map<String, dynamic>> mapList(
      List<DesignationModelParam> categories) {
    List<Map<String, dynamic>> listOfCategory = categories
        .map((category) => {
              "name": category.name,
              "categoryId": category.categoryId,
              "isOther": category.isOther,
            })
        .toList();
    return listOfCategory;
  }
}
