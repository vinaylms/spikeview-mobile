import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parentProfile/wizard/CompletedWizard.dart';
import 'package:spike_view_project/parentProfile/wizard/AddChildOtherInterestWidget.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/profile/studentWizard/CompletedStudentWizard.dart';

import 'package:spike_view_project/profile/studentWizard/SkillSelectionWiget.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';
import 'package:spike_view_project/skill/model/SkillModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';

import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
//import 'package:spike_view_project/modal/SavedInterestListModel.dart';

// Create a Form Widget
class AddChildFutureGoalWidget extends StatefulWidget {
  //ProfileInfoModal profileInfoModal;
  StudentDataModel studModel;
  String pageName;
  String sasToken;
  int stage;

  AddChildFutureGoalWidget(
      this.studModel, this.pageName, this.sasToken, this.stage);

  @override
  AddChildFutureGoalWidgetState createState() {
    return  AddChildFutureGoalWidgetState();
  }
}

class AddChildFutureGoalWidgetState extends State<AddChildFutureGoalWidget>
    with BaseCommonWidget {
  final _formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, token;

  SkillModel _skillModel =  SkillModel();

  List<SkillData> selectedLoveInterestsList =  List<SkillData>();

  String strOtherInterest = '';

  TextEditingController instituteController =
       TextEditingController(text: "");
  String popString = '';
  String strInstitute = '';
  final FocusNode _otherInterestFocus = FocusNode();

  SkillIntrestDataModel widgetSkillModel =  SkillIntrestDataModel();

  bool isOptionClicked = false;

  int optionCount = 0;

  Color bottomViewColor = Palette.dividerColor;

  bool showList = false;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();

  bool isNeedCounselorYes = false;
  bool isNeedCounselorNo = false;

  bool isNotShare = false;
  bool isNo = false;
  bool isYes = false;

  TextEditingController _textFieldController =
       TextEditingController(text: "");
  final FocusNode _textFieldFocus = FocusNode();

  List<SkillData> _searchedUniversityList =  List<SkillData>();

  List<String> selectedUniversityOption = [];

  List<SkillData> _universityList =  List();

  List<SkillData> removedUniversiyList =  List<SkillData>();
  List<SkillData> origanalUniversiyList =  List<SkillData>();

  int listIndexFrom = 0;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_WIZARD_USERID);
    token = prefs.getString(UserPreference.USER_TOKEN);
    print('inside getSharedPreferences() EditInterest');
    print(
        'inside getSharedPreferences() student id 111:: ${prefs.getString(UserPreference.PARENT_WIZARD_USERID)}');
    print(
        'inside getSharedPreferences() student id 222:: ${prefs.getString(UserPreference.USER_ID)}');
    print(
        'inside getSharedPreferences() student id 333:: ${widget.studModel.userId}');
    print(
        'inside getSharedPreferences() student roleid 333:: ${widget.studModel.roleId}');

    await apiCallForSkill(context);
    await callLoveInterestApi();
  }

  //=========================================================Api Calling =======================================

  Future<String> callLoveInterestApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling().apiCall(context,
            Constant.ENDPOINT_GET_HOBBY_TYPE_API + "major_interests", "get");
        print("Love Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _skillModel =  SkillModel.fromJson(response.data);
              print(
                  'setdata _skillModel.skillList 111 size::: ${_skillModel.skillList.length}');

              try {
                _universityList = _skillModel.skillList;
                _searchedUniversityList = _universityList;
                /*_searchedUniversityList.clear();
                _searchedUniversityList.addAll(_skillModel.skillList.sublist(0, 10));
                listIndexFrom = 10;*/

                for (Skills skills
                    in widgetSkillModel.result[0].majorInterests) {
                  selectedUniversityOption.add(skills.name);
                }
                //selectedUniversityOption.addAll(widgetSkillModel.result[0].goalUniversities);

                if (_universityList != null && _universityList.isNotEmpty) {
                  origanalUniversiyList.addAll(_universityList);
                  for (Skills selectedOption
                      in widgetSkillModel.result[0].majorInterests) {
                    if (selectedOption.hobbyId != "" &&
                        selectedOption.hobbyId != null &&
                        selectedOption.hobbyId.toString() != 'null') {
                      for (var universityResultModel in origanalUniversiyList) {
                        print(
                            'universityResultModel:::::: ${universityResultModel.name}');
                        if (selectedOption.name.toString() ==
                            universityResultModel.name.toString()) {
                          removedUniversiyList.add(SkillData(
                              //sId: universityResultModel.sId,
                              name: universityResultModel.name,
                              hobbyId: universityResultModel.hobbyId));

                          selectedLoveInterestsList.add(SkillData(
                              name: universityResultModel.name,
                              hobbyId: universityResultModel.hobbyId));
                        }
                      }
                    } else {
                      selectedLoveInterestsList.add(SkillData(
                        name: selectedOption.name.toString(),
                      ));
                    }
                  }
                }

                print(
                    'selectedUniversityOption length:: ${selectedUniversityOption.length}');
                print('_universityList length:: ${_universityList.length}');
                print(
                    'origanalUniversiyList length:: ${origanalUniversiyList.length}');
                print(
                    'removedUniversiyList length:: ${removedUniversiyList.length}');

                //if (removedUniversiyList.length > 0) {
                _universityList.clear();
                //}
                print('_universityList length 111:: ${_universityList.length}');
                for (final e in origanalUniversiyList) {
                  bool found = false;
                  for (final f in removedUniversiyList) {
                    if (e.hobbyId.toString() == f.hobbyId.toString()) {
                      found = true;
                      break;
                    }
                  }
                  if (!found) {
                    _universityList.add(e);
                  }
                }
                print('_universityList length 222:: ${_universityList.length}');
                print(
                    'selectedLoveInterestsList length 222:: ${selectedLoveInterestsList.length}');
                //add data to re

                setState(() {
                  _universityList;
                  _searchedUniversityList;
                  removedUniversiyList;
                  origanalUniversiyList;
                  selectedUniversityOption;
                  selectedLoveInterestsList;
                });
              } catch (e) {
                print(
                    'inside ENDPOINT_universities_list catch error:: ${e.toString()}');
              }
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      e.toString();
    }
  }

  Future<String> apiCallForSkill(context) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling().apiCall(context,
            Constant.ENDPOINT_GET_SKILL_API + userIdPref + "&roleId=1", "get");
        print("Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widgetSkillModel =
                   SkillIntrestDataModel.fromJson(response.data);
              setState(() {
                _skillModel;
                widgetSkillModel;
                selectedLoveInterestsList;
                if (widgetSkillModel != null) {
                  print(
                      'widgetSkillModel.result[0].goalInterestInstitute:: ${widgetSkillModel.result[0].goalInterestInstitute}');
                  if (widgetSkillModel.result[0].goalInterestInstitute !=
                          null &&
                      widgetSkillModel.result[0].goalInterestInstitute != "" &&
                      widgetSkillModel.result[0].goalInterestInstitute !=
                          "null") {
                    instituteController.text =
                        widgetSkillModel.result[0].goalInterestInstitute;
                    strInstitute =
                        widgetSkillModel.result[0].goalInterestInstitute;
                  }

                  //to init needCounselor
                  if (widgetSkillModel.result[0].needCounselor != null) {
                    isNeedCounselorYes = false;
                    isNeedCounselorNo = false;
                    if (widgetSkillModel.result[0].needCounselor) {
                      isNeedCounselorYes = true;
                    } else {
                      isNeedCounselorNo = true;
                    }
                  }

                  //to init financialSupport
                  if (widgetSkillModel.result[0].financialSupport != null) {
                    //isYes ? "Yes" : isNo ? "No" : "Notshare" ,
                    isYes = false;
                    isNotShare = false;
                    isNo = false;
                    if (widgetSkillModel.result[0].financialSupport == 'Yes')
                      isYes = true;
                    else if (widgetSkillModel.result[0].financialSupport ==
                        'No')
                      isNo = true;
                    else if (widgetSkillModel.result[0].financialSupport ==
                        'Notshare') isNotShare = true;
                    /*setState(() {
                      isYes;
                      isNo;
                      isNotShare;
                    });*/
                  }

                  //

                }
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Edit Data ------------------

  Future editInterest(String navigateTo) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //  CustomProgressLoader.showLoader(context);

        //await getSelectedData();

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": 1, //int.parse(widget.studModel.roleId),
          "major_interests":
              selectedLoveInterestsList.map((item) => item.toJson()).toList(),
          "financialSupport": isYes
              ? "Yes"
              : isNo
                  ? "No"
                  : "Notshare",
          "needCounselor": isNeedCounselorYes,
        };

        print("map+++" + map.toString());
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_SKILL_API, map);
        print("response:-" + response.toString());
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                popString = "push";
                //Navigator.pop(context, popString);
                print('Data updated successfully');
                if (navigateTo == 'next') {
                  onTapNextPage();
                } else
                  onTapPrePage();
              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } catch (e) {}
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    try {
      getSharedPreferences();
    } catch (e) {
      print(e.toString());
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    void conformationForSkip() {
      showDialog(
          barrierDismissible: false,
          context: context,
          builder: (_) =>  WillPopScope(
              onWillPop: () {
                Navigator.pop(context);
              },
              child:  SafeArea(
                  child:  Scaffold(
                      backgroundColor: Colors.black38,
                      body:  Stack(
                        children: <Widget>[
                           Positioned(
                              right: 0.0,
                              left: 0.0,
                              bottom: 40.0,
                              child:  Container(
                                  height: 200.0,
                                  color: Colors.transparent,
                                  child:  Stack(
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          13.0,
                                          20.0,
                                          13.0,
                                          0.0,
                                          ListView(children: <Widget>[
                                             Container(
                                              height: 145.0,
                                              padding:  EdgeInsets.all(10.0),
                                              width: double.infinity,
                                              color: Colors.white,
                                              child:  Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: <Widget>[
                                                     Text(
                                                      "Are you sure you want to skip this step?",
                                                      textAlign:
                                                          TextAlign.center,
                                                      maxLines: 5,
                                                      style:  TextStyle(
                                                          color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                          height: 1.2,
                                                          fontSize: 16.0,
                                                          fontFamily:
                                                              Constant.TYPE_CUSTOMREGULAR),
                                                    ),
                                                  ]),
                                            )
                                          ])),
                                    ],
                                  ))),
                           Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 10.0,
                            child:  Align(
                              alignment: Alignment.bottomCenter,
                              child: PaddingWrap.paddingfromLTRB(
                                  13.0,
                                  0.0,
                                  13.0,
                                  0.0,
                                   Container(
                                      color: Colors.white,
                                      padding:  EdgeInsets.all(10.0),
                                      height: 51.0,
                                      child:  Row(
                                        children: <Widget>[
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Cancel",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.GREY_TEXT_COLOR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            flex: 1,
                                          ),
                                           Expanded(
                                            child:  InkWell(
                                              child:  Container(
                                                  child:  Text(
                                                "Skip",
                                                textAlign: TextAlign.center,
                                                style:  TextStyle(
                                                    color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                    fontSize: 16.0,
                                                    fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                              )),
                                              onTap: () {
                                                Navigator.pop(context);
                                                onTapNextPage();
                                              },
                                            ),
                                            flex: 1,
                                          )
                                        ],
                                      ))),
                            ),
                          ),
                        ],
                      )))));
    }

    final double statusBarHeight = MediaQuery.of(context).padding.top;

    //-------------------------------------Main Ui ------------------------------------------
    return  WillPopScope(
      onWillPop: () {
        Navigator.pop(context, popString);
      },
      child:  GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child:  Scaffold(
              backgroundColor:  ColorValues.SCREEN_BG_COLOR,
              //backgroundColor:  Color(0XFFF4F2F2),

              body: Stack(
                children: <Widget>[
                   Positioned(
                    bottom: 65.0,
                    right: 0.0,
                    left: 0.0,
                    top: 0.0,
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.only(
                                top: statusBarHeight + 20,
                                left: 13.0,
                                right: 13.0,
                                bottom: 7),
                            child: Center(
                              child:  Image.asset(
                                  "assets/progress_indecator/indicator_step7.png",
                                  height: 26.0,
                                  width: 300.0,
                                  fit: BoxFit.fitWidth),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(top: 20, right: 13),
                            child:  Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                 Text(
                                  //"Step 7 of 7",
                                  "",
                                  style:  TextStyle(
                                      fontSize: 15.0,
                                      fontFamily: Constant.customRegular,
                                      color:  ColorValues.HEADING_COLOR_EDUCATION),
                                ),
                                InkWell(
                                  child:  Text(
                                    "SKIP ",
                                    style:  TextStyle(
                                        fontSize: 14.0,
                                        fontFamily: Constant.customRegular,
                                        color:  ColorValues.GREY_TEXT_COLOR),
                                  ),
                                  onTap: () {
                                    //onTapNextPage();
                                    if (isOptionClicked)
                                      conformationForSkip();
                                    else
                                      onTapNextPage();
                                  },
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 10.0,
                            ),
                            child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Center(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            0.0, 12, 0, 5),
                                        child:  Image.asset(
                                            "assets/story_new/add_goal.png",
                                            height: 50.0,
                                            width: 50.0,
                                            fit: BoxFit.fitHeight),
                                      ),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          5.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Almost done",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              18.0,
                                              FontWeight.bold,
                                              3)),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          20.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Just a few more questions about your child's future plans.",
                                              TextAlign.center,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              14.0,
                                              FontWeight.normal,
                                              4)),

                                      //==========
                                    ],
                                  ),
                                ),
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    0.0,
                                    13.0,
                                    0.0,
                                    TextViewWrap.textViewMultiLine(
                                        "What do they want to study (major)?",
                                        TextAlign.start,
                                         ColorValues.HEADING_COLOR_EDUCATION,
                                        16.0,
                                        FontWeight.bold,
                                        3)),
                                /*PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    0.0,
                                    13.0,
                                    0.0,
                                    TextViewWrap.textViewMultiLine(
                                        "Add Major of interest in which you want to go in future",
                                        TextAlign.start,
                                         ColorValues.HEADING_COLOR_EDUCATION,
                                        12.0,
                                        FontWeight.normal,
                                        3)),*/
                                _skillModel != null
                                    ? Padding(
                                        padding: const EdgeInsets.only(
                                          right: 13.0,
                                          left: 13.0,
                                        ),
                                        child: collegeDropdownView())
                                    : Container(
                                        height: 0.0,
                                      ),
                                selectedLoveInterestsList != null &&
                                        selectedLoveInterestsList.length > 0
                                    ? Padding(
                                        padding: const EdgeInsets.only(
                                            right: 13.0, left: 13.0, top: 5.0),
                                        child: getUniversitySelectedChips(
                                            selectedLoveInterestsList, true),
                                      )
                                    : Container(
                                        width: 0,
                                        height: 0,
                                      ),
                                Container(
                                  height: 15.0,
                                ),
                                /*  selectedLoveInterestsList.length>0?     Divider(
                                  color:  ColorValues.GREY__COLOR_DIVIDER,
                                ): Container(
                                  height: 0.0,
                                ),*/
                                Padding(
                                  padding: const EdgeInsets.only(
                                    right: 13.0,
                                    left: 13.0,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          15.0,
                                          0.0,
                                          15.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Will they need financial support?",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              16.0,
                                              FontWeight.bold,
                                              3)),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isYes
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "Yes",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isYes = true;
                                                isNo = false;
                                                isNotShare = false;
                                              });
                                            },
                                          ),
                                          Container(
                                            width: 11,
                                            height: 0,
                                          ),
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNo
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "No",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isYes = false;
                                                isNo = true;
                                                isNotShare = false;
                                              });
                                            },
                                          ),
                                          Container(
                                            width: 11,
                                            height: 0,
                                          ),
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNotShare
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "Don't want to share",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isYes = false;
                                                isNo = false;
                                                isNotShare = true;
                                              });
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 15.0,
                                ),
                                 Divider(
                                  color:  ColorValues.GREY__COLOR_DIVIDER,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    right: 13.0,
                                    left: 13.0,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          15.0,
                                          0.0,
                                          15.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Will they need a counselor?",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              16.0,
                                              FontWeight.bold,
                                              3)),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNeedCounselorYes
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "Yes",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isNeedCounselorYes = true;
                                                isNeedCounselorNo = false;
                                              });
                                            },
                                          ),
                                          Container(
                                            width: 11,
                                            height: 0,
                                          ),
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNeedCounselorNo
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "No",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isNeedCounselorYes = false;
                                                isNeedCounselorNo = true;
                                              });
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                   Positioned(
                      bottom: 0.0, left: 0, right: 0, child: getBottomBar())
                ],
              ))),
    );
  }

  getInstituteTextField() {
    return  Container(
        padding:  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
        margin: EdgeInsets.all(0.0),
        child:  TextFormField(
          enabled: optionCount > 0 ? true : false,
          keyboardType: TextInputType.text,
          controller: instituteController,
          maxLength: TextLength.TESTSCORE_DESC_MAX_LENGTH,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          maxLines: null,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(
              0.0,
              5.0,
              5.0,
              5.0,
            ),
            counterText: "",errorStyle:Util.errorTextStyle,
            labelText: "Add Institute",
            enabledBorder: UnderlineInputBorder(
              borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: ColorValues.DARK_GREY, width: 1.0)),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            hintText: "UT Austin, MIT",
            hintStyle:  TextStyle(
                color:  ColorValues.hintColor,
                fontFamily: Constant.TYPE_CUSTOMREGULAR,
                fontSize: 13),
            fillColor: Colors.transparent,
          ),
          /*validator: (val) =>
          val.trim().isEmpty ? MessageConstant.ENTER_INTEREST_INSTITUTE_VAL : null,*/
          onSaved: (val) => strInstitute = val.trim(),
        ));
  }

  Future apiCallWizardCompleted() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await  ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_COMPLETED_WIZARD +
              prefs.getString(UserPreference.PARENT_WIZARD_USERID),
          "get",
        );
        print("wizardapi" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            widget.studModel.isWizardCompleted = "true";
            setState(() {
              widget.studModel.isWizardCompleted = "true";
            });
            apiCallingUpdate();
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //As per student apurva added new
  Future wizardCompleted() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        response = await  ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_WELCOME_EMAIL + widget.studModel.userId + "/1",
            "get");

        print(Constant.ENDPOINT_WELCOME_EMAIL + widget.studModel.userId);
        print("profile+++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              widget.studModel.isWizardCompleted = "true";
              setState(() {
                widget.studModel.isWizardCompleted = "true";
              });
              Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) =>
                       CompletedWizard(widget.studModel.userId)));
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {}
  }

  Future<void> onTapNextPage() async {
    /*Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         CompletedWizard(widget.studModel.userId)));
        */

    apiCallWizardCompleted();
  }

  Future<void> onTapPrePage() async {
    //String result = await
    /*Navigator.of(context).pushReplacement(new MaterialPageRoute(
        builder: (BuildContext context) =>
         AddChildStudentOtherInterestWidget(widget.studModel, '', widget.sasToken,widget.stage)));*/

    Navigator.pop(context);
  }

  Future apiCallingUpdate() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;
        try {
          Map map = {"userId": userIdPref, "stage": "8"};
          response = await  ApiCalling().apiCallPutWithMapData(
              context, Constant.ENDPOINT_UPDATE_STAGE, map);
          CustomProgressLoader.cancelLoader(context);
        } catch (e) {
          CustomProgressLoader.cancelLoader(context);
        }
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              //do code here
              //await apiCallWizardCompleted();
              //await wizardCompleted();

              Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) =>
                       CompletedWizard(widget.studModel.userId)));
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  Container getBottomBar() {
    return  Container(
        child:  Row(
      children: <Widget>[
         InkWell(
          child:  Padding(
              padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
              child: Image.asset(
                'assets/newDesignIcon/parentProfile/backword.png',
                height: 45.0,
                width: 45.0,
              )),
          onTap: () {
            //  editInterest('previous');
            onTapPrePage();
          },
        ),
         Expanded(
          child:  InkWell(
            child:  Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 10.0),
                child:  Text(
                  "",
                  style: TextStyle(
                      fontSize: 16.0,
                      fontFamily: Constant.customRegular,
                      color: ColorValues.GREY_TEXT_COLOR),
                  textAlign: TextAlign.center,
                )),
            onTap: () {
              // skipOnClick();
            },
          ),
          flex: 1,
        ),
        selectedLoveInterestsList.length > 0
            ?  InkWell(
                child:  Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                    child: Image.asset(
                      'assets/newDesignIcon/parentProfile/next.png',
                      height: 45.0,
                      width: 45.0,
                    )),
                onTap: () {
                  editInterest('next');
                },
              )
            :  Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                child: Image.asset(
                  'assets/newDesignIcon/parentProfile/next_gray.png',
                  height: 45.0,
                  width: 45.0,
                ))
      ],
    ));
  }

  collegeDropdownView() {
    return Padding(
      padding: const EdgeInsets.only(right: 0.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: bottomBorderDynamic(bottomViewColor),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                /*selectedLoveInterestsList.length > 0
                    ? PaddingWrap.paddingfromLTRB(
                    0.0,
                    15.0,
                    0.0,
                    0.0,
                    TextViewWrap.textViewMultiLine(
                        "Add your interest",
                        TextAlign.start,
                         ColorValues.GREY__COLOR,
                        14.0,
                        FontWeight.normal,
                        3))
                    : Container(),*/
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              showList = !showList;
                            });
                          },
                          child: TextField(
                              controller: _textFieldController,
                              style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              //autofocus: true,
                              onChanged: (value) {
                                //print('onChanged called... text:: ${_textFieldController.text}');
                                callListSearch();
                              },
                              onEditingComplete: () {
                                setState(() {});
                              },
                              textInputAction: TextInputAction.done,
                              focusNode: _textFieldFocus,
                              autocorrect: false,
                              onSubmitted: (term) {
                                ///////////////
                                _textFieldFocus.unfocus();
                                if (_textFieldController.text != null &&
                                    _textFieldController.text != "") {
                                  if (!findPersonUsingWhere(
                                      _textFieldController.text)) {
                                    selectedUniversityOption
                                        .add(_textFieldController.text);
                                    selectedLoveInterestsList.add(SkillData(
                                        name:
                                            _textFieldController.text.trim()));
                                    //removedUniversiyList.add(SkillData(name: _textFieldController.text.trim()));
                                  }
                                }

                                _textFieldController.clear();
                                setState(() {
                                  selectedUniversityOption;
                                  selectedLoveInterestsList;
                                  _universityList;
                                  _searchedUniversityList = _universityList;
                                  showList = false;
                                });
                              },
                              cursorColor: Constant.CURSOR_COLOR,
                              decoration:  InputDecoration(
                                contentPadding: const EdgeInsets.fromLTRB(
                                    0.0, 5.0, 5.0, 5.0),
                                border: InputBorder.none,
                                /*hintText: selectedLoveInterestsList //spikeViewUserList //selectedUniversityOption
                                    .length ==
                                    0
                                    ? 'Add your interest' : "",
                                //: '${selectedUniversityOption[selectedUniversityOption.length - 1]}',*/
                                labelText: "Add your interest",
                                labelStyle:  TextStyle(
                                    fontSize: 16.0,
                                    color:  ColorValues.GREY__COLOR,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              ))),
                    ),
                    IconButton(
                      onPressed: () {
                        showList = !showList;
                        setState(() {});
                      },
                      icon: Padding(
                        padding: const EdgeInsets.only(left: 15.0, top: 0),
                        child: Icon(showList
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down),
                      ),
                    ),
                  ],
                ),
                /*selectedOtherOption.length > 0
                              ? selectOtherCategoryTextField()
                              : Container(),*/
              ],
            ),
          ),
          _skillModel.skillList != null && _skillModel.skillList.length > 0
              /*&& selectedLoveInterestsList.length !=
                      _skillModel.skillList.length*/
              ? universityListWidget()
              : Container(),
        ],
      ),
    );
  }

  universityListWidgetOld() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? _searchedUniversityList.length > 0
                ? Container(
                    height: _searchedUniversityList.length == 1
                        ? 50.0
                        : _searchedUniversityList.length == 2
                            ? 90.0
                            : _searchedUniversityList.length == 3
                                ? 130
                                : 200.0,
                    child: ListView(children: [
                      Card(
                        child: Container(
                          padding: _searchedUniversityList.length > 0
                              ? EdgeInsets.all(10)
                              : EdgeInsets.all(0),
                          child: AnimatedList(
                            initialItemCount: _searchedUniversityList.length,
                            shrinkWrap: true,
                            itemBuilder: (context, index, animation) {
                              animation = CurvedAnimation(
                                  curve: Curves.linear, parent: animation);

                              return _buildAddedItem(
                                  _searchedUniversityList[index], index);
                            },
                          ),
                        ),
                      )
                    ]))
                : Container()
            : Container(),
      ],
    );
  }

  universityListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? _searchedUniversityList.length > 0
                ? Card(
                    child: Container(
                      //color: Colors.green,
                      height: _searchedUniversityList.length == 1
                          ? 50.0
                          : _searchedUniversityList.length == 2
                              ? 90.0
                              : _searchedUniversityList.length == 3
                                  ? 130
                                  : 200.0,
                      padding: _searchedUniversityList.length > 0
                          ? EdgeInsets.all(10)
                          : EdgeInsets.all(0),
                      child: ListView.builder(
                        padding: EdgeInsets.zero,
                        key: _listKey,
                        itemCount: _searchedUniversityList.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return _buildAddedItem(
                              _searchedUniversityList[index], index);
                        },
                      ),
                    ),
                  )
                : Container()
            : Container(),
      ],
    );
  }

  Widget _buildAddedItem(SkillData item, int index) {
    return item.name != null
        ? Container(
            //color:index %2 == 0? Colors.red : Colors.blue,
            child: InkWell(
              onTap: () {
                print("item++++" + item.name);
                //toggalSelection(false, index);
                onListItemTap(item);
              },
              child: AnimatedContainer(
                curve: Curves.easeIn,
                duration: Duration(milliseconds: 500),
                width: MediaQuery.of(context).size.width,
                child: Text(item.name,
                    style: TextStyle(fontFamily: Constant.customRegular)),
                padding: EdgeInsets.all(8),
              ),
            ),
          )
        : Container(
            width: 0,
            height: 0,
          );
  }

  List<SkillData> callListSearch() {
    print(
        'inside callListSearch() search text::: ${_textFieldController.text.trim()}');

    showList = false;

    if (_textFieldController.text.trim() != '') {
      _searchedUniversityList = _skillModel.skillList
          .where((food) => food.name
              .toLowerCase()
              .startsWith(_textFieldController.text.toLowerCase()))
          .toList();
    } else
      _searchedUniversityList = _skillModel.skillList;
    setState(() {
      _searchedUniversityList;
      showList = true;
    });
    print(
        'inside callListSearch() _searchedUniversityList size:; ${_searchedUniversityList.length}');
    return _searchedUniversityList;
  }

  bool findPersonUsingWhere(String personName) {
    // Return list of people matching the condition
    final foundPeople = selectedLoveInterestsList
        .where((element) => element.name == personName);

    if (foundPeople.isNotEmpty) {
      print('Using where: ${foundPeople.first}');
      return true;
    } else
      return false;
  }

  void onListItemTap(SkillData item) {
    _textFieldFocus.unfocus();
    removedUniversiyList.add(item);
    selectedLoveInterestsList.add(
        SkillData(name: item.name, hobbyId: item.hobbyId, type: item.type));

    selectedUniversityOption.add(item.name);
    if (_universityList.length > 0) {
      _searchedUniversityList.remove(item);
      _universityList.remove(item);
    }
    showList = !showList;
    _textFieldController.text = '';
    _searchedUniversityList = _universityList;
    setState(() {
      bottomViewColor = Palette.dividerColor;
      _textFieldController;
      _searchedUniversityList;
      _universityList;
    });
  }

  getUniversitySelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 5.0,
                  runSpacing: 0.0,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return InputChip(
                      label: Text(
                        '${_items[index].name}',
                        maxLines: 4,
                        softWrap: true,
                      ),
                      backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                      shape: StadiumBorder(
                        side: BorderSide(
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                      ),
                      onSelected: (bool value) {},
                      deleteIcon: Icon(
                        Icons.clear,
                        color:  ColorValues.WHITE,
                        size: 16.0,
                      ),
                      onDeleted: () {
                        print("selected index:: $index");
                        updateList(_items[index], index);
                      },
                      labelStyle: TextStyle(
                        color: ColorValues.WHITE,
                        fontSize: 16,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12.0, vertical: 3.0),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        : Container(
            height: 0,
            width: 0,
          );
  }

  void updateList(SkillData item, int index) {
    print('inside updateList');
    int indexR = 0;
    //for (SkillData removeitem in removedUniversiyList) {
    for (int i = 0; i < removedUniversiyList.length; i++) {
      print(
          'inside updateList removeitem name:: ${removedUniversiyList[i].name}');
      if (item.name == removedUniversiyList[i].name && item.hobbyId != "") {
        print('update this inside name:: ${removedUniversiyList[i].name}');
        _universityList.add(removedUniversiyList[i]);
        indexR = i;
      }
    }

    if (item.hobbyId != null && item.hobbyId != "") {
      removedUniversiyList.removeAt(indexR);
    }

    //removedUniversiyList.removeAt(index);
    selectedLoveInterestsList.removeAt(index);
    selectedUniversityOption.removeAt(index);
    setState(() {
      _universityList;
      removedUniversiyList;
      selectedLoveInterestsList;
      selectedUniversityOption;
      if (showList) showList = !showList;
    });
  }
}
