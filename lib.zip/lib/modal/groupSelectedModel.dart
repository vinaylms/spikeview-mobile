import 'dart:io';

class GroupSelectedModel {
  String id;

  GroupSelectedModel(this.id);
  Map<String, dynamic> toJson() => {'id': int.parse(id)};

}

