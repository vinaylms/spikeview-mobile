import 'MessageConstant.dart';

class ValidationWidget {
  static bool isName(String em) {
    return RegExp(r"^[a-zA-Z-. '’]+$").hasMatch(em.trim());
  }

  static bool isSchoolName(String em) {
    return RegExp(r"^[a-zA-Z0-9' ]*$").hasMatch(em.trim());
  }

  static bool isZipCode(String value) {
    //return RegExp(r'^[a-zA-Z0-9]$').hasMatch(value.trim());
    return RegExp(r'^[a-zA-Z0-9 ]{1,15}$').hasMatch(value.trim());
  }

  static bool isEmail(String em) {
    String emailRegexp =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = RegExp(emailRegexp);
    return regExp.hasMatch(em.trim());
  }

  /* static bool isSecondaryEmail(String em,List<String> educatorAllowedDomain) {
    String emailRegexp =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = RegExp(emailRegexp);
    bool result= regExp.hasMatch(em.trim());
    for (String domain in educatorAllowedDomain) {
      print("domain+++" + domain);
      if (em.endsWith(domain)) {
       return false;
      }
    }

    return result;
  }*/
  //org, .edu and .us domains are not allowed for personal email

  static String isSecondaryEmail(
      String em, List<String> educatorAllowedDomain) {
    String emailRegexp =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = RegExp(emailRegexp);
    bool result = regExp.hasMatch(em.trim());
    if (!result) {
      return MessageConstant.ENTER_CORRECRT_EMAIL_VAL;
    }
    for (String domain in educatorAllowedDomain) {
      print("domain+++" + domain);
      if (em.endsWith(domain)) {
        return MessageConstant.ENTER_CORRECRT_DOMAIN_VAL;
      }
    }

    return result ? null : MessageConstant.ENTER_CORRECRT_EMAIL_VAL;
  }

  static String isSecondaryEmailOnEdit(
      String em, List<String> educatorAllowedDomain, email) {
    String emailRegexp =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regExp = RegExp(emailRegexp);
    bool result = regExp.hasMatch(em.trim());
    if (!result) {
      return MessageConstant.ENTER_CORRECRT_EMAIL_VAL;
    }
    for (String domain in educatorAllowedDomain) {
      print("domain+++" + domain);
      if (em.endsWith(domain)) {
        return MessageConstant.ENTER_CORRECRT_DOMAIN_VAL;
      }
    }
    try {
      if (email.toString().toLowerCase() == em.toLowerCase()) {
        return MessageConstant.SECONDARY_EMAIL_VAL;
      }
    } catch (e) {}

    return result ? null : MessageConstant.ENTER_CORRECRT_EMAIL_VAL;
  }

  static bool isPass(String em) {
    String emailRegexp =
        r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[?!@#$%^&*()_+.])(?=.*[a-zA-Z].*)[a-zA-Z\d\!.?@#\$%&\*]{8,}$';

    RegExp regExp = RegExp(emailRegexp);
    bool isPasw = regExp.hasMatch(em);

    return isPasw;
  }

  static bool isphone(String value) {
    return RegExp(r'(^(?:[+0]9)?[0-9]{6,15}$)').hasMatch(value.trim());
  }

  static bool isphoneNumber(String value) {
    return RegExp(r'(^(?:[+0-]9)?[0-9]{6,15}$)').hasMatch(value.trim());
  }

  static bool isMessage(String em) {
    String p = r"^[a-zA-Z0-9]+(([',. -][a-zA-Z0-9 ])?[a-zA-Z0-9]*)*$";
    RegExp regExp = RegExp(p);
    return regExp.hasMatch(em.trim());
  }

  static bool isUrl(String em) {
    return RegExp(
            r"^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$")
        .hasMatch(em.trim());
  }

  static bool specialCha(String value) {
    bool response =
        RegExp(r'[!@#$%^&*(),.?":;{}|/<>~’`\+_\-=\]\[]').hasMatch(value.trim());
    if (!response) {
      if (value.contains("'") || value.contains('\\')) {
        return true;
      } else {
        return false;
      }
    }

    return response;
  }

  static bool NumberChara(String value) {
    //return RegExp(r'^[a-zA-Z0-9]$').hasMatch(value.trim());
    return RegExp(r'[0-9]').hasMatch(value);
  }

  static bool upper_lower_case(String value) {
    //return RegExp(r'^[a-zA-Z0-9]$').hasMatch(value.trim());
    return RegExp(r'[a-zA-Z]').hasMatch(value);
  }

  static bool upper_case(String value) {
    //return RegExp(r'^[a-zA-Z0-9]$').hasMatch(value.trim());
    return RegExp(r'[A-Z]').hasMatch(value);
  }

  static bool lower_case(String value) {
    //return RegExp(r'^[a-zA-Z0-9]$').hasMatch(value.trim());
    return RegExp(r'[a-z]').hasMatch(value);
  }

  static bool isURL(String s) => hasMatch(s,
      r"^((((H|h)(T|t)|(F|f))(T|t)(P|p)((S|s)?))\://)?(www.|[a-zA-Z0-9].)[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,7}(\:[0-9]{1,5})*(/($|[a-zA-Z0-9\.\,\;\?\'\\\+&amp;%\$#\=~_\-]+))*$");

  static bool hasMatch(String value, String pattern) {
    return (value == null) ? false : RegExp(pattern).hasMatch(value);
  }

  static bool isValidaGPA(String em) {
    //return RegExp(r"^[1-6]{0,1}|\d?\d(?:[.,]\d\d?)?)$").hasMatch(em.trim());
    // return RegExp(r"^([0-5]{1,2}){1}(\.[0-9]{1,2})?$").hasMatch(em.trim());

    if(em.length==1&& em=="." && em.startsWith(".")){
      return false;
    }else

    if (double.parse(em) <= 6.0) {

      if (em.length > 4) {
        return false;
      } else {
        if (em.startsWith(".")){
          return false;
        }else{
          return true;
        }
      }
    } else if (double.parse(em) > 6){
      return false;
    }

    else {
      return false;
    }
  }

/*  static bool isValidaGPA(String em) {
    //return RegExp(r"^[1-6]{0,1}|\d?\d(?:[.,]\d\d?)?)$").hasMatch(em.trim());
    // return RegExp(r"^([0-5]{1,2}){1}(\.[0-9]{1,2})?$").hasMatch(em.trim());

    if(em.length==1&& em=="."){
      return false;
    }else

    if (double.parse(em) <= 6.0) {
      if (em.length > 4) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }*/
}
