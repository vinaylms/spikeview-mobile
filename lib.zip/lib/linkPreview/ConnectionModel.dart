import 'dart:io';

import 'package:spike_view_project/Connection/RefferalModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';

class ConnectionModel {
  List<RequestedTagModel> tagList =  List();
  List<RequestedTagModel> sendRequestList =  List();
  List<RequestedTagModel> pendinForParentDataList =  List();
  List<RequestedTagModel> receivedRequestList =  List();
  List<RefferalModel> refferList =  List();
  List<PeopleYouMayKnow> peopleYouMayKnowList =  List();

  ConnectionModel({
    this.tagList,
    this.sendRequestList,
    this.pendinForParentDataList,
    this.receivedRequestList,
    this.refferList,
    this.peopleYouMayKnowList,
});

}

