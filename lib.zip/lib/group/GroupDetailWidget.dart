import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dio/dio.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/home/NewCommentListWidget.dart';
import 'package:spike_view_project/home/NewEditPostWidget.dart';
import 'package:spike_view_project/home/NewLikeDetailWidget.dart';
import 'package:spike_view_project/home/NewSharePostWidget.dart';
import 'package:spike_view_project/home_page/blocs/home_bloc.dart';
import 'package:spike_view_project/db/db_helper_new.dart';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:spike_view_project/group/GroupMembersListWidget.dart';
import 'package:spike_view_project/group/InviteMember.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';
import 'package:spike_view_project/home/AddPost.dart';
import 'package:spike_view_project/home/OpportunityView.dart';
import 'package:spike_view_project/home/SelectedGroup.dart';
import 'package:spike_view_project/home/TagDetailWidget.dart';
import 'package:spike_view_project/home/callToAction/InquireNowScreen.dart';
import 'package:spike_view_project/home_page/ui/home_widget.dart';
import 'package:spike_view_project/linkPreview/whatsapp/NewWhatsAppViewFeed.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/RewardStatusResponse.dart';
import 'package:spike_view_project/modal/UserPostModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/report/ReportWidget.dart';

import 'package:spike_view_project/shareFlow/ConnectionSelectionWidget.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:spike_view_project/profile/studentWizard/StudentOnBoarding.dart';

import 'New/ManageGroupWidget.dart';

// Create a Form Widget
class GroupDetailWidget extends StatefulWidget {
  String groupId, studentId, page, isAdimin;
  String sasToken, containerName;

  GroupDetailWidget(this.groupId, this.page, this.sasToken, this.containerName,
      this.studentId);

  @override
  GroupDetailWidgetState createState() {
    return GroupDetailWidgetState();
  }
}

class GroupDetailWidgetState extends State<GroupDetailWidget> {
  SharedPreferences prefs;
  String userIdPref,
      roleId,
      profile_image_path,
      token,
      dob,
      badge,
      badgeImage,
      convertDOB;
  int offset = 0, diffrenceInDob = 0, gamificationPoints = 0;
  bool isLoadMore = true;
  List<GroupDetailModel> groupList = List();
  ScrollController _scrollController2 = ScrollController();
  List<VideoPlayerController> allVideoController = List();
  List<UserPostModal> userPostList = List<UserPostModal>();
  static StreamController syncDoneController = StreamController.broadcast();
  bool isParent = false;
  bool isLoading = true;
  File imagePathCover;
  String strAzureCoverImageUploadPath, strPrefixPathforCoverPhoto;
  String sasToken, containerName;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String status = "pop";
  ProfileInfoModal profileInfoModal;
  bool isTitleVisible = false;
  ScrollController _scrollController = ScrollController();
  bool _isAppbar = true;
  bool isKeyboadrOpen = false;
  String profilePath, companyPath;
  bool isShowAllGroupRequest = false;
  Offset position = Offset(20.0, 20.0);
  RegExp exp = RegExp(
      r"(http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");

  void appBarStatus(bool status) {
    setState(() {
      _isAppbar = status;
    });
  }

  Future apiCallingForDeleteFeed(userPostModal, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": userPostModal.feedId,
          "groupId": widget.groupId,
          /*, "roleId": int.parse(roleId)*/
        };
        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_FEED_DELETE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              userPostList.removeAt(index);
              setState(() {
                userPostList;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallingForUpdateFeed(userPostModal, visibility, scopeList) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": userPostModal.feedId,
          "visibility": visibility,
          "roleId": int.parse(roleId),
          "scope": scopeList.map((item) => item).toList()
        };
        Response response = await ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_FEED_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              userPostModal.visibility = visibility;
              setState(() {
                userPostModal;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallForRemoveComment(List<CommentData> commentList, feedId,
      UserPostModal userPostModal, commentId, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": int.parse(feedId),
          "commentId": commentList[index].commentId,
          "roleId": int.parse(roleId),
          "dateTime": DateTime.now().millisecondsSinceEpoch
        };
        print("maop++++" + map.toString());

        Response response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_REMOVE_COMMENT, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              commentList.removeAt(index);
              if (commentList.length == 0) {
                userPostModal.isCommented = false;
              }
              setState(() {
                commentList;
                userPostModal;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      print("error+++" + e.toString());
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future callApiForSaasChange() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        print("shubh image response1 callApiForSaasChange+++" +
            response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallingForAddLike(feedId, userpostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        bool isLike = false;
        if (userpostModal.isLike) {
          isLike = false;
        } else {
          isLike = true;
        }
        Map map = {
          "feedId": feedId,
          "userId": int.parse(userIdPref),
          "isLike": isLike,
          "roleId": int.parse(roleId),
          "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "LikeFeed"
        };

        Response response = await ApiCalling()
            .apiCallPutWithMapData(context, Constant.ENDPOINT_ADD_LIKE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              if (userpostModal.isLike) {
                userpostModal.isLike = false;
                userpostModal.likesCount = userpostModal.likesCount - 1;
                userpostModal.likeList.removeLast();
              } else {
                userpostModal.isLike = true;
                userpostModal.likesCount = userpostModal.likesCount + 1;
                userpostModal.likeList.add(new Likes(
                    userIdPref,
                    roleId == "4"
                        ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                        : prefs
                            .getString(UserPreference.NAME)
                            .replaceAll("null", ""),
                    roleId == "4"
                        ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                        : profile_image_path,
                    "student",
                    "",
                    "",
                    prefs.getBool(UserPreference.IS_PARENT) ? "2" : "1",
                    prefs.getString(UserPreference.badgeType),
                    prefs.getInt(UserPreference.gamificationPoints),
                    prefs.getString(UserPreference.badgeImage)));
              }
              setState(() {
                userpostModal;
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallingForAddComment(feedId, comment, userpostModal) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "feedId": feedId,
          "userId": int.parse(userIdPref),
          "comment": comment,
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "name": "",
          "title": "",
          "roleId": int.parse(roleId),
          "profilePicture": "",
          "lastActivityTime": DateTime.now().millisecondsSinceEpoch,
          "lastActivityType": "CommentOnFeed"
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_FEED_COMMENT, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              try {
                userpostModal.isCommented = true;
                List<Likes> likesList = List();
                userpostModal.commentList.insert(
                    0,
                    CommentData(
                        response.data["result"]["commentId"].toString(),
                        comment,
                        userIdPref,
                        "few seconds",
                        roleId == "4"
                            ? prefs.getString(UserPreference.COMPANY_IMAGE_PATH)
                            : profile_image_path,
                        roleId == "4"
                            ? prefs.getString(UserPreference.COMPANY_NAME_PATH)
                            : prefs
                                .getString(UserPreference.NAME)
                                .replaceAll("null", ""),
                        "",
                        userIdPref,
                        likesList,
                        false,
                        prefs.getBool(UserPreference.IS_PARENT) ? "2" : "1",
                        badge,
                        gamificationPoints,
                        badgeImage,
                        true));
                setState(() {
                  userPostList;
                });
              } catch (e) {
                e.toString();
                crashlytics_bloc.recordCrashlyticsError(
                    e, "GroupDetailWidget", context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  onBack2() async {
    print("widget.page++" + widget.page);
    print("widget.page++" + widget.page);
    if (widget.page == "signup") {
      print('API CALL APURVA');
      //profileApi();

      StudentOnBoarding()
          .getStudentOnBoardingInit(context, null, sasToken, userIdPref);
    } else if (widget.page == "login") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        StudentOnBoarding().getStudentOnBoardingInit(
            context, profileInfoModal, sasToken, userIdPref);
      }
    } else if (widget.page == "Notification") {
      if (roleId == "1") {
        // For Studenet
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.GROUP_TYPE,
                      userId: userIdPref,
                    )));
      } else if (roleId == "2") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.GROUP_TYPE,
                      userId: userIdPref,
                    )));
        // For Parent
      } else if (roleId == "4") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.GROUP_TYPE,
                      userId: userIdPref,
                    )));

        // For Partner
      }
    } else {
      Navigator.pop(context, status);
      if (widget.page == "invite") syncDoneController.add("");
    }
  }

  showErrorMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack2();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: 'ERROR: ',
                                    style: TextStyle(
                                      color: Color(0xffFF0101),
                                      height: 1.2,
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: msg,
                                        style: TextStyle(
                                            color: Color(0xffFF0101),
                                            fontSize: 13.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily: Constant.customRegular),
                                      )
                                    ],
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCallForGetChange() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("shubh image response1 apiCallForGetChange++");

        print(
            'Apurva Group Detail API URL:: ${Constant.ENDPOINT_GROUPS_MEMBERS + widget.groupId + "/" + userIdPref}');
        Response response;
        response = await ApiCalling2().apiCall(
            context,
            Constant.ENDPOINT_GROUPS_MEMBERS +
                widget.groupId +
                "/" +
                userIdPref,
            "get");
        print("shubh image apiCallForGetChange" + response.toString());
        if (response != null) {
          /* if (response.data['result'].toString() == "[]") {
            showErrorMsg( MessageConstant
                .GROUP_DELETED, context);
          }else */
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupList.clear();
              groupList = ParseJson.parseGroupDetailMap(
                  response.data['result'], userIdPref, roleId);

              if (groupList.length > 0) {
                setState(() {
                  groupList;
                  print("shubh image" + groupList[0].groupImage.toString());
                  //print("Apurva 222 badgeImage" + groupList[0].memberList[0].badgeImage);
                });
              }

              /*for(int i=0; i<groupList.length;i++){
              for(int j=0; i<groupList[i].memberList.length;j++) {
                print('Apurva Name:: ${groupList[i].memberList[j].firstName}');
                print('Apurva badge:: ${groupList[i].memberList[j].badge}');
                print('Apurva badgeImage:: ${groupList[i].memberList[j].badgeImage}');
                print('Apurva status:: ${groupList[i].memberList[j].status}');
              }
              }*/
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallForGet() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print(
            'Apurva API URL:: ${Constant.ENDPOINT_GROUPS_MEMBERS + widget.groupId + "/" + userIdPref}');
        Response response;
        response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_GROUPS_MEMBERS +
                widget.groupId +
                "/" +
                userIdPref,
            "get");
        print("shubh image response1" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              groupList.clear();
              groupList = ParseJson.parseGroupDetailMap(
                  response.data['result'], userIdPref, roleId);

              if (groupList.length > 0) {
                setState(() {
                  groupList;
                  print("shubh image" + groupList[0].groupImage.toString());
                  //print("Apurva 222 badgeImage" + groupList[0].memberList[0].badgeImage);
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallingForUserPostChange() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        setState(() {
          isLoading = true;
        });
        print("shubh image response1 apiCallingForUserPostChange++");

        Response response = await ApiCalling2().apiCall(
            context,
            "ui/feed/postListByGroupId?groupId=" +
                widget.groupId +
                "&skip=0" +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        print("shubh image apiCallingForUserPostChange" + response.toString());
        setState(() {
          isLoading = false;
        });
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              userPostList.clear();
              userPostList = ParseJson.parseHomeData(
                  response.data['result'], userIdPref, roleId);
              if (userPostList.length > 0) {
                setState(() {
                  userPostList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallingForUserPost() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            "ui/feed/postListByGroupId?groupId=" +
                widget.groupId +
                "&skip=0" +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");
        print("shubh image response2" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              userPostList.clear();
              userPostList = ParseJson.parseHomeData(
                  response.data['result'], userIdPref, roleId);
              if (userPostList.length > 0) {
                setState(() {
                  userPostList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  void groupInvitationAccepted() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: 'Awesome! You have successfully joined this group',
            negativeText: 'Close',
            isSucessPopup: true,
            positiveTextColor: AppConstants.colorStyle.btn_text_red,
            onNegativeTap: () {},
          );
        });
  }

  Future apiCallingForAccept(groupId, index, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        /*  Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "status": type
        };*/

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "isAdmin": false,
          "status": type
        };

        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              apiCallForGet();
              this.status = "push";
              if (type == "Accepted") groupInvitationAccepted();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

  Future apiCallingForUserPostLoadMore() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context,
            "ui/feed/postListByGroupId?groupId=" +
                widget.groupId +
                "&skip=" +
                offset.toString() +
                "&userId=" +
                userIdPref +
                "&roleId=" +
                roleId,
            "get");

        print("LoadMore++++" +
            "ui/feed/postListByGroupId?groupId=" +
            widget.groupId +
            "&skip=" +
            offset.toString() +
            "&userId=" +
            userIdPref +
            "&roleId=" +
            roleId);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              List<UserPostModal> userPostListNew = ParseJson.parseHomeData(
                  response.data['result'], userIdPref, roleId);
              if (userPostListNew.length > 0) {
                userPostList.addAll(userPostListNew);
                setState(() {
                  userPostList;
                });
              } else {
                isLoadMore = false;
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
    }
  }

//-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath, prefixPath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + prefixPath
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      return "";
    }
  }

  //--------------------------Upload Cover Image Data ------------------
  Future uploadCoverIMage(type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        print("groupid" + widget.groupId);
        Map map = {
          "groupImage":
              strPrefixPathforCoverPhoto + strAzureCoverImageUploadPath,
          "groupId": int.parse(widget.groupId)
        };

        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_GROUP_PHOTO_UPDATE, map);

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //  ToastWrap.showToast(msg);
              this.status = "push";

              setState(() {
                this.status;
              });

              print("status" + this.status.toString());
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  showSucessMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 5000), () async {
      print("timer off");
      Navigator.pop(context);
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));
  }

  //--------------------------Upload Cover Image Data ------------------
  Future apiCallForForwardParentChange() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        print("joinMap++++apiCallForForwardParent");
        print("joinMap++++apiCallForForwardParent" + widget.studentId);
        Map map = {
          "groupId": int.parse(widget.groupId),
          "parentId": int.parse(userIdPref),
          "userId": int.parse(widget.studentId)
        };

        print("joinMap++++" + map.toString());

        response = await ApiCalling2().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);
        print("shubh image response5" + response.toString());
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //showSucessMsg(msg, context);
              apiCallForGet();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  Future apiCallForForwardParent() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        print("joinMap++++apiCallForForwardParent");
        print("joinMap++++apiCallForForwardParent" + widget.studentId);
        Map map = {
          "groupId": int.parse(widget.groupId),
          "parentId": int.parse(userIdPref),
          "userId": int.parse(widget.studentId)
        };

        print("joinMap++++" + map.toString());

        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_JOIN_GROUP_FORWARD, map);
        print("shubh image response5" + response.toString());
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //  showSucessMsg(msg, context);
              apiCallForGet();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  //--------------------------Upload Cover Image Data ------------------
  Future apiCallJoin() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId)
        };
        print("joinMap++++" + map.toString());

        response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // showSucessMsg(msg, context);
              syncDoneController.add("");
              apiCallForGet();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

//--------------------------Profile Info api ------------------
  Future profileApiChange() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print("shubh image response1 profileApiChange++");

        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_PERSONAL_INFO + userIdPref + "/false", "get");
        print("shubh image response1 profileApiChange++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              profileInfoModal =
                  ParseJson.parseMapUserProfile(response.data['result']);
              if (profileInfoModal != null) {
                setState(() {
                  //prefs.setString(UserPreference.ISACTIVE, profileInfoModal.isActive);

                  profileInfoModal;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  Future apiCallingReject(memberId, index) async {
    try {
      print("memberId" + memberId);
      print("groupid" + widget.groupId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(memberId),
          "status": "Rejected",
          "isAdmin": true,
          "roleId": int.parse(groupList[0].requestedList[index].roleId)
        };
        print("map++++" + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADMIN_UPDATED_GROUP_REQUEST, map);
        CustomProgressLoader.cancelLoader(context);
        print("response reject++++:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              groupList[0].requestedList.removeAt(index);
              setState(() {
                groupList[0].requestedList;
              });
              //apiCallForGet();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCalling(memberId, index) async {
    try {
      print("memberId" + memberId);
      print("groupid" + widget.groupId);
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(memberId),
          "status": "Accepted",
          "isAdmin": true,
          "roleId": int.parse(groupList[0].requestedList[index].roleId)
        };

        print("map++++" + map.toString());
        response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADMIN_UPDATED_GROUP_REQUEST, map);
        CustomProgressLoader.cancelLoader(context);
        print("response accept++++:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //  ToastWrap.showToast(msg);

              apiCallForGet();
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  Future apiCallingForLeave() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "userId": int.parse(userIdPref),
          "groupId": int.parse(widget.groupId),
          "roleId": int.parse(roleId)
        };
        response = await ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_LEAVE_GROUP, map);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context, "push");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  Future apiCallingDeleteGroup() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        CustomProgressLoader.showLoader(context);
        Response response;

        Map map = {"groupId": int.parse(widget.groupId)};
        print("test++++" + map.toString());
        response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_ADD_GROUP, map);
        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              Navigator.pop(context, "push");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }
  bool isFeed_AccessControl = true;

  BuildContext context;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    badge = prefs.getString(UserPreference.badgeType);
    gamificationPoints = prefs.getInt(UserPreference.gamificationPoints);
    badgeImage = prefs.getString(UserPreference.badgeImage);
    profile_image_path = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    token = prefs.getString(UserPreference.USER_TOKEN);
    isParent = prefs.getBool("isParent");
    profilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    companyPath = prefs.getString(UserPreference.COMPANY_IMAGE_PATH);
    dob = prefs.getString(UserPreference.DOB);

    isUserRepoted = UserPreference.getIsUserReported();

    try {
      isFeed_AccessControl = prefs
          .getString(UserPreference.ACCESS_CONTROL_FEED_STATUS)
          .toLowerCase() ==
          "true";
    } catch (e) {
      isFeed_AccessControl = true;
    }

    try {
      if (prefs.getString(UserPreference.ACCESS_CONTROL_GROUP) == "true") {
        ACCESS_CONTROL_GROUP = true;
        print("......................." +
            prefs.getString(UserPreference.ACCESS_CONTROL_GROUP));
      } else {
        ACCESS_CONTROL_GROUP = false;
        print("......................." +
            prefs.getString(UserPreference.ACCESS_CONTROL_GROUP));
      }
    } catch (e) {
      ACCESS_CONTROL_GROUP = true;
    }

    if (!isFeed_AccessControl) {
      ACCESS_CONTROL_GROUP = false;
    }





    if (dob != null && dob != 'null') {
      int d = int.tryParse(dob);
      DateTime date = DateTime.fromMillisecondsSinceEpoch(d);
      diffrenceInDob = Util.currentAge(date, 13);
      convertDOB =
          DateTime.fromMillisecondsSinceEpoch(d, isUtc: true).toString();
      var now = DateTime.fromMillisecondsSinceEpoch(d);
      var formatter = DateFormat('MM-dd-yyyy');
      convertDOB = formatter.format(now);
    }

    setState(() {
      position = Offset(((MediaQuery.of(context).size.width) - 68.0),
          ((MediaQuery.of(context).size.height) - 160.0));
    });
    if (isParent == null) {
      isParent = false;
    }

    CustomProgressLoader.showLoader(context);
    profileApiChange();
    await apiCallForGetChange();
    if (groupList != null &&
        groupList[0].isActive == "false" &&
        widget.page != "groupBoat") {
      CustomProgressLoader.cancelLoader(context);
      ToastWrap.showToastWithPush(MessageConstant.GROUP_REPORTED_HIDE, context);
      // Navigator.pop(context);
    } else {
      await apiCallingForUserPostChange();

      if (widget.studentId != "") {
        await apiCallForForwardParentChange();
      }

      CustomProgressLoader.cancelLoader(context);

      // showInvitationDialog(context);

      if (widget.page == "ActionPerformed") {
        ToastWrap.showToast2Sec("Action already been taken", context);
      }
      if (groupList != null &&
          groupList[0] != null &&
          groupList[0].status == "Invited") {
        if (13 > diffrenceInDob && groupList[0].adminRoleId == "4") {
        } else
        /*if (_isAdult(convertDOB))*/ {
          // showInvitationDialog(context);
        }
      }

      print("shubh image response1 loader cancel+++");
      callApiForSaasChange();

      strPrefixPathforCoverPhoto = Constant.CONTAINER_PREFIX +
          userIdPref +
          "/" +
          Constant.CONTAINER_FEED +
          "/";
      setState(() {});
    }
    //anaylytics.setCurrentSreen(ScreenNameConstant.group_detail_page);
  }

  Future apiCallingForAcceptGroupInvitation(groupId, index, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "status": type,
          "isAdmin": false,
          "roleId": int.parse(roleId),
        };
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              apiCallForGet();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  showInvitationDialog(context) {
    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                // Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  body: Stack(
                    children: [
                      Positioned(
                        right: 13.0,
                        top: 55.0,
                        left: 13.0,
                        child: Container(
                          color: Colors.black,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0, 13, 0),
                                      child: Text("Respond Request",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.white,
                                              fontFamily:
                                                  Constant.latoRegular))),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 3, 0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color: ColorValues.GREY__COLOR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("REJECT",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily:
                                                        Constant.latoRegular)),
                                          )),
                                      onTap: () {
                                        if (context != null)
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop('dialog');

                                        apiCallingForAccept(
                                            groupList[0].groupId,
                                            0,
                                            "Rejected");
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        20.0, 3, 12.0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("ACCEPT",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily:
                                                        Constant.latoRegular)),
                                          )),
                                      onTap: () {
                                        if (context != null)
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop('dialog');
                                        apiCallingForAccept(
                                            groupList[0].groupId,
                                            0,
                                            "Accepted");
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                          right: 2.0,
                          top: 45.0,
                          child: InkWell(
                              child: Image.asset(
                                "assets/black_circle_cancel.png",
                                height: 30.0,
                                width: 30.0,
                              ),
                              onTap: () {
                                if (context != null)
                                  Navigator.of(context, rootNavigator: true)
                                      .pop('dialog');
                              }))
                    ],
                  )),
              onTap: () {
                // Navigator.pop(context);
              },
            )));
  }

  bool ACCESS_CONTROL_GROUP = true;
  bool isUserRepoted = true;

  @override
  void initState() {
    _scrollController.addListener(() {
      if (_scrollController.offset >=
              _scrollController.position.maxScrollExtent &&
          !_scrollController.position.outOfRange) {
        ++offset;
        if (isLoadMore) apiCallingForUserPostLoadMore();
      }

      if (_scrollController.offset < 150.0) {
        if (isTitleVisible)
          setState(() {
            isTitleVisible = false;
          });
      } else {
        if (!isTitleVisible)
          setState(() {
            isTitleVisible = true;
          });
      }
    });

    getSharedPreferences();

    // TODO: implement initState
    super.initState();
  }

  Future apiCallingForIncreaseCount(feedId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling2().apiCall(context,
            Constant.ENDPOINT_INCREASE_NUMBER_OF_COUNT + feedId, "get");

        print("apiCallingForIncreaseCount data" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      // ToastWrap.showToast(e.toString(), context);
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  Future apiCallForForwardFeed(userPostModal, index) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "opportunityId":
              int.parse(userPostModal.opportunityModelForFeed.opportunityId),
          "userId": int.parse(userIdPref)
        };
        print("map+++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_FEED_FORWARD, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              if (msg.contains("Opportunity already forwarded to parent")) {
                ToastWrap.showToast(msg, context);
              } else {
                feedForwardConformation();
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  void feedForwardConformation() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            headingText:
                'Your post has been forwarded to your parent. Please follow up with them ',
            negativeText: 'OK',
            isSucessPopup: true,
            positiveTextColor: AppConstants.colorStyle.btn_text_red,
            onNegativeTap: () {},
            msg: '',
          );
        });
  }

  Future apiCallJoinGroup(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;

        Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId)
        };
        print("map++++" + map.toString());
        response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_JOIN_GROUP, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              syncDoneController.add("");
              groupInvitationAccepted();
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "GroupDetailWidget", context);
      e.toString();
    }
  }

  Widget getText(String s, Color color) {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0),
      child: Text(s,
          style: TextStyle(
              fontFamily: Constant.latoRegular, color: color, fontSize: 14.0)),
    );
  }

  void onTapLike(userPostModal) {
    if (groupList.isNotEmpty &&
        groupList[0].status == MessageConstant.ABOUT_GROUP_ACCEPTED) {
      apiCallingForAddLike(userPostModal.feedId, userPostModal);
    }
  }

  onTapLikeText(userPostModal) {
    Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            NewLikeDetailWidget(userPostModal.feedId, userIdPref)));
  }

  void onTapShare(userPostModel) async {
    if (groupList.isNotEmpty &&
        groupList[0].status == MessageConstant.ABOUT_GROUP_ACCEPTED) {
      if (userPostModel.visibility == "Private" ||
          userPostModel.visibility == "SelectedConnections") {
        ToastWrap.showToast("Only public feeds can be shared.", context);
      } else {
        String result = await Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => NewSharePostWidget(
                profileInfoModal, userPostModel, "group", widget.groupId)));

        if (result == "push") {
          apiCallingForUserPost();
        }
      }
    }
  }

  void onTapViewAllComments(commentList, feedId, userPostModel) async {
    if (groupList.isNotEmpty &&
        groupList[0].status == MessageConstant.ABOUT_GROUP_ACCEPTED) {
      String result = await Navigator.of(context).push(new MaterialPageRoute(
          builder: (BuildContext context) => NewCommentListWidget(
              commentList,
              profile_image_path,
              feedId,
              prefs.getString(UserPreference.NAME).replaceAll("null", ""),
              userPostModel,
              userIdPref,
              roleId,
              badge,
              gamificationPoints,
              badgeImage)));

      if (result == "push") {
        // apiCallingForUserPost();
      }
    }
  }

  void onTapAddPost(groupId, groupModel) async {
    print('inside onTapAddPost');
    RewardStatusResponse result = await Navigator.of(context).push(
        MaterialPageRoute(
            builder: (BuildContext context) => AddPost(
                profileInfoModal, groupId,
                groupDetailModel: groupList[0])));

    if (result != null) {
      DbHelper().deleteTable();
      homeBloc.fetcPost(userIdPref, roleId, context);
      Util.showRewardPoint(result.rewardStatus, context);
      apiCallingForUserPost();
    }
  }

  onTapMemberDetail(GroupDetailModel groupList) async {
    //print('groupList::: ${groupList.memberList[1].firstName}');
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) => GroupMembersListWidget(
            widget.groupId, groupList, userIdPref, roleId)));
    if (result == "push") {
      apiCallForGet();
    }
  }

  Container getInfoUi() {
    return Container(
      padding: EdgeInsets.only(left: 20.0, right: 20, top: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: BaseText(
              text: 'About group',
              textColor: ColorValues.labelColor,
              fontFamily: AppConstants.stringConstant.latoRegular,
              fontWeight: FontWeight.w500,
              fontSize: 14,
              textAlign: TextAlign.start,
              maxLines: 3,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 3.0),
            child: BaseText(
              text: groupList[0].aboutGroup,
              textColor: ColorValues.TEXT_COLOR,
              fontFamily: AppConstants.stringConstant.latoRegular,
              fontWeight: FontWeight.w500,
              fontSize: 16,
              textAlign: TextAlign.start,
              maxLines: 50,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: BaseText(
              text: 'Group created on',
              textColor: ColorValues.labelColor,
              fontFamily: AppConstants.stringConstant.latoRegular,
              fontWeight: FontWeight.w500,
              fontSize: 14,
              textAlign: TextAlign.start,
              maxLines: 3,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 3.0),
            child: BaseText(
              text: groupList[0].creationDate,
              textColor: ColorValues.TEXT_COLOR,
              fontFamily: AppConstants.stringConstant.latoRegular,
              fontWeight: FontWeight.w500,
              fontSize: 16,
              textAlign: TextAlign.start,
              maxLines: 3,
            ),
          ),
          groupList[0].otherInfo != null &&
                  groupList[0].otherInfo != 'null' &&
                  groupList[0].otherInfo != ''
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: BaseText(
                        text: 'Group rule',
                        textColor: ColorValues.labelColor,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontWeight: FontWeight.w500,
                        fontSize: 14,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 3.0),
                      child: BaseText(
                        text: groupList[0].otherInfo,
                        textColor: ColorValues.TEXT_COLOR,
                        fontFamily: AppConstants.stringConstant.latoRegular,
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                        textAlign: TextAlign.start,
                        maxLines: 3,
                      ),
                    ),
                  ],
                )
              : SizedBox()
        ],
      ),
    );
  }

  onTapImageTile(tapedUserId, roleId) {
    if (tapedUserId == userIdPref) {
    } else {
      Util.onTapImageTile(
          tapedUserRole: roleId, partnerUserId: tapedUserId, context: context);
    }
  }

  onTapInviteGroup() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            InviteMember(widget.groupId, "", groupList[0].allMembersList)));

    if (result == "push") {
      apiCallForGet();
    }
  }

  void notInvited() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            headingText:
                'Members cannot be added to this group. Members who are interested in the opportunity associated with this group will need to opt into it.',
            negativeText: 'OK',
            isSucessPopup: true,
            positiveTextColor: AppConstants.colorStyle.btn_text_red,
            onNegativeTap: () {}, msg: null,
          );
        });
  }

  Column getHeaderUi() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        groupList[0].isAdmin
            ? PaddingWrap.paddingfromLTRB(
                20.0,
                20.0,
                20.0,
                20.0,
                Container(
                  height: 34,
                  child: Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: InkWell(
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Container(
                              height: 34,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: ColorValues.WHITE,
                                border: Border.all(
                                    color: AppConstants.colorStyle.lightBlue),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                "Manage group",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  // fontWeight: FontWeight.w600,
                                  color: AppConstants.colorStyle.lightBlue,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                          onTap: () async {
                            String result = await Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        ManageGroupWidget(groupList[0],
                                            sasToken, containerName)));
                            print('refresh++++++detail++' +
                                result.trim().toString());

                            if (result == 'push') {
                              status = 'push';
                              await apiCallForGetChange();
                            } else if (result == 'delete') {
                              Navigator.pop(context, 'push');
                            } else if (result == 'report') {
                              Navigator.pop(context, 'push');
                            }
                          },
                        ),
                      ),
                      Expanded(
                          flex: 1,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10.0),
                            child: Container(
                              width: double.infinity,
                              height: 34,
                              child: ElevatedButton(
                                onPressed: () {
                                  if (isUserRepoted) {
                                    if (!groupList[0].isOpportunityAdded) {
                                      onTapInviteGroup();
                                    } else {
                                      notInvited();
                                    }
                                  } else {
                                    ToastWrap.showToast1Sec(
                                        "User repoted..", context);
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                  elevation: 0,
                                  tapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  primary: AppConstants.colorStyle.lightBlue,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: Text(
                                  'Invite to group',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    // fontWeight: FontWeight.w400,
                                    color: ColorValues.WHITE,
                                    fontFamily:
                                        AppConstants.stringConstant.latoRegular,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ),
                          )),
                    ],
                  ),
                ))
            : groupList[0].type == "public" && groupList[0].status == "Accepted"
                ? PaddingWrap.paddingfromLTRB(
                    20.0,
                    20.0,
                    20.0,
                    20.0,
                    Container(
                      height: 34,
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.only(right: 10.0),
                                child: Container(
                                  height: 34,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: ColorValues.WHITE,
                                    border: Border.all(
                                        color:
                                            AppConstants.colorStyle.lightBlue),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    "More options",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      //fontWeight: FontWeight.w600,
                                      color: AppConstants.colorStyle.lightBlue,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                              onTap: () async {
                                String result = await Navigator.of(context)
                                    .push(new MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            ManageGroupWidget(groupList[0],
                                                sasToken, containerName)));
                                print('refresh++++++detail++' +
                                    result.trim().toString());
                                if (result == 'push') {
                                  status = 'push';
                                  await apiCallForGetChange();
                                } else if (result == 'delete') {
                                  Navigator.pop(context, 'push');
                                } else if (result == 'leave') {
                                  Navigator.pop(context, 'push');
                                } else if (result == 'report') {
                                  Navigator.pop(context, 'push');
                                }
                              },
                            ),
                          ),
                          Expanded(
                              flex: 1,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 10.0),
                                child: Container(
                                  width: double.infinity,
                                  height: 34,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      if (isUserRepoted) {
                                        if (!groupList[0].isOpportunityAdded) {
                                          onTapInviteGroup();
                                        } else {
                                          notInvited();
                                        }
                                      } else {
                                        ToastWrap.showToast1Sec(
                                            "User repoted..", context);
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                      elevation: 0,
                                      tapTargetSize:
                                          MaterialTapTargetSize.shrinkWrap,
                                      primary:
                                          AppConstants.colorStyle.lightBlue,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    child: Text(
                                      'Invite to group',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        //  fontWeight: FontWeight.w600,
                                        color: ColorValues.WHITE,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                ),
                              )),
                        ],
                      ),
                    ))
                : groupList[0].status == "Accepted"
                    ? PaddingWrap.paddingfromLTRB(
                        20.0,
                        20.0,
                        20.0,
                        20.0,
                        Container(
                          height: 34,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              InkWell(
                                child: Padding(
                                  padding: const EdgeInsets.only(right: 10.0),
                                  child: Container(
                                    height: 34,
                                    width: 160,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      color: ColorValues.WHITE,
                                      border: Border.all(
                                          color: AppConstants
                                              .colorStyle.lightBlue),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      "More options",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        // fontWeight: FontWeight.w600,
                                        color:
                                            AppConstants.colorStyle.lightBlue,
                                        fontFamily: AppConstants
                                            .stringConstant.latoMedium,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                ),
                                onTap: () async {
                                  String result = await Navigator.of(context)
                                      .push(new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              ManageGroupWidget(groupList[0],
                                                  sasToken, containerName)));
                                  print('refresh++++++detail++' +
                                      result.trim().toString());
                                  if (result == 'push') {
                                    status = 'push';
                                    await apiCallForGetChange();
                                  } else if (result == 'delete') {
                                    Navigator.pop(context, 'push');
                                  } else if (result == 'leave') {
                                    Navigator.pop(context, 'push');
                                  } else if (result == 'report') {
                                    Navigator.pop(context, 'push');
                                  }
                                },
                              )
                            ],
                          ),
                        ))
                    : Container(
                        height: 0.0,
                      ),
        groupList[0].status == null ||
                groupList[0].status == "null" ||
                groupList[0].status == "Invited" ||
                groupList[0].status == "Requested" ||
                groupList[0].status == ""
            ? getInfoUi()
            : Container(
                height: 0.0,
              ),
        /*  groupList.length > 0 &&
                  groupList[0].isAdmin &&
                  groupList[0].requestedList.length > 0
              ? Column(
                  children: <Widget>[
                    groupList[0].requestedList.length > 0
                        ? Container(
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          13.0, 5.0, 0.0, 5.0),
                                      child: Text(
                                        groupList[0].requestedList.length == 1
                                            ? " MEMBER REQUEST (" +
                                                groupList[0]
                                                    .requestedList
                                                    .length
                                                    .toString() +
                                                ")"
                                            : " MEMBER REQUESTS (" +
                                                groupList[0]
                                                    .requestedList
                                                    .length
                                                    .toString() +
                                                ")",
                                        style: TextStyle(
                                            fontSize: 12.0,
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.customRegular),
                                      )),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: groupList[0].requestedList.length > 3
                                      ? InkWell(
                                          child: Container(
                                              height: 40.0,
                                              child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      10.0, 3.0, 13.0, 0.0),
                                                  child: Text(
                                                    "View All",
                                                    style: TextStyle(
                                                        fontSize: 14.0,
                                                        color: ColorValues
                                                            .BLUE_COLOR_BOTTOMBAR,
                                                        fontFamily: Constant
                                                            .customRegular),
                                                  ))),
                                          onTap: () {
                                            onTapViewAllGroupRequest(
                                                groupList[0]);
                                          },
                                        )
                                      : Container(
                                          height: 0.0,
                                        ),
                                  flex: 0,
                                )
                              ],
                            ),
                            color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                            height: 25.0,
                          )
                        : Container(
                            height: 0.0,
                          ),
                    Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 15.0, 0.0, 15.0),
                        child: Column(
                          children: List.generate(
                              groupList[0].requestedList.length > 3
                                  ? 3
                                  : groupList[0].requestedList.length,
                              (int index) {
                            return getListview(
                                groupList[0].requestedList[index],
                                index,
                                false);
                          }),
                        )),
                  ],
                )
              : Container(
                  height: 0.0,
                ),*/
      ],
    );
  }

  void conformationDialogForDeletFeed(userPostModal, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
          //  headingText: 'Delete post',
            headingText: 'Are you sure you want to delete this post?',
            negativeText: 'Cancel',
            isThreeStepPopup:true,
            positiveText: 'Delete',
            positiveTextColor: AppConstants.colorStyle.btn_text_red,
            onNegativeTap: () {},
            onPositiveTap: () {
              apiCallingForDeleteFeed(userPostModal, index);
            },
          );
        });
  }

  onTapReportForFeed(userPostModal, index) async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            Report("groupFeed", "", userPostModal.feedId, "")));
    if (result == "push") {
      userPostModal.isReported = "true";

      setState(() {
        userPostList;
      });
    } else if (result == "hide") {
      userPostList.removeAt(index);
      setState(() {
        userPostList;
      });
    }
  }

  void editDeletePopUp(userPostModal, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    //  padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                          child: Container(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                              child: Text(
                                "Edit",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              )),
                          onTap: () async {
                            Navigator.pop(context);
                            String result = await Navigator.of(context).push(
                                new MaterialPageRoute(
                                    builder: ( context) =>
                                        NewEditPostWidget(profileInfoModal, widget.groupId,
                                            null, userPostModal,
                                        ),
                                ),
                            );
                            if (result == "push") {
                              apiCallingForUserPost();
                            }
                          },
                        ),
                        Container(
                          color: AppConstants.colorStyle.dividerPopUp,
                          height: 1.0,
                        ),
                        InkWell(
                          child: Container(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                              child: Text(
                                "Delete",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: ColorValues.circle4,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              )),
                          onTap: () async {
                            Navigator.pop(context);
                            conformationDialogForDeletFeed(
                                userPostModal, index);
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: BaseText(
                        text: "Cancel",
                        textAlign: TextAlign.center,
                        textColor: Color(0xff27275A),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ));
        });
  }

  void infoDialog() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    //  padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                          height: 10,
                        ),
                        Image.asset(
                          'assets/profile/parent/info.png',
                          height: 25.0,
                          width: 25.0,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        RichText(
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            text: 'Forward to Parent',
                            style: TextStyle(
                              color: Color(0xff27275A),
                              fontSize: 16.0,
                              fontFamily: Constant.latoMedium,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 15.0, right: 15),
                          child: Container(
                              child: RichText(
                            maxLines: 5,
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              text:
                                  'Great that you are interested on this opportunity. Because you are under 13, please follow up your parent/guardian to help with next steps. They will see the details in their feed.',
                              style: TextStyle(
                                fontSize: 14,
                                color: const Color(0xff666B9A),
                                fontFamily: Constant.latoRegular,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          )),
                        ),
                        SizedBox(
                          height: 10,
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: BaseText(
                        text: "Close",
                        textAlign: TextAlign.center,
                        textColor: Color(0xff27275A),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ));
        });
  }

  void forwardToParentConformAtionDialog(userPostModal, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: 'Are you sure you want to forward this feed to your parent?',
            negativeText: 'No',
            positiveText: 'Yes',
            isSucessPopup: false,
            positiveTextColor: AppConstants.colorStyle.btn_text_red,
            onNegativeTap: () {},
            onPositiveTap: () {
              apiCallForForwardFeed(userPostModal, index);
            },
          );
        });
  }

  Widget _loader(BuildContext context) => Center(
          child: Container(
        child: Image.asset(
          "assets/aerial/feed_default_img.png",
          fit: BoxFit.cover,
        ),
      ));

  Widget _error() {
    return Center(
      child: Image.asset(
        "assets/aerial/feed_default_img.png",
        fit: BoxFit.fill,
      ),
    );
  }

  void onlyDeletePopUp(userPostModal, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    //  padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                          child: Container(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                              child: Text(
                                "Delete",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: ColorValues.circle4,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              )),
                          onTap: () async {
                            Navigator.pop(context);
                            conformationDialogForDeletFeed(
                                userPostModal, index);
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: BaseText(
                        text: "Cancel",
                        textAlign: TextAlign.center,
                        textColor: Color(0xff27275A),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ));
        });
  }

  void issuePopUp(userPostModal, index) {
    if (groupList.isNotEmpty &&
        groupList[0].status == MessageConstant.ABOUT_GROUP_ACCEPTED) {
      showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          isDismissible: false,
          builder: (_) {
            return Padding(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Container(
                      //  padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                      ),
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          InkWell(
                            child: Container(
                                padding:
                                EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                                child: Text(
                                  "Having an issue?",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: ColorValues.circle4,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16),
                                )),
                            onTap: () async {
                              Navigator.pop(context);

                              if (userPostModal.isReported == "true") {
                                ToastWrap.showToast1Sec(
                                    "You have already reported this post.",
                                    context);
                              } else {
                                onTapReportForFeed(userPostModal, index);
                              }
                            },
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    InkWell(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        alignment: Alignment.center,
                        child: BaseText(
                          text: "Cancel",
                          textAlign: TextAlign.center,
                          textColor: Color(0xff27275A),
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          fontFamily: Constant.latoRegular,
                        ),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                      },
                    ),
                  ],
                ));
          });
    }
  }

  onTapView(url) async {
    Navigator.push(
        context,
        MaterialPageRoute(
            //   builder: (context) =>  DashBoardWidget()));
            builder: (context) => WebViewWidget(
                url.contains("http") ? url : "https://" + url, "spikeview")));
    //   await launch(url);
  }

  Widget _shareButton({@required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Transform.translate(
        offset: const Offset(0, -2),
        child: Image.asset(
          "assets/feed/share.png",
          height: 26.0,
          width: 26.0,
        ),
      ),
    );
  }

  void optionMenuForShareOpportunity(userPostModal, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                    //  padding: EdgeInsets.fromLTRB(15, 15, 15, 13),
                    clipBehavior: Clip.antiAlias,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                          child: Container(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                              child: Text(
                                "Share as post",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_2,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              )),
                          onTap: () async {
                            Navigator.pop(context);
                            onTapShare(userPostModal);
                          },
                        ),
                        Container(
                          color: AppConstants.colorStyle.dividerPopUp,
                          height: 1.0,
                        ),
                        InkWell(
                          child: Container(
                              padding:
                                  EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                              child: Text(
                                "Share with connections",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_2,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 16),
                              )),
                          onTap: () async {
                            Navigator.pop(context);
                            Navigator.of(context).push(new MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    ConnectionsSelectionWidget(
                                        userIdPref,
                                        roleId,
                                        userPostModal.opportunityModelForFeed
                                            .opportunityId,
                                        userPostModal.feedId)));
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  InkWell(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: BaseText(
                        text: "Cancel",
                        textAlign: TextAlign.center,
                        textColor: Color(0xff27275A),
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ],
              ));
        });
  }

  Widget imageViewforOpportunityStack(userPostModal) {
    return Container(
      decoration: new BoxDecoration(
        /*image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),*/
        gradient: LinearGradient(
          colors: [
            Color(0xff000000),
            Color(0x00000000),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
        20.0,
        12.0,
        20.0,
        12.0,
        Row(
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(
                      userPostModal.postOwnerProfilePicture),
              placeHolderImage: userPostModal.postOwnerRoleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 46.0,
              height: 46.0,
              onTap: () async {
                onTapImageTile(
                    userPostModal.postOwner, userPostModal.postOwnerRoleId);
              },
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child: RichText(
                      maxLines: 2,
                      textAlign: TextAlign.start,
                      text: TextSpan(
                        text: userPostModal.postOwnerLastName == "null"
                            ? userPostModal.postOwnerFirstName
                            : userPostModal.postOwnerFirstName +
                                " " +
                                userPostModal.postOwnerLastName,
                        style: TextStyle(
                          color: ColorValues.WHITE,
                          fontSize: 16.0,
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w500,
                        ),
                        children: userPostModal.tagList.length == 0
                            ? [
                                WidgetSpan(
                                  child: userPostModal.postOwnerRoleId == "1"
                                      ? Util.getStudentBadgeRichTextWithPadding(
                                          userPostModal.postOwnerBadge,
                                          userPostModal.postOwnerBadgeImage)
                                      : Container(
                                          height: 0.0,
                                          width: 0.0,
                                        ),
                                )
                              ]
                            : [
                                WidgetSpan(
                                  child: userPostModal.postOwnerRoleId == "1"
                                      ? Util.getStudentBadgeRichTextWithPadding(
                                          userPostModal.postOwnerBadge,
                                          userPostModal.postOwnerBadgeImage)
                                      : Container(
                                          height: 0.0,
                                          width: 0.0,
                                        ),
                                ),
                                TextSpan(
                                    text: ' with ',
                                    style: TextStyle(
                                      color: ColorValues.WHITE,
                                      fontSize: 14.0,
                                      fontFamily: Constant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                    )),
                                TextSpan(
                                  text: userPostModal.tagList[0].name == null ||
                                          userPostModal.tagList[0].name ==
                                              "null"
                                      ? ""
                                      : userPostModal.tagList[0].name,
                                  style: TextStyle(
                                    color: ColorValues.WHITE,
                                    fontSize: 14.0,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                userPostModal.tagList.length > 1
                                    ? TextSpan(
                                        text: ' and ',
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 14.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      )
                                    : TextSpan(
                                        text: "",
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 14.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                userPostModal.tagList.length > 1
                                    ? TextSpan(
                                        text: (userPostModal.tagList.length - 1)
                                            .toString(),
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 14.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      )
                                    : TextSpan(
                                        text: "",
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 14.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                userPostModal.tagList.length > 1
                                    ? TextSpan(
                                        text: " others ",
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 14.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      )
                                    : TextSpan(
                                        text: "",
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 14.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                              ],
                      ),
                    ),
                    onTap: () {
                      if (userPostModal.tagList.length > 0) {
                        Navigator.of(context).push(new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                TagDetailWidget(userPostModal.tagList)));
                      } else {
                        print("clicked");
                        onTapImageTile(userPostModal.postOwner,
                            userPostModal.postOwnerRoleId);
                      }
                    },
                  ),
                  const SizedBox(height: 3),
                  TextViewWrap.textView(
                      userPostModal.shareTime,
                      TextAlign.center,
                      ColorValues.WHITE,
                      12.0,
                      FontWeight.normal),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget getListViewPostForOpportuntiy(
      UserPostModal userPostModal, index, bool isUserRepoted) {
    return Container(
      color: ColorValues.WHITE,
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 21),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          // getEvent(userPostModal),
          PaddingWrap.paddingfromLTRB(
              11.0,
              10.0,
              11.0,
              10.0,
              Row(
                children: <Widget>[
                  Expanded(
                    child: ProfileImageView(
                      imagePath: Constant.IMAGE_PATH_SMALL +
                          ParseJson.getSmallImage(userPostModal.profilePicture),
                      placeHolderImage: userPostModal.postOwnerRoleId == "4"
                          ? "assets/profile/partner_img.png"
                          : 'assets/profile/user_on_user.png',
                      width: 46.0,
                      height: 46.0,
                      onTap: () async {
                        onTapImageTile(userPostModal.postOwner,
                            userPostModal.postOwnerRoleId);
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: PaddingWrap.paddingfromLTRB(
                        8.0,
                        0.0,
                        15.0,
                        0.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            InkWell(
                              child: Container(
                                  child: RichText(
                                maxLines: 2,
                                textAlign: TextAlign.start,
                                text: TextSpan(
                                  text: userPostModal.lastName == null ||
                                          userPostModal.lastName == "null"
                                      ? userPostModal.firstName
                                      : userPostModal.firstName +
                                          " " +
                                          userPostModal.lastName,
                                  style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  children: [
                                    WidgetSpan(
                                      child: userPostModal.roleId == "1"
                                          ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                                  userPostModal.badge,
                                                  userPostModal.badgeImage)
                                          : Container(
                                              height: 0.0,
                                              width: 0.0,
                                            ),
                                    ),
                                    TextSpan(
                                        text: ' shared ',
                                        style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontFamily: Constant.latoRegular,
                                          fontWeight: FontWeight.normal,
                                        )),
                                    TextSpan(
                                      text: userPostModal.postOwnerLastName ==
                                              ""
                                          ? userPostModal.postOwnerFirstName
                                                  .trim() +
                                              "'s"
                                          : userPostModal.postOwnerFirstName +
                                              " " +
                                              userPostModal.postOwnerLastName
                                                  .toString()
                                                  .trim() +
                                              "'s",
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16.0,
                                          fontFamily: Constant.latoSemibold
                                      ),
                                    ),
                                    TextSpan(
                                      text: " post",
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16.0,
                                        fontFamily: Constant.latoRegular,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ],
                                ),
                              )),
                              onTap: () {
                                onTapImageTile(userPostModal.postedBy,
                                    userPostModal.roleId);
                              },
                            ),
                            Padding(
                              padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                              child: Row(
                                children: [
                                  TextViewWrap.textView(
                                      userPostModal.dateTime,
                                      TextAlign.center,
                                      ColorValues.labelColor,
                                      12.0,
                                      FontWeight.normal),
                                  userIdPref == userPostModal.postedBy &&
                                          roleId ==
                                              userPostModal.roleId.toString()
                                      ? PaddingWrap.paddingfromLTRB(
                                          4.0,
                                          0.0,
                                          5.0,
                                          0.0,
                                          Image.asset(
                                            userPostModal.visibility ==
                                                    "Private"
                                                ? "assets/profile/post/private_new.png"
                                                : userPostModal.visibility ==
                                                        "SelectedConnections"
                                                    ? "assets/profile/post/selected_connections.png"
                                                    : userPostModal
                                                                .visibility ==
                                                            "AllConnections"
                                                        ? "assets/profile/post/connection.png"
                                                        : userPostModal
                                                                    .visibility ==
                                                                "Group"
                                                            ? "assets/profile/post/group_data.png"
                                                            : "assets/profile/post/community.png",
                                            width: 13.0,
                                            color: userPostModal.visibility ==
                                                    "SelectedConnections"
                                                ? null
                                                : ColorValues.GREY_TEXT_COLOR,
                                            height: 13.0,
                                          ))
                                      : Container(height: 0.0),
                                ],
                              ),
                            )
                          ],
                        )),
                    flex: 4,
                  ),
                  Expanded(
                    child: userIdPref == userPostModal.postedBy &&
                            roleId == userPostModal.roleId.toString()
                        ? Container(
                            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 30.0),
                            child: InkWell(
                              child: Image.asset(
                                "assets/feed/three_dot_blue.png",
                                width: 16.0,
                                height: 16.0,
                              ),
                              onTap: () {
                                // optionMenuDelete(userPostModal, index);
                                onlyDeletePopUp(userPostModal, index);
                              },
                            ))
                        : Container(
                            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 30.0),
                            child: InkWell(
                              child: Image.asset(
                                "assets/feed/three_dot_blue.png",
                                width: 16.0,
                                height: 16.0,
                              ),
                              onTap: () {
                                // optionForReport(userPostModal, index);
                                issuePopUp(userPostModal, index);
                              },
                            )),
                    flex: 0,
                  )
                ],
              )),
          userPostModal.shareText == "null" || userPostModal.shareText == ""
              ? const SizedBox.shrink()
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                      0.0,
                      10.0,
                      10.0,
                      0.0,
                      userPostModal.shareText == "" ||
                              userPostModal.shareText == "null" ||
                              userPostModal.shareText == "\n"
                          ? const SizedBox.shrink()
                          : PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              userPostModal.isShareMore
                                  ? Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          apiCallingForIncreaseCount(
                                              userPostModal.feedId);
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .push(new MaterialPageRoute(
                                                  fullscreenDialog: true,
                                                  builder:
                                                      (BuildContext context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                        },
                                        text: userPostModal.shareText,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 14.0),
                                        linkStyle: TextStyle(
                                            color: ColorValues
                                                .BLUE_COLOR_BOTTOMBAR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                      ),
                                    )
                                  : Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          apiCallingForIncreaseCount(
                                              userPostModal.feedId);
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .push(new MaterialPageRoute(
                                                  fullscreenDialog: true,
                                                  builder:
                                                      (BuildContext context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                        },
                                        text: userPostModal.shareText,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 14.0),
                                        linkStyle: TextStyle(
                                            color: ColorValues
                                                .BLUE_COLOR_BOTTOMBAR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                      ),
                                    )),
                    ),
                  ],
                ),
          userPostModal.postOwnerDeleted
              ? PaddingWrap.paddingfromLTRB(
                  11.0,
                  5.0,
                  11.0,
                  5.0,
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                        border: Border.all(
                            width: 0.5,
                            color: ColorValues.GREY__COLOR_DIVIDER)),
                    child: PaddingWrap.paddingfromLTRB(
                        11.0,
                        17.0,
                        11.0,
                        16.0,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            TextViewWrap.textView(
                                "You can’t see this post",
                                TextAlign.start,
                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                14.0,
                                FontWeight.bold),
                            TextViewWrap.textView(
                                MessageConstant.AUTHOR_DELETED_POST,
                                TextAlign.start,
                                ColorValues.HEADING_COLOR_EDUCATION_1,
                                14.0,
                                FontWeight.normal)
                          ],
                        )),
                  ),
                )
              : PaddingWrap.paddingfromLTRB(
                  11.0,
                  5.0,
                  11.0,
                  5.0,
                  Container(
                    // decoration: BoxDecoration(
                    //     border: Border.all(
                    //         width: 0.1, color: Colors.black)),
                    child: Stack(
                      // crossAxisAlignment: CrossAxisAlignment.start,
                      // mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        InkWell(
                          child: Container(
                            width: double.infinity,
                            child: Card(
                              elevation: 0.0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(0.0)),
                              color: ColorValues.WHITE,
                              child: Column(
                                children: <Widget>[
                                  PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    //
                                    userPostModal.opportunityModelForFeed
                                                .assestVideoAndImage.length >
                                            0
                                        ? SizedBox(
                                            // Pager view
                                            height: 250.0,
                                            child: PageIndicatorContainer(
                                              pageView: PageView.builder(
                                                itemCount: userPostModal
                                                    .opportunityModelForFeed
                                                    .assestVideoAndImage
                                                    .length,
                                                controller: PageController(),
                                                itemBuilder: (context, index2) {
                                                  return Stack(
                                                    children: <Widget>[
                                                      userPostModal
                                                                  .opportunityModelForFeed
                                                                  .assestVideoAndImage[
                                                                      index2]
                                                                  .type ==
                                                              "image"
                                                          ? Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .black,
                                                              ),
                                                              child:
                                                                  CachedNetworkImage(
                                                                width: double
                                                                    .infinity,
                                                                height: 250.0,
                                                                imageUrl: Constant
                                                                        .IMAGE_PATH +
                                                                    userPostModal
                                                                        .opportunityModelForFeed
                                                                        .assestVideoAndImage[
                                                                            index2]
                                                                        .file,
                                                                fit: BoxFit
                                                                    .contain,
                                                                placeholder: (context,
                                                                        url) =>
                                                                    _loader(
                                                                        context),
                                                                errorWidget:
                                                                    (context,
                                                                            url,
                                                                            error) =>
                                                                        _error(),
                                                              ),
                                                            )
                                                          : InkWell(
                                                              child: Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: Colors
                                                                    .black,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            0),
                                                              ),
                                                              height: 250.0,
                                                              child: Center(
                                                                child: VideoPlayPause(
                                                                    userPostModal
                                                                        .opportunityModelForFeed
                                                                        .assestVideoAndImage[
                                                                            index2]
                                                                        .file,
                                                                    "",
                                                                    true,
                                                                    allVideoController),
                                                              ),
                                                            )),
                                                      userPostModal
                                                                      .opportunityModelForFeed
                                                                      .assestVideoAndImage
                                                                      .length ==
                                                                  1 ||
                                                              userPostModal
                                                                      .opportunityModelForFeed
                                                                      .assestVideoAndImage[
                                                                          index2]
                                                                      .type ==
                                                                  "video"
                                                          ? const SizedBox
                                                              .shrink()
                                                          : InkWell(
                                                              onTap: () {
                                                                Navigator.of(context).push(new MaterialPageRoute(
                                                                    builder: (BuildContext context) => CommonFullViewWidget(
                                                                        userPostModal
                                                                            .opportunityModelForFeed
                                                                            .assestVideoAndImage,
                                                                        MessageConstant
                                                                            .HOME_OPPORTUNITY_HEDING,
                                                                        index2,
                                                                        MessageConstant
                                                                            .COMPANY_PROFILE_HEDING)));
                                                              },
                                                              child: Container(
                                                                height: 250.0,
                                                                width: double
                                                                    .infinity,
                                                                child:
                                                                    Image.asset(
                                                                  "assets/newDesignIcon/navigation/layer_image.png",
                                                                  fit: BoxFit
                                                                      .fill,
                                                                ),
                                                              ))
                                                    ],
                                                  );
                                                },
                                                onPageChanged: (index) {},
                                              ),
                                              align: IndicatorAlign.bottom,
                                              length: userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage
                                                  .length,
                                              indicatorSpace: 10.0,
                                              indicatorColor: userPostModal
                                                          .opportunityModelForFeed
                                                          .assestVideoAndImage
                                                          .length ==
                                                      1
                                                  ? Colors.transparent
                                                  : Color(0xffc4c4c4),
                                              indicatorSelectorColor: userPostModal
                                                          .opportunityModelForFeed
                                                          .assestVideoAndImage
                                                          .length ==
                                                      1
                                                  ? Colors.transparent
                                                  : Color(0XFFFFFFFF),
                                              shape: IndicatorShape.circle(
                                                  size: 5.0),
                                            ))
                                        : Stack(
                                            children: <Widget>[
                                              Image.asset(
                                                "assets/profile/default_achievement.png",
                                                fit: BoxFit.cover,
                                                height: 280.0,
                                                width: double.infinity,
                                              ),
                                              Container(
                                                height: 280.0,
                                                color: Colors.black54
                                                    .withOpacity(.4),
                                              ),
                                            ],
                                          ),
                                  ),
                                  Container(
                                    height: 40,
                                    color: ColorValues.call_now_color,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: <Widget>[
                                            diffrenceInDob < 13
                                                ? Expanded(
                                                    child: InkWell(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                15.0,
                                                                7.0,
                                                                15.0,
                                                                0.0),
                                                        child: Container(
                                                            height: 25.0,
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsets
                                                                      .fromLTRB(
                                                                          6.0,
                                                                          0.0,
                                                                          6.0,
                                                                          0.0),
                                                              child: Text(
                                                                "FORWARD TO PARENT",
                                                                style: TextStyle(
                                                                    color: ColorValues
                                                                        .WHITE,
                                                                    fontSize:
                                                                        14.0,
                                                                    fontFamily:
                                                                        Constant
                                                                            .latoRegular,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600),
                                                              ),
                                                            )),
                                                      ),
                                                      onTap: () {
                                                        forwardToParentConformAtionDialog(
                                                            userPostModal,
                                                            index);
                                                      },
                                                    ),
                                                    flex: 0,
                                                  )
                                                : Expanded(
                                                    child: InkWell(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                15.0,
                                                                0.0,
                                                                15.0,
                                                                0.0),
                                                        child: Container(
                                                          height: 25.0,
                                                          //alignment: FractionalOffset.center,
                                                          // decoration: BoxDecoration(
                                                          //   color:
                                                          //       ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                                                          //   border:
                                                          //       Border.all(color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                                                          // ),
                                                          child: Padding(
                                                            padding: EdgeInsets
                                                                .fromLTRB(
                                                                    6.0,
                                                                    0.0,
                                                                    6.0,
                                                                    0.0),
                                                            child: Text(
                                                              userPostModal
                                                                          .opportunityModelForFeed
                                                                          .actionType ==
                                                                      Constant
                                                                          .LINK_URL
                                                                  ? userPostModal
                                                                              .opportunityModelForFeed
                                                                              .linkUrlPosition ==
                                                                          Constant
                                                                              .LEARN_MORE
                                                                      ? "Learn more"
                                                                      : userPostModal.opportunityModelForFeed.linkUrlPosition ==
                                                                              Constant
                                                                                  .GET_OFFER
                                                                          ? "Get offer"
                                                                          : "Apply now"
                                                                  : userPostModal
                                                                              .opportunityModelForFeed
                                                                              .actionType ==
                                                                          Constant
                                                                              .JOIN_GROUP
                                                                      ? "Join group"
                                                                      : userPostModal.opportunityModelForFeed.actionType ==
                                                                              Constant.CALL_NOW
                                                                          ? "Call now"
                                                                          : "Inquire now",
                                                              style: TextStyle(
                                                                  color:
                                                                      ColorValues
                                                                          .WHITE,
                                                                  fontSize:
                                                                      16.0,
                                                                  fontFamily:
                                                                      Constant
                                                                          .latoRegular,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      onTap: () {
                                                        apiCallingForIncreaseCount(
                                                            userPostModal
                                                                .feedId);
                                                        if (userPostModal
                                                                .opportunityModelForFeed
                                                                .actionType ==
                                                            Constant.LINK_URL) {
                                                          onTapView(userPostModal
                                                              .opportunityModelForFeed
                                                              .url);
                                                        } else if (userPostModal
                                                                .opportunityModelForFeed
                                                                .actionType ==
                                                            Constant
                                                                .JOIN_GROUP) {
                                                          if (prefs != null &&
                                                              userPostModal !=
                                                                  null &&
                                                              Util.showJoinGroupButton(
                                                                      prefs,
                                                                      userPostModal
                                                                          .schoolCode,
                                                                      userPostModal
                                                                          .opportunityModelForFeed
                                                                          .actionType) ==
                                                                  "true") {
                                                            apiCallJoinGroup(
                                                                userPostModal
                                                                    .opportunityModelForFeed
                                                                    .groupIdAction);
                                                          } else {
                                                            ToastWrap.showToast(
                                                                MessageConstant
                                                                    .OPPORTUNITY_NOT_IN_COMMUNITY,
                                                                context);
                                                          }
                                                        } else if (userPostModal
                                                                .opportunityModelForFeed
                                                                .actionType ==
                                                            Constant.CALL_NOW) {
                                                          String callingNumber =
                                                              userPostModal
                                                                  .opportunityModelForFeed
                                                                  .callingNumber;
                                                          launch("tel:" +
                                                              callingNumber);
                                                        } else {
                                                          Navigator.of(context).push(new MaterialPageRoute(
                                                              builder: (BuildContext context) => InquireNowScreen(
                                                                  userPostModal
                                                                      .opportunityModelForFeed
                                                                      .opportunityId,
                                                                  userPostModal
                                                                      .feedId,
                                                                  userPostModal
                                                                      .opportunityModelForFeed
                                                                      .formId,
                                                                  userPostModal
                                                                      .opportunityModelForFeed
                                                                      .offerId
                                                                      .toString(),
                                                                  "")));
                                                        }
                                                      },
                                                    ),
                                                    flex: 0,
                                                  ),
                                            Spacer(),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: diffrenceInDob < 13
                                                  ? InkWell(
                                                      child: Image.asset(
                                                        'assets/profile/parent/info.png',
                                                        height: 20.0,
                                                        width: 20.0,
                                                        color: Colors.white,
                                                      ),
                                                      onTap: () {
                                                        infoDialog();
                                                      },
                                                    )
                                                  : Icon(
                                                      Icons.arrow_forward_ios,
                                                      size: 15,
                                                      color: Colors.white,
                                                    ),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          onTap: () {
                            if (diffrenceInDob < 13) {
                              forwardToParentConformAtionDialog(
                                  userPostModal, index);
                            } else {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      OpportunityViewWidget(
                                          userPostModal.opportunityModelForFeed,
                                          userPostModal.feedId,
                                          userIdPref,
                                          roleId,
                                          diffrenceInDob,
                                          "")));
                            }
                          },
                        ),
                        imageViewforOpportunityStack(userPostModal),
                      ],
                    ),
                  ),
                ),
          Row(
            children: [
              Expanded(
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20.0, 5.0, 10.0, 10.0),
                    child: Text(
                      userPostModal.opportunityModelForFeed.offerId == "4" ||
                              userPostModal.opportunityModelForFeed.offerId ==
                                  "5"
                          ? userPostModal.opportunityModelForFeed.serviceTitle
                          : userPostModal.opportunityModelForFeed.jobTitle,
                      style: TextStyle(
                          color: ColorValues.HEADING_COLOR_EDUCATION_1,
                          fontSize: 14.0,
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w400),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                flex: 1,
              ),
            ],
          ),

          Padding(
            padding: const EdgeInsets.only(left: 20, top: 5, right: 20),
            child: Row(
              children: <Widget>[
                InkWell(
                  onTap: () {
                    onTapLike(userPostModal);
                  },
                  child: userPostModal.isLike
                      ? Image.asset(
                          "assets/feed/heart_red.png",
                          height: 21.0,
                          width: 21.0,
                        )
                      : Image.asset(
                          "assets/feed/heart_blue.png",
                          height: 21.0,
                          width: 21.0,
                        ),
                ),
                SizedBox(width: 7),
                InkWell(
                  onTap: () {
                    onTapViewAllComments(userPostModal.commentList,
                        userPostModal.feedId, userPostModal);

                    /* if (userPostModal.isShowCommentIcon)
                                userPostModal.isShowCommentIcon = false;
                              else {
                                _scrollController
                                    .jumpTo((_scrollController.offset + 80.0));
                                userPostModal.isShowCommentIcon = true;
                              }

                              setState(() {
                                userPostModal.isShowCommentIcon;
                              });*/
                  },
                  child: Image.asset(
                    "assets/feed/comment.png",
                    height: 28.0,
                    width: 28.0,
                  ),
                ),
                SizedBox(width: 7),
                _shareButton(onTap: () {
                  if (groupList.isNotEmpty &&
                      groupList[0].status ==
                          MessageConstant.ABOUT_GROUP_ACCEPTED) {
                    optionMenuForShareOpportunity(userPostModal, index);
                  }
                }),
                Spacer(),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
            child: isUserRepoted
                ? ACCESS_CONTROL_GROUP
                    ? Row(
                        children: <Widget>[
                          Expanded(
                            child: userPostModal.likesCount > 0
                                ? PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    0.0,
                                    7.0,
                                    0.0,
                                    InkWell(
                                      child: TextViewWrap.textView(
                                          userPostModal.likesCount == 0
                                              ? "Like"
                                              : userPostModal.likesCount == 1
                                                  ? "1 Like"
                                                  : userPostModal.likesCount
                                                          .toString() +
                                                      " Likes",
                                          TextAlign.end,
                                          ColorValues.labelColor,
                                          12.0,
                                          FontWeight.w500),
                                      onTap: () {
                                        onTapLikeText(userPostModal);
                                      },
                                    ))
                                : const SizedBox.shrink(),
                            flex: 0,
                          ),
                          userPostModal.commentList.length > 0
                              ? InkWell(
                                  child: TextViewWrap.textView(
                                      userPostModal.commentList.length == 0
                                          ? "Comment"
                                          : "" +
                                              userPostModal.commentList.length
                                                  .toString() +
                                              " Comments",
                                      TextAlign.left,
                                      ColorValues.labelColor,
                                      12.0,
                                      FontWeight.w500),
                                  onTap: () {
                                    onTapViewAllComments(
                                        userPostModal.commentList,
                                        userPostModal.feedId,
                                        userPostModal);
                                  },
                                )
                              : const SizedBox.shrink()
                        ],
                      )
                    : const SizedBox.shrink()
                : const SizedBox.shrink(),
          ),

          ///Don't remove it
          // isUserRepoted
          //     ? ACCESS_CONTROL_FEED
          //     ? PaddingWrap.paddingAll(
          //     0.0,
          //     Column(
          //       crossAxisAlignment: CrossAxisAlignment.start,
          //       mainAxisAlignment: MainAxisAlignment.start,
          //       children: <Widget>[
          //         // Comment List view
          //         Padding(
          //             padding: EdgeInsets.fromLTRB(
          //                 10.0, 12.0, 10.0, 0.0),
          //             child: Column(
          //                 crossAxisAlignment:
          //                 CrossAxisAlignment.start,
          //                 children: List.generate(
          //                     userPostModal.commentList
          //                         .length >
          //                         3
          //                         ? 3
          //                         : userPostModal.commentList
          //                         .length, (int index) {
          //                   return PaddingWrap
          //                       .paddingfromLTRB(
          //                       10.0,
          //                       5.0,
          //                       10.0,
          //                       12.0,
          //                       Row(
          //                         crossAxisAlignment:
          //                         CrossAxisAlignment
          //                             .start,
          //                         children: <Widget>[
          //
          //
          //                           ProfileImageView(
          //                             imagePath: Constant
          //                                 .IMAGE_PATH_SMALL +
          //                                 userPostModal
          //                                     .commentList[index]
          //                                     .profilePicture,
          //                             placeHolderImage: userPostModal
          //                                 .commentList[index]
          //                                 .roleId ==
          //                                 "4"
          //                                 ? "assets/profile/partner_img.png"
          //                                 : 'assets/profile/user_on_user.png',
          //                             width: 40.0,
          //                             height: 40.0,
          //                             onTap: () async {
          //                               onTapImageTile(
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .commentedBy,
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .roleId);
          //                             },
          //                           ), // User Image
          //                           SizedBox(
          //                             width: 9.0,
          //                           ),
          //                           Expanded(
          //                             child: Column(
          //                               crossAxisAlignment:
          //                               CrossAxisAlignment
          //                                   .start,
          //                               mainAxisAlignment:
          //                               MainAxisAlignment
          //                                   .start,
          //                               children: <
          //                                   Widget>[
          //                                 Padding(
          //                                   padding:
          //                                   const EdgeInsets
          //                                       .fromLTRB(
          //                                       0,
          //                                       0,
          //                                       0,
          //                                       0),
          //                                   child:
          //                                   Container(
          //                                       child:
          //                                       Row(
          //                                         children: <
          //                                             Widget>[
          //                                           RichText(
          //                                             maxLines:
          //                                             2,
          //                                             textAlign:
          //                                             TextAlign.start,
          //                                             text:
          //                                             TextSpan(
          //                                               text: userPostModal
          //                                                   .commentList[index]
          //                                                   .name,
          //                                               style:
          //                                               TextStyle(
          //                                                 color:
          //                                                 ColorValues
          //                                                     .HEADING_COLOR_EDUCATION_1,
          //                                                 fontSize:
          //                                                 14.0,
          //                                                 fontWeight:
          //                                                 FontWeight
          //                                                     .bold,
          //                                               ),
          //                                             ),
          //                                           ),
          //                                           userPostModal
          //                                               .commentList[index] !=
          //                                               null &&
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .roleId ==
          //                                                   "1"
          //                                           //true
          //                                               ? Util
          //                                               .getStudentBadge12(
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .badge,
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .badgeImage)
          //                                               : Container(),
          //                                         ],
          //                                       )),
          //                                 ),
          //                                 Container(
          //                                   child:
          //                                   Linkify(
          //                                     onOpen:
          //                                         (link) async {
          //                                       Navigator.of(context,
          //                                           rootNavigator: true)
          //                                           .push(
          //                                           new MaterialPageRoute(
          //                                               fullscreenDialog:
          //                                               true,
          //                                               builder: (
          //                                                   BuildContext context) =>
          //                                                   WebViewWidget(
          //                                                       link
          //                                                           .url,
          //                                                       "spikeview")));
          //                                     },
          //                                     text: userPostModal
          //                                         .commentList[
          //                                     index]
          //                                         .comment,
          //                                     style: TextStyle(
          //                                         color: ColorValues
          //                                             .HEADING_COLOR_EDUCATION_1,
          //                                         fontSize:
          //                                         14.0,
          //                                         fontWeight:
          //                                         FontWeight
          //                                             .normal,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR),
          //                                     linkStyle: TextStyle(
          //                                         color: ColorValues
          //                                             .BLUE_COLOR_BOTTOMBAR,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR,
          //                                         fontSize:
          //                                         14.0),
          //                                   ),
          //                                 ),
          //                                 Padding(
          //                                     padding: EdgeInsets
          //                                         .fromLTRB(
          //                                         0.0,
          //                                         5.0,
          //                                         0.0,
          //                                         0.0),
          //                                     child: Row(
          //                                       mainAxisAlignment:
          //                                       MainAxisAlignment
          //                                           .start,
          //                                       crossAxisAlignment:
          //                                       CrossAxisAlignment
          //                                           .center,
          //                                       children: <
          //                                           Widget>[
          //                                         Expanded(
          //                                           child:
          //                                           Row(
          //                                             mainAxisAlignment:
          //                                             MainAxisAlignment
          //                                                 .start,
          //                                             crossAxisAlignment:
          //                                             CrossAxisAlignment
          //                                                 .start,
          //                                             children: <
          //                                                 Widget>[
          //                                               Text(
          //                                                 userPostModal
          //                                                     .commentList[index]
          //                                                     .dateTime,
          //                                                 textAlign: TextAlign
          //                                                     .end,
          //                                                 style: TextStyle(
          //                                                     color: ColorValues
          //                                                         .GREY_TEXT_COLOR,
          //                                                     fontSize: 12.0,
          //                                                     fontFamily: Constant
          //                                                         .customRegular),
          //                                               )
          //                                             ],
          //                                           ),
          //                                           flex:
          //                                           0,
          //                                         ),
          //                                         Container(
          //                                           width:
          //                                           10.0,
          //                                         ),
          //                                         Expanded(
          //                                           child: userIdPref ==
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .commentedBy //&& userPostModal.commentList[index].isComment
          //                                               ? InkWell(
          //                                             child: Padding(
          //                                               padding: const EdgeInsets
          //                                                   .fromLTRB(
          //                                                   0.0, 0, 0,
          //                                                   0),
          //                                               child: Image
          //                                                   .asset(
          //                                                 "assets/feed/three_dot_blue.png",
          //                                                 width: 15.0,
          //                                                 height: 15.0,
          //                                               ),
          //                                             ),
          //                                             onTap: () {
          //                                               optionForDelete(
          //                                                   userPostModal
          //                                                       .commentList,
          //                                                   userPostModal
          //                                                       .feedId,
          //                                                   userPostModal,
          //                                                   userPostModal
          //                                                       .commentList[index]
          //                                                       .commentId,
          //                                                   index);
          //                                             },
          //                                           )
          //                                               : Container(
          //                                             height: 1.0,
          //                                           ),
          //                                           flex:
          //                                           0,
          //                                         )
          //                                       ],
          //                                     )),
          //                               ],
          //                             ),
          //                             flex: 1,
          //                           ) ,
          //                         ],
          //                       ),);
          //                 },),),),
          //
          //         // View All Comments
          //         userPostModal.commentList.length > 3
          //             ? InkWell(
          //           child: PaddingWrap.paddingfromLTRB(
          //             10.0,
          //             0.0,
          //             0.0,
          //             5.0,
          //             TextViewWrap.textView(
          //                 "View All " +
          //                     userPostModal
          //                         .commentList.length
          //                         .toString() +
          //                     " Comments",
          //                 TextAlign.left,
          //                 ColorValues.labelColor,
          //                 12.0,
          //                 FontWeight.w500),
          //           ),
          //           onTap: () {
          //             onTapViewAllComments(
          //                 userPostModal.commentList,
          //                 userPostModal.feedId,
          //                 userPostModal);
          //           },
          //         )
          //             : Container(
          //           height: 0.0,
          //         ),
          //
          //         // Comment Edit Text
          //         userPostModal.isShowCommentIcon
          //             ? PaddingWrap.paddingAll(
          //             10.0,
          //             Row(
          //               children: <Widget>[
          //
          //
          //                 //Alok Code Done
          //                 ProfileImageView(
          //                   imagePath: roleId == "4"
          //                       ? Constant
          //                       .IMAGE_PATH +
          //                       companyPath
          //                       : Constant
          //                       .IMAGE_PATH +
          //                       profilePath,
          //                   placeHolderImage: roleId == "4"
          //                       ? "assets/profile/partner_img.png"
          //                       : 'assets/profile/user_on_user.png',
          //                   width: 40.0,
          //                   height: 40.0,
          //                   onTap: () async {
          //
          //                   },
          //                 ),
          //                 SizedBox(
          //                   width: 9.0,
          //                 ),
          //                 Expanded(
          //                     child: Container(
          //                         decoration: BoxDecoration(
          //                             border: Border.all(
          //                                 width: 1.0,
          //                                 color: ColorValues
          //                                     .LIGHT_GREY_TEXT_COLOR)),
          //                         child: Row(
          //                           crossAxisAlignment:
          //                           CrossAxisAlignment
          //                               .center,
          //                           mainAxisAlignment:
          //                           MainAxisAlignment
          //                               .center,
          //                           children: <Widget>[
          //                             Expanded(
          //                               child: TextField(
          //                                 controller:
          //                                 userPostModal
          //                                     .txtController,
          //                                 style: TextStyle(
          //                                     fontFamily:
          //                                     Constant
          //                                         .TYPE_CUSTOMREGULAR),
          //                                 keyboardType:
          //                                 TextInputType
          //                                     .text,
          //                                 textCapitalization:
          //                                 TextCapitalization
          //                                     .sentences,
          //                                 maxLines: null,
          //                                 maxLength:
          //                                 TextLength
          //                                     .COMMENT_MAX_LENGTH,
          //                                 onChanged: (s) {
          //                                   if (s
          //                                       .trim()
          //                                       .length >
          //                                       0) {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     true;
          //                                   } else {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                   }
          //                                   setState(() {
          //                                   });
          //                                 },
          //                                 decoration:
          //                                 InputDecoration(
          //                                   border:
          //                                   InputBorder
          //                                       .none,
          //                                   filled: true,
          //                                   counterStyle:
          //                                   TextStyle(
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   counterText:
          //                                   "",
          //                                   hintText: roleId ==
          //                                       "4"
          //                                       ? "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference
          //                                               .COMPANY_NAME_PATH)
          //                                       : "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference.NAME)
          //                                           .replaceAll(
          //                                           "null",
          //                                           ""),
          //                                   hintStyle: TextStyle(
          //                                       color: ColorValues
          //                                           .GREY_TEXT_COLOR,
          //                                       fontSize:
          //                                       14.0,
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   fillColor: Colors
          //                                       .transparent,
          //                                 ),
          //                               ),
          //                               flex: 4,
          //                             ),
          //                             Expanded(
          //                               child:
          //                               /*userPostModal
          //                                         .isCommentIconVisible
          //                                     ?*/
          //                               InkWell(
          //                                 child: PaddingWrap
          //                                     .paddingfromLTRB(
          //                                     0.0,
          //                                     0.0,
          //                                     5.0,
          //                                     0.0,
          //                                     Image
          //                                         .asset(
          //                                       "assets/feed/sent_icon.png",
          //                                       width:
          //                                       22.0,
          //                                       height:
          //                                       22.0,
          //                                     )),
          //                                 onTap: () {
          //                                   if (userPostModal
          //                                       .isCommentIconVisible) {
          //                                     FocusScope.of(
          //                                         context)
          //                                         .requestFocus(
          //                                         FocusNode());
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                     onAddComment(
          //                                         userPostModal
          //                                             .feedId,
          //                                         userPostModal
          //                                             .txtController
          //                                             .text,
          //                                         userPostModal);
          //                                     userPostModal
          //                                         .txtController
          //                                         .text = "";
          //                                     setState(
          //                                             () {
          //
          //                                         });
          //                                   }
          //                                 },
          //                               )
          //                               /*:  Container(
          //                                         height: 0.0,
          //                                       )*/
          //                               ,
          //                               flex: 0,
          //                             )
          //                           ],
          //                         )),
          //                     flex: 1)
          //               ],
          //             ))
          //             : Container(
          //           height: 0.0,
          //         ),
          //
          //         (userPostList.length - 1) == index
          //             ? Container(
          //           height: 10.0,
          //         )
          //             : const SizedBox.shrink(),
          //         Container(
          //           height: 20.0,
          //         ),
          //       ],
          //     ),)
          //     : const SizedBox.shrink()
          //     : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget imageViewForOpportunityOwner(userPostModal, index) {
    return Container(
        decoration: new BoxDecoration(
          /*image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),*/
          gradient: LinearGradient(
            colors: [
              Color(0xff000000),
              Color(0x00000000),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        padding: const EdgeInsets.fromLTRB(20, 12, 0, 10),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(
                      userPostModal.opportunityModelForFeed.profilePicture),
              placeHolderImage: userPostModal.roleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 46.0,
              height: 46.0,
              onTap: () async {
                onTapImageTile(userPostModal.postedBy, userPostModal.roleId);
              },
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child: Row(
                      children: <Widget>[
                        RichText(
                          maxLines: 2,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            text: userPostModal
                                .opportunityModelForFeed.companyName,
                            style: TextStyle(
                              color: ColorValues.WHITE,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w500,
                              fontFamily: Constant.latoRegular,
                            ),
                          ),
                        ),
                      ],
                    ),
                    onTap: () {
                      onTapImageTile(
                          userPostModal.postedBy, userPostModal.roleId);
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: TextViewWrap.textView(
                        userPostModal.dateTime,
                        TextAlign.center,
                        ColorValues.WHITE,
                        12.0,
                        FontWeight.w500),
                  ),
                ],
              ),
            ),
            InkWell(
              child: Padding(
                padding: EdgeInsets.fromLTRB(13, 3, 13, 3),
                child: Image.asset(
                  "assets/feed/three_dot_white.png",
                  width: 15.0,
                  height: 15.0,
                ),
              ),
              onTap: () {
                userIdPref == userPostModal.postedBy &&
                        roleId == userPostModal.roleId.toString()
                    ? onlyDeletePopUp(userPostModal, index)
                    : issuePopUp(userPostModal, index);
              },
            ),
          ],
        ));
  }

  Widget getListViewForOpportunity(
      UserPostModal userPostModal, index, bool isUserRepoted) {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 21),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          InkWell(
            child: Container(
              width: double.infinity,
              child: Stack(
                children: <Widget>[
                  PaddingWrap.paddingfromLTRB(
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    //
                    userPostModal.opportunityModelForFeed.assestVideoAndImage
                                .length >
                            0
                        ? SizedBox(
                            // Pager view
                            height: 250.0,
                            child: PageIndicatorContainer(
                              pageView: PageView.builder(
                                itemCount: userPostModal.opportunityModelForFeed
                                    .assestVideoAndImage.length,
                                controller: PageController(),
                                itemBuilder: (context, index2) {
                                  return Stack(
                                    children: <Widget>[
                                      userPostModal
                                                  .opportunityModelForFeed
                                                  .assestVideoAndImage[index2]
                                                  .type ==
                                              "image"
                                          ? Container(
                                              decoration: BoxDecoration(
                                                color: Colors.black,
                                              ),
                                              child: CachedNetworkImage(
                                                width: double.infinity,
                                                height: 250.0,
                                                imageUrl: Constant.IMAGE_PATH +
                                                    userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage[
                                                            index2]
                                                        .file,
                                                fit: BoxFit.contain,
                                                placeholder: (context, url) =>
                                                    _loader(context),
                                                errorWidget:
                                                    (context, url, error) =>
                                                        _error(),
                                              ),
                                            )
                                          : InkWell(
                                              child: Container(
                                              decoration: BoxDecoration(
                                                color: Colors.black,
                                                borderRadius:
                                                    BorderRadius.circular(0),
                                              ),
                                              height: 250.0,
                                              child: Center(
                                                child: VideoPlayPause(
                                                    userPostModal
                                                        .opportunityModelForFeed
                                                        .assestVideoAndImage[
                                                            index2]
                                                        .file,
                                                    "",
                                                    true,
                                                    allVideoController),
                                              ),
                                            )),
                                      userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage
                                                      .length ==
                                                  1 ||
                                              userPostModal
                                                      .opportunityModelForFeed
                                                      .assestVideoAndImage[
                                                          index2]
                                                      .type ==
                                                  "video"
                                          ? Container(
                                              height: 0.0,
                                            )
                                          : InkWell(
                                              onTap: () {
                                                Navigator.of(context).push(new MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                        CommonFullViewWidget(
                                                            userPostModal
                                                                .opportunityModelForFeed
                                                                .assestVideoAndImage,
                                                            MessageConstant
                                                                .HOME_OPPORTUNITY_HEDING,
                                                            index2,
                                                            MessageConstant
                                                                .COMPANY_PROFILE_HEDING)));
                                              },
                                              child: Container(
                                                height: 250.0,
                                                width: double.infinity,
                                                child: Image.asset(
                                                  "assets/newDesignIcon/navigation/layer_image.png",
                                                  fit: BoxFit.fill,
                                                ),
                                              ))
                                    ],
                                  );
                                },
                                onPageChanged: (index) {},
                              ),
                              align: IndicatorAlign.bottom,
                              length: userPostModal.opportunityModelForFeed
                                  .assestVideoAndImage.length,
                              indicatorSpace: 10.0,
                              indicatorColor: userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length ==
                                      1
                                  ? Colors.transparent
                                  : Color(0xffc4c4c4),
                              indicatorSelectorColor: userPostModal
                                          .opportunityModelForFeed
                                          .assestVideoAndImage
                                          .length ==
                                      1
                                  ? Colors.transparent
                                  : ColorValues.WHITE,
                              shape: IndicatorShape.circle(size: 5.0),
                            ))
                        : Stack(
                            children: <Widget>[
                              Image.asset(
                                "assets/profile/default_achievement.png",
                                fit: BoxFit.cover,
                                height: 250.0,
                                width: double.infinity,
                              ),
                              Container(
                                height: 250.0,
                                color: Colors.black54.withOpacity(.4),
                              )
                            ],
                          ),
                  ),
                  imageViewForOpportunityOwner(userPostModal, index),
                ],
              ),
            ),
            onTap: () {
              Navigator.of(context).push(new MaterialPageRoute(
                  builder: (BuildContext context) => OpportunityViewWidget(
                      userPostModal.opportunityModelForFeed,
                      userPostModal.feedId,
                      userIdPref,
                      roleId,
                      diffrenceInDob,
                      "")));
            },
          ),
          Container(
            height: 40,
            color: ColorValues.call_now_color,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    diffrenceInDob < 13
                        ? Expanded(
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    15.0, 7.0, 15.0, 0.0),
                                child: Container(
                                    height: 25.0,
                                    child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          6.0, 0.0, 6.0, 0.0),
                                      child: Text(
                                        "FORWARD TO PARENT",
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    )),
                              ),
                              onTap: () {
                                forwardToParentConformAtionDialog(
                                    userPostModal, index);
                              },
                            ),
                            flex: 0,
                          )
                        : Expanded(
                            child: InkWell(
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    15.0, 0.0, 15.0, 0.0),
                                child: Container(
                                    height: 25.0,
                                    // alignment:
                                    //     FractionalOffset
                                    //         .center,
                                    // decoration: BoxDecoration(
                                    //   color: ColorValues
                                    //       .OPPORTUNITY_GROUP_SELECTION_GRP,
                                    //   border: Border.all(
                                    //       color: ColorValues
                                    //           .BLUE_COLOR_BOTTOMBAR),
                                    // ),
                                    child: Padding(
                                      padding: EdgeInsets.fromLTRB(
                                          6.0, 0.0, 6.0, 0.0),
                                      child: Text(
                                        userPostModal.opportunityModelForFeed
                                                    .actionType ==
                                                Constant.LINK_URL
                                            ? userPostModal
                                                        .opportunityModelForFeed
                                                        .linkUrlPosition ==
                                                    Constant.LEARN_MORE
                                                ? "Learn more"
                                                : userPostModal
                                                            .opportunityModelForFeed
                                                            .linkUrlPosition ==
                                                        Constant.GET_OFFER
                                                    ? "Get offer"
                                                    : "Apply now"
                                            : userPostModal
                                                        .opportunityModelForFeed
                                                        .actionType ==
                                                    Constant.JOIN_GROUP
                                                ? "Join group"
                                                : userPostModal
                                                            .opportunityModelForFeed
                                                            .actionType ==
                                                        Constant.CALL_NOW
                                                    ? "Call now"
                                                    : "Inquire now",
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 16.0,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    )),
                              ),
                              onTap: () {
                                apiCallingForIncreaseCount(
                                    userPostModal.feedId);
                                if (userPostModal
                                        .opportunityModelForFeed.actionType ==
                                    Constant.LINK_URL) {
                                  onTapView(
                                    userPostModal.opportunityModelForFeed.url,
                                  );
                                } else if (userPostModal
                                        .opportunityModelForFeed.actionType ==
                                    Constant.JOIN_GROUP) {
                                  if (prefs != null &&
                                      userPostModal != null &&
                                      Util.showJoinGroupButton(
                                              prefs,
                                              userPostModal.schoolCode,
                                              userPostModal
                                                  .opportunityModelForFeed
                                                  .actionType) ==
                                          "true") {
                                    apiCallJoinGroup(userPostModal
                                        .opportunityModelForFeed.groupIdAction);
                                  } else {
                                    ToastWrap.showToast(
                                        MessageConstant
                                            .OPPORTUNITY_NOT_IN_COMMUNITY,
                                        context);
                                  }
                                } else if (userPostModal
                                        .opportunityModelForFeed.actionType ==
                                    Constant.CALL_NOW) {
                                  String callingNumber = userPostModal
                                      .opportunityModelForFeed.callingNumber;
                                  launch("tel:" + callingNumber);
                                } else {
                                  Navigator.of(context).push(
                                      new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              InquireNowScreen(
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .opportunityId,
                                                  userPostModal.feedId,
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .formId,
                                                  userPostModal
                                                      .opportunityModelForFeed
                                                      .offerId
                                                      .toString(),
                                                  "")));
                                }
                              },
                            ),
                            flex: 0,
                          ),
                    Spacer(),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: diffrenceInDob < 13
                          ? InkWell(
                              child: Image.asset(
                                'assets/profile/parent/info.png',
                                height: 20.0,
                                width: 20.0,
                                color: Colors.white,
                              ),
                              onTap: () {
                                infoDialog();
                              },
                            )
                          : Icon(
                              Icons.arrow_forward_ios,
                              size: 15,
                              color: Colors.white,
                            ),
                    )
                  ],
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20, top: 10, right: 20),
            child: Row(
              children: <Widget>[
                InkWell(
                  onTap: () {
                    onTapLike(userPostModal);
                  },
                  child: userPostModal.isLike
                      ? Image.asset(
                          "assets/feed/heart_red.png",
                          height: 21.0,
                          width: 21.0,
                        )
                      : Image.asset(
                          "assets/feed/heart_blue.png",
                          height: 21.0,
                          width: 21.0,
                        ),
                ),
                SizedBox(
                  width: 7,
                ),
                InkWell(
                  onTap: () {
                    onTapViewAllComments(userPostModal.commentList,
                        userPostModal.feedId, userPostModal);

                    /*  if (userPostModal.isShowCommentIcon)
                              userPostModal.isShowCommentIcon = false;
                            else {
                              _scrollController
                                  .jumpTo((_scrollController.offset + 80.0));
                              userPostModal.isShowCommentIcon = true;
                            }

                            setState(() {
                              userPostModal.isShowCommentIcon;
                            });*/
                  },
                  child: Image.asset(
                    "assets/feed/comment.png",
                    height: 28.0,
                    width: 28.0,
                  ),
                ),
                SizedBox(
                  width: 7,
                ),
                _shareButton(onTap: () {
                  if (groupList.isNotEmpty &&
                      groupList[0].status ==
                          MessageConstant.ABOUT_GROUP_ACCEPTED) {
                    optionMenuForShareOpportunity(userPostModal, index);
                  }
                }),
                Spacer(),
                // Padding(
                //   padding: const EdgeInsets.only(
                //     right: 20,
                //   ),
                //   child: InkWell(
                //     onTap: () {
                //       print("sss like");
                //     },
                //     child: Image.asset(
                //       "assets/feed/save_icon_border.png",
                //       height: 12.0,
                //       width: 12.0,
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
          isUserRepoted
              ? ACCESS_CONTROL_GROUP
                  ? userPostModal.likesCount > 0 ||
                          userPostModal.commentList.length > 0
                      ? Padding(
                          padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: userPostModal.likesCount > 0
                                    ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        7.0,
                                        0.0,
                                        InkWell(
                                          child: TextViewWrap.textView(
                                              userPostModal.likesCount == 0
                                                  ? "Like"
                                                  : userPostModal.likesCount ==
                                                          1
                                                      ? "1 Like"
                                                      : userPostModal.likesCount
                                                              .toString() +
                                                          " Likes",
                                              TextAlign.end,
                                              ColorValues.labelColor,
                                              12.0,
                                              FontWeight.w500),
                                          onTap: () {
                                            onTapLikeText(userPostModal);
                                          },
                                        ))
                                    : const SizedBox.shrink(),
                                flex: 0,
                              ),
                              userPostModal.commentList.length == 0
                                  ? const SizedBox.shrink()
                                  : InkWell(
                                      child: TextViewWrap.textView(
                                          userPostModal.commentList.length == 0
                                              ? "Comment"
                                              : "" +
                                                  userPostModal
                                                      .commentList.length
                                                      .toString() +
                                                  " Comments",
                                          TextAlign.left,
                                          ColorValues.labelColor,
                                          12.0,
                                          FontWeight.w500),
                                      onTap: () {
                                        onTapViewAllComments(
                                            userPostModal.commentList,
                                            userPostModal.feedId,
                                            userPostModal);
                                      },
                                    )
                            ],
                          ),
                        )
                      : const SizedBox.shrink()
                  : const SizedBox.shrink()
              : const SizedBox.shrink(),
          Padding(
            padding: const EdgeInsets.fromLTRB(20.0, 8.0, 20.0, 0.0),
            child: Text(
              userPostModal.opportunityModelForFeed.offerId == "4" ||
                      userPostModal.opportunityModelForFeed.offerId == "5"
                  ? userPostModal.opportunityModelForFeed.serviceTitle
                  : userPostModal.opportunityModelForFeed.jobTitle,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                  fontSize: 14.0,
                  fontFamily: Constant.latoRegular,
                  fontWeight: FontWeight.w400),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),

          ///Don't remove it
          // isUserRepoted
          //     ? ACCESS_CONTROL_FEED
          //     ? PaddingWrap.paddingAll(
          //     0.0,
          //     Column(
          //       crossAxisAlignment: CrossAxisAlignment.start,
          //       mainAxisAlignment: MainAxisAlignment.start,
          //       children: <Widget>[
          //         // Comment List view
          //         Padding(
          //             padding: EdgeInsets.fromLTRB(
          //                 10.0, 12.0, 10.0, 10.0),
          //             child: Column(
          //                 crossAxisAlignment:
          //                 CrossAxisAlignment.start,
          //                 children: List.generate(
          //                     userPostModal.commentList.length >
          //                         3
          //                         ? 3
          //                         : userPostModal.commentList
          //                         .length, (int index) {
          //                   return PaddingWrap.paddingfromLTRB(
          //                       10.0,
          //                       5.0,
          //                       10.0,
          //                       12.0,
          //                       Row(
          //                         crossAxisAlignment:
          //                         CrossAxisAlignment.start,
          //                         children: <Widget>[
          //
          //                           ProfileImageView(
          //                             imagePath: Constant
          //                                 .IMAGE_PATH_SMALL +
          //                                 userPostModal
          //                                     .commentList[
          //                                 index]
          //                                     .profilePicture,
          //                             placeHolderImage: userPostModal
          //                                 .commentList[
          //                             index]
          //                                 .roleId ==
          //                                 "4"
          //                                 ? "assets/profile/partner_img.png"
          //                                 : 'assets/profile/user_on_user.png',
          //                             width: 40.0,
          //                             height: 40.0,
          //                             onTap: () async {
          //                               onTapImageTile(
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .commentedBy,
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .roleId);
          //                             },
          //                           ), // User Image
          //                           SizedBox(
          //                             width: 9.0,
          //                           ),
          //                           Expanded(
          //                             child: Column(
          //                               crossAxisAlignment:
          //                               CrossAxisAlignment
          //                                   .start,
          //                               mainAxisAlignment:
          //                               MainAxisAlignment
          //                                   .start,
          //                               children: <Widget>[
          //                                 Padding(
          //                                   padding:
          //                                   const EdgeInsets
          //                                       .fromLTRB(
          //                                       0, 0, 0, 0),
          //                                   child: Container(
          //                                       child: Row(
          //                                         children: <
          //                                             Widget>[
          //                                           RichText(
          //                                             maxLines: 2,
          //                                             textAlign:
          //                                             TextAlign
          //                                                 .start,
          //                                             text:
          //                                             TextSpan(
          //                                               text: userPostModal
          //                                                   .commentList[
          //                                               index]
          //                                                   .name,
          //                                               style:
          //                                               TextStyle(
          //                                                 color: ColorValues
          //                                                     .HEADING_COLOR_EDUCATION_1,
          //                                                 fontSize:
          //                                                 14.0,
          //                                                 fontWeight:
          //                                                 FontWeight
          //                                                     .bold,
          //                                               ),
          //                                               /* children: <TextSpan>[
          //                                                     TextSpan(
          //                                                         text: userPostModal
          //                                                             .commentList[
          //                                                                 index]
          //                                                             .comment,
          //                                                         style:  TextStyle(
          //                                                             color: ColorValues.HEADING_COLOR_EDUCATION_1,
          //                                                             fontSize:
          //                                                                 14.0,
          //                                                             fontWeight:
          //                                                                 FontWeight
          //                                                                     .normal,
          //                                                             fontFamily:
          //                                                                 Constant.TYPE_CUSTOMREGULAR)),
          //                                                   ],*/
          //                                             ),
          //                                           ),
          //                                           userPostModal
          //                                               .commentList[index] !=
          //                                               null &&
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .roleId ==
          //                                                   "1"
          //                                           //true
          //                                               ? Util
          //                                               .getStudentBadge12(
          //                                               userPostModal
          //                                                   .commentList[
          //                                               index]
          //                                                   .badge,
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .badgeImage)
          //                                               : Container(),
          //                                         ],
          //                                       )),
          //                                 ),
          //                                 Container(
          //                                   child: Linkify(
          //                                     onOpen:
          //                                         (link) async {
          //                                       Navigator.of(
          //                                           context,
          //                                           rootNavigator:
          //                                           true)
          //                                           .push(
          //                                           new MaterialPageRoute(
          //                                               fullscreenDialog:
          //                                               true,
          //                                               builder: (
          //                                                   BuildContext context) =>
          //                                                   WebViewWidget(
          //                                                       link.url,
          //                                                       "spikeview")));
          //                                     },
          //                                     text: userPostModal
          //                                         .commentList[
          //                                     index]
          //                                         .comment,
          //                                     style: TextStyle(
          //                                         color: ColorValues
          //                                             .HEADING_COLOR_EDUCATION_1,
          //                                         fontSize:
          //                                         14.0,
          //                                         fontWeight:
          //                                         FontWeight
          //                                             .normal,
          //                                         fontFamily:
          //                                         Constant
          //                                             .latoRegular),
          //                                     linkStyle: TextStyle(
          //                                         color: ColorValues
          //                                             .BLUE_COLOR_BOTTOMBAR,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR,
          //                                         fontSize:
          //                                         14.0),
          //                                   ),
          //                                 ),
          //                                 Padding(
          //                                     padding:
          //                                     EdgeInsets
          //                                         .fromLTRB(
          //                                         0.0,
          //                                         5.0,
          //                                         0.0,
          //                                         0.0),
          //                                     child: Row(
          //                                       mainAxisAlignment:
          //                                       MainAxisAlignment
          //                                           .start,
          //                                       crossAxisAlignment:
          //                                       CrossAxisAlignment
          //                                           .center,
          //                                       children: <
          //                                           Widget>[
          //                                         Expanded(
          //                                           child: Row(
          //                                             mainAxisAlignment:
          //                                             MainAxisAlignment
          //                                                 .start,
          //                                             crossAxisAlignment:
          //                                             CrossAxisAlignment
          //                                                 .start,
          //                                             children: <
          //                                                 Widget>[
          //                                               Text(
          //                                                 userPostModal
          //                                                     .commentList[index]
          //                                                     .dateTime,
          //                                                 textAlign:
          //                                                 TextAlign.end,
          //                                                 style: TextStyle(
          //                                                     color: ColorValues
          //                                                         .GREY_TEXT_COLOR,
          //                                                     fontSize: 12.0,
          //                                                     fontFamily: Constant
          //                                                         .customRegular),
          //                                               )
          //                                             ],
          //                                           ),
          //                                           flex: 0,
          //                                         ),
          //                                         Container(
          //                                           width: 10.0,
          //                                         ),
          //                                         Expanded(
          //                                           child: userIdPref ==
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .commentedBy //&&
          //                                           // userPostModal.commentList[index].isComment
          //                                               ? InkWell(
          //                                             child:
          //                                             Padding(
          //                                               padding: const EdgeInsets
          //                                                   .fromLTRB(
          //                                                   0.0, 0, 0, 0),
          //                                               child: Image
          //                                                   .asset(
          //                                                 "assets/feed/three_dot_blue.png",
          //                                                 width: 15.0,
          //                                                 height: 15.0,
          //                                               ),
          //                                             ),
          //                                             onTap:
          //                                                 () {
          //                                               optionForDelete(
          //                                                   userPostModal
          //                                                       .commentList,
          //                                                   userPostModal
          //                                                       .feedId,
          //                                                   userPostModal,
          //                                                   userPostModal
          //                                                       .commentList[index]
          //                                                       .commentId,
          //                                                   index);
          //                                             },
          //                                           )
          //                                               : Container(
          //                                             height:
          //                                             1.0,
          //                                           ),
          //                                           flex: 0,
          //                                         )
          //                                       ],
          //                                     )),
          //                               ],
          //                             ),
          //                             flex: 1,
          //                           ) // Comment List Cell
          //                         ],
          //                       ));
          //                 }))),
          //
          //         // View All Comments
          //         userPostModal.commentList.length > 3
          //             ? InkWell(
          //           child: PaddingWrap.paddingfromLTRB(
          //             10.0,
          //             0.0,
          //             0.0,
          //             5.0,
          //             TextViewWrap.textView(
          //                 "View All " +
          //                     userPostModal
          //                         .commentList.length
          //                         .toString() +
          //                     " Comments",
          //                 TextAlign.left,
          //                 ColorValues.labelColor,
          //                 12.0,
          //                 FontWeight.w500),
          //           ),
          //           onTap: () {
          //             onTapViewAllComments(
          //                 userPostModal.commentList,
          //                 userPostModal.feedId,
          //                 userPostModal);
          //           },
          //         )
          //             : const SizedBox.shrink(),
          //
          //         // Comment Edit Text
          //         userPostModal.isShowCommentIcon
          //             ? PaddingWrap.paddingAll(
          //             10.0,
          //             Row(
          //               children: <Widget>[
          //
          //
          //                 //Alok Code Done
          //                 ProfileImageView(
          //                   imagePath: roleId == "4"
          //                       ? Constant.IMAGE_PATH +
          //                       companyPath
          //                       : Constant.IMAGE_PATH +
          //                       profilePath,
          //                   placeHolderImage: roleId == "4"
          //                       ? "assets/profile/partner_img.png"
          //                       : 'assets/profile/user_on_user.png',
          //                   width: 40.0,
          //                   height: 40.0,
          //                   onTap: () async {
          //
          //                   },
          //                 ),
          //                 SizedBox(
          //                   width: 9.0,
          //                 ),
          //                 Expanded(
          //                     child: Container(
          //                         decoration: BoxDecoration(
          //                             border: Border.all(
          //                                 width: 1.0,
          //                                 color: ColorValues
          //                                     .LIGHT_GREY_TEXT_COLOR)),
          //                         child: Row(
          //                           crossAxisAlignment:
          //                           CrossAxisAlignment
          //                               .center,
          //                           mainAxisAlignment:
          //                           MainAxisAlignment
          //                               .center,
          //                           children: <Widget>[
          //                             Expanded(
          //                               child: TextField(
          //                                 controller:
          //                                 userPostModal
          //                                     .txtController,
          //                                 style: TextStyle(
          //                                     fontFamily:
          //                                     Constant
          //                                         .TYPE_CUSTOMREGULAR),
          //                                 keyboardType:
          //                                 TextInputType
          //                                     .text,
          //                                 textCapitalization:
          //                                 TextCapitalization
          //                                     .sentences,
          //                                 maxLines: null,
          //                                 maxLength: TextLength
          //                                     .COMMENT_MAX_LENGTH,
          //                                 onChanged: (s) {
          //                                   if (s
          //                                       .trim()
          //                                       .length >
          //                                       0) {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     true;
          //                                   } else {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                   }
          //                                   setState(() {
          //                                     userPostModal
          //                                         .isCommentIconVisible;
          //                                   });
          //                                 },
          //                                 decoration:
          //                                 InputDecoration(
          //                                   border:
          //                                   InputBorder
          //                                       .none,
          //                                   counterStyle: TextStyle(
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   filled: true,
          //                                   counterText: "",
          //                                   hintText: roleId ==
          //                                       "4"
          //                                       ? "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference
          //                                               .COMPANY_NAME_PATH)
          //                                       : "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference.NAME)
          //                                           .replaceAll(
          //                                           "null",
          //                                           ""),
          //                                   hintStyle: TextStyle(
          //                                       color: ColorValues
          //                                           .GREY_TEXT_COLOR,
          //                                       fontSize:
          //                                       14.0,
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   fillColor: Colors
          //                                       .transparent,
          //                                 ),
          //                               ),
          //                               flex: 4,
          //                             ),
          //                             Expanded(
          //                               child:
          //                               /*userPostModal
          //                                           .isCommentIconVisible
          //                                       ?*/
          //                               InkWell(
          //                                 child: PaddingWrap
          //                                     .paddingfromLTRB(
          //                                     0.0,
          //                                     0.0,
          //                                     5.0,
          //                                     0.0,
          //                                     Image
          //                                         .asset(
          //                                       "assets/feed/sent_icon.png",
          //                                       width:
          //                                       22.0,
          //                                       height:
          //                                       22.0,
          //                                     )),
          //                                 onTap: () {
          //                                   if (userPostModal
          //                                       .isCommentIconVisible) {
          //                                     FocusScope.of(
          //                                         context)
          //                                         .requestFocus(
          //                                         FocusNode());
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                     onAddComment(
          //                                         userPostModal
          //                                             .feedId,
          //                                         userPostModal
          //                                             .txtController
          //                                             .text,
          //                                         userPostModal);
          //                                     userPostModal
          //                                         .txtController
          //                                         .text = "";
          //                                     setState(() {
          //                                       userPostModal
          //                                           .txtController;
          //                                       userPostModal
          //                                           .isCommentIconVisible;
          //                                     });
          //                                   }
          //                                 },
          //                               )
          //                               /*:  Container(
          //                                           height: 0.0,
          //                                         )*/
          //                               ,
          //                               flex: 0,
          //                             )
          //                           ],
          //                         )),
          //                     flex: 1)
          //               ],
          //             ))
          //             : const SizedBox.shrink(),
          //
          //         (userPostList.length - 1) == index
          //             ? Container(
          //           height: 10.0,
          //         )
          //             : const SizedBox.shrink(),
          //         Container(
          //           height: 20.0,
          //         )
          //       ],
          //     ))
          //     : const SizedBox.shrink()
          //     : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget _imageAndNamegetListViewPost(UserPostModal userPostModal, int index) {
    return PaddingWrap.paddingfromLTRB(
      14.0,
      10.0,
      0.0,
      10.0,
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          ProfileImageView(
            imagePath: Constant.IMAGE_PATH_SMALL +
                ParseJson.getSmallImage(userPostModal.profilePicture),
            placeHolderImage: userPostModal.roleId == "4"
                ? "assets/profile/partner_img.png"
                : 'assets/profile/user_on_user.png',
            width: 46.0,
            height: 46.0,
            onTap: () async {
              onTapImageTile(userPostModal.postedBy, userPostModal.roleId);
            },
          ),
          Expanded(
            child: PaddingWrap.paddingfromLTRB(
                13.0,
                0.0,
                0.0,
                0.0,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    InkWell(
                      child: Container(
                        child: RichText(
                          maxLines: 2,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            text: (userPostModal.lastName == null ||
                                        userPostModal.lastName == "null"
                                    ? userPostModal.firstName
                                    : userPostModal.firstName +
                                        " " +
                                        userPostModal.lastName)
                                .trim(),
                            style: TextStyle(
                                color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontSize: 16.0,
                                fontWeight: FontWeight.w500,
                                fontFamily: Constant.latoRegular),
                            children: [
                              WidgetSpan(
                                child: userPostModal.roleId == "1"
                                    ? Util.getStudentBadgeRichTextWithPadding(
                                        userPostModal.badge,
                                        userPostModal.badgeImage)
                                    : SizedBox.shrink(),
                              ),
                              TextSpan(
                                  text: ' shared ',
                                  style: TextStyle(
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: Constant.latoRegular)),
                              TextSpan(
                                text: (userPostModal.postedGroupName != null &&
                                            userPostModal.postedGroupName !=
                                                "null" &&
                                            userPostModal.postedGroupName != ""
                                        ? userPostModal.postedGroupName
                                        : userPostModal.postOwnerLastName == ""
                                            ? userPostModal.postOwnerFirstName
                                                    .trim() +
                                                "'s"
                                            : userPostModal.postOwnerFirstName +
                                                " " +
                                                userPostModal.postOwnerLastName
                                                    .toString()
                                                    .trim() +
                                                "'s")
                                    .trim(),
                                recognizer: TapGestureRecognizer()
                                  ..onTap = () {
                                    if (userPostModal.postedGroupName == null ||
                                        userPostModal.postedGroupName !=
                                            "null" ||
                                        userPostModal.postedGroupName != "") {
                                      Navigator.of(context).push(
                                          new MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  GroupDetailWidget(
                                                      userPostModal
                                                          .postedGroupId,
                                                      "",
                                                      "",
                                                      "",
                                                      "")));
                                    }
                                  },
                                style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    //fontWeight: FontWeight.bold,
                                    fontFamily: Constant.latoRegular),
                              ),
                              TextSpan(
                                text: " post",
                                style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontSize: 16.0,
                                    //fontWeight: FontWeight.bold,
                                    fontFamily: Constant.latoRegular),
                              ),
                            ],
                          ),
                        ),
                      ),
                      onTap: () {
                        onTapImageTile(
                            userPostModal.postedBy, userPostModal.roleId);
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                      child: Row(
                        children: [
                          TextViewWrap.textView(
                              userPostModal.dateTime,
                              TextAlign.center,
                              ColorValues.labelColor,
                              12.0,
                              FontWeight.normal),
                          userIdPref == userPostModal.postedBy &&
                                  roleId == userPostModal.roleId.toString()
                              ? PaddingWrap.paddingfromLTRB(
                                  4.0,
                                  0.0,
                                  5.0,
                                  0.0,
                                  Image.asset(
                                    userPostModal.visibility == "Private"
                                        ? "assets/profile/post/private_new.png"
                                        : userPostModal.visibility ==
                                                "SelectedConnections"
                                            ? "assets/profile/post/selected_connections.png"
                                            : userPostModal.visibility ==
                                                    "AllConnections"
                                                ? "assets/profile/post/connection.png"
                                                : userPostModal.visibility ==
                                                        "Group"
                                                    ? "assets/profile/post/group_data.png"
                                                    : "assets/profile/post/community.png",
                                    width: 13.0,
                                    color: userPostModal.visibility ==
                                            "SelectedConnections"
                                        ? null
                                        : ColorValues.labelColor,
                                    height: 13.0,
                                  ))
                              : Container(height: 0.0),
                        ],
                      ),
                    )
                  ],
                )),
            flex: 4,
          ),
          InkWell(
              onTap: () {
                if (userIdPref == userPostModal.postedBy &&
                    roleId == userPostModal.roleId.toString()) {
                  // optionMenuDelete(userPostModal, index);
                  onlyDeletePopUp(userPostModal, index);
                } else {
                  // optionForReport(userPostModal, index);
                  issuePopUp(userPostModal, index);
                }
              },
              child: Padding(
                padding: const EdgeInsets.fromLTRB(15, 4, 14, 0),
                child: Image.asset(
                  "assets/feed/three_dot_blue.png",
                  height: 15.0,
                  width: 15.0,
                ),
              )),
        ],
      ),
    );
  }

  Widget _imageAndNamegetListViewPost2(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
      20.0,
      10.0,
      0.0,
      10.0,
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          ProfileImageView(
            imagePath: Constant.IMAGE_PATH_SMALL +
                ParseJson.getSmallImage(userPostModal.profilePicture),
            placeHolderImage: userPostModal.postOwnerRoleId == "4"
                ? "assets/profile/partner_img.png"
                : 'assets/profile/user_on_user.png',
            width: 46.0,
            height: 46.0,
            onTap: () async {
              onTapImageTile(
                  userPostModal.postOwner, userPostModal.postOwnerRoleId);
            },
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        child: Container(
                            child: RichText(
                          maxLines: 2,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            text: userPostModal.lastName == "null"
                                ? userPostModal.firstName
                                : userPostModal.firstName +
                                    " " +
                                    userPostModal.lastName,
                            style: TextStyle(
                              color:
                                  userPostModal.postdata.imageList.length == 0
                                      ? userPostModal.postdata.metaUrl != ""
                                          ? AppConstants.colorStyle.white
                                          : AppConstants.colorStyle.darkBlue
                                      : AppConstants.colorStyle.white,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w500,
                              fontFamily: Constant.latoRegular,
                            ),
                            children: userPostModal.tagList.length == 0 &&
                                    userPostModal.groupList.length == 0
                                ? [
                                    WidgetSpan(
                                      child: userPostModal.roleId == "1"
                                          ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                                  userPostModal.badge,
                                                  userPostModal.badgeImage)
                                          : Container(
                                              height: 0.0,
                                              width: 0.0,
                                            ),
                                    ),
                                  ]
                                : userPostModal.tagList.length != 0
                                    ?  [
                                            WidgetSpan(
                                              child: userPostModal.roleId == "1"
                                                  ? Util
                                                      .getStudentBadgeRichTextWithPadding(
                                                          userPostModal.badge,
                                                          userPostModal
                                                              .badgeImage)
                                                  : Container(
                                                      height: 0.0,
                                                      width: 0.0,
                                                    ),
                                            ),
                                            TextSpan(
                                                text: ' with ',
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                    fontSize: 16.0,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                            TextSpan(
                                              text: userPostModal.tagList[0]
                                                              .name ==
                                                          null ||
                                                      userPostModal.tagList[0]
                                                              .name ==
                                                          "null"
                                                  ? ""
                                                  : userPostModal
                                                      .tagList[0].name,
                                              style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontSize: 16.0,
                                                  fontFamily: Constant.latoSemibold
                                              ),
                                            ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                                    text: ' and ',
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontSize: 16.0,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  )
                                                : TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontSize: 14.0,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                                    text: (userPostModal.tagList
                                                                .length -
                                                            1)
                                                        .toString(),
                                                    style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION_1,
                                                      fontSize: 16.0,
                                                        fontFamily: Constant.latoSemibold
                                                    ),
                                                  )
                                                : TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontSize: 14.0,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                                    text: " others ",
                                                    style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION_1,
                                                      fontSize: 16.0,
                                                        fontFamily: Constant.latoRegular
                                                    ),
                                                  )
                                                : TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION_1,
                                                        fontSize: 14.0,
                                                        fontWeight:
                                                            FontWeight.normal,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                          ]:[],
                          ),
                        )),
                        onTap: () {
                          if (userPostModal.tagList.length > 0) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    TagDetailWidget(userPostModal.tagList)));
                          } else {
                            print("clicked");
                            onTapImageTile(userPostModal.postOwner,
                                userPostModal.postOwnerRoleId);
                          }
                        },
                      ),
                      flex: 0,
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                  child: Row(
                    children: [
                      // color:userPostModal.postdata.imageList.length == 0?userPostModal.postdata.metaUrl !=
                      //                       ""?
                      TextViewWrap.textView(
                          userPostModal.dateTime,
                          TextAlign.center,
                          userPostModal.postdata.imageList.length == 0
                              ? userPostModal.postdata.metaUrl != ""
                                  ? ColorValues.WHITE
                                  : ColorValues.HEADING_COLOR_EDUCATION_1
                              : ColorValues.WHITE,
                          12.0,
                          FontWeight.w500),
                      userIdPref == userPostModal.postedBy &&
                              roleId == userPostModal.roleId.toString()
                          ? PaddingWrap.paddingfromLTRB(
                              4.0,
                              0.0,
                              5.0,
                              0.0,
                              Image.asset(
                                userPostModal.visibility == "Private"
                                    ? "assets/profile/post/private_new.png"
                                    : userPostModal.visibility ==
                                            "SelectedConnections"
                                        ? "assets/profile/post/selected_connections.png"
                                        : userPostModal.visibility ==
                                                "AllConnections"
                                            ? "assets/profile/post/connection.png"
                                            : userPostModal.visibility ==
                                                    "Group"
                                                ? "assets/profile/post/group_data.png"
                                                : "assets/profile/post/community.png",
                                width: 13.0,
                                color: userPostModal.visibility ==
                                        "SelectedConnections"
                                    ? null
                                    : ColorValues.GREY_TEXT_COLOR,
                                height: 13.0,
                              ))
                          : Container(height: 0.0),
                    ],
                  ),
                ),

                // TextViewWrap.textView(
                //     userPostModal
                //         .shareTime,
                //     TextAlign.center,
                //     ColorValues
                //         .GREY_TEXT_COLOR,
                //     12.0,
                //     FontWeight
                //         .normal),
              ],
            ),
          ),
          InkWell(
            onTap: () {
              if (userIdPref == userPostModal.postedBy &&
                  roleId == userPostModal.roleId.toString()) {
                // optionMenuDelete(userPostModal, index);
                onlyDeletePopUp(userPostModal, index);
              } else {
                // optionForReport(userPostModal, index);
                issuePopUp(userPostModal, index);
              }
            },
            child: Padding(
              padding: const EdgeInsets.fromLTRB(15, 4, 20, 0),
              child: userPostModal.postdata.imageList.length == 0
                  ? userPostModal.postdata.metaUrl != ""
                      ? Image.asset(
                          "assets/feed/three_dot_white.png",
                          height: 15.0,
                          width: 15.0,
                        )
                      : Image.asset(
                          "assets/feed/three_dot_blue.png",
                          height: 15.0,
                          width: 15.0,
                        )
                  : Image.asset(
                      "assets/feed/three_dot_white.png",
                      height: 15.0,
                      width: 15.0,
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _imageAndNamegetListViewForSharedPostBlue(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
      20.0,
      12.0,
      0.0,
      12.0,
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          ProfileImageView(
            imagePath: Constant.IMAGE_PATH_SMALL +
                ParseJson.getSmallImage(userPostModal.postOwnerProfilePicture),
            placeHolderImage: userPostModal.postOwnerRoleId == "4"
                ? "assets/profile/partner_img.png"
                : 'assets/profile/user_on_user.png',
            width: 46.0,
            height: 46.0,
            onTap: () async {
              onTapImageTile(
                  userPostModal.postOwner, userPostModal.postOwnerRoleId);
            },
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                InkWell(
                  child: RichText(
                    maxLines: 2,
                    textAlign: TextAlign.start,
                    text: TextSpan(
                      text: userPostModal.postOwnerLastName == "null"
                          ? userPostModal.postOwnerFirstName
                          : userPostModal.postOwnerFirstName +
                              " " +
                              userPostModal.postOwnerLastName,
                      style: TextStyle(
                        color: ColorValues.HEADING_COLOR_EDUCATION_1,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: Constant.latoRegular,
                      ),
                      children: userPostModal.tagList.length == 0
                          ? [
                              WidgetSpan(
                                child: userPostModal.postOwnerRoleId == "1"
                                    ? Util.getStudentBadgeRichTextWithPadding(
                                        userPostModal.postOwnerBadge,
                                        userPostModal.postOwnerBadgeImage)
                                    : Container(
                                        height: 0.0,
                                        width: 0.0,
                                      ),
                              )
                            ]
                          : [
                              WidgetSpan(
                                child: userPostModal.postOwnerRoleId == "1"
                                    ? Util.getStudentBadgeRichTextWithPadding(
                                        userPostModal.postOwnerBadge,
                                        userPostModal.postOwnerBadgeImage)
                                    : Container(
                                        height: 0.0,
                                        width: 0.0,
                                      ),
                              ),
                              TextSpan(
                                  text: ' with ',
                                  style: TextStyle(
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.normal,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR)),
                              TextSpan(
                                text: userPostModal.tagList[0].name == null ||
                                        userPostModal.tagList[0].name == "null"
                                    ? ""
                                    : userPostModal.tagList[0].name,
                                style: TextStyle(
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontSize: 16.0,
                                    fontFamily: Constant.latoSemibold
                                ),
                              ),
                              userPostModal.tagList.length > 1
                                  ? TextSpan(
                                      text: ' and ',
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    )
                                  : TextSpan(
                                      text: "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                              userPostModal.tagList.length > 1
                                  ? TextSpan(
                                      text: (userPostModal.tagList.length - 1)
                                          .toString(),
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16.0,
                                          fontFamily: Constant.latoSemibold
                                      ),
                                    )
                                  : TextSpan(
                                      text: "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                              userPostModal.tagList.length > 1
                                  ? TextSpan(
                                      text: " others ",
                                      style: TextStyle(
                                        color: ColorValues
                                            .HEADING_COLOR_EDUCATION_1,
                                        fontSize: 16.0,
                                          fontFamily: Constant.latoRegular
                                      ),
                                    )
                                  : TextSpan(
                                      text: "",
                                      style: TextStyle(
                                          color: ColorValues
                                              .HEADING_COLOR_EDUCATION_1,
                                          fontSize: 16.0,
                                          fontWeight: FontWeight.normal,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR),
                                    ),
                            ],
                    ),
                  ),
                  onTap: () {
                    if (userPostModal.tagList.length > 0) {
                      Navigator.of(context).push(new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              TagDetailWidget(userPostModal.tagList)));
                    } else {
                      print("clicked");
                      onTapImageTile(userPostModal.postOwner,
                          userPostModal.postOwnerRoleId);
                    }
                  },
                ),
                const SizedBox(height: 3),
                TextViewWrap.textView(userPostModal.shareTime, TextAlign.center,
                    ColorValues.labelColor, 12.0, FontWeight.w500),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _imageAndNamegetListViewForSharedPost(userPostModal, index) {
    return Container(
      decoration: new BoxDecoration(
        /*image: new DecorationImage(
              image: new AssetImage("assets/feed/background_imageview.png"),
              fit: BoxFit.cover,
            ),*/
        gradient: LinearGradient(
          colors: [
            Color(0xff000000),
            Color(0x00000000),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: PaddingWrap.paddingfromLTRB(
        20.0,
        12.0,
        20.0,
        12.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(
                      userPostModal.postOwnerProfilePicture),
              placeHolderImage: userPostModal.postOwnerRoleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 46.0,
              height: 46.0,
              onTap: () async {
                onTapImageTile(
                    userPostModal.postOwner, userPostModal.postOwnerRoleId);
              },
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  InkWell(
                    child: RichText(
                      maxLines: 2,
                      textAlign: TextAlign.start,
                      text: TextSpan(
                        text: userPostModal.postOwnerLastName == "null"
                            ? userPostModal.postOwnerFirstName
                            : userPostModal.postOwnerFirstName +
                                " " +
                                userPostModal.postOwnerLastName,
                        style: TextStyle(
                          color: ColorValues.WHITE,
                          fontSize: 16.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: Constant.latoRegular,
                        ),
                        children: userPostModal.tagList.length == 0
                            ? [
                                WidgetSpan(
                                  child: userPostModal.postOwnerRoleId == "1"
                                      ? Util.getStudentBadgeRichTextWithPadding(
                                          userPostModal.postOwnerBadge,
                                          userPostModal.postOwnerBadgeImage)
                                      : Container(
                                          height: 0.0,
                                          width: 0.0,
                                        ),
                                )
                              ]
                            : [
                                WidgetSpan(
                                  child: userPostModal.postOwnerRoleId == "1"
                                      ? Util.getStudentBadgeRichTextWithPadding(
                                          userPostModal.postOwnerBadge,
                                          userPostModal.postOwnerBadgeImage)
                                      : Container(
                                          height: 0.0,
                                          width: 0.0,
                                        ),
                                ),
                                TextSpan(
                                    text: ' with ',
                                    style: TextStyle(
                                        color: ColorValues.WHITE,
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily:
                                            Constant.TYPE_CUSTOMREGULAR)),
                                TextSpan(
                                  text: userPostModal.tagList[0].name == null ||
                                          userPostModal.tagList[0].name ==
                                              "null"
                                      ? ""
                                      : userPostModal.tagList[0].name,
                                  style: TextStyle(
                                    color: ColorValues.WHITE,
                                    fontSize: 16.0,
                                      fontFamily: Constant.latoSemibold
                                  ),
                                ),
                                userPostModal.tagList.length > 1
                                    ? TextSpan(
                                        text: ' and ',
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      )
                                    : TextSpan(
                                        text: "",
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      ),
                                userPostModal.tagList.length > 1
                                    ? TextSpan(
                                        text: (userPostModal.tagList.length - 1)
                                            .toString(),
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 16.0,
                                            fontFamily: Constant.latoSemibold
                                        ),
                                      )
                                    : TextSpan(
                                        text: "",
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      ),
                                userPostModal.tagList.length > 1
                                    ? TextSpan(
                                        text: " others ",
                                        style: TextStyle(
                                          color: ColorValues.WHITE,
                                          fontSize: 16.0,
                                            fontFamily: Constant.latoRegular
                                        ),
                                      )
                                    : TextSpan(
                                        text: "",
                                        style: TextStyle(
                                            color: ColorValues.WHITE,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR),
                                      ),
                              ],
                      ),
                    ),
                    onTap: () {
                      if (userPostModal.tagList.length > 0) {
                        Navigator.of(context).push(new MaterialPageRoute(
                            builder: (BuildContext context) =>
                                TagDetailWidget(userPostModal.tagList)));
                      } else {
                        print("clicked");
                        onTapImageTile(userPostModal.postOwner,
                            userPostModal.postOwnerRoleId);
                      }
                    },
                  ),
                  const SizedBox(height: 3),
                  TextViewWrap.textView(
                      userPostModal.shareTime,
                      TextAlign.center,
                      ColorValues.WHITE,
                      12.0,
                      FontWeight.w500),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget getListViewPost(userPostModal, index, bool isUserRepoted) {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 21),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          // getEvent(userPostModal),

          userPostModal.shareText != null &&
                  userPostModal.postOwnerFirstName != "null" &&
                  userPostModal.postOwnerFirstName != null
              // userPostModal.shareText != "" &&
              // userPostModal.shareText != "null"
              ? _imageAndNamegetListViewPost(userPostModal, index)
              : const SizedBox.shrink(),
          userPostModal.shareText == "null" || userPostModal.shareText == ""
              ? const SizedBox.shrink()
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    PaddingWrap.paddingfromLTRB(
                      10.0,
                      8.0,
                      10.0,
                      0.0,
                      userPostModal.shareText == "" ||
                              userPostModal.shareText == "null" ||
                              userPostModal.shareText == "\n"
                          ? const SizedBox.shrink()
                          : PaddingWrap.paddingfromLTRB(
                              10.0,
                              0.0,
                              0.0,
                              0.0,
                              userPostModal.isShareMore
                                  ? Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          apiCallingForIncreaseCount(
                                              userPostModal.feedId);
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .push(new MaterialPageRoute(
                                                  fullscreenDialog: true,
                                                  builder:
                                                      (BuildContext context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                        },
                                        text: userPostModal.shareText,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14.0),
                                        linkStyle: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14.0),
                                      ),
                                    )
                                  : Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          apiCallingForIncreaseCount(
                                              userPostModal.feedId);
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .push(new MaterialPageRoute(
                                                  fullscreenDialog: true,
                                                  builder:
                                                      (BuildContext context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                        },
                                        text: userPostModal.shareText,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14.0),
                                        linkStyle: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14.0),
                                      ),
                                    )),
                    ),
                  ],
                ),
          userPostModal.postOwnerDeleted
              ? PaddingWrap.paddingfromLTRB(
                  11.0,
                  10.0,
                  11.0,
                  0.0,
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: ColorValues.OPPORTUNITY_GROUP_SELECTION_GRP,
                        border: Border.all(
                            width: 0.5,
                            color: ColorValues.GREY__COLOR_DIVIDER)),
                    child: PaddingWrap.paddingfromLTRB(
                      11.0,
                      17.0,
                      11.0,
                      16.0,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          TextViewWrap.textView(
                              "You can’t see this post",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION_1,
                              14.0,
                              FontWeight.bold),
                          TextViewWrap.textView(
                              MessageConstant.AUTHOR_DELETED_POST,
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION_1,
                              14.0,
                              FontWeight.normal)
                        ],
                      ),
                    ),
                  ),
                )
              : PaddingWrap.paddingfromLTRB(
                  0.0,
                  10.0,
                  0.0,
                  5.0,
                  Container(
                    decoration: BoxDecoration(),
                    child: Stack(
                      children: <Widget>[
                        userPostModal.postdata.assetsList.length == 0
                            ? const SizedBox.shrink()
                            : PaddingWrap.paddingfromLTRB(
                                10.0,
                                0.0,
                                10.0,
                                0.0,
                                Container(
                                  height: 280.0,
                                  child: SizedBox(
                                    // Pager view
                                    height: 280.0,
                                    child: PageIndicatorContainer(
                                      pageView: PageView.builder(
                                        itemCount: userPostModal
                                            .postdata.assetsList.length,
                                        controller: PageController(),
                                        itemBuilder: (context, index2) {
                                          return userPostModal
                                                      .postdata
                                                      .assetsList[index2]
                                                      .type ==
                                                  "image"
                                              ? InkWell(
                                                  child:
                                                      Stack(children: <Widget>[
                                                    Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.black,
                                                        ),
                                                        height: 280.0,
                                                        child:
                                                            CachedNetworkImage(
                                                          width:
                                                              double.infinity,
                                                          height: 280.0,
                                                          imageUrl: Constant
                                                                  .IMAGE_PATH_SMALL +
                                                              ParseJson.getMediumImage(
                                                                  userPostModal
                                                                      .postdata
                                                                      .assetsList[
                                                                          index2]
                                                                      .file),
                                                          fit: BoxFit.cover,
                                                          placeholder: (context,
                                                                  url) =>
                                                              _loader(context),
                                                          errorWidget: (context,
                                                                  url, error) =>
                                                              _error(),
                                                        )),
                                                    userPostModal
                                                                .postdata
                                                                .assetsList
                                                                .length ==
                                                            1
                                                        ? InkWell(
                                                            onTap: () {
                                                              Navigator.of(context).push(new MaterialPageRoute(
                                                                  builder: (BuildContext context) => CommonFullViewWidget(
                                                                      userPostModal
                                                                          .postdata
                                                                          .assetsList,
                                                                      MessageConstant
                                                                          .HOME_FEED,
                                                                      index2,
                                                                      MessageConstant
                                                                          .COMPANY_PROFILE_HEDING)));
                                                            },
                                                            child: Container(
                                                              height: 0.0,
                                                            ))
                                                        : InkWell(
                                                            onTap: () {
                                                              Navigator.of(context).push(new MaterialPageRoute(
                                                                  builder: (BuildContext context) => CommonFullViewWidget(
                                                                      userPostModal
                                                                          .postdata
                                                                          .assetsList,
                                                                      MessageConstant
                                                                          .HOME_FEED,
                                                                      index2,
                                                                      MessageConstant
                                                                          .COMPANY_PROFILE_HEDING)));
                                                            },
                                                            child: Container(
                                                              height: 280.0,
                                                              width: double
                                                                  .infinity,
                                                              child:
                                                                  Image.asset(
                                                                "assets/newDesignIcon/navigation/layer_image.png",
                                                                fit:
                                                                    BoxFit.fill,
                                                              ),
                                                            ))
                                                  ]),
                                                  onTap: () {
                                                    Navigator.of(context).push(new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            CommonFullViewWidget(
                                                                userPostModal
                                                                    .postdata
                                                                    .assetsList,
                                                                MessageConstant
                                                                    .HOME_FEED,
                                                                index2,
                                                                MessageConstant
                                                                    .COMPANY_PROFILE_HEDING)));
                                                  },
                                                )
                                              : InkWell(
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      color: Colors.black,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              0),
                                                    ),
                                                    height: 250.0,
                                                    width: double.infinity,
                                                    child: Center(
                                                      child: Center(
                                                        child: VideoPlayPause(
                                                            userPostModal
                                                                .postdata
                                                                .assetsList[
                                                                    index2]
                                                                .file,
                                                            userPostModal
                                                                .feedId,
                                                            true,
                                                            allVideoController),
                                                      ),
                                                    ),
                                                  ),
                                                  onTap: () {},
                                                );
                                        },
                                        onPageChanged: (index) {},
                                      ),
                                      align: IndicatorAlign.bottom,
                                      length: userPostModal
                                          .postdata.assetsList.length,
                                      indicatorSpace: 10.0,
                                      indicatorColor: userPostModal
                                                  .postdata.assetsList.length ==
                                              1
                                          ? Colors.transparent
                                          : Color(0xffc4c4c4),
                                      indicatorSelectorColor: userPostModal
                                                  .postdata.assetsList.length ==
                                              1
                                          ? Colors.transparent
                                          : Color(0XFFFFFFFF),
                                      shape: IndicatorShape.circle(size: 5.0),
                                    ),
                                  ),
                                ),
                              ),
                        userPostModal.postdata.assetsList.length == 0
                            ? userPostModal.postdata == null ||
                                    userPostModal.postdata.text == null ||
                                    userPostModal.postdata.text == "null"
                                ? const SizedBox.shrink()
                                : userPostModal.postdata.metaUrl != ""
                                    ? Container(
                                        margin:
                                            EdgeInsets.symmetric(vertical: 4.0),
                                        child: userPostModal.shareText != null &&
                                                userPostModal.postOwnerFirstName !=
                                                    "null" &&
                                                userPostModal
                                                        .postOwnerFirstName !=
                                                    null
                                            ? NewWhatsAppViewFeed(
                                                imageUrl: userPostModal
                                                    .postdata.metaImage,
                                                feedId: userPostModal.feedId,
                                                title: userPostModal
                                                    .postdata.metaTitle,
                                                url: userPostModal
                                                    .postdata.metaUrl,
                                                metaHeight: userPostModal
                                                    .postdata.metaHeight,
                                                metaWidth: userPostModal
                                                    .postdata.metaWidth,
                                                metaSource: userPostModal
                                                    .postdata.metaSource,
                                                description: userPostModal
                                                    .postdata.metaDescription,
                                                isEmptyFeed: false)
                                            : NewWhatsAppViewFeed(
                                                imageUrl: userPostModal
                                                    .postdata.metaImage,
                                                feedId: userPostModal.feedId,
                                                title: "",
                                                url: userPostModal.postdata.metaUrl,
                                                metaHeight: userPostModal.postdata.metaHeight,
                                                metaWidth: userPostModal.postdata.metaWidth,
                                                metaSource: "",
                                                description: "",
                                                isEmptyFeed: true))
                                    : const SizedBox.shrink()
                            : const SizedBox.shrink(),
                        userPostModal.postOwnerFirstName == "null" ||
                                userPostModal.postOwnerFirstName == null
                            ? _imageAndNamegetListViewPost2(
                                userPostModal, index)
                            : userPostModal.postdata.assetsList.length == 0 &&
                                    (userPostModal.postdata.metaUrl == "" &&
                                        userPostModal.postdata.metaImage == "")
                                ? _imageAndNamegetListViewForSharedPostBlue(
                                    userPostModal, index)
                                : _imageAndNamegetListViewForSharedPost(
                                    userPostModal, index),
                      ],
                    ),
                  ),
                ),
          userPostModal.postOwnerFirstName == "null" ||
                  userPostModal.postOwnerFirstName == null
              ? const SizedBox.shrink()
              : userPostModal.postOwnerDeleted
                  ? const SizedBox.shrink()
                  : PaddingWrap.paddingfromLTRB(
                      20.0,
                      8.0,
                      20.0,
                      0.0,
                      Container(
                        child: Linkify(
                          onOpen: (link) async {
                            apiCallingForIncreaseCount(userPostModal.feedId);
                            Navigator.of(context, rootNavigator: true).push(
                                new MaterialPageRoute(
                                    fullscreenDialog: true,
                                    builder: (BuildContext context) =>
                                        WebViewWidget(link.url, "spikeview")));
                          },
                          text: exp
                                      .allMatches(userPostModal.postdata.text)
                                      .length >
                                  1
                              ? userPostModal.postdata.text
                              : userPostModal.postdata.text
                                  .toString()
                                  .replaceAll(exp, ''),
                          style: TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular,
                              fontSize: 14.0,
                              fontWeight: FontWeight.w400),
                          linkStyle: TextStyle(
                              color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              fontSize: 14.0),
                        ),
                      ),
                    ),

          isUserRepoted
              ? ACCESS_CONTROL_GROUP
                  ? Padding(
                      padding:
                          const EdgeInsets.only(left: 20, top: 8, right: 20),
                      child: Row(
                        children: <Widget>[
                          InkWell(
                            onTap: () {
                              onTapLike(userPostModal);
                            },
                            child: userPostModal.isLike
                                ? Image.asset(
                                    "assets/feed/heart_red.png",
                                    height: 21.0,
                                    width: 21.0,
                                  )
                                : Image.asset(
                                    "assets/feed/heart_blue.png",
                                    height: 21.0,
                                    width: 21.0,
                                  ),
                          ),
                          SizedBox(
                            width: 7,
                          ),
                          InkWell(
                            onTap: () {
                              onTapViewAllComments(userPostModal.commentList,
                                  userPostModal.feedId, userPostModal);
                              /*     if (userPostModal
                                        .isShowCommentIcon)
                                      userPostModal
                                          .isShowCommentIcon = false;
                                    else {
                                      _scrollController.jumpTo(
                                          (_scrollController.offset +
                                              80.0));
                                      userPostModal
                                          .isShowCommentIcon = true;
                                    }

                                    setState(() {
                                      userPostModal.isShowCommentIcon;
                                    });*/
                            },
                            child: Image.asset(
                              "assets/feed/comment.png",
                              height: 28.0,
                              width: 28.0,
                            ),
                          ),
                          SizedBox(
                            width: 7,
                          ),
                          _shareButton(onTap: () {
                            onTapShare(userPostModal);
                          }),
                          Spacer(),
                        ],
                      ),
                    )
                  : const SizedBox.shrink()
              : const SizedBox.shrink(),
          isUserRepoted
              ? ACCESS_CONTROL_GROUP
                  ? userPostModal.likesCount > 0 ||
                          userPostModal.commentList.length > 0
                      ? Padding(
                          padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: userPostModal.likesCount > 0
                                    ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        7.0,
                                        0.0,
                                        InkWell(
                                          child: TextViewWrap.textView(
                                              userPostModal.likesCount == 0
                                                  ? "Like"
                                                  : userPostModal.likesCount ==
                                                          1
                                                      ? "1 Like"
                                                      : userPostModal.likesCount
                                                              .toString() +
                                                          " Likes",
                                              TextAlign.end,
                                              ColorValues.labelColor,
                                              12.0,
                                              FontWeight.w500),
                                          onTap: () {
                                            onTapLikeText(userPostModal);
                                          },
                                        ))
                                    : const SizedBox.shrink(),
                                flex: 0,
                              ),
                              userPostModal.commentList.length == 0
                                  ? const SizedBox.shrink()
                                  : InkWell(
                                      child: TextViewWrap.textView(
                                          userPostModal.commentList.length == 0
                                              ? "Comment"
                                              : "" +
                                                  userPostModal
                                                      .commentList.length
                                                      .toString() +
                                                  " Comments",
                                          TextAlign.left,
                                          ColorValues.labelColor,
                                          12.0,
                                          FontWeight.w500),
                                      onTap: () {
                                        onTapViewAllComments(
                                            userPostModal.commentList,
                                            userPostModal.feedId,
                                            userPostModal);
                                      },
                                    )
                            ],
                          ),
                        )
                      : const SizedBox.shrink()
                  : const SizedBox.shrink()
              : const SizedBox.shrink(),
          userPostModal.postdata == null ||
                  userPostModal.postdata.text == null ||
                  userPostModal.postdata.text == "null"
              ? const SizedBox.shrink()
              : userPostModal.postdata.metaUrl != ""
                  ? userPostModal.shareText != null &&
                          userPostModal.postOwnerFirstName != "null" &&
                          userPostModal.postOwnerFirstName != null
                      ? const SizedBox.shrink()
                      : Container(
                          padding: EdgeInsets.fromLTRB(13.0, 12.0, 13.0, 0),
                          color: Color(0XFFFFFFFF),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              InkWell(
                                child: Text(
                                  userPostModal.postdata.metaTitle == null
                                      ? ""
                                      : userPostModal.postdata.metaTitle.trim(),
                                  textAlign: TextAlign.start,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontFamily: Constant.TYPE_CUSTOMBOLD,
                                      fontSize: 14.0),
                                ),
                                onTap: () {
                                  onTapView(userPostModal);
                                },
                              ),
                              InkWell(
                                child: Text(
                                  userPostModal.postdata.metaSource == null
                                      ? ""
                                      : userPostModal.postdata.metaSource
                                          .trim(),
                                  textAlign: TextAlign.start,
                                  maxLines: 1,
                                  style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      color:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontFamily: Constant.latoRegular,
                                      fontSize: 14.0),
                                ),
                                onTap: () {
                                  //onTapView();
                                  Navigator.of(context).push(
                                      new MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              WebViewWidget(
                                                  userPostModal
                                                      .postdata.metaUrl,
                                                  "spikeview")));
                                },
                              ),
                              Text(
                                userPostModal.postdata.metaDescription == null
                                    ? ""
                                    : userPostModal.postdata.metaDescription
                                        .trim(),
                                textAlign: TextAlign.start,
                                maxLines:
                                    userPostModal.postdata.isShowMore ? 30 : 3,
                                style: TextStyle(
                                    color:
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                    fontWeight: FontWeight.w400,
                                    fontFamily: Constant.latoRegular,
                                    fontSize: 14.0),
                              ),
                              userPostModal.postdata.metaDescription
                                          .trim()
                                          .length >
                                      190
                                  ? InkWell(
                                      child: Text(
                                        userPostModal.postdata.isShowMore
                                            ? "Less"
                                            : "More",
                                        textAlign: TextAlign.start,
                                        maxLines: 1,
                                        style: TextStyle(
                                            color: ColorValues
                                                .BLUE_COLOR_BOTTOMBAR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 12.0),
                                      ),
                                      onTap: () {
                                        setState(() {
                                          if (userPostModal
                                              .postdata.isShowMore) {
                                            userPostModal.postdata.isShowMore =
                                                false;
                                          } else
                                            userPostModal.postdata.isShowMore =
                                                true;
                                        });
                                      })
                                  : const SizedBox.shrink(),
                            ],
                          ),
                        )
                  : PaddingWrap.paddingfromLTRB(
                      20.0,
                      0.0,
                      20.0,
                      0.0,
                      userPostModal.postdata.text == "" ||
                              userPostModal.postdata.text == "null" ||
                              userPostModal.postdata.text == "\n"
                          ? const SizedBox.shrink()
                          : userPostModal.postdata.assetsList.length == 0 &&
                                  (userPostModal.postdata.metaUrl != "" &&
                                      userPostModal.postdata.metaImage != "")
                              ? exp
                                              .allMatches(
                                                  userPostModal.postdata.text)
                                              .length ==
                                          1 &&
                                      userPostModal.postdata.text
                                              .toString()
                                              .replaceAll(exp, '')
                                              .length ==
                                          0
                                  ? const SizedBox.shrink()
                                  : PaddingWrap.paddingfromLTRB(
                                      4.0,
                                      10.0,
                                      13.0,
                                      0.0,
                                      Container(
                                        child: Linkify(
                                          onOpen: (link) async {
                                            apiCallingForIncreaseCount(
                                                userPostModal.feedId);
                                            Navigator.of(context,
                                                    rootNavigator: true)
                                                .push(new MaterialPageRoute(
                                                    fullscreenDialog: true,
                                                    builder: (BuildContext
                                                            context) =>
                                                        WebViewWidget(link.url,
                                                            "spikeview")));
                                          },
                                          text: exp
                                                      .allMatches(userPostModal
                                                          .postdata.text)
                                                      .length >
                                                  1
                                              ? userPostModal.postdata.text
                                              : userPostModal.postdata.text
                                                  .toString()
                                                  .replaceAll(exp, ''),
                                          style: TextStyle(
                                              color: ColorValues
                                                  .HEADING_COLOR_EDUCATION_1,
                                              fontFamily: Constant.latoRegular,
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w400),
                                          linkStyle: TextStyle(
                                              color: ColorValues
                                                  .BLUE_COLOR_BOTTOMBAR,
                                              fontFamily:
                                                  Constant.TYPE_CUSTOMREGULAR,
                                              fontSize: 14.0),
                                        ),
                                      ))
                              : userPostModal.postOwnerFirstName == "null" ||
                                      userPostModal.postOwnerFirstName == null
                                  ? Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          apiCallingForIncreaseCount(
                                              userPostModal.feedId);
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .push(new MaterialPageRoute(
                                                  fullscreenDialog: true,
                                                  builder:
                                                      (BuildContext context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                        },
                                        text: userPostModal.postdata.text,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400),
                                        linkStyle: TextStyle(
                                            color: ColorValues
                                                .BLUE_COLOR_BOTTOMBAR,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                            fontSize: 14.0),
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                    ),

          ///Don't remove it
          // isUserRepoted
          //     ? ACCESS_CONTROL_FEED
          //     ? PaddingWrap.paddingAll(
          //     0.0,
          //     Column(
          //       crossAxisAlignment: CrossAxisAlignment.start,
          //       mainAxisAlignment: MainAxisAlignment.start,
          //       children: <Widget>[
          //         // Comment List view
          //         // Padding(
          //         //   padding: const EdgeInsets.all(10.0),
          //         //   child: Divider(
          //         //       height: 1.0,
          //         //       color: ColorValues.DARK_GREY),
          //         // ),
          //         Padding(
          //             padding: EdgeInsets.fromLTRB(
          //                 10.0, 12.0, 10.0, 0.0),
          //             child: Column(
          //                 crossAxisAlignment:
          //                 CrossAxisAlignment.start,
          //                 children: List.generate(
          //                     userPostModal.commentList
          //                         .length >
          //                         3
          //                         ? 3
          //                         : userPostModal.commentList
          //                         .length, (int index) {
          //                   return PaddingWrap
          //                       .paddingfromLTRB(
          //                       10.0,
          //                       5.0,
          //                       10.0,
          //                       12.0,
          //                       Row(
          //                         crossAxisAlignment:
          //                         CrossAxisAlignment
          //                             .start,
          //                         children: <Widget>[
          //
          //
          //                           ProfileImageView(
          //                             imagePath: Constant
          //                                 .IMAGE_PATH_SMALL +
          //                                 userPostModal
          //                                     .commentList[index]
          //                                     .profilePicture,
          //                             placeHolderImage: userPostModal
          //                                 .commentList[index]
          //                                 .roleId ==
          //                                 "4"
          //                                 ? "assets/profile/partner_img.png"
          //                                 : 'assets/profile/user_on_user.png',
          //                             width: 40.0,
          //                             height: 40.0,
          //                             onTap: () async {
          //                               onTapImageTile(
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .commentedBy,
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .roleId);
          //                             },
          //                           ), // User Image
          //                           SizedBox(
          //                             width: 9.0,
          //                           ),
          //                           Expanded(
          //                             child: Column(
          //                               crossAxisAlignment:
          //                               CrossAxisAlignment
          //                                   .start,
          //                               mainAxisAlignment:
          //                               MainAxisAlignment
          //                                   .start,
          //                               children: <
          //                                   Widget>[
          //                                 Padding(
          //                                   padding:
          //                                   const EdgeInsets
          //                                       .fromLTRB(
          //                                       0,
          //                                       0,
          //                                       0,
          //                                       0),
          //                                   child:
          //                                   Container(
          //                                       child:
          //                                       Row(
          //                                         children: <
          //                                             Widget>[
          //                                           RichText(
          //                                             maxLines:
          //                                             2,
          //                                             textAlign:
          //                                             TextAlign.start,
          //                                             text:
          //                                             TextSpan(
          //                                               text: userPostModal
          //                                                   .commentList[index]
          //                                                   .name,
          //                                               style:
          //                                               TextStyle(
          //                                                 color:
          //                                                 ColorValues
          //                                                     .HEADING_COLOR_EDUCATION_1,
          //                                                 fontSize:
          //                                                 14.0,
          //                                                 fontWeight:
          //                                                 FontWeight
          //                                                     .bold,
          //                                               ),
          //                                               /* children: <TextSpan>[
          //                                             TextSpan(
          //                                                 text: userPostModal
          //                                                     .commentList[
          //                                                         index]
          //                                                     .comment,
          //                                                 style:  TextStyle(
          //                                                     color: ColorValues.HEADING_COLOR_EDUCATION_1,
          //                                                     fontSize:
          //                                                         14.0,
          //                                                     fontWeight:
          //                                                         FontWeight
          //                                                             .normal,
          //                                                     fontFamily:
          //                                                         Constant.TYPE_CUSTOMREGULAR)),
          //                                       ],*/
          //                                             ),
          //                                           ),
          //                                           userPostModal
          //                                               .commentList[index] !=
          //                                               null &&
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .roleId ==
          //                                                   "1"
          //                                           //true
          //                                               ? Util
          //                                               .getStudentBadge12(
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .badge,
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .badgeImage)
          //                                               : Container(
          //                                             height: 0.0,
          //                                             width: 0.0,
          //                                           ),
          //                                         ],
          //                                       )),
          //                                 ),
          //                                 Container(
          //                                   child:
          //                                   Linkify(
          //                                     onOpen:
          //                                         (link) async {
          //                                       Navigator.of(context,
          //                                           rootNavigator: true)
          //                                           .push(
          //                                           new MaterialPageRoute(
          //                                               fullscreenDialog:
          //                                               true,
          //                                               builder: (
          //                                                   BuildContext context) =>
          //                                                   WebViewWidget(
          //                                                       link
          //                                                           .url,
          //                                                       "spikeview")));
          //                                     },
          //                                     text: userPostModal
          //                                         .commentList[
          //                                     index]
          //                                         .comment,
          //                                     style: TextStyle(
          //                                         color: ColorValues
          //                                             .HEADING_COLOR_EDUCATION_1,
          //                                         fontSize:
          //                                         14.0,
          //                                         fontWeight:
          //                                         FontWeight
          //                                             .normal,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR),
          //                                     linkStyle: TextStyle(
          //                                         color: ColorValues
          //                                             .BLUE_COLOR_BOTTOMBAR,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR,
          //                                         fontSize:
          //                                         14.0),
          //                                   ),
          //                                 ),
          //                                 Padding(
          //                                     padding: EdgeInsets
          //                                         .fromLTRB(
          //                                         0.0,
          //                                         5.0,
          //                                         0.0,
          //                                         0.0),
          //                                     child: Row(
          //                                       mainAxisAlignment:
          //                                       MainAxisAlignment
          //                                           .start,
          //                                       crossAxisAlignment:
          //                                       CrossAxisAlignment
          //                                           .center,
          //                                       children: <
          //                                           Widget>[
          //                                         Expanded(
          //                                           child:
          //                                           Row(
          //                                             mainAxisAlignment:
          //                                             MainAxisAlignment
          //                                                 .start,
          //                                             crossAxisAlignment:
          //                                             CrossAxisAlignment
          //                                                 .start,
          //                                             children: <
          //                                                 Widget>[
          //                                               Text(
          //                                                 userPostModal
          //                                                     .commentList[index]
          //                                                     .dateTime,
          //                                                 textAlign: TextAlign
          //                                                     .end,
          //                                                 style: TextStyle(
          //                                                     color: ColorValues
          //                                                         .GREY_TEXT_COLOR,
          //                                                     fontSize: 12.0,
          //                                                     fontFamily: Constant
          //                                                         .customRegular),
          //                                               )
          //                                             ],
          //                                           ),
          //                                           flex:
          //                                           0,
          //                                         ),
          //                                         Container(
          //                                           width:
          //                                           10.0,
          //                                         ),
          //                                         Expanded(
          //                                           child: userIdPref ==
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .commentedBy //&& userPostModal.commentList[index].isComment
          //                                               ? InkWell(
          //                                             child: Padding(
          //                                               padding: const EdgeInsets
          //                                                   .fromLTRB(
          //                                                   0.0, 0, 0,
          //                                                   5),
          //                                               child: Image
          //                                                   .asset(
          //                                                 "assets/feed/three_dot_blue.png",
          //                                                 width: 15.0,
          //                                                 height: 15.0,
          //                                               ),
          //                                             ),
          //                                             onTap: () {
          //                                               optionForDelete(
          //                                                   userPostModal
          //                                                       .commentList,
          //                                                   userPostModal
          //                                                       .feedId,
          //                                                   userPostModal,
          //                                                   userPostModal
          //                                                       .commentList[index]
          //                                                       .commentId,
          //                                                   index);
          //                                             },
          //                                           )
          //                                               : Container(
          //                                             height: 1.0,
          //                                           ),
          //                                           flex:
          //                                           0,
          //                                         )
          //                                       ],
          //                                     )),
          //                               ],
          //                             ),
          //                             flex: 1,
          //                           ) // Comment List Cell
          //                         ],
          //                       ));
          //                 }))),
          //
          //         // View All Comments
          //         userPostModal.commentList.length > 3
          //             ? InkWell(
          //           child: PaddingWrap.paddingfromLTRB(
          //             10.0,
          //             0.0,
          //             0.0,
          //             5.0,
          //             TextViewWrap.textView(
          //                 "View All " +
          //                     userPostModal
          //                         .commentList.length
          //                         .toString() +
          //                     " Comments",
          //                 TextAlign.left,
          //                 ColorValues.labelColor,
          //                 12.0,
          //                 FontWeight.w500),
          //           ),
          //           onTap: () {
          //             onTapViewAllComments(
          //                 userPostModal.commentList,
          //                 userPostModal.feedId,
          //                 userPostModal);
          //           },
          //         )
          //             : Container(
          //           height: 0.0,
          //         ),
          //
          //         // Comment Edit Text
          //         userPostModal.isShowCommentIcon
          //             ? PaddingWrap.paddingAll(
          //             10.0,
          //             Row(
          //               children: <Widget>[
          //                 //Alok Code Done
          //
          //                 ProfileImageView(
          //                   imagePath: roleId == "4"
          //                       ? Constant
          //                       .IMAGE_PATH +
          //                       companyPath
          //                       : Constant
          //                       .IMAGE_PATH +
          //                       profilePath,
          //                   placeHolderImage: roleId == "4"
          //                       ? "assets/profile/partner_img.png"
          //                       : 'assets/profile/user_on_user.png',
          //                   width: 40.0,
          //                   height: 40.0,
          //                   onTap: () async {
          //
          //                   },
          //                 ),
          //                 SizedBox(
          //                   width: 9.0,
          //                 ),
          //                 Expanded(
          //                     child: Container(
          //                         decoration: BoxDecoration(
          //                             border: Border.all(
          //                                 width: 1.0,
          //                                 color: ColorValues
          //                                     .LIGHT_GREY_TEXT_COLOR)),
          //                         child: Row(
          //                           crossAxisAlignment:
          //                           CrossAxisAlignment
          //                               .center,
          //                           mainAxisAlignment:
          //                           MainAxisAlignment
          //                               .center,
          //                           children: <Widget>[
          //                             Expanded(
          //                               child: TextField(
          //                                 controller:
          //                                 userPostModal
          //                                     .txtController,
          //                                 style: TextStyle(
          //                                     fontFamily:
          //                                     Constant
          //                                         .TYPE_CUSTOMREGULAR),
          //                                 keyboardType:
          //                                 TextInputType
          //                                     .text,
          //                                 textCapitalization:
          //                                 TextCapitalization
          //                                     .sentences,
          //                                 maxLines: null,
          //                                 maxLength:
          //                                 TextLength
          //                                     .COMMENT_MAX_LENGTH,
          //                                 onChanged: (s) {
          //                                   if (s
          //                                       .trim()
          //                                       .length >
          //                                       0) {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     true;
          //                                   } else {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                   }
          //                                   setState(() {
          //                                     userPostModal
          //                                         .isCommentIconVisible;
          //                                   });
          //                                 },
          //                                 decoration:
          //                                 InputDecoration(
          //                                   border:
          //                                   InputBorder
          //                                       .none,
          //                                   filled: true,
          //                                   counterText:
          //                                   "",
          //                                   hintText: roleId ==
          //                                       "4"
          //                                       ? "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference
          //                                               .COMPANY_NAME_PATH)
          //                                       : "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference.NAME)
          //                                           .replaceAll(
          //                                           "null",
          //                                           ""),
          //                                   hintStyle: TextStyle(
          //                                       color: ColorValues
          //                                           .GREY_TEXT_COLOR,
          //                                       fontSize:
          //                                       14.0,
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   fillColor: Colors
          //                                       .transparent,
          //                                 ),
          //                               ),
          //                               flex: 4,
          //                             ),
          //                             Expanded(
          //                               child:
          //                               /*userPostModal
          //                                   .isCommentIconVisible
          //                               ?*/
          //                               InkWell(
          //                                 child: PaddingWrap
          //                                     .paddingfromLTRB(
          //                                     0.0,
          //                                     0.0,
          //                                     5.0,
          //                                     0.0,
          //                                     Image
          //                                         .asset(
          //                                       "assets/feed/sent_icon.png",
          //                                       width:
          //                                       22.0,
          //                                       height:
          //                                       22.0,
          //                                     )),
          //                                 onTap: () {
          //                                   if (userPostModal
          //                                       .isCommentIconVisible) {
          //                                     FocusScope.of(
          //                                         context)
          //                                         .requestFocus(
          //                                         FocusNode());
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                     onAddComment(
          //                                         userPostModal
          //                                             .feedId,
          //                                         userPostModal
          //                                             .txtController
          //                                             .text,
          //                                         userPostModal);
          //                                     userPostModal
          //                                         .txtController
          //                                         .text = "";
          //                                     setState(
          //                                             () {
          //                                           userPostModal
          //                                               .txtController;
          //                                           userPostModal
          //                                               .isCommentIconVisible;
          //                                         });
          //                                   }
          //                                 },
          //                               )
          //                               /*:  Container(
          //                                   height: 0.0,
          //                                 )*/
          //                               ,
          //                               flex: 0,
          //                             )
          //                           ],
          //                         )),
          //                     flex: 1)
          //               ],
          //             ))
          //             : Container(
          //           height: 0.0,
          //         ),
          //
          //         (userPostList.length - 1) == index
          //             ? Container(
          //           height: 10.0,
          //         )
          //             : Container(
          //           height: 0.0,
          //         ),
          //         Container(
          //           height: 20.0,
          //         )
          //         // PaddingWrap.paddingfromLTRB(
          //         //     0.0,
          //         //     10.0,
          //         //     0.0,
          //         //     10.0,
          //         //     Divider(
          //         //       color: ColorValues.WHITE,
          //         //       height: 1.0,
          //         //     ))
          //       ],
          //     ))
          //     : const SizedBox.shrink()
          //     : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget imageViewForGetListViewBlue(userPostModal, index) {
    return PaddingWrap.paddingfromLTRB(
        20.0,
        12.0,
        0.0,
        0.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            ProfileImageView(
              imagePath: Constant.IMAGE_PATH_SMALL +
                  ParseJson.getSmallImage(userPostModal.profilePicture),
              placeHolderImage: userPostModal.roleId == "4"
                  ? "assets/profile/partner_img.png"
                  : 'assets/profile/user_on_user.png',
              width: 46.0,
              height: 46.0,
              onTap: () async {
                onTapImageTile(userPostModal.postedBy, userPostModal.roleId);
              },
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: InkWell(
                          child: Container(
                              child: RichText(
                            maxLines: 3,
                            textAlign: TextAlign.start,
                            text: TextSpan(
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  if (userPostModal.tagList.length > 0 &&
                                      userPostModal.groupList.length > 0) {
                                    onTapImageTile(userPostModal.postedBy,
                                        userPostModal.roleId);
                                  }
                                },
                              text: userPostModal.lastName == null ||
                                      userPostModal.lastName == "null"
                                  ? userPostModal.firstName
                                  : userPostModal.firstName +
                                      " " +
                                      userPostModal.lastName,
                              style: TextStyle(
                                  color: ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: Constant.latoRegular),
                              children: userPostModal.tagList.length == 0 &&
                                      userPostModal.groupList.length == 0
                                  ? [
                                      WidgetSpan(
                                        child: userPostModal.roleId == "1"
                                            ? Util
                                                .getStudentBadgeRichTextWithPadding(
                                                    userPostModal.badge,
                                                    userPostModal.badgeImage)
                                            : Container(
                                                height: 0.0,
                                                width: 0.0,
                                              ),
                                      ),
                                    ]
                                  : userPostModal.tagList.length != 0
                                      ?  [
                                              WidgetSpan(
                                                child: userPostModal.roleId ==
                                                        "1"
                                                    ? Util
                                                        .getStudentBadgeRichTextWithPadding(
                                                            userPostModal.badge,
                                                            userPostModal
                                                                .badgeImage)
                                                    : Container(
                                                        height: 0.0,
                                                        width: 0.0,
                                                      ),
                                              ),
                                              TextSpan(
                                                  text: ' with ',
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION_1,
                                                      fontSize: 16.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontFamily: Constant
                                                          .latoRegular)),
                                              TextSpan(
                                                text: userPostModal.tagList[0]
                                                                .name ==
                                                            null ||
                                                        userPostModal.tagList[0]
                                                                .name ==
                                                            "null"
                                                    ? ""
                                                    : userPostModal
                                                        .tagList[0].name,
                                                style: TextStyle(
                                                    color: ColorValues
                                                        .HEADING_COLOR_EDUCATION_1,
                                                    fontSize: 16.0,
                                                    fontFamily: Constant.latoSemibold
                                                   ),
                                              ),
                                              userPostModal.tagList.length > 1
                                                  ? TextSpan(
                                                      text: ' and ',
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    )
                                                  : TextSpan(
                                                      text: "",
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    ),
                                              userPostModal.tagList.length > 1
                                                  ? TextSpan(
                                                      text: (userPostModal
                                                                  .tagList
                                                                  .length -
                                                              1)
                                                          .toString(),
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    )
                                                  : TextSpan(
                                                      text: "",
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    ),
                                              userPostModal.tagList.length > 1
                                                  ? TextSpan(
                                                      text: " others ",
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontSize: 16.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    )
                                                  : TextSpan(
                                                      text: "",
                                                      style: TextStyle(
                                                          color: ColorValues
                                                              .HEADING_COLOR_EDUCATION_1,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          fontFamily: Constant
                                                              .latoRegular),
                                                    ),
                                            ]:[],
                            ),
                          )),
                          onTap: () {
                            if (userPostModal.tagList.length > 0 &&
                                userPostModal.groupList.length > 0) {
                            } else if (userPostModal.groupList.length > 0) {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      SelectedGroup(userPostModal,userPostModal.groupList)));
                            } else if (userPostModal.tagList.length > 0) {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      TagDetailWidget(userPostModal.tagList)));
                            } else {
                              onTapImageTile(
                                  userPostModal.postedBy, userPostModal.roleId);
                            }
                          },
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                    child: Row(
                      children: [
                        TextViewWrap.textView(
                            userPostModal.dateTime,
                            TextAlign.center,
                            ColorValues.labelColor,
                            12.0,
                            FontWeight.w400),
                        userPostModal.visibility == ""
                            ? Container(
                                height: 0.0,
                              )
                            : userIdPref == userPostModal.postedBy &&
                                    roleId == userPostModal.roleId.toString()
                                ? PaddingWrap.paddingfromLTRB(
                                    4.0,
                                    0.0,
                                    5.0,
                                    0.0,
                                    Image.asset(
                                      userPostModal.visibility == "Private"
                                          ? "assets/profile/post/private_new.png"
                                          : userPostModal.visibility ==
                                                  "SelectedConnections"
                                              ? "assets/profile/post/selected_connections.png"
                                              : userPostModal.visibility ==
                                                      "AllConnections"
                                                  ? "assets/profile/post/connection.png"
                                                  : userPostModal.visibility ==
                                                          "Group"
                                                      ? "assets/profile/post/group_data.png"
                                                      : "assets/profile/post/community.png",
                                      width: 13.0,
                                      color: userPostModal.visibility ==
                                              "SelectedConnections"
                                          ? null
                                          : ColorValues.labelColor,
                                      height: 14.0,
                                    ))
                                : Container(
                                    height: 0.0,
                                  ),
                        /*  userPostModal.visibility == ""
                                              ?  Container(
                                                  height: 0.0,
                                                )
                                              : PaddingWrap.paddingfromLTRB(
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  0.0,
                                                  TextViewWrap.textView(
                                                      userPostModal.visibility ==
                                                              "Private"
                                                          ? "Private"
                                                          : userPostModal
                                                                      .visibility ==
                                                                  "SelectedConnections"
                                                              ? "Selected Connections"
                                                              : userPostModal
                                                                          .visibility ==
                                                                      "AllConnections"
                                                                  ? "Connections"
                                                                  : userPostModal
                                                                              .visibility ==
                                                                          "Group"
                                                                      ? "Group"
                                                                      : "Community",
                                                      TextAlign.center,
                                                      ColorValues.GREY_TEXT_COLOR,
                                                      12.0,
                                                      FontWeight.normal))*/
                      ],
                    ),
                  )
                ],
              ),
            ),
            Expanded(
              child: userIdPref == userPostModal.postedBy &&
                      roleId == userPostModal.roleId.toString()
                  ? Container(
                      padding: EdgeInsets.fromLTRB(13, 4.0, 13, 0),
                      child: InkWell(
                        child: Image.asset(
                          "assets/feed/three_dot_blue.png",
                          width: 15.0,
                          height: 15.0,
                        ),
                        onTap: () {
                          editDeletePopUp(userPostModal, index);
                        },
                      ))
                  : Container(
                      padding: EdgeInsets.fromLTRB(13, 4.0, 13, 0),
                      child: InkWell(
                        child: Image.asset(
                          "assets/feed/three_dot_blue.png",
                          width: 15.0,
                          height: 15.0,
                        ),
                        onTap: () {
                          issuePopUp(userPostModal, index);
                        },
                      )),
              flex: 0,
            )
          ],
        ));
  }

  Widget imageViewForGetListView(userPostModal, index) {
    return Container(
      decoration: BoxDecoration(
        /* image: DecorationImage(
            image: AssetImage("assets/feed/background_imageview.png"),
            fit: BoxFit.cover,
          ),*/
        gradient: LinearGradient(
          colors: [
            Color(0xff000000),
            Color(0x00000000),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 0, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          ProfileImageView(
            imagePath: Constant.IMAGE_PATH_SMALL +
                ParseJson.getSmallImage(userPostModal.profilePicture),
            placeHolderImage: userPostModal.roleId == "4"
                ? "assets/profile/partner_img.png"
                : 'assets/profile/user_on_user.png',
            height: 46.0,
            width: 46.0,
            onTap: () async {
              onTapImageTile(userPostModal.postedBy, userPostModal.roleId);
            },
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                      child: InkWell(
                        child: RichText(
                          maxLines: 3,
                          textAlign: TextAlign.start,
                          text: TextSpan(
                            recognizer: TapGestureRecognizer()
                              ..onTap = () {
                                if (userPostModal.tagList.length > 0 &&
                                    userPostModal.groupList.length > 0) {
                                  onTapImageTile(userPostModal.postedBy,
                                      userPostModal.roleId);
                                }
                              },
                            text: userPostModal.lastName == null ||
                                    userPostModal.lastName == "null"
                                ? userPostModal.firstName
                                : userPostModal.firstName +
                                    " " +
                                    userPostModal.lastName,
                            style: TextStyle(
                                color: ColorValues.WHITE,
                                fontSize: 16.0,
                                fontWeight: FontWeight.w500,
                                fontFamily: Constant.latoRegular),
                            children: userPostModal.tagList.length == 0 &&
                                    userPostModal.groupList.length == 0
                                ? [
                                    WidgetSpan(
                                      child: userPostModal.roleId == "1"
                                          ? Util
                                              .getStudentBadgeRichTextWithPadding(
                                                  userPostModal.badge,
                                                  userPostModal.badgeImage)
                                          : Container(
                                              height: 0.0,
                                              width: 0.0,
                                            ),
                                    ),
                                  ]
                                : userPostModal.tagList.length != 0
                                    ?  [
                                            WidgetSpan(
                                              child: userPostModal.roleId == "1"
                                                  ? Util
                                                      .getStudentBadgeRichTextWithPadding(
                                                          userPostModal.badge,
                                                          userPostModal
                                                              .badgeImage)
                                                  : Container(
                                                      height: 0.0,
                                                      width: 0.0,
                                                    ),
                                            ),
                                            TextSpan(
                                                text: ' with ',
                                                style: TextStyle(
                                                    color: ColorValues.WHITE,
                                                    fontSize: 16.0,
                                                    fontWeight: FontWeight.w500,
                                                    fontFamily:
                                                        Constant.latoRegular)),
                                            TextSpan(
                                              text: userPostModal.tagList[0]
                                                              .name ==
                                                          null ||
                                                      userPostModal.tagList[0]
                                                              .name ==
                                                          "null"
                                                  ? ""
                                                  : userPostModal
                                                      .tagList[0].name,
                                              style: TextStyle(
                                                  color: ColorValues.WHITE,
                                                  fontSize: 16.0,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily:
                                                      Constant.latoRegular),
                                            ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                                    text: ' and ',
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.WHITE,
                                                        fontSize: 16.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoRegular),
                                                  )
                                                : TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.WHITE,
                                                        fontSize: 14.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoRegular),
                                                  ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                                    text: (userPostModal.tagList
                                                                .length -
                                                            1)
                                                        .toString(),
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.WHITE,
                                                        fontSize: 16.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoRegular),
                                                  )
                                                : TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.WHITE,
                                                        fontSize: 14.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoRegular),
                                                  ),
                                            userPostModal.tagList.length > 1
                                                ? TextSpan(
                                                    text: " others ",
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.WHITE,
                                                        fontSize: 16.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoRegular),
                                                  )
                                                : TextSpan(
                                                    text: "",
                                                    style: TextStyle(
                                                        color:
                                                            ColorValues.WHITE,
                                                        fontSize: 14.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: Constant
                                                            .latoRegular),
                                                  ),
                                          ]:[],
                          ),
                        ),
                        onTap: () {
                          if (userPostModal.tagList.length > 0 &&
                              userPostModal.groupList.length > 0) {
                          } else if (userPostModal.groupList.length > 0) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    SelectedGroup(userPostModal,userPostModal.groupList)));
                          } else if (userPostModal.tagList.length > 0) {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    TagDetailWidget(userPostModal.tagList)));
                          } else {
                            onTapImageTile(
                                userPostModal.postedBy, userPostModal.roleId);
                          }
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
                /*    TextViewWrap.textView(
                                          userPostModal.dateTime,
                                          TextAlign.center,
                                          ColorValues.GREY_TEXT_COLOR,
                                          12.0,
                                          FontWeight.normal),*/
                Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 5, 0, 0),
                  child: Row(
                    children: [
                      TextViewWrap.textView(
                          userPostModal.dateTime,
                          TextAlign.center,
                          ColorValues.WHITE,
                          12.0,
                          FontWeight.w400),
                      userPostModal.visibility == ""
                          ? Container(
                              height: 0.0,
                            )
                          : userIdPref == userPostModal.postedBy &&
                                  roleId == userPostModal.roleId.toString()
                              ? PaddingWrap.paddingfromLTRB(
                                  4.0,
                                  0.0,
                                  5.0,
                                  0.0,
                                  Image.asset(
                                    userPostModal.visibility == "Private"
                                        ? "assets/profile/post/private_new.png"
                                        : userPostModal.visibility ==
                                                "SelectedConnections"
                                            ? "assets/profile/post/selected_connections.png"
                                            : userPostModal.visibility ==
                                                    "AllConnections"
                                                ? "assets/profile/post/connection.png"
                                                : userPostModal.visibility ==
                                                        "Group"
                                                    ? "assets/profile/post/group_data.png"
                                                    : "assets/profile/post/community.png",
                                    width: 13.0,
                                    color: userPostModal.visibility ==
                                            "SelectedConnections"
                                        ? null
                                        : ColorValues.WHITE,
                                    height: 14.0,
                                  ))
                              : Container(
                                  height: 0.0,
                                ),
                    ],
                  ),
                )
              ],
            ),
          ),
          InkWell(
            child: Padding(
              padding: EdgeInsets.fromLTRB(15, 4, 15, 3),
              child: Image.asset(
                "assets/feed/three_dot_white.png",
                width: 15.0,
                height: 15.0,
              ),
            ),
            onTap: () {
              userIdPref == userPostModal.postedBy &&
                      roleId == userPostModal.roleId.toString()
                  ? editDeletePopUp(userPostModal, index)
                  : issuePopUp(userPostModal, index);
            },
          )
        ],
      ),
    );
  }

  Widget getListView(UserPostModal userPostModal, index, bool isUserRepoted) {
    return Container(
      color: ColorValues.SCREEN_BG_COLOR,
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 21),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Stack(
            children: <Widget>[
              userPostModal.postdata == null ||
                      userPostModal.postdata.text == null ||
                      userPostModal.postdata.text == "null"
                  ? const SizedBox.shrink()
                  : PaddingWrap.paddingfromLTRB(
                      10.0,
                      0.0,
                      10.0,
                      0.0,
                      Container(
                        color: Colors.transparent,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              0.0,
                              userPostModal.postdata.text == "" ||
                                      userPostModal.postdata.text == "null" ||
                                      userPostModal.postdata.text == "\n"
                                  ? const SizedBox.shrink()
                                  : userPostModal.postdata.assetsList.length ==
                                              0 &&
                                          (userPostModal.postdata.metaUrl !=
                                                  "" &&
                                              userPostModal
                                                      .postdata.metaImage !=
                                                  "")
                                      ? exp
                                                      .allMatches(userPostModal
                                                          .postdata.text)
                                                      .length ==
                                                  1 &&
                                              userPostModal.postdata.text
                                                      .toString()
                                                      .replaceAll(exp, '')
                                                      .length ==
                                                  0
                                          ? const SizedBox.shrink()
                                          : PaddingWrap.paddingfromLTRB(
                                              4.0,
                                              10.0,
                                              13.0,
                                              0.0,
                                              Container(
                                                child: Linkify(
                                                  onOpen: (link) async {
                                                    apiCallingForIncreaseCount(
                                                        userPostModal.feedId);
                                                    Navigator.of(context,
                                                            rootNavigator: true)
                                                        .push(new MaterialPageRoute(
                                                            fullscreenDialog:
                                                                true,
                                                            builder: (BuildContext
                                                                    context) =>
                                                                WebViewWidget(
                                                                    link.url,
                                                                    "spikeview")));
                                                  },
                                                  text: "",
                                                  style: TextStyle(
                                                      color: ColorValues
                                                          .HEADING_COLOR_EDUCATION_1,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                  linkStyle: TextStyle(
                                                      color: ColorValues
                                                          .BLUE_COLOR_BOTTOMBAR,
                                                      fontFamily: Constant
                                                          .TYPE_CUSTOMREGULAR,
                                                      fontSize: 14.0),
                                                ),
                                              ))
                                      : Container(
                                          child: Linkify(
                                            onOpen: (link) async {
                                              apiCallingForIncreaseCount(
                                                  userPostModal.feedId);
                                              Navigator.of(context,
                                                      rootNavigator: true)
                                                  .push(new MaterialPageRoute(
                                                      fullscreenDialog: true,
                                                      builder: (BuildContext
                                                              context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                            },
                                            text: "",
                                            // userPostModal
                                            //         .postdata.text +
                                            //     "SSSSSS",
                                            style: TextStyle(
                                                color: ColorValues
                                                    .HEADING_COLOR_EDUCATION_1,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 14.0),
                                            linkStyle: TextStyle(
                                                color: ColorValues
                                                    .BLUE_COLOR_BOTTOMBAR,
                                                fontFamily:
                                                    Constant.TYPE_CUSTOMREGULAR,
                                                fontSize: 14.0),
                                          ),
                                        ),
                            ),
                          ],
                        ),
                      ),
                    ),
              userPostModal.postdata.assetsList.length == 0
                  ? const SizedBox.shrink()
                  : SizedBox(
                      height: 250.0,
                      child: PageIndicatorContainer(
                        pageView: PageView.builder(
                          itemCount: userPostModal.postdata.assetsList.length,
                          controller: PageController(),
                          itemBuilder: (context, index2) {
                            return userPostModal
                                        .postdata.assetsList[index2].type ==
                                    'image'
                                ? InkWell(
                                    child: Stack(children: <Widget>[
                                      Container(
                                          decoration: BoxDecoration(
                                            color: Colors.black,
                                          ),
                                          height: 250.0,
                                          child: CachedNetworkImage(
                                            width: double.infinity,
                                            height: 250.0,
                                            imageUrl:
                                                Constant.IMAGE_PATH_SMALL +
                                                    ParseJson.getMediumImage(
                                                        userPostModal
                                                            .postdata
                                                            .assetsList[index2]
                                                            .file),
                                            fit: BoxFit.cover,
                                            placeholder: (context, url) =>
                                                _loader(context),
                                            errorWidget:
                                                (context, url, error) =>
                                                    _error(),
                                          )),
                                      userPostModal
                                                  .postdata.assetsList.length ==
                                              1
                                          ? InkWell(
                                              onTap: () {
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            CommonFullViewWidget(
                                                                userPostModal
                                                                    .postdata
                                                                    .assetsList,
                                                                MessageConstant
                                                                    .HOME_FEED,
                                                                index2,
                                                                MessageConstant
                                                                    .COMPANY_PROFILE_HEDING)));
                                              },
                                              child: Container(
                                                height: 0.0,
                                              ))
                                          : InkWell(
                                              onTap: () {
                                                Navigator.of(context).push(
                                                    new MaterialPageRoute(
                                                        builder: (BuildContext
                                                                context) =>
                                                            CommonFullViewWidget(
                                                                userPostModal
                                                                    .postdata
                                                                    .assetsList,
                                                                MessageConstant
                                                                    .HOME_FEED,
                                                                index2,
                                                                MessageConstant
                                                                    .COMPANY_PROFILE_HEDING)));
                                              },
                                              child: Container(
                                                height: 250.0,
                                                width: double.infinity,
                                                child: Image.asset(
                                                  "assets/newDesignIcon/navigation/layer_image.png",
                                                  fit: BoxFit.fill,
                                                ),
                                              ))
                                    ]),
                                    onTap: () {
                                      Navigator.of(context).push(MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              CommonFullViewWidget(
                                                  userPostModal
                                                      .postdata.assetsList,
                                                  MessageConstant.HOME_FEED,
                                                  index2,
                                                  MessageConstant
                                                      .COMPANY_PROFILE_HEDING)));
                                    },
                                  )
                                : InkWell(
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.black,
                                        borderRadius: BorderRadius.circular(0),
                                      ),
                                      height: 250.0,
                                      width: double.infinity,
                                      child: Center(
                                        child: Center(
                                          child: Center(
                                            child: VideoPlayPause(
                                                userPostModal.postdata
                                                    .assetsList[index2].file,
                                                userPostModal.feedId,
                                                true,
                                                allVideoController),
                                          ),
                                        ),
                                      ),
                                    ),
                                    onTap: () {
                                      print('ontap video feed::: ');
                                      apiCallingForIncreaseCount(
                                          userPostModal.feedId);
                                    },
                                  );
                          },
                          onPageChanged: (index) {},
                        ),
                        align: IndicatorAlign.bottom,
                        length: userPostModal.postdata.assetsList.length,
                        indicatorSpace: 10.0,
                        indicatorColor:
                            userPostModal.postdata.assetsList.length == 1
                                ? Colors.transparent
                                : Color(0xffc4c4c4),
                        indicatorSelectorColor:
                            userPostModal.postdata.assetsList.length == 1
                                ? Colors.transparent
                                : ColorValues.WHITE,
                        shape: IndicatorShape.circle(size: 5.0),
                      ),
                    ),
              userPostModal.postdata.assetsList.length == 0
                  ? userPostModal.postdata == null ||
                          userPostModal.postdata.text == null ||
                          userPostModal.postdata.text == "null"
                      ? const SizedBox.shrink()
                      : userPostModal.postdata.metaUrl != ""
                          ? Container(
                              margin: EdgeInsets.symmetric(vertical: 4.0),
                              child: NewWhatsAppViewFeed(
                                  imageUrl: userPostModal.postdata.metaImage,
                                  feedId: userPostModal.feedId,
                                  title: "",
                                  url: userPostModal.postdata.metaUrl,
                                  metaHeight: userPostModal.postdata.metaHeight,
                                  metaWidth: userPostModal.postdata.metaWidth,
                                  metaSource: "",
                                  description: "",
                                  isEmptyFeed: true))
                          : const SizedBox.shrink()
                  : const SizedBox.shrink(),
              userPostModal.postdata.assetsList.length == 0 &&
                      (userPostModal.postdata.metaUrl == "" &&
                          userPostModal.postdata.metaImage == "")
                  ? imageViewForGetListViewBlue(userPostModal, index)
                  : imageViewForGetListView(userPostModal, index),
            ],
          ),
          isUserRepoted
              ? ACCESS_CONTROL_GROUP
                  ? Padding(
                      padding:
                          const EdgeInsets.only(left: 20, top: 5, right: 20),
                      child: Row(
                        children: <Widget>[
                          InkWell(
                            onTap: () {
                              onTapLike(userPostModal);
                            },
                            child: userPostModal.isLike
                                ? Image.asset(
                                    "assets/feed/heart_red.png",
                                    height: 21.0,
                                    width: 21.0,
                                  )
                                : Image.asset(
                                    "assets/feed/heart_blue.png",
                                    height: 21.0,
                                    width: 21.0,
                                  ),
                          ),
                          const SizedBox(width: 7),
                          InkWell(
                            onTap: () {
                              onTapViewAllComments(userPostModal.commentList,
                                  userPostModal.feedId, userPostModal);
                            },
                            child: Image.asset(
                              "assets/feed/comment.png",
                              height: 28.0,
                              width: 28.0,
                            ),
                          ),
                          const SizedBox(width: 7),
                          _shareButton(onTap: () {
                            onTapShare(userPostModal);
                          }),
                          Spacer(),
                        ],
                      ),
                    )
                  : const SizedBox.shrink()
              : const SizedBox.shrink(),
          isUserRepoted
              ? ACCESS_CONTROL_GROUP
                  ? userPostModal.likesCount > 0 ||
                          userPostModal.commentList.length > 0
                      ? Padding(
                          padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: userPostModal.likesCount > 0
                                    ? PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        0.0,
                                        7.0,
                                        0.0,
                                        InkWell(
                                          child: TextViewWrap.textView(
                                              userPostModal.likesCount == 0
                                                  ? "Like"
                                                  : userPostModal.likesCount ==
                                                          1
                                                      ? "1 Like"
                                                      : userPostModal.likesCount
                                                              .toString() +
                                                          " Likes",
                                              TextAlign.end,
                                              ColorValues.labelColor,
                                              12.0,
                                              FontWeight.w500),
                                          onTap: () {
                                            onTapLikeText(userPostModal);
                                          },
                                        ))
                                    : const SizedBox.shrink(),
                                flex: 0,
                              ),
                              userPostModal.commentList.length == 0
                                  ? const SizedBox.shrink()
                                  : InkWell(
                                      child: TextViewWrap.textView(
                                          userPostModal.commentList.length == 0
                                              ? "Comment"
                                              : "" +
                                                  userPostModal
                                                      .commentList.length
                                                      .toString() +
                                                  " Comments",
                                          TextAlign.left,
                                          ColorValues.labelColor,
                                          12.0,
                                          FontWeight.w500),
                                      onTap: () {
                                        onTapViewAllComments(
                                            userPostModal.commentList,
                                            userPostModal.feedId,
                                            userPostModal);
                                      },
                                    )
                            ],
                          ),
                        )
                      : const SizedBox.shrink()
                  : const SizedBox.shrink()
              : const SizedBox.shrink(),

          userPostModal.postdata.metaUrl != ""
              ? Container(
                  width: double.infinity,
                  padding: EdgeInsets.fromLTRB(13.0, 10.0, 13.0, 0),
                  color: Color(0XFFFFFFFF),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      InkWell(
                        child: Text(
                          userPostModal.postdata.metaTitle == null
                              ? ""
                              : userPostModal.postdata.metaTitle.trim(),
                          textAlign: TextAlign.start,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.TYPE_CUSTOMBOLD,
                              fontSize: 14.0),
                        ),
                        onTap: () {
                          onTapView(userPostModal);
                        },
                      ),
                      InkWell(
                        child: Text(
                          userPostModal.postdata.metaSource == null
                              ? ""
                              : userPostModal.postdata.metaSource.trim(),
                          textAlign: TextAlign.start,
                          maxLines: 1,
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontFamily: Constant.latoRegular,
                              fontSize: 14.0),
                        ),
                        onTap: () {
                          //onTapView();
                          Navigator.of(context).push(new MaterialPageRoute(
                              builder: (BuildContext context) => WebViewWidget(
                                  userPostModal.postdata.metaUrl,
                                  "spikeview")));
                        },
                      ),
                      Text(
                        userPostModal.postdata.metaDescription == null
                            ? ""
                            : userPostModal.postdata.metaDescription.trim(),
                        textAlign: TextAlign.start,
                        maxLines: userPostModal.postdata.isShowMore ? 30 : 3,
                        style: TextStyle(
                            color: ColorValues.HEADING_COLOR_EDUCATION_1,
                            fontWeight: FontWeight.w400,
                            fontFamily: Constant.latoRegular,
                            fontSize: 14.0),
                      ),
                      userPostModal.postdata.metaDescription.trim().length > 190
                          ? InkWell(
                              child: Text(
                                userPostModal.postdata.isShowMore
                                    ? "Less"
                                    : "More",
                                textAlign: TextAlign.start,
                                maxLines: 1,
                                style: TextStyle(
                                    color: ColorValues.BLUE_COLOR_BOTTOMBAR,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                    fontSize: 12.0),
                              ),
                              onTap: () {
                                setState(() {
                                  if (userPostModal.postdata.isShowMore) {
                                    userPostModal.postdata.isShowMore = false;
                                  } else
                                    userPostModal.postdata.isShowMore = true;
                                });
                              })
                          : const SizedBox.shrink(),
                    ],
                  ),
                )
              : const SizedBox.shrink(),

          userPostModal.postdata == null ||
                  userPostModal.postdata.text == null ||
                  userPostModal.postdata.text == "null"
              ? const SizedBox.shrink()
              : PaddingWrap.paddingfromLTRB(
                  20.0,
                  10.0,
                  20.0,
                  0.0,
                  Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        PaddingWrap.paddingfromLTRB(
                          0.0,
                          0.0,
                          0.0,
                          0.0,
                          userPostModal.postdata.text == "" ||
                                  userPostModal.postdata.text == "null" ||
                                  userPostModal.postdata.text == "\n"
                              ? const SizedBox.shrink()
                              : userPostModal.postdata.imageList.length == 0 &&
                                      (userPostModal.postdata.media == null ||
                                          userPostModal.postdata.media == "" ||
                                          userPostModal.postdata.media ==
                                              "null") &&
                                      (userPostModal.postdata.metaUrl != "" &&
                                          userPostModal.postdata.metaImage !=
                                              "")
                                  ? exp
                                                  .allMatches(userPostModal
                                                      .postdata.text)
                                                  .length ==
                                              1 &&
                                          userPostModal.postdata.text
                                                  .toString()
                                                  .replaceAll(exp, '')
                                                  .length ==
                                              0
                                      ? const SizedBox.shrink()
                                      : PaddingWrap.paddingfromLTRB(
                                          4.0,
                                          10.0,
                                          13.0,
                                          0.0,
                                          Container(
                                            child: Linkify(
                                              onOpen: (link) async {
                                                apiCallingForIncreaseCount(
                                                    userPostModal.feedId);
                                                Navigator.of(context,
                                                        rootNavigator: true)
                                                    .push(new MaterialPageRoute(
                                                        fullscreenDialog: true,
                                                        builder: (BuildContext
                                                                context) =>
                                                            WebViewWidget(
                                                                link.url,
                                                                "spikeview")));
                                              },
                                              text: exp
                                                          .allMatches(
                                                              userPostModal
                                                                  .postdata
                                                                  .text)
                                                          .length >
                                                      1
                                                  ? userPostModal.postdata.text
                                                  : userPostModal.postdata.text
                                                      .toString()
                                                      .replaceAll(exp, ''),
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily:
                                                      Constant.latoRegular,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.w400),
                                              linkStyle: TextStyle(
                                                  color: ColorValues
                                                      .HEADING_COLOR_EDUCATION_1,
                                                  fontFamily:
                                                      Constant.latoRegular,
                                                  fontSize: 14.0,
                                                  fontWeight: FontWeight.w400),
                                            ),
                                          ))
                                  : Container(
                                      child: Linkify(
                                        onOpen: (link) async {
                                          apiCallingForIncreaseCount(
                                              userPostModal.feedId);
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .push(new MaterialPageRoute(
                                                  fullscreenDialog: true,
                                                  builder:
                                                      (BuildContext context) =>
                                                          WebViewWidget(
                                                              link.url,
                                                              "spikeview")));
                                        },
                                        text: userPostModal.postdata.text,
                                        style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400),
                                        linkStyle: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION_1,
                                            fontFamily: Constant.latoRegular,
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400),
                                      ),
                                    ),
                        ),
                      ],
                    ),
                  ),
                ),

          ///Don't remove it
          // isUserRepoted
          //     ? ACCESS_CONTROL_FEED
          //     ? PaddingWrap.paddingAll(
          //     0.0,
          //     Column(
          //       crossAxisAlignment: CrossAxisAlignment.start,
          //       mainAxisAlignment: MainAxisAlignment.start,
          //       children: <Widget>[
          //         // Comment List view
          //         Padding(
          //             padding: EdgeInsets.fromLTRB(
          //                 10.0, 12.0, 10.0, 0.0),
          //             child: Column(
          //                 crossAxisAlignment:
          //                 CrossAxisAlignment.start,
          //                 children: List.generate(
          //                     userPostModal.commentList.length >
          //                         3
          //                         ? 3
          //                         : userPostModal.commentList
          //                         .length, (int index) {
          //                   return PaddingWrap.paddingfromLTRB(
          //                       10.0,
          //                       5.0,
          //                       10.0,
          //                       12.0,
          //                       Row(
          //                         crossAxisAlignment:
          //                         CrossAxisAlignment.start,
          //                         children: <Widget>[
          //                           ProfileImageView(
          //                             imagePath: Constant
          //                                 .IMAGE_PATH_SMALL +
          //                                 userPostModal
          //                                     .commentList[
          //                                 index]
          //                                     .profilePicture,
          //                             placeHolderImage: userPostModal
          //                                 .commentList[
          //                             index]
          //                                 .roleId ==
          //                                 "4"
          //                                 ? "assets/profile/partner_img.png"
          //                                 : 'assets/profile/user_on_user.png',
          //                             width: 40.0,
          //                             height: 40.0,
          //                             onTap: () async {
          //                               onTapImageTile(
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .commentedBy,
          //                                   userPostModal
          //                                       .commentList[
          //                                   index]
          //                                       .roleId);
          //                             },
          //                           ),
          //
          //
          //                           // User Image
          //                           SizedBox(
          //                             width: 9.0,
          //                           ),
          //                           Expanded(
          //                             child: Column(
          //                               crossAxisAlignment:
          //                               CrossAxisAlignment
          //                                   .start,
          //                               mainAxisAlignment:
          //                               MainAxisAlignment
          //                                   .start,
          //                               children: <Widget>[
          //                                 Padding(
          //                                   padding:
          //                                   const EdgeInsets
          //                                       .fromLTRB(
          //                                       0, 0, 0, 0),
          //                                   child: Container(
          //                                       child: Row(
          //                                         children: <
          //                                             Widget>[
          //                                           RichText(
          //                                             maxLines: 2,
          //                                             textAlign:
          //                                             TextAlign
          //                                                 .start,
          //                                             text:
          //                                             TextSpan(
          //                                               text: userPostModal
          //                                                   .commentList[
          //                                               index]
          //                                                   .name,
          //                                               style:
          //                                               TextStyle(
          //                                                 color: ColorValues
          //                                                     .HEADING_COLOR_EDUCATION_1,
          //                                                 fontSize:
          //                                                 14.0,
          //                                                 fontWeight:
          //                                                 FontWeight
          //                                                     .bold,
          //                                               ),
          //                                                children: <TextSpan>[
          //                                                   TextSpan(
          //                                                       text: userPostModal
          //                                                           .commentList[
          //                                                               index]
          //                                                           .comment,
          //                                                       style:  TextStyle(
          //                                                           color: ColorValues.HEADING_COLOR_EDUCATION_1,
          //                                                           fontSize:
          //                                                               14.0,
          //                                                           fontWeight:
          //                                                               FontWeight
          //                                                                   .normal,
          //                                                           fontFamily:
          //                                                               Constant.TYPE_CUSTOMREGULAR)),
          //                                                 ],
          //                                             ),
          //                                           ),
          //                                           userPostModal
          //                                               .commentList[index] !=
          //                                               null &&
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .roleId ==
          //                                                   "1"
          //                                           //true
          //                                               ? Util
          //                                               .getStudentBadge12(
          //                                               userPostModal
          //                                                   .commentList[
          //                                               index]
          //                                                   .badge,
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .badgeImage)
          //                                               : Container(
          //                                             height:
          //                                             0.0,
          //                                             width:
          //                                             0.0,
          //                                           ),
          //                                         ],
          //                                       )),
          //                                 ),
          //                                 Container(
          //                                   child: Linkify(
          //                                     onOpen:
          //                                         (link) async {
          //                                       Navigator.of(
          //                                           context,
          //                                           rootNavigator:
          //                                           true)
          //                                           .push(
          //                                           new MaterialPageRoute(
          //                                               fullscreenDialog:
          //                                               true,
          //                                               builder: (
          //                                                   BuildContext context) =>
          //                                                   WebViewWidget(
          //                                                       link.url,
          //                                                       "spikeview")));
          //                                     },
          //                                     text: userPostModal
          //                                         .commentList[
          //                                     index]
          //                                         .comment,
          //                                     style: TextStyle(
          //                                         color: ColorValues
          //                                             .HEADING_COLOR_EDUCATION_1,
          //                                         fontSize:
          //                                         14.0,
          //                                         fontWeight:
          //                                         FontWeight
          //                                             .normal,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR),
          //                                     linkStyle: TextStyle(
          //                                         color: ColorValues
          //                                             .BLUE_COLOR_BOTTOMBAR,
          //                                         fontFamily:
          //                                         Constant
          //                                             .TYPE_CUSTOMREGULAR,
          //                                         fontSize:
          //                                         14.0),
          //                                   ),
          //                                 ),
          //                                 Padding(
          //                                     padding:
          //                                     EdgeInsets
          //                                         .fromLTRB(
          //                                         0.0,
          //                                         5.0,
          //                                         0.0,
          //                                         0.0),
          //                                     child: Row(
          //                                       mainAxisAlignment:
          //                                       MainAxisAlignment
          //                                           .start,
          //                                       crossAxisAlignment:
          //                                       CrossAxisAlignment
          //                                           .center,
          //                                       children: <
          //                                           Widget>[
          //                                         Expanded(
          //                                           child: Row(
          //                                             mainAxisAlignment:
          //                                             MainAxisAlignment
          //                                                 .start,
          //                                             crossAxisAlignment:
          //                                             CrossAxisAlignment
          //                                                 .start,
          //                                             children: <
          //                                                 Widget>[
          //                                               Text(
          //                                                 userPostModal
          //                                                     .commentList[index]
          //                                                     .dateTime,
          //                                                 textAlign:
          //                                                 TextAlign.end,
          //                                                 style: TextStyle(
          //                                                     color: ColorValues
          //                                                         .GREY_TEXT_COLOR,
          //                                                     fontSize: 12.0,
          //                                                     fontFamily: Constant
          //                                                         .customRegular),
          //                                               )
          //                                             ],
          //                                           ),
          //                                           flex: 0,
          //                                         ),
          //                                         Container(
          //                                           width: 10.0,
          //                                         ),
          //                                         Expanded(
          //                                           child: userIdPref ==
          //                                               userPostModal
          //                                                   .commentList[index]
          //                                                   .commentedBy //&&//
          //                                           // userPostModal.commentList[index].isComment
          //                                               ? InkWell(
          //                                             child:
          //                                             Padding(
          //                                               padding: const EdgeInsets
          //                                                   .fromLTRB(
          //                                                   0.0, 0, 0, 0),
          //                                               child: Image
          //                                                   .asset(
          //                                                 "assets/feed/three_dot_blue.png",
          //                                                 width: 15.0,
          //                                                 height: 15.0,
          //                                               ),
          //                                             ),
          //                                             onTap:
          //                                                 () {
          //                                               optionForDelete(
          //                                                   userPostModal
          //                                                       .commentList,
          //                                                   userPostModal
          //                                                       .feedId,
          //                                                   userPostModal,
          //                                                   userPostModal
          //                                                       .commentList[index]
          //                                                       .commentId,
          //                                                   index);
          //                                             },
          //                                           )
          //                                               : Container(
          //                                             height:
          //                                             1.0,
          //                                           ),
          //                                           flex: 0,
          //                                         )
          //                                       ],
          //                                     )),
          //                               ],
          //                             ),
          //                             flex: 1,
          //                           ) // Comment List Cell
          //                         ],
          //                       ));
          //                 }))),
          //
          //         // View All Comments
          //         userPostModal.commentList.length > 3
          //             ? InkWell(
          //           child: PaddingWrap.paddingfromLTRB(
          //             10.0,
          //             0.0,
          //             0.0,
          //             5.0,
          //             TextViewWrap.textView(
          //                 "View All " +
          //                     userPostModal
          //                         .commentList.length
          //                         .toString() +
          //                     " Comments",
          //                 TextAlign.left,
          //                 ColorValues.labelColor,
          //                 12.0,
          //                 FontWeight.w500),
          //           ),
          //           onTap: () {
          //             onTapViewAllComments(
          //                 userPostModal.commentList,
          //                 userPostModal.feedId,
          //                 userPostModal);
          //           },
          //         )
          //             : Container(
          //           height: 0.0,
          //         ),
          //
          //         // Comment Edit Text
          //         userPostModal.isShowCommentIcon
          //             ? PaddingWrap.paddingAll(
          //             10.0,
          //             Row(
          //               children: <Widget>[
          //                 //Alok Code Done
          //                 ProfileImageView(
          //                   imagePath: roleId == "4"
          //                       ? Constant.IMAGE_PATH +
          //                       companyPath
          //                       : Constant.IMAGE_PATH +
          //                       profilePath,
          //                   placeHolderImage: roleId == "4"
          //                       ? "assets/profile/partner_img.png"
          //                       : 'assets/profile/user_on_user.png',
          //                   width: 40.0,
          //                   height: 40.0,
          //                   onTap: () async {
          //
          //                   },
          //                 ),
          //
          //
          //                 SizedBox(
          //                   width: 9.0,
          //                 ),
          //                 Expanded(
          //                     child: Container(
          //                         decoration: BoxDecoration(
          //                             border: Border.all(
          //                                 width: 1.0,
          //                                 color: ColorValues
          //                                     .LIGHT_GREY_TEXT_COLOR)),
          //                         child: Row(
          //                           crossAxisAlignment:
          //                           CrossAxisAlignment
          //                               .center,
          //                           mainAxisAlignment:
          //                           MainAxisAlignment
          //                               .center,
          //                           children: <Widget>[
          //                             Expanded(
          //                               child: TextField(
          //                                 controller:
          //                                 userPostModal
          //                                     .txtController,
          //                                 style: TextStyle(
          //                                     fontFamily:
          //                                     Constant
          //                                         .TYPE_CUSTOMREGULAR),
          //                                 keyboardType:
          //                                 TextInputType
          //                                     .text,
          //                                 textCapitalization:
          //                                 TextCapitalization
          //                                     .sentences,
          //                                 maxLines: null,
          //                                 maxLength: TextLength
          //                                     .COMMENT_MAX_LENGTH,
          //                                 onChanged: (s) {
          //                                   if (s
          //                                       .trim()
          //                                       .length >
          //                                       0) {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     true;
          //                                   } else {
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                   }
          //                                   setState(() {
          //                                     userPostModal
          //                                         .isCommentIconVisible;
          //                                   });
          //                                 },
          //                                 decoration:
          //                                 InputDecoration(
          //                                   border:
          //                                   InputBorder
          //                                       .none,
          //                                   filled: true,
          //                                   counterText: "",
          //                                   counterStyle: TextStyle(
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   hintText: roleId ==
          //                                       "4"
          //                                       ? "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference
          //                                               .COMPANY_NAME_PATH)
          //                                       : "Add Comment as " +
          //                                       prefs.getString(
          //                                           UserPreference.NAME)
          //                                           .replaceAll(
          //                                           "null",
          //                                           ""),
          //                                   hintStyle: TextStyle(
          //                                       color: ColorValues
          //                                           .GREY_TEXT_COLOR,
          //                                       fontSize:
          //                                       14.0,
          //                                       fontFamily:
          //                                       Constant
          //                                           .TYPE_CUSTOMREGULAR),
          //                                   fillColor: Colors
          //                                       .transparent,
          //                                 ),
          //                               ),
          //                               flex: 4,
          //                             ),
          //                             Expanded(
          //                               child:
          //                               userPostModal
          //                                         .isCommentIconVisible
          //                                     ?
          //                               InkWell(
          //                                 child: PaddingWrap
          //                                     .paddingfromLTRB(
          //                                     0.0,
          //                                     0.0,
          //                                     5.0,
          //                                     0.0,
          //                                     Image
          //                                         .asset(
          //                                       "assets/feed/sent_icon.png",
          //                                       width:
          //                                       22.0,
          //                                       height:
          //                                       22.0,
          //                                     )),
          //                                 onTap: () {
          //                                   if (userPostModal
          //                                       .isCommentIconVisible) {
          //                                     FocusScope.of(
          //                                         context)
          //                                         .requestFocus(
          //                                         FocusNode());
          //                                     userPostModal
          //                                         .isCommentIconVisible =
          //                                     false;
          //                                     onAddComment(
          //                                         userPostModal
          //                                             .feedId,
          //                                         userPostModal
          //                                             .txtController
          //                                             .text,
          //                                         userPostModal);
          //                                     userPostModal
          //                                         .txtController
          //                                         .text = "";
          //                                     setState(() {
          //                                       userPostModal
          //                                           .txtController;
          //                                       userPostModal
          //                                           .isCommentIconVisible;
          //                                     });
          //                                   }
          //                                 },
          //                               )
          //                               :  Container(
          //                                         height: 0.0,
          //                                       )
          //                               ,
          //                               flex: 0,
          //                             )
          //                           ],
          //                         )),
          //                     flex: 1)
          //               ],
          //             ))
          //             : Container(
          //           height: 0.0,
          //         ),
          //
          //         (userPostList.length - 1) == index
          //             ? Container(
          //           height: 10.0,
          //         )
          //             : Container(
          //           height: 10.0,
          //         ),
          //         Container(
          //           height: 20.0,
          //         )
          //         // PaddingWrap.paddingfromLTRB(
          //         //     0.0,
          //         //     10.0,
          //         //     0.0,
          //         //     10.0,
          //         //     Divider(
          //         //       color:
          //         //           ColorValues.GREY_TEXT_COLOR,
          //         //       height: 1.0,
          //         //     ))
          //       ],
          //     ))
          //     : const SizedBox.shrink()
          //     : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Padding getFeedUi(feedType, bool ACCESS_CONTROL_GROUP) {
    return PaddingWrap.paddingfromLTRB(
      0.0,
      3.0,
      0.0,
      0.0,
      Column(
        children: <Widget>[
          userPostList.length > 0
              ? ListView.builder(
                  shrinkWrap: true,
                  controller: _scrollController2,
                  scrollDirection: Axis.vertical,
                  itemCount: userPostList.length,
                  padding: EdgeInsets.all(0.0),
                  itemBuilder: (BuildContext context, int position) {
                    if (userPostList[position].isOpportunity) {
                      print('Apurva 1111 Oppo');
                      if (userPostList[position].postOwner == "null") {
                        print('Apurva 1111');
                        return getListViewForOpportunity(
                            userPostList[position], position, isUserRepoted);
                      } else {
                        print('Apurva 2222');
                        return getListViewPostForOpportuntiy(
                            userPostList[position], position, isUserRepoted);
                      }
                    } else {
                      print('userPostList[position].postOwner +++' +
                          userPostList[position].postOwner);
                      if (userPostList[position].postOwner == "null" ||
                          userPostList[position].postOwner == "0") {
                        print('Apurva 3333');
                        return getListView(
                            userPostList[position], position, isUserRepoted);
                      } else {
                        print('Apurva 4444');
                        return getListViewPost(
                            userPostList[position], position, isUserRepoted);
                      }
                    }
                  },
                )
              : isLoading
                  ? SizedBox()
                  : Center(
                      child: PaddingWrap.paddingfromLTRB(
                          10.0,
                          5.0,
                          10.0,
                          30.0,
                          Container(
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  /* PaddingWrap.paddingfromLTRB(
                                      0.0,
                                      18.0,
                                      0.0,
                                      0.0,
                                      Image.asset(
                                        "assets/not_joined.png",
                                        width: 300.0,
                                        height: 151.0,
                                      )),*/
                                  groupList[0].status ==
                                          MessageConstant.ABOUT_GROUP_ACCEPTED
                                      ? Container(height: 0)
                                      : groupList[0].type ==
                                              MessageConstant
                                                  .ABOUT_GROUP_PRIVATE
                                          ? PaddingWrap.paddingfromLTRB(
                                              0.0,
                                              15.0,
                                              0.0,
                                              5.0,
                                              TextViewWrap.textViewMultiLine(
                                                  MessageConstant
                                                      .ABOUT_GROUP_JOIN_GROUP_CHECK_FEED,
                                                  TextAlign.center,
                                                  ColorValues.GREY_TEXT_COLOR,
                                                  16.0,
                                                  FontWeight.bold,
                                                  2))
                                          : SizedBox(),
                                  PaddingWrap.paddingfromLTRB(
                                      13.0,
                                      80.0,
                                      13.0,
                                      21.0,
                                      TextViewWrap.textViewMultiLine(
                                          groupList[0].status ==
                                                  MessageConstant
                                                      .ABOUT_GROUP_ACCEPTED
                                              ? MessageConstant
                                                  .ABOUT_GROUP_SHARING_KNOWLEDGE
                                              : groupList[0].type ==
                                                      MessageConstant
                                                          .ABOUT_GROUP_PRIVATE
                                                  ? MessageConstant
                                                      .ABOUT_GROUP_JOIN_THE_GROUP
                                                  : '',
                                          TextAlign.center,
                                          AppConstants.colorStyle.lightPurple,
                                          14.0,
                                          FontWeight.normal,
                                          8)),
                                ],
                              ))))
        ],
      ),
    );
  }

  Container getPrivateRequest() {
    return Container(
      padding: EdgeInsets.fromLTRB(20.0, 0.0, 20.0, 30.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          /* Padding(
            padding: const EdgeInsets.only(top:20.0),
            child: BaseText(
              text: 'Group rules',
              textColor: ColorValues.labelColor,
              fontFamily:
              AppConstants.stringConstant.latoRegular,
              fontWeight: FontWeight.w500,
              fontSize: 14,
              textAlign: TextAlign.start,
              maxLines: 3,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top:3.0),
            child: Row(
              children: [
                Expanded(child:Padding(
                    padding: const EdgeInsets.only(left:5.0,top: 3),
                    child: Container(
                      decoration: new BoxDecoration(
                          color: Color(0xff3D4361),
                          borderRadius: new BorderRadius.all(Radius.circular(10)
                          )
                      ),
                      height: 8,width:8,)) ,flex: 0,),
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(left:7.0),
                  child: BaseText(
                    text: 'Growing the group towards its purpose.',
                    textColor: ColorValues.TEXT_COLOR,
                    fontFamily:
                    AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    textAlign: TextAlign.start,
                    maxLines: 3,
                  ),
                ) ,flex: 1,),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top:3.0),
            child: Row(
              children: [
                Expanded(child:Padding(
                    padding: const EdgeInsets.only(left:5.0,top: 3),
                    child: Container(
                      decoration: new BoxDecoration(
                          color: Color(0xff3D4361),
                          borderRadius: new BorderRadius.all(Radius.circular(10)
                          )
                      ),
                      height: 8,width:8,)) ,flex: 0,),
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(left:7.0),
                  child: BaseText(
                    text: 'Keeping the group spam-free.',
                    textColor: ColorValues.TEXT_COLOR,
                    fontFamily:
                    AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    textAlign: TextAlign.start,
                    maxLines: 3,
                  ),
                ) ,flex: 1,),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top:3.0),
            child: Row(
              children: [
                Expanded(child:Padding(
                    padding: const EdgeInsets.only(left:5.0,top: 3),
                    child: Container(
                      decoration: new BoxDecoration(
                          color: Color(0xff3D4361),
                          borderRadius: new BorderRadius.all(Radius.circular(10)
                          )
                      ),
                      height: 8,width:8,)) ,flex: 0,),
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(left:7.0),
                  child: BaseText(
                    text: 'Acquainting members with Dos and Don’ts.',
                    textColor: ColorValues.TEXT_COLOR,
                    fontFamily:
                    AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    textAlign: TextAlign.start,
                    maxLines: 3,
                  ),
                ) ,flex: 1,),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top:3.0),
            child: Row(
              children: [
                Expanded(child:Padding(
                    padding: const EdgeInsets.only(left:5.0,top: 3),
                    child: Container(
                      decoration: new BoxDecoration(
                          color: Color(0xff3D4361),
                          borderRadius: new BorderRadius.all(Radius.circular(10)
                          )
                      ),
                      height: 8,width:8,)) ,flex: 0,),
                Expanded(child: Padding(
                  padding: const EdgeInsets.only(left:7.0),
                  child: BaseText(
                    text: 'Be Kind and Courteous.',
                    textColor: ColorValues.TEXT_COLOR,
                    fontFamily:
                    AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 16,
                    textAlign: TextAlign.start,
                    maxLines: 3,
                  ),
                ) ,flex: 1,),
              ],
            ),
          ),*/
        ],
      ),
    );
  }

  onBack() async {
    print("widget.page++" + widget.page);
    print("widget.page++" + widget.page);
    if (widget.page == "signup") {
      StudentOnBoarding()
          .getStudentOnBoardingInit(context, null, sasToken, userIdPref);
    } else if (widget.page == "login") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);
      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        StudentOnBoarding().getStudentOnBoardingInit(
            context, profileInfoModal, sasToken, userIdPref);
      }
    } else if (widget.page == "Notification") {
      if (roleId == "1") {
        // For Studenet
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidget(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.GROUP_TYPE,
                      userId: userIdPref,
                    )));
      } else if (roleId == "2") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidgetParent(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.GROUP_TYPE,
                      userId: userIdPref,
                    )));
        // For Parent
      } else if (roleId == "4") {
        Navigator.of(Constant.applicationContext)
            .popUntil((route) => route.isFirst);
        Navigator.pushReplacement(
            Constant.applicationContext,
            MaterialPageRoute(
                //   builder: (context) =>  DashBoardWidget()));
                builder: (context) => DashBoardWidgetPartner(
                      prefs.getString(UserPreference.IS_PARENT_ROLE),
                      prefs.getString(UserPreference.IS_PARTNER_ROLE),
                      prefs.getString(UserPreference.IS_USER_ROLE),
                      currentPage: Constant.GROUP_TYPE,
                      userId: userIdPref,
                    )));

        // For Partner
      }
    } else {
      Navigator.pop(context, status);
      if (widget.page == MessageConstant.ABOUT_GROUP_INVITED)
        syncDoneController.add("");
    }
  }

  getView() {
    return Container(
      width: double.infinity,
      decoration: isTitleVisible
          ? BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(
                  width: 1.0,
                  color: ColorValues.DEVIDER_COLOR,
                ),
              ),
            )
          : const BoxDecoration(color: Colors.transparent),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 20.0, top: 20, left: 20,right: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () {
                onBack();
              },
              child: Image.asset(
                "assets/new_onboarding/back_blue_icon.png",
                height: 32.0,
                width: 32.0,
              ),
            ),
            const HelpButtonWidget(),
          ],
        ),
      ),
    );
  }

  Future apiCallForDelete(groupId) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "groupId": groupId,
          "status": "Rejected",
          "roleId": int.parse(roleId),
          "isAdmin": true,
          "userId": int.parse(userIdPref),
        };

        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_DELETE_GROUP_MEMBER, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg, context);

              if (mounted) {
                status = 'push';
                syncDoneController.add("");
                apiCallForGet();
              }
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "GroupRequestSentWidget", context);
      e.toString();
    }
  }

  void showConfirmationAlert(groupId) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: 'Are you sure you want to withdraw?',
            negativeText: 'Cancel',
            positiveText: 'Withdraw',
            isSucessPopup: false,
            positiveTextColor: AppConstants.colorStyle.btn_text_red,
            onNegativeTap: () {},
            onPositiveTap: () {
              apiCallForDelete(groupId);
            },
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    this.context = context;

    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: Scaffold(
          bottomNavigationBar: groupList != null &&
                  groupList.length > 0 &&
                  groupList[0].status == "Requested"
              ? InkWell(
                  child: PaddingWrap.paddingfromLTRB(
                      20.0,
                      20.0,
                      20.0,
                      20.0,
                      Container(
                          height: 44,
                          decoration: BoxDecoration(
                            color: AppConstants.colorStyle.lightBlue,
                            border: Border.all(
                                color: AppConstants.colorStyle.lightBlue),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Align(
                              alignment: Alignment.center,
                              // Align however you like (i.e .centerRight, centerLeft)
                              child: Text(
                                "Withdraw",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: ColorValues.WHITE,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontSize: 18.0,
                                ),
                              )))),
                  onTap: () async {
                    showConfirmationAlert(groupList[0].groupId);
                  },
                )
              : groupList != null &&
                      groupList.length > 0 &&
                      groupList[0].status !=
                          MessageConstant.ABOUT_GROUP_ACCEPTED &&
                      groupList[0].status != MessageConstant.ABOUT_GROUP_INVITED
                  ? InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                          20.0,
                          20.0,
                          20.0,
                          20.0,
                          Container(
                              height: 44,
                              decoration: BoxDecoration(
                                color: AppConstants.colorStyle.lightBlue,
                                border: Border.all(
                                    color: AppConstants.colorStyle.lightBlue),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Align(
                                  alignment: Alignment.center,
                                  // Align however you like (i.e .centerRight, centerLeft)
                                  child: Text(
                                    groupList[0].type ==
                                            MessageConstant.ABOUT_GROUP_PRIVATE
                                        ? "Accept"
                                        : "Join",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: ColorValues.WHITE,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontSize: 18.0,
                                    ),
                                  )))),
                      onTap: () async {
                        if (!(groupList[0].status ==
                            MessageConstant.ABOUT_GROUP_REQUESTED)) {
                          apiCallJoin();
                        }
                      },
                    )
                  : groupList.length > 0 &&
                          (groupList != null &&
                              groupList[0] != null &&
                              groupList[0].status == "Invited")
                      ? (13 > diffrenceInDob && groupList[0].adminRoleId == "4")
                          ? SizedBox()
                          : Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: PaddingWrap.paddingfromLTRB(
                                      20.0,
                                      20.0,
                                      0.0,
                                      20.0,
                                      InkWell(
                                        onTap: () {
                                          apiCallingForAccept(
                                              groupList[0].groupId,
                                              0,
                                              "Rejected");
                                        },
                                        child: Container(
                                            height: 44,
                                            decoration: BoxDecoration(
                                              color: ColorValues.WHITE,
                                              border: Border.all(
                                                  color: Color(0xffB2BDDB)),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Align(
                                                alignment: Alignment.center,
                                                // Align however you like (i.e .centerRight, centerLeft)
                                                child: Text(
                                                  'Reject',
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: AppConstants
                                                        .colorStyle.lightPurple,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoRegular,
                                                    fontSize: 18,
                                                  ),
                                                ))),
                                      )),
                                ),
                                Expanded(
                                  flex: 3,
                                  child: PaddingWrap.paddingfromLTRB(
                                      12.0,
                                      20.0,
                                      20.0,
                                      20.0,
                                      InkWell(
                                        onTap: () {
                                          apiCallingForAccept(
                                              groupList[0].groupId,
                                              0,
                                              "Accepted");
                                        },
                                        child: Container(
                                            height: 44,
                                            decoration: BoxDecoration(
                                              color: AppConstants
                                                  .colorStyle.lightBlue,
                                              border: Border.all(
                                                  color: AppConstants
                                                      .colorStyle.lightBlue),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Align(
                                                alignment: Alignment.center,
                                                // Align however you like (i.e .centerRight, centerLeft)
                                                child: Text(
                                                  'Accept',
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: ColorValues.WHITE,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoMedium,
                                                    fontSize: 18.0,
                                                  ),
                                                ))),
                                      )),
                                ),
                              ],
                            )
                      : SizedBox(),
          backgroundColor: Colors.white,

          /*  floatingActionButton: groupList.isNotEmpty
              && groupList[0].status == MessageConstant.ABOUT_GROUP_ACCEPTED
          ?FloatingActionButton(
              elevation: 0.0,

              child: Image.asset("assets/png/post1.png",
                width: 56.0,
                height: 56.0,
              ),
              onPressed: () async {
                onTapAddPost(
                    groupList[0].groupId,
                    groupList[0]);
              })
              : const SizedBox.shrink(),*/
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Positioned(
                    left: 0.0,
                    right: 0.0,
                    top: 0.0,
                    bottom: 0.0,
                    child: ListView(
                      controller: _scrollController,
                      shrinkWrap: true,
                      children: <Widget>[
                        SizedBox(
                          height: 80,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 5.0),
                          child: SizedBox(
                            height: 78.0,
                            width: 78.0,
                            child: Center(
                              child: Container(
                                height: 78.0,
                                width: 78.0,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    border: Border.all(
                                        color: Colors.white, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        spreadRadius: 3,
                                        blurRadius: 3,
                                        offset: Offset(0, 3),
                                        color:
                                            Color.fromRGBO(98, 175, 226, 0.09),
                                      )
                                    ]),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(15.0),
                                    child: FadeInImage(
                                      height: 78.0,
                                      width: 78.0,
                                      fit: BoxFit.cover,
                                      placeholder: AssetImage(
                                        'assets/newDesignIcon/group/default_circle_bg.png',
                                      ),
                                      image: NetworkImage(groupList.length > 0
                                          ? Constant.IMAGE_PATH_SMALL +
                                              groupList[0].groupImage
                                          : ""),
                                    )),
                              ),
                            ),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 20.0, right: 20, top: 20),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Flexible(
                                    child: BaseText(
                                      text: groupList.length > 0
                                          ? groupList[0].groupName + "  "
                                          : "",
                                      textColor:
                                          ColorValues.HEADING_COLOR_EDUCATION_1,
                                      fontFamily: AppConstants
                                          .stringConstant.latoMedium,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 18,
                                      textAlign: TextAlign.center,
                                      maxLines: 3,
                                    ),
                                  ),
                                  Expanded(
                                    child: groupList.length > 0 &&
                                            groupList[0].isAdmin
                                        ? Padding(
                                            padding: const EdgeInsets.only(
                                                left: 5.0, top: 4),
                                            child: Container(
                                                height: 18.0,
                                                width: 45,
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                  color: ColorValues
                                                      .TAB_BACKGROUND_COLOR,
                                                  borderRadius:
                                                      BorderRadius.circular(15),
                                                ),
                                                child: Padding(
                                                  padding: EdgeInsets.fromLTRB(
                                                      0.0, 0.0, 0.0, 2.0),
                                                  child: BaseText(
                                                    text: 'Owner',
                                                    textColor: AppConstants
                                                        .colorStyle.lightPurple,
                                                    fontFamily: AppConstants
                                                        .stringConstant
                                                        .latoRegular,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 12,
                                                    textAlign: TextAlign.start,
                                                    maxLines: 3,
                                                  ),
                                                )),
                                          )
                                        : SizedBox(),
                                    flex: 0,
                                  )
                                ],
                              ),
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(top: 5.0),
                                  child: Image.asset(
                                    groupList.length > 0
                                        ? groupList[0].type ==
                                                MessageConstant
                                                    .ABOUT_GROUP_PRIVATE
                                            ? "assets/png/private_group.png"
                                            : "assets/png/public_group.png"
                                        : "assets/png/public_group.png",
                                    height: 15.0,
                                    width: 15.0,
                                    color: AppConstants.colorStyle.lightPurple,
                                  ),
                                ),
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    5.0,
                                    0.0,
                                    0.0,
                                    BaseText(
                                      text: groupList.length > 0
                                          ? groupList[0].type ==
                                                  MessageConstant
                                                      .ABOUT_GROUP_PRIVATE
                                              ? MessageConstant
                                                  .ABOUT_GROUP_PRIVATE_GROUP
                                              : MessageConstant
                                                  .ABOUT_GROUP_PUBLIC_GROUP
                                          : "",
                                      textColor:
                                          AppConstants.colorStyle.lightGrey,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    )),
                                /* groupList.length > 0 &&
                                            ((groupList[0].type ==
                                                MessageConstant
                                                    .ABOUT_GROUP_PRIVATE &&
                                                groupList[0]
                                                    .status ==
                                                    MessageConstant
                                                        .ABOUT_GROUP_ACCEPTED) ||
                                                groupList[0].type == 'public')
                                            ?*/
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8.0, right: 8, top: 7),
                                  child: Container(
                                    height: 12,
                                    color: AppConstants.colorStyle.lightGrey,
                                    width: 1,
                                  ),
                                )
                                /* : SizedBox()*/,
                                InkWell(
                                  onTap: () {
                                    if (groupList.length > 0 &&
                                        ((groupList[0].type ==
                                                    MessageConstant
                                                        .ABOUT_GROUP_PRIVATE &&
                                                groupList[0].status ==
                                                    MessageConstant
                                                        .ABOUT_GROUP_ACCEPTED) ||
                                            groupList[0].type == 'public')) {
                                      onTapMemberDetail(groupList[0]);
                                    }
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 5.0),
                                    child: BaseText(
                                      text: groupList.length > 0
                                          ? groupList[0]
                                                  .memberList
                                                  .length
                                                  .toString() +
                                              ' Member(s)'
                                          : '',
                                      textColor:
                                          AppConstants.colorStyle.lightBlue,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                      textAlign: TextAlign.start,
                                      maxLines: 3,
                                    ),
                                  ),
                                )
                                /*    : SizedBox()*/
                              ],
                            )
                          ],
                        ),

                        //   headerUiDesign(),
                        groupList.length > 0
                            ? Column(
                                children: <Widget>[
                                  getHeaderUi(),
                                  groupList[0].type == "public" ||
                                          widget.page == "groupBoat"
                                      ? getFeedUi(
                                          groupList[0].status ==
                                                  MessageConstant
                                                      .ABOUT_GROUP_ACCEPTED
                                              ? true
                                              : false,
                                          ACCESS_CONTROL_GROUP)
                                      : groupList[0].status ==
                                              MessageConstant
                                                  .ABOUT_GROUP_ACCEPTED
                                          ? getFeedUi(
                                              true, ACCESS_CONTROL_GROUP)
                                          : getPrivateRequest()
                                ],
                              )
                            : Container(
                                height: 0.0,
                              )
                      ],
                    )),
                Positioned(
                    left: 0.0,
                    right: 0.0,
                    top: 0.0,
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 200),
                      child: getView(),
                    )),
                groupList.isNotEmpty &&
                        groupList[0].status ==
                            MessageConstant.ABOUT_GROUP_ACCEPTED
                    ? Positioned(
                        left: position.dx,
                        top: position.dy,
                        child: Draggable(
                          feedback: isUserRepoted
                              ? FloatingActionButton(
                                  elevation: 0.0,
                                  backgroundColor:
                                      ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                  child: Container(
                                    width: 56.0,
                                    height: 56.0,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(35),
                                        border: Border.all(
                                            color: Colors.white, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            blurRadius: 15,
                                            offset: Offset(2, 2),
                                            color:
                                                Color.fromRGBO(0, 0, 0, 0.15),
                                          )
                                        ]),
                                    child: Image.asset(
                                      "assets/png/post1.png",
                                      width: 56.0,
                                      height: 56.0,
                                    ),
                                  ),
                                  onPressed: () {
                                    if (isFeed_AccessControl) {
                                      onTapAddPost(
                                          groupList[0].groupId,
                                          groupList[0]);
                                    } else {
                                      ToastWrap.showToastForAccessDenied(
                                          MessageConstant
                                              .FEATURE_DIABLED,
                                          context);
                                    }
                                  })
                              : const SizedBox.shrink(),
                          child: isUserRepoted
                              ? FloatingActionButton(
                                  elevation: 0.0,
                                  backgroundColor:
                                      ColorValues.BOTTOAMBAR_ADD_BG_COLOUR,
                                  child: Image.asset(
                                    "assets/png/post.png",
                                    width: 56.0,
                                    height: 56.0,
                                  ),
                                  onPressed: () {
                                    if (isFeed_AccessControl) {
                                      onTapAddPost(
                                          groupList[0].groupId,
                                          groupList[0]);
                                    } else {
                                      ToastWrap.showToastForAccessDenied(
                                          MessageConstant
                                              .FEATURE_DIABLED,
                                          context);
                                    }
                                  })
                              : const SizedBox.shrink(),
                          childWhenDragging: const SizedBox.shrink(),
                          onDragEnd: (details) {
                            if (details.offset.dy > 50.0 &&
                                details.offset.dy <
                                    (MediaQuery.of(context).size.height) -
                                        80.0) {
                              setState(() {
                                position = Offset(
                                    ((MediaQuery.of(context).size.width) -
                                        60.0),
                                    details.offset.dy);
                              });
                            }
                          },
                        ),
                      )
                    : Positioned(
                        left: 0,
                        top: 0,
                        child: SizedBox(
                          height: 0,
                        )),
              ],
            ),
          ),
        ));
  }
}
