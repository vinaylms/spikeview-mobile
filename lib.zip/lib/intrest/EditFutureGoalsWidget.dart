import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/base_common_widget.dart';
import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/education/model/UniversityModel.dart';
import 'package:spike_view_project/main.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';

import 'package:spike_view_project/profile/studentWizard/SkillSelectionWiget.dart';
import 'package:spike_view_project/profile_bloc_pattern/blocs/profile_bloc.dart';
import 'package:spike_view_project/skill/model/SkillIntrestDataModel.dart';
import 'package:spike_view_project/skill/model/SkillModel.dart';
import 'package:spike_view_project/values/ColorValues.dart';
//import 'package:spike_view_project/modal/SavedInterestListModel.dart';

// Create a Form Widget
class EditFutureGoalsWidget extends StatefulWidget {
  SkillIntrestDataModel _mSkillModel;
  bool isFirstTimeCalling;
  ProfileInfoModal profileInfoModal;

  EditFutureGoalsWidget(
      this._mSkillModel, this.isFirstTimeCalling, this.profileInfoModal);

  @override
  EditFutureGoalsWidgetState createState() {
    return  EditFutureGoalsWidgetState();
  }
}

class EditFutureGoalsWidgetState extends State<EditFutureGoalsWidget>
    with BaseCommonWidget {
  final _formKey = GlobalKey<FormState>();
  SharedPreferences prefs;
  String userIdPref, token;

  SkillModel _skillModel =  SkillModel();

  List<SkillData> selectedLoveInterestsList =  List<SkillData>();

  String strInstitute = '';
  int optionCount = 0;

  TextEditingController instituteController =
       TextEditingController(text: "");
  String popString = '';

  final FocusNode _otherInterestFocus = FocusNode();

  Color bottomViewColor = Palette.dividerColor;

  bool showList = false;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();

  bool isNeedCounselorYes = false;
  bool isNeedCounselorNo = false;

  bool isNotShare = false;
  bool isNo = false;
  bool isYes = false;

  TextEditingController _textFieldController =
       TextEditingController(text: "");
  final FocusNode _textFieldFocus = FocusNode();

  List<SkillData> _searchedUniversityList =  List<SkillData>();

  List<String> selectedUniversityOption = [];

  List<SkillData> _universityList =  List();

  List<SkillData> removedUniversiyList =  List<SkillData>();
  List<SkillData> origanalUniversiyList =  List<SkillData>();
  ScrollController controller;
  int listIndexFrom = 0;

  //List<SkillData> removedUniversiyList=new List<SkillData>();
//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = widget.profileInfoModal.userId;
    token = prefs.getString(UserPreference.USER_TOKEN);
    print('inside getSharedPreferences() EditInterest');
    setState(() {
      if (widget._mSkillModel != null) {
        if (widget._mSkillModel.result[0].goalInterestInstitute != null &&
            widget._mSkillModel.result[0].goalInterestInstitute != "" &&
            widget._mSkillModel.result[0].goalInterestInstitute != "null") {
          instituteController.text =
              widget._mSkillModel.result[0].goalInterestInstitute;
          strInstitute = widget._mSkillModel.result[0].goalInterestInstitute;
        }

        //to init needCounselor
        if (widget._mSkillModel.result[0].needCounselor != null) {
          isNeedCounselorYes = false;
          isNeedCounselorNo = false;
          if (widget._mSkillModel.result[0].needCounselor) {
            isNeedCounselorYes = true;
          } else {
            isNeedCounselorNo = true;
          }
        }

        //to init financialSupport
        if (widget._mSkillModel.result[0].financialSupport != null) {
          //isYes ? "Yes" : isNo ? "No" : "Notshare" ,
          isYes = false;
          isNotShare = false;
          isNo = false;
          if (widget._mSkillModel.result[0].financialSupport == 'Yes')
            isYes = true;
          else if (widget._mSkillModel.result[0].financialSupport == 'No')
            isNo = true;
          else if (widget._mSkillModel.result[0].financialSupport == 'Notshare')
            isNotShare = true;
          setState(() {
            isYes;
            isNo;
            isNotShare;
          });
        }
      }
    });
    await callLoveInterestApi();
  }

  void _scrollListener() {
    print(controller.position.extentAfter);
    /*
      var colors = ["red", "green", "blue", "orange", "pink"];
      print(colors.sublist(1, 3)); // [green, blue]
     */
    if (controller.position.extentAfter < 500) {
      print('inside _scrollListener listIndexFrom:: $listIndexFrom');
      if (_textFieldController.text == "") {
        setState(() {
          _searchedUniversityList.addAll(
              _universityList.sublist(listIndexFrom, listIndexFrom + 10));
          listIndexFrom = listIndexFrom + 10;
        });
      }
    }
  }

  //=========================================================Api Calling =======================================

  Future<String> callLoveInterestApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //ReferPointResponse referPointResponse;
        String referPoint = '';
        Response response = await  ApiCalling().apiCall(context,
            Constant.ENDPOINT_GET_HOBBY_TYPE_API + "major_interests", "get");
        print("Love Skill Response" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              _skillModel =  SkillModel.fromJson(response.data);
              print(
                  'setdata _skillModel.skillList 111 size::: ${_skillModel.skillList.length}');

              try {
                _universityList = _skillModel.skillList;
                _searchedUniversityList = _skillModel.skillList;

                for (Skills skills
                    in widget._mSkillModel.result[0].majorInterests) {
                  selectedUniversityOption.add(skills.name);
                }

                if (_universityList != null && _universityList.isNotEmpty) {
                  origanalUniversiyList.addAll(_universityList);
                  for (Skills selectedOption
                      in widget._mSkillModel.result[0].majorInterests) {
                    if (selectedOption.hobbyId != "" &&
                        selectedOption.hobbyId != null &&
                        selectedOption.hobbyId.toString() != 'null') {
                      for (var universityResultModel in origanalUniversiyList) {
                        print(
                            'universityResultModel:::::: ${universityResultModel.name}');
                        if (selectedOption.name.toString() ==
                            universityResultModel.name.toString()) {
                          removedUniversiyList.add(SkillData(
                              //sId: universityResultModel.sId,
                              name: universityResultModel.name,
                              hobbyId: universityResultModel.hobbyId));

                          selectedLoveInterestsList.add(SkillData(
                              name: universityResultModel.name,
                              hobbyId: universityResultModel.hobbyId));
                        }
                      }
                    } else {
                      selectedLoveInterestsList.add(SkillData(
                        name: selectedOption.name.toString(),
                      ));
                    }
                  }
                }

                print(
                    'selectedUniversityOption length:: ${selectedUniversityOption.length}');
                print('_universityList length:: ${_universityList.length}');
                print(
                    'origanalUniversiyList length:: ${origanalUniversiyList.length}');
                print(
                    'removedUniversiyList length:: ${removedUniversiyList.length}');

                //if (removedUniversiyList.length > 0) {
                _universityList.clear();
                //}
                print('_universityList length 111:: ${_universityList.length}');
                for (final e in origanalUniversiyList) {
                  bool found = false;
                  for (final f in removedUniversiyList) {
                    if (e.hobbyId.toString() == f.hobbyId.toString()) {
                      found = true;
                      break;
                    }
                  }
                  if (!found) {
                    _universityList.add(e);
                  }
                }
                print('_universityList length 222:: ${_universityList.length}');
                //add data to re

                setState(() {
                  _universityList;
                  _searchedUniversityList;
                  removedUniversiyList;
                  origanalUniversiyList;
                  selectedUniversityOption;
                  selectedLoveInterestsList;
                });
              } catch (e) {
                crashlytics_bloc.recordCrashlyticsError(e,"EditFutureGoalsWidget",context);
                print(
                    'inside ENDPOINT_universities_list catch error:: ${e.toString()}');
              }
              //}
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
        return '';
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditFutureGoalsWidget",context);
      e.toString();
    }
  }

  //--------------------------Edit Data ------------------

  void conformationDialogForAddIntoProfile() {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) =>  WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child:  SafeArea(
                child:  Scaffold(
                    backgroundColor: Colors.black38,
                    body:  Stack(
                      children: <Widget>[
                         Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child:  Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child:  Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                           Container(
                                            height: 145.0,
                                            padding:  EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child:  Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                   Text(
                                                    "Do you want to publish this interest to your public profile?",
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style:  TextStyle(
                                                        color:  ColorValues.HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily:
                                                            Constant.TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                         Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child:  Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                 Container(
                                    color: Colors.white,
                                    padding:  EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child:  Row(
                                      children: <Widget>[
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "No",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              editInterest(false);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  InkWell(
                                            child:  Container(
                                                child:  Text(
                                              "Yes",
                                              textAlign: TextAlign.center,
                                              style:  TextStyle(
                                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily:Constant.TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              editInterest(true);
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  void _checkValidation() async {
    FocusScope.of(context).requestFocus(new FocusNode());
    final form = _formKey.currentState;

    form.save();
    if (form.validate()) {
      if (widget.isFirstTimeCalling) {
        if (Util.dobCheck(widget.profileInfoModal.dob) &&
            widget.profileInfoModal.publicUrl != null &&
            widget.profileInfoModal.publicUrl != "null" &&
            widget.profileInfoModal.publicUrl != "") {
          conformationDialogForAddIntoProfile();
        } else {
          editInterest(false);
        }
      } else {
        editInterest(false);
      }
    } else {
      print("Failure 00");
    }
  }

  Future editInterest(addIntoProfile) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        //  CustomProgressLoader.showLoader(context);

        //await getSelectedData();

        Map map = {
          "userId": int.parse(userIdPref),
          "roleId": 1, //int.parse(roleId),
          "major_interests":
              selectedLoveInterestsList.map((item) => item.toJson()).toList(),
          "financialSupport": isYes
              ? "Yes"
              : isNo
                  ? "No"
                  : "Notshare",
          "needCounselor": isNeedCounselorYes,
          "addIntoProfile": addIntoProfile
        };

        print("map+++" + map.toString());
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_ADD_SKILL_API, map);
        print("response:-" + response.toString());
        try {
          if (response != null) {
            if (response.statusCode == 200) {
              String status = response.data[LoginResponseConstant.STATUS];
              String msg = response.data[LoginResponseConstant.MESSAGE];

              if (status == "Success") {
                popString = "push";
                Navigator.pop(context, popString);
                print('Data updated successfully');

              } else {
                ToastWrap.showToast(msg, context);
              }
            }
          }
        } catch (e) {
          crashlytics_bloc.recordCrashlyticsError(e,"EditFutureGoalsWidget",context);
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditFutureGoalsWidget",context);
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    try {
      getSharedPreferences();
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e,"EditFutureGoalsWidget",context);
      print(e.toString());
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    //-------------------------------------Main Ui ------------------------------------------
    return  WillPopScope(
      onWillPop: () {
        Navigator.pop(context, popString);
      },
      child:  GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(new FocusNode());
          },
          child:  Scaffold(
              backgroundColor:  ColorValues.SCREEN_BG_COLOR,
              appBar:  AppBar(
                elevation: 0.0,
                automaticallyImplyLeading: false,
                titleSpacing: 2.0,
                brightness: Brightness.light,
                leading:  Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                     InkWell(
                      child:  SizedBox(
                        height: 40.0,
                        width: 40.0,
                        child: PaddingWrap.paddingfromLTRB(
                            0.0,
                            5.0,
                            0.0,
                            3.0,
                             Center(
                                child:  Image.asset(
                                    "assets/newDesignIcon/navigation/back.png",
                                    height: 20.0,
                                    width: 10.0,
                                    fit: BoxFit.fitHeight))),
                      ),
                      onTap: () {
                        Navigator.pop(context, 'back');
                      },
                    )
                  ],
                ),
                actions: <Widget>[
                   InkWell(
                    child: PaddingWrap.paddingfromLTRB(
                        5.0,
                        7.0,
                        10.0,
                        5.0,
                         Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                             Text(
                              "Save ",
                              style:  TextStyle(
                                  fontSize: 16.0,
                                  fontFamily: Constant.customRegular,
                                  color:  ColorValues.BLUE_COLOR_BOTTOMBAR),
                            )
                          ],
                        )),
                    onTap: () {
                      //editInterest();
                      _checkValidation();
                      //if (!isApiCalling) _validateCardDetail();
                    },
                  )
                ],
                title:  Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                     Text(
                      "Future Goals",
                      style:  TextStyle(
                          fontSize: 18.0,
                          fontFamily: Constant.customRegular,
                          color:
                               ColorValues.HEADING_COLOR_EDUCATION),
                    )
                  ],
                ),
                backgroundColor: Colors.white,
              ),
              body: Column(
                children: <Widget>[
                  CustomViews.getSepratorLine(),
                  Expanded(
                    child: ListView(
                      children: <Widget>[
                        Form(
                          key: _formKey,
                          child: Padding(
                            padding:
                                const EdgeInsets.only(top: 10.0, left: 0.0),
                            child:  Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(left: 13.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          5.0,
                                          TextViewWrap.textViewMultiLine(
                                              "What’s next after high school?",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              18.0,
                                              FontWeight.bold,
                                              3)),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          35.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Select what you would like to do after high school.",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              14.0,
                                              FontWeight.normal,
                                              4)),
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                          TextViewWrap.textViewMultiLine(
                                              "What do you want to study (major)?",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              16.0,
                                              FontWeight.bold,
                                              3)),
                                      /*PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          0.0,
                                          0.0,
                                          0.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Add Major of interest in which you want to go in future",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              12.0,
                                              FontWeight.normal,
                                              3)),*/
                                      _skillModel != null
                                          ? collegeDropdownView()
                                          : Container(
                                              height: 0.0,
                                            ),
                                      selectedLoveInterestsList != null &&
                                              selectedLoveInterestsList.length >
                                                  0
                                          ? Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 5.0),
                                              child: getUniversitySelectedChips(
                                                  selectedLoveInterestsList,
                                                  true))
                                          : Container(
                                              width: 0,
                                              height: 0,
                                            ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 15.0,
                                ),
                                /*  selectedLoveInterestsList.length>0?     Divider(
                                  color:  ColorValues.GREY__COLOR_DIVIDER,
                                ): Container(
                                  height: 0.0,
                                ),*/
                                Padding(
                                  padding: const EdgeInsets.only(left: 13.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          15.0,
                                          0.0,
                                          15.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Do you need financial support?",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              16.0,
                                              FontWeight.bold,
                                              3)),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isYes
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "Yes",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isYes = true;
                                                isNo = false;
                                                isNotShare = false;
                                              });
                                            },
                                          ),
                                          Container(
                                            width: 11,
                                            height: 0,
                                          ),
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNo
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "No",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isYes = false;
                                                isNo = true;
                                                isNotShare = false;
                                              });
                                            },
                                          ),
                                          Container(
                                            width: 11,
                                            height: 0,
                                          ),
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNotShare
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "Don't want to share",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isYes = false;
                                                isNo = false;
                                                isNotShare = true;
                                              });
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 15.0,
                                ),
                                 Divider(
                                  color:  ColorValues.GREY__COLOR_DIVIDER,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 13.0,
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      PaddingWrap.paddingfromLTRB(
                                          0.0,
                                          15.0,
                                          0.0,
                                          15.0,
                                          TextViewWrap.textViewMultiLine(
                                              "Do you need counselor support?",
                                              TextAlign.start,
                                               ColorValues.HEADING_COLOR_EDUCATION,
                                              16.0,
                                              FontWeight.bold,
                                              3)),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNeedCounselorYes
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "Yes",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isNeedCounselorYes = true;
                                                isNeedCounselorNo = false;
                                              });
                                            },
                                          ),
                                          Container(
                                            width: 11,
                                            height: 0,
                                          ),
                                          InkWell(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: <Widget>[
                                                Image.asset(
                                                    isNeedCounselorNo
                                                        ? "assets/newDesignIcon/group/check_radio.png"
                                                        : "assets/newDesignIcon/group/uncheck_radio.png",
                                                    height: 15,
                                                    width: 15),
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 8.0),
                                                  child: TextViewWrap
                                                      .textViewMultiLine(
                                                          "No",
                                                          TextAlign.start,
                                                           ColorValues.GREY__COLOR,
                                                          14.0,
                                                          FontWeight.normal,
                                                          1),
                                                )
                                              ],
                                            ),
                                            onTap: () {
                                              setState(() {
                                                isNeedCounselorYes = false;
                                                isNeedCounselorNo = true;
                                              });
                                            },
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    //bottom: 20,
                    //right: 13,
                    alignment: Alignment.bottomLeft,
                    child:  InkWell(
                      child:  Padding(
                          padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                          child: Image.asset(
                            'assets/newDesignIcon/parentProfile/backword.png',
                            height: 45.0,
                            width: 45.0,
                          )),
                      onTap: () {
                        Navigator.of(context).pop(popString);
                      },
                    ),
                  )
                ],
              ))),
    );
  }

  collegeDropdownView() {
    return Padding(
      padding: const EdgeInsets.only(right: 13.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: bottomBorderDynamic(bottomViewColor),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[

                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: InkWell(
                          onTap: () {
                            setState(() {
                              showList = !showList;
                            });
                          },
                          child: TextField(
                              controller: _textFieldController,
                              //autofocus: true,
                              onChanged: (value) {
                                //print('onChanged called... text:: ${_textFieldController.text}');
                                callListSearch();
                              },
                              style:  TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              onEditingComplete: () {
                                setState(() {});
                              },
                              textInputAction: TextInputAction.done,
                              focusNode: _textFieldFocus,
                              autocorrect: false,
                              onSubmitted: (term) {
                                _textFieldFocus.unfocus();
                                if (_textFieldController.text != null &&
                                    _textFieldController.text != "") {
                                List<SkillData> _searchedSelected  = selectedLoveInterestsList
                                    .where((food) => food.name
                                    .toLowerCase()
                                    .startsWith(_textFieldController.text.trim().toLowerCase()))
                                    .toList();
                                if (_searchedSelected.length==0||_searchedSelected.isEmpty) {
                                  if (!findPersonUsingWhere(
                                      _textFieldController.text.trim())) {
                                    selectedUniversityOption
                                        .add(_textFieldController.text.trim());
                                    selectedLoveInterestsList.add(SkillData(
                                        name:
                                        _textFieldController.text.trim()));
                                    //removedUniversiyList.add(SkillData(name: _textFieldController.text.trim()));
                                  }
                                }
                                }

                                _textFieldController.clear();
                                setState(() {
                                  selectedUniversityOption;
                                  selectedLoveInterestsList;
                                  _universityList;
                                  _searchedUniversityList = _universityList;
                                  showList = false;
                                });
                              },
                              cursorColor: Constant.CURSOR_COLOR,
                              decoration:  InputDecoration(
                                contentPadding: const EdgeInsets.fromLTRB(
                                    0.0, 5.0, 5.0, 5.0),
                                border: InputBorder.none,
                                /*hintText: selectedLoveInterestsList //spikeViewUserList //selectedUniversityOption
                                        .length ==
                                        0
                                        ? 'Add your interest' : "",
                                    //: '${selectedUniversityOption[selectedUniversityOption.length - 1]}',*/
                                labelText: "Add your interest",
                                labelStyle:  TextStyle(
                                    fontSize: 16.0,
                                    color:  ColorValues.GREY__COLOR,
                                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                              ))),
                    ),
                    IconButton(
                      onPressed: () {
                        showList = !showList;
                        setState(() {});
                      },
                      icon: Padding(
                        padding: const EdgeInsets.only(left: 15.0, top: 0),
                        child: Icon(showList
                            ? Icons.keyboard_arrow_up
                            : Icons.keyboard_arrow_down),
                      ),
                    ),
                  ],
                ),
                /*selectedOtherOption.length > 0
                              ? selectOtherCategoryTextField()
                              : Container(),*/
              ],
            ),
          ),
          _skillModel.skillList != null && _skillModel.skillList.length > 0
              /*&& selectedLoveInterestsList.length !=
                      _skillModel.skillList.length*/
              ? universityListWidget()
              : Container(),
        ],
      ),
    );
  }

  universityListWidget() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        showList
            ? _searchedUniversityList.length > 0
                ? Card(
                    child: Container(
                      height: _searchedUniversityList.length == 1
                          ? 50.0
                          : _searchedUniversityList.length == 2
                              ? 90.0
                              : _searchedUniversityList.length == 3
                                  ? 130
                                  : 200.0,
                      padding: _searchedUniversityList.length > 0
                          ? EdgeInsets.all(10)
                          : EdgeInsets.all(0),
                      child: ListView.builder(
                        padding: EdgeInsets.zero,
                        //controller: controller,
                        key: _listKey,
                        itemCount: _searchedUniversityList.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return _searchedUniversityList[index].isSelected
                              ? Container(
                                  width: 0,
                                  height: 0,
                                )
                              : _buildAddedItem(
                                  _searchedUniversityList[index], index);
                        },
                      ),
                    ),
                  )
                : Container()
            : Container(),
      ],
    );
  }

  Widget _buildAddedItem(SkillData item, int index) {
    return item.name != null
        ? Container(
            child: InkWell(
              onTap: () {
                print("item++++" + item.name);
                //toggalSelection(false, index);
                onListItemTap(item);
              },
              child: AnimatedContainer(
                curve: Curves.easeIn,
                duration: Duration(milliseconds: 500),
                width: MediaQuery.of(context).size.width,
                child: Text(item.name,
                    style: TextStyle(fontFamily: Constant.customRegular)),
                padding: EdgeInsets.all(8),
              ),
            ),
          )
        : Container(
            width: 0,
            height: 0,
          );
  }

  List<SkillData> callListSearch() {
    print(
        'inside callListSearch() search text::: ${_textFieldController.text.trim()}');

    showList = false;

    if (_textFieldController.text.trim() != '') {
      _searchedUniversityList = _skillModel.skillList
          .where((food) => food.name
              .toLowerCase()
              .startsWith(_textFieldController.text.toLowerCase()))
          .toList();
    } else {
      _searchedUniversityList = _skillModel.skillList;
      /*_searchedUniversityList.clear();
      _searchedUniversityList.addAll(_skillModel.skillList.sublist(0, 10));
      listIndexFrom = 10;*/
    }
    setState(() {
      _searchedUniversityList;
      showList = true;
    });
    print(
        'inside callListSearch() _searchedUniversityList size:; ${_searchedUniversityList.length}');
    return _searchedUniversityList;
  }

  bool findPersonUsingWhere(String personName) {
    // Return list of people matching the condition
    final foundPeople = selectedLoveInterestsList
        .where((element) => element.name == personName);

    if (foundPeople.isNotEmpty) {
      print('Using where: ${foundPeople.first}');
      return true;
    } else
      return false;
  }

  void onListItemTap(SkillData item) {
    _textFieldFocus.unfocus();
    removedUniversiyList.add(item);
    selectedLoveInterestsList.add(
        SkillData(name: item.name, hobbyId: item.hobbyId, type: item.type));

    selectedUniversityOption.add(item.name);
    if (_universityList.length > 0) {
      _searchedUniversityList.remove(item);
      _universityList.remove(item);
    }
    showList = !showList;
    _textFieldController.text = '';
    //
    _searchedUniversityList = _universityList;
    /*_searchedUniversityList.clear();
    _searchedUniversityList.addAll(_skillModel.skillList.sublist(0, 10));
    listIndexFrom = 10;*/
    setState(() {
      bottomViewColor = Palette.dividerColor;
      _textFieldController;
      _searchedUniversityList;
      _universityList;
    });
  }

  getUniversitySelectedChips(_items, bool isSelected) {
    return _items != null
        ? MediaQuery.removePadding(
            context: context,
            removeTop: true,
            removeBottom: true,
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              primary: true,
              shrinkWrap: true,
              children: <Widget>[
                Wrap(
                  spacing: 5.0,
                  runSpacing: 0.0,
                  children: List<Widget>.generate(
                      _items.length, // place the length of the array here
                      (int index) {
                    return InputChip(
                      label: Text(
                        '${_items[index].name}',
                        maxLines: 4,
                        softWrap: true,
                        style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                        ),
                      ),
                      backgroundColor: ColorValues.BLUE_COLOR_BOTTOMBAR,
                      shape: StadiumBorder(
                        side: BorderSide(
                            color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                      ),
                      onSelected: (bool value) {},
                      deleteIcon: Icon(
                        Icons.clear,
                        color:  ColorValues.WHITE,
                        size: 16.0,
                      ),
                      onDeleted: () {
                        print("selected index:: $index");
                        updateList(_items[index], index);
                      },
                      labelStyle: TextStyle(
                        color: ColorValues.WHITE,
                        fontSize: 16,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12.0, vertical: 3.0),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        : Container(
            height: 0,
            width: 0,
          );
  }

  void updateList(SkillData item, int index) {
    print('inside updateList');
    int indexR = 0;
    //for (SkillData removeitem in removedUniversiyList) {
    for (int i = 0; i < removedUniversiyList.length; i++) {
      print(
          'inside updateList removeitem name:: ${removedUniversiyList[i].name}');
      if (item.name == removedUniversiyList[i].name && item.hobbyId != "") {
        print('update this inside name:: ${removedUniversiyList[i].name}');
        _universityList.add(removedUniversiyList[i]);
        indexR = i;
      }
    }

    if (item.hobbyId != null && item.hobbyId != "") {
      removedUniversiyList.removeAt(indexR);
    }

    //removedUniversiyList.removeAt(index);
    selectedLoveInterestsList.removeAt(index);
    selectedUniversityOption.removeAt(index);
    setState(() {
      _universityList;
      removedUniversiyList;
      selectedLoveInterestsList;
      selectedUniversityOption;
      if (showList) showList = !showList;
    });
  }
}
