import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:keyboard_actions/keyboard_actions.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/common/check_permission.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/education/model/CollegeDegreeModel.dart';
import 'package:spike_view_project/education/model/CollegeInfoDetailModel.dart';
import 'package:spike_view_project/education/model/EducationDetailInfoModel.dart';
import 'package:spike_view_project/education/model/PursuingYearModel.dart';
import 'package:spike_view_project/modal/OrganizationModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/patnerFlow/opportunity/upload_media.dart';
import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class EditStudentEducationWidget extends StatefulWidget {
  String dob, isActive, editFrom;

  //ProfileEducationModal profileEducationModal;
  Institute institute;

  EditStudentEducationWidget(
      this.dob, this.isActive, this.editFrom, this.institute);

  @override
  EditEducationState createState() {
    return EditEducationState(dob, isActive);
  }
}

class EditEducationState extends State<EditStudentEducationWidget> {
  final _formKey = GlobalKey<FormState>();
  String dob, isActive;

  String educationInit = 'School';

  Timer _timer;
  String previousText = "";

  EditEducationState(this.dob, this.isActive);

  FocusNode gpaFocus = FocusNode();
  FocusNode togpaFocus = FocusNode();
  String strAchievement,
      strSearchInstiuteHint = "",
      strFromDate,
      strToDate,
      strName,
      strEmail,
      strCity,
      strDeascription,
      grade1,
      strGrade1 = "",
      grade2,
      strGrade2 = "",
      year1 = "",
      stryear1 = "",
      year2 = "",
      stryear2 = "";
  TextEditingController cityController, descControler;
  SharedPreferences prefs;
  String strAzureUploadPath = "";
  List<OrganizationModal> organizationLst = List<OrganizationModal>();
  bool isLoadMore=false;
  bool isAllDataLoaded = false;
  int skipIndex = 0;
  TextEditingController fromDateController, toDateController;
  static const platform = const MethodChannel('samples.flutter.io/battery');
  String userIdPref, token;
  TextEditingController _searchQuery;
  List<String> yearList = List();
  List<String> toYearList = List();
  String sasToken, containerName;
  bool _IsSearching;
  String selectedText = "";
  double searchListHeight = 200.0;
  File imagePath;
  String _searchText = "",
      strOrganizationId = "",
      strInstiute = "",
      strOrganizationType = "School",
      strPrefixPathOrganization;
  final List<String> _items = [
    'Select Grade',
    '1st',
    '2nd',
    '3rd',
    '4th',
    '5th',
    '6th',
    '7th',
    '8th',
    '9th',
    '10th',
    '11th',
    '12th',
  ].toList();
  bool isChange = false;
  String isPerformChnges = "pop";
  bool isPresent = false;

  bool isWeighted = false;

  TextEditingController otherDegreeController = TextEditingController(text: "");
  TextEditingController professionalCertificatesDegreeController =
      TextEditingController(text: "");
  TextEditingController majorController = TextEditingController(text: "");
  TextEditingController minorController = TextEditingController(text: "");
  TextEditingController obGpaController = TextEditingController(text: "");
  TextEditingController totGpaController = TextEditingController(text: "");

  String obtGPA = "";
  String totGPA = "";

  List<CollegeInfoResult> collegeInfoList = List();

  int searchListLength = 0;

  int selectedEduIndex = 0;

  String strMajor = '',
      strMinor = '',
      strOtherDegree = '',
      strProfessionCertificateDegree = '';
  String graduationYear = 'Graduation Year';
  String strDegree = '', strDegreeYear = '', strGraduationYear = '';
  String inactivedeg = null;
  List<CollegeDegreeResult> inactiveCollegeDegreeList = List();
  var isOtherSelected = false;
  var isProfessionalCertificatesSelected = false;

  CollegeDegreeModel collegeDegreeModel = CollegeDegreeModel();
  CollegeInfoDetailModel collegeInfoDetailModel = CollegeInfoDetailModel();

  PursuingYearModel pursuingYearModel = PursuingYearModel();

  List<CollegePursuingResult> pursuingYearList = List();
  List<CollegeDegreeResult> collegeDegreeList = List();

  final List<String> eduOptionList = [
    'School',
    'College',
  ].toList();

  List<String> gradualtionYearList = List();

  bool isReadyForApiCall = false;

//------------------------------------Retrive data ( Userid nd token ) ---------------------
  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_WIZARD_USERID);
    token = prefs.getString(UserPreference.USER_TOKEN);

    if (widget.editFrom == 'School') {
      //  recommendationApi();
    } else {
      //  collegeInfoApi();
      collegeDegreeApi();
      collegePursuingApi();
    }
    callApiForSaas();
    strPrefixPathOrganization = Constant.CONTAINER_PREFIX +
        userIdPref +
        "/" +
        Constant.CONTAINER_ORGANIZATION +
        "/";
  }

  //=========================================================Api Calling =======================================
  //--------------------------SaasToken  api ------------------
  Future callApiForSaas() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
          context,
          Constant.ENDPOINT_SAS,
          "post",
        );
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              sasToken = response.data['result']['sasToken'];
              containerName = response.data['result']['container'];
              if (containerName != null && containerName != "")
                Constant.CONTAINER_NAME = containerName;
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }
  Future recommendationApiLoadMore() async {
    try {

      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": previousText,
          "type": educationInit,
          "skip": skipIndex,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2().apiCallPostWithMapData(
            context, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());
        isLoadMore=false;
        _IsSearching = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              var organizationLst1 =
              ParseJson.parseMapOrganization(response.data['result'], educationInit);
              if (organizationLst1.length > 0) {
                setState(() {
                  organizationLst.addAll(organizationLst1);
                });
              }else{
                isAllDataLoaded = true;
              }
            }
          }
        }
        setState(() {});
      } else {
        isLoadMore=false;
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoadMore=false;
      setState(() {});
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }
  //--------------------------Recommendation Info api ------------------
  Future recommendationApi(searchText, type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "name": searchText,
          "type": type,
          "skip": skipIndex,
        };
        print("data++++++searchText===" + map.toString());
        Response response = await ApiCalling2()
            .apiCallPostWithMapData(context, Constant.SCHOOL_SEACRH_API, map);
        print("data++++++searchText===" + response.toString());
        _IsSearching = false;
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              organizationLst.clear();
              organizationLst =
                  ParseJson.parseMapOrganization(response.data['result'], type);
              if (organizationLst.length > 0) {
                setState(() {
                  organizationLst;
                  print("List Lenght ---------" +
                      organizationLst.length.toString());
                });
              }
            }
          }
        }
        setState(() {});
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(e, "AddEducation", context);
      e.toString();
    }
  }

  Future collegeInfoApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling().apiCall(
            context, Constant.ENDPOINT_COLLEGE_ORGANIZATION_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              collegeInfoList.clear();
              collegeInfoDetailModel =
                  CollegeInfoDetailModel.fromJson(response.data);

              collegeInfoList.addAll(collegeInfoDetailModel.result);
              //collegeInfoList.insert(0,  CollegeInfoResult(degreeId: -1,name: "Degree"));

              setState(() {
                collegeInfoList;
              });
              print('collegeInfoList size:: ${collegeInfoList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //call college degree list API
  Future collegeDegreeApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        print('collegeDegreeApi() 111');
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_GET_DEGREE, "get");
        print('collegeDegreeApi() 222');
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              print('collegeDegreeApi() 333');
              collegeDegreeList.clear();
              collegeDegreeModel = CollegeDegreeModel.fromJson(response.data);

              collegeDegreeList.addAll(collegeDegreeModel.result);
              inactiveCollegeDegreeList
                  .addAll(collegeDegreeModel.inactiveRresult);
              //collegeDegreeList.insert(0,  CollegeDegreeResult(degreeId: -1, name: "Degree"));

              print('appu strDegree:: ${strDegree}');
              setState(() {
                //collegeDegreeList = collegeDegreeList.reversed.toList();
                collegeDegreeList;
                if (collegeDegreeList.length > 0 && strDegree != null) {
                  // Return list of people matching the condition
                  String deg = null;
                  for (var item in collegeDegreeList) {
                    if (item.name == strDegree) {
                      deg = strDegree;
                      break;
                    }
                  }
                  if (deg == null) {
                    //inactiveCollegeDegreeList
                    for (var item in inactiveCollegeDegreeList) {
                      if (item.name == strDegree) {
                        inactivedeg = strDegree;
                        break;
                      }
                    }
                  }
                  strDegree = deg;
                } else
                  strDegree = null;
              });
              print('appu 22 strDegree:: ${strDegree}');
              print('collegeDegreeModel size:: ${collegeDegreeList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //call college pursuing list API
  Future collegePursuingApi() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response = await ApiCalling()
            .apiCall(context, Constant.ENDPOINT_YEAR_LIST, "get");
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              pursuingYearList.clear();
              pursuingYearModel = PursuingYearModel.fromJson(response.data);
              pursuingYearList.addAll(pursuingYearModel.result);

              setState(() {
                //pursuingYearList = pursuingYearList.reversed.toList();
                pursuingYearList;
                if (strDegreeYear == '' && pursuingYearList.length > 0)
                  //strDegreeYear = pursuingYearList[0].name;
                  strDegreeYear = null;
              });

              print('pursuingYearList size:: ${pursuingYearList.length}');
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      e.toString();
    }
  }

  //-------------------------------------Upload image on Azure --------------------------
  Future<String> uploadImgOnAzure(imagePath) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (sasToken != "" && containerName != "") {
          final String result = await platform.invokeMethod('getBatteryLevel', {
            "sasToken": sasToken,
            "imagePath": imagePath,
            "uploadPath": Constant.IMAGE_PATH + strPrefixPathOrganization
          });

          print("image_path" + result);
          return result;
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      return "";
    } on Exception catch (e) {
      CustomProgressLoader.cancelLoader(context);
      return "";
    }
  }

  //--------------------------Edit Data ------------------
  Future editEducation() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (isChange) {
          strAzureUploadPath = strPrefixPathOrganization + strAzureUploadPath;
        }
        /*Map map = {
          "educationId": widget.institute.educationId,
          "userId": userIdPref,
          "organizationId": strOrganizationId??"",
          "logo": strAzureUploadPath,
          "institute": strInstiute.trim(),
          "city": cityController.text.trim(),
          "fromYear": year1,
          "toYear": year2 == "" || year2 == "null" ? null : year2,
          "fromGrade": grade1,
          "toGrade": grade2,
          "description": "",
          "isActive": isActive,
          "type": strOrganizationType
        };
        print("map+++" + map.toString());
        Response response = await  ApiCalling2().apiCallPutWithMapData(
            context, Constant.ENDPOINT_ADD_ORGANIZATION, map);*/

        Map map;
        Response response;
        if (educationInit == "School") {
          map = {
            "educationId": widget.institute.educationId,
            "userId": userIdPref,
            "organizationId": strOrganizationId == null ?? "",
            "logo": strAzureUploadPath,
            "institute": strInstiute.trim(),
            "city": cityController.text.trim(),
            "fromYear": year1,
            "toYear": year2 == "" || year2 == "null" ? null : year2,
            "fromGrade": grade1,
            "toGrade": grade2,
            //"description": strDeascription,
            "isActive": isActive,
            "type": educationInit, //strOrganizationType,
            "gpa": obtGPA != '' ? double.parse(obtGPA) : '',
            "outOfGpa": totGPA != '' ? double.parse(totGPA) : '',
            "isWeighted": isWeighted,
            "certifications": ""
          };
          print("Education School map::::: " + map.toString());
          response = await ApiCalling2().apiCallPutWithMapData(
              context, Constant.ENDPOINT_ADD_ORGANIZATION, map);
        } else {
          map = {
            "educationId": widget.institute.educationId,
            "userId": userIdPref,
            "organizationId": strOrganizationId ?? "",
            "logo": strAzureUploadPath,
            "institute": strInstiute.trim(),
            "city": cityController.text.trim(),
            "fromYear": year1,
            "toYear": year2 == "" || year2 == "null" ? null : year2,
            //"description": strDeascription,
            "isActive": isActive,
            "type": educationInit, //strOrganizationType, //"type":"College",
            "gpa": obtGPA != '' ? double.parse(obtGPA) : '',
            "outOfGpa": totGPA != '' ? double.parse(totGPA) : '',
            "isWeighted": isWeighted,
            "degree": strDegree != null ? strDegree : inactivedeg,
            "otherDegree": strOtherDegree,
            "major": strMajor,
            "minor": strMinor,
            "year": strDegreeYear,
            "graduationYear": strGraduationYear,
            "certifications": strProfessionCertificateDegree
          };

          print("Education College map::::: " + map.toString());
          response = await ApiCalling2().apiCallPutWithMapData(
              context, Constant.ENDPOINT_UPDATE_COLLEGE_INFO, map);
        }

        print("Education API response::::: " + response.toString());

        CustomProgressLoader.cancelLoader(context);
        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];

            if (status == "Success") {
              Navigator.pop(context, "push");
            } else {
              ToastWrap.showToast(msg, context);
            }
          }
        }
      } else {
        CustomProgressLoader.cancelLoader(context);
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    try {
      educationInit = widget.editFrom;

      DateTime date = DateTime.fromMillisecondsSinceEpoch(int.tryParse(dob));

      for (int i = date.year; i <= DateTime.now().year + 10; i++) {
        gradualtionYearList.add(i.toString());
      }
      gradualtionYearList.add("Graduation Year");
      setState(() {
        gradualtionYearList = gradualtionYearList.reversed.toList();
      });

      for (int i = date.year; i <= DateTime.now().year; i++) {
        yearList.add(i.toString());
      }
      yearList.add("Select Year");
      setState(() {
        yearList = yearList.reversed.toList();
      });

      for (int i = date.year; i <= (new DateTime.now().year + 10); i++) {
        toYearList.add(i.toString());
      }
      toYearList.add("Select Year");
      setState(() {
        toYearList = toYearList.reversed.toList();
      });

      _searchQuery = TextEditingController(text: widget.institute.institute);
      print("yearlist" + yearList.length.toString());
      _IsSearching = false;
      _searchQuery.addListener(() {
        if (_searchQuery.text.isEmpty) {
          setState(() {
            _IsSearching = false;
            _searchText = "";
            previousText = "";
            organizationLst.clear();
            collegeInfoList.clear();
          });
        } else {
          if (selectedText.trim() != _searchQuery.text.trim()) {
            if (_searchQuery.text.trim().length > 1) {
              if (educationInit == "School") {
                if (_timer != null) {
                  print("data++++++timer cancel");
                  _timer.cancel();
                }
                _timer = Timer(const Duration(milliseconds: 600), () {
                  if (previousText.trim() != _searchQuery.text.trim()) {
                    previousText = _searchQuery.text;
                    if (!_IsSearching) {
                      _IsSearching = true;
                      skipIndex = 0;
                      isAllDataLoaded = false;
                      recommendationApi(_searchQuery.text.trim(), 'school');
                    }
                  }
                });
              } else {
                if (_timer != null) {
                  print("data++++++timer cancel");
                  _timer.cancel();
                }
                _timer = Timer(const Duration(milliseconds: 600), () {
                  if (previousText.trim() != _searchQuery.text.trim()) {
                    previousText = _searchQuery.text;
                    if (!_IsSearching) {
                      _IsSearching = true;
                      skipIndex = 0;
                      isAllDataLoaded = false;
                      recommendationApi(_searchQuery.text.trim(), 'college');
                    }
                  }
                });
              }
            }
          }
        }
      });

      strSearchInstiuteHint = widget.institute.institute;
      if (widget.institute.organizationId.toString() != null &&
          widget.institute.organizationId.toString() != "null" &&
          widget.institute.organizationId.toString() != '')
        strOrganizationId = widget.institute.organizationId.toString();
      else
        strOrganizationId = '';

      print('Apurva edit strOrganizationId:: $strOrganizationId');
      strInstiute = widget.institute.institute;
      cityController = TextEditingController(text: widget.institute.city);
      /*   descControler =  TextEditingController(
          text: widget.institute.description);*/
      if (educationInit == 'School') {
        strGrade1 = widget.institute.fromGrade;
        grade1 = widget.institute.fromGrade;
        strGrade2 = widget.institute.toGrade;
        grade2 = widget.institute.toGrade;
      } else {
        //init college fields
        if (widget.institute.degree.toString() != 'null' &&
            widget.institute.degree != '') {
          strDegree = widget.institute.degree;
        } else {
          strDegree = null;
        }

        if (widget.institute.degree == 'Other') {
          isOtherSelected = true;
          isProfessionalCertificatesSelected = false;
          strOtherDegree = widget.institute.otherDegree;
          otherDegreeController.text = widget.institute.otherDegree;
        } else if (widget.institute.degree == 'Professional Certificate') {
          isOtherSelected = false;
          isProfessionalCertificatesSelected = true;
          strProfessionCertificateDegree = widget.institute.certifications;
          professionalCertificatesDegreeController.text =
              widget.institute.certifications;
        }

        strMajor = widget.institute.major;
        majorController.text = widget.institute.major;
        strMinor = widget.institute.minor;
        minorController.text = widget.institute.minor;

        strDegreeYear = widget.institute.year;

        if (widget.institute.graduationYear != null &&
            widget.institute.graduationYear != "") {
          strGraduationYear = widget.institute.graduationYear;
          graduationYear = widget.institute.graduationYear;
        }
      }

      //GPA
      if (widget.institute.gpa.toString() != "null" &&
          widget.institute.gpa.toString() != "") {
        obtGPA = widget.institute.gpa.toString();
        obGpaController.text = widget.institute.gpa.toString();
      }
      if (widget.institute.outOfGpa.toString() != "null" &&
          widget.institute.outOfGpa.toString() != "") {
        totGPA = widget.institute.outOfGpa.toString();
        totGpaController.text = widget.institute.outOfGpa.toString();
      }
      if (widget.institute.isWeighted != null)
        isWeighted = widget.institute.isWeighted;

      year1 = widget.institute.fromYear;
      stryear1 = widget.institute.fromYear;

      if (widget.institute.toYear == null ||
          widget.institute.toYear == "null" ||
          widget.institute.toYear == "") {
        year2 = null;
        stryear2 = "";
        isPresent = true;
      } else {
        year2 = widget.institute.toYear;
        stryear2 = widget.institute.toYear;
      }

      print("stryear1" + stryear1 + " stryear2" + stryear2);
      setState(() {
        strAzureUploadPath = widget.institute.logo;
      });

      getSharedPreferences();
    } catch (e) {
      print(e.toString());
    }
    super.initState();
  }

  Future<Null> _cropImage(File imageFile) async {
    imagePath = await ImageCropper.cropImage(
      sourcePath: imageFile.path,
      ratioX: 2.0,
      ratioY: 2.0,
    );
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    //-----------------------------------Image Selectio Ui nd core logic-------------------------------

    Future getImage(type) async {
      imagePath = await UploadMedia(context).pickImageFromGallery();
      //imagePath = await ImagePicker.pickImage(source: ImageSource.gallery);
      if (imagePath != null) {
        String strPath = imagePath.toString().substring(
            imagePath.toString().lastIndexOf("/") + 1,
            imagePath.toString().length);

        print("imagepath shubh" + strPath);
        if (strPath.toString().contains(".") &&
            (!strPath.toString().contains(".gif"))) {
          print("img   :-" +
              imagePath
                  .toString()
                  .replaceAll("File: ", "")
                  .replaceAll("'", "")
                  .trim());
          if (imagePath != null) {
            // await _cropImage(imagePath);
            isChange = true;
            strAzureUploadPath = "";
            imagePath = imagePath;
            setState(() {
              isChange;
              imagePath;
              strAzureUploadPath;
            });
          }
        } else {
          ToastWrap.showToast(
              MessageConstant.IMAGE_SOURCE_IS_INCORRECT_ERROR, context);
        }
      }
    }

    Widget imageSelectionView() {
      return Container(
        width: 113.0,
        height: 118.0,
        child: Stack(
          children: <Widget>[
            Positioned(
                bottom: 5.0,
                left: 0.0,
                top: 0.0,
                right: 0.0,
                child: Center(
                    child: Container(
                  child: Image.asset(
                    "assets/profile/education_form_default.png",
                    fit: BoxFit.cover,
                  ),
                  width: 113.0,
                  height: 113.0,
                ))),
            Positioned(
                bottom: 0.0,
                right: 0.0,
                child: InkWell(
                  child: Container(
                    //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                    child: Image.asset("assets/newDesignIcon/edit_img.png"),
                    height: 25.0,
                  ),
                  onTap: () async {
                    var status = await Permission.photos.status;
                    if (status.isGranted) {
                      getImage(ImageSource.gallery);
                    } else {
                      checkPermissionPhoto(context);
                    }
                  },
                ))
          ],
        ),
      );
    }

    Widget isImageSelectedView() {
      return Container(
        width: 113.0,
        height: 118.0,
        child: Stack(
          children: <Widget>[
            Positioned(
                bottom: 5.0,
                left: 0.0,
                top: 0.0,
                right: 0.0,
                child: imagePath == null
                    ? Center(
                        child: Container(
                        child: Image.network(
                          Constant.IMAGE_PATH + strAzureUploadPath,
                          fit: BoxFit.cover,
                        ),
                        width: 113.0,
                        height: 113.0,
                      ))
                    : Center(
                        child: Container(
                        child: Image.file(
                          imagePath,
                          fit: BoxFit.cover,
                        ),
                        width: 113.0,
                        height: 113.0,
                      ))),
            Positioned(
                bottom: 0.0,
                right: 0.0,
                child: InkWell(
                  child: Container(
                    //padding:  EdgeInsets.fromLTRB(20.0, 12.0, 0.0, 0.0),
                    child: Image.asset("assets/newDesignIcon/edit_img.png"),
                    height: 25.0,
                  ),
                  onTap: () async {
                    var status = await Permission.photos.status;
                    if (status.isGranted) {
                      getImage(ImageSource.gallery);
                    } else {
                      checkPermissionPhoto(context);
                    }
                  },
                ))
          ],
        ),
      );
    }

    //------------------------------------- Dropdown List for Grade & Year Spinner -------------------------
    final dropdownMenuGrade = _items
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: Text(item,
                style: TextStyle(
                  fontFamily: Constant.TYPE_CUSTOMREGULAR,
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                ))))
        .toList();

    //college degree year
    final dropdownCollegeYear = pursuingYearList
        .map((CollegePursuingResult item) => DropdownMenuItem<String>(
            value: item.name,
            child: Text(
              item.name,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    //college degree
    final dropdownCollegeDegree = collegeDegreeList
        .map((CollegeDegreeResult item) => DropdownMenuItem<String>(
            value: item.name,
            child: Text(
              item.name,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();

    //dropdown for school/college selection
    final dropdownMenuEducation = eduOptionList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: Text(
              item,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
            )))
        .toList();
    final dropdownGraduationYear = gradualtionYearList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(
                  item,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                ))))
        .toList();

    final dropdownMenuYear = yearList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(item,
                    style: TextStyle(
                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                    )))))
        .toList();

    final dropdownMenutoYear = toYearList
        .map((String item) => DropdownMenuItem<String>(
            value: item,
            child: PaddingWrap.paddingfromLTRB(
                0.0,
                0.0,
                0.0,
                0.0,
                Text(item,
                    style: TextStyle(
                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                    )))))
        .toList();
    //------------------------------------------- Search LIst Ui  and Logic implementation ----------------------------
    List<InkWell> _buildSearchList() {
      return List.generate(organizationLst.length, (int index) {
        return InkWell(
            child: Column(
              children: <Widget>[
                ListTile(title: Text(organizationLst[index].name)),
                Divider(
                  color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                ),
                organizationLst.length > 20 &&
                    organizationLst.length - 1 == index
                    ? isLoadMore
                    ? Container(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(
                            ColorValues.BLUE_COLOR_BOTTOMBAR),
                        strokeWidth: 2.0,
                      ),
                    ))
                    :isAllDataLoaded?SizedBox(height: 0,): ListTile(
                    onTap: () {
                      skipIndex++;
                      setState(() {
                        isLoadMore = true;
                      });
                      recommendationApiLoadMore();
                    },
                    title: Text(
                      'View More',
                      style: TextStyle(
                          color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                    ))
                    : SizedBox()
              ],
            ),
            onTap: () {
              setState(() {
                selectedText = organizationLst[index].name;
                _searchQuery.text = organizationLst[index].name;
                strOrganizationId = organizationLst[index].organizationId;
                strOrganizationType = organizationLst[index].type;
                _searchQuery.selection =
                    TextSelection.collapsed(offset: _searchQuery.text.length);
                organizationLst.clear();
                _IsSearching = false;
              });
            });
      });
    }

    List<InkWell> _buildSearchListCollege() {
      return List.generate(organizationLst.length, (int index) {
        return InkWell(
            child: Column(
              children: <Widget>[
                ListTile(title: Text(organizationLst[index].name)),
                Divider(
                  color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                ),
                organizationLst.length > 20 &&
                    organizationLst.length - 1 == index
                    ? isLoadMore
                    ? Container(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(
                            ColorValues.BLUE_COLOR_BOTTOMBAR),
                        strokeWidth: 2.0,
                      ),
                    ))
                    : isAllDataLoaded?SizedBox(height: 0,):ListTile(
                    onTap: () {
                      skipIndex++;
                      setState(() {
                        isLoadMore = true;
                      });
                      recommendationApiLoadMore();
                    },
                    title: Text(
                      'View More',
                      style: TextStyle(
                          color: ColorValues.BLUE_COLOR_BOTTOMBAR),
                    ))
                    : SizedBox()
              ],
            ),
            onTap: () {
              setState(() {
                selectedText = organizationLst[index].name;
                _searchQuery.text = organizationLst[index].name;
                strOrganizationId =
                    organizationLst[index].organizationId.toString();
                strOrganizationType = organizationLst[index].type;
                _searchQuery.selection =
                    TextSelection.collapsed(offset: _searchQuery.text.length);
                organizationLst.clear();
                _IsSearching = false;
              });
            });
      });
    }

    Container getOrganizationUi() {
      return Container(
          child: Column(
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              13.0,
              50.0,
              13.0,
              0.0,
              TextFormField(
                  controller: _searchQuery,
                  maxLength: TextLength.SCHOOL_NAME_LENGTH,
                  autocorrect: false,
                  enableInteractiveSelection: false,
                  enableSuggestions: false,
                  cursorColor: Constant.CURSOR_COLOR,
                  keyboardType: TextInputType.visiblePassword,
                  // textCapitalization: TextCapitalization.sentences,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  onSaved: (String value) {
                    // firstName.text = value!;
                  },
                  validator: (val) => val.trim().length == 0
                      ? MessageConstant.ENTER_INSTITUTE_NAME_VAL
                      : /*!ValidationWidget.isSchoolName(val.trim())
                          ? MessageConstant.ENTER_INSTITUTE_NAME_VAL_School
                          :*/ null,
                  decoration: InputDecoration(
                    hintText: 'Search School',
                    labelText: "School",
                    errorStyle: Util.errorTextStyle,
                    contentPadding:
                        const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                    enabledBorder: UnderlineInputBorder(
                      borderSide:
                          BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                    ),
                    counterStyle:
                        TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0)),
                    labelStyle: TextStyle(
                        color: ColorValues.GREY_TEXT_COLOR,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    counterText: "",
                    fillColor: Colors.transparent,
                  ))),
          _searchQuery.text.trim().length > 1
              ? PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  10.0,
                  0.0,
                  Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: organizationLst.length > 0
                                  ? ColorValues.LIGHT_GREY_TEXT_COLOR
                                  : Colors.transparent,
                              width: 1.0)),
                      height: organizationLst.length == 0
                          ? 0.0
                          : organizationLst.length == 1
                              ? 70.0
                              : organizationLst.length == 2
                                  ? 145.0
                                  : organizationLst.length == 3 ? 220.0 : 300.0,
                      child: ListView(children: _buildSearchList())))
              : Container(
                  height: 0.0,
                )
        ],
      ));
    }

    Container getCollegeOrganizationUi() {
      return Container(
          child: Column(
        children: <Widget>[
          PaddingWrap.paddingfromLTRB(
              13.0,
              30.0,
              13.0,
              0.0,
              TextFormField(
                  controller: _searchQuery,
                  maxLength: 200,
                  maxLines: 1,keyboardType: TextInputType.visiblePassword,
                  textCapitalization: TextCapitalization.sentences,
                  style: TextStyle(
                      color: ColorValues.HEADING_COLOR_EDUCATION,
                      fontSize: 16.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR),
                  validator: (val) => val.trim().isEmpty
                      ? educationInit == "School"
                          ? MessageConstant.ENTER_INSTITUTE_NAME_VAL
                          : MessageConstant.ENTER_College_NAME_VAL
                      : null,
                  decoration: InputDecoration(
                    enabledBorder: UnderlineInputBorder(
                      borderSide:
                          BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                    ),
                    counterStyle:
                        TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    focusedBorder: UnderlineInputBorder(
                      borderSide:
                          BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                    ),
                    hintText: 'Search College',
                    contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                    labelText: "College",
                    errorStyle: Util.errorTextStyle,
                    labelStyle: TextStyle(
                        color: ColorValues.GREY_TEXT_COLOR,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR),
                    counterText: "",
                    fillColor: Colors.transparent,
                  ))),
          _searchQuery.text.trim().length > 1
              ? PaddingWrap.paddingfromLTRB(
                  10.0,
                  0.0,
                  10.0,
                  0.0,
                  Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: organizationLst.length > 0
                                  ? ColorValues.LIGHT_GREY_TEXT_COLOR
                                  : Colors.transparent,
                              width: 1.0)),
                      height: organizationLst.length == 0
                          ? 0.0
                          : organizationLst.length == 1
                              ? 70.0
                              : organizationLst.length == 2
                                  ? 145.0
                                  : organizationLst.length == 3 ? 220.0 : 300.0,
                      child: ListView(children: _buildSearchListCollege())))
              : Container(
                  height: 0,
                )
        ],
      ));
    }

//-----------------------------------------------Spinner Ui Grade nd Year --------------------------------
    final gradeUi1 = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        10.0,
        0.0,
        Container(
            height: 28.0,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      strGrade1,
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    ),
                    value: grade1,
                    items: dropdownMenuGrade,
                    onChanged: (s) {
                      if (s != "Select Grade") {
                        setState(() {
                          FocusScope.of(context).requestFocus(new FocusNode());

                          grade1 = s;
                          strGrade1 = s;
                          grade2 = s;
                          strGrade2 = s;
                        });
                      }
                    }))));

    final gradeUi2 = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        16.0,
        0.0,
        Container(
            height: 28.0,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      strGrade2,
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    ),
                    value: grade2,
                    items: dropdownMenuGrade,
                    onChanged: (s) {
                      if (s != "Select Grade") {
                        if (grade1 == null) {
                          ToastWrap.showToast(
                              MessageConstant.SELECT_GRADE_FROM_VAL, context);
                        } else {
                          String strg1 = grade1
                              .replaceAll("th", "")
                              .replaceAll("st", "")
                              .replaceAll("rd", "")
                              .replaceAll("nd", "");
                          String strg2 = s
                              .replaceAll("th", "")
                              .replaceAll("st", "")
                              .replaceAll("rd", "")
                              .replaceAll("nd", "");
                          if (int.parse(strg1) <=
                              int.parse(strg2.replaceAll("th", ""))) {
                            setState(() {
                              FocusScope.of(context)
                                  .requestFocus(new FocusNode());

                              grade2 = s;
                              strGrade2 = s;
                            });
                          } else {
                            ToastWrap.showToast(
                                MessageConstant
                                    .FROM_GRADE_LESS_THAN_TO_GRADE_VAL,
                                context);
                          }
                        }
                      }
                    }))));
    final yearUi1 = Container(
        height: 28.0,
        padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
        width: double.infinity,
        child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
                hint: Text(
                  year1,
                  style: TextStyle(
                      fontSize: 15.0,
                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      color: ColorValues.HEADING_COLOR_EDUCATION),
                ),
                value: year1,
                items: dropdownMenuYear,
                onChanged: (s) {
                  if (grade2 == null && educationInit == "School") {
                    ToastWrap.showToast(
                        MessageConstant.SELECT_GRADE_FROM_VAL, context);
                  } else {
                    setState(() {
                      FocusScope.of(context).requestFocus(new FocusNode());

                      if (stryear2 != "") {
                        if (int.parse(s) > int.parse(stryear2)) {
                          ToastWrap.showToast(
                              MessageConstant
                                  .FROM_DATE_SMALLER_THAN_TO_DATE_VAL,
                              context);
                        } else {
                          year1 = s;
                          stryear1 = s;
                        }
                      } else {
                        year1 = s;
                        stryear1 = s;
                      }

                      /*  String strg1 = grade1
                          .replaceAll("th", "")
                          .replaceAll("st", "")
                          .replaceAll("rd", "")
                          .replaceAll("nd", "");
                      String strg2 = strGrade2
                          .replaceAll("th", "")
                          .replaceAll("st", "")
                          .replaceAll("rd", "")
                          .replaceAll("nd", "");
                      int diffrence = int.parse(strg2) - int.parse(strg1);
                      if (year1 == (new DateTime.now().year + 1).toString()) {
                        year2 = s;
                        stryear2 = year2;
                      } else {
                        if (int.parse(yearList[1]) <=
                            (int.parse(s) + (diffrence + 1))) {
                          if (int.parse(yearList[1]) <
                              (int.parse(s) + (diffrence + 1))) {
                            year2 = toYearList[1].toString();
                            stryear2 = year2;
                          } else {
                            year2 = yearList[1].toString();
                            stryear2 = year2;
                          }
                        } else {
                          year2 = (int.parse(s) + (diffrence + 1)).toString();
                          stryear2 = year2;
                        }
                      }*/
                    });
                  }
                })));

    final yearUi2 = PaddingWrap.paddingfromLTRB(
        0.0,
        0.0,
        16.0,
        0.0,
        Container(
            height: 28.0,
            padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
            decoration: BoxDecoration(
                border: Border(
                    bottom:
                        BorderSide(color: ColorValues.DARK_GREY, width: 1.0))),
            width: double.infinity,
            child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                    hint: Text(
                      stryear2,
                      style: TextStyle(
                          fontSize: 15.0,
                          fontFamily: Constant.TYPE_CUSTOMREGULAR,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    ),
                    value: year2,
                    items: dropdownMenutoYear,
                    onChanged: (s) {
                      if (year1 == null) {
                        ToastWrap.showToast(
                            MessageConstant.SELECT_FROM_DATE_VAL, context);
                      } else {
                        if (int.parse(year1) <= int.parse(s)) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            isPresent = false;
                            year2 = s;
                            stryear2 = s;
                          });
                        } else {
                          ToastWrap.showToast(
                              MessageConstant.TO_DATE_GRATER_THAN_FROM_DATE_VAL,
                              context);
                        }
                      }
                    }))));
//-------------------------------------Text Input Fields Ui -----------------------------------
    final cityUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
          maxLength: 200,
          controller: cityController,
          cursorColor: Constant.CURSOR_COLOR,
          textCapitalization: TextCapitalization.sentences,
          style: TextStyle(
              color: ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          decoration: InputDecoration(
            hintText: 'e.g.,  York',
            labelText: "City",
            contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            errorStyle: Util.errorTextStyle,
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
            ),
            labelStyle: TextStyle(
                color: ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            counterText: "",
            fillColor: Colors.transparent,
            /*suffixIcon:  GestureDetector(
                        child:  Icon(
                          Icons.arrow_drop_down,
                        ),
                      )*/
          ),
          validator: (val) =>
              val.trim().isEmpty ? MessageConstant.ENTER_CITY_VAL : null,

          //onSaved: (val) => strCity = val,
        )));

    /* final descriptrionUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
         Container(
            child:  TextFormField(
          keyboardType: TextInputType.text,
          controller: descControler,
          maxLines: null,
          cursorColor: Constant.CURSOR_COLOR,
          style:  TextStyle(
              color:  ColorValues.HEADING_COLOR_EDUCATION,
              fontSize: 16.0,
              fontFamily: Constant.TYPE_CUSTOMREGULAR),
          textCapitalization: TextCapitalization.sentences,
          decoration:  InputDecoration(
            contentPadding: const EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
            hintText: 'Enter Here',
            labelText: "Description",
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: ColorValues.DARK_GREY,width: 1.0),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(
                  color: ColorValues.DARK_GREY,width: 1.0),
            ),
            labelStyle:  TextStyle(
                color:  ColorValues.GREY_TEXT_COLOR,
                fontFamily: Constant.TYPE_CUSTOMREGULAR),
            counterText: "",
            fillColor: Colors.transparent,
          ),
        )));*/

    Text getTextLabel(txt, size, color, fontWeight) {
      return Text(
        txt,
        style: TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final degreeUi = PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        13.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strDegree == null && inactivedeg == null
                ? Container(
                    height: 10.0,
                  )
                : PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    0.0,
                    getTextLabel("Degree", 11.0, ColorValues.GREY_TEXT_COLOR,
                        FontWeight.normal)),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        hint: Text(
                          inactivedeg != null ? inactivedeg : "Degree",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: strDegree,
                        items: dropdownCollegeDegree,
                        onChanged: (s) {
                          setState(() {
                            strDegree = s;
                            if (s == 'Other') {
                              isOtherSelected = true;
                              isProfessionalCertificatesSelected = false;
                            } else if (s == 'Professional Certificate') {
                              isOtherSelected = false;
                              isProfessionalCertificatesSelected = true;
                            } else {
                              isOtherSelected = false;
                              isProfessionalCertificatesSelected = false;
                            }
                          });
                        }))),
          ],
        ));

    final degreeYearUi = PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        13.0,
        0.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strDegreeYear == null
                ? Container(
                    height: 10.0,
                  )
                : PaddingWrap.paddingfromLTRB(
                    0.0,
                    10.0,
                    0.0,
                    0.0,
                    getTextLabel("Class", 11.0, ColorValues.GREY_TEXT_COLOR,
                        FontWeight.normal)),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        hint: Text(
                          "Class",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: strDegreeYear,
                        items: dropdownCollegeYear,
                        onChanged: (s) {
                          setState(() {
                            strDegreeYear = s;
                          });
                        }))),
          ],
        ));

    final graduationYearUi = PaddingWrap.paddingfromLTRB(
        13.0,
        0.0,
        13.0,
        20.0,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            strGraduationYear != '' && strGraduationYear != 'Graduation Year'
                ? getTextLabel("Graduation Year", 11.0,
                    ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                : getTextLabel(
                    "", 11.0, ColorValues.GREY_TEXT_COLOR, FontWeight.normal),
            Container(
                height: 28.0,
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 5.0),
                decoration: BoxDecoration(
                    border: Border(
                        bottom: BorderSide(
                            color: ColorValues.DARK_GREY, width: 1.0))),
                width: double.infinity,
                child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                        hint: Text(
                          "Graduation Year",
                          style: TextStyle(
                              fontFamily: Constant.TYPE_CUSTOMREGULAR,
                              color: ColorValues.GREY_TEXT_COLOR),
                        ),
                        value: graduationYear,
                        items: dropdownGraduationYear,
                        onChanged: (s) {
                          setState(() {
                            FocusScope.of(context)
                                .requestFocus(new FocusNode());
                            graduationYear = s;
                            strGraduationYear = s;
                          });
                        }))),
          ],
        ));

    final otherDegreeUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 100,
              controller: otherDegreeController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                errorStyle: Util.errorTextStyle,
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Other',
                labelText: "Other",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) => val.trim().isEmpty
                  ? MessageConstant.SELECT_Other_DEGREE_VAL
                  : null,
              onSaved: (val) => strOtherDegree = val,
            )));
    final professionalCertificatesDegreeUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 200,
              controller: professionalCertificatesDegreeController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                errorStyle: Util.errorTextStyle,
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Certification Name',
                labelText: "Certification Name",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) => val.trim().isEmpty
                  ? MessageConstant.SELECT_professional_Certificates_DEGREE_VAL
                  : null,
              onSaved: (val) => strProfessionCertificateDegree = val,
            )));
    final majorUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 200,
              controller: majorController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                errorStyle: Util.errorTextStyle,
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Major',
                labelText: "Major",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) => strDegree != null &&
                      strDegree != '' &&
                      strDegree != 'null' &&
                      val.trim().isEmpty
                  ? MessageConstant.SELECT_MAJOR_VAL
                  : null,
              onSaved: (val) => strMajor = val,
            )));
    final minorUi = PaddingWrap.paddingfromLTRB(
        13.0,
        15.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.visiblePassword,
              maxLength: 200,
              controller: minorController,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                errorStyle: Util.errorTextStyle,
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'Minor',
                labelText: "Minor",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              /*validator: (val) =>
              val.trim().isEmpty ? MessageConstant.SELECT_MINOR_VAL : null,*/
              onSaved: (val) => strMinor = val,
            )));

    final gpaFieldUi = PaddingWrap.paddingfromLTRB(
        13.0,
        0.0,
        0.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.done,

              maxLength: 10,
              focusNode: gpaFocus,
              controller: obGpaController,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              inputFormatters: [
                WhitelistingTextInputFormatter(RegExp(r'^\d+\.?\d{0,2}')),
              ],
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                counterStyle:
                TextStyle(fontFamily: Constant.TYPE_CUSTOMREGULAR),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                  BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                hintText: 'GPA',
                labelText: "GPA",
                errorStyle: Util.errorTextStyle,
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              validator: (val) {
                return val
                    .trim()
                    .length == 0
                    ? null
                    : !ValidationWidget.isValidaGPA(val)
                    ? MessageConstant.ENTER_gpa_out_of_less
                    : null ;
              },
              onSaved: (val) => obtGPA = val,
            )));

    final totalFieldUi = PaddingWrap.paddingfromLTRB(
        6.0,
        0.0,
        13.0,
        0.0,
        Container(
            padding: EdgeInsets.all(0.0),
            child: TextFormField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.done,
              maxLength: 10,
              focusNode: togpaFocus,
              controller: totGpaController,
              style: TextStyle(
                  color: ColorValues.HEADING_COLOR_EDUCATION,
                  fontSize: 16.0,
                  fontFamily: Constant.TYPE_CUSTOMREGULAR),
              decoration: InputDecoration(
                enabledBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide:
                      BorderSide(color: ColorValues.DARK_GREY, width: 1.0),
                ),
                errorStyle: Util.errorTextStyle,
                hintText: '',
                labelText: "GPA Out of",
                contentPadding: EdgeInsets.fromLTRB(0.0, 5.0, 5.0, 5.0),
                labelStyle: TextStyle(
                    color: ColorValues.GREY_TEXT_COLOR,
                    fontFamily: Constant.TYPE_CUSTOMREGULAR),
                counterText: "",
                fillColor: Colors.transparent,
              ),
              /* validator: (val) {
                return val.trim().isEmpty && obtGPA.trim().isNotEmpty ? MessageConstant.ENTER_out_of_VAL
:
                null;
              },*/
              onSaved: (val) => totGPA = val,
            )));

    final getDateFromToUI = PaddingWrap.paddingfromLTRB(
        13.0,
        20.0,
        0.0,
        0.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          mainAxisAlignment: MainAxisAlignment.start,
          textBaseline: TextBaseline.ideographic,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  year1 != null
                      ? getTextLabel("Date From", 11.0,
                          ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                      : getTextLabel("", 11.0, ColorValues.GREY_TEXT_COLOR,
                          FontWeight.normal),
                  yearUi1
                ],
              ),
              flex: 4,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  year2 != null
                      ? getTextLabel("Date To", 11.0,
                          ColorValues.GREY_TEXT_COLOR, FontWeight.normal)
                      : getTextLabel("", 11.0, ColorValues.GREY_TEXT_COLOR,
                          FontWeight.normal),
                  yearUi2
                ],
              ),
              flex: 4,
            ),
          ],
        ));

    final getDateFromToCheckbox = PaddingWrap.paddingfromLTRB(
        0.0,
        8.0,
        0.0,
        0.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[],
              ),
              flex: 5,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                          child: Image.asset(
                            isPresent
                                ? "assets/newDesignIcon/login/check.png"
                                : "assets/newDesignIcon/login/uncheck.png",
                            width: 25.0,
                            height: 25.0,
                          )),
                      onTap: () {
                        if (isPresent)
                          isPresent = false;
                        else
                          isPresent = true;
                        setState(() {
                          isPresent;
                          year2 = null;
                          stryear2 = "";
                        });
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0.0, 3.0, 0.0, 0.0),
                      child: Container(
                          child: TextViewWrap.textView(
                              "Ongoing   ",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontWeight.normal)),
                    ),
                    flex: 0,
                  )
                ],
              ),
              flex: 5,
            )
          ],
        ));

    final getCGPAUI = PaddingWrap.paddingfromLTRB(
        0.0,
        20.0,
        0.0,
        20.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          mainAxisAlignment: MainAxisAlignment.start,
          textBaseline: TextBaseline.ideographic,
          children: <Widget>[
            Expanded(
              child: gpaFieldUi,
              flex: 4,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child:  totalFieldUi,//totalFieldUi,
              flex: 4,
            ),
          ],
        ));

    final getCGPAWeightCheckbox = PaddingWrap.paddingfromLTRB(
        0.0,
        8.0,
        0.0,
        30.0,
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[],
              ),
              flex: 5,
            ),
            Expanded(
              child: Container(),
              flex: 1,
            ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Expanded(
                    child: InkWell(
                      child: Padding(
                          padding: EdgeInsets.fromLTRB(5.0, 0.0, 0.0, 0.0),
                          child: Image.asset(
                            isWeighted
                                ? "assets/newDesignIcon/login/check.png"
                                : "assets/newDesignIcon/login/uncheck.png",
                            width: 25.0,
                            height: 25.0,
                          )),
                      onTap: () {
                        if (isWeighted)
                          isWeighted = false;
                        else
                          isWeighted = true;
                        setState(() {
                          isWeighted;
                        });
                      },
                    ),
                    flex: 0,
                  ),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0.0, 3.0, 0.0, 0.0),
                      child: Container(
                          child: TextViewWrap.textView(
                              "Weighted",
                              TextAlign.start,
                              ColorValues.HEADING_COLOR_EDUCATION,
                              16.0,
                              FontWeight.normal)),
                    ),
                    flex: 0,
                  )
                ],
              ),
              flex: 5,
            )
          ],
        ));

    //------------------------------------Button Ui nd Logic Implementation-----------------------------
    /*bool validatioCheck() {
      if (strInstiute.length <= 0) {
        ToastWrap.showToast(MessageConstant.ENTER_INSTITUTE_NAME_VAL, context);
        return false;
      } else if (strGrade1 == "" || strGrade1 == "Select Grade") {
        ToastWrap.showToast(MessageConstant.SELECT_GRAD_VAL, context);
        return false;
      } else if (strGrade2 == "" || strGrade2 == "Select Grade") {
        ToastWrap.showToast(MessageConstant.SELECT_GRAD_VAL, context);
        return false;
      } else if (stryear1 == "" || stryear1 == "Select Year") {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        return false;
      } else if ((stryear2 == "" || stryear2 == "Select Year") &&
          (!isPresent)) {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        return false;
      }
      return true;
    }*/
    bool validatioCheck() {
      if (strInstiute.length <= 0) {
        ToastWrap.showToast(MessageConstant.ENTER_INSTITUTE_NAME_VAL, context);
        isReadyForApiCall = false;
        return false;
      } else if (stryear1 == "" || stryear1 == "Select Year") {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        isReadyForApiCall = false;
        return false;
      }
      /*else if (stryear2 == "" || stryear2 == "Select Year") {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        isReadyForApiCall = false;
        return false;
      }*/
      else if ((stryear2 == "" || stryear2 == "Select Year") && (!isPresent)) {
        ToastWrap.showToast(MessageConstant.SELECT_YEAR_VAL, context);
        isReadyForApiCall = false;
        return false;
      } else if (educationInit == "School") {
        if (strGrade1 == "" || strGrade1 == "Select Grade") {
          ToastWrap.showToast(MessageConstant.SELECT_GRAD_VAL, context);
          isReadyForApiCall = false;
          return false;
        } else if (strGrade2 == "" || strGrade2 == "Select Grade") {
          ToastWrap.showToast(MessageConstant.SELECT_GRAD_VAL, context);
          isReadyForApiCall = false;
          return false;
        }
      } else {
        //for remaining college fields
        /*if (strDegree == "" || strDegree == "Degree") {
          ToastWrap.showToast(MessageConstant.SELECT_Degree_VAL, context);
          isReadyForApiCall = false;
          return false;
        } else */
        if (strDegreeYear == "" || strDegreeYear == null) {
          ToastWrap.showToast(MessageConstant.SELECT_degree_year_VAL, context);
          isReadyForApiCall = false;
          return false;
        }
        /* else if (strGraduationYear == "" || strGraduationYear == "Graduation Year") {
          ToastWrap.showToast(MessageConstant.SELECT_GRADUATION_YEAR_VAL, context);
          isReadyForApiCall = false;
          return false;
        }*/
      }

      isReadyForApiCall = true;
      return true;
    }

    void _checkValidation() async {
      strInstiute = _searchQuery.text;
      final form = _formKey.currentState;
      form.save();
      if (form.validate()) {
        if (validatioCheck()) {
          try {
            if (imagePath != null) {
              CustomProgressLoader.showLoader(context);
              Timer _timer = Timer(const Duration(milliseconds: 400), () async {
                strAzureUploadPath = await uploadImgOnAzure(imagePath
                    .toString()
                    .replaceAll("File: ", "")
                    .replaceAll("'", "")
                    .trim());
                editEducation();
              });
            } else {
              CustomProgressLoader.showLoader(context);
              editEducation();
            }
            /* } else {
              ToastWrap.showToast(
                  MessageConstant.DONT_THINK_YOU_MAKE_TENURE_VAL, context);
            }*/
          } catch (e) {
            //  CustomProgressLoader.cancelLoader(context);
          }
        }
      } else {
        print("Failure 00");
      }
    }

    Center getEditButtton() {
      return Center(
          child: Container(
        height: 35.0,
        width: 150.0,
        color: ColorValues.BLUE_COLOR_BOTTOMBAR,
        child: InkWell(
          child: Padding(
            padding: EdgeInsets.fromLTRB(0.0, 8.0, 0.0, 0.0),
            child: TextViewWrap.textView("SAVE", TextAlign.center,
                ColorValues.WHITE, 14.0, FontWeight.normal),
          ),
          onTap: () {
            _checkValidation();
          },
        ),
      ));
    }

    void skipOnClick() {
      Navigator.pop(context);
//    Navigator.of(context).push(new MaterialPageRoute(
//        builder: (BuildContext context) =>  ACCompetenciesWidget(
//            sasToken,
//            widget.institute.,
//            studModel.lastName == "" || studModel.lastName == "null"
//                ? studModel.firstName
//                : studModel.firstName + " " + studModel.lastName)));
    }

    void onNextClick() {
      // make Api Call
      _checkValidation();
    }

    void onBackwordClick() {
      Navigator.pop(context);
    }

    Container getBottomBar() {
      return Container(
          child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          InkWell(
            child: Padding(
                padding: EdgeInsets.fromLTRB(13.0, 0.0, 0.0, 20.0),
                child: Image.asset(
                  'assets/newDesignIcon/parentProfile/backword.png',
                  height: 45.0,
                  width: 45.0,
                )),
            onTap: () {
              onBackwordClick();
            },
          ),
          Container(
              child: Padding(
                  padding: EdgeInsets.only(
                      left: 0.0, top: 0.0, right: 0.0, bottom: 20.0),
                  child: Container(
                      height: 32.0,
                      child: FlatButton(
                        onPressed: () {
                          _checkValidation();
                          //onNextClick();
                        },
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(0)),
                        color: ColorValues.BLUE_COLOR,
                        child: Row(
                          // Replace with a Row for horizontal icon + text
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 35.0),
                              child: Text('SAVE',
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontFamily: Constant.TYPE_CUSTOMREGULAR,
                                      color: Colors.white)),
                            ),
                          ],
                        ),
                      )))),
          InkWell(
            child: Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 13.0, 20.0),
                child: SizedBox(
                  height: 45.0,
                  width: 45.0,
                )),
            onTap: () {
              //_checkValidation();
            },
          ),
        ],
      ));
    }

    // Build a Form widget using the _formKey we created above
    getSchoolView() {
      return PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          0.0,
          10.0,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              PaddingWrap.paddingfromLTRB(
                  13.0,
                  10.0,
                  0.0,
                  0.0,
                  Container(
                      width: 125.0,
                      child: imagePath == null && strAzureUploadPath == ""
                          ? imageSelectionView()
                          : isImageSelectedView())),
              getOrganizationUi(),
              /*   PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  15.0,
                                  0.0,
                                  0.0,
                                  getTextLabel("City", 16.0, Colors.grey,
                                      FontWeight.normal)),*/
              cityUi,
              //descriptrionUi,
              //get
              PaddingWrap.paddingfromLTRB(
                  13.0,
                  20.0,
                  0.0,
                  0.0,
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            grade1 != null
                                ? getTextLabel(
                                    "Grade From",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal)
                                : getTextLabel(
                                    "",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal),
                            gradeUi1
                          ],
                        ),
                        flex: 4,
                      ),
                      Expanded(
                        child: Container(),
                        flex: 1,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            grade2 != null
                                ? getTextLabel(
                                    "Grade To",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal)
                                : getTextLabel(
                                    "",
                                    11.0,
                                    ColorValues.GREY_TEXT_COLOR,
                                    FontWeight.normal),
                            gradeUi2
                          ],
                        ),
                        flex: 4,
                      ),
                    ],
                  )),
              getDateFromToUI,
              getDateFromToCheckbox,

              getCGPAUI,
              getCGPAWeightCheckbox,
            ],
          ));
    }

    getCollegeView() {
      return PaddingWrap.paddingfromLTRB(
          0.0,
          10.0,
          0.0,
          10.0,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              PaddingWrap.paddingfromLTRB(
                  13.0,
                  10.0,
                  0.0,
                  0.0,
                  Container(
                      width: 125.0,
                      child: imagePath == null && strAzureUploadPath == ""
                          ? imageSelectionView()
                          : isImageSelectedView())),
              getCollegeOrganizationUi(),
              /*   PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  15.0,
                                  0.0,
                                  0.0,
                                  getTextLabel("City", 16.0, Colors.grey,
                                      FontWeight.normal)),*/
              cityUi,
              //descriptrionUi,

              //Degree
              degreeUi,
              isOtherSelected ? otherDegreeUi : Container(),
              isProfessionalCertificatesSelected
                  ? professionalCertificatesDegreeUi
                  : Container(),

              //major and minor
              !isProfessionalCertificatesSelected ? majorUi : Container(),
              !isProfessionalCertificatesSelected ? minorUi : Container(),
              degreeYearUi,

              //Date UI
              getDateFromToUI,
              getDateFromToCheckbox,

              //GPA UI
              getCGPAUI,
             getCGPAWeightCheckbox,

              graduationYearUi,
            ],
          ));
    }

    //-------------------------------------Main Ui ------------------------------------------
    final double statusBarHeight = MediaQuery.of(context).padding.top;
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(new FocusNode());
        },
        child: Scaffold(
            backgroundColor: ColorValues.SCREEN_BG_COLOR,
            body: FormKeyboardActions(
                nextFocus: false,
                keyboardActionsPlatform: KeyboardActionsPlatform.IOS,
                //optional
                keyboardBarColor: Colors.grey[200],
                //optional
                actions: [
                  KeyboardAction(
                    focusNode: gpaFocus,
                  ),
                  KeyboardAction(
                    focusNode: togpaFocus,
                  ),
                ],
                child: Column(
                  children: <Widget>[
                    /*Padding(
                  padding: const EdgeInsets.fromLTRB(0.0, 80, 0, 10),
                  child:  Image.asset("assets/profile/student/st13.png",
                      height: 10.0, width: 100.0, fit: BoxFit.fitHeight),
                ),
                 Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 30.0, 0.0, 0.0),
                    child:  Image.asset(
                      "assets/profile/student/add_education.png",
                      height: 45.0,
                      width: 35.0,
                    )),
                 Padding(
                    padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 0.0),
                    child:  Text(
                      "Edit Education",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontFamily: Constant.customRegular,
                          fontSize: 15.0,
                          fontWeight: FontWeight.normal,
                          color: ColorValues.HEADING_COLOR_EDUCATION),
                    )),*/
                    /*Align(
                  alignment: Alignment.centerLeft,
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: statusBarHeight + 20, right: 13.0, left: 13.0),
                    child:  Text(
                      //"Step 3 of 7",
                      "",
                      style:  TextStyle(
                          fontSize: 15.0,
                          fontFamily: Constant.customRegular,
                          color:  ColorValues.HEADING_COLOR_EDUCATION),
                    ),
                  ),
                ),*/
                    Padding(
                      padding: EdgeInsets.only(
                          top: statusBarHeight + 20,
                          left: 13.0,
                          right: 13.0,
                          bottom: 7),
                      child: Center(
                        child: Image.asset(
                            "assets/progress_indecator/indicator_step3.png",
                            height: 26.0,
                            width: 300.0,
                            fit: BoxFit.fitWidth),
                      ),
                    ),
                    Expanded(
                      child: ListView(
                        children: <Widget>[
                          // CustomViews.getSepratorLine(),
                          Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                              child: Image.asset(
                                "assets/profile/student/add_education.png",
                                height: 45.0,
                                width: 35.0,
                              )),

                          Padding(
                              padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "Edit Education",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontFamily: Constant.customRegular,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.bold,
                                    color: ColorValues.HEADING_COLOR_EDUCATION),
                              )),
                          Form(
                            key: _formKey,
                            child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              10.0,
                              educationInit == "School"
                                  ? getSchoolView()
                                  : getCollegeView(),
                              /*Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                 Align(
                                    alignment: Alignment.center,
                                    child: PaddingWrap.paddingfromLTRB(
                                        0.0,
                                        10.0,
                                        0.0,
                                        0.0,
                                         Container(
                                            width: 125.0,
                                            child: strAzureUploadPath == "" &&
                                                    imagePath == null
                                                ? imageSelectionView()
                                                : isImageSelectedView()))),
                                */ /*  getTextLabel("Institute", 16.0, Colors.grey,
                                  FontWeight.normal),*/ /*
                                getOrganizationUi(),
                                */ /*  PaddingWrap.paddingfromLTRB(
                                  0.0,
                                  15.0,
                                  0.0,
                                  0.0,
                                  getTextLabel("City", 16.0, Colors.grey,
                                      FontWeight.normal)),*/ /*
                                cityUi,
                                //descriptrionUi,
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    0.0,
                                    0.0,
                                     Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              getTextLabel(
                                                  "Grade From",
                                                  11.0,
                                                   ColorValues.GREY_TEXT_COLOR,
                                                  FontWeight.normal),
                                              gradeUi1
                                            ],
                                          ),
                                          flex: 4,
                                        ),
                                         Expanded(
                                          child:  Container(),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              getTextLabel(
                                                  "Grade To",
                                                  11.0,
                                                   ColorValues.GREY_TEXT_COLOR,
                                                  FontWeight.normal),
                                              gradeUi2
                                            ],
                                          ),
                                          flex: 4,
                                        ),
                                      ],
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    20.0,
                                    0.0,
                                    0.0,
                                     Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              getTextLabel(
                                                  "Date From",
                                                  11.0,
                                                   ColorValues.GREY_TEXT_COLOR,
                                                  FontWeight.normal),
                                              yearUi1
                                            ],
                                          ),
                                          flex: 4,
                                        ),
                                         Expanded(
                                          child:  Container(),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              getTextLabel(
                                                  "Date To",
                                                  11.0,
                                                   ColorValues.GREY_TEXT_COLOR,
                                                  FontWeight.normal),
                                              yearUi2
                                            ],
                                          ),
                                          flex: 4,
                                        ),
                                      ],
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    8.0,
                                    0.0,
                                    8.0,
                                     Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: <Widget>[
                                         Expanded(
                                          child:  Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[],
                                          ),
                                          flex: 5,
                                        ),
                                         Expanded(
                                          child:  Container(),
                                          flex: 1,
                                        ),
                                         Expanded(
                                          child:  Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                               Expanded(
                                                child:  InkWell(
                                                  child: Padding(
                                          padding:   EdgeInsets.fromLTRB(
                                              5.0, 0.0, 0.0, 0.0),
                                          child:  Image.asset(
                                                    isPresent
                                                        ? "assets/newDesignIcon/login/check.png"
                                                        : "assets/newDesignIcon/login/uncheck.png",
                                                    width: 25.0,
                                                    height: 25.0,
                                                  )),
                                                  onTap: () {
                                                    if (isPresent)
                                                      isPresent = false;
                                                    else
                                                      isPresent = true;
                                                    setState(() {
                                                      isPresent;
                                                      year2 = null;
                                                      stryear2 = "";
                                                    });
                                                  },
                                                ),
                                                flex: 0,
                                              ),
                                               Expanded(
                                                child: Container(
                                                  padding:
                                                       EdgeInsets.fromLTRB(
                                                          5.0, 3.0, 0.0, 0.0),
                                                  child:  Container(
                                                      child: TextViewWrap.textView(
                                                          "Ongoing   ",
                                                          TextAlign.start,
                                                           ColorValues.HEADING_COLOR_EDUCATION,
                                                          16.0,
                                                          FontWeight.normal)),
                                                ),
                                                flex: 0,
                                              )
                                            ],
                                          ),
                                          flex: 5,
                                        )
                                      ],
                                    )),
                                */ /*new Padding(
                                    padding: EdgeInsets.fromLTRB(
                                        0.0, 30.0, 0.0, 0.0),
                                    child: getEditButtton())*/ /*
                              ],
                            )*/
                            ),
                          )
                        ],
                      ),
                      flex: 1,
                    ),
                    Container(
                      child: getBottomBar(),
                    )
                  ],
                ))));
  }
}
