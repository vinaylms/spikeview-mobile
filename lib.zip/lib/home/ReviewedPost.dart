

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/help_button_widget.dart';

class ReviewedPostScreen extends StatefulWidget {
  @override
  _GenerateState createState() => _GenerateState();
}

class _GenerateState extends State<ReviewedPostScreen> {

  Future<bool> _onWillPop() {
    Navigator.pop(context,'pop');
  }
  @override
  Widget build(BuildContext context) {

    return WillPopScope(
      onWillPop:_onWillPop,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        bottomSheet: postButton(),
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Container(
              height: double.infinity,
              width: double.infinity,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/generateScript/script_background.png"),
                      fit: BoxFit.fill)),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 40, left: 20, right: 20),
              child: SizedBox(
                height: 100,
                width: double.infinity,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context,'pop');
                      },
                      child: Image.asset(
                        "assets/generateScript/back.png",
                        height: 32.0,
                        width: 32.0,
                      ),
                    ),
                    const HelpButtonWidget(),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Container(
                margin: const EdgeInsets.only(top: 125),
                child:  Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: Container(
                    transform: Matrix4.translationValues(0.0, -125.0, 0.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SvgPicture.asset(
                              "assets/feed/info.svg",
                              semanticsLabel: 'info Icon'
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 28,right: 28,top: 10),
                            child: Text(
                                AppConstants.stringConstant.spikeCommunityReviewed,
                                textAlign: TextAlign.center,
                                style: AppConstants.txtStyle.heading16600LatoRegularLightPurple
                            ),
                          ),
                        ]),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
  postButton() {
    return Container(
        color: AppConstants.colorStyle.white,
        child: Padding(
            padding: EdgeInsets.only(top: 10.0),
            child: Container(
                margin: EdgeInsets.only(left: 20,right: 20,bottom: 70),
                height: 44.0,
                child: FlatButton(
                  onPressed: () {
                  },
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  color: AppConstants.colorStyle.lightBlue,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(AppConstants.stringConstant.post,
                          style: AppConstants.txtStyle.heading18600LatoRegularWhite),
                    ],
                  ),
                ))));
  }
}