import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';

import 'package:intl/intl.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/constant/ValidationWidget.dart';
import 'package:spike_view_project/group/model/GroupDetailModel.dart';

import 'package:spike_view_project/values/ColorValues.dart';

// Create a Form Widget
class InviteByEmailWidget extends StatefulWidget {
  GroupDetailModel groupDetailModel;

  InviteByEmailWidget(this.groupDetailModel);

  @override
  InviteByEmailWidgetState createState() {
    return  InviteByEmailWidgetState();
  }
}

class InviteByEmailWidgetState extends State<InviteByEmailWidget> {
  final _formKey = GlobalKey<FormState>();

  String strFirstName, strLastName, strEmail;
  List<String> dataList =  List<String>();



  //--------------------------Api Calling ------------------

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Future apiCallForInvite() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "members": [],
          "groupId": int.parse(widget.groupDetailModel.groupId),
          "firstName": strFirstName,
          "lastName": strLastName,
          "email": strEmail,
          "invitedBy": widget.groupDetailModel.adminName
        };
        Response response = await  ApiCalling().apiCallPostWithMapData(
            context, Constant.ENDPOINT_INVITE_BY_EMAIL, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
          ToastWrap.showToast(msg,context);
              Navigator.pop(context);
            }else{
              ToastWrap.showToast(msg,context);
            }
          }
        }
      } else {
        ToastWrap.showToast(MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR,context);
      }
    } catch (e) {
      e.toString();
    }
  }

  bool isName(String em) {
    return RegExp(r"^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$").hasMatch(em.trim());
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    // Build a Form widget using the _formKey we created above
    Text getTextLabel(txt, size, color, fontWeight) {
      return  Text(
        txt,
        style:
             TextStyle(fontSize: size, color: color, fontWeight: fontWeight),
      );
    }

    final firstName =  Container(
        child:  TextFormField(
      keyboardType: TextInputType.text,
      maxLength: 20,
      decoration:  InputDecoration(
        filled: true,
        hintText: MessageConstant.INVITE_EMAIL_FIRST_NAME,
        labelText: MessageConstant.INVITE_EMAIL_FIRST_NAME,
        errorStyle: Util.errorTextStyle,
        labelStyle:  TextStyle(color:  ColorValues.TEXT_LIGHT_GREY),
        counterText: "",
        hintStyle:  TextStyle(color:  Color(0XFFB1B4C0)),
        fillColor: ColorValues.hintColor,

      ),
      validator: (val) => val.trim().length == 0
          ? MessageConstant.ENTER_FIRST_NAME_VAL
          : !isName(val) ? MessageConstant.FIRST_NAME_CONTAINS_ALPHABET_VAL : null,
      onSaved: (val) => strFirstName = val,
    ));

    final lastName =  Container(
        child:  TextFormField(
      keyboardType: TextInputType.text,
      maxLength: 20,
      decoration:  InputDecoration(
        filled: true,
        hintText: MessageConstant.INVITE_EMAIL_LAST_NAME,
        labelText: MessageConstant.INVITE_EMAIL_LAST_NAME,
        errorStyle: Util.errorTextStyle,
        labelStyle:  TextStyle(color:  ColorValues.TEXT_LIGHT_GREY),
        counterText: "",
        hintStyle:  TextStyle(color:  ColorValues.hintColor),
        fillColor: Colors.transparent,

      ),
      validator: (val) => val.trim().length == 0
          ? MessageConstant.ENTER_LAST_NAME_VAL
          : !isName(val) ? MessageConstant.LAST_NAME_CONTAINS_ALPHABET_VAL: null,
      onSaved: (val) => strLastName = val,
    ));

    final email =  Container(
        child:  TextFormField(
      keyboardType: TextInputType.text,
      decoration:  InputDecoration(
        filled: true,
        hintText: "abc@xyz.com",
        labelText: MessageConstant.INVITE_EMAIL_EMAIL,
        errorStyle: Util.errorTextStyle,
        hintStyle:  TextStyle(color:  ColorValues.hintColor),
        labelStyle:  TextStyle(color:  ColorValues.TEXT_LIGHT_GREY),
        fillColor: Colors.transparent,

      ),
      validator: (val) => val.trim().length == 0
          ? MessageConstant.ENTER_EMAIL_VAL
          : !ValidationWidget.isEmail(val) ? MessageConstant.VALID_EMAIL_VAL: null,
      onSaved: (val) => strEmail = val,
    ));

    void _checkValidation() async {
      final form = _formKey.currentState;
      form.save();
      if (form.validate()) {
        try {
          apiCallForInvite();
        } catch (e) {
          CustomProgressLoader.cancelLoader(context);
        }
      } else {
        print("Failure 00");
      }
    }

    final submitButton = Padding(
        padding:
             EdgeInsets.only(left: 0.0, top: 30.0, right: 0.0, bottom: 0.0),
        child:  Container(
            height: 50.0,
            child: FlatButton(
              onPressed: _checkValidation,
              color:  ColorValues.BLUE_COLOR,
              child: Row(
                // Replace with a Row for horizontal icon + text
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(MessageConstant.INVITE_EMAIL_INVITE,
                      style: TextStyle(
                          fontFamily: Constant.TYPE_CUSTOMBOLD, color: Colors.white)),
                ],
              ),
            )));



    return  WillPopScope(
        onWillPop: () {
          Navigator.pop(context);
        },
        child:  GestureDetector(
            onTap: () {
              FocusScope.of(context).requestFocus(new FocusNode());
            },
            child:  Scaffold(
                appBar:  AppBar(
                  automaticallyImplyLeading: false,
                  titleSpacing: 2.0,
                  brightness: Brightness.light,
                  leading:  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                       InkWell(
                        child: PaddingWrap.paddingfromLTRB(
                            5.0,
                            0.0,
                            0.0,
                            0.0,
                             Image.asset(
                              "assets/profile/post/back_arrow_blue.png",
                              height: 30.0,
                              width: 30.0,
                            )),
                        onTap: () {
                          Navigator.pop(context);
                        },
                      )
                    ],
                  ),
                  title:  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                       Text(
                        MessageConstant.INVITE_EMAIL_INVITE_MEMBERS_EMAIL,
                        style:  TextStyle(
                            color:  ColorValues.BLUE_COLOR),
                      )
                    ],
                  ),
                  backgroundColor: Colors.white,
                ),
                body:  Theme(
                    data:  ThemeData(hintColor: Colors.grey[300]),
                    child:  Stack(
                      children: <Widget>[
                         Positioned(
                          bottom: 80.0,
                          right: 0.0,
                          left: 0.0,
                          top: 0.0,
                          child: ListView(
                            children: <Widget>[
                              Form(
                                key: _formKey,
                                child: PaddingWrap.paddingAll(
                                  10.0,
                                   Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[

                                        firstName,

                                        lastName,

                                        email,
                                      ]),
                                ),
                              )
                            ],
                          ),
                        ),
                         Positioned(
                            bottom: 0.0,
                            right: 0.0,
                            left: 0.0,
                            child:  Row(
                              children: <Widget>[
                                 Expanded(
                                  child: submitButton,
                                  flex: 1,
                                ),
                              ],
                            ))
                      ],
                    )))));
  }
}
