import 'dart:async';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ButtonView.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

import '../main.dart';

class NewReceivedWidget extends StatefulWidget {
  @override
  State<NewReceivedWidget> createState() => _NewReceivedWidgetState();
}

class _NewReceivedWidgetState extends State<NewReceivedWidget>
    with AutomaticKeepAliveClientMixin {
  BuildContext context;
  ScrollController _scrollController = ScrollController();
  TextEditingController edtController = TextEditingController();
  List<RequestedTagModel> tagList = List();
  List<RequestedTagModel> searchtagList = List();
  int listType;
  String statusIndex, searchName = "";
  int skip = 0;
  int searchCount = 0;
  SharedPreferences prefs;
  String userIdPref, roleId, dob, userProfilePath;
  StreamSubscription<dynamic> _streamSubscription;
  int diffrenceInDob = 0;

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.PARENT_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    userProfilePath = prefs.getString(UserPreference.PROFILE_IMAGE_PATH);
    dob = prefs.getString(UserPreference.DOB);
    if (dob != null && dob != 'null') {
      int millis = int.tryParse(dob);
      DateTime dobDate = DateTime.fromMillisecondsSinceEpoch(millis);
      diffrenceInDob = Util.currentAge(dobDate, 13);
    }
    setState(() {
      diffrenceInDob;
    });
    listType = 0;
    statusIndex = Constant.REQUESTED;
    apiToGetDetail();
  }

  Timer _timer;

  void _onSearch() {
    if (edtController.text.trim().isNotEmpty) {
      if (_timer?.isActive ?? false) {
        _timer?.cancel();
      }
      _timer = Timer(Duration(seconds: 1), () {
        skip = 0;
        isLoading = true;
        setState(() {});
        apiToGetDetail();
      });
    }
  }

  @override
  void initState() {
    _streamSubscription =
        SplashScreenState.syncDoneController.stream.listen((value) {
      print("value//////" + value.toString());
      print("SSS check Value ${value}");
      if (Constant.CONNECTIONS_PROFILE == value) {
        skip = 0;
        apiToGetDetail();
      }
    });

    getSharedPreferences();
    // TODO: implement initState
    super.initState();

    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        skip = skip + 1;

        print("No Index---- " + skip.toString());
        apiToGetDetail();
      }
    });
  }

  Future apiToGetDetail() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        isLoading = true;
        setState(() {
          isLoading;
        });
        searchCount = 0;
        print(Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
            userIdPref +
            "&status=" +
            statusIndex.toString() +
            "&roleId=" +
            roleId +
            "&skip=" +
            skip.toString());

        Response response = await ApiCalling().apiCall(
            context,
            Constant.ENDPOINT_CONNECTION_LIST_VIEW_ALL +
                userIdPref +
                "&status=" +
                statusIndex.toString() +
                "&roleId=" +
                roleId +
                "&skip=" +
                skip.toString() +
                "&name=" +
                searchName +
                "&limit=" +
                "10",
            "get");
        isLoading = false;
        if (searchName.isEmpty) {
          searchtagList.clear();
        } else {
          if (searchCount == 0) {
            searchtagList.clear();
            searchCount = 1;
          }
        }

        setState(() {
          isLoading;
        });

        print("-=------------ skip.toString()++++ " + skip.toString());
        print(response.toString());

        if (response != null) {
          if (response.statusCode == 200) {
            //  var parsedJson = json.decode(response.toString());

            String status = response.data[LoginResponseConstant.STATUS];
            if (status == "Success") {
              switch (listType) {
                case 0:
                  List<RequestedTagModel> tagListLocal = List();
                  tagListLocal = ParseJson.parseRequestedTagList(
                      response.data['result']); //['Requested']
                  if (searchName.isEmpty) {
                    for (int i = 0; i < tagList.length; i++) {
                      for (int j = 0; j < tagListLocal.length; j++) {
                        if (tagList[i].patner.userId ==
                            tagListLocal[j].patner.userId) {
                          tagListLocal.removeAt(j);
                        }
                      }
                    }
                  } else {
                    for (int i = 0; i < searchtagList.length; i++) {
                      for (int j = 0; j < tagListLocal.length; j++) {
                        if (searchtagList[i].userId == tagListLocal[j].userId) {
                          tagListLocal.removeAt(j);
                        }
                      }
                    }
                  }
                  if (searchName.isEmpty) {
                    tagList.addAll(tagListLocal);
                    searchtagList.addAll(tagList);
                    print("SSS 111 ${searchtagList.length}");
                  } else {
                    searchtagList.addAll(tagListLocal);
                    print("SSS 222 ${searchtagList.length}");
                  }

                  setState(() {
                    tagList;
                    searchtagList;
                  });
                  break;
              }

              if (tagList != null) {
                if (tagList.length > 0) {
                  prefs.setString(
                      UserPreference.ISACTIVE, tagList[0].userIsActive);
                }

                setState(() {
                  print("After Success Response");
                  tagList;
                  searchtagList;
                  // sendRequestList;
                  // pendingRequestList;
                  // recievedRequestList;
                  // peopleYouMayKnowList;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      isLoading = false;
      setState(() {
        isLoading;
      });
      e.toString();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  bool isNeedToRefresh = false;
  bool isLoading = true;
  SlidableController slidableCtrl = SlidableController();

  Widget build(BuildContext context) {
    this.context = context;
    return tagList.length > 0
        ? Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 10.0),
                child: SizedBox(
                  height: 40,
                  child: TextField(
                    textAlign: TextAlign.left,
                    controller: edtController,
                    onChanged: (value) {
                      searchName = value;
                      _onSearch();
                      // if (value.isNotEmpty) {
                      //   searchCount = 0;
                      //   apiToGetDetail();
                      // }
                    },
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: ColorValues.TAB_BACKGROUND_COLOR,
                      hintText: "Search connections",
                      hintStyle: TextStyle(
                          fontSize: 14,
                          fontFamily: Constant.latoRegular,
                          fontWeight: FontWeight.w400,
                          color: ColorValues.hintColor),
                      contentPadding:
                          EdgeInsets.fromLTRB(15.0, 10.0, 20.0, 10.0),
                      suffixIcon: IconButton(
                        onPressed: () {
                          if (edtController.text.trim() != "") {
                            apiToGetDetail();
                          }
                        },
                        icon: Image.asset(
                          "assets/newDesignIcon/connections/new_search.png",
                          height: 20,
                          width: 20,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10.0),
                        ),
                        borderSide:
                            BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(10.0),
                        ),
                        borderSide:
                            BorderSide(color: ColorValues.BORDER_COLOR_NEW),
                      ),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10.0),
                          ),
                          borderSide: new BorderSide(
                              color: ColorValues.BORDER_COLOR_NEW)),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: searchtagList.length > 0
                    ? ListView.builder(
                        controller: _scrollController,
                        itemCount: searchtagList.length,
                        padding: EdgeInsets.only(bottom: 10),
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              getListview(searchtagList[index], index, false,
                                  "", tagList.length),
                              const Padding(
                                padding: EdgeInsets.fromLTRB(20, 1, 20, 0),
                                child: Divider(
                                  thickness: 1,
                                  height: 0,
                                  color: Color(0xffE5EBF0),
                                ),
                              )
                            ],
                          );
                        },
                      )
                    : Center(
                        child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Image.asset(
                            "assets/newDesignIcon/icon/no_user_found.png",
                            height: 111.0,
                          ),
                          const SizedBox(height: 10),
                          BaseText(
                            text: 'No user found',
                            textColor: ColorValues.HEADING_COLOR_CHAT_1,
                            fontFamily: AppConstants.stringConstant.latoMedium,
                            fontWeight: FontWeight.w600,
                            fontSize: 18,
                            textAlign: TextAlign.center,
                            maxLines: 1,
                          ),
                        ],
                      )),
              ),
            ],
          )
        : isLoading
            ? Center(child: Container())
            : Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                          padding: EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                          child: Container(
                            width: 120.0,
                            height: 111.0,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: AssetImage(
                                    'assets/newDesignIcon/connections/man_to_guide.png',
                                  ),
                                  fit: BoxFit.cover),
                            ),
                          )),
                      Center(
                          child: Padding(
                        padding: const EdgeInsets.fromLTRB(20.0, 0, 20.0, 0),
                        child: Text(
                          "You don't have any pending connection requests.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: ColorValues.HEADING_COLOR_EDUCATION_1,
                              fontSize: 18.0,
                              fontFamily: Constant.latoRegular),
                        ),
                      )),
                    ],
                  ),
                ),
              );
  }

  Widget getListview(RequestedTagModel requestedTagModel, index,
      bool isSentRequest, status, int length) {
    return Slidable(
      controller: slidableCtrl,
      actionPane: SlidableDrawerActionPane(),
      actionExtentRatio: 0.18,
      child: InkWell(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, index == 0 ? 6 : 16, 20, 16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: ProfileImageView(
                  imagePath: Constant.IMAGE_PATH_SMALL +
                      ParseJson.getSmallImage(
                          requestedTagModel.patner.profilePicture),
                  placeHolderImage: requestedTagModel.patner.roleId == "4"
                      ? "assets/profile/partner_img.png"
                      : 'assets/profile/user_on_user.png',
                  height: 48.0,
                  width: 48.0,
                  onTap: () async {
                    if (requestedTagModel.patner.userId == userIdPref) {
                    } else {
                      Util.onTapImageTile(
                          tapedUserRole: requestedTagModel.patner.roleId,
                          partnerUserId: requestedTagModel.patner.userId,
                          context: context);
                    }
                  },
                ),
                flex: 0,
              ),
              Expanded(
                child: PaddingWrap.paddingfromLTRB(
                    10.0,
                    0.0,
                    0.0,
                    0.0,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: BaseText(
                                text: getName(null, requestedTagModel),
                                textColor:
                                    ColorValues.HEADING_COLOR_EDUCATION_1,
                                fontFamily:
                                    AppConstants.stringConstant.latoMedium,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                                maxLines: 1,
                                textAlign: TextAlign.start,
                              ),
                              flex: 0,
                            ),
                            Expanded(
                              flex: 0,
                              child: requestedTagModel.patner.roleId == "1"
                                  ? Util.getStudentBadge12New(
                                      requestedTagModel.patner.badge,
                                      requestedTagModel.patner.badgeImage)
                                  : Container(),
                            ),
                          ],
                        ),
                        requestedTagModel.patner.tagline == null ||
                                requestedTagModel.patner.tagline == "null" ||
                                requestedTagModel.patner.tagline == ""
                            ? Container(
                                height: 0.0,
                              )
                            : PaddingWrap.paddingfromLTRB(
                                0.0,
                                4.0,
                                0.0,
                                5.0,
                                TextViewWrap.textView(
                                  requestedTagModel.patner.tagline == null ||
                                          requestedTagModel.patner.tagline ==
                                              "null" ||
                                          requestedTagModel.patner.tagline == ""
                                      ? ""
                                      : requestedTagModel.patner.tagline,
                                  TextAlign.start,
                                  ColorValues.labelColor,
                                  14.0,
                                  FontWeight.normal,
                                ))
                      ],
                    )),
                flex: 1,
              ),
              Expanded(
                child: diffrenceInDob >= 13
                    ? Row(
                        children: <Widget>[
                          roleId == "2"
                              ? isSentRequest
                                  ? Text("")
                                  : ButtonView(
                                      btnName: 'Approve',
                                      borderColor:
                                          AppConstants.colorStyle.lightBlue,
                                      bgColor:
                                          AppConstants.colorStyle.box_bg_color,
                                      txtColor:
                                          AppConstants.colorStyle.lightBlue,
                                      onButtonTap: () {
                                        apiCallingForAccept(
                                            requestedTagModel.connectId,
                                            index,
                                            "Accepted",
                                            requestedTagModel.userIsActive);
                                      },
                                    )
                              : listType == 1
                                  ? new Container(
                                      height: 0.0,
                                    )
                                  : ButtonView(
                                      btnName: 'Approve',
                                      borderColor:
                                          AppConstants.colorStyle.lightBlue,
                                      bgColor:
                                          AppConstants.colorStyle.box_bg_color,
                                      txtColor:
                                          AppConstants.colorStyle.lightBlue,
                                      onButtonTap: () {
                                        apiCallingForAccept(
                                            requestedTagModel.connectId,
                                            index,
                                            "Accepted",
                                            requestedTagModel.userIsActive);
                                      },
                                    )
                        ],
                      )
                    : SizedBox(),
                flex: 0,
              ),
            ],
          ),
        ),
        onTap: () {
          /*    if (requestedTagModel.patner.userId == userIdPref) {
          } else {
            Util.onTapImageTile(
                tapedUserRole: requestedTagModel.patner.roleId,
                partnerUserId: requestedTagModel.patner.userId,
                context: context);
          }*/
        },
      ),
      secondaryActions: <Widget>[
        SlideAction(
          child: Text("Delete",
              style: TextStyle(
                  color: ColorValues.WHITE,
                  fontSize: 14.0,
                  fontFamily: Constant.latoRegular)),
          // color: ColorValues.Delete_lable_color,
          decoration: BoxDecoration(color: ColorValues.Delete_lable_color),
          onTap: () {
            print("------- Cancel Button");

            String name = requestedTagModel.patner.lastName == null ||
                    requestedTagModel.patner.lastName == "null" ||
                    requestedTagModel.patner.lastName == ""
                ? requestedTagModel.patner.firstName
                : requestedTagModel.patner.firstName +
                    " " +
                    requestedTagModel.patner.lastName;

            educationRemoveConfromationDialog(
                requestedTagModel.connectId, name, index);
          },
        ),
      ],
    );
  }

  void educationRemoveConfromationDialog(id, name, index) {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            msg: 'Are you sure you want to delete? ',
            negativeText: 'Cancel',
            positiveText: 'Delete',
            isSucessPopup: false,
            positiveTextColor: ColorValues.circle4,
            onNegativeTap: () {},
            onPositiveTap: () {
              apiCallingForUnfriend(
                id,
                index,
              );
            },
          );
        });
  }

  Future apiCallingForAccept(connectionId, index, type, userIsActive) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            isNeedToRefresh = true;
            searchtagList.clear();
            tagList.removeAt(index);
            searchtagList.addAll(tagList);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForUnfriend(connectionId, int index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId)
      };
      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            if(index > -1){
              searchtagList.removeAt(index);
              tagList.removeAt(index);
            }
            isNeedToRefresh = true;
            setState(() {});
          }
        }
      }
    } catch (e) {
      debugPrint('apiCallingForUnfriend error ${e.toString()}');
    }
  }

  getName(PeopleYouMayKnow, requestedTagModel) {
    String firstName, lastName;

    if (PeopleYouMayKnow != null) {
      if (PeopleYouMayKnow.lastName == null ||
          PeopleYouMayKnow.lastName == "null" ||
          PeopleYouMayKnow.lastName == "") {
        lastName = "";
      } else {
        lastName = PeopleYouMayKnow.lastName;
      }

      if (PeopleYouMayKnow.firstName == null ||
          PeopleYouMayKnow.firstName == "null" ||
          PeopleYouMayKnow.firstName == "") {
        firstName = PeopleYouMayKnow.email;
      } else {
        firstName = PeopleYouMayKnow.firstName;
      }

      return firstName + " " + lastName;
    } else {
      if (requestedTagModel.patner.lastName == null ||
          requestedTagModel.patner.lastName == "null" ||
          requestedTagModel.patner.lastName == "") {
        lastName = "";
      } else {
        lastName = requestedTagModel.patner.lastName;
      }

      if (requestedTagModel.patner.firstName == null ||
          requestedTagModel.patner.firstName == "null" ||
          requestedTagModel.patner.firstName == "") {
        firstName = requestedTagModel.patner.email;
      } else {
        firstName = requestedTagModel.patner.firstName;
      }

      return firstName + " " + lastName;
    }
  }

  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => true;
}
