import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:spike_view_project/common/CommonFullViewWidget.dart';

import 'package:spike_view_project/common/palette.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';

import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/customViews/CustomViews.dart';
import 'package:spike_view_project/modal/ScoreDataModel.dart';

import 'package:spike_view_project/profile_bloc_pattern/models/profile_detail_model.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/full_image_widget.dart';
import 'package:url_launcher/url_launcher.dart';

// Create a Form Widget
class DocumentPerformance extends StatefulWidget {
  Scores testModel;
  ScoreDataModel model;
  String subjectName;

  DocumentPerformance(this.testModel, {this.model, this.subjectName});

  @override
  DocumentPerformanceState createState() {
    return DocumentPerformanceState(testModel);
  }
}

class DocumentPerformanceState extends State<DocumentPerformance> {
  Scores testModel;
  static const platform = const MethodChannel('samples.flutter.io/battery');

  DocumentPerformanceState(this.testModel);

  //=========================================================Api Calling =======================================

  @override
  void initState() {
    super.initState();
    if (testModel == null) {
      testModel = Scores(
          sId: widget.model.sId,
          userTestId: widget.model.userTestId,
          testId: widget.model.testId,
          userId: widget.model.userId,
          dateTaken: widget.model.dateTaken,
          imageUrl: widget.model.imageUrl,
          docUrl: widget.model.docUrl,
          name: widget.model.name,
          isProfileDisplay: widget.model.isProfileDisplay);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;

    return GestureDetector(
        child: WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: GestureDetector(
                child: customAppbar(
                    context,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(
                                left: 20.0, right: 20, top: 24, bottom: 0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                BaseText(
                                  text: testModel.name,
                                  textColor:
                                      ColorValues.HEADING_COLOR_EDUCATION_1,
                                  fontFamily:
                                      AppConstants.stringConstant.latoMedium,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 28,
                                  textAlign: TextAlign.start,
                                  maxLines: 3,
                                ),
                                widget.subjectName != null&& widget.subjectName!=''
                                    ?Padding(
                                  padding: const EdgeInsets.only(
                                      top: 4.0, bottom: 0),
                                  child: BaseText(
                                    text:widget.subjectName,
                                    textColor: ColorValues.labelColor,
                                    fontFamily: AppConstants
                                        .stringConstant.latoRegular,
                                    fontWeight: FontWeight.w400,
                                    fontSize: 16,
                                    textAlign: TextAlign.center,
                                    maxLines: 1,
                                  ),
                                )
                                    :testModel.subjects!=null&& testModel.subjects.length == 1
                                        ? Padding(
                                            padding: const EdgeInsets.only(
                                                top: 4.0, bottom: 0),
                                            child: BaseText(
                                              text:
                                                  testModel.subjects[0].subject,
                                              textColor: ColorValues.labelColor,
                                              fontFamily: AppConstants
                                                  .stringConstant.latoRegular,
                                              fontWeight: FontWeight.w400,
                                              fontSize: 16,
                                              textAlign: TextAlign.center,
                                              maxLines: 1,
                                            ),
                                          )
                                        : SizedBox(),
                              ],
                            ),
                          ),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0,
                              0.0,
                              0.0,
                              5.0,
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Expanded(
                                    child: ListView(
                                      children: <Widget>[
                                        testModel.docUrl.length > 0
                                            ? Container(
                                                padding: EdgeInsets.fromLTRB(
                                                    20.0, 0.0, 0.0, 0.0),
                                                child: GridView.count(
                                                  primary: false,
                                                  shrinkWrap: true,
                                                  padding:
                                                      const EdgeInsets.all(0.0),
                                                  crossAxisSpacing: 10.0,
                                                  childAspectRatio: 1.0,
                                                  scrollDirection:
                                                      Axis.vertical,
                                                  crossAxisCount: 3,
                                                  children: testModel.docUrl
                                                      .map((file) {
                                                    return Stack(
                                                      children: <Widget>[
                                                        Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    0.0,
                                                                    0,
                                                                    0,
                                                                    0),
                                                            child: InkWell(
                                                              child: Container(
                                                                  height: 96.0,
                                                                  width: 96.0,
                                                                  child: Image
                                                                      .asset(
                                                                    "assets/png/pdf.png",
                                                                    height:
                                                                        96.0,
                                                                    width: 96.0,
                                                                  )),
                                                              onTap: () {
                                                                launch(Constant
                                                                        .IMAGE_PATH +
                                                                    file);
                                                              },
                                                            )),
                                                      ],
                                                    );
                                                  }).toList(),
                                                ))
                                            : SizedBox(),
                                        testModel.docUrl.length > 0
                                            ? Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 20,
                                                    right: 20,
                                                    top: 10.0,
                                                    bottom: 15),
                                                child: Container(
                                                  height: 1,
                                                  color: AppConstants.colorStyle
                                                      .borderColorBTN,
                                                ),
                                              )
                                            : SizedBox(),
                                        testModel.imageUrl.length > 0
                                            ? Container(
                                                padding: EdgeInsets.fromLTRB(
                                                    20.0, 0.0, 0.0, 0.0),
                                                child: GridView.count(
                                                    primary: false,
                                                    shrinkWrap: true,
                                                    padding:
                                                        const EdgeInsets.all(
                                                            0.0),
                                                    crossAxisSpacing: 10.0,
                                                    childAspectRatio: 1.0,
                                                    scrollDirection:
                                                        Axis.vertical,
                                                    crossAxisCount: 3,
                                                    children: List.generate(
                                                        testModel
                                                            .imageUrl.length,
                                                        (int index2) {
                                                      return InkWell(
                                                        onTap: () {

                                                          Navigator.of(context).push(
                                                            MaterialPageRoute(
                                                              builder:
                                                                  (context) =>
                                                                  FullImageWidget(
                                                                    type: FullImageType.urlList,
                                                                    imagePath: '',
                                                                    imagesUrlList: testModel
                                                                        .imageUrl,
                                                                    listInitialIndex: index2,
                                                                    toolbarTitle: MessageConstant
                                                                        .TEST_SCORE_HEDING,
                                                                  ),
                                                            ),
                                                          );

                                                     /*     Navigator.of(context).push(new MaterialPageRoute(
                                                              builder: (BuildContext
                                                                      context) =>
                                                                  CommonFullViewWidget(
                                                                      testModel
                                                                          .imageUrl,
                                                                      MessageConstant
                                                                          .TEST_SCORE_HEDING,
                                                                      index2,
                                                                      MessageConstant
                                                                          .TEST_SCORE_HEDING)));*/
                                                        },
                                                        child: Container(
                                                            height: 96.0,
                                                            child: Stack(
                                                              children: <
                                                                  Widget>[
                                                                Positioned(
                                                                  top: 5.0,
                                                                  child: Column(
                                                                    children: <
                                                                        Widget>[
                                                                      FadeInImage
                                                                          .assetNetwork(
                                                                        fit: BoxFit
                                                                            .cover,
                                                                        placeholder:
                                                                            'assets/aerial/default_img.png',
                                                                        image: Constant.IMAGE_PATH +
                                                                            testModel.imageUrl[index2],
                                                                        height:
                                                                            96.0,
                                                                        width:
                                                                            96.0,
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                /*  Padding(
                                                              padding:
                                                              const EdgeInsets.fromLTRB(
                                                                  0.0, 5, 0, 0),
                                                              child:     Container(
                                                                height: 50.0,
                                                                width: 75.0,
                                                                color:     Color(0XFFC0C0C0)
                                                                    .withOpacity(.4),
                                                              ),
                                                            ),*/
                                                              ],
                                                            )),
                                                      );
                                                    })))
                                            : SizedBox(),
                                      ],
                                    ),
                                    flex: 1,
                                  )
                                ],
                              )),
                          flex: 1,
                        ),
                        Expanded(
                          child: Stack(
                            children: [
                              InkWell(
                                child: PaddingWrap.paddingfromLTRB(
                                    20.0,
                                    20.0,
                                    20.0,
                                    20.0,
                                    Container(
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color:
                                              AppConstants.colorStyle.lightBlue,
                                          border: Border.all(
                                              color: AppConstants
                                                  .colorStyle.lightBlue),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        child: Align(
                                            alignment: Alignment.center,
                                            // Align however you like (i.e .centerRight, centerLeft)
                                            child: Text(
                                              "Done",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                color: ColorValues.WHITE,
                                                fontFamily: AppConstants
                                                    .stringConstant.latoMedium,
                                                fontSize: 18.0,
                                              ),
                                            )))),
                                onTap: () async {
                                  Navigator.pop(context);
                                },
                              ),
                            ],
                          ),
                          flex: 0,
                        )
                      ],
                    ), () {
              Navigator.pop(context);
            }, isShowIcon: false))));
  }
}
