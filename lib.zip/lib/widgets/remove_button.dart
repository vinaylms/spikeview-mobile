import 'package:flutter/material.dart';

class RemoveButton extends StatelessWidget {
  final VoidCallback onTap;

  const RemoveButton({
    @required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return  InkWell(
      child: Image.asset(
        'assets/profile/skills/red_close.png',
        height: 25,
        width: 25,
      ),
      onTap: onTap,
    );
  }
}
