import 'package:flutter/material.dart';
import 'package:spike_view_project/modal/patner/time_between.dart';
class OperationNewClass {
  //List<TextEditingController> startTimeController =[], endTimeController = [];
  String dayName;
  bool duplicateValue = false;
  bool isSelect = false;

  List<DayScheduleData> dayScheduleData =  List();
  //List<TimeBetween> toFromTime = [];

  //OperationNewClass(this.startTimeController, this.endTimeController, this.dayName, this.isSelect,this.toFromTime);
  OperationNewClass(this.dayName, this.isSelect,this.duplicateValue, this.dayScheduleData);


  /*Map<String, dynamic> toJson() => {
    "dayName": dayName,
    "startTime": startTimeController,
    "endTime": endTimeController,
    "open": isSelect,
    "toFromTime" : toFromTime
  };*/
  Map<String, dynamic> toJson() => {
    "day": dayName,
    "open": isSelect,
    "hours" : dayScheduleData
  };

}

class DayScheduleData {
  //TimeBetween toFromTime;
  String toTime = "";
  String fromTime = "";
  int timeFrom = 0;
  int timeTo = 0;
  TextEditingController startTimeController, endTimeController;

  DayScheduleData({this.toTime, this.fromTime,this.timeTo, this.timeFrom,this.startTimeController,this.endTimeController});
}