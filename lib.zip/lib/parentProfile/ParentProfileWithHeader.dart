import 'dart:async';

import 'dart:ui';

import 'package:spike_view_project/ChatReafctor/model/FrienndListModel.dart';
import 'package:spike_view_project/ChatReafctor/view/chat_room.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/group/RequestedGroupList.dart';
import 'package:spike_view_project/modal/GroupListForUserModel.dart';
import 'package:spike_view_project/modal/RequestedTagListModel.dart';
import 'package:dio/dio.dart';
import 'package:flutter/rendering.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/api_interface/ApiCallingWithoutProgressIndicator.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:spike_view_project/common/CustomProgressDialog.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/modal/ConnectionModel.dart';
import 'package:spike_view_project/modal/NarrativeModel.dart';
import 'package:spike_view_project/modal/ProfileEducationModel.dart';
import 'package:spike_view_project/modal/ProfileInfoModel.dart';
import 'package:spike_view_project/modal/StudentDataModel.dart';
import 'package:spike_view_project/modal/option_menu.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:spike_view_project/common/crashlytics_widget.dart';
import 'package:spike_view_project/report/ReportWidget.dart';

import 'package:spike_view_project/values/ColorValues.dart';
import 'package:spike_view_project/widgets/ProfileImageView.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class ParentProfilePageWithHeader extends StatefulWidget {
  static String tag = 'login-page';
  String parentId, callingType;
  String connectionId, groupId;
  String requestStatus;

  ParentProfilePageWithHeader(this.parentId, this.callingType,
      {this.connectionId, this.requestStatus, this.groupId});

  @override
  ParentProfilePageWithHeaderState createState() =>
      ParentProfilePageWithHeaderState();
}

final formKey = GlobalKey<FormState>();

class ParentProfilePageWithHeaderState
    extends State<ParentProfilePageWithHeader> {
  Color borderColor = Colors.amber;
  bool isRememberMe = false;
  bool isDataRember = false;
  String strNetworkImage = "";
  String token, roleId;
  ProfileInfoModal profileInfoModal;
  List<StudentDataModel> listStudent = List();
  List<ProfileEducationModal> userEducationList = List<ProfileEducationModal>();
  List<NarrativeModel> narrativeList = List<NarrativeModel>();
  List<Recomdation> recommendationtList = List<Recomdation>();
  BuildContext context;
  SharedPreferences prefs;
  String strSummary;
  String strAccCount = "", strRecCount = "";
  bool isActive = false;
  ConnectionModel connectionModel;
  bool isSentRequest = true;
  StreamSubscription<dynamic> _streamSubscription;
  bool isConnected = false;
  bool isParentApprovalPending = false;
  bool isAccepetd = false;
  String connectId = "0";
  bool isSubscribe = false;
  int subsCriberId = 0;
  ScrollController _scrollController = ScrollController();
  bool isTitleVisible = false;
  bool isDataLoading = true;
  static StreamController syncDoneController = StreamController.broadcast();
  bool isCallStudentRequestApi = false;
  List<RequestedTagModel> pendinForParentDataList = List();
  List<RequestedTagModel> receivedRequestList = List();

  String searchUserAccessConnection = "";

  Future apiGetAccessControl() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      Response response = await ApiCalling2().apiCall(
          context,
          Constant.ACCESS_CONTROL +
              profileInfoModal.schoolCode +
              "&userId=" +
              profileInfoModal.userId +
              "&roleId=2",
          "get");
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            searchUserAccessConnection = response.data['result']
                    ['accessControl']['connection']
                .toString();
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  //--------------------------Profile Info api ------------------
  Future profileApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(
          context,
          widget.callingType == "search"
              ? Constant.ENDPOINT_PERSONAL_INFO_NEW +
                  widget.parentId +
                  "/true/" +
                  "2/" +
                  roleId
              : Constant.ENDPOINT_PERSONAL_INFO_NEW +
                  widget.parentId +
                  "/false/" +
                  "2/" +
                  roleId,
          "get");

      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            profileInfoModal =
                ParseJson.parseMapUserProfile(response.data['result']);

            if (profileInfoModal != null) {
              try {
                if (profileInfoModal.schoolCode != null &&
                    profileInfoModal.schoolCode != "") {
                  await apiGetAccessControl();
                }
              } catch (e) {}
              strNetworkImage = profileInfoModal.profilePicture;
              setState(() {
                strNetworkImage;
                profileInfoModal;
              });
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      e.toString();
    }
  }

  //--------------------------  api ------------------
  Future apiCallForConnect() async {
    try {
      bool ageStatus = false;
      if (prefs.getString(UserPreference.DOB) != null &&
          prefs.getString(UserPreference.DOB) != 'null') {
        ageStatus = Util.currentAge(
                DateTime.fromMillisecondsSinceEpoch(
                    int.tryParse(prefs.getString(UserPreference.DOB))),
                13) <
            13;
      }
      Map map = {
        "userId": prefs.getString(UserPreference.USER_ID),
        "partnerId": int.parse(widget.parentId),
        "userRoleId": roleId,
        "partnerRoleId": 2,
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": ageStatus ? "Pending" : "Requested",
        "isActive": profileInfoModal.isActive
      };

      print("connect+++" + map.toString());
      Response response = await ApiCalling().apiCallPostWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            // ToastWrap.showToast(msg);
            String connectId = response.data["result"]["connectId"].toString();
            this.connectId = connectId;
            setState(() {
              isConnected = true;
              isAccepetd = false;
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future apiCallForCheckSubscribe() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;

        if (prefs.getBool(UserPreference.IS_PARENT)) {
          uri = Constant.ENDPOINT_CHECK_IS_SUBSCRIBE +
              prefs.getString(UserPreference.PARENT_ID) +
              "&partnerId=" +
              widget.parentId +
              "&partnerRoleId=2&userRoleId=" +
              prefs.getString(UserPreference.ROLE_ID);
        } else {
          uri = Constant.ENDPOINT_CHECK_IS_SUBSCRIBE +
              prefs.getString(UserPreference.USER_ID) +
              "&partnerId=" +
              widget.parentId +
              "&partnerRoleId=2&userRoleId=" +
              prefs.getString(UserPreference.ROLE_ID);
        }
        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            var map = response.data['result'];
            if (map.length > 0) {
              String status = map[map.length - 1]['status'];
              subsCriberId = map[map.length - 1]['subscribeId'];
              if (status == "Un-Subscribe") {
                isSubscribe = false;
              } else {
                isSubscribe = true;
              }
              if (mounted) {
                setState(() {
                  isSubscribe;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future apiCallForUnSubscribe() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "subscribeId": subsCriberId,
          "userId": prefs.getString(UserPreference.USER_ID),
          "followerId": widget.parentId,
          "userRoleId": roleId,
          "partnerRoleId": 2,
          "followerName": profileInfoModal.lastName == null ||
                  profileInfoModal.lastName == ""
              ? profileInfoModal.firstName
              : profileInfoModal.firstName + " " + profileInfoModal.lastName,
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "isActive": true,
          "status": "Un-Subscribe"
        };
        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_SUBSCRIBE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast("Un-Subscribe Successfully");
              if (mounted) {
                setState(() {
                  isSubscribe = false;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future apiCallForSubscribe() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {
          "userId": prefs.getString(UserPreference.USER_ID),
          "followerId": widget.parentId,
          "userRoleId": roleId,
          "partnerRoleId": 2,
          "followerName": profileInfoModal.lastName == null ||
                  profileInfoModal.lastName == ""
              ? profileInfoModal.firstName
              : profileInfoModal.firstName + " " + profileInfoModal.lastName,
          "dateTime": DateTime.now().millisecondsSinceEpoch,
          "isActive": true,
          "status": "Subscribe"
        };
        Response response = await ApiCalling()
            .apiCallPostWithMapData(context, Constant.ENDPOINT_SUBSCRIBE, map);
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              // ToastWrap.showToast(msg);
              if (mounted) {
                setState(() {
                  isSubscribe = true;
                });
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  //--------------------------  api ------------------
  Future apiCallDisConnect() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Map map = {"connectId": int.parse(connectId), "roleId": roleId};
        Response response = await ApiCalling().apiCallDeleteWithMapData(
            context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              //ToastWrap.showToast(msg);
              setState(() {
                isConnected = false;
                isAccepetd = false;
              });
            } else {
              ToastWrap.showToastLong(msg, context);
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future studentByParentApi(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response = await ApiCalling2().apiCall(context,
          Constant.ENDPOINT_PARENT_STUDENTSBYPARENT + widget.parentId, "get");
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          if (status == "Success") {
            listStudent.clear();
            listStudent =
                ParseJson.parseMapStudentByParent(response.data['result']);
            if (listStudent != null) {
              setState(() {
                listStudent;
              });
            }
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
    }
  }

  Future apiCallingForAccept() async {
    try {
      Map map = {
        "connectId": int.parse(widget.connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": widget.requestStatus,
        "isActive": "true",
        "roleId": 2,
        "userId": int.parse(widget.parentId),
      };
      Response response = await ApiCalling2().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("connect:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            ToastWrap.showToastGreen(
                MessageConstant.PARENT_ACCEPT_CONNECTION_MSG, context);
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

   Future apiCallForChildConnectionStatus() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;
        uri = Constant.ENDPOINT_CHILD_CONNECTION_STATUS + widget.connectionId;

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print("ENDPOINT_CHILD_CONNECTION_STATUS++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status =
                response.data[LoginResponseConstant.STATUS].toString();
            if (status == "Success") {
              setState(() {
                isCallStudentRequestApi = true;
              });
            } else {
              String msg =
                  response.data[LoginResponseConstant.MESSAGE].toString();
              if (msg != null && msg != "null") {
                setState(() {
                  isCallStudentRequestApi = false;
                });
                ToastWrap.showToastGreen(msg, context);
              }
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future apiCallForChildList() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;
        uri = Constant.ENDPOINT_CHILD_LIST +
            prefs.getString(UserPreference.PARENT_ID) +
            "&partnerId=" +
            widget.parentId +
            "&roleId=" +
            roleId +
            "&partnerRoleId=2";

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print("getChildRequest++++" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            pendinForParentDataList.clear();
            receivedRequestList.clear();
            String status = response.data[LoginResponseConstant.STATUS];

            var map = response.data['result'];

            if (map.length > 0) {
              pendinForParentDataList = ParseJson.parseRequestedTagList(
                  response.data['result']['Pending']);

              receivedRequestList = ParseJson.parseRequestedTagList(
                  response.data['result']['receivedRequest']);
            }
            setState(() {});
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future apiCallingForDeleteStudentConnection(connectionId, index) async {
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "roleId": int.parse(roleId),
        "userId": prefs.getString(UserPreference.PARENT_ID)
      };
      Response response = await ApiCalling().apiCallDeleteWithMapData(
          context, Constant.ENDPOINT_CONNECTION_DELETE_UPDATE, map);

      print("response:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            syncDoneController.add("");
            apiCallForChildList();
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
    }
  }

  Future apiCallingForAcceptChildRequest(
      connectionId, index, type, userIsActive) async {
    print("datatat");
    try {
      Map map = {
        "connectId": int.parse(connectionId),
        "dateTime": DateTime.now().millisecondsSinceEpoch,
        "status": type,
        "isActive": userIsActive,
        "roleId": int.parse(roleId),
        "userId": int.parse(widget.parentId),
      };
      Response response = await ApiCalling().apiCallPutWithMapData(
          context, Constant.ENDPOINT_CONNECTION_UPDATE, map);

      print("connect:-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            ToastWrap.showToastGreen(
                MessageConstant.PARENT_ACCEPT_CONNECTION_MSG, context);
            syncDoneController.add("");
            apiCallForChildList();
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
    }
  }

  void educationRemoveConfromationDialog(
      id, name, index, int listType, requestedTagModel) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return ConfirmationDialog(
          msg: "This connection request will be declined.",
          onPositiveTap: () {
            apiCallingForDeleteStudentConnection(id, index);
          },
        );
      },
    );
  }

  Container getListviewForPending(
      requestedTagModel, index, bool isSentRequest, status) {
    return Container(
        color: Colors.transparent,
        padding: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
        child: Card(
            color: Colors.transparent,
            elevation: 0.0,
            child: Column(
              children: <Widget>[
                InkWell(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    RichText(
                                        maxLines: 1,
                                        textAlign: TextAlign.start,
                                        text: TextSpan(
                                          text: "From ",
                                          style: TextStyle(
                                            color: ColorValues
                                                .HEADING_COLOR_EDUCATION,
                                            fontSize: 14.0,
                                            fontFamily:
                                                Constant.TYPE_CUSTOMREGULAR,
                                          ),
                                          children: <TextSpan>[
                                            TextSpan(
                                                text: requestedTagModel.userData
                                                                .lastName ==
                                                            null ||
                                                        requestedTagModel
                                                                .userData
                                                                .lastName ==
                                                            "null" ||
                                                        requestedTagModel
                                                                .userData
                                                                .lastName ==
                                                            ""
                                                    ? requestedTagModel
                                                        .userData.firstName
                                                    : requestedTagModel.userData
                                                            .firstName +
                                                        " " +
                                                        requestedTagModel
                                                            .userData.lastName,
                                                style: TextStyle(
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMBOLD,
                                                    fontSize: 14.0,
                                                    color: ColorValues
                                                        .GREY_TEXT_COLOR))
                                          ],
                                        )))
                              ],
                            )),
                        flex: 1,
                      ),
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            isSentRequest
                                ? Text("")
                                : InkWell(
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                            height: 45.0,
                                            width: 45.0,
                                            child: Image.asset(
                                              'assets/newDesignIcon/connections/tick_blue.png',
                                            ))),
                                    onTap: () {
                                      apiCallingForAcceptChildRequest(
                                          requestedTagModel.connectId,
                                          index,
                                          "Requested",
                                          requestedTagModel.userIsActive);
                                    },
                                  ),
                            InkWell(
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                  child: Container(
                                      height: 35.0,
                                      width: 35.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel.png',
                                      ))),
                              onTap: () {
                                String name =
                                    requestedTagModel.patner.lastName == null ||
                                            requestedTagModel.patner.lastName ==
                                                "null" ||
                                            requestedTagModel.patner.lastName ==
                                                ""
                                        ? requestedTagModel.patner.firstName
                                        : requestedTagModel.patner.firstName +
                                            " " +
                                            requestedTagModel.patner.lastName;

                                educationRemoveConfromationDialog(
                                    requestedTagModel.connectId,
                                    name,
                                    index,
                                    2,
                                    requestedTagModel);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ),
                index > 0
                    ? Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                        child: Divider(
                          color: ColorValues.DARK_GREY,
                          height: 0.5,
                        ))
                    : Container(
                        height: 0.0,
                      ),
              ],
            )));
  }

  Container getListviewForRecieveList(
      requestedTagModel, index, bool isSentRequest, status) {
    return Container(
        color: Colors.transparent,
        padding: EdgeInsets.fromLTRB(10.0, 5.0, 10.0, 0.0),
        child: Card(
            color: Colors.transparent,
            elevation: 0.0,
            child: Column(
              children: <Widget>[
                InkWell(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Expanded(
                        child: PaddingWrap.paddingfromLTRB(
                            10.0,
                            0.0,
                            0.0,
                            0.0,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    RichText(
                                      maxLines: 1,
                                      textAlign: TextAlign.start,
                                      text: TextSpan(
                                        text: "For ",
                                        style: TextStyle(
                                          color: ColorValues.GREY_TEXT_COLOR,
                                          fontSize: 14.0,
                                          fontFamily:
                                              Constant.TYPE_CUSTOMREGULAR,
                                          fontWeight: FontWeight.normal,
                                        ),
                                        children: <TextSpan>[
                                          TextSpan(
                                              text: requestedTagModel.patner
                                                              .lastName ==
                                                          null ||
                                                      requestedTagModel.patner
                                                              .lastName ==
                                                          "null" ||
                                                      requestedTagModel.patner
                                                              .lastName ==
                                                          ""
                                                  ? requestedTagModel
                                                      .patner.firstName
                                                  : requestedTagModel
                                                          .patner.firstName +
                                                      " " +
                                                      requestedTagModel
                                                          .patner.lastName,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.normal,
                                                  fontFamily:
                                                      Constant.TYPE_CUSTOMBOLD,
                                                  fontSize: 14.0,
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR))
                                        ],
                                      ),
                                    ))
                              ],
                            )),
                        flex: 1,
                      ),
                      Expanded(
                        child: Row(
                          children: <Widget>[
                            isSentRequest
                                ? Text("")
                                : InkWell(
                                    child: Padding(
                                        padding: EdgeInsets.fromLTRB(
                                            0.0, 0.0, 0.0, 0.0),
                                        child: Container(
                                            height: 45.0,
                                            width: 45.0,
                                            child: Image.asset(
                                              'assets/newDesignIcon/connections/tick_blue.png',
                                            ))),
                                    onTap: () {
                                      apiCallingForAcceptChildRequest(
                                          requestedTagModel.connectId,
                                          index,
                                          "Accepted",
                                          requestedTagModel.userIsActive);
                                    },
                                  ),
                            InkWell(
                              child: Padding(
                                  padding:
                                      EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                                  child: Container(
                                      height: 35.0,
                                      width: 35.0,
                                      child: Image.asset(
                                        'assets/newDesignIcon/connections/cancel.png',
                                      ))),
                              onTap: () {
                                String name = requestedTagModel
                                                .userData.lastName ==
                                            null ||
                                        requestedTagModel.userData.lastName ==
                                            "null" ||
                                        requestedTagModel.userData.lastName ==
                                            ""
                                    ? requestedTagModel.userData.firstName
                                    : requestedTagModel.userData.firstName +
                                        " " +
                                        requestedTagModel.userData.lastName;

                                educationRemoveConfromationDialog(
                                    requestedTagModel.connectId,
                                    name,
                                    index,
                                    1,
                                    requestedTagModel);
                              },
                            )
                          ],
                        ),
                        flex: 0,
                      ),
                    ],
                  ),
                ),
                index > 0
                    ? Padding(
                        padding: EdgeInsets.fromLTRB(0.0, 5.0, 0.0, 0.0),
                        child: Divider(
                          color: ColorValues.DARK_GREY,
                          height: 0.5,
                        ))
                    : Container(
                        height: 0.0,
                      ),
              ],
            )));
  }

  GroupListForUserModel _mGroupListForUserModel;

  Future apiCallForGetRequestData() async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        Response response;
        String uri;

        uri = Constant.ENDPOINT_GROUP_REQUESTED_BY_USER +
            prefs.getString(UserPreference.USER_ID) +
            "&roleId=" +
            prefs.getString(UserPreference.ROLE_ID) +
            "&requestedBy=" +
            widget.parentId +
            "&requestedRole=" +
            "2";

        print(uri);
        response = await ApiCalling2().apiCall(context, uri, "get");
        print(response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            _mGroupListForUserModel =
                GroupListForUserModel.fromJson(response.data);
            setState(() {
            });
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  Future apiCallingForAcceptGroupRequest(type) async {
    try {
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        /*  Map map = {
          "groupId": int.parse(groupId),
          "userId": int.parse(userIdPref),
          "roleId": int.parse(roleId),
          "status": type
        };*/

        Map map = {
          "groupId": int.parse(widget.groupId),
          "userId": int.parse(profileInfoModal.userId),
          "roleId": int.parse(profileInfoModal.roleId),
          "isAdmin": true,
          "status": type
        };

        print("map++++" + map.toString());
        Response response = await ApiCalling().apiCallPutWithMapData(
            context, Constant.ENDPOINT_UPDATE_GROUP_REQUEST, map);

        print("response:-" + response.toString());
        if (response != null) {
          if (response.statusCode == 200) {
            String status = response.data[LoginResponseConstant.STATUS];
            String msg = response.data[LoginResponseConstant.MESSAGE];
            if (status == "Success") {
              setState(() {
                widget.groupId = null;
                isPerformChanges = "push";
              });
            }
          }
        }
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  showInvitationDialog(context) {
    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                // Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  body: Stack(
                    children: [
                      Positioned(
                        right: 13.0,
                        top: 70.0,
                        left: 13.0,
                        child: Container(
                          color: Colors.black,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0, 13, 0),
                                      child: Text("RESPOND REQUEST",
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.white,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR))),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.fromLTRB(0.0, 3, 0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color: ColorValues.GREY__COLOR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("REJECT",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                          )),
                                      onTap: () {
                                        Navigator.pop(context);
                                        apiCallingForAcceptGroupRequest(
                                            "Rejected");
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        20.0, 3, 12.0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("ACCEPT",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                          )),
                                      onTap: () {
                                        Navigator.pop(context);
                                        apiCallingForAcceptGroupRequest(
                                            "Accepted");
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                          right: 2.0,
                          top: 60.0,
                          child: InkWell(
                              child: Image.asset(
                                "assets/black_circle_cancel.png",
                                height: 30.0,
                                width: 30.0,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              }))
                    ],
                  )),
              onTap: () {
                // Navigator.pop(context);
              },
            )));
  }

  showInvitationDialogForNumberOfRequest(context) {
    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              //  Navigator.pop(context);
            },
            child: GestureDetector(
              onHorizontalDragUpdate: (GestureDragUpdateCallback) {
                // Navigator.pop(context);
              },
              child: Scaffold(
                  backgroundColor: Colors.transparent,
                  body: Stack(
                    children: [
                      Positioned(
                        right: 13.0,
                        top: 70.0,
                        left: 13.0,
                        child: Container(
                          color: Colors.black,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0, 0, 0),
                                      child: Text(
                                          "Join group request (" +
                                              _mGroupListForUserModel
                                                  .groupList.length
                                                  .toString() +
                                              ")",
                                          style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.white,
                                              fontFamily: Constant
                                                  .TYPE_CUSTOMREGULAR))),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                        10.0, 3, 12.0, 3),
                                    child: InkWell(
                                      child: Container(
                                          color:
                                              ColorValues.BLUE_COLOR_BOTTOMBAR,
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(
                                                10.0, 5, 10, 5),
                                            child: Text("View Request",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.white,
                                                    fontFamily: Constant
                                                        .TYPE_CUSTOMREGULAR)),
                                          )),
                                      onTap: () async {
                                        String result = await Navigator.of(
                                                context)
                                            .push(new MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    RequestedGroupList(
                                                        _mGroupListForUserModel,
                                                        profileInfoModal.userId,
                                                        profileInfoModal
                                                            .roleId)));
                                        if (result == "push") {
                                          isPerformChanges = "push";
                                          apiCallForGetRequestData();
                                        }
                                      },
                                    ),
                                  ),
                                  flex: 0,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                          right: 2.0,
                          top: 60.0,
                          child: InkWell(
                              child: Image.asset(
                                "assets/black_circle_cancel.png",
                                height: 30.0,
                                width: 30.0,
                              ),
                              onTap: () {
                                Navigator.pop(context);
                              }))
                    ],
                  )),
              onTap: () {
                // Navigator.pop(context);
              },
            )));
  }

  bool isConnection_AccessControl = true;
  bool isProfileVisiblity = true;
  bool isChat_AccessControl = true;

  getSharedPreferences() async {
    setState(() {
      isDataLoading = true;
    });
    prefs = await SharedPreferences.getInstance();
    token = prefs.getString(UserPreference.USER_TOKEN);
    roleId = prefs.getString(UserPreference.ROLE_ID);
    try {
      isProfileVisiblity =
      prefs.getString(UserPreference.ACCESS_CONTROL_PROFILE_VISIBILITY) ==
          "enable"
          ? true
          : false;
    } catch (e) {
      isProfileVisiblity = true;
    }
    if (!isProfileVisiblity) {
      setState(() {
        isDataLoading = false;
      });
      try {
        isConnection_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
            .toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isConnection_AccessControl = true;
      }
      if(isConnection_AccessControl){
        ToastWrap.showToastWithPushMultiLine(
            MessageConstant.PROFILE_VISIBILITY_DISABLED_CONNECTION_ENABLED, context);
      }else {
        ToastWrap.showToastWithPushMultiLine(
            MessageConstant.PROFILE_VISIBILITY_DISABLED, context);
      }
      // Navigator.pop(context);
    }else {
      try {
        isConnection_AccessControl = prefs
            .getString(UserPreference.ACCESS_CONTROL_CONNECTION)
            .toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isConnection_AccessControl = true;
      }
      try {
        isChat_AccessControl =
        prefs.getString(UserPreference.ACCESS_CONTROL_CHAT).toLowerCase() ==
            "disable"
            ? false
            : true;
      } catch (e) {
        isChat_AccessControl = true;
      }

      setState(() {});
      var isConnect = await ConectionDetecter.isConnected();
      if (isConnect) {
        if (widget.groupId == null &&
            widget.callingType != "notification" &&
            widget.callingType != "ActionPerformed" &&
            widget.callingType != "pushNotification")
          await apiCallForGetRequestData();

        CustomProgressLoader.showLoader2(context);

        if (widget.connectionId != null &&
            widget.connectionId != "" &&
            roleId == "2" &&
            (widget.callingType == "redirect" ||
                widget.callingType == "view" ||
                widget.callingType == "notification")) {
          await apiCallForChildConnectionStatus();
        }
        if ((widget.connectionId != null && widget.connectionId != "") &&
            widget.callingType == "redirect" &&
            isCallStudentRequestApi) {
          await apiCallingForAccept();
        }

        if (roleId == "2") {
          await apiCallForChildList();
        }

        await apiCallForCheckSubscribe();
        await apiCallForCheckIsFriend(false);

        await profileApi(false);
        await studentByParentApi(false);
        isDataLoading = false;
        CustomProgressLoader.cancelLoader(context);
      } else {
        ToastWrap.showToast(
            MessageConstant.CONNECTION_NOT_AVAILABLE_ERROR, context);
      }
      if (widget.callingType == "ActionPerformed") {
        ToastWrap.showToast2Sec("Action already been taken", context);
      }
      Timer(const Duration(milliseconds: 2500), () async {
        if (widget.groupId != null) showInvitationDialog(context);
        if (_mGroupListForUserModel != null &&
            _mGroupListForUserModel.groupList.length > 0) {
          showInvitationDialogForNumberOfRequest(context);
        }
      });
    }
  }

  String isPerformChanges = "pop";

  @override
  void initState() {
    print("changes");

    _scrollController.addListener(() {
      if (_scrollController.offset < 300.0) {
        setState(() {
          isTitleVisible = false;
        });
      } else {
        setState(() {
          isTitleVisible = true;
        });
      }

      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {}
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {}
    });
    getSharedPreferences();
    _streamSubscription =
        DashBoardStateParent.syncDoneController.stream.listen((value) {
      apiUpdated(value);
    });
    super.initState();
  }

  void apiUpdated(String result) async {
    profileApi(true);
  }

  Future apiCallForCheckIsFriend(isShowLaoder) async {
    try {
      if (isShowLaoder) CustomProgressLoader.showLoader(context);
      Response response;
      String uri;

      if (prefs.getBool(UserPreference.IS_PARENT)) {
        uri = Constant.ENDPOINT_CHECK_IS_FRIEND +
            prefs.getString(UserPreference.PARENT_ID) +
            "&partnerId=" +
            widget.parentId +
            "&partnerRoleId=2&userRoleId=" +
            prefs.getString(UserPreference.ROLE_ID);
      } else {
        uri = Constant.ENDPOINT_CHECK_IS_FRIEND +
            prefs.getString(UserPreference.USER_ID) +
            "&partnerId=" +
            widget.parentId +
            "&partnerRoleId=2&userRoleId=" +
            prefs.getString(UserPreference.ROLE_ID);
      }
      print(uri);
      response = await ApiCalling2().apiCall(context, uri, "get");
      print(response.toString());
      if (isShowLaoder) CustomProgressLoader.cancelLoader(context);
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          var map = response.data['result'];
          if (map.length > 0) {
            isConnected = true;

            String status = map[map.length - 1]['status'];
            isSubscribe = false;
            if (status == "Accepted") {
              isAccepetd = true;
              isSubscribe = true;
            } else if (status == "Requested") {
              isAccepetd = false;
            } else if (status == "Pending") {
              isParentApprovalPending = true;
            } else {
              isConnected = false;
            }

            String connectId = map[map.length - 1]['connectId'].toString();
            String userId = map[map.length - 1]['userId'].toString();
            String partnerId = map[map.length - 1]['partnerId'].toString();
            String dateTime = map[map.length - 1]['dateTime'].toString();
            int lastSeen = map[map.length - 1]['lastSeen'];
            int online = map[map.length - 1]['online'];
            this.connectId = connectId;
            try {
              String requestType =
                  map[map.length - 1]['requestType'].toString();

              if (requestType == "ReceivedByUnder13") {
                isSentRequest = false;
              } else {
                isSentRequest = true;
              }
            } catch (e) {
              crashlytics_bloc.recordCrashlyticsError(
                  e, "ParentProfileWithHeader", context);
            }
            connectionModel = ConnectionModel(connectId, userId, partnerId,
                dateTime, status, lastSeen, online);
            setState(() {
            });
          }
        }
      }
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      e.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    this.context = context;

    return WillPopScope(
      onWillPop: () {
        onBack();
        return Future.value(false);
      },
      child: Scaffold(
        /* appBar: AppBar(
            automaticallyImplyLeading: false,
            titleSpacing: 0.0,
            brightness: Brightness.light,
            leading: IconButton(
                icon: Image.asset("assets/newDesignIcon/icon/back_icon.png",
                    height: 32.0, width: 32.0, fit: BoxFit.fill),
                onPressed: () {
                  onBack();
                }),
            actions: [
              InkWell(
                child: Container(
                    padding: EdgeInsets.fromLTRB(20.0, 0.0, 13.0, 0.0),
                    child: Image.asset(
                      "assets/png/more.png",
                      width: 32.0,
                      height: 32.0,
                    )),
                onTap: () {
                  optionMenu();
                },
              )
            ],
            backgroundColor: Colors.white,
            elevation: 0.0,
          ),*/
        body: Container(
          color: Colors.white,
          child: ListView(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 50, 20, 0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          child: Image.asset(
                            "assets/new_onboarding/back_blue_icon.png",
                            height: 32.0,
                            width: 32.0,
                            fit: BoxFit.fill,
                          ),
                          onTap: () => onBack(),
                        ),
                        InkWell(
                          child: Image.asset(
                            "assets/png/more.png",
                            width: 32.0,
                            height: 32.0,
                          ),
                          onTap: () => optionMenu(),
                        )
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              0.0, 10.0, 13.0, 10.0,  Container(
                              width: 65.0,
                              height: 65.0,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: [
                                  BoxShadow(
                                    color: ColorValues.light_blue,
                                    offset: Offset(0, 2),
                                    blurRadius: 6,
                                  ),
                                ],
                                border: Border.all(
                                  color: ColorValues.light_blue,
                                  width: 5,
                                ),
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0),
                                child:FadeInImage.assetNetwork(
                                    fit: BoxFit.contain,
                                    placeholder: 'assets/profile/user_on_user.png',
                                    image: profileInfoModal == null
                                        ? ""
                                        : Constant.IMAGE_PATH_SMALL +
                                        ParseJson.getMediumImage(
                                            profileInfoModal.profilePicture)

                                ),
                              ))),
                          flex: 0,
                        ),
                        Expanded(
                          child: PaddingWrap.paddingfromLTRB(
                              5.0,
                              0.0,
                              0.0,
                              8.0,
                              Container(
                                  child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  PaddingWrap.paddingAll(
                                    2.0,
                                    TextViewWrap.textViewMultiLine(
                                        profileInfoModal == null
                                            ? ""
                                            : profileInfoModal.lastName == "" ||
                                                    profileInfoModal.lastName ==
                                                        "null"
                                                ? profileInfoModal.firstName
                                                : profileInfoModal.firstName +
                                                    " " +
                                                    profileInfoModal.lastName,
                                        TextAlign.start,
                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                        getLenthOfName() > 24 ? 22.0 : 24.0,
                                        FontWeight.normal,
                                        2),
                                  ),
                                ],
                              ))),
                          flex: 1,
                        )
                      ],
                    ),
                  ],
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  roleId == "4"
                      ? const SizedBox.shrink()
                      : prefs != null &&
                              profileInfoModal != null &&
                              Util.showAcceptButton(
                                      prefs,
                                      profileInfoModal.schoolCode,
                                      searchUserAccessConnection) ==
                                  "true"
                          ? getUiButtonsIfStudentLoggedIn()
                          : const SizedBox.shrink(),
                  (pendinForParentDataList.length > 0 ||
                              receivedRequestList.length > 0) &&
                          roleId == "2"
                      ? PaddingWrap.paddingfromLTRB(
                          20.0,
                          5.0,
                          20.0,
                          10.0,
                          Container(
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                      color: ColorValues.BORDER_COLOR,
                                      width: 0.5)),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  receivedRequestList.length == 0
                                      ? const SizedBox.shrink()
                                      : Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child: Container(
                                            child: Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              13.0,
                                                              0.0,
                                                              0.0,
                                                              0.0),
                                                      child: Text(
                                                        "APPROVE THIS CONNECTION REQUEST(S)",
                                                        style: TextStyle(
                                                            fontSize: 12.0,
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            fontFamily: Constant
                                                                .customRegular),
                                                      )),
                                                  flex: 1,
                                                ),
                                              ],
                                            ),
                                            color: Color(0xffDEDEDE),
                                            height: 25.0,
                                          )),
                                  receivedRequestList.length == 0
                                      ? const SizedBox.shrink()
                                      : Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 5.0, 0.0, 10.0),
                                          child: Column(
                                            children: List.generate(
                                                receivedRequestList.length,
                                                (int index) {
                                              return getListviewForRecieveList(
                                                  receivedRequestList[index],
                                                  index,
                                                  false,
                                                  "Requested");
                                            }),
                                          )),
                                  pendinForParentDataList.length == 0
                                      ? const SizedBox.shrink()
                                      : Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          child: Container(
                                            child: Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Padding(
                                                      padding:
                                                          EdgeInsets.fromLTRB(
                                                              13.0,
                                                              0.0,
                                                              0.0,
                                                              0.0),
                                                      child: Text(
                                                        "APPROVE THIS SENT REQUEST(S)",
                                                        style: TextStyle(
                                                            fontSize: 12.0,
                                                            color: ColorValues
                                                                .HEADING_COLOR_EDUCATION,
                                                            fontFamily: Constant
                                                                .customRegular),
                                                      )),
                                                  flex: 1,
                                                ),
                                              ],
                                            ),
                                            color: Color(0xffDEDEDE),
                                            height: 25.0,
                                          )),
                                  pendinForParentDataList.length == 0
                                      ? const SizedBox.shrink()
                                      : Padding(
                                          padding: EdgeInsets.fromLTRB(
                                              0.0, 5.0, 0.0, 10.0),
                                          child: Column(
                                            children: List.generate(
                                                pendinForParentDataList.length,
                                                (int index) {
                                              return getListviewForPending(
                                                  pendinForParentDataList[
                                                      index],
                                                  index,
                                                  roleId == "2" ? false : true,
                                                  "Requested");
                                            }),
                                          )),
                                ],
                              )))
                      : const SizedBox.shrink(),
                  isDataLoading
                  ?const SizedBox.shrink()
                      : listStudent.length > 0
                      ? getStudentsUi()
                      : PaddingWrap.paddingfromLTRB(
                          13.0,
                          10.0,
                          13.0,
                          20.0,
                          Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                    color: ColorValues.LIGHT_GREY_TEXT_COLOR,
                                    width: 0.5)),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                PaddingWrap.paddingfromLTRB(
                                    0.0,
                                    10.0,
                                    0.0,
                                    0.0,
                                    Image.asset(
                                      "assets/no_child.png",
                                      width: 300.0,
                                      height: 151.0,
                                    )),
                                PaddingWrap.paddingfromLTRB(
                                    13.0,
                                    7.0,
                                    13.0,
                                    30.0,
                                    TextViewWrap.textViewMultiLine(
                                        "No profile details available. Please check back later.",
                                        TextAlign.center,
                                        ColorValues.GREY_TEXT_COLOR,
                                        14.0,
                                        FontWeight.normal,
                                        4)),
                              ],
                            ),
                          ),
                        ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _loader(BuildContext context, String placeHolderImage) => Center(
          child: Container(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.cover,
        ),
      ));

  Widget _error(String placeHolderImage) {
    return Center(
      child: Image.asset(
        placeHolderImage,
        fit: BoxFit.fill,
      ),
    );
  }

  Widget isImageSelectedView() {
    return Container(
      width: 65.0,
      height: 65.0,
      child: Stack(
        children: <Widget>[




          Center(
            child: Stack(
              children: [
                Container(
                  width: 65.0,
                  height: 65.0,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: ColorValues.light_blue,
                        offset: Offset(0, 2),
                        blurRadius: 6,
                      ),
                    ],
                    border: Border.all(
                      color: ColorValues.light_blue,
                      width: 5,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: profileInfoModal != null
                        ?  ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: FadeInImage.assetNetwork(
                        fit: BoxFit.fill,
                        placeholder: 'assets/profile/user_on_user.png',
                        image: profileInfoModal == null
                            ? ""
                            : Constant.IMAGE_PATH_SMALL +
                            ParseJson.getMediumImage(
                                profileInfoModal.profilePicture)

                      ),
                    )



                        : Image.asset("assets/profile/user_on_user.png"),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  int getLenthOfName() {
    int lenght = 0;
    if (profileInfoModal == null) {
      return 0;
    } else {
      if (profileInfoModal.lastName == "" ||
          profileInfoModal.lastName == "null") {
        lenght = 0;
      } else {
        lenght = profileInfoModal.firstName.length +
            profileInfoModal.lastName.length;
      }
    }
    return lenght;
  }

  Padding getUiButtonsIfStudentLoggedIn() {
    return PaddingWrap.paddingfromLTRB(
      20.0,
      20.0,
      20.0,
      10.0,
      Container(
        decoration: BoxDecoration(
          color: Color(0xffFBFBFB),
          borderRadius: BorderRadius.circular(10),
        ),
        child: isParentApprovalPending
            ? Padding(
                padding: const EdgeInsets.all(15.0),
                child: Center(
                    child: BaseText(
                  text: isSentRequest
                      ? connectionModel.userId ==
                              prefs.getString(UserPreference.PARENT_ID)
                          ? "Your parent approval pending"
                          : "Pending from parent"
                      : connectionModel.partnerId ==
                              prefs.getString(UserPreference.PARENT_ID)
                          ? "Your parent approval pending"
                          : "Pending from parent",
                  textColor: Color(0xff4684EB),
                  fontFamily: AppConstants.stringConstant.latoRegular,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  maxLines: 1,
                )),
              )
            : Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          isConnected
                              ? isAccepetd
                                  ? InkWell(
                                      child: Column(
                                        children: <Widget>[
                                          Image.asset(
                                            "assets/newDesignIcon/userprofile/right.png",
                                            width: 18.0,
                                            height: 18.0,
                                          ),
                                          SizedBox(height: 1,),
                                          BaseText(
                                            text: "Connected",
                                            textColor: AppConstants
                                                .colorStyle.lightBlue,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            maxLines: 1,
                                          )
                                        ],
                                      ),
                                      onTap: () {
                                        //  removeConnectionConformationDialog();
                                      },
                                    )
                                  : InkWell(
                                      child: Column(
                                        children: <Widget>[
                                          Image.asset(
                                            "assets/newIcon/cancle_blue.png",
                                            width: 22.0,
                                            height: 22.0,
                                          ),
                                          SizedBox(height: 1,),
                                          BaseText(
                                            text: "Withdraw",
                                            textColor: AppConstants
                                                .colorStyle.lightGreyShade,
                                            fontFamily: AppConstants
                                                .stringConstant.latoRegular,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            maxLines: 1,
                                          )
                                        ],
                                      ),
                                      onTap: () {
                                        apiCallDisConnect();
                                      },
                                    )
                              : InkWell(
                                  child: Column(
                                    children: <Widget>[
                                      Image.asset(
                                        "assets/newDesignIcon/userprofile/connect.png",
                                        width: 22.0,
                                        height: 22.0,
                                      ),
                                      SizedBox(height: 1,),
                                      BaseText(
                                        text: "Connect",
                                        textColor: AppConstants
                                            .colorStyle.lightGreyShade,
                                        fontFamily: AppConstants
                                            .stringConstant.latoRegular,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        maxLines: 1,
                                      )
                                    ],
                                  ),
                                  onTap: () {
                                    if (isConnection_AccessControl) {
                                      apiCallForConnect();
                                    } else {
                                      ToastWrap.showToastForAccessDenied(
                                          MessageConstant.FEATURE_DIABLED, context);
                                    }
                                  },
                                )
                        ],
                      ),
                      flex: 1,
                    ),
                    isSubscribe || isAccepetd
                        ? Expanded(
                            child: Center(
                              child: InkWell(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/newDesignIcon/userprofile/subscribe_blue.png",
                                      width: 20.0,
                                      height: 20.0,
                                    ),
                                    SizedBox(height: 1,),
                                    BaseText(
                                      text: "Following",
                                      textColor:
                                          AppConstants.colorStyle.lightBlue,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      maxLines: 1,
                                    )
                                  ],
                                ),
                                onTap: () {
                                  apiCallForUnSubscribe();
                                },
                              ),
                            ),
                            flex: 1,
                          )
                        : Expanded(
                            child: Center(
                              child: InkWell(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/newDesignIcon/userprofile/subscribe.png",
                                      width: 20.0,
                                      height: 20.0,
                                    ),
                                    SizedBox(height: 1,),
                                    BaseText(
                                      text: "Follow",
                                      textColor: AppConstants
                                          .colorStyle.lightGreyShade,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      maxLines: 1,
                                    )
                                  ],
                                ),
                                onTap: () {
                                  apiCallForSubscribe();
                                },
                              ),
                            ),
                            flex: 1,
                          ),
                    isConnected && isAccepetd
                        ? Expanded(
                            child: Center(
                              child: InkWell(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Image.asset(
                                      "assets/newDesignIcon/userprofile/msg.png",
                                      width: 22.0,
                                      height: 22.0,
                                    ),
                                    SizedBox(height: 1,),
                                    BaseText(
                                      text: "Chat",
                                      textColor: AppConstants
                                          .colorStyle.lightGreyShade,
                                      fontFamily: AppConstants
                                          .stringConstant.latoRegular,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      maxLines: 1,
                                    )
                                  ],
                                ),
                                onTap: () {
                                  String userIdNew =
                                      prefs.getString(UserPreference.PARENT_ID);

                                  Friends model = Friends(
                                      connectId:
                                          int.parse(connectionModel.connectId),
                                      userId: int.parse(prefs
                                          .getString(UserPreference.PARENT_ID)),
                                      firstName: profileInfoModal.firstName,
                                      lastName: profileInfoModal.lastName,
                                      profilePicture:
                                          profileInfoModal.profilePicture,
                                      partnerId: int.parse(
                                          connectionModel.partnerId == userIdNew
                                              ? connectionModel.userId
                                              : connectionModel.partnerId),
                                      partnerFirstName:
                                          profileInfoModal.firstName,
                                      partnerLastName:
                                          profileInfoModal.lastName,
                                      partnerRoleId: 2,
                                      partnerProfilePicture:
                                          profileInfoModal.profilePicture,
                                      dateTime:
                                          DateTime.now().millisecondsSinceEpoch,
                                      creationTime: profileInfoModal
                                                      .creationTime !=
                                                  null &&
                                              profileInfoModal.creationTime !=
                                                  "null" &&
                                              profileInfoModal.creationTime !=
                                                  ""
                                          ? int.parse(profileInfoModal.creationTime)
                                          : 0,
                                      isActive: true,
                                      online: connectionModel.online == null || connectionModel.online == "null" ? 0 : connectionModel.online,
                                      lastMessage: "",
                                      unreadMessages: 0,
                                      lastTime: 0,
                                      lastSeen: connectionModel.lastSeen == null || connectionModel.lastSeen == "null" ? 0 : connectionModel.lastSeen,
                                      textSentBy: int.parse(prefs.getString(UserPreference.USER_ID)));

                                  if (isChat_AccessControl) {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder:
                                                (BuildContext context) =>
                                                ChatRoomWidget(
                                                    model, "", "")));
                                  } else {
                                    ToastWrap.showToastForAccessDenied(
                                        MessageConstant.FEATURE_DIABLED,
                                        context);
                                  }
                                },
                              ),
                            ),
                            flex: 1,
                          )
                        : Expanded(
                            child: const SizedBox.shrink(),
                            flex: 0,
                          ),
                  ],
                ),
              ),
      ),
    );
  }

//-----------------------------------------Student List Design ----------------------------------------
  onTapStudentItem(index) {
    Util.onTapImageTile(
        tapedUserRole: listStudent[index].roleId,
        partnerUserId: listStudent[index].userId,
        context: context);
  }

  Widget getStudentsUi() {
    return PaddingWrap.paddingfromLTRB(
      20.0,
      15.0,
      20.0,
      0.0,
      Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(
              color: Colors.white,
              width: 1,
            )),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            BaseText(
              text: profileInfoModal != null
                  ? profileInfoModal.firstName != null &&
                          profileInfoModal.firstName != "null"
                      ? profileInfoModal.firstName + "'s " + "Children"
                      : "Children"
                  : "Children",
              textColor: ColorValues.HEADING_COLOR_EDUCATION_1,
              fontFamily: AppConstants.stringConstant.latoRegular,
              fontWeight: FontWeight.w700,
              fontSize: 18,
              textAlign: TextAlign.start,
              maxLines: 3,
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                listStudent.length,
                (int index) {
                  return Container(
                    decoration: BoxDecoration(
                        color: Color(0xffE8ECFF),
                        borderRadius: BorderRadius.circular(10.0),
                        border: Border.all(
                          color: Color(0xffE8ECFF),
                          width: 1,
                        )),
                    margin: const EdgeInsets.only(top: 10.0),
                    child: InkWell(
                      child: PaddingWrap.paddingfromLTRB(
                        0.0,
                        10.0,
                        0.0,
                        10.0,
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Expanded(
                              child: PaddingWrap.paddingfromLTRB(
                                  11.0,
                                  0.0,
                                  11.0,
                                  0.0,
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      InkWell(
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[



                                            Expanded(
                                              child:
                                              ProfileImageView(
                                                imagePath:Constant
                                                    .IMAGE_PATH_SMALL +
                                                    ParseJson.getMediumImage(
                                                        listStudent[index]
                                                            .profilePicture),
                                                placeHolderImage:  'assets/profile/user_on_user.png',
                                                height: 48.0,
                                                width: 48.0,
                                                onTap: () async{

                                                },
                                              ),
                                              flex: 0,
                                            ),
                                            Expanded(
                                              child:
                                                  PaddingWrap.paddingfromLTRB(
                                                      10.0,
                                                      0.0,
                                                      0.0,
                                                      0.0,
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Row(
                                                            children: <Widget>[
                                                              Expanded(
                                                                child: BaseText(
                                                                  text: listStudent[index]
                                                                              .lastName ==
                                                                          "null"
                                                                      ? listStudent[
                                                                              index]
                                                                          .firstName
                                                                      : listStudent[index]
                                                                              .firstName +
                                                                          " " +
                                                                          listStudent[index]
                                                                              .lastName,
                                                                  textColor:
                                                                      ColorValues
                                                                          .HEADING_COLOR_EDUCATION_1,
                                                                  fontFamily: AppConstants
                                                                      .stringConstant
                                                                      .latoRegular,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                  fontSize: 16,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .start,
                                                                  maxLines: 3,
                                                                ),
                                                                flex: 1,
                                                              ),
                                                            ],
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .fromLTRB(
                                                                    0.0,
                                                                    0,
                                                                    12,
                                                                    8),
                                                            child: listStudent[index]
                                                                            .tagline ==
                                                                        null ||
                                                                    listStudent[index]
                                                                            .tagline ==
                                                                        "null" ||
                                                                    listStudent[index]
                                                                            .tagline ==
                                                                        ""
                                                                ? Container(
                                                                    height: 0.0,
                                                                  )
                                                                : BaseText(
                                                                    text: listStudent[index].tagline ==
                                                                            "null"
                                                                        ? ""
                                                                        : listStudent[index]
                                                                            .tagline,
                                                                    textColor: AppConstants
                                                                        .colorStyle
                                                                        .lightPurple,
                                                                    fontFamily: AppConstants
                                                                        .stringConstant
                                                                        .latoRegular,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    fontSize:
                                                                        14,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .start,
                                                                    maxLines: 3,
                                                                  ),
                                                          ),
                                                        ],
                                                      )),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                        onTap: () {
                                          onTapStudentItem(index);
                                        },
                                      )
                                    ],
                                  )),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  onTapReport() async {
    String result = await Navigator.of(context).push(new MaterialPageRoute(
        builder: (BuildContext context) =>
            Report("profile", "", "", widget.parentId, roleIdUser: "2")));
    if (result == "push") {
      Navigator.pop(context);
    }
  }

  void optionMenu() {
    final List<OptionMenu> list = [];
    list.add(OptionMenu(
        title: "Report profile",
        onTap: () {
          onTapReport();
        }),
    );

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isDismissible: false,
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ListView.separated(
                  itemBuilder: (_, index) {
                    return InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        list[index].onTap();
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: BaseText(
                          text: list[index].title,
                          maxLines: 1,
                          textAlign: TextAlign.center,
                          textColor: const Color(0xff30322F),
                          fontFamily: AppConstants.stringConstant.latoRegular,
                          fontWeight: FontWeight.w500,
                          fontSize: 18,
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (_, index) => Divider(
                    height: 0,
                    thickness: 1,
                    color: const Color(0xffE8E8E8),
                  ),
                  itemCount: list.length,
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                ),
              ),
              const SizedBox(height: 10),
              InkWell(
                onTap: () => Navigator.pop(context),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: const EdgeInsets.all(13),
                  child: BaseText(
                    text: 'Cancel',
                    maxLines: 1,
                    textAlign: TextAlign.center,
                    textColor: const Color(0xff4684EB),
                    fontFamily: AppConstants.stringConstant.latoRegular,
                    fontWeight: FontWeight.w500,
                    fontSize: 18,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void onBack() {
    try {
      if (!isDataLoading) {
        if (widget.callingType.trim() == "redirect" ||
            widget.callingType.trim() == "view" ||
            widget.callingType == "pushNotification") {
          print("isDataLoading++++onBack" + isDataLoading.toString());
          if (roleId == "1") {
            // For Studenet
            Navigator.pushReplacement(
                //Constant.applicationContext,
                context,
                MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) => DashBoardWidget(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));
          } else if (roleId == "2") {
            Navigator.pushReplacement(
                //Constant.applicationContext,
                context,
                MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) => DashBoardWidgetParent(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));

            // For Parent
          } else if (roleId == "4") {
            Navigator.pushReplacement(
                //Constant.applicationContext,
                context,
                MaterialPageRoute(
                    //   builder: (context) =>  DashBoardWidget()));
                    builder: (context) => DashBoardWidgetPartner(
                        prefs.getString(UserPreference.IS_PARENT_ROLE),
                        prefs.getString(UserPreference.IS_PARTNER_ROLE),
                        prefs.getString(UserPreference.IS_USER_ROLE),
                        currentPage: Constant.PROFILE_TYPE)));

            // For Partner
          }
          // For Parent

        } else {
          print("isDataLoading++pop" + isDataLoading.toString());
          Navigator.pop(context, isPerformChanges);
        }
      } else {}
    } catch (e) {
      crashlytics_bloc.recordCrashlyticsError(
          e, "ParentProfileWithHeader", context);
      print("ERrrrr++++++" + e.toString());
    }
  }
}
