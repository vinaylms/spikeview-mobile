import 'dart:async';
import 'package:spike_view_project/common/CommonFullViewWidget.dart';
import 'package:spike_view_project/common/theme/app_text_styles.dart';
import 'package:spike_view_project/component/app_constants.dart';
import 'package:spike_view_project/component/base_text.dart';
import 'package:spike_view_project/component/custom_app_bar.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Parent.dart';
import 'package:spike_view_project/drawer/Dash_Board_Widget_Partner.dart';
import 'package:adhara_socket_io/manager.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:page_indicator/page_indicator.dart';
import 'package:spike_view_project/common/Util.dart';
import 'package:spike_view_project/constant/MessageConstant.dart';
import 'package:spike_view_project/constant/Padding_Wrap.dart';
import 'package:spike_view_project/constant/TextLength.dart';
import 'package:spike_view_project/constant/TextView_Wrap.dart';
import 'package:spike_view_project/group/GroupDetailWidget.dart';

import 'package:spike_view_project/notification/model/GroupDetailForReport.dart';
import 'package:spike_view_project/notification/model/UserDetailForReport.dart';
import 'package:spike_view_project/parser/ParseJson.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:spike_view_project/ResponseDart/LoginResponseConstant.dart';
import 'package:spike_view_project/UserPreferences/UserPreference.dart';
import 'package:spike_view_project/api_interface/ApiCalling.dart';
import 'package:spike_view_project/common/Connectivity.dart';
import 'package:dio/dio.dart';
import 'package:spike_view_project/common/ToastWrap.dart';
import 'package:spike_view_project/constant/Constant.dart';
import 'package:spike_view_project/values/ColorValues.dart';
import 'package:flutter/services.dart';
import 'package:spike_view_project/webview/WebViewWidget.dart';
import 'package:spike_view_project/widgets/confirmation_dialog.dart';

class GroupReportWidgetBoat extends StatefulWidget {
  String feedId, pageName, requestId;

  GroupReportWidgetBoat(this.feedId, this.pageName, this.requestId);

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return GroupReportWidgetBoatWidgetBoatState();
  }
}

class GroupReportWidgetBoatWidgetBoatState
    extends State<GroupReportWidgetBoat> {
  SharedPreferences prefs;
  String userIdPref, roleId;
  bool isLoading = true;
  GroupDetailForReport groupDetailForReport;
  String dob;
  RegExp exp = RegExp(
      r"(http|ftp|https|Https|Http)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?");

  var showAll = true;
  final length = 50;
  showSucessMsg(msg, context, duration, maxLine) {
    /*Timer _timer;

    print("timer on");
    _timer = Timer(Duration(milliseconds: duration), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: maxLine == 2 ? 65.0 : 85.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: maxLine,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: msg,
                                    style: TextStyle(
                                        color: Color(0xff408738),
                                        fontSize: 13.0,
                                        fontWeight: FontWeight.normal,
                                        fontFamily: Constant.customRegular),
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {
                _timer.cancel();
                Navigator.pop(context);
              },
            )));*/

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isDismissible: false,
        builder: (_) {
          return ConfirmationDialog(
            negativeText: 'OK',
            msg: msg,
            isSucessPopup: true,
            onNegativeTap: (){
              onBack();
            },
          );
        });
  }

  void conformationDialogForCommunityPost(msg, value) {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {
              Navigator.pop(context);
            },
            child: SafeArea(
                child: Scaffold(
                    backgroundColor: Colors.black38,
                    body: Stack(
                      children: <Widget>[
                        Positioned(
                            right: 0.0,
                            left: 0.0,
                            bottom: 40.0,
                            child: Container(
                                height: 200.0,
                                color: Colors.transparent,
                                child: Stack(
                                  children: <Widget>[
                                    PaddingWrap.paddingfromLTRB(
                                        13.0,
                                        20.0,
                                        13.0,
                                        0.0,
                                        ListView(children: <Widget>[
                                          Container(
                                            height: 145.0,
                                            padding: EdgeInsets.all(10.0),
                                            width: double.infinity,
                                            color: Colors.white,
                                            child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    msg,
                                                    textAlign: TextAlign.center,
                                                    maxLines: 5,
                                                    style: TextStyle(
                                                        color: ColorValues
                                                            .HEADING_COLOR_EDUCATION,
                                                        height: 1.2,
                                                        fontSize: 16.0,
                                                        fontFamily: Constant
                                                            .TYPE_CUSTOMREGULAR),
                                                  ),
                                                ]),
                                          )
                                        ])),
                                  ],
                                ))),
                        Positioned(
                          right: 0.0,
                          left: 0.0,
                          bottom: 10.0,
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: PaddingWrap.paddingfromLTRB(
                                13.0,
                                0.0,
                                13.0,
                                0.0,
                                Container(
                                    color: Colors.white,
                                    padding: EdgeInsets.all(10.0),
                                    height: 51.0,
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "Cancel",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .GREY_TEXT_COLOR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                          ),
                                          flex: 1,
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            child: Container(
                                                child: Text(
                                              "OK",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: ColorValues
                                                      .BLUE_COLOR_BOTTOMBAR,
                                                  fontSize: 16.0,
                                                  fontFamily: Constant
                                                      .TYPE_CUSTOMREGULAR),
                                            )),
                                            onTap: () {
                                              Navigator.pop(context);
                                              apiCallingForUpdate();
                                            },
                                          ),
                                          flex: 1,
                                        )
                                      ],
                                    ))),
                          ),
                        ),
                      ],
                    )))));
  }

  showErrorMsg(msg, context) {
    Timer _timer;

    print("timer on");
    _timer = Timer(const Duration(milliseconds: 3000), () async {
      print("timer off");
      Navigator.pop(context);
      onBack();
    });

    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) => WillPopScope(
            onWillPop: () {},
            child: GestureDetector(
              child: Scaffold(
                backgroundColor: Colors.transparent,
                body: Stack(
                  children: <Widget>[
                    Positioned(
                        right: 0.0,
                        top: 55.0,
                        left: 0.0,
                        child: Container(
                          height: 65.0,
                          padding: EdgeInsets.fromLTRB(12.0, 10.0, 0, 10.0),
                          color: Color(0xffF1EDC3),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                RichText(
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  text: TextSpan(
                                    text: 'ERROR: ',
                                    style: TextStyle(
                                      color: Color(0xffFF0101),
                                      height: 1.2,
                                      fontSize: 13.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    children: <TextSpan>[
                                      TextSpan(
                                        text: msg,
                                        style: TextStyle(
                                            color: Color(0xffFF0101),
                                            fontSize: 13.0,
                                            fontWeight: FontWeight.normal,
                                            fontFamily: Constant.customRegular),
                                      )
                                    ],
                                  ),
                                )
                              ]),
                        )),
                  ],
                ),
              ),
              onTap: () {},
            )));
  }

  Future apiCallingForGetData() async {
    try {
      Response response;

      print("group response  ::-" +
          Constant.REPORT_GROUP_UNBLOCK +
          widget.feedId +
          "&requestId=" +
          widget.requestId);
      response = await ApiCalling().apiCall(
          context,
          Constant.REPORT_GROUP_UNBLOCK +
              widget.feedId +
              "&requestId=" +
              widget.requestId,
          "get");
      print("group response  ::-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          groupDetailForReport = GroupDetailForReport.fromJson(response.data);

          print("groupDetailForReport.result.isActive ::-" + groupDetailForReport.result.isActive.toString());
          setState(() {});
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  Future apiCallingForUpdate() async {
    try {
      Response response;

      Map map = {
        "userId": userIdPref,
        "roleId": roleId,
        "id": widget.feedId,
        "reportType": "Group",
      };
      print("map:-" + map.toString());

      response = await ApiCalling()
          .apiCallPutWithMapData(context, Constant.REPORT_FEED_UNBLOCK, map);
      print(" group response  :-" + response.toString());
      if (response != null) {
        if (response.statusCode == 200) {
          String status = response.data[LoginResponseConstant.STATUS];
          String msg = response.data[LoginResponseConstant.MESSAGE];
          if (status == "Success") {
            showSucessMsg(msg, context, 3000, 2);
            setState(() {});
          }
        }
      }
    } catch (e) {
      e.toString();
    }
  }

  getSharedPreferences() async {
    prefs = await SharedPreferences.getInstance();
    userIdPref = prefs.getString(UserPreference.USER_ID);
    roleId = prefs.getString(UserPreference.ROLE_ID);

    apiCallingForGetData();
  }

  onBack() async {
    if (widget.pageName == "") {
      String roleId = prefs.getString(UserPreference.ROLE_ID);

      if (roleId == "2") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetParent(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else if (roleId == "4") {
        Navigator.of(context).push(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidgetPartner(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      } else {
        Navigator.of(context).pushReplacement(new MaterialPageRoute(
            builder: (BuildContext context) => DashBoardWidget(
                prefs.getString(UserPreference.IS_PARENT_ROLE),
                prefs.getString(UserPreference.IS_PARTNER_ROLE),
                prefs.getString(UserPreference.IS_USER_ROLE))));
      }
    } else {
      Navigator.pop(context);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    getSharedPreferences();
    print("==================== INIT STATE");
  }

  @override
  Widget build(BuildContext context) {
    Constant.applicationContext = context;
    Widget _loader(BuildContext context, String placeHolderImage) => Center(
            child: Container(
          child: Image.asset(
            placeHolderImage,
            fit: BoxFit.cover,
          ),
        ));

    Widget _error(String placeHolderImage) {
      return Center(
        child: Image.asset(
          placeHolderImage,
          fit: BoxFit.fill,
        ),
      );
    }

    onTapImageTile(tapedUserId, roleId) {
      if (tapedUserId == userIdPref) {
      } else {
        Util.onTapImageTile(
            tapedUserRole: roleId,
            partnerUserId: tapedUserId,
            context: context);
      }
    }

    Container getSelectedWidgets() {
      return Container(
        //color: Colors.redAccent,
        child: MediaQuery.removePadding(
          context: context,
          removeTop: true,
          removeBottom: true,
          child: ListView(
            physics: const NeverScrollableScrollPhysics(),
            primary: true,
            shrinkWrap: true,
            children: <Widget>[
              Wrap(
                spacing: 5.0,
                runSpacing: 0.0,
                children: List<Widget>.generate(
                    groupDetailForReport.result.report.reasonType.length,
                    // place the length of the array here
                    (int index) {
                  //int h = _items[index].name.toString().length % 36;
                  //print('Height h:::: $h');
                  return InputChip(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10))),

                    label: Text(
                      '${groupDetailForReport.result.report.reasonType[index]}',
                      overflow: TextOverflow.clip,
                      style: TextStyle(
                        fontSize: 14.0,color: AppConstants.colorStyle.darkBlue,
                        fontFamily: Constant.TYPE_CUSTOMREGULAR,
                      ),
                    ),
                    // softWrap: true,maxLines: 100,
                    //materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    backgroundColor: Color(0xffC1E3FC),

                    onSelected: (bool value) {},

                    labelStyle: AppTextStyle.getDynamicStyleGroup(
                        ColorValues.HEADING_COLOR_EDUCATION,
                        16.0,
                        FontType.Regular),
                    /*TextStyle(
                          color:     ColorValues.HEADING_COLOR_EDUCATION,
                          fontSize: 16,fontFamily:
                        Constant.TYPE_CUSTOMREGULAR,
                        ),*/
                    padding: const EdgeInsets.symmetric(
                        horizontal: 5.0, vertical: 3.0),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      );
    }



    return WillPopScope(
        onWillPop: () {
          onBack();
        },
        child: Scaffold(


            body: Stack(
              children: <Widget>[
                Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(
                              "assets/generateScript/script_background.png"),
                          fit: BoxFit.fill)),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 40, left: 20, right: 20),
                  child: SizedBox(
                    height: 103,
                    width: double.infinity,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            onBack();                        // Navigator.pop(context, isPerformChnges);
                          },
                          child: Image.asset(
                            "assets/generateScript/back.png",
                            height: 32.0,
                            width: 32.0,
                          ),
                        ),


                        Container(
                          width: 80,
                          height: 32,
                          decoration: BoxDecoration(
                            border: Border.all(
                                width:
                                2.0,
                                color: Color(
                                    0xffB2BDDB)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: InkWell(
                            child: Padding(
                                padding: const EdgeInsets.only(top: 4.0, left: 9.0, right: 0,bottom: 4),
                                child: Text(
                                  "See more",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: ColorValues.labelColor,
                                    fontFamily: Constant.latoRegular,
                                    fontWeight: FontWeight.w600,
                                  ),
                                )),
                            onTap: () {
                              Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder:
                                          (BuildContext context) =>
                                          GroupDetailWidget(
                                              widget.feedId,
                                              "groupBoat",
                                              "",
                                              "",
                                              "")));
                            },
                          ),
                        )
                         ,

                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                      ),
                    ),
                    margin: const EdgeInsets.only(top: 115),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20,right: 20),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 4),
                            Expanded(
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(30),
                                    topRight: Radius.circular(30),
                                  ),
                                ),
                                child:Column(

                                    children: <Widget>[

                                      Container(
                                        margin: const EdgeInsets.only(
                                            left: 0, right: 10, top: 15,bottom: 10),
                                        alignment: Alignment.centerLeft,
                                        width:
                                        MediaQuery.of(context).size.width,
                                        color: Colors.white,
                                        child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text:   'Group report',
                                                style: AppConstants
                                                    .txtStyle.heading28_700LatoRegularDarkBlue),
                                            TextSpan(
                                                recognizer:
                                                TapGestureRecognizer()
                                                  ..onTap = () {},
                                                text: '',
                                                style: AppConstants
                                                    .txtStyle.heading26_700LatoRegularDarkBlue)
                                          ]),
                                        ),
                                      ),

                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(0.0, 0, 0, 0),
                                          child: groupDetailForReport==null|| groupDetailForReport
                                              .result==null?SizedBox(): SingleChildScrollView(
                                            child: Column(
                                              children: [
                                                Column(
                                                  children: <Widget>[

                                                    Padding(
                                                      padding: const EdgeInsets.only(right: 5.0,top: 15),
                                                      child: SizedBox(
                                                        height: 78.0,
                                                        width: 78.0,
                                                        child: Center(
                                                          child: Container(
                                                            height: 78.0,
                                                            width: 78.0,
                                                            decoration: BoxDecoration(
                                                                borderRadius: BorderRadius.circular(15),
                                                                border: Border.all(
                                                                    color: Colors.white, width: 1),
                                                                boxShadow: [
                                                                  BoxShadow(
                                                                    spreadRadius: 3,
                                                                    blurRadius: 3,
                                                                    offset: Offset(0, 3),
                                                                    color:
                                                                    Color.fromRGBO(98, 175, 226, 0.09),
                                                                  )
                                                                ]),
                                                            child: ClipRRect(
                                                                borderRadius: BorderRadius.circular(15.0),
                                                                child: FadeInImage(
                                                                  height: 78.0,
                                                                  width: 78.0,
                                                                  fit: BoxFit.cover,
                                                                  placeholder: AssetImage(
                                                                    'assets/newDesignIcon/group/default_circle_bg.png',
                                                                  ),
                                                                  image: NetworkImage( Constant.IMAGE_PATH +
                                                                      groupDetailForReport
                                                                          .result.groupImage),
                                                                )),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: const EdgeInsets.only(top:10.0),
                                                      child: BaseText(
                                                        text:groupDetailForReport.result.groupName,
                                                        textColor:
                                                        ColorValues.HEADING_COLOR_EDUCATION_1,
                                                        fontFamily: AppConstants
                                                            .stringConstant.latoMedium,
                                                        fontWeight: FontWeight.w700,
                                                        fontSize: 18,
                                                        textAlign: TextAlign.center,
                                                        maxLines: 3,
                                                      ),
                                                    ),

                                                    Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                      children: <Widget>[
                                                        Padding(
                                                          padding: const EdgeInsets.only(top: 5.0),
                                                          child: Image.asset(
                                                            groupDetailForReport.result.type ==
                                                                MessageConstant
                                                                    .ABOUT_GROUP_PRIVATE
                                                                ? "assets/png/private_group.png"
                                                                : "assets/png/public_group.png"
                                                            ,
                                                            height: 15.0,
                                                            width: 15.0,
                                                            color: AppConstants.colorStyle.lightPurple,
                                                          ),
                                                        ),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            5.0,
                                                            0.0,
                                                            0.0,
                                                            BaseText(
                                                              text:  groupDetailForReport.result.type ==
                                                                  MessageConstant
                                                                      .ABOUT_GROUP_PRIVATE
                                                                  ? MessageConstant
                                                                  .ABOUT_GROUP_PRIVATE_GROUP
                                                                  : MessageConstant
                                                                  .ABOUT_GROUP_PUBLIC_GROUP
                                                              ,
                                                              textColor:
                                                              AppConstants.colorStyle.lightGrey,
                                                              fontFamily: AppConstants
                                                                  .stringConstant.latoRegular,
                                                              fontWeight: FontWeight.w500,
                                                              fontSize: 14,
                                                              textAlign: TextAlign.start,
                                                              maxLines: 3,
                                                            )),



                                                      ],
                                                    ),






                                                 Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      children: <Widget>[
                                                        Padding(
                                                          padding: const EdgeInsets.only(top:20.0),
                                                          child: BaseText(
                                                            text: 'About group',
                                                            textColor: ColorValues.labelColor,
                                                            fontFamily:
                                                            AppConstants.stringConstant.latoRegular,
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            textAlign: TextAlign.start,
                                                            maxLines: 3,
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding: const EdgeInsets.only(top:3.0),
                                                          child:BaseText(
                                                            text: groupDetailForReport.result.aboutGroup,
                                                            textColor: ColorValues.TEXT_COLOR,
                                                            fontFamily:
                                                            AppConstants.stringConstant.latoRegular,
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            textAlign: TextAlign.start,
                                                            maxLines: 50,
                                                          ),
                                                        ),


                                                        Padding(
                                                          padding: const EdgeInsets.only(top:20.0),
                                                          child: BaseText(
                                                            text: 'Group created on',
                                                            textColor: ColorValues.labelColor,
                                                            fontFamily:
                                                            AppConstants.stringConstant.latoRegular,
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            textAlign: TextAlign.start,
                                                            maxLines: 3,
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding: const EdgeInsets.only(top:3.0),
                                                          child:BaseText(
                                                            text:  groupDetailForReport.result.creationDate.toString(),
                                                            textColor: ColorValues.TEXT_COLOR,
                                                            fontFamily:
                                                            AppConstants.stringConstant.latoRegular,
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            textAlign: TextAlign.start,
                                                            maxLines: 3,
                                                          ),
                                                        ),

                                                        groupDetailForReport.result.otherInfo=='null'||   groupDetailForReport.result.otherInfo==''?SizedBox(): Padding(
                                                          padding: const EdgeInsets.only(top:20.0),
                                                          child: BaseText(
                                                            text: 'Group rule',
                                                            textColor: ColorValues.labelColor,
                                                            fontFamily:
                                                            AppConstants.stringConstant.latoRegular,
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 14,
                                                            textAlign: TextAlign.start,
                                                            maxLines: 3,
                                                          ),
                                                        ),
                                                        groupDetailForReport.result.otherInfo=='null'||  groupDetailForReport.result.otherInfo==''?SizedBox():   Padding(
                                                          padding: const EdgeInsets.only(top:3.0),
                                                          child:BaseText(
                                                            text: groupDetailForReport.result.otherInfo,
                                                            textColor: ColorValues.TEXT_COLOR,
                                                            fontFamily:
                                                            AppConstants.stringConstant.latoRegular,
                                                            fontWeight: FontWeight.w500,
                                                            fontSize: 16,
                                                            textAlign: TextAlign.start,
                                                            maxLines: 3,
                                                          ),
                                                        ),



                                                        groupDetailForReport != null &&
                                                            groupDetailForReport
                                                                .result.report.reasonType.length >
                                                                0
                                                            ?     PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            14.0,
                                                            13.0,
                                                            8.0,
                                                            Text(
                                                              "Reason Category",
                                                              textAlign: TextAlign.start,
                                                              style: TextStyle(
                                                                  color: AppConstants.colorStyle.darkBlue,
                                                                  fontSize: 16.0,
                                                                  fontFamily:
                                                                  Constant.TYPE_CUSTOMREGULAR),
                                                            )):SizedBox(),
                                                        groupDetailForReport != null &&
                                                            groupDetailForReport
                                                                .result.report.reasonType.length >
                                                                0
                                                            ?    Padding(
                                                            padding: const EdgeInsets.fromLTRB(
                                                                0.0, 0, 0, 0),
                                                            child: getSelectedWidgets()):SizedBox(),
                                                        PaddingWrap.paddingfromLTRB(
                                                            0.0,
                                                            15.0,
                                                            0.0,
                                                            0.0,
                                                            Container(
                                                                child: Container(
                                                                    width: double.infinity,
                                                                    decoration: BoxDecoration(
                                                                        color: Colors.white,
                                                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                                                        border: Border.all(
                                                                            color: ColorValues
                                                                                .BORDER_COLOR,
                                                                            width: 0.5)),
                                                                    child: Container(
                                                                        //color: Colors.white,
                                                                        child: Column(
                                                                          crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                          mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                          children: <Widget>[
                                                                            PaddingWrap.paddingfromLTRB(
                                                                                13.0,
                                                                                13.0,
                                                                                13.0,
                                                                                13.0,
                                                                                Text(
                                                                                    groupDetailForReport
                                                                                        .result
                                                                                        .report
                                                                                        .reason,
                                                                                    overflow:
                                                                                    TextOverflow
                                                                                        .ellipsis,
                                                                                    maxLines: null,
                                                                                    style: TextStyle(
                                                                                        fontFamily:
                                                                                        Constant
                                                                                            .TYPE_CUSTOMREGULAR,
                                                                                        color:ColorValues.TEXT_COLOR,
                                                                                        fontSize:
                                                                                        14.0))),
                                                                          ],
                                                                        ))))),
                                                      ],
                                                    )

                                                  ],
                                                ),



                                              ],
                                            ),
                                          ),
                                        ),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child:  groupDetailForReport == null ||

                                            groupDetailForReport.result.isActive
                                            ? SizedBox()
                                            : PaddingWrap
                                            .paddingfromLTRB(
                                            0.0,
                                            30.0,
                                            0.0,
                                            0.0,
                                            Container(
                                                color: Colors.white,
                                                padding: EdgeInsets.all(0.0),
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: <Widget>[

                                                    Expanded(
                                                      child: InkWell(
                                                        child: Padding(
                                                          padding: const EdgeInsets.fromLTRB(
                                                              8, 0.0, 0, 15),
                                                          child: Container(
                                                              decoration: BoxDecoration(
                                                                  color: ColorValues
                                                                      .BLUE_COLOR_BOTTOMBAR,
                                                                  // border:  Border.all(

                                                                  //     width: 0.5),
                                                                  borderRadius:
                                                                  const BorderRadius.all(
                                                                      Radius.circular(10))
                                                              ),
                                                              //  color:  ColorValues.BLUE_COLOR_BOTTOMBAR,
                                                              width: 120.0,
                                                              height: 40.0,
                                                              child: Center(
                                                                child: Text(
                                                                  "Unblock",
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(
                                                                      color: Colors.white,
                                                                      fontSize: 16.0,
                                                                      fontFamily: Constant
                                                                          .TYPE_CUSTOMREGULAR),
                                                                ),
                                                              )),
                                                        ),
                                                        onTap: () {
                                                          apiCallingForUpdate();
                                                        },
                                                      ),
                                                      flex: 1,
                                                    )
                                                  ],
                                                ))) ,
                                        flex: 0,
                                      )




                                    ]),
                              ),
                            ),
                          ]),
                    ),
                  ),
                )],
            ))


    );

  }

  Widget getText(String s, int color) {
    return Padding(
      padding: const EdgeInsets.only(left: 0.0),
      child: Text(s,
          style: TextStyle(
              fontFamily: Constant.TYPE_CUSTOMREGULAR,
              color: Color(color),
              fontSize: 14.0)),
    );
  }
}

