import 'dart:io';

import 'package:spike_view_project/modal/StudentDataModel.dart';


class SpikeUserInvitationModel{
 String firstName,lastName,userId,roleId;

 SpikeUserInvitationModel(this.firstName, this.lastName, this.userId,this.roleId);
 Map<String, dynamic> toJson() => {
   'userId':int.parse(userId),
   'roleId':int.parse(roleId),

 };

}


