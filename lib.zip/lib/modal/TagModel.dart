import 'dart:io';

class TagModel {
  String userId,firstName,lastName,email,profilePicture,roleId;
  bool isSelected=false;
  String badge;
  String badgeImage;
  int gamificationPoints;
  TagModel(this.userId, this.firstName, this.lastName, this.email,
      this.profilePicture,this.isSelected,this.roleId,this.badge,this.gamificationPoints,this.badgeImage);


}


