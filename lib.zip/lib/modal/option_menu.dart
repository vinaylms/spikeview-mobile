import 'package:flutter/cupertino.dart';

class OptionMenu{
  String title;
  VoidCallback onTap;

  OptionMenu({@required this.title,@required this.onTap});
}