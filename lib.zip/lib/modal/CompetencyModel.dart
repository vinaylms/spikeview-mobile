class CompetencyModel {
  String level1;
  bool isSelected, selectAll;
  List<Level2Competencies> level2Competencylist;
  Level2Competencies selectedLevel2;

  CompetencyModel(
    this.level1,
    this.level2Competencylist,
    this.isSelected,
    this.selectAll, {
    this.selectedLevel2,
  });
}

class Level2Competencies {
  String name, competencyTypeId;
  bool isSelected;
  bool hasInfo;
  String otherName;
  List<Level3Competencies> level3Competencylist;

  Level2Competencies(
    this.name,
    this.competencyTypeId,
    this.isSelected,
    this.level3Competencylist, {
    this.otherName,
    this.hasInfo,
  });
}

class Level3Competencies {
  String name, key;

  Level3Competencies(this.name, this.key);
}
